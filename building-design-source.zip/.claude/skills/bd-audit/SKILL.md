---
name: bd-audit
description: Check an existing Building Design project (a .bdp file, or an IFC/DWG/PDF to bring in) for modelling errors, rule compliance, energy and thermal bridges, services and documentation, and write a report with the fixes. Use when asked to review, check, audit or bring up to date an existing project.
---

# Audit of an existing project

Works through the Building Design MCP server (`building-design`): the app must be running (`npm run dev`, then a
browser tab or `npm run headless`). Do not change the user's file in place: save fixes as a new file unless told.

## Steps

1. **Open.** `open_project` for a `.bdp`; `model_from_file` for IFC, DWG, DXF or PDF (then save it as `.bdp`).
   `project_summary` to see levels, elements and views.
2. **Model quality.** `physical_model_quality` (duplicates, tiny elements, walls that nearly meet, walls and beams
   short of the slab, unsupported elements) and `model_warnings` (unenclosed or doubled rooms, overlapping walls and
   openings, repeated marks and numbers, broken stair rules, lost hosts).
3. **Rules.** `check_requirements` (room sizes, heights, lighting and ventilation ratios), stairs through
   `model_warnings`.
4. **Information.** `find_by_criteria` for missing data: elements without classification, doors without mark,
   custom properties left empty (`get_property_values`). `views` and `graphic_overrides` to see how the drawings
   are set up.
5. **Building physics.** `energy_evaluation` (annual balance, heat loss per zone, envelope review) and
   `thermal_bridge` on the junctions that matter (outside corners, wall-slab in a section, columns in walls):
   report ψ and fRsi, flag fRsi below 0.75.
6. **Structure and services**, when present: the analytical model (`export_file` with `saf`; its notes say what
   was left out), `mep_networks` with `list` and `quality`, and `create_fittings` if fittings are missing.
7. **Fix** what is unambiguous (with the user's go-ahead for anything that changes the design), one undo step each;
   `save_project` to a new file.
8. **Report**: a Markdown file next to the project (`export_file` cannot write Markdown: write it yourself) with
   findings by severity, numbers (areas, U, ψ, fRsi, kWh/m²a), what was fixed, what needs a decision.
