---
name: bd-batch
description: Process a folder of drawings or projects in Building Design one after the other with no window — model each from its DWG/PDF/picture, check it, save it and export it — and write a summary table. Use for batch conversions, nightly checks, or when many files must go through the same steps.
---

# Batch work in Building Design

1. Make sure the app runs without a window: the dev server (`npm run dev`) and `npm run headless`. Check with
   `project_summary`; if it says Building Design is not open, start them (in the background) and try again.
2. List the files in the folder the user gave (absolute paths, inside the home folder). Decide per file:
   `.bdp` → `open_project`; DWG/DXF/PDF/PNG/JPG/IFC → `new_project` then `model_from_file`.
3. For each file follow the steps of the `bd-new-project` skill (model, name, check, save, export) or of
   `bd-audit` (existing projects), with the same choices for every file unless one needs otherwise.
4. Write outputs next to each source in a subfolder `building-design/` (`<name>.bdp`, `.ifc`, plan PDFs, schedules
   `.xlsx`) unless told another place.
5. Keep going when one file fails: note the error and move on.
6. At the end write `summary.md` in the folder: one row per file with levels, walls, doors, windows, zones, total
   area, problems found, files written, and errors.

To run it unattended (cron, CI, scheduled task) use `scripts/bd-job.sh` from this folder, which starts Claude Code
in print mode with only the Building Design tools allowed.
