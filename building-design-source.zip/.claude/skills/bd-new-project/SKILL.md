---
name: bd-new-project
description: Make a new Building Design project from a drawing (DWG, DXF, PDF, picture, photo, IFC) or a written brief, check it, document it and save it with its exports. Use when asked to start, model or set up a new project in Building Design.
---

# New project in Building Design

Works through the Building Design MCP server (`building-design`), so the app must be running: `npm run dev`
in this folder, and either a browser tab on it or `npm run headless` for no window. If a tool answers that
Building Design is not open, say which of the two to start.

Lengths are millimetres in every tool. Each change is one undo step.

## Steps

1. **Start.** `new_project` (metric unless the source or the user says imperial), with the project's name.
2. **Model from the source.**
   - A file on this computer: `model_from_file` with its absolute path (DWG/DXF layers, PDF vector or scanned,
     pictures, photos taken at an angle, IFC). Then look at it: `look_at_view` on the plan and the 3D view,
     `room_areas`, `model_warnings`.
   - A picture already placed, or something `model_from_file` missed: `view_image` (zoom into regions to read
     dimensions and room names), `calibrate_image`, `model_from_image`, then `trace_floor_plan` for what is missing.
   - A brief only: `create_level`, `create_walls` (closed chains, wall type by name), doors and windows with
     `run_command`/`trace_floor_plan`, rooms; ask for anything the brief leaves open that changes the design.
3. **Name and classify.** Name and number the zones from the drawing (`set_parameters`), `classify_elements`,
   and the project's own properties if the user has them (`property_groups`, `property_definitions`,
   `set_property_values`). IDs of doors and windows: `assign_ids` (e.g. prefix D/W, level code, two digits).
4. **Check.** `physical_model_quality`, `model_warnings`, `check_requirements` (Italian DM 1975 rules for rooms),
   `mep_networks` with `quality` when there are services. Fix what is clearly a modelling error; list the rest.
5. **Evaluate** when asked or when it matters: `energy_evaluation` (annual, with the city's climate),
   `thermal_bridge` on typical junctions (corner, wall-slab in a section).
6. **Document.** Schedules (`create_schedule` for doors, windows, rooms), sheets and views through
   `run_command`/`search_commands`; keynotes and graphic override rules if the user works with them.
7. **Save and export** into the folder the user named (default: next to the source file, inside the home folder):
   `save_project` (`.bdp`), `export_file` with `ifc`, `pdf` (each sheet or plan), `xlsx` (schedules), `saf`
   (structural analytical model, when there is structure), `dxf` if asked.
8. **Report** in the user's language: what was modelled (levels, walls, doors, windows, zones with areas), what the
   checks found and fixed, what is uncertain (names read from a picture, scale), and the files written.
