/**
 * Dev-server plugin: the AI's line to Claude, two ways.
 *
 *   - With ANTHROPIC_API_KEY in .env.local, the page posts one turn (system
 *     prompt, messages, tools) to /api/claude; this forwards it with the
 *     Anthropic SDK, so the key stays in Node and never reaches the browser.
 *     Model, effort and output size are set here, not by the page.
 *   - Without a key, /api/claude-code runs the Claude Code CLI (`claude -p`)
 *     on the user's own Claude Code login. It works on the project through
 *     the MCP bridge (mcp-bridge.mjs) and can use nothing else: no shell, no
 *     files, no web.
 *
 * /api/claude-backend tells the page which one is available. These run
 * before Vite's own host and CORS checks, so they make their own: only a page
 * served from this machine, posting JSON to its own origin, gets through.
 */
import Anthropic from '@anthropic-ai/sdk';
import { spawn, execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readdirSync } from 'node:fs';
import { homedir, tmpdir } from 'node:os';
import { join } from 'node:path';

// Conversations carry pictures of floor plans.
const MAX_BODY = 32 * 1024 * 1024;
const CLI_TIMEOUT = 15 * 60_000;
// Everything Claude Code could do besides the project's own tools.
const CLI_DISALLOWED = ['Bash', 'Edit', 'Write', 'Read', 'Glob', 'Grep', 'NotebookEdit', 'WebFetch', 'WebSearch', 'Task'];
const LOCAL_HOST = /^(localhost|127\.0\.0\.1|\[::1\]|[a-z0-9.-]+\.localhost)(:\d+)?$/i;
// Models that take `fallbacks: "default"`: a declined request is retried
// server-side on the model Anthropic recommends for that kind of refusal.
const FALLBACK_MODELS = new Set(['claude-opus-5-5', 'claude-opus-5', 'claude-fable-5-1', 'claude-sonnet-5-5']);

export default function claudeProxy(env) {
  const model = env.ANTHROPIC_MODEL || 'claude-opus-5-5';
  let client = null;
  return {
    name: 'claude-proxy',
    apply: 'serve',
    configureServer(server) {
      const log = server.config.logger;
      const cli = env.CLAUDE_CODE_BIN || findClaudeCode();

      server.middlewares.use('/api/claude-backend', (req, res) => {
        if (req.method !== 'POST' || !fromThisPage(req)) return reply(res, 403, { error: 'Only this app may use the AI' });
        const backend = env.ANTHROPIC_API_KEY ? 'api' : cli && env.BD_MCP_TOKEN ? 'claude-code' : 'none';
        reply(res, 200, { backend });
      });

      server.middlewares.use('/api/claude-code', async (req, res) => {
        if (req.method !== 'POST') return reply(res, 405, { error: 'Use POST' });
        if (!fromThisPage(req)) return reply(res, 403, { error: 'Only this app may use the AI' });
        if (!/^application\/json\b/i.test(req.headers['content-type'] || '')) return reply(res, 415, { error: 'Send JSON' });
        if (!cli) return reply(res, 503, { error: 'Claude Code was not found. Install it, or set CLAUDE_CODE_BIN in .env.local.' });
        if (!env.BD_MCP_TOKEN) return reply(res, 503, { error: 'No BD_MCP_TOKEN in .env.local. Run npm run mcp:setup.' });
        let body;
        try {
          body = JSON.parse(await readBody(req));
        } catch (err) {
          return reply(res, 400, { error: err.message });
        }
        const { system, message, session } = body || {};
        if (typeof message !== 'string' || !message.trim()) return reply(res, 400, { error: 'Expected a message' });
        const port = server.httpServer?.address()?.port;
        const mcp = { mcpServers: { 'building-design': { type: 'http', url: `http://localhost:${port}/mcp`, headers: { Authorization: `Bearer ${env.BD_MCP_TOKEN}` } } } };
        const args = ['-p', '--output-format', 'json', '--strict-mcp-config', '--mcp-config', JSON.stringify(mcp), '--allowedTools', 'mcp__building-design', '--disallowedTools', ...CLI_DISALLOWED];
        if (typeof system === 'string' && system) args.push('--append-system-prompt', system);
        if (typeof session === 'string' && /^[\w-]{8,64}$/.test(session)) args.push('--resume', session);
        try {
          const out = await runCli(cli, args, message);
          if (out.is_error) {
            const text = String(out.result || 'Claude Code could not answer');
            if (/authenticat|log ?in|oauth/i.test(text)) return reply(res, 401, { error: `Claude Code is not logged in here. In a terminal run "${cli}", type /login, then try again.` });
            return reply(res, 502, { error: text });
          }
          log.info(`claude code: ${out.num_turns ?? '?'} turns, ${out.duration_ms ?? '?'} ms`, { timestamp: true });
          reply(res, 200, { text: out.result || '', session: out.session_id || null });
        } catch (err) {
          reply(res, 502, { error: err.message || 'Claude Code failed' });
        }
      });

      server.middlewares.use('/api/claude', async (req, res) => {
        if (req.method !== 'POST') return reply(res, 405, { error: 'Use POST' });
        if (!fromThisPage(req)) return reply(res, 403, { error: 'Only this app may use the AI' });
        if (!/^application\/json\b/i.test(req.headers['content-type'] || '')) return reply(res, 415, { error: 'Send JSON' });
        if (!env.ANTHROPIC_API_KEY) return reply(res, 503, { error: 'No Claude API key. Add ANTHROPIC_API_KEY to .env.local in the building-design folder, then restart the dev server.' });

        let body;
        try {
          body = JSON.parse(await readBody(req));
        } catch (err) {
          return reply(res, 400, { error: err.message });
        }
        const { system, messages, tools } = body || {};
        if (typeof system !== 'string' || !Array.isArray(messages) || !messages.length || !Array.isArray(tools)) return reply(res, 400, { error: 'Expected system, messages and tools' });

        client ??= new Anthropic({ apiKey: env.ANTHROPIC_API_KEY });
        try {
          const message = await client.beta.messages.create({
            model,
            max_tokens: 16000,
            output_config: { effort: 'medium' },
            // The system prompt and tools repeat on every round of a turn.
            cache_control: { type: 'ephemeral' },
            system,
            messages,
            ...(tools.length ? { tools: tools.map(({ name, description, input_schema }) => ({ name, description, input_schema })) } : {}),
            ...(FALLBACK_MODELS.has(model) ? { betas: ['server-side-fallback-2026-07-01'], fallbacks: 'default' } : {}),
          });
          const u = message.usage || {};
          log.info(`claude ${message.model}: ${u.input_tokens ?? 0} in (${u.cache_read_input_tokens ?? 0} cached), ${u.output_tokens ?? 0} out, ${message.stop_reason}`, { timestamp: true });
          reply(res, 200, message);
        } catch (err) {
          if (err instanceof Anthropic.AuthenticationError) return reply(res, 401, { error: 'Claude rejected the API key. Check ANTHROPIC_API_KEY in .env.local.' });
          if (err instanceof Anthropic.NotFoundError) return reply(res, 404, { error: `Model ${model} is not available to this API key.` });
          if (err instanceof Anthropic.RateLimitError) return reply(res, 429, { error: 'Too many requests to Claude. Wait a moment and try again.' });
          if (err instanceof Anthropic.APIConnectionError) return reply(res, 502, { error: 'Could not reach the Claude API. Check your connection.' });
          if (err instanceof Anthropic.APIError) return reply(res, err.status || 502, { error: err.message });
          log.error(`claude: ${err?.stack || err}`);
          reply(res, 500, { error: 'The AI request failed' });
        }
      });
    },
  };
}

/** The Claude Code CLI: on PATH, in its usual install places, or bundled with the Claude app. */
export function findClaudeCode() {
  try {
    const p = execFileSync('/usr/bin/which', ['claude'], { encoding: 'utf8' }).trim();
    if (p) return p;
  } catch {
    // not on PATH
  }
  const home = homedir();
  for (const p of [join(home, '.local/bin/claude'), join(home, '.claude/local/claude')]) if (existsSync(p)) return p;
  const app = join(home, 'Library/Application Support/Claude/claude-code');
  try {
    const versions = readdirSync(app).sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
    for (const v of versions) {
      for (const sub of readdirSync(join(app, v))) {
        const p = join(app, v, sub, 'claude.app/Contents/MacOS/claude');
        if (existsSync(p)) return p;
      }
    }
  } catch {
    // no Claude app
  }
  return null;
}

/** Run `claude -p` with the message on stdin; resolves to its JSON result. */
function runCli(cli, args, message) {
  const cwd = join(tmpdir(), 'building-design-claude');
  mkdirSync(cwd, { recursive: true });
  const childEnv = { ...process.env };
  delete childEnv.ANTHROPIC_API_KEY; // use the Claude Code login, not an API key
  return new Promise((resolve, reject) => {
    const child = spawn(cli, args, { cwd, env: childEnv, stdio: ['pipe', 'pipe', 'pipe'] });
    let out = '';
    let err = '';
    const timer = setTimeout(() => {
      child.kill('SIGTERM');
      reject(new Error('Claude Code took too long'));
    }, CLI_TIMEOUT);
    child.stdout.on('data', (d) => (out += d));
    child.stderr.on('data', (d) => (err += d));
    child.on('error', (e) => {
      clearTimeout(timer);
      reject(e);
    });
    child.on('close', () => {
      clearTimeout(timer);
      try {
        resolve(JSON.parse(out));
      } catch {
        reject(new Error((err || out).trim().slice(0, 500) || 'Claude Code gave no answer'));
      }
    });
    child.stdin.end(message);
  });
}

/** A same-origin request from a page this machine serves (no other site, no rebinding). */
function fromThisPage(req) {
  const host = req.headers.host || '';
  if (!LOCAL_HOST.test(host)) return false;
  const site = req.headers['sec-fetch-site'];
  if (site && site !== 'same-origin') return false;
  try {
    return new URL(req.headers.origin).host === host;
  } catch {
    return false;
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(new Error('Request too large'));
        req.destroy();
      } else chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function reply(res, status, data) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(data));
}
