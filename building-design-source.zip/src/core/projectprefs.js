/**
 * Project Preferences beyond the working units (Archicad's, reimplemented):
 *
 *   project.calcRules { wallOpeningMin, slabHoleMin, roofHoleMin }  (m²) openings and holes
 *     smaller than these are not taken off the net surfaces and volumes;
 *   project.structuralUnits { system, force, length }  units of the SAF export and of the loads;
 *   project.analyticalColors { column, beam, wall, slab, link, width }  the analytical model's look;
 *   project.mepRoute { duct, pipe, cable: { bend, slope } }  defaults of the MEP routes.
 */
import { area as polyArea, pointInPolygon } from './geom.js';
import { openingSize, wallLength, verticalExtent, wallAxis, levelElevation } from './model.js';
import { axisPoint } from './walls.js';
import { typeThickness } from './catalog.js';

export const CALC_DEFAULTS = { wallOpeningMin: 0, slabHoleMin: 0, roofHoleMin: 0 };

export const calcRules = (project) => ({ ...CALC_DEFAULTS, ...(project?.calcRules || {}) });

/** Area of a slab, roof or ceiling less the holes that are big enough to count (mm²). */
export function netSlabArea(doc, el) {
  const r = calcRules(doc.get('project'));
  const min = (el.kind === 'roof' ? r.roofHoleMin : r.slabHoleMin) * 1e6;
  return polyArea(el.boundary || []) - (el.holes || []).map((h) => polyArea(h)).filter((a) => a >= min).reduce((s, a) => s + a, 0);
}

/** The openings hosted by a wall that count under the calculation rules: total area (mm²). */
export function wallOpeningsArea(doc, wall) {
  const min = calcRules(doc.get('project')).wallOpeningMin * 1e6;
  let total = 0;
  for (const kind of ['door', 'window', 'opening'])
    for (const o of doc.all(kind)) {
      if (o.hostId !== wall.id) continue;
      const s = openingSize(doc, o);
      // Past the wall's ends it cuts nothing.
      if (o.t != null && (+o.t - s.width / 2 >= wallLength(wall) || +o.t + s.width / 2 <= 0)) continue;
      const a = s.width * s.height;
      if (a >= min) total += a;
    }
  return total;
}

const wallGross = (doc, w) => {
  const { base, top } = verticalExtent(doc, w);
  return wallLength(w) * (top - base);
};

export const netWallArea = (doc, w) => Math.max(0, wallGross(doc, w) - wallOpeningsArea(doc, w));

/** The part of a wall a slab passes through, which belongs to the slab (mm³): along the wall's axis, under the slab's polygon, through the heights they share. */
export function wallSlabOverlap(doc, w) {
  const t = typeThickness(doc.get(w.typeId));
  const L = wallLength(w);
  if (!(t > 0) || !(L > 1)) return 0;
  const { base, top } = verticalExtent(doc, w);
  const axis = wallAxis(doc, w);
  const n = Math.max(64, Math.ceil(L / 25));
  let total = 0;
  for (const f of doc.all('floor')) {
    if (!f.boundary || f.boundary.length < 3) continue;
    const zTop = levelElevation(doc, f.levelId) + (+f.offset || 0);
    const h = Math.min(top, zTop) - Math.max(base, zTop - typeThickness(doc.get(f.typeId)));
    if (!(h > 0)) continue;
    let inside = 0;
    for (let i = 0; i < n; i++) {
      const p = axisPoint(axis, ((i + 0.5) / n) * L, 0);
      if (pointInPolygon(p, f.boundary) && !(f.holes || []).some((q) => pointInPolygon(p, q))) inside++;
    }
    total += (inside / n) * L * t * h;
  }
  return total;
}

export const netWallVolume = (doc, w) => Math.max(0, netWallArea(doc, w) * typeThickness(doc.get(w.typeId)) - wallSlabOverlap(doc, w));

// Structural units --------------------------------------------------------------------------------

export const FORCE_UNITS = [
  { value: 'kN', label: 'Kilonewton (kN)', perKN: 1 },
  { value: 'N', label: 'Newton (N)', perKN: 1000 },
  { value: 'kgf', label: 'Kilogram force (kgf)', perKN: 101.97162 },
  { value: 'tf', label: 'Tonne force (tf)', perKN: 0.10197162 },
  { value: 'lbf', label: 'Pound force (lbf)', perKN: 224.80894 },
  { value: 'kip', label: 'Kip (kip)', perKN: 0.22480894 },
];
export const LOAD_LENGTHS = [
  { value: 'm', label: 'Metre (m)', m: 1 },
  { value: 'ft', label: 'Foot (ft)', m: 0.3048 },
];
export const STRUCTURAL_DEFAULTS = { system: 'metric', force: 'kN', length: 'm' };

export const structuralUnits = (project) => ({ ...STRUCTURAL_DEFAULTS, ...(project?.structuralUnits || {}) });

const forceOf = (u) => FORCE_UNITS.find((x) => x.value === u.force) || FORCE_UNITS[0];
const lengthOf = (u) => LOAD_LENGTHS.find((x) => x.value === u.length) || LOAD_LENGTHS[0];
const per = (type, u) => (type === 'line' ? lengthOf(u).m : type === 'surface' ? lengthOf(u).m ** 2 : 1);

/** A load value stored in kN, kN/m or kN/m² in the chosen units. */
export const loadToDisplay = (v, type, u) => v * forceOf(u).perKN * per(type, u);
export const loadFromDisplay = (v, type, u) => v / forceOf(u).perKN / per(type, u);

/** The unit text of a load of this type: kN, kN/m or kN/m² in the chosen units. */
export function loadUnitLabel(type, u) {
  const f = forceOf(u).value;
  const l = lengthOf(u).value;
  return type === 'line' ? `${f}/${l}` : type === 'surface' ? `${f}/${l}²` : f;
}

// Analytical model look ----------------------------------------------------------------------------

export const ANALYTICAL_COLORS = { column: '#2f6fd6', beam: '#d63a3a', wall: '#e6a028', slab: '#3ca078', link: '#c030c0', width: 2.5 };

export const analyticalColors = (project) => ({ ...ANALYTICAL_COLORS, ...(project?.analyticalColors || {}) });

/** #rrggbb as a CSS rgba() with this opacity. */
export function hexAlpha(hex, a) {
  const n = parseInt(String(hex).slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
}

// MEP routing --------------------------------------------------------------------------------------

export const ROUTE_DEFAULTS = { duct: { bend: 1, slope: 0 }, pipe: { bend: 1, slope: 0 }, cable: { bend: 1, slope: 0 } };

export function routePrefs(project) {
  const r = project?.mepRoute || {};
  return Object.fromEntries(Object.keys(ROUTE_DEFAULTS).map((k) => [k, { ...ROUTE_DEFAULTS[k], ...(r[k] || {}) }]));
}

/** The family of routing preferences a MEP kind belongs to. */
export const routeFamily = (kind) => (/pipe/i.test(kind) ? 'pipe' : /duct/i.test(kind) ? 'duct' : 'cable');

// Site ---------------------------------------------------------------------------------------------

/** project.trueNorth (degrees counterclockwise from the model's +Y, in -180..180) for north pointing from a to b. */
export function northFromPoints(a, b) {
  let deg = (Math.atan2(b[1] - a[1], b[0] - a[0]) * 180) / Math.PI - 90;
  if (deg <= -180) deg += 360;
  if (deg > 180) deg -= 360;
  return Math.round(deg * 100) / 100;
}
