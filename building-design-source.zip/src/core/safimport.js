/**
 * SAF Translators and SAF import (Archicad's SAF add-on, reimplemented from
 * the SAF 2.x workbook layout at saf.guide):
 *
 *   project.safTranslator { members, surfaces, supports, loads, combinations }  what the SAF export writes
 *
 * Import: a SAF workbook (sheets by name) becomes physical elements:
 *   StructuralCurveMember  vertical → column, horizontal → beam, sloping → brace
 *   StructuralSurfaceMember horizontal → slab, vertical → wall (on its lowest edge)
 * at the levels nearest below them, with types of the nearest size (new
 * generic types when none is close).
 */
import { typeThickness } from './catalog.js';
import { wallTypeMaking } from './floorplan.js';

export const SAF_DEFAULTS = { members: true, surfaces: true, supports: true, loads: true, combinations: true };

/** The project's SAF translator with its defaults. */
export function safTranslator(doc) {
  return { ...SAF_DEFAULTS, ...(doc.get('project')?.safTranslator || {}) };
}

/** The analytical model cut down to what the translator writes. */
export function filterSAFModel(model, t) {
  const m = { ...model };
  if (!t.members) {
    m.members = [];
    m.links = [];
  }
  if (!t.surfaces) {
    m.surfaces = [];
    m.edgeSupports = [];
  }
  if (!t.supports) {
    m.supports = [];
    m.edgeSupports = [];
  }
  if (!t.loads) m.loads = [];
  if (!t.combinations) m.combinations = [];
  // Loads on what is no longer written go too.
  const keepM = new Set(m.members.map((x) => x.name));
  const keepS = new Set(m.surfaces.map((x) => x.name));
  m.loads = m.loads.filter((l) => (l.member ? keepM.has(l.member) : true) && (l.surface ? keepS.has(l.surface) : true));
  return m;
}

const IMPERIAL = { ft: ['m', 0.3048], in: ['mm', 25.4], kip: ['kN', 4.4482216], 'kip/ft': ['kN/m', 14.593903], 'kip/ft2': ['kN/m2', 47.880259], 'lb/ft3': ['kg/m3', 16.018463], ksi: ['MPa', 6.8947573] };

function metricCell(v, c) {
  if (!c || v === '' || v == null) return v;
  if (typeof v === 'number') return v * c[1];
  if (/^[-\d.; ]+$/.test(String(v))) return String(v).split(';').map((x) => +x * c[1]).join('; ');
  return v;
}

/** Rows of a sheet as objects keyed by header (header row first). */
function records(rows) {
  if (!rows?.length) return [];
  const head = rows[0].map((h) => String(h ?? '').trim());
  // Imperial workbooks (the units are in the headers) are read as metric.
  const toMetric = head.map((h) => IMPERIAL[/\[([^\]]+)\]$/.exec(h)?.[1]]);
  if (toMetric.some(Boolean))
    return records([head.map((h, i) => (toMetric[i] ? h.replace(/\[[^\]]+\]$/, `[${toMetric[i][0]}]`) : h)), ...rows.slice(1).map((r) => r.map((v, i) => metricCell(v, toMetric[i])))]);
  return rows
    .slice(1)
    .filter((r) => r?.some((c) => c !== '' && c != null))
    .map((r) => Object.fromEntries(head.map((h, i) => [h, r[i]])));
}
const col = (rec, ...names) => {
  for (const n of names) {
    const k = Object.keys(rec).find((x) => x.toLowerCase().startsWith(n.toLowerCase()));
    if (k && rec[k] !== '' && rec[k] != null) return rec[k];
  }
  return undefined;
};
const list = (v) =>
  String(v ?? '')
    .split(/[;,]/)
    .map((x) => x.trim())
    .filter(Boolean);

/** The size of a cross-section from its parameters (mm): { w, d }, or null. */
function sectionSize(sec) {
  if (!sec) return null;
  const p = list(col(sec, 'Parameters')).map(Number).filter(Number.isFinite);
  const shape = String(col(sec, 'Shape') || '').toLowerCase();
  if (/circle|round|chs/.test(shape) && p[0]) return { w: p[0], d: p[0] };
  if (p.length >= 2) return { w: p[1], d: p[0] };
  if (p.length === 1) return { w: p[0], d: p[0] };
  // Named sections such as IPE300 or HEB200: the number is the depth.
  const n = /(\d{2,4})/.exec(String(col(sec, 'Name') || ''))?.[1];
  return n ? { w: Math.round(+n * 0.6), d: +n } : null;
}

/**
 * Make the elements of a SAF workbook in doc (inside a transaction). sheets: Map(name → rows). Returns
 * { columns, beams, braces, slabs, walls, skipped }.
 */
export function safToModel(doc, sheets) {
  const out = { columns: 0, beams: 0, braces: 0, slabs: 0, walls: 0, skipped: 0 };
  const get = (name) => records(sheets.get(name) || [...sheets.entries()].find(([k]) => k.toLowerCase() === name.toLowerCase())?.[1]);
  const nodes = new Map();
  for (const r of get('StructuralPointConnection')) {
    const x = +col(r, 'Coordinate X');
    const y = +col(r, 'Coordinate Y');
    const z = +col(r, 'Coordinate Z');
    if ([x, y, z].every(Number.isFinite)) nodes.set(String(col(r, 'Name')), [x * 1000, y * 1000, z * 1000]);
  }
  const sections = new Map(get('StructuralCrossSection').map((r) => [String(col(r, 'Name')), r]));
  const levels = doc.levels();
  const levelAt = (z) => levels.filter((l) => l.elevation <= z + 5).at(-1) || levels[0];
  const typeNear = (kind, size) => {
    const all = doc.all(`${kind}Type`);
    if (!size) return all[0];
    const cost = (t) => Math.abs((+t.width || 0) - size.w) + Math.abs((+t.depth || 0) - size.d);
    return all.reduce((b, t) => (!b || cost(t) < cost(b) ? t : b), null);
  };
  for (const r of get('StructuralCurveMember')) {
    const ns = list(col(r, 'Nodes')).map((n) => nodes.get(n));
    if (ns.length < 2 || ns.some((n) => !n)) {
      out.skipped++;
      continue;
    }
    const [a, b] = [ns[0], ns.at(-1)];
    const lo = a[2] <= b[2] ? a : b;
    const hi = lo === a ? b : a;
    const plan = Math.hypot(b[0] - a[0], b[1] - a[1]);
    const rise = hi[2] - lo[2];
    const size = sectionSize(sections.get(String(col(r, 'Cross section') || '')));
    const lv = levelAt(lo[2]);
    if (plan < 1 || rise > plan * 5) {
      const t = typeNear('column', size);
      doc.add({ kind: 'column', typeId: t?.id, levelId: lv.id, at: [lo[0], lo[1]], baseOffset: Math.round(lo[2] - lv.elevation), topLevelId: null, height: Math.round(rise) });
      out.columns++;
    } else if (Math.abs(rise) < 10) {
      const t = typeNear('beam', size);
      const z = a[2];
      const blv = levelAt(z);
      doc.add({ kind: 'beam', typeId: t?.id, levelId: blv.id, a: [a[0], a[1]], b: [b[0], b[1]], offset: Math.round(z - blv.elevation) });
      out.beams++;
    } else {
      const t = doc.all('braceType')[0] || null;
      doc.add({ kind: 'brace', typeId: t?.id, levelId: lv.id, a: [lo[0], lo[1]], b: [hi[0], hi[1]], baseOffset: Math.round(lo[2] - lv.elevation), topLevelId: null, height: Math.round(rise) });
      out.braces++;
    }
  }
  for (const r of get('StructuralSurfaceMember')) {
    const ns = list(col(r, 'Nodes')).map((n) => nodes.get(n));
    if (ns.length < 3 || ns.some((n) => !n)) {
      out.skipped++;
      continue;
    }
    const th = +col(r, 'Thickness') || 200;
    const zs = ns.map((p) => p[2]);
    const zmin = Math.min(...zs);
    const zmax = Math.max(...zs);
    if (zmax - zmin < 10) {
      const lv = levelAt(zmax);
      const ft = doc.all('floorType').reduce((b, t) => (!b || Math.abs(typeThickness(t) - th) < Math.abs(typeThickness(b) - th) ? t : b), null);
      // The analytical plane is the slab's middle: its top is half a thickness up.
      doc.add({ kind: 'floor', typeId: ft?.id, levelId: lv.id, offset: Math.round(zmax + th / 2 - lv.elevation), boundary: ns.map((p) => [p[0], p[1]]) });
      out.slabs++;
    } else {
      // A wall on its two lowest corners, the farthest apart.
      const low = ns.filter((p) => p[2] - zmin < 10);
      if (low.length < 2) {
        out.skipped++;
        continue;
      }
      let [p, q] = [low[0], low[1]];
      for (const u of low) for (const v of low) if (Math.hypot(u[0] - v[0], u[1] - v[1]) > Math.hypot(p[0] - q[0], p[1] - q[1])) [p, q] = [u, v];
      const lv = levelAt(zmin);
      const wt = wallTypeMaking(doc, th, null);
      doc.add({ kind: 'wall', typeId: wt?.id, levelId: lv.id, a: [p[0], p[1]], b: [q[0], q[1]], baseOffset: Math.round(zmin - lv.elevation), topLevelId: null, height: Math.round(zmax - zmin) });
      out.walls++;
    }
  }
  return out;
}
