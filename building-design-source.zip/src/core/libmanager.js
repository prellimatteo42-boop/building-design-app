/**
 * Library Manager report (Archicad's Library Manager, reimplemented): the
 * libraries the project's GDL parts come from (by the first folder of their
 * source path, or "Project" for parts made here), with how many parts each
 * gives and how many are placed; duplicates (one name from several
 * libraries); missing parts (placed objects whose type is gone) and macros a
 * part calls that it does not carry; unused parts that can be removed.
 */
const GDL_KINDS = ['componentType', 'doorType', 'windowType'];
const PLACED = { componentType: 'component', doorType: 'door', windowType: 'window' };

/** The library a GDL type comes from. */
export function libraryOf(t) {
  const src = String(t.gdl?.source || '');
  if (!src) return t.familyName === 'DWG Block' ? 'DWG blocks' : 'Project';
  return src.split(/[\\/]/)[0] || 'Library';
}

export function libraryReport(doc) {
  const types = doc.all(...GDL_KINDS).filter((t) => t.family === 'gdl' || t.gdl);
  const used = new Map();
  for (const k of Object.values(PLACED)) for (const el of doc.all(k)) used.set(el.typeId, (used.get(el.typeId) || 0) + 1);
  const libs = new Map();
  for (const t of types) {
    const name = libraryOf(t);
    const l = libs.get(name) || { name, parts: 0, placed: 0 };
    l.parts++;
    l.placed += used.get(t.id) || 0;
    libs.set(name, l);
  }
  const byName = new Map();
  for (const t of types) {
    const k = String(t.name || '').toLowerCase();
    byName.set(k, [...(byName.get(k) || []), t]);
  }
  const duplicates = [...byName.values()].filter((list) => list.length > 1 && new Set(list.map(libraryOf)).size > 1).map((list) => ({ name: list[0].name, ids: list.map((t) => t.id), libraries: [...new Set(list.map(libraryOf))] }));
  const missing = [];
  for (const [typeKind, kind] of Object.entries(PLACED))
    for (const el of doc.all(kind)) {
      const t = doc.get(el.typeId);
      if (!t || t.kind !== typeKind) missing.push({ id: el.id, kind, problem: `its type ${el.typeId || '(none)'} is not in the project` });
    }
  const macros = [];
  for (const t of types) {
    const g = t.gdl || {};
    const have = new Set(Object.keys(g.macros || {}).map((k) => k.toLowerCase()));
    const text = [g.master, g.script3d, g.script2d].filter(Boolean).join('\n');
    const calls = new Set([...text.matchAll(/CALL\s+"([^"]+)"/gi)].map((m) => m[1].toLowerCase()));
    const lost = [...calls].filter((c) => !have.has(c) && !have.has(c.replace(/\.gsm$/, '')) && c !== 'resize_a_b_zzyzx');
    if (lost.length && g.lenient !== false) macros.push({ id: t.id, name: t.name, missing: lost });
  }
  const unused = types.filter((t) => !used.get(t.id)).map((t) => ({ id: t.id, name: t.name, library: libraryOf(t) }));
  return { libraries: [...libs.values()].sort((a, b) => b.parts - a.parts), duplicates, missing, macros, unused };
}
