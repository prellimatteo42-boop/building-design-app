/**
 * MEP networks, as Archicad's MEP System Browser and MEP Model Quality:
 * runs (ducts, pipes, cable trays, conduits) joined end to end in 3D, with
 * the terminals and equipment at their ends, grouped into networks by
 * kind and system. Each network reports its length, its open connections
 * (run ends with nothing attached) and its problems: a size or system that
 * changes at a joint, a run of no length, two runs on top of each other,
 * sanitary pipes laid without fall.
 *
 * A run may slope: its middle elevation is `offset` at a and `endOffset`
 * at b (both above its level). A run with the same plan ends is vertical
 * (a riser).
 */
import { levelElevation } from './model.js';
import { categoryOf } from './catalog.js';
import { MEP_KINDS, mepSize, systemOf } from './mep.js';

/** Categories of equipment a run of each kind connects to. */
const TERMINALS = {
  duct: ['airTerminals', 'mechanical'],
  pipe: ['plumbing', 'sprinklers', 'mechanical'],
  cableTray: ['electricalEquipment', 'lighting', 'electricalFixtures'],
  conduit: ['electricalEquipment', 'lighting', 'electricalFixtures'],
};

/** The two ends of a run in 3D. */
export function runEnds(doc, el) {
  const z = levelElevation(doc, el.levelId);
  const za = z + (+el.offset || 0);
  const zb = z + (el.endOffset != null ? +el.endOffset : +el.offset || 0);
  return [
    [el.a[0], el.a[1], za],
    [el.b[0], el.b[1], zb],
  ];
}

/** Slope of a run in percent (rise over plan length), or null for a riser. */
export function runSlope(doc, el) {
  const [a, b] = runEnds(doc, el);
  const l = Math.hypot(b[0] - a[0], b[1] - a[1]);
  return l < 1 ? null : ((b[2] - a[2]) / l) * 100;
}

/** 3D length of a run. */
export function runLength(doc, el) {
  const [a, b] = runEnds(doc, el);
  return Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
}

const same = (p, q, tol = 2) => Math.abs(p[0] - q[0]) <= tol && Math.abs(p[1] - q[1]) <= tol && Math.abs(p[2] - q[2]) <= tol * 3;

/** A terminal's connection point: its insertion point at its elevation. */
function terminalPoint(doc, c) {
  if (!Array.isArray(c.at)) return null;
  const t = doc.get(c.typeId) || {};
  return [c.at[0], c.at[1], levelElevation(doc, c.levelId) + (+(c.offset ?? c.elevation ?? t.elevation) || 0)];
}

/**
 * The connectors of a placed MEP part (its type's mepConnectors, from Save Selection as MEP Part) in 3D:
 * [{ p, dir, family, size, system }]. Local connectors are in mm from the part's origin, turned with it.
 */
export function connectorPoints(doc, c) {
  const t = doc.get(c.typeId);
  if (!t?.mepConnectors?.length || !Array.isArray(c.at)) return [];
  const r = ((+c.rotation || 0) * Math.PI) / 180;
  const z0 = levelElevation(doc, c.levelId) + (+(c.offset ?? c.elevation ?? t.elevation) || 0);
  const turn = (v) => [v[0] * Math.cos(r) - v[1] * Math.sin(r), v[0] * Math.sin(r) + v[1] * Math.cos(r)];
  return t.mepConnectors.map((k) => {
    const q = turn(k.at);
    const d = turn(k.dir || [1, 0, 0]);
    return { p: [c.at[0] + q[0], c.at[1] + q[1], z0 + (k.at[2] || 0)], dir: [d[0], d[1], k.dir?.[2] || 0], family: k.family, size: k.size, system: k.system };
  });
}

/**
 * The connectors a MEP part saved from a selection gets: the ends of the selected runs that no other selected run
 * meets, relative to the part's origin (the selection's lowest corner), pointing out of the part.
 */
export function connectorsFromSelection(doc, ids, origin) {
  const runs = ids.map((id) => doc.get(id)).filter((el) => el && MEP_KINDS.includes(el.kind) && el.a && el.b);
  const out = [];
  for (const r of runs) {
    const e = runEnds(doc, r);
    e.forEach((p, i) => {
      const meets = runs.some((o) => o !== r && runEnds(doc, o).some((q) => same(p, q, 5)));
      if (meets) return;
      const other = e[1 - i];
      const l = Math.hypot(p[0] - other[0], p[1] - other[1], p[2] - other[2]) || 1;
      const sz = mepSize(doc, r);
      out.push({ at: [p[0] - origin[0], p[1] - origin[1], p[2] - origin[2]].map((v) => Math.round(v)), dir: [(p[0] - other[0]) / l, (p[1] - other[1]) / l, (p[2] - other[2]) / l].map((v) => Math.round(v * 1e4) / 1e4), family: r.kind, size: { round: !!sz.round, w: sz.w, h: sz.h }, system: r.system ?? systemOf(r).value });
    });
  }
  return out;
}

/**
 * Networks of runs and terminals: [{ kind, system, runs: [id], terminals: [id], length, openEnds: [{ id, p }] }].
 * A terminal joins a run end within its reach (half its size, at least 300 mm, across; 600 mm up or down).
 */
export function mepNetworks(doc) {
  const runs = MEP_KINDS.flatMap((k) => doc.all(k)).filter((el) => el.a && el.b);
  const ends = new Map(runs.map((r) => [r.id, runEnds(doc, r)]));
  const parent = new Map(runs.map((r) => [r.id, r.id]));
  const find = (x) => {
    while (parent.get(x) !== x) {
      parent.set(x, parent.get(parent.get(x)));
      x = parent.get(x);
    }
    return x;
  };
  const union = (a, b) => parent.set(find(a), find(b));
  const joined = new Map(runs.map((r) => [r.id, [false, false]]));
  // Runs of one kind meet where their ends coincide, or where an end lies on another run (a tee).
  for (let i = 0; i < runs.length; i++)
    for (let j = i + 1; j < runs.length; j++) {
      const r = runs[i];
      const s = runs[j];
      if (r.kind !== s.kind) continue;
      const er = ends.get(r.id);
      const es = ends.get(s.id);
      for (let a = 0; a < 2; a++)
        for (let b = 0; b < 2; b++)
          if (same(er[a], es[b])) {
            union(r.id, s.id);
            joined.get(r.id)[a] = true;
            joined.get(s.id)[b] = true;
          }
      for (const [x, ex, y, ey] of [
        [r, er, s, es],
        [s, es, r, er],
      ])
        for (let a = 0; a < 2; a++)
          if (!joined.get(x.id)[a] && onSegment(ex[a], ey[0], ey[1], Math.max(10, mepSize(doc, y).w / 2))) {
            union(x.id, y.id);
            joined.get(x.id)[a] = true;
          }
    }
  // Terminals.
  const terminalOf = new Map();
  for (const c of doc.all('component')) {
    // A MEP part joins runs at its connectors.
    const conns = connectorPoints(doc, c);
    if (conns.length) {
      for (const k of conns)
        for (const r of runs) {
          if (r.kind !== k.family) continue;
          const e = ends.get(r.id);
          for (let a = 0; a < 2; a++)
            if (same(e[a], k.p, Math.max(20, (k.size?.w || 0) / 4))) {
              joined.get(r.id)[a] = true;
              if (!terminalOf.has(c.id)) terminalOf.set(c.id, r.id);
              else union(terminalOf.get(c.id), r.id);
            }
        }
      continue;
    }
    const cat = categoryOf(c, doc);
    const p = terminalPoint(doc, c);
    if (!p) continue;
    const t = doc.get(c.typeId) || {};
    const reach = Math.max(300, (+t.width || 0) / 2, (+t.depth || 0) / 2);
    for (const r of runs) {
      if (!TERMINALS[r.kind]?.includes(cat)) continue;
      const e = ends.get(r.id);
      for (let a = 0; a < 2; a++)
        if (Math.hypot(e[a][0] - p[0], e[a][1] - p[1]) <= reach && Math.abs(e[a][2] - p[2]) <= Math.max(600, (+t.height || 0) + 100)) {
          joined.get(r.id)[a] = true;
          if (!terminalOf.has(c.id)) terminalOf.set(c.id, r.id);
        }
    }
  }
  const groups = new Map();
  for (const r of runs) {
    const k = find(r.id);
    if (!groups.has(k)) groups.set(k, { kind: r.kind, systems: new Set(), runs: [], terminals: [], length: 0, openEnds: [] });
    const g = groups.get(k);
    g.runs.push(r.id);
    g.systems.add(systemOf(r).label);
    g.length += runLength(doc, r);
    joined.get(r.id).forEach((j, i) => !j && g.openEnds.push({ id: r.id, end: i, p: ends.get(r.id)[i] }));
  }
  for (const [cid, rid] of terminalOf) groups.get(find(rid)).terminals.push(cid);
  return [...groups.values()].map((g) => ({ ...g, system: [...g.systems].join(', '), systems: undefined }));
}

function onSegment(p, a, b, tol) {
  const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const l2 = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];
  if (l2 < 1) return false;
  const t = ((p[0] - a[0]) * d[0] + (p[1] - a[1]) * d[1] + (p[2] - a[2]) * d[2]) / l2;
  if (t <= 0.01 || t >= 0.99) return false;
  return Math.hypot(a[0] + d[0] * t - p[0], a[1] + d[1] * t - p[1], a[2] + d[2] * t - p[2]) <= tol;
}

/** Every run and terminal connected to the given elements. */
export function connectedMep(doc, ids) {
  const want = new Set(ids);
  const out = new Set();
  for (const n of mepNetworks(doc)) if ([...n.runs, ...n.terminals].some((id) => want.has(id))) for (const id of [...n.runs, ...n.terminals]) out.add(id);
  return out;
}

/**
 * MEP Model Quality: [{ kind: 'open' | 'size' | 'system' | 'zero' | 'overlap' | 'fall', message, ids, p? }].
 * minFall: the least fall of sanitary pipes, in percent.
 */
export function mepQuality(doc, { minFall = 1 } = {}) {
  const issues = [];
  const runs = MEP_KINDS.flatMap((k) => doc.all(k)).filter((el) => el.a && el.b);
  for (const n of mepNetworks(doc)) for (const o of n.openEnds) issues.push({ kind: 'open', message: 'Open connection: nothing is attached to this end', ids: [o.id], p: o.p });
  for (let i = 0; i < runs.length; i++) {
    const r = runs[i];
    const er = runEnds(doc, r);
    if (runLength(doc, r) < 1) issues.push({ kind: 'zero', message: 'Run of no length', ids: [r.id], p: er[0] });
    if (r.kind === 'pipe' && systemOf(r).value === 'sanitary') {
      const s = runSlope(doc, r);
      if (s != null && Math.abs(s) < minFall) issues.push({ kind: 'fall', message: `Sanitary pipe with ${Math.abs(s).toFixed(1)}% fall (at least ${minFall}%)`, ids: [r.id], p: er[0] });
    }
    for (let j = i + 1; j < runs.length; j++) {
      const s = runs[j];
      if (s.kind !== r.kind) continue;
      const es = runEnds(doc, s);
      if ((same(er[0], es[0]) && same(er[1], es[1])) || (same(er[0], es[1]) && same(er[1], es[0]))) {
        issues.push({ kind: 'overlap', message: 'Two runs on top of each other', ids: [r.id, s.id], p: er[0] });
        continue;
      }
      for (let a = 0; a < 2; a++)
        for (let b = 0; b < 2; b++) {
          if (!same(er[a], es[b])) continue;
          const zr = mepSize(doc, r);
          const zs = mepSize(doc, s);
          const transition = doc.all('mepFitting').some((fit) => fit.fittingType === 'transition' && fit.ends?.some((e) => e.id === r.id) && fit.ends?.some((e) => e.id === s.id));
          if (!transition && (Math.abs(zr.w - zs.w) > 1 || Math.abs(zr.h - zs.h) > 1)) issues.push({ kind: 'size', message: `Size changes at a joint (${Math.round(zr.w)} to ${Math.round(zs.w)} mm) without a transition`, ids: [r.id, s.id], p: er[a] });
          if (systemOf(r).value !== systemOf(s).value) issues.push({ kind: 'system', message: `Systems meet at a joint: ${systemOf(r).label} and ${systemOf(s).label}`, ids: [r.id, s.id], p: er[a] });
        }
    }
  }
  return issues;
}

/**
 * Resolve Connections: open ends of runs that nearly meet (within tol in plan, at one height) are brought to their
 * midpoint. Returns [{ id, patch }] to apply.
 */
export function resolveConnections(doc, tol = 150, zTol = 50) {
  const open = mepNetworks(doc).flatMap((n) => n.openEnds);
  const used = new Set();
  const out = new Map();
  for (let i = 0; i < open.length; i++) {
    if (used.has(i)) continue;
    let best = -1;
    let bd = tol;
    for (let j = i + 1; j < open.length; j++) {
      if (used.has(j) || open[j].id === open[i].id) continue;
      const [p, q] = [open[i].p, open[j].p];
      const d = Math.hypot(p[0] - q[0], p[1] - q[1]);
      if (d <= bd && d > 0.01 && Math.abs((p[2] || 0) - (q[2] || 0)) <= zTol) {
        best = j;
        bd = d;
      }
    }
    if (best < 0) continue;
    used.add(i).add(best);
    const [a, b] = [open[i], open[best]];
    const m = [(a.p[0] + b.p[0]) / 2, (a.p[1] + b.p[1]) / 2];
    for (const o of [a, b]) out.set(o.id, { ...(out.get(o.id) || {}), [o.end === 0 ? 'a' : 'b']: m });
  }
  return [...out].map(([id, patch]) => ({ id, patch }));
}
