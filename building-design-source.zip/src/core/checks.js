/**
 * Checks of the model's weight and attributes, as Archicad's PolyCount and
 * Check Surfaces: triangles per element and per type, materials named but
 * missing, and materials nothing uses.
 */

/** PolyCount: [{ id, kind, name, triangles }] heaviest first, and totals by type. meshOf gives an element's 3D. */
export function polyCount(doc, ids, meshOf) {
  const rows = [];
  const byType = new Map();
  for (const id of ids) {
    const el = doc.get(id);
    const m = el && meshOf(el);
    if (!m?.pos) continue;
    const tris = m.pos.length / 9 + (m.tex || []).reduce((s, g) => s + g.pos.length / 9, 0);
    if (!tris) continue;
    const type = doc.get(el.typeId);
    rows.push({ id, kind: el.kind, name: type?.name || el.name || el.kind, triangles: tris });
    const k = type?.id || el.kind;
    const t = byType.get(k) || { name: type?.name || el.kind, count: 0, triangles: 0 };
    t.count++;
    t.triangles += tris;
    byType.set(k, t);
  }
  rows.sort((a, b) => b.triangles - a.triangles);
  return { rows, types: [...byType.values()].sort((a, b) => b.triangles - a.triangles), total: rows.reduce((s, r) => s + r.triangles, 0) };
}

const MAT_KEYS = ['materialId', 'panelMaterialId', 'frameMaterialId', 'topMaterialId', 'sideMaterialId'];

/** Check Surfaces: { missing: [{ id, name, materialId }], unused: [{ id, name }] }. */
export function checkSurfaces(doc) {
  const mats = new Set(doc.all('material').map((m) => m.id));
  const used = new Set();
  const missing = [];
  for (const it of doc.items.values()) {
    if (it.kind === 'material') continue;
    const refs = [...MAT_KEYS.map((k) => it[k]), ...(it.layers || []).map((l) => l.materialId)].filter((x) => typeof x === 'string' && x);
    for (const r of refs) {
      used.add(r);
      if (!mats.has(r)) missing.push({ id: it.id, name: it.name || it.kind, materialId: r });
    }
    // GDL parts naming materials.
    for (const m of String(it.gdl?.script3d || '').matchAll(/MATERIAL\s+"([^"]+)"/gi)) used.add(m[1]);
    for (const p of it.gdl?.params || []) if (p.kind === 'material' && typeof p.value === 'string') used.add(p.value);
  }
  const unused = doc.all('material').filter((m) => !used.has(m.id)).map((m) => ({ id: m.id, name: m.name || m.id }));
  return { missing, unused };
}
