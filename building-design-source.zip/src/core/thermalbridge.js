/**
 * Thermal Bridge Simulation, as Archicad's: two-dimensional steady-state
 * heat conduction through a junction cut in plan (EN ISO 10211), from the
 * layers of the walls and the columns with their building materials'
 * thermal conductivity.
 *
 * The box around the junction is split into square cells; each cell is a
 * material of the wall layer or column under it, or air: inside a room
 * (interior, θi with surface resistance Rsi) or outside (θe, Rse). The cut
 * edges of the box are adiabatic, so the box should reach about 1 m past
 * the junction. The temperatures are solved by conjugate gradients.
 *
 * Results: the heat flow Q (W per metre of height), the thermal coupling
 * coefficient L2D = Q / (θi − θe), the linear thermal transmittance
 * ψ = L2D − Σ U·l with lengths l measured on the interior faces (ψi) or the
 * exterior faces (ψe), the lowest interior surface temperature and the
 * temperature factor fRsi = (θsi,min − θe) / (θi − θe), and the field of
 * temperatures for a picture.
 */
import { pointInPolygon } from './geom.js';
import { wallOutline } from './walls.js';
import { thermalProperties } from './materials.js';
import { typeThickness } from './catalog.js';
import { verticalExtent, levelElevation } from './model.js';
import { viewFrame } from './elevation.js';

export const TB_DEFAULTS = { inside: 20, outside: 0, rsi: 0.13, rse: 0.04, cell: 10 };

/** λ of a material for a layer: its conductivity, or thickness / resistance for air gaps; null when unknown. */
function lambdaOf(doc, materialId, thickness) {
  const m = doc.get(materialId);
  if (+m?.conductivity > 0) return +m.conductivity;
  if (+m?.resistance > 0 && thickness > 0) return thickness / 1000 / +m.resistance;
  return null;
}

/** Clip a convex polygon to the half-plane dot(p, n) >= c. */
function clipHalf(poly, n, c) {
  const out = [];
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const da = a[0] * n[0] + a[1] * n[1] - c;
    const db = b[0] * n[0] + b[1] * n[1] - c;
    if (da >= 0) out.push(a);
    if ((da >= 0) !== (db >= 0)) {
      const t = da / (da - db);
      out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
    }
  }
  return out;
}

/**
 * The solid parts in plan near a box on a level: [{ poly, lambda, name, elementId }].
 * Each wall's joined outline is split into its layers (from the exterior face inward).
 */
export function junctionParts(doc, scene, levelId, notes = new Set()) {
  const parts = [];
  const solved = scene.walls.level(levelId);
  for (const g of solved.walls.values()) {
    if (g.axis.curve) {
      notes.add('Curved walls are left out.');
      continue;
    }
    const type = doc.get(g.wall.typeId);
    const outline = wallOutline(g);
    const ax = g.axis;
    const sign = ax.ext[0] * ax.n[0] + ax.ext[1] * ax.n[1] > 0 ? 1 : -1;
    // Offsets across the wall: exterior face at sign·half.
    const layers = type?.layers?.length ? type.layers : [{ materialId: type?.materialId, thickness: typeThickness(type) || ax.half * 2 }];
    const total = layers.reduce((s, l) => s + (+l.thickness || 0), 0) || ax.half * 2;
    let depth = 0;
    const dirN = [ax.n[0] * sign, ax.n[1] * sign]; // towards the exterior
    const c0 = ax.a[0] * dirN[0] + ax.a[1] * dirN[1]; // the axis
    for (const l of layers) {
      const t = ((+l.thickness || 0) * ax.half * 2) / total;
      // Between depth and depth + t from the exterior face.
      const outer = c0 + ax.half - depth;
      const inner = c0 + ax.half - depth - t;
      let poly = clipHalf(outline, [-dirN[0], -dirN[1]], -outer - 0.01);
      poly = clipHalf(poly, dirN, inner - 0.01);
      depth += t;
      if (poly.length < 3) continue;
      let lambda = lambdaOf(doc, l.materialId, +l.thickness);
      if (lambda == null) {
        notes.add(`${doc.get(l.materialId)?.name || 'A layer'} of ${type?.name || 'a wall'} has no thermal conductivity: 1.0 W/mK assumed.`);
        lambda = 1;
      }
      parts.push({ poly, lambda, name: doc.get(l.materialId)?.name || 'Layer', elementId: g.wall.id, z0: g.base, z1: g.top, thickness: ax.half * 2 });
    }
  }
  for (const hub of solved.hubs || []) {
    const owner = doc.get(hub.ids?.[0]);
    const core = doc.get(owner?.typeId)?.layers?.find((l) => l.function === 'structure');
    parts.push({ poly: hub.poly, lambda: (core && lambdaOf(doc, core.materialId, +core.thickness)) || 1, name: 'Junction', elementId: owner?.id, z0: hub.base, z1: hub.top });
  }
  for (const c of doc.all('column')) {
    if (c.levelId !== levelId || !c.at) continue;
    const type = doc.get(c.typeId) || {};
    const w = +type.width || 450;
    const d = +type.depth || w;
    const r = ((+c.rotation || 0) * Math.PI) / 180;
    const poly =
      type.shape === 'round'
        ? Array.from({ length: 24 }, (_, k) => [c.at[0] + (w / 2) * Math.cos((2 * Math.PI * k) / 24), c.at[1] + (w / 2) * Math.sin((2 * Math.PI * k) / 24)])
        : [
            [-w / 2, -d / 2],
            [w / 2, -d / 2],
            [w / 2, d / 2],
            [-w / 2, d / 2],
          ].map(([x, y]) => [c.at[0] + x * Math.cos(r) - y * Math.sin(r), c.at[1] + x * Math.sin(r) + y * Math.cos(r)]);
    // Columns sit over the walls they stand in.
    const { base, top } = verticalExtent(doc, c);
    parts.unshift({ poly, lambda: lambdaOf(doc, type.materialId || 'mat-concrete', w) || 2.3, name: doc.get(type.materialId)?.name || 'Column', elementId: c.id, column: true, z0: base, z1: top, thickness: Math.min(w, d) });
  }
  return parts;
}

/**
 * Solve the junction in a box { x0, y0, x1, y1 } (mm) on a level.
 * Returns { Q, L2D, psiI, psiE, thetaSiMin, fRsi, grid: { nx, ny, cell, x0, y0, T (Float32Array), kind (Uint8Array 0 solid, 1 interior air, 2 exterior air) }, flanking, notes }.
 */
export function simulateJunction(doc, scene, levelId, box, opts = {}) {
  const o = { ...TB_DEFAULTS, ...opts };
  const notes = new Set();
  const parts = junctionParts(doc, scene, levelId, notes);
  const rooms = doc.all('room').filter((r) => r.levelId === levelId).map((r) => scene.rooms.room(r)).filter(Boolean);
  const res = solveGrid(parts, box, (p) => (rooms.some((r) => pointInPolygon(p, r.outer)) ? 1 : 2), o, notes);
  if (res.error) return res;
  const { L2D } = res;
  // Flanking elements: each wall's U times the length of its interior (or exterior) face in the box.
  const flanking = [];
  const solved = scene.walls.level(levelId);
  const inBox = (a, b) => clipLength(a, b, box);
  for (const g of solved.walls.values()) {
    const ax = g.axis;
    if (ax.curve) continue;
    const outline = wallOutline(g);
    if (!outline.some((p) => p[0] > box.x0 && p[0] < box.x1 && p[1] > box.y0 && p[1] < box.y1) && !segmentHitsBox(g.L0, g.L1, box) && !segmentHitsBox(g.R0, g.R1, box)) continue;
    const u = thermalProperties(doc, doc.get(g.wall.typeId))?.u;
    if (!u) {
      notes.add(`${doc.get(g.wall.typeId)?.name || 'A wall'} has no U-value: left out of ψ.`);
      continue;
    }
    const extLeft = ax.ext[0] * ax.n[0] + ax.ext[1] * ax.n[1] > 0;
    const faceL = inBox(g.L0, g.L1);
    const faceR = inBox(g.R0, g.R1);
    const lIn = extLeft ? faceR : faceL;
    const lOut = extLeft ? faceL : faceR;
    flanking.push({ id: g.wall.id, name: doc.get(g.wall.typeId)?.name || 'Wall', u, lIn: lIn / 1000, lOut: lOut / 1000 });
  }
  return finish(res, flanking, o, notes);
}

/** ψ from L2D and the flanking elements, and the result record. */
function finish(res, flanking, o, notes) {
  const psiI = res.L2D - flanking.reduce((s, f) => s + f.u * f.lIn, 0);
  const psiE = res.L2D - flanking.reduce((s, f) => s + f.u * f.lOut, 0);
  if (res.iterations >= 20000) notes.add('The solver did not fully converge.');
  const dT = o.inside - o.outside;
  return {
    Q: res.Q,
    L2D: res.L2D,
    psiI,
    psiE,
    thetaSiMin: Number.isFinite(res.thetaSiMin) ? res.thetaSiMin : null,
    fRsi: Number.isFinite(res.thetaSiMin) ? (res.thetaSiMin - o.outside) / dT : null,
    flanking,
    settings: o,
    iterations: res.iterations,
    grid: res.grid,
    notes: [...notes],
  };
}

/**
 * Solve the temperatures in a box over parts [{ poly, lambda, elementId }] (2D, mm); air cells take
 * airKind(point): 1 interior, 2 exterior. Returns { Q, L2D, thetaSiMin, iterations, grid, faces } where
 * faces counts, per element, the cell faces it shares with interior and exterior air (mm).
 */
function solveGrid(parts, box, airKind, o, notes) {
  const h = Math.max(2, +o.cell || 10);
  const nx = Math.max(4, Math.round((box.x1 - box.x0) / h));
  const ny = Math.max(4, Math.round((box.y1 - box.y0) / h));
  const N = nx * ny;
  const lam = new Float32Array(N);
  const kind = new Uint8Array(N);
  const owner = new Array(N).fill(null);
  // Parts near the box only.
  const near = parts.filter((p) => {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const q of p.poly) (x0 = Math.min(x0, q[0])), (y0 = Math.min(y0, q[1])), (x1 = Math.max(x1, q[0])), (y1 = Math.max(y1, q[1]));
    return x1 >= box.x0 && x0 <= box.x1 && y1 >= box.y0 && y0 <= box.y1;
  });
  for (let j = 0; j < ny; j++)
    for (let i = 0; i < nx; i++) {
      const p = [box.x0 + (i + 0.5) * h, box.y0 + (j + 0.5) * h];
      const k = j * nx + i;
      // A centre right on the line where two parts meet belongs to neither: nudge it.
      const part = near.find((s) => pointInPolygon(p, s.poly)) || near.find((s) => pointInPolygon([p[0] + 0.37, p[1] + 0.21], s.poly)) || near.find((s) => pointInPolygon([p[0] - 0.29, p[1] - 0.43], s.poly));
      if (part) {
        lam[k] = part.lambda;
        kind[k] = 0;
        owner[k] = part.elementId;
      } else kind[k] = airKind(p);
    }
  // Unknowns: solid cells.
  const idx = new Int32Array(N).fill(-1);
  let n = 0;
  for (let k = 0; k < N; k++) if (kind[k] === 0) idx[k] = n++;
  if (!n) return { error: 'Nothing solid in the box: put it over the elements of the junction.' };
  const hm = h / 1000;
  // Matrix in compressed rows: diag + up to 4 neighbours; right-hand side from the air boundaries.
  const diag = new Float64Array(n);
  const rhs = new Float64Array(n);
  const nb = new Int32Array(n * 4).fill(-1);
  const gw = new Float64Array(n * 4);
  const surf = []; // interior surface faces: [cell, G]
  const faces = new Map();
  // Conductances from the resistance along the path between cell centres, sampled at 1/8 of a cell,
  // so layer faces fall where they are and not on the cell grid.
  const lambdaAt = (p) => {
    for (const q of [p, [p[0] + 0.37, p[1] + 0.21], [p[0] - 0.29, p[1] - 0.43]]) for (const s of near) if (pointInPolygon(q, s.poly)) return s.lambda;
    return 0;
  };
  // The path is split exactly where it crosses the parts' edges; each piece takes the λ at its middle.
  const edges = [];
  for (const s of near) for (let e = 0; e < s.poly.length; e++) edges.push([s.poly[e], s.poly[(e + 1) % s.poly.length]]);
  const pathG = (i, j, di, dj, rs) => {
    const c = [box.x0 + (i + 0.5) * h, box.y0 + (j + 0.5) * h];
    const ts = [0, 1];
    for (const [p, q] of edges) {
      // Crossing of the path c + t·h·d (t in 0..1) with edge p-q.
      if (di !== 0) {
        if ((p[0] - c[0]) * di < -1e-9 && (q[0] - c[0]) * di < -1e-9) continue;
        if (Math.abs(q[0] - p[0]) < 1e-12) {
          const t = ((p[0] - c[0]) * di) / h;
          if (t > 0 && t < 1 && (c[1] - p[1]) * (c[1] - q[1]) <= 0) ts.push(t);
        } else {
          const y = c[1];
          if ((p[1] - y) * (q[1] - y) > 0 || Math.abs(q[1] - p[1]) < 1e-12) continue;
          const x = p[0] + ((y - p[1]) * (q[0] - p[0])) / (q[1] - p[1]);
          const t = ((x - c[0]) * di) / h;
          if (t > 0 && t < 1) ts.push(t);
        }
      } else {
        const x = c[0];
        if ((p[0] - x) * (q[0] - x) > 0 || Math.abs(q[0] - p[0]) < 1e-12) {
          if (Math.abs(q[0] - p[0]) < 1e-12 && Math.abs(p[0] - x) < 1e-9) continue;
          if ((p[0] - x) * (q[0] - x) > 0) continue;
        }
        const y = Math.abs(q[0] - p[0]) < 1e-12 ? null : p[1] + ((x - p[0]) * (q[1] - p[1])) / (q[0] - p[0]);
        if (y == null) continue;
        const t = ((y - c[1]) * dj) / h;
        if (t > 0 && t < 1) ts.push(t);
      }
    }
    ts.sort((a, b) => a - b);
    let R = 0;
    for (let k = 1; k < ts.length; k++) {
      const len = (ts[k] - ts[k - 1]) * hm;
      if (len <= 0) continue;
      const tm = ((ts[k] + ts[k - 1]) / 2) * h;
      const l = lambdaAt([c[0] + di * tm, c[1] + dj * tm]);
      if (l > 0) R += len / l;
      else if (rs != null) break; // into the air: the surface resistance takes over
      else R += len / 0.025; // a thin air gap between solid cells
    }
    if (rs != null) R += rs;
    return hm / (R || 1e-9);
  };
  for (let j = 0; j < ny; j++)
    for (let i = 0; i < nx; i++) {
      const k = j * nx + i;
      const u = idx[k];
      if (u < 0) continue;
      let s = 0;
      const nbrs = [
        [i - 1, j],
        [i + 1, j],
        [i, j - 1],
        [i, j + 1],
      ];
      nbrs.forEach(([ii, jj], d) => {
        if (ii < 0 || jj < 0 || ii >= nx || jj >= ny) return; // adiabatic cut
        const kk = jj * nx + ii;
        const [di, dj] = [ii - i, jj - j];
        if (kind[kk] === 0) {
          const g = pathG(i, j, di, dj, null);
          nb[u * 4 + d] = idx[kk];
          gw[u * 4 + d] = g;
          s += g;
        } else {
          const inside = kind[kk] === 1;
          const g = pathG(i, j, di, dj, inside ? o.rsi : o.rse);
          if (owner[k]) {
            if (!faces.has(owner[k])) faces.set(owner[k], { in: 0, out: 0 });
            faces.get(owner[k])[inside ? 'in' : 'out'] += h;
          }
          s += g;
          rhs[u] += g * (inside ? o.inside : o.outside);
          if (inside) surf.push([u, g]);
        }
      });
      diag[u] = s || 1e-9;
    }
  // Conjugate gradients, Jacobi preconditioned.
  const mul = (x, y) => {
    for (let u = 0; u < n; u++) {
      let v = diag[u] * x[u];
      for (let d = 0; d < 4; d++) {
        const w = nb[u * 4 + d];
        if (w >= 0) v -= gw[u * 4 + d] * x[w];
      }
      y[u] = v;
    }
  };
  const x = new Float64Array(n).fill((o.inside + o.outside) / 2);
  const r = new Float64Array(n);
  const z = new Float64Array(n);
  const pv = new Float64Array(n);
  const q = new Float64Array(n);
  mul(x, q);
  for (let u = 0; u < n; u++) r[u] = rhs[u] - q[u];
  for (let u = 0; u < n; u++) z[u] = r[u] / diag[u];
  pv.set(z);
  let rz = 0;
  for (let u = 0; u < n; u++) rz += r[u] * z[u];
  const norm0 = Math.sqrt(rhs.reduce((t, v) => t + v * v, 0)) || 1;
  let it = 0;
  for (; it < 20000; it++) {
    mul(pv, q);
    let pq = 0;
    for (let u = 0; u < n; u++) pq += pv[u] * q[u];
    const a = rz / pq;
    let rr = 0;
    for (let u = 0; u < n; u++) {
      x[u] += a * pv[u];
      r[u] -= a * q[u];
      rr += r[u] * r[u];
    }
    if (Math.sqrt(rr) / norm0 < 1e-10) break;
    for (let u = 0; u < n; u++) z[u] = r[u] / diag[u];
    let rz2 = 0;
    for (let u = 0; u < n; u++) rz2 += r[u] * z[u];
    const b = rz2 / rz;
    rz = rz2;
    for (let u = 0; u < n; u++) pv[u] = z[u] + b * pv[u];
  }
  // Heat flow from the interior, and the interior surface temperatures.
  let Q = 0;
  let thetaSiMin = Infinity;
  for (const [u, g] of surf) {
    const flow = g * (o.inside - x[u]); // W/m through this face
    Q += flow;
    const qd = flow / hm; // W/m²
    thetaSiMin = Math.min(thetaSiMin, o.inside - qd * o.rsi);
  }
  const dT = o.inside - o.outside;
  const T = new Float32Array(N);
  for (let k = 0; k < N; k++) T[k] = kind[k] === 0 ? x[idx[k]] : kind[k] === 1 ? o.inside : o.outside;
  return { Q, L2D: Q / dT, thetaSiMin, iterations: it, faces, grid: { nx, ny, cell: h, x0: box.x0, y0: box.y0, T, kind } };
}

/** Length of segment a-b inside an axis-aligned box. */
function clipLength(a, b, box) {
  let t0 = 0;
  let t1 = 1;
  const d = [b[0] - a[0], b[1] - a[1]];
  for (const [p, q] of [
    [-d[0], a[0] - box.x0],
    [d[0], box.x1 - a[0]],
    [-d[1], a[1] - box.y0],
    [d[1], box.y1 - a[1]],
  ]) {
    if (Math.abs(p) < 1e-12) {
      if (q < 0) return 0;
    } else {
      const t = q / p;
      if (p < 0) t0 = Math.max(t0, t);
      else t1 = Math.min(t1, t);
    }
  }
  return t1 > t0 ? (t1 - t0) * Math.hypot(d[0], d[1]) : 0;
}

const segmentHitsBox = (a, b, box) => clipLength(a, b, box) > 0;

/** A box around the junction of the given walls/columns: their meeting point, reaching `reach` mm past their faces. */
export function junctionBox(doc, scene, ids, reach = 1000) {
  const els = ids.map((id) => doc.get(id)).filter(Boolean);
  const walls = els.filter((e) => e.kind === 'wall' && e.a && e.b);
  const cols = els.filter((e) => e.kind === 'column' && e.at);
  let center = null;
  let thick = 0;
  if (cols.length) center = cols[0].at;
  // The nearest pair of wall ends (or end and wall) is the junction.
  let best = Infinity;
  for (let i = 0; i < walls.length; i++)
    for (let j = i + 1; j < walls.length; j++)
      for (const p of [walls[i].a, walls[i].b])
        for (const qq of [walls[j].a, walls[j].b]) {
          const d = Math.hypot(p[0] - qq[0], p[1] - qq[1]);
          if (d < best) (best = d), (center = [(p[0] + qq[0]) / 2, (p[1] + qq[1]) / 2]);
        }
  for (const w of walls) thick = Math.max(thick, typeThickness(doc.get(w.typeId)) || 300);
  if (!center && walls.length) center = [(walls[0].a[0] + walls[0].b[0]) / 2, (walls[0].a[1] + walls[0].b[1]) / 2];
  if (!center) return null;
  const half = reach + thick;
  return { x0: center[0] - half, y0: center[1] - half, x1: center[0] + half, y1: center[1] + half, levelId: (walls[0] || cols[0]).levelId };
}

/** RGB of a temperature between lo and hi on a blue-to-red scale. */
export function heatColor(t, lo, hi) {
  const s = Math.max(0, Math.min(1, (t - lo) / (hi - lo || 1)));
  const stops = [
    [0, [49, 54, 149]],
    [0.25, [69, 117, 180]],
    [0.5, [171, 217, 233]],
    [0.65, [254, 224, 144]],
    [0.8, [244, 109, 67]],
    [1, [165, 0, 38]],
  ];
  for (let i = 1; i < stops.length; i++)
    if (s <= stops[i][0]) {
      const [a, ca] = stops[i - 1];
      const [b, cb] = stops[i];
      const f = (s - a) / (b - a);
      return ca.map((c, k) => Math.round(c + (cb[k] - c) * f));
    }
  return stops.at(-1)[1];
}

// Sections ----------------------------------------------------------------------------------

/** Where a plan polygon crosses the section line: [u0, u1] intervals along it. */
function lineIntervals(poly, frame) {
  const L = frame.look;
  const R = frame.right;
  const o = frame.origin;
  const us = [];
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const da = (a[0] - o[0]) * L[0] + (a[1] - o[1]) * L[1];
    const db = (b[0] - o[0]) * L[0] + (b[1] - o[1]) * L[1];
    if ((da > 0) === (db > 0)) continue;
    const t = da / (da - db);
    const p = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
    us.push((p[0] - o[0]) * R[0] + (p[1] - o[1]) * R[1]);
  }
  us.sort((x, y) => x - y);
  const out = [];
  for (let i = 0; i + 1 < us.length; i += 2) if (us[i + 1] - us[i] > 0.5) out.push([us[i], us[i + 1]]);
  return out;
}

const rect = (u0, u1, z0, z1) => [
  [u0, z0],
  [u1, z0],
  [u1, z1],
  [u0, z1],
];

/**
 * The solid parts cut by a section view, in its (u, z) coordinates: columns, then slabs layer by layer from the top,
 * then the walls' layers (slabs take precedence over walls, as in Archicad's element priorities).
 */
export function sectionJunctionParts(doc, scene, view, notes = new Set()) {
  const frame = viewFrame(view);
  const out = [];
  const walls = [];
  for (const lv of doc.levels()) {
    for (const p of junctionParts(doc, scene, lv.id, notes)) {
      if (p.z0 == null) continue;
      const dest = p.column ? out : walls;
      for (const [u0, u1] of lineIntervals(p.poly, frame)) dest.push({ ...p, poly: rect(u0, u1, p.z0, p.z1) });
    }
  }
  for (const f of doc.all('floor')) {
    if (!f.boundary?.length) continue;
    const type = doc.get(f.typeId) || {};
    const top = levelElevation(doc, f.levelId) + (+f.offset || 0);
    const layers = type.layers?.length ? type.layers : [{ materialId: type.materialId, thickness: typeThickness(type) || 200 }];
    if (f.holes?.length) notes.add('Openings in slabs are not cut in the section simulation.');
    for (const [u0, u1] of lineIntervals(f.boundary, frame)) {
      let z = top;
      for (const l of layers) {
        const t = +l.thickness || 0;
        if (t <= 0) continue;
        let lambda = lambdaOf(doc, l.materialId, t);
        if (lambda == null) {
          notes.add(`${doc.get(l.materialId)?.name || 'A layer'} of ${type.name || 'a slab'} has no thermal conductivity: 1.0 W/mK assumed.`);
          lambda = 1;
        }
        out.push({ poly: rect(u0, u1, z - t, z), lambda, name: doc.get(l.materialId)?.name || 'Layer', elementId: f.id, thickness: typeThickness(type) || t, slab: true });
        z -= t;
      }
    }
  }
  if (doc.all('roof').length) notes.add('Roofs are not part of the section simulation yet.');
  return [...out, ...walls];
}

/** A box in a section view around the junction of the selected walls and slabs (u, z in mm). */
export function sectionJunctionBox(doc, scene, view, ids, reach = 1000) {
  const frame = viewFrame(view);
  const parts = sectionJunctionParts(doc, scene, view);
  const mine = parts.filter((p) => ids.includes(p.elementId));
  const walls = mine.filter((p) => !p.slab);
  const slabs = mine.filter((p) => p.slab);
  if (!mine.length) return null;
  const span = (list, k) => [Math.min(...list.flatMap((p) => p.poly.map((q) => q[k]))), Math.max(...list.flatMap((p) => p.poly.map((q) => q[k])))];
  let u;
  let z;
  if (walls.length && slabs.length) {
    const [wu0, wu1] = span(walls, 0);
    // The wall that the slab meets: the one whose interval is nearest the slab's edge.
    u = (wu0 + wu1) / 2;
    const [sz0, sz1] = span(slabs, 1);
    z = (sz0 + sz1) / 2;
    if (walls.length > 1) {
      // Several walls cut: keep the one nearest the slab's end.
      const [su0, su1] = span(slabs, 0);
      const best = walls.reduce((a, b) => {
        const da = Math.min(Math.abs((a.poly[0][0] + a.poly[1][0]) / 2 - su0), Math.abs((a.poly[0][0] + a.poly[1][0]) / 2 - su1));
        const dbb = Math.min(Math.abs((b.poly[0][0] + b.poly[1][0]) / 2 - su0), Math.abs((b.poly[0][0] + b.poly[1][0]) / 2 - su1));
        return dbb < da ? b : a;
      });
      u = (best.poly[0][0] + best.poly[1][0]) / 2;
    }
  } else {
    const [u0, u1] = span(mine, 0);
    const [z0, z1] = span(mine, 1);
    u = (u0 + u1) / 2;
    z = slabs.length ? (z0 + z1) / 2 : z1;
  }
  const thick = Math.max(300, ...mine.map((p) => p.thickness || 0));
  void frame;
  return { x0: u - reach - thick, x1: u + reach + thick, y0: z - reach - thick, y1: z + reach + thick };
}

/**
 * Solve a junction in a section view (walls, slabs, columns; u across the view, z up). Air is interior where a
 * room of the level at that height lies under the point in plan, exterior elsewhere. Flanking elements are those
 * with exterior faces longer than twice their thickness (the envelope), measured on the grid.
 */
export function simulateSection(doc, scene, view, box, opts = {}) {
  const o = { ...TB_DEFAULTS, ...opts };
  const notes = new Set();
  const frame = viewFrame(view);
  const parts = sectionJunctionParts(doc, scene, view, notes);
  const levels = doc.levels();
  const rooms = doc.all('room').map((r) => {
    const i = levels.findIndex((l) => l.id === r.levelId);
    const z0 = levels[i]?.elevation ?? 0;
    const z1 = levels[i + 1]?.elevation ?? z0 + (+r.upperOffset || 3000);
    return { reg: scene.rooms.room(r), z0, z1 };
  }).filter((r) => r.reg);
  const air = ([u, z]) => {
    const p = [frame.origin[0] + frame.right[0] * u, frame.origin[1] + frame.right[1] * u];
    return rooms.some((r) => z >= r.z0 && z < r.z1 && pointInPolygon(p, r.reg.outer)) ? 1 : 2;
  };
  const res = solveGrid(parts, box, air, o, notes);
  if (res.error) return res;
  const flanking = [];
  // Exterior faces of what is not flanking (a slab edge reaching the outside) go to the flanking walls, as external
  // dimensions run past it.
  let edgeOut = 0;
  for (const [id, f] of res.faces) {
    const part = parts.find((p) => p.elementId === id);
    if (part && !(f.out > 2 * (part.thickness || 300) && f.in > 0)) edgeOut += f.out;
  }
  for (const [id, f] of res.faces) {
    const el = doc.get(id);
    const part = parts.find((p) => p.elementId === id);
    if (!el || !part || f.out <= 2 * (part.thickness || 300) || f.in <= 0) continue;
    const u = thermalProperties(doc, doc.get(el.typeId))?.u;
    if (!u) {
      notes.add(`${doc.get(el.typeId)?.name || 'An element'} has no U-value: left out of ψ.`);
      continue;
    }
    flanking.push({ id, name: doc.get(el.typeId)?.name || el.kind, u, lIn: f.in / 1000, lOut: f.out / 1000 });
  }
  for (const fl of flanking) fl.lOut += edgeOut / 1000 / flanking.length;
  return finish(res, flanking, o, notes);
}
