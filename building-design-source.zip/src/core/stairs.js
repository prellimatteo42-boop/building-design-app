/**
 * Stair layout: flights and landings for straight, L-shaped and U-shaped
 * stairs. A stair runs from its base to its top level; the risers are
 * shared between flights and each landing sits at the top of a flight.
 *
 * Flight: { start (center of its first riser line), dir, side (left unit
 * vector), risers, z0 (bottom), run (length) }
 * Landing: { poly, z }
 */
import { add, sub, scale, norm, perp, len } from './geom.js';
import { stairLayout } from './model.js';

export const STAIR_SHAPES = [
  { value: 'straight', label: 'Straight' },
  { value: 'l', label: 'L-shaped' },
  { value: 'u', label: 'U-shaped' },
  { value: 'spiral', label: 'Spiral' },
];

/** The shapes a placed stair can show: also its own flights, for a stair that came with them (an Archicad one). */
export const STAIR_SHAPES_PLACED = [...STAIR_SHAPES, { value: 'flights', label: 'Flights as Drawn' }];

/** Radius of a spiral stair's central column. */
export const SPIRAL_CORE = 100;

/**
 * Spiral geometry: { c, rin, rout, rwalk, a0, step (radians per tread, signed), treads }.
 * The tread depth is measured on the walking line, in the middle of the width.
 */
export function spiralLayout(el, lay) {
  const { risers: R, tread: td, width: W } = lay;
  const rin = SPIRAL_CORE;
  const rout = rin + W;
  const rwalk = rin + W / 2;
  const d0 = sub(el.b, el.a);
  const a0 = Math.atan2(d0[1], d0[0]);
  const sign = el.turn === 'right' ? -1 : 1;
  const step = sign * Math.min(Math.PI / 4, td / rwalk);
  return { c: el.a, rin, rout, rwalk, a0, step, treads: Math.max(1, R) };
}

export function stairFlights(doc, el) {
  const lay = stairLayout(doc, el);
  const { base, risers: R, riserHeight: rh, tread: td, width: W } = lay;
  const d0 = sub(el.b, el.a);
  const dir = len(d0) > 1 ? norm(d0) : [1, 0];
  const left = perp(dir);
  const turn = el.turn === 'right' ? scale(left, -1) : left;
  const shape = el.shape || 'straight';
  const flights = [];
  const landings = [];
  if (shape === 'spiral') return { ...lay, shape, dir, flights, landings, spiral: spiralLayout(el, lay) };
  if (shape === 'flights' && Array.isArray(el.flightPath) && el.flightPath.length >= 2) return pathFlights(el, lay, dir, left);
  if (shape === 'straight' || shape === 'flights' || R < 4) {
    flights.push({ start: el.a, dir, side: left, risers: R, z0: base, run: (R - 1) * td });
    return { ...lay, shape: 'straight', dir, flights, landings };
  }
  // System Edit Mode: where the stair turns (risers in the first flight) and the landing's depth.
  const r1 = Math.max(2, Math.min(R - 2, Math.round(+el.splitRisers) || Math.ceil(R / 2)));
  const r2 = R - r1;
  const s1 = (r1 - 1) * td;
  const zLanding = base + r1 * rh;
  const D = Math.max(W, +el.landingDepth || W);
  flights.push({ start: el.a, dir, side: left, risers: r1, z0: base, run: s1 });
  const P = (s, w) => add(add(el.a, scale(dir, s)), scale(turn, w));
  if (shape === 'l') {
    landings.push({ poly: [P(s1, -W / 2), P(s1 + D, -W / 2), P(s1 + D, W / 2), P(s1, W / 2)], z: zLanding });
    const d2 = turn;
    flights.push({ start: P(s1 + D - W / 2, W / 2), dir: d2, side: perp(d2), risers: r2, z0: zLanding, run: (r2 - 1) * td, fromLanding: true });
  } else {
    const gap = Math.max(0, +el.gap || 100);
    landings.push({ poly: [P(s1, -W / 2), P(s1 + D, -W / 2), P(s1 + D, W * 1.5 + gap), P(s1, W * 1.5 + gap)], z: zLanding });
    const d2 = scale(dir, -1);
    flights.push({ start: P(s1, W + gap), dir: d2, side: perp(d2), risers: r2, z0: zLanding, run: (r2 - 1) * td, fromLanding: true });
  }
  return { ...lay, shape, dir, flights, landings };
}

/**
 * A stair of any number of flights (as Archicad's are, read from a project): el.flightPath = [{ at: [u, v], dir: [u, v],
 * risers }], each flight's first riser centre and direction in the stair's own frame (u along a→b, v to its left), so
 * the stair moves and turns with a and b. The last flight takes the risers left. Between two flights a landing at the
 * top of the first: from its last tread on, as deep as the stair is wide or as far as the next flight's first riser
 * line reaches, and as wide as both.
 */
function pathFlights(el, lay, dir, left) {
  const { base, risers: R, riserHeight: rh, tread: td, width: W } = lay;
  const world = (u, v) => add(add(el.a, scale(dir, u)), scale(left, v));
  const vec = (u, v) => norm(add(scale(dir, u), scale(left, v)));
  const path = el.flightPath.map((f) => ({ start: world(f.at[0], f.at[1]), dir: vec(f.dir[0], f.dir[1]), risers: Math.max(1, Math.round(+f.risers || 1)) }));
  const flights = [];
  const landings = [];
  let z = base;
  let used = 0;
  for (const [k, f] of path.entries()) {
    const last = k === path.length - 1;
    const r = last ? Math.max(1, R - used) : f.risers;
    const run = Math.max(0, (r - 1) * td);
    const side = perp(f.dir);
    flights.push({ start: f.start, dir: f.dir, side, risers: r, z0: z, run, ...(k ? { fromLanding: true } : {}) });
    used += r;
    z += r * rh;
    if (last) break;
    const next = path[k + 1];
    const edge = [add(next.start, scale(perp(next.dir), W / 2)), add(next.start, scale(perp(next.dir), -W / 2))];
    const uv = edge.map((p) => {
      const d = sub(p, f.start);
      return [d[0] * f.dir[0] + d[1] * f.dir[1], d[0] * side[0] + d[1] * side[1]];
    });
    const u0 = run;
    const u1 = Math.max(run + W, ...uv.map((q) => q[0]));
    const v0 = Math.min(-W / 2, ...uv.map((q) => q[1]));
    const v1 = Math.max(W / 2, ...uv.map((q) => q[1]));
    const P = (u, v) => add(add(f.start, scale(f.dir, u)), scale(side, v));
    landings.push({ poly: [P(u0, v0), P(u1, v0), P(u1, v1), P(u0, v1)], z });
  }
  return { ...lay, shape: 'flights', dir, flights, landings };
}

/** Plan outline corners of a flight: from its first riser to its last. */
export function flightOutline(f, W) {
  const o = add(f.start, scale(f.side, -W / 2));
  const S = (s, w) => add(add(o, scale(f.dir, s)), scale(f.side, w));
  return [S(0, 0), S(f.run, 0), S(f.run, W), S(0, W)];
}

/** Point on a flight at distance s along it and w across from its right edge. */
export function flightPoint(f, W, s, w) {
  const o = add(f.start, scale(f.side, -W / 2));
  return add(add(o, scale(f.dir, s)), scale(f.side, w));
}
