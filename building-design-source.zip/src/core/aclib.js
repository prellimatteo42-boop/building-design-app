/**
 * Library parts from a user's own Archicad libraries (io/gsm.js) as GDL
 * objects of this app (gdlobject.js): their parameters in this app's units,
 * their master, 2D and 3D scripts, and the macros they call, carried with
 * them so the object runs on its own. Scripts run leniently: what this GDL
 * reader leaves out is counted, not fatal.
 */
import { libraryParts, readLibraryPart } from '../io/gsm.js';
import { runGDL } from './gdl.js';
import { read3DBinary } from '../io/binary3d.js';
import { modelPortGeometry, meshBinary, readMeshBinary } from '../io/modelport.js';

const KIND = { integer: 'integer', length: 'length', angle: 'angle', number: 'number', boolean: 'boolean', material: 'material', buildingMaterial: 'material', profile: 'integer', string: 'string', pen: 'integer', fill: 'integer', lineType: 'integer', lightSwitch: 'boolean', color: 'integer', intensity: 'number' };

/**
 * A library: parts by name (lower case), and the objects among them (not macros). A project's embedded library
 * has its parts by GUID too, the pictures its textures name by file name, and the user's libraries behind it
 * (`fallback`) for the macros it does not carry.
 */
export class ArchicadLibrary {
  constructor({ fallback = null } = {}) {
    this.parts = new Map();
    this.byGuid = new Map();
    this.images = new Map();
    this.files = [];
    this.fallback = fallback;
  }

  /** Add one part from a project's embedded library, by its name and GUID (hex, as at 0x48 of its header). */
  addPart(name, bytes, { guid = null, file = 'embedded' } = {}) {
    const e = { name, path: `${file}/${name}.gsm`, bytes, lp: null, file };
    if (!this.parts.has(name.toLowerCase())) this.parts.set(name.toLowerCase(), e);
    if (guid) this.byGuid.set(String(guid).toLowerCase(), e);
    return e;
  }

  /** A picture a texture names by its file name ({ mime, bytes }). */
  addImage(name, mime, bytes) {
    this.images.set(String(name).toLowerCase(), { mime, bytes });
  }

  /** A picture by file name, with or without its extension, here or in the libraries behind. */
  image(name) {
    const k = String(name).toLowerCase();
    const found = this.images.get(k) || [...this.images].find(([n]) => n.replace(/\.[a-z0-9]+$/, '') === k)?.[1];
    return found || this.fallback?.image?.(name) || null;
  }

  /** A part by its GUID, read on first use. */
  getGuid(guid) {
    const e = guid && this.byGuid.get(String(guid).toLowerCase());
    return e ? this.get(e.name, e) : null;
  }

  /** Add a container (.lcf, .libpack) or a single part (.gsm). Returns how many parts it added. */
  add(name, bytes) {
    const list = /\.gsm$/i.test(name) ? [{ path: name, bytes }] : libraryParts(bytes);
    let n = 0;
    for (const p of list) {
      const short = p.path.split('/').pop().replace(/\.gsm$/i, '');
      this.parts.set(short.toLowerCase(), { name: short, path: p.path, bytes: p.bytes, lp: null, file: name });
      n++;
    }
    this.files.push({ name, parts: n });
    return n;
  }

  /** A part read on first use (here, else in the libraries behind). */
  get(name, given = null) {
    const e = given || this.parts.get(String(name).toLowerCase());
    if (!e) return this.fallback?.get(name) || null;
    if (!e.lp) {
      try {
        e.lp = readLibraryPart(e.bytes);
      } catch {
        e.lp = { params: [], scripts: {}, broken: true };
      }
    }
    return e;
  }

  /** Objects to place: parts outside macro folders, with a 3D script. */
  objects() {
    return [...this.parts.values()].filter((e) => !/(^|\/)(macros?|.*macros)\//i.test(e.path) && !/_m$|macro/i.test(e.name)).sort((a, b) => a.path.localeCompare(b.path));
  }
}

/**
 * A material for an Archicad material parameter: their values index the
 * attributes of Archicad's own project, which this app does not have, so
 * the parameter's name and description choose one of this app's instead.
 */
const MATERIAL_WORDS = [
  ['mat-glass', /glass|glaz|vetr|скл|стекл|verre/i],
  ['mat-fabric-warm', /cushion|pillow|upholst|fabric|textile|seat|sofa|couch|mattress|bedding|blanket|cuscin|tessut|seduta|ткан|подушк/i],
  ['mat-porcelain', /porcelain|ceramic|sink|basin|toilet|wc|bidet|tub|shower|ceramica|porcellana|lavab/i],
  ['mat-steel', /leg|frame|metal|steel|chrome|alu|base|handle|knob|wheel|caster|rod|tube|gamb|telaio|metall|acciaio|ніжк|ножк|каркас/i],
  ['mat-wood', /top|wood|timber|desk|board|shelf|panel|door|drawer|veneer|oak|walnut|legn|piano|ripiano|дерев|столешн/i],
  ['mat-stone', /stone|marble|granite|concrete|pietra|marmo|камін|камен/i],
  ['mat-paint-white', /plastic|body|cover|shell|lamp|shade|paint/i],
];
// Railings and stairs: their panels are glass, their posts, rails and fixings steel, as Archicad's defaults.
const RAILING_WORDS = [
  ['mat-glass', /panel|glass|glaz/i],
  ['mat-steel', /post|rail|bar|fixing|bracket|baluster|clamp|bolt|plate|rod|beam|stringer|frame|support|end/i],
];

function materialFor(p, path = '') {
  const words = `${p.name} ${p.label || ''}`;
  if (/(^|\/)(stair and railing|railing)(\/|$)/i.test(path) || /\/Railing\//i.test(path)) for (const [id, re] of RAILING_WORDS) if (re.test(words)) return id;
  for (const [id, re] of MATERIAL_WORDS) if (re.test(words)) return id;
  return 'mat-wood-light';
}

/** A macro resolver over a library that records every macro it hands out. */
function resolver(lib, used) {
  return (name) => {
    const e = lib.get(name);
    if (!e || e.lp.broken) return null;
    used.set(e.name.toLowerCase(), e);
    return macroOf(e.lp, e.path);
  };
}

const macroOf = (lp, path = '') => ({ params: lp.params.map((p) => ({ name: p.name, value: p.kind === 'material' || p.kind === 'buildingMaterial' ? materialFor(p, path) : p.value })), scripts: { master: lp.scripts.master || '', script2d: lp.scripts.script2d || '', script3d: lp.scripts.script3d || '', paramScript: lp.scripts.paramScript || '' }, binary: binaryOf(lp) });

/** BINARY's data for a part: its 3DBN sections read on first use. */
function binaryOf(lp) {
  if (!lp.binaries?.size) return null;
  const read = new Map();
  return (id) => {
    if (!read.has(id)) read.set(id, lp.binaries.has(id) ? readMeshBinary(lp.binaries.get(id)) || read3DBinary(lp.binaries.get(id)) : null);
    return read.get(id);
  };
}

/** A part's binary 3D sections, as base64 by number, when its scripts draw them (for a type to carry). */
function binariesOf(lp) {
  const src = `${lp.scripts.master || ''}\n${lp.scripts.script3d || ''}`;
  if (!lp.binaries?.size || !/\bBINARY\b/i.test(src)) return undefined;
  const out = {};
  for (const [id, bytes] of lp.binaries) out[id] = base64(bytes);
  return out;
}

function base64(bytes) {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

/** A picture as a data URL. */
function dataUrl({ mime, bytes }) {
  return `data:${mime};base64,${base64(bytes)}`;
}

/** Variables for running a part as it comes (metres, Archicad's values). */
export function partVars(lp) {
  const vars = {};
  for (const p of lp.params) vars[p.name.toUpperCase()] = p.value;
  return vars;
}

/**
 * The macros a part's scripts name in CALL "..." and the settings objects
 * they read with LIBRARYGLOBAL("..."), with the ones those name in turn,
 * as found in the library (at most `limit`).
 */
export function namedMacros(lib, e, limit = 400) {
  const out = new Map();
  const queue = [e];
  const re = /\b(?:call|libraryglobal\s*\()\s*"([^"]+)"/gi;
  while (queue.length && out.size < limit) {
    const part = queue.shift();
    for (const src of Object.values(part.lp?.scripts || {})) {
      if (typeof src !== 'string') continue;
      for (const m of src.matchAll(re)) {
        const key = m[1].toLowerCase();
        if (out.has(key) || key === e.name.toLowerCase()) continue;
        const found = lib.get(m[1]);
        if (!found || found.lp?.broken) continue;
        out.set(key, found);
        queue.push(found);
      }
    }
  }
  return [...out.values()];
}

/** Run a part's master and 3D (or 2D) script against a library. Returns { run, used }. */
export function runPart(lib, e, mode = '3d') {
  const used = new Map();
  const src = `${e.lp.scripts.master || ''}\n${(mode === '2d' ? e.lp.scripts.script2d : e.lp.scripts.script3d) || ''}`;
  const run = runGDL(src, { vars: partVars(e.lp), lenient: true, macros: resolver(lib, used), mode, maxSteps: 3e6, binary: binaryOf(e.lp) });
  return { run, used };
}

/**
 * A component type for a part (to add to a document): its size from A, B
 * and ZZYZX, its parameters in millimetres, its scripts and every macro its
 * 2D and 3D runs called.
 */
export function partType(lib, e) {
  const mp = modelPortType(e);
  if (mp) return mp;
  const used = new Map();
  const pics = new Set();
  for (const mode of ['3d', '2d']) {
    try {
      const { run, used: u } = runPart(lib, e, mode);
      for (const [k, v] of u) used.set(k, v);
      for (const t of run.tris) if (t.tex) pics.add(t.tex.pic);
      for (const q of run.pictures2) pics.add(q.pic);
    } catch {
      /* a run that stops still names the macros it reached */
    }
  }
  // Every macro its scripts name, and theirs in turn: branches a run with the default values does not
  // take (another option, a stair component's geometry that only the stair gives) need theirs too.
  for (const m of namedMacros(lib, e)) if (!used.has(m.name.toLowerCase())) used.set(m.name.toLowerCase(), m);
  // The pictures its textures use as it comes, from the part or else the macros it calls.
  const pictures = {};
  for (const id of pics) {
    const pic = [e, ...used.values()].map((m) => m.lp.pictures?.get(id)).find(Boolean) || (typeof id === 'string' ? lib.image?.(id) : null);
    if (pic && /^image\/(png|jpe?g|gif|bmp|webp)/.test(pic.mime)) pictures[id] = dataUrl(pic);
  }
  const val = (n) => +(e.lp.params.find((p) => p.name.toUpperCase() === n)?.value || 0);
  const params = e.lp.params
    .filter((p) => KIND[p.kind] && !['A', 'B', 'ZZYZX'].includes(p.name.toUpperCase()))
    .map((p) => ({ name: p.name, label: p.label || p.name, kind: Array.isArray(p.value) ? 'array' : KIND[p.kind], value: Array.isArray(p.value) ? p.value : p.kind === 'length' ? Math.round(p.value * 1e4) / 10 : p.kind === 'material' || p.kind === 'buildingMaterial' ? materialFor(p, e.path) : p.kind === 'string' ? (typeof p.value === 'string' ? p.value : '') : p.value }));
  const macros = {};
  for (const [k, m] of used) {
    const { binary, ...macro } = macroOf(m.lp, m.path);
    const binaries = binariesOf(m.lp);
    macros[k] = binaries ? { ...macro, binaries } : macro;
  }
  const binaries = binariesOf(e.lp);
  // Doors and windows become door and window types: the wall's hole is the opening's, the rest GDL.
  // By the part's name, else the folder nearest it (a library's top folder may name both).
  // Whole words: "Outdoor" is no door.
  const kindIn = (txt) => (/\b(doors?|gates?)\b/i.test(txt) ? 'doorType' : /\b(windows?|skylights?|glazing)\b/i.test(txt) ? 'windowType' : null);
  const folders = e.path.split('/').slice(0, -1).reverse().filter((f) => !/doors? and windows?/i.test(f));
  const opening = kindIn(e.name) || folders.map(kindIn).find(Boolean) || null;
  if (opening)
    return {
      kind: opening,
      family: 'gdl',
      name: e.name,
      width: Math.round(val('A') * 1000) || 900,
      height: Math.round(val('B') * 1000) || 2100,
      ...(opening === 'windowType' ? { sill: 900 } : {}),
      gdl: { lenient: true, source: e.path, params, master: e.lp.scripts.master || '', script3d: e.lp.scripts.script3d || '', script2d: e.lp.scripts.script2d || '', paramScript: e.lp.scripts.paramScript || '', macros, pictures, ...(binaries ? { binaries } : {}) },
    };
  return {
    kind: 'componentType',
    family: 'gdl',
    category: 'furniture',
    familyName: 'Archicad Object',
    name: e.name,
    width: Math.round(val('A') * 1000) || 1000,
    depth: Math.round(val('B') * 1000) || 1000,
    height: Math.round(val('ZZYZX') * 1000) || 1000,
    gdl: { lenient: true, source: e.path, params, master: e.lp.scripts.master || '', script3d: e.lp.scripts.script3d || '', script2d: e.lp.scripts.script2d || '', paramScript: e.lp.scripts.paramScript || '', macros, pictures, ...(binaries ? { binaries } : {}) },
  };
}

/**
 * A part whose 3D an add-on draws from the part's own model data ('mpcu', see io/modelport.js): a type that draws
 * that model itself, one BINARY body per colour, stretched to A, B and ZZYZX as the add-on does (its scale is the size
 * asked over the part's own), and its plan the projection of its 3D. Null when the part has no such data.
 */
export function modelPortType(e) {
  const s = e.lp?.sections?.mpcu;
  if (!s || s.off + s.len > e.bytes.length) return null;
  let g = null;
  try {
    g = modelPortGeometry(e.bytes.subarray(s.off, s.off + s.len));
  } catch {
    g = null;
  }
  if (!g?.groups.length) return null;
  const val = (n) => +(e.lp.params.find((p) => p.name.toUpperCase() === n)?.value || 0);
  const size = [0, 1, 2].map((k) => Math.max(1e-6, g.max[k] - g.min[k]));
  const [a0, b0, z0] = [val('A') || size[0], val('B') || size[1], val('ZZYZX') || size[2]];
  const num = (v) => String(+v.toPrecision(10));
  const lines = ['! The model this part carries in its data, as its add-on would draw it.', `MUL A / ${num(a0)}, B / ${num(b0)}, ZZYZX / ${num(z0)}`];
  const binaries = {};
  g.groups.forEach((grp, i) => {
    const name = `mp_${i + 1}`;
    lines.push(`DEFINE MATERIAL "${name}" 0, ${grp.color.map((v) => num(v)).join(', ')}`, `MATERIAL "${name}"`, `BINARY 0, ${i + 1}`);
    binaries[i + 1] = base64(meshBinary(grp.tris, grp.edges));
  });
  lines.push('DEL 1');
  const params = e.lp.params
    .filter((p) => KIND[p.kind] && !['A', 'B', 'ZZYZX'].includes(p.name.toUpperCase()) && !/^_scl|^_trigger$/i.test(p.name))
    .map((p) => ({ name: p.name, label: p.label || p.name, kind: Array.isArray(p.value) ? 'array' : KIND[p.kind], value: Array.isArray(p.value) ? p.value : p.kind === 'length' ? Math.round(p.value * 1e4) / 10 : p.kind === 'material' || p.kind === 'buildingMaterial' ? materialFor(p, e.path) : p.kind === 'string' ? (typeof p.value === 'string' ? p.value : '') : p.value }));
  return {
    kind: 'componentType',
    family: 'gdl',
    category: 'furniture',
    familyName: 'Archicad Object',
    name: e.name,
    width: Math.round(a0 * 1000),
    depth: Math.round(b0 * 1000),
    height: Math.round(z0 * 1000),
    gdl: { lenient: true, source: e.path, modelPort: { triangles: g.triangles, blocks: g.blocks }, params, master: '', script3d: lines.join('\n'), script2d: 'PROJECT2 3, 270, 2', paramScript: '', macros: {}, pictures: {}, binaries },
  };
}

/**
 * Parts of Archicad's localised libraries by their international name and package: a project made with another
 * language's library (its names translated, its version at the end: "Куб 25") finds the same object in the user's.
 * Names without their version; [localised, international, package].
 */
const LOCALISED_PARTS = [
  ['Куб', 'Cube', 'Basic Shapes and Special Constructions'],
  ['Цилиндр', 'Cylinder', 'Basic Shapes and Special Constructions'],
  ['Обеденный Стул 01', 'Dining Chair 01', 'Chairs'],
  ['Обеденный Стул 02', 'Dining Chair 02', 'Chairs'],
  ['Обеденный Стул 03', 'Dining Chair 03', 'Chairs'],
  ['Пуф 04', 'Ottoman 04', 'Chairs'],
  ['Диван 01', 'Sofa 01', 'Couches and Sofas'],
  ['Диван 04', 'Sofa 04', 'Couches and Sofas'],
  ['Кресло-кровать 01', 'Sofa Chair 01', 'Couches and Sofas'],
  ['Кресло-кровать 04', 'Sofa Chair 04', 'Couches and Sofas'],
  ['Кушетка 01', 'Sofa Bed 01', 'Couches and Sofas'],
  ['Подушка', 'Pillow', 'Decoration'],
  ['Зеркало', 'Mirror', 'Decoration'],
  ['Прикроватная Тумбочка 04', 'Nightstand 04', 'Cabinets and Shelves'],
  ['Гардероб 02', 'Wardrobe 02', 'Cabinets and Shelves'],
  ['Модульный Гардероб', 'Wardrobe Modular', 'Cabinets and Shelves'],
  ['Стеллаж Книжный 01', 'Bookshelf 01', 'Cabinets and Shelves'],
  ['Тумба под ТВ Корпусная', 'TV Stand Mounted', 'Cabinets and Shelves'],
  ['Кровать 04', 'Bed 04', 'Beds'],
  ['Кровать Двуспальная 04', 'Bed Double 04', 'Beds'],
  ['Стол Журнальный 04', 'Coffee Table 04', 'Tables'],
  ['Стол Журнальный 06', 'Coffee Table 06', 'Tables'],
  ['Стол Круглый 01', 'Round Table 01', 'Tables'],
  ['Стол Обеденный 01', 'Dining Table 01', 'Tables'],
  ['Стол Офисный Прямоугольный', 'Office Desk Rect', 'Tables'],
  ['Обеденная Группа с Круглым Столом', 'Dining Table Round', 'Furniture Layouts'],
  ['Плоская Панель ТВ', 'Flat Panel TV', 'Office and School Equipment'],
  ['Холодильник', 'Refrigerator', 'Appliances'],
  ['Встроенная Посудомоечная Машина', 'Dishwasher Built-in', 'Appliances'],
  ['Духовой Шкаф Встроенный', 'Oven Built-in', 'Appliances'],
  ['Варочная Панель Встроенная', 'Cooktop Built-in', 'Appliances'],
  ['Варочная Панель Электрическая', 'Cooktop Electric', 'Appliances'],
  ['Навесной Шкаф Прямой', 'Wall Cabinet Block', 'Kitchen'],
  ['Напольный Шкаф Прямой', 'Base Cabinet Block', 'Kitchen'],
  ['Секция Прямая', 'Base Cabinet Block', 'Kitchen'],
  ['Секция 1-створчатая', 'Base Cabinet Block', 'Kitchen'],
  ['Секция 2-створчатая', 'Base Cabinet Block', 'Kitchen'],
  ['Шкаф Напольный 1-створчатый', 'Base Cabinet Block', 'Kitchen'],
  ['Шкаф Напольный 2-створчатый', 'Base Cabinet Block', 'Kitchen'],
  ['Секция Угловая Г-образная', 'Base Cabinet Corner L', 'Kitchen'],
  ['Секция Угловая 1-створчатая', 'Base Cabinet Corner S', 'Kitchen'],
  ['Стиральная Машина', 'Washer', 'Plumbing Fixtures and Bathroom'],
  ['Сушильная Машина', 'Dryer', 'Plumbing Fixtures and Bathroom'],
  ['Душевой Поддон Прямоугольный', 'Shower Tray', 'Plumbing Fixtures and Bathroom'],
  ['Смеситель', 'Tap', 'Plumbing Fixtures and Bathroom'],
  ['Полотенцедержатель', 'Towel Rack', 'Plumbing Fixtures and Bathroom'],
  ['Радиатор Чугунный', 'Radiator Cast Iron', 'Heating and Air-Conditioning'],
  ['Радиатор с Горизонтальными Трубами', 'Radiator Panel', 'Heating and Air-Conditioning'],
  ['Водонагреватель Электрический', 'Electric Water Heater', 'Heating and Air-Conditioning'],
  ['Водонагреватель Газовый', 'Gas Water Heater', 'Heating and Air-Conditioning'],
  ['Кондиционер Воздуха', 'Air Conditioner', 'Heating and Air-Conditioning'],
  ['Настенный Кондиционер Воздуха', 'Air Conditioner', 'Heating and Air-Conditioning'],
  ['Жалюзи Вертикальные', 'Vertical Blinds', 'Sun Protection'],
  ['Жалюзи Горизонтальные', 'Venetian Blind', 'Sun Protection'],
  ['Потолочная Решетка', 'Ceiling Grille', 'MEP Library'],
  ['Настенная Решетка', 'Sidewall Grille', 'MEP Library'],
  ['Круглая Решетка', 'Round Grille', 'MEP Library'],
  ['Воздуховод Прямолинейный', 'Duct Straight', 'MEP Library'],
  ['Переход Воздуховода', 'Duct Transformer', 'MEP Library'],
  ['Прямолинейная Труба', 'Pipe Straight', 'MEP Library'],
  ['Труба', 'Pipe Straight', 'MEP Library'],
  ['Противопожарный Шкаф', 'Fire Hose Cabinet', 'Fire Protection'],
  ['Знак Севера', 'North Symbol', 'Graphic Symbols'],
  ['Символ Уклона', 'Slope Symbol', 'Graphic Symbols'],
];
const LOCALISED = new Map(LOCALISED_PARTS.map(([l, en, pack]) => [l.toLowerCase(), { name: en, pack }]));

/** The part's international name and package for a localised one ("Куб 25" → Cube), or null. */
export function internationalPart(name) {
  const plain = String(name || '').trim().replace(/\s+\d{2}$/, '');
  return LOCALISED.get(plain.toLowerCase()) || LOCALISED.get(String(name || '').trim().toLowerCase()) || null;
}
