/**
 * What a drawing writes beside its elements: the sizes of doors and windows
 * (width over height, "120 + 90 OL" for a window with a fanlight, "PH 85"
 * for the sill), written dimensions along their lines, and windows above
 * the cut plane, drawn with dashes across the wall. All in model mm.
 */
import { dist, dot, sub, add, scale, norm } from './geom.js';
import { rayToWall } from './recognize.js';

/** The middle of a text, from its start, its size and its angle. */
export function textCentre(t) {
  const a = t.angle || 0;
  const d = [Math.cos(a), Math.sin(a)];
  const n = [-d[1], d[0]];
  return add(add(t.at, scale(d, String(t.text).length * t.size * 0.27)), scale(n, t.size * 0.35));
}

/** A size in cm written as a number, or a sum ("120 + 90 OL"); null otherwise. */
export function sizeValue(text) {
  const m = /^\s*(\d{2,3})(?:\s*\+\s*(\d{2,3}))?(?:\s*OL)?\s*$/i.exec(text);
  return m ? +m[1] + (+m[2] || 0) : null;
}

/** A sill height written beside a window ("PH 85"), in cm, or null. */
export function sillValue(text) {
  const m = /^\s*(?:PH|BRH|H\.?\s*dav\.?|parapetto)\s*[=:]?\s*(\d{2,3})\s*$/i.exec(text);
  return m ? +m[1] : null;
}

/** Pairs of sizes written one over the other: [{ a, b, c, angle }], a and b the texts, c their middle. */
export function stackedSizes(texts) {
  const nums = texts.filter((t) => sizeValue(t.text) != null).map((t) => ({ t, c: textCentre(t), v: sizeValue(t.text) }));
  const out = [];
  for (let i = 0; i < nums.length; i++)
    for (let j = i + 1; j < nums.length; j++) {
      const [p, q] = [nums[i], nums[j]];
      if (Math.abs((p.t.angle || 0) - (q.t.angle || 0)) > 0.05 || Math.abs(p.t.size - q.t.size) > 0.2 * p.t.size) continue;
      // Stacked: apart across the reading direction, by a line or so, and about level along it.
      const a = p.t.angle || 0;
      const d = [Math.cos(a), Math.sin(a)];
      const n = [-d[1], d[0]];
      const v = sub(q.c, p.c);
      const across = Math.abs(dot(v, n));
      const along = Math.abs(dot(v, d));
      if (across < p.t.size * 0.8 || across > p.t.size * 2 || along > p.t.size * 3) continue;
      out.push({ a: p, b: q, c: scale(add(p.c, q.c), 0.5) });
    }
  return out;
}

/**
 * The label of an opening: { width, height } in mm from the nearest stack of
 * two sizes of which one is about its width, or null. Marks the texts used.
 */
export function openingLabel(o, stacks, used, reach = 1800) {
  let best = null;
  for (const s of stacks) {
    if (used.has(s.a.t) || used.has(s.b.t)) continue;
    const d = dist(s.c, o.at);
    if (d > reach || (best && d >= best.d)) continue;
    const fit = (x) => Math.abs(x.v * 10 - o.width);
    const [w, h] = fit(s.a) <= fit(s.b) ? [s.a, s.b] : [s.b, s.a];
    if (fit(w) > Math.max(220, o.width * 0.25) || h.v * 10 < 300) continue;
    best = { d, s, width: w.v * 10, height: h.v * 10 };
  }
  if (!best) return null;
  used.add(best.s.a.t).add(best.s.b.t);
  // "120 + 90 OL": the casement's height, then the light over it.
  const parts = [best.s.a, best.s.b].map((x) => /^\s*(\d{2,3})\s*\+\s*\d{2,3}/.exec(x.t.text)).find(Boolean);
  return { width: best.width, height: best.height, ...(parts ? { transomAt: +parts[1] * 10 } : {}) };
}

/** The sill written nearest a window, in mm, or null. Marks the text used. */
export function nearestSill(o, texts, used, reach = 1600) {
  let best = null;
  for (const t of texts) {
    const v = sillValue(t.text);
    if (v == null || used.has(t)) continue;
    const d = dist(textCentre(t), o.at);
    if (d <= reach && (!best || d < best.d)) best = { d, t, v };
  }
  if (!best) return null;
  used.add(best.t);
  return best.v * 10;
}

/**
 * Written dimensions: a number sitting on a straight thin line running its way, about as long as the number says.
 * [{ a, b, text, value, t }], value in mm. strokes: [{ a, b }].
 */
export function writtenDimensions(texts, strokes, used = new Set(), walls = []) {
  const out = [];
  // Drawn one over the other, numbers are an opening's width and height.
  const stacked = new Set(stackedSizes(texts).filter((s) => !used.has(s.a.t) && !used.has(s.b.t)).flatMap((s) => [s.a.t, s.b.t]));
  for (const t of texts) {
    if (used.has(t) || stacked.has(t) || !/^\s*\d+(?:[.,]\d+)?\s*$/.test(t.text)) continue;
    const raw = +t.text.replace(',', '.');
    const a = t.angle || 0;
    const d = [Math.cos(a), Math.sin(a)];
    const n = [-d[1], d[0]];
    const c = textCentre(t);
    let best = null;
    for (const s of strokes) {
      const L = dist(s.a, s.b);
      if (L < 300 || Math.abs(dot(norm(sub(s.b, s.a)), d)) < 0.998) continue;
      const m = scale(add(s.a, s.b), 0.5);
      const off = Math.abs(dot(sub(m, c), n));
      if (off > t.size * 2.2 || Math.abs(dot(sub(m, c), d)) > Math.max(t.size * 3, L * 0.25)) continue;
      // cm, mm or m on the drawing: the one that fits the line's length, to 8 %.
      let value = [raw * 10, raw, raw * 1000].find((v) => Math.abs(v - L) <= 0.08 * L);
      let line = s;
      // Some drawings stop the line short of the walls: a room's size then runs face to face.
      if (value == null && walls.length) {
        const whole = toFaces(s, walls);
        const W = dist(whole.a, whole.b);
        value = W > L ? [raw * 10, raw, raw * 1000].find((v) => Math.abs(v - W) <= 0.05 * W) : null;
        line = whole;
      }
      if (value == null) continue;
      if (!best || off < best.off) best = { off, s: line, value };
    }
    if (best) {
      used.add(t);
      out.push({ a: best.s.a, b: best.s.b, text: t.text.trim(), value: best.value, t });
    }
  }
  return out;
}

/** A line carried on from each end to the nearest wall face ahead, within 450 mm. */
function toFaces(s, walls) {
  const out = (from, d) => {
    let best = null;
    for (const w of walls) {
      const t = rayToWall(from, d, w);
      if (t == null || t <= 0) continue;
      const u = norm(sub(w.b, w.a));
      const cos = Math.abs(d[0] * -u[1] + d[1] * u[0]);
      const face = t - w.thickness / 2 / Math.max(cos, 0.2);
      if (best == null || face < best) best = face;
    }
    return best != null && best > 0 && best <= 450 ? add(from, scale(d, best)) : from;
  };
  const d = norm(sub(s.b, s.a));
  return { a: out(s.a, [-d[0], -d[1]]), b: out(s.b, d) };
}

/** Height ("RH=356", "H=2.70") and floor finish ("Belag: Parkett") written in a stamp. */
export function stampExtras(lines) {
  const out = {};
  for (const l of lines) {
    let m = /^\s*RH\s*=?\s*(\d{3})\s*$/i.exec(l);
    if (m) out.height = +m[1] * 10;
    m = /^\s*H\s*=\s*(\d(?:[.,]\d{1,3})?)\s*m?\s*$/i.exec(l);
    if (m) out.height = +m[1].replace(',', '.') * 1000;
    m = /^\s*(?:Belag|Pavimento|Finish)\s*:\s*(\S.*?)\s*$/i.exec(l);
    if (m) out.finish = m[1];
  }
  return out;
}

/**
 * Windows above the cut plane: on a wall, two stations with dashes across its thickness, as far apart as a label says.
 * [{ at, width, height }]. Marks labels used.
 */
export function dashedWindows(walls, strokes, stacks, used, texts = []) {
  const found = [];
  for (const w of walls) {
    const L = dist(w.a, w.b);
    if (L < 300) continue;
    const d = norm(sub(w.b, w.a));
    const n = [-d[1], d[0]];
    const half = w.thickness / 2;
    const stations = new Map();
    for (const s of strokes) {
      const len = dist(s.a, s.b);
      if (len > Math.max(200, w.thickness * 0.5) || Math.abs(dot(norm(sub(s.b, s.a)), n)) < 0.99) continue;
      const m = scale(add(s.a, s.b), 0.5);
      if (Math.abs(dot(sub(m, w.a), n)) > half) continue;
      const u = dot(sub(m, w.a), d);
      if (u < 0 || u > L) continue;
      const key = Math.round(u / 10) * 10;
      stations.set(key, (stations.get(key) || 0) + len);
    }
    const xs = [...stations].filter(([, v]) => v >= 0.35 * w.thickness).map(([k]) => k).sort((p, q) => p - q);
    for (let i = 0; i < xs.length; i++)
      for (let j = i + 1; j < xs.length; j++) {
        const at = add(w.a, scale(d, (xs[i] + xs[j]) / 2));
        const width = xs[j] - xs[i];
        // Only a window whose sill is written: that is why it is dashed, above the cut.
        if (!texts.some((t) => sillValue(t.text) != null && !used.has(t) && dist(textCentre(t), at) < 1200)) continue;
        for (const s of stacks) {
          const fit = (x) => Math.abs(x.v * 10 - width);
          const [wd, ht] = fit(s.a) <= fit(s.b) ? [s.a, s.b] : [s.b, s.a];
          const e = dist(s.c, at);
          if (fit(wd) <= 60 && ht.v * 10 >= 300 && e <= 1200) found.push({ e, s, at, width: wd.v * 10, height: ht.v * 10 });
        }
      }
  }
  // The nearest label first: each label makes one window.
  const out = [];
  for (const f of found.sort((p, q) => p.e - q.e)) {
    if (used.has(f.s.a.t) || used.has(f.s.b.t)) continue;
    used.add(f.s.a.t).add(f.s.b.t);
    out.push({ at: f.at, width: f.width, height: f.height, aboveCut: true });
  }
  return out;
}

/**
 * How a window's frames sit in its wall, from the lines drawn across its width inside the wall's thickness (three to an assembly: two rails and the glass).
 * { frameWidth, frameDepth, reveal, frameSide, boxWindow, sillBoard } or null. o: { at, width }, d and n the wall's axes, half its half thickness.
 */
export function windowFrames(o, d, n, half, strokes) {
  const rails = [];
  let beyond = 0;
  for (const s of strokes) {
    const L = dist(s.a, s.b);
    if (L < 0.6 * o.width || Math.abs(dot(sub(s.b, s.a), d)) / L < 0.99) continue;
    const m = scale(add(s.a, s.b), 0.5);
    if (Math.abs(dot(sub(m, o.at), d)) > 0.25 * o.width) continue;
    const e = dot(sub(m, o.at), n);
    if (Math.abs(e) > half + 90 && Math.abs(e) < half + 8) continue;
    if (Math.abs(e) > half + 8) {
      if (Math.abs(e) <= half + 90) beyond++;
      continue;
    }
    if (Math.abs(e) > half - 8) continue;
    const start = Math.min(Math.abs(dot(sub(s.a, o.at), d)), Math.abs(dot(sub(s.b, o.at), d)));
    if (!rails.some((r) => Math.abs(r.e - e) < 5)) rails.push({ e, end: Math.max(Math.abs(dot(sub(s.a, o.at), d)), Math.abs(dot(sub(s.b, o.at), d))), start });
  }
  if (rails.length < 2) return beyond ? null : { sillBoard: false };
  rails.sort((p, q) => p.e - q.e);
  const lo = rails[0].e;
  const hi = rails.at(-1).e;
  const centre = (lo + hi) / 2;
  // Toward the face the frames lie nearest; set in the middle, neither.
  const side = Math.abs(centre) > 0.1 * half ? Math.sign(centre) : 0;
  const out = { frameDepth: Math.round(hi - lo), reveal: Math.round(half - (side >= 0 ? hi : -lo)), sillBoard: beyond ? undefined : false };
  if (side) out.frameSide = [n[0] * side, n[1] * side];
  const inner = rails.reduce((v, r) => Math.max(v, r.end), 0);
  if (inner > 0 && inner < o.width / 2 - 5) out.frameWidth = Math.round(o.width / 2 - inner);
  // Two assemblies: a wide gap between two groups of lines.
  let gap = 0;
  for (let i = 1; i < rails.length; i++) gap = Math.max(gap, rails[i].e - rails[i - 1].e);
  if (rails.length >= 5 && gap > 45) out.boxWindow = true;
  return out;
}

/** The end of a leader starting by a text: the far end of a straight line touching the text's side, or null. */
export function leaderTarget(t, strokes) {
  const c = textCentre(t);
  const half = String(t.text).length * t.size * 0.27;
  const a = t.angle || 0;
  const d = [Math.cos(a), Math.sin(a)];
  let best = null;
  for (const s of strokes) {
    const L = dist(s.a, s.b);
    if (L < 300 || L > 4000) continue;
    for (const [near, far] of [[s.a, s.b], [s.b, s.a]]) {
      const v = sub(near, c);
      const along = Math.abs(dot(v, d));
      const across = Math.abs(dot(v, [-d[1], d[0]]));
      if (along < half - t.size || along > half + t.size * 1.5 || across > t.size) continue;
      // Pointing away from the text.
      if (dot(sub(far, near), sub(near, c)) <= 0) continue;
      // A leader leaves from the text's own line; a wall's face merely passes by.
      if (!best || across < best.across - 1 || (Math.abs(across - best.across) <= 1 && L < best.L)) best = { L, far, across };
    }
  }
  return best ? best.far : null;
}
