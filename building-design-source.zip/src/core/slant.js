/**
 * Slanted walls, as in Archicad: a wall leaning at an angle (slanted), or
 * with each face at its own angle (double slanted, wider or narrower at the
 * top). The upright wall is built as usual, then sheared: each point moves
 * across the wall by its height above the base times the tangent of the
 * angle of the face it is nearer to.
 *
 *   wall.slant: 'slanted' | 'double', slantOuter (deg), slantInner (deg); positive leans to the exterior
 */
import { wallAxis, verticalExtent } from './model.js';

/** The two face angles' tangents { tIn, tOut } of a slanted wall, or null for an upright one. */
export function slantOf(el) {
  if (!el?.slant || el.arc) return null;
  const clamp = (d) => Math.tan((Math.max(-75, Math.min(75, +d || 0)) * Math.PI) / 180);
  const tOut = clamp(el.slantOuter);
  const tIn = el.slant === 'double' ? clamp(el.slantInner) : tOut;
  return tIn || tOut ? { tIn, tOut } : null;
}

/** The function moving a point (x, y, z) of a wall to where the slant puts it. */
export function slantShear(doc, el) {
  const s = slantOf(el);
  if (!s) return null;
  const ax = wallAxis(doc, el);
  const { base } = verticalExtent(doc, el);
  const e = ax.ext;
  const half = Math.max(1e-6, ax.half);
  return (x, y, z) => {
    const across = (x - ax.a[0]) * e[0] + (y - ax.a[1]) * e[1];
    const f = Math.max(0, Math.min(1, (across + half) / (2 * half)));
    const d = (s.tIn * (1 - f) + s.tOut * f) * (z - base);
    return [x + e[0] * d, y + e[1] * d, z];
  };
}

/** A sheared copy of a mesh, with face normals and bounds recomputed. */
export function shearMesh(mesh, F) {
  const pos = new Float32Array(mesh.pos.length);
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < mesh.pos.length; i += 3) {
    const q = F(mesh.pos[i], mesh.pos[i + 1], mesh.pos[i + 2]);
    pos[i] = q[0];
    pos[i + 1] = q[1];
    pos[i + 2] = q[2];
    for (let k = 0; k < 3; k++) {
      if (q[k] < min[k]) min[k] = q[k];
      if (q[k] > max[k]) max[k] = q[k];
    }
  }
  const nrm = new Int8Array(mesh.nrm.length);
  for (let t = 0; t + 8 < pos.length; t += 9) {
    const u = [pos[t + 3] - pos[t], pos[t + 4] - pos[t + 1], pos[t + 5] - pos[t + 2]];
    const v = [pos[t + 6] - pos[t], pos[t + 7] - pos[t + 1], pos[t + 8] - pos[t + 2]];
    const n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    const l = Math.hypot(...n) || 1;
    for (let k = 0; k < 3; k++) for (let c = 0; c < 3; c++) nrm[t + k * 3 + c] = Math.round((n[c] / l) * 127);
  }
  const edges = new Float32Array(mesh.edges.length);
  for (let i = 0; i < mesh.edges.length; i += 3) {
    const q = F(mesh.edges[i], mesh.edges[i + 1], mesh.edges[i + 2]);
    edges[i] = q[0];
    edges[i + 1] = q[1];
    edges[i + 2] = q[2];
  }
  return { ...mesh, pos, nrm, edges, bounds: pos.length ? { min, max } : mesh.bounds };
}

/** Shear a wall's plan graphics to where its faces are at the cut height. */
export function shearPlan(b, F, z) {
  const P = (p) => F(p[0], p[1], z).slice(0, 2);
  for (const l of b.lines) {
    l.a = P(l.a);
    l.b = P(l.b);
  }
  for (const f of b.fills) {
    f.poly = f.poly.map(P);
    f.holes = (f.holes || []).map((hh) => hh.map(P));
  }
  b.picks = b.picks.map((poly) => poly.map(P));
  for (const t of b.texts) t.at = P(t.at);
}
