/**
 * Favorites, as in Archicad: named tool settings. A favorite keeps the
 * type and the instance parameters of an element (height, offsets, location
 * line, layer, structural flag, zone category...) but not where it is: no
 * geometry, host, level or identity. The top constraint is kept relative to
 * the element's level (the level above, or none), and a roof keeps one slope.
 *
 * favorite { kind: 'favorite', name, elementKind, typeId, params, topAbove, slope }
 */

/** Fields that place or identify an element, never kept. */
const SKIP = new Set([
  'id', 'kind', 'a', 'b', 'at', 'c', 'r', 'a0', 'a1', 'boundary', 'holes', 'path', 'points',
  'hostId', 't', 'groupId', 'viewId', 'levelId', 'topLevelId', 'tagAt', 'number', 'mark',
  'worksetId', 'optionId', 'phaseId', 'demolishedPhaseId', 'pinned', 'attachTopId',
  'joinA', 'joinB', 'joinStyleA', 'joinStyleB', 'flipped', 'rotation', 'slopes', 'overhangs',
  'curtainU', 'curtainV', 'typeId', 'wallId', 'stairId', 'targetId', 'paintId', 'zoneId',
]);

export function favoritesFor(doc, kind) {
  return doc
    .all('favorite')
    .filter((f) => f.elementKind === kind)
    .sort((x, y) => String(x.name).localeCompare(String(y.name), undefined, { numeric: true }));
}

/** A favorite made from an element's settings. */
export function favoriteFrom(doc, el, name) {
  const params = {};
  for (const [k, v] of Object.entries(el)) if (!SKIP.has(k) && v !== undefined) params[k] = v;
  const fav = { kind: 'favorite', name, elementKind: el.kind, typeId: el.typeId ?? null, params };
  if (el.topLevelId !== undefined) fav.topAbove = !!el.topLevelId && el.topLevelId === doc.levelAbove(el.levelId)?.id;
  if (Array.isArray(el.slopes)) fav.slope = el.slopes.find((s) => s != null) ?? null;
  return fav;
}

/** The patch a favorite makes to an element of its kind (on level levelId, with n boundary edges). */
export function favoritePatch(doc, fav, el) {
  const patch = { ...fav.params };
  if (fav.typeId && doc.has(fav.typeId)) patch.typeId = fav.typeId;
  if (fav.topAbove !== undefined) patch.topLevelId = fav.topAbove ? doc.levelAbove(el.levelId)?.id ?? null : null;
  if (fav.slope !== undefined && Array.isArray(el.boundary)) patch.slopes = el.boundary.map(() => fav.slope);
  return patch;
}
