/**
 * Elevate, as in Archicad's Pet palette: move elements up or down by a
 * distance through their own vertical offsets: the base offset (and the top
 * offset when the top is attached to a level), else the offset from the
 * level, else a window's sill.
 */
import { instanceParams, paramValue } from './props.js';

/** The patch that raises el by dz, or null when it has no vertical offset. */
export function elevatePatch(doc, el, dz) {
  // A frozen morph carries absolute heights in its triangles (morph.js).
  if (el.kind === 'morph' && Array.isArray(el.tris)) return { tris: el.tris.map((v, i) => (i % 3 === 2 ? v + dz : v)) };
  const params = new Map(instanceParams(el).filter((d) => d.type === 'length').map((d) => [d.key, d]));
  const ctx = { doc };
  const val = (k) => +paramValue(params.get(k), el, ctx) || 0;
  if (params.has('baseOffset')) {
    const patch = { baseOffset: val('baseOffset') + dz };
    if (params.has('topOffset') && el.topLevelId) patch.topOffset = val('topOffset') + dz;
    return patch;
  }
  if (params.has('offset')) return { offset: val('offset') + dz };
  if (params.has('sill')) return { sill: val('sill') + dz };
  return null;
}
