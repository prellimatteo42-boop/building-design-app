/**
 * Library developer tools, as Archicad's Library Developer menu: Place All
 * Objects, Test All Library Parts, Search Callers, Check for Missing
 * Attributes, XML export and import of library parts and placed objects,
 * and Import 3DS as GDL Object.
 */
import { runGdlType } from './gdlobject.js';
import { gdlFromMeshes } from './savegdl.js';

const gdlTypes = (doc) => doc.filter((t) => t.family === 'gdl' && t.gdl && /Type$/.test(t.kind));

/** Positions for every placeable library part on a grid: [{ typeId, at }] (mm), rows of `perRow`. */
export function placeAllPositions(doc, { gap = 600, perRow = 10, kinds = ['componentType'] } = {}) {
  const types = doc.filter((t) => kinds.includes(t.kind));
  const out = [];
  let x = 0;
  let y = 0;
  let rowDepth = 0;
  types.forEach((t, i) => {
    const w = +t.width || 1000;
    const d = +t.depth || 1000;
    if (i && i % perRow === 0) {
      x = 0;
      y -= rowDepth + gap;
      rowDepth = 0;
    }
    out.push({ typeId: t.id, at: [Math.round(x + w / 2), Math.round(y - d / 2)] });
    x += w + gap;
    rowDepth = Math.max(rowDepth, d);
  });
  return out;
}

/**
 * Test All Library Parts: run every GDL part; report [{ id, name, ok, triangles, lines, error, unknown }] where ok is
 * false on an error or when the part draws nothing.
 */
export function testLibraryParts(doc) {
  return gdlTypes(doc).map((t) => {
    let r;
    try {
      r = runGdlType(t);
    } catch (e) {
      r = { error: e.message, tris: [], lines: [] };
    }
    const tris = r.tris?.length || 0;
    const lines = (r.lines?.length || 0) + (r.polys?.length || 0);
    return { id: t.id, name: t.name, ok: !r.error && tris + lines > 0, triangles: tris, lines, error: r.error || null, unknown: r.unknown ? Object.keys(r.unknown) : [] };
  });
}

const scriptsOf = (t) => {
  const g = t.gdl || {};
  const own = [g.master, g.script3d, g.script2d, g.scriptParams, g.scriptUI].filter(Boolean).join('\n');
  const macros = Object.values(g.macros || {}).map((m) => [m.master, m.script3d, m.script2d].filter(Boolean).join('\n'));
  return [own, ...macros].join('\n');
};

/** Search Callers: the GDL parts whose scripts (or their macros) CALL a macro by name. */
export function searchCallers(doc, macro) {
  const name = String(macro).trim().toLowerCase();
  if (!name) return [];
  const re = /CALL\s+"([^"]+)"/gi;
  const out = [];
  for (const t of gdlTypes(doc)) {
    const s = scriptsOf(t);
    let m;
    let n = 0;
    re.lastIndex = 0;
    while ((m = re.exec(s))) if (m[1].toLowerCase() === name) n++;
    if (n) out.push({ id: t.id, name: t.name, calls: n });
  }
  return out;
}

/** Check for Missing Attributes: materials a GDL part names (MATERIAL "x", material parameters) that the project lacks. */
export function missingAttributes(doc) {
  const have = new Set(doc.all('material').flatMap((m) => [m.id, String(m.name || '').toLowerCase()]));
  const out = [];
  const re = /MATERIAL\s+"([^"]+)"/gi;
  for (const t of gdlTypes(doc)) {
    const names = new Set();
    const s = scriptsOf(t);
    let m;
    re.lastIndex = 0;
    while ((m = re.exec(s))) names.add(m[1]);
    for (const p of t.gdl.params || []) if (p.kind === 'material' && typeof p.value === 'string' && p.value) names.add(p.value);
    const missing = [...names].filter((n) => !have.has(n) && !have.has(n.toLowerCase()));
    if (missing.length) out.push({ id: t.id, name: t.name, missing });
  }
  return out;
}

// XML ---------------------------------------------------------------------------------------------------

const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const cdata = (s) => `<![CDATA[${String(s ?? '').replace(/]]>/g, ']]]]><![CDATA[>')}]]>`;

/** Library parts as XML (in the spirit of LP_XMLConverter: one Symbol per part, its parameters and scripts). */
export function libraryXML(doc, ids = null) {
  const parts = gdlTypes(doc).filter((t) => !ids || ids.includes(t.id));
  const body = parts.map((t) => {
    const g = t.gdl;
    const params = (g.params || []).map((p) => `      <Parameter name="${esc(p.name)}" kind="${esc(p.kind)}" label="${esc(p.label || p.name)}">${esc(JSON.stringify(p.value ?? null))}</Parameter>`).join('\n');
    return [
      `  <Symbol name="${esc(t.name)}" kind="${esc(t.kind)}" category="${esc(t.category || '')}" A="${t.width || 0}" B="${t.depth || 0}" ZZYZX="${t.height || 0}">`,
      `    <ParamSection>\n${params}\n    </ParamSection>`,
      g.master ? `    <Script_1D>${cdata(g.master)}</Script_1D>` : '',
      `    <Script_2D>${cdata(g.script2d)}</Script_2D>`,
      `    <Script_3D>${cdata(g.script3d)}</Script_3D>`,
      '  </Symbol>',
    ]
      .filter(Boolean)
      .join('\n');
  });
  return `<?xml version="1.0" encoding="UTF-8"?>\n<Library source="Building Design">\n${body.join('\n')}\n</Library>\n`;
}

/** Placed objects as XML: their library part by name, position, rotation, level and own parameter values. */
export function placedXML(doc, { levelId = null, ids = null } = {}) {
  const comps = doc.all('component').filter((c) => (!levelId || c.levelId === levelId) && (!ids || ids.includes(c.id)));
  const rows = comps.map((c) => {
    const t = doc.get(c.typeId);
    const lv = doc.get(c.levelId);
    const vals = c.gdlValues ? `\n    <Values>${esc(JSON.stringify(c.gdlValues))}</Values>\n  ` : '';
    return `  <Object part="${esc(t?.name || '')}" x="${Math.round(c.at[0])}" y="${Math.round(c.at[1])}" z="${Math.round(+c.offset || +c.elevation || 0)}" rotation="${+c.rotation || 0}" level="${esc(lv?.name || '')}">${vals}</Object>`;
  });
  return `<?xml version="1.0" encoding="UTF-8"?>\n<PlacedObjects source="Building Design" count="${comps.length}">\n${rows.join('\n')}\n</PlacedObjects>\n`;
}

const attr = (tag, name) => {
  const m = new RegExp(`\\b${name}="([^"]*)"`).exec(tag);
  return m ? m[1].replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&') : null;
};

/** Read placed objects back: [{ part, at, z, rotation, level, gdlValues }]. */
export function readPlacedXML(text) {
  const out = [];
  const re = /<Object\b([^>]*?)(\/>|>([\s\S]*?)<\/Object>)/g;
  let m;
  while ((m = re.exec(text))) {
    const tag = m[1];
    const inner = m[3] || '';
    const v = /<Values>([\s\S]*?)<\/Values>/.exec(inner);
    let gdlValues = null;
    try {
      gdlValues = v ? JSON.parse(v[1].replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')) : null;
    } catch {
      gdlValues = null;
    }
    out.push({ part: attr(tag, 'part'), at: [+attr(tag, 'x') || 0, +attr(tag, 'y') || 0], z: +attr(tag, 'z') || 0, rotation: +attr(tag, 'rotation') || 0, level: attr(tag, 'level'), gdlValues });
  }
  return out;
}

/** Components (not added) for read objects, matched to this project's types by name and levels by name. */
export function placeFromXML(doc, objs, fallbackLevelId) {
  const byName = new Map(doc.filter((t) => t.kind === 'componentType').map((t) => [t.name, t]));
  const levels = new Map(doc.levels().map((l) => [l.name, l.id]));
  const out = [];
  const missing = new Set();
  for (const o of objs) {
    const t = byName.get(o.part);
    if (!t) {
      missing.add(o.part);
      continue;
    }
    out.push({ kind: 'component', typeId: t.id, levelId: levels.get(o.level) || fallbackLevelId, at: o.at, rotation: o.rotation, offset: o.z, ...(o.gdlValues ? { gdlValues: o.gdlValues } : {}) });
  }
  return { components: out, missing: [...missing] };
}

// 3DS ----------------------------------------------------------------------------------------------------

/**
 * Read a 3D Studio (.3ds) file: [{ name, pos (triangles, Float32Array, mm), edges }]. Units: the file's (often
 * inches or metres; `scale` turns them into mm). Edges are the outline and creases (faces meeting at over 20°).
 */
export function read3DS(buffer, { scale = 1 } = {}) {
  const dv = new DataView(buffer instanceof ArrayBuffer ? buffer : buffer.buffer, buffer.byteOffset || 0, buffer.byteLength);
  const objects = [];
  const readName = (o) => {
    let s = '';
    let i = o;
    while (i < dv.byteLength && dv.getUint8(i) !== 0) s += String.fromCharCode(dv.getUint8(i++));
    return { s, next: i + 1 };
  };
  const walk = (start, end, cur) => {
    let o = start;
    while (o + 6 <= end) {
      const id = dv.getUint16(o, true);
      const len = dv.getUint32(o + 2, true);
      if (len < 6 || o + len > end) break;
      const body = o + 6;
      if (id === 0x4d4d || id === 0x3d3d) walk(body, o + len, cur);
      else if (id === 0x4000) {
        const { s, next } = readName(body);
        const obj = { name: s, verts: null, faces: null };
        walk(next, o + len, obj);
        if (obj.verts && obj.faces) objects.push(obj);
      } else if (id === 0x4100 && cur) walk(body, o + len, cur);
      else if (id === 0x4110 && cur) {
        const n = dv.getUint16(body, true);
        cur.verts = new Float32Array(n * 3);
        for (let i = 0; i < n * 3; i++) cur.verts[i] = dv.getFloat32(body + 2 + i * 4, true) * scale;
      } else if (id === 0x4120 && cur) {
        const n = dv.getUint16(body, true);
        cur.faces = new Uint16Array(n * 3);
        for (let i = 0; i < n; i++) for (let k = 0; k < 3; k++) cur.faces[i * 3 + k] = dv.getUint16(body + 2 + i * 8 + k * 2, true);
      }
      o += len;
    }
  };
  walk(0, dv.byteLength, null);
  return objects.map((obj) => meshOf(obj));
}

function meshOf({ name, verts: V, faces: F }) {
  const pos = new Float32Array(F.length * 3);
  const P = (i) => [V[i * 3], V[i * 3 + 1], V[i * 3 + 2]];
  const normals = [];
  for (let f = 0; f < F.length; f += 3) {
    const a = P(F[f]);
    const b = P(F[f + 1]);
    const c = P(F[f + 2]);
    pos.set([...a, ...b, ...c], f * 3);
    const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
    const v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    const n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    const l = Math.hypot(...n) || 1;
    normals.push(n.map((x) => x / l));
  }
  const edgeFaces = new Map();
  for (let f = 0; f < F.length; f += 3)
    for (const [i, j] of [
      [F[f], F[f + 1]],
      [F[f + 1], F[f + 2]],
      [F[f + 2], F[f]],
    ]) {
      const k = i < j ? `${i},${j}` : `${j},${i}`;
      if (!edgeFaces.has(k)) edgeFaces.set(k, []);
      edgeFaces.get(k).push(f / 3);
    }
  const edges = [];
  const cos20 = Math.cos((20 * Math.PI) / 180);
  for (const [k, fs] of edgeFaces) {
    const crease = fs.length !== 2 || normals[fs[0]].reduce((s, x, i) => s + x * normals[fs[1]][i], 0) < cos20;
    if (!crease) continue;
    const [i, j] = k.split(',').map(Number);
    edges.push(...P(i), ...P(j));
  }
  return { name, pos, edges: new Float32Array(edges) };
}

/** A GDL object type (not added) from a 3DS file's meshes. */
export function gdlFrom3DS(meshes, name, materialId = 'mat-default') {
  const g = gdlFromMeshes(meshes.map((m) => ({ mesh: m, materialId })));
  if (!g) return null;
  return { kind: 'componentType', family: 'gdl', familyName: 'GDL Object (3DS)', category: 'genericModels', name, width: g.width, depth: g.depth, height: g.height, gdl: { params: [], script3d: g.script3d, script2d: g.script2d } };
}
