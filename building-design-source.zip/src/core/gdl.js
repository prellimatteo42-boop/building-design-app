/**
 * GDL, the language of Archicad's library parts, enough of it for objects
 * written by hand or by the assistant: a 3D script and a 2D script over
 * parameters, run with the object's size (A, B, ZZYZX) in metres as GDL
 * has it. The run is bounded (statements and triangles), so a script that
 * loops for ever stops with an error instead.
 *
 * Statements: assignment (with LET), DIM, IF/THEN/ELSE/ENDIF (and one-line
 * IF), FOR/NEXT, WHILE/ENDWHILE, REPEAT/UNTIL, GOSUB/RETURN, GOTO, END.
 * Numbered or named labels end with a colon.
 * 3D: ADD, ADDX/Y/Z, ROTX/Y/Z, MUL, MULX/Y/Z, DEL, DEL TOP, MATERIAL,
 * BLOCK, BRICK, CYLIND, ELLIPS, SPHERE, CONE, PRISM, PRISM_, CPRISM_,
 * SLAB_, REVOLVE, RECT, LIN_, HOTSPOT.
 * 2D: ADD2, ROT2, MUL2, DEL, PEN, LINE2, RECT2, POLY2, POLY2_, CIRCLE2,
 * ARC2, TEXT2, HOTSPOT2, PROJECT2 (the 3D seen from above).
 * Polygon point status codes: 900 sets an arc centre, 3000 an arc to the
 * point about it, 4000 an arc by the angle given as y.
 */

// Lexer ---------------------------------------------------------------------------------------

import earcut from 'earcut';
import { PolyOps } from './polyops.js';
import { textSolid, textAdvance } from './text3d.js';

const KEYWORDS = new Set(['IF', 'THEN', 'ELSE', 'ENDIF', 'FOR', 'TO', 'STEP', 'NEXT', 'WHILE', 'DO', 'ENDWHILE', 'REPEAT', 'UNTIL', 'GOSUB', 'GOTO', 'RETURN', 'END', 'EXIT', 'LET', 'DIM', 'AND', 'OR', 'EXOR', 'NOT', 'MOD']);

export function lex(src, { lenient = false } = {}) {
  const out = [];
  let i = 0;
  let line = 1;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    if (c === '\n') {
      // A line ending in a comma goes on: argument lists span lines.
      const last = out.at(-1);
      if (!(last && last.t === 'op' && last.v === ',')) out.push({ t: 'nl', line });
      line++;
      i++;
      continue;
    }
    if (c === ' ' || c === '\t' || c === '\r' || c === '\u3000' || c === '\u00a0') {
      i++;
      continue;
    }
    // A backslash ending a line carries the statement on to the next one with something on it (Archicad's
    // scripts leave blank and comment lines inside a long condition).
    if (c === '\\' && /^\\[ \t]*(![^\n]*)?\r?\n/.test(src.slice(i, i + 200))) {
      while (i < n && src[i] !== '\n') i++;
      i++;
      line++;
      for (let m; (m = /^[ \t\r]*(![^\n]*)?\n/.exec(src.slice(i, i + 400))); ) {
        i += m[0].length;
        line++;
      }
      continue;
    }
    if (c === '!') {
      while (i < n && src[i] !== '\n') i++;
      continue;
    }
    if ((c >= '0' && c <= '9') || (c === '.' && /[0-9]/.test(src[i + 1] || ''))) {
      const m = /^(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?/.exec(src.slice(i));
      // Imperial lengths: a number marked " is in inches, ' in feet; a fraction so marked (7/8") is one length.
      const unit = src[i + m[0].length];
      const scale = unit === '"' ? 0.0254 : unit === "'" ? 0.3048 : 1;
      let v = parseFloat(m[0]);
      const [num, slash] = [out.at(-2), out.at(-1)];
      if (scale !== 1 && slash?.t === 'op' && slash.v === '/' && num?.t === 'num' && !num.unit) {
        out.length -= 2;
        v = num.v / v;
        // A whole number before it (1 1/4"): one mixed length.
        const whole = out.at(-1);
        if (whole?.t === 'num' && !whole.unit && whole.line === line && /^[ \t]$/.test(src[i - String(num.v).length - 2] ?? '')) {
          out.length -= 1;
          v += whole.v;
        }
      }
      // Feet and inches together (5'10"): one length.
      const inch = unit === "'" ? /^(\d+(?:\.\d+)?)"/.exec(src.slice(i + m[0].length + 1, i + m[0].length + 20)) : null;
      if (inch) {
        out.push({ t: 'num', v: v * 0.3048 + parseFloat(inch[1]) * 0.0254, unit: true, line });
        i += m[0].length + 1 + inch[0].length;
        continue;
      }
      out.push(scale !== 1 ? { t: 'num', v: v * scale, unit: true, line } : { t: 'num', v, line });
      i += m[0].length + (scale !== 1 ? 1 : 0);
      continue;
    }
    if (c === '"' || c === "'" || c === '`' || c === '´' || c === '”' || c === '“') {
      // Typographic quotes too (´…´, “…” or ”…”), as some scripts were typed.
      const end = src.indexOf(c === '“' ? '”' : c, i + 1);
      const j = end < 0 ? n : end;
      out.push({ t: 'str', v: src.slice(i + 1, j), line });
      i = j + 1;
      continue;
    }
    if (/[A-Za-z_~]/.test(c)) {
      // Names, with a command's version (POLY2_B{2}); a dictionary's fields come as '.' and a name.
      const m = /^[A-Za-z_~][A-Za-z0-9_~]*(\{\d+\})?/.exec(src.slice(i, i + 256));
      const up = m[0].toUpperCase();
      // Right after a '.', a word is a dictionary's field even when it is a keyword (_point.end).
      const field = src[i - 1] === '.' && out.at(-1)?.v === '.';
      out.push(KEYWORDS.has(up) && !field ? { t: 'kw', v: up, line } : { t: 'id', v: up, raw: m[0], line });
      i += m[0].length;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (['<>', '<=', '>=', '**'].includes(two)) {
      out.push({ t: 'op', v: two === '**' ? '^' : two, line });
      i += 2;
      continue;
    }
    if ('+-*/^%=<>#&|@(),:[]{}.'.includes(c)) {
      out.push({ t: 'op', v: c, line });
      i++;
      continue;
    }
    if (lenient) {
      i++;
      continue;
    }
    throw new GdlError(`Unexpected character "${c}"`, line);
  }
  out.push({ t: 'nl', line });
  out.push({ t: 'eof', line });
  return out;
}

/** Messages of running scripts (PRINT and errors), for the GDL Messages window; collected only when on. */
export const gdlMessages = {
  on: false,
  list: [],
  subs: new Set(),
  push(text, line = null) {
    if (!this.on) return;
    this.list.push({ text: String(text), line });
    if (this.list.length > 500) this.list.shift();
    for (const f of this.subs) f();
  },
  clear() {
    this.list.length = 0;
  },
  subscribe(f) {
    this.subs.add(f);
    return () => this.subs.delete(f);
  },
};

export class GdlError extends Error {
  constructor(msg, line) {
    super(line ? `Line ${line}: ${msg}` : msg);
    this.line = line;
    gdlMessages.push(msg, line);
  }
}

// Parser --------------------------------------------------------------------------------------

/**
 * Parse into a flat list of statements; blocks are resolved to jumps so
 * GOTO, GOSUB and structured statements share one program counter.
 */
export function parse(src, { lenient = false } = {}) {
  const toks = lex(src, { lenient });
  let p = 0;
  const peek = () => toks[p];
  const next = () => toks[p++];
  const isOp = (v) => peek().t === 'op' && peek().v === v;
  const isKw = (v) => peek().t === 'kw' && peek().v === v;
  const expectOp = (v) => {
    if (!isOp(v)) throw new GdlError(`Expected "${v}"`, peek().line);
    next();
  };
  const prog = [];
  const labels = new Map();
  const blocks = [];

  // Expressions, by precedence (lowest first): OR/EXOR, AND, comparison, + -, * / MOD, ^, unary.
  const expr = () => orExpr();
  const orExpr = () => {
    let l = andExpr();
    for (;;) {
      if (isKw('OR') || isOp('|')) (next(), (l = { op: 'or', l, r: andExpr() }));
      else if (isKw('EXOR') || isOp('@')) (next(), (l = { op: 'xor', l, r: andExpr() }));
      else return l;
    }
  };
  const andExpr = () => {
    let l = cmpExpr();
    while (isKw('AND') || isOp('&')) (next(), (l = { op: 'and', l, r: cmpExpr() }));
    return l;
  };
  const cmpExpr = () => {
    let l = addExpr();
    for (;;) {
      const t = peek();
      if (t.t === 'op' && ['=', '<>', '#', '<', '>', '<=', '>='].includes(t.v)) {
        next();
        l = { op: t.v === '#' ? '<>' : t.v, l, r: addExpr() };
      } else return l;
    }
  };
  const addExpr = () => {
    let l = mulExpr();
    for (;;) {
      if (isOp('+') || isOp('-')) {
        const o = next().v;
        l = { op: o, l, r: mulExpr() };
      } else return l;
    }
  };
  const mulExpr = () => {
    let l = powExpr();
    for (;;) {
      if (isOp('*') || isOp('/') || isOp('%') || isKw('MOD')) {
        const o = next().v;
        l = { op: o === '%' || o === 'MOD' ? 'mod' : o, l, r: powExpr() };
      } else return l;
    }
  };
  const powExpr = () => {
    const l = unary();
    if (isOp('^')) {
      next();
      return { op: '^', l, r: powExpr() };
    }
    return l;
  };
  const unary = () => {
    if (isOp('-')) return next(), { op: 'neg', l: unary() };
    if (isOp('+')) return next(), unary();
    if (isKw('NOT')) return next(), { op: 'not', l: unary() };
    return atom();
  };
  const atom = () => {
    const t = next();
    if (t.t === 'num') return { num: t.v };
    if (t.t === 'str') return { str: t.v };
    if (t.t === 'op' && t.v === '(') {
      const e = expr();
      expectOp(')');
      return e;
    }
    if (t.t === 'id') {
      if (isOp('(')) {
        next();
        const args = [];
        if (!isOp(')')) {
          args.push(expr());
          while (isOp(',')) (next(), args.push(expr()));
        }
        expectOp(')');
        return { call: t.v, args, line: t.line };
      }
      const path = accessors();
      return path.length ? { name: t.v, path } : { name: t.v };
    }
    throw new GdlError(`Unexpected ${t.t === 'eof' ? 'end of script' : `"${t.v ?? t.t}"`}`, t.line);
  };
  // After a name: fields (.key) and indices ([i] or [i, j]) in any order.
  const accessors = () => {
    const path = [];
    for (;;) {
      if (isOp('.') && toks[p + 1]?.t === 'id') {
        next();
        path.push({ field: next().v });
      } else if (isOp('[')) {
        next();
        path.push({ index: expr() });
        while (isOp(',')) (next(), path.push({ index: expr() }));
        expectOp(']');
      } else return path;
    }
  };
  const argList = () => {
    const args = [];
    if (peek().t === 'nl' || isOp(':') || isKw('ELSE') || peek().t === 'eof') return args;
    // DEL TOP and similar: a bare keyword-like word.
    args.push(expr());
    while (isOp(',')) (next(), args.push(expr()));
    return args;
  };
  const endStmt = () => {
    while (isOp(':')) next();
  };

  const statement = () => {
    const t = peek();
    if (t.t === 'nl') return void next();
    if (isOp(':')) return void next();
    // Labels: "10:" or "name": at a statement's start, name: alone on its line.
    if (toks[p + 1]?.t === 'op' && toks[p + 1].v === ':' && (t.t === 'num' || t.t === 'str' || (t.t === 'id' && ['nl', 'eof'].includes(toks[p + 2]?.t)))) {
      next();
      next();
      labels.set(t.t === 'num' ? String(t.v) : String(t.v).toUpperCase(), prog.length);
      return;
    }
    if (t.t === 'kw') {
      next();
      switch (t.v) {
        case 'LET':
          return statement();
        case 'DIM': {
          // DIM a[n], b[n][m], and a size left out for an array that grows: c[], d[][].
          do {
            const nm = next();
            const sizes = [];
            while (isOp('[')) {
              next();
              sizes.push(isOp(']') ? null : expr());
              expectOp(']');
            }
            if (!sizes.length) throw new GdlError('Expected [', nm.line);
            prog.push({ k: 'dim', name: nm.v, sizes, line: t.line });
          } while (isOp(',') && next());
          return;
        }
        case 'IF': {
          const cond = expr();
          if (!isKw('THEN') && !isKw('GOTO') && !isKw('GOSUB')) throw new GdlError('Expected THEN', t.line);
          if (isKw('GOTO')) {
            next();
            prog.push({ k: 'ifgoto', cond, target: target(), line: t.line });
            return;
          }
          if (isKw('GOSUB')) {
            // IF cond GOSUB label: a one-line IF.
            next();
            const jf = { k: 'jf', cond, to: -1, line: t.line };
            prog.push(jf);
            prog.push({ k: 'gosub', target: target(), line: t.line });
            jf.to = prog.length;
            return;
          }
          next();
          // THEN: (a colon after THEN) opens a block IF written on one line, to its ENDIF.
          const colon = peek().t === 'op' && peek().v === ':';
          if (colon) next();
          if (colon || peek().t === 'nl') {
            // A block IF.
            const jf = { k: 'jf', cond, to: -1, line: t.line };
            prog.push(jf);
            blocks.push({ type: 'if', jf, jumps: [] });
            return;
          }
          // One-line IF: THEN statement or THEN label.
          if (peek().t === 'num' && (toks[p + 1].t === 'nl' || toks[p + 1].t === 'eof')) {
            prog.push({ k: 'ifgoto', cond, target: target(), line: t.line });
            return;
          }
          const jf = { k: 'jf', cond, to: -1, line: t.line };
          prog.push(jf);
          inline();
          if (isKw('ELSE')) {
            next();
            const jmp = { k: 'jmp', to: -1 };
            prog.push(jmp);
            jf.to = prog.length;
            inline();
            jmp.to = prog.length;
          } else jf.to = prog.length;
          return;
        }
        case 'ELSE': {
          const b = blocks.at(-1);
          if (!b || b.type !== 'if') throw new GdlError('ELSE without IF', t.line);
          const jmp = { k: 'jmp', to: -1 };
          prog.push(jmp);
          b.jumps.push(jmp);
          b.jf.to = prog.length;
          b.jf = null;
          // ELSE IF ... THEN on one line chains another block.
          if (isKw('IF')) {
            next();
            const cond = expr();
            if (!isKw('THEN')) throw new GdlError('Expected THEN', t.line);
            next();
            const jf = { k: 'jf', cond, to: -1, line: t.line };
            prog.push(jf);
            b.jf = jf;
          }
          return;
        }
        case 'ENDIF': {
          const b = blocks.pop();
          if (!b || b.type !== 'if') throw new GdlError('ENDIF without IF', t.line);
          if (b.jf) b.jf.to = prog.length;
          for (const j of b.jumps) j.to = prog.length;
          return;
        }
        case 'FOR': {
          const v = next();
          if (v.t !== 'id') throw new GdlError('Expected a variable after FOR', t.line);
          expectOp('=');
          const from = expr();
          if (!isKw('TO')) throw new GdlError('Expected TO', t.line);
          next();
          const to = expr();
          let step = { num: 1 };
          if (isKw('STEP')) (next(), (step = expr()));
          prog.push({ k: 'set', name: v.v, e: from, line: t.line });
          const test = { k: 'fortest', name: v.v, to, step, exit: -1, line: t.line };
          // The end and the step are worked out once, as the loop starts (a body that GETs from the
          // buffer must not shorten a loop to NSP / 4).
          prog.push({ k: 'forinit', test });
          const top = prog.length;
          prog.push(test);
          blocks.push({ type: 'for', name: v.v, test, top, step });
          return;
        }
        case 'NEXT': {
          if (peek().t === 'id') next();
          const b = blocks.pop();
          if (!b || b.type !== 'for') throw new GdlError('NEXT without FOR', t.line);
          prog.push({ k: 'forstep', name: b.name, step: b.step, test: b.test });
          prog.push({ k: 'jmp', to: b.top });
          b.test.exit = prog.length;
          return;
        }
        case 'DO':
          blocks.push({ type: 'do', top: prog.length });
          return;
        case 'WHILE': {
          // DO ... WHILE cond: the loop's end.
          if (blocks.at(-1)?.type === 'do') {
            const b = blocks.pop();
            prog.push({ k: 'jt', cond: expr(), to: b.top, line: t.line });
            return;
          }
          const cond = expr();
          if (isKw('DO')) next();
          const top = prog.length;
          const jf = { k: 'jf', cond, to: -1, line: t.line };
          prog.push(jf);
          blocks.push({ type: 'while', top, jf });
          return;
        }
        case 'ENDWHILE': {
          const b = blocks.pop();
          if (!b || b.type !== 'while') throw new GdlError('ENDWHILE without WHILE', t.line);
          prog.push({ k: 'jmp', to: b.top });
          b.jf.to = prog.length;
          return;
        }
        case 'REPEAT':
          blocks.push({ type: 'repeat', top: prog.length });
          return;
        case 'UNTIL': {
          const b = blocks.pop();
          if (!b || b.type !== 'repeat') throw new GdlError('UNTIL without REPEAT', t.line);
          prog.push({ k: 'jf', cond: expr(), to: b.top, until: true, line: t.line });
          return;
        }
        case 'GOSUB':
          prog.push({ k: 'gosub', target: target(), line: t.line });
          return;
        case 'GOTO':
          prog.push({ k: 'goto', target: target(), line: t.line });
          return;
        case 'RETURN':
          prog.push({ k: 'return', line: t.line });
          return;
        case 'END':
        case 'EXIT':
          // A macro's END gives its values back to RETURNED_PARAMETERS.
          prog.push({ k: 'end', args: argList() });
          return;
        default:
          throw new GdlError(`Unexpected ${t.v}`, t.line);
      }
    }
    simple();
  };
  // A statement after THEN or ELSE on the same line.
  const inline = () => {
    if (peek().t === 'kw' && ['GOSUB', 'GOTO', 'RETURN', 'END', 'EXIT', 'LET'].includes(peek().v)) return statement();
    simple();
  };
  const labelOf = (tok) => {
    if (tok.t === 'num') return String(tok.v);
    if (tok.t === 'str') return String(tok.v).toUpperCase();
    throw new GdlError('Expected a label', tok.line);
  };
  // A jump's label: a number or a string, or an expression that gives one (GOSUB iStyle, GOSUB 100 + iLegType).
  const target = () => {
    const t = peek();
    const nx = toks[p + 1];
    if ((t.t === 'num' || t.t === 'str') && (!nx || nx.t === 'nl' || nx.t === 'eof' || (nx.t === 'kw' && nx.v === 'ELSE') || (nx.t === 'op' && nx.v === ':'))) return labelOf(next());
    if (t.t !== 'id' && t.t !== 'num' && t.t !== 'str' && !(t.t === 'op' && (t.v === '(' || t.v === '-'))) return labelOf(next());
    return { e: expr() };
  };
  // An assignment or a command with its arguments.
  const simple = () => {
    const t = next();
    if (t.t !== 'id') throw new GdlError(`Unexpected "${t.v ?? t.t}"`, t.line);
    const word = (w) => peek().t === 'id' && peek().v === w;
    if (/^PROJECT2/.test(t.v)) {
      // PROJECT2{3} ..., PARAMETERS name = value, ...: the 3D drawn from above, with values of its own
      // (taken as the object's: the projection is of its 3D as it stands).
      const args = [];
      while (peek().t !== 'nl' && peek().t !== 'eof' && !word('PARAMETERS')) {
        args.push(expr());
        if (isOp(',')) next();
        else break;
      }
      if (word('PARAMETERS')) {
        next();
        while (peek().t === 'id' && toks[p + 1]?.t === 'op' && toks[p + 1].v === '=') {
          next();
          next();
          expr();
          if (isOp(',')) next();
        }
      }
      prog.push({ k: 'cmd', name: t.v, args, line: t.line });
      return endStmt();
    }
    if (t.v === 'PARAGRAPH' || t.v === 'TEXTBLOCK') {
      // PARAGRAPH name alignment, indents, spacing...; then its lines (PEN, [SET] STYLE, strings) to ENDPARAGRAPH.
      // TEXTBLOCK name width, anchor, angle, width factor, spacing factor, fixed height, paragraph names...
      const name = expr();
      if (isOp(',')) next();
      prog.push({ k: 'cmd', name: t.v, args: [name, ...(peek().t === 'nl' || peek().t === 'eof' ? [] : argList())], line: t.line });
      if (t.v === 'TEXTBLOCK') return endStmt();
      endStmt();
      for (;;) {
        while (peek().t === 'nl') next();
        if (peek().t === 'eof') return;
        if (word('ENDPARAGRAPH')) {
          next();
          prog.push({ k: 'cmd', name: 'ENDPARAGRAPH', args: [], line: peek().line });
          return endStmt();
        }
        if (['PEN', 'SET', 'STYLE', 'MATERIAL'].some(word)) {
          simple();
          continue;
        }
        prog.push({ k: 'cmd', name: 'PARATEXT', args: argList(), line: peek().line });
        endStmt();
      }
    }
    if (t.v === 'CALL') {
      // CALL "macro" [PARAMETERS [ALL] [name = value, ...]] [RETURNED_PARAMETERS a, b, ...], or CALL "macro", v1, v2...
      const name = expr();
      const st = { k: 'call', name, all: false, assigns: [], positional: [], returned: [], line: t.line };
      // CALL "macro", PARAMETERS ...: a comma may come before the keyword.
      if (isOp(',') && toks[p + 1]?.t === 'id' && ['PARAMETERS', 'RETURNED_PARAMETERS'].includes(toks[p + 1].v)) next();
      if (word('PARAMETERS')) {
        next();
        if (word('ALL')) (next(), (st.all = true));
        if (isOp(',')) next();
        while (peek().t === 'id' && peek().v !== 'RETURNED_PARAMETERS' && toks[p + 1]?.t === 'op' && toks[p + 1].v === '=') {
          const nm = next().v;
          next();
          st.assigns.push({ name: nm, e: expr() });
          if (isOp(',')) next();
        }
      } else if (isOp(',')) {
        next();
        st.positional.push(expr());
        while (isOp(',')) (next(), st.positional.push(expr()));
      }
      if (word('RETURNED_PARAMETERS')) {
        next();
        while (peek().t === 'id') {
          st.returned.push(atom());
          if (isOp(',')) next();
          else break;
        }
      }
      prog.push(st);
    } else if (t.v === 'DICT') {
      const names = [];
      while (peek().t === 'id') {
        names.push(next().v);
        if (isOp(',')) next();
        else break;
      }
      prog.push({ k: 'dict', names, line: t.line });
    } else if (t.v === 'PARAMETERS') {
      // The parameter script sets parameters: PARAMETERS a = 1, b = 2.
      const assigns = [];
      while (peek().t === 'id' && toks[p + 1]?.t === 'op' && toks[p + 1].v === '=') {
        const nm = next().v;
        next();
        assigns.push({ name: nm, e: expr() });
        if (isOp(',')) next();
      }
      for (const a of assigns) prog.push({ k: 'set', name: a.name, e: a.e, line: t.line });
    } else if (isOp('=')) {
      next();
      prog.push({ k: 'set', name: t.v, e: expr(), line: t.line });
    } else if (isOp('[') || (isOp('.') && toks[p + 1]?.t === 'id')) {
      const path = accessors();
      expectOp('=');
      prog.push({ k: 'set', name: t.v, path, e: expr(), line: t.line });
    } else {
      // VALUES "name" [,] value, ...: the name may come without a comma; RANGE [a, b] STEP c and CUSTOM kept as words.
      if (t.v === 'VALUES' && peek().t !== 'nl' && peek().t !== 'eof') {
        const args = [expr()];
        if (isOp(',')) next();
        const stop = () => peek().t === 'nl' || peek().t === 'eof' || isOp(':');
        while (!stop()) {
          if (peek().t === 'id' && (peek().v === 'RANGE' || peek().v === 'CUSTOM')) {
            const w = next().v;
            args.push({ str: `\u0000${w}` });
            // A range's bounds and step: skipped up to the next comma outside brackets.
            let depth = 0;
            while (!stop() && !(depth === 0 && isOp(','))) {
              const x = next();
              if (x.t === 'op' && (x.v === '[' || x.v === '(')) depth++;
              if (x.t === 'op' && (x.v === ']' || x.v === ')')) depth--;
            }
          } else args.push(expr());
          if (isOp(',')) next();
          else break;
        }
        prog.push({ k: 'cmd', name: 'VALUES', args, line: t.line });
        while (!stop()) next();
        endStmt();
        return;
      }
      // SET MATERIAL x, SET FILL x...: the word belongs to the command.
      if ((t.v === 'SET' || t.v === 'DEFINE') && peek().t === 'id') {
        const w = next().v;
        let args = [];
        if (t.v === 'SET') args = argList();
        else if (w === 'TEXTURE' || w === 'MATERIAL' || /^STYLE/.test(w)) {
          // DEFINE TEXTURE / MATERIAL: the values up to ADDITIONAL_DATA (renderer settings, left out).
          const stop = () => peek().t === 'nl' || peek().t === 'eof' || (peek().t === 'id' && peek().v === 'ADDITIONAL_DATA');
          // The name comes without a comma after it: DEFINE TEXTURE "name" picture, width, ...
          if (!stop()) {
            args.push(expr());
            if (isOp(',')) next();
            if (!stop()) args.push(expr());
            while (isOp(',') && (next(), !stop())) args.push(expr());
          }
        }
        prog.push({ k: 'cmd', name: `${t.v} ${/^STYLE/.test(w) ? 'STYLE' : w}`, args, line: t.line });
        if (t.v === 'DEFINE') while (peek().t !== 'nl' && peek().t !== 'eof') next();
        endStmt();
        return;
      }
      // DEL TOP: a word argument.
      if (t.v === 'DEL' && peek().t === 'id' && peek().v === 'TOP') {
        next();
        prog.push({ k: 'cmd', name: 'DEL', args: [{ str: 'TOP' }], line: t.line });
      } else prog.push({ k: 'cmd', name: t.v, args: argList(), line: t.line });
    }
    endStmt();
  };
  const skipped = [];
  while (peek().t !== 'eof') {
    if (!lenient) {
      statement();
      continue;
    }
    // Lenient: a statement this reader does not follow is left out, with the rest of its line, and
    // whatever of it went into the program already (a jump to its first number only would end the script).
    const at = p;
    const plen = prog.length;
    const blen = blocks.length;
    try {
      statement();
    } catch (err) {
      skipped.push(err.message);
      prog.length = plen;
      if (blocks.length > blen) blocks.length = blen;
      p = Math.max(p, at + 1);
      while (peek().t !== 'nl' && peek().t !== 'eof') next();
    }
  }
  if (blocks.length && !lenient) throw new GdlError(`${blocks.at(-1).type.toUpperCase()} is not closed`, toks.at(-1).line);
  // Lenient: blocks left open end at the script's end.
  for (const b of blocks) {
    if (b.jf) b.jf.to = prog.length;
    for (const j of b.jumps || []) j.to = prog.length;
    if (b.test) b.test.exit = prog.length;
  }
  return { prog, labels, skipped };
}

// Evaluation ----------------------------------------------------------------------------------

const D2R = Math.PI / 180;
const FUNCS = {
  SIN: (x) => Math.sin(x * D2R),
  COS: (x) => Math.cos(x * D2R),
  TAN: (x) => Math.tan(x * D2R),
  ATN: (x) => Math.atan(x) / D2R,
  ACS: (x) => Math.acos(x) / D2R,
  ASN: (x) => Math.asin(x) / D2R,
  SQR: (x) => Math.sqrt(x),
  ABS: (x) => Math.abs(x),
  INT: (x) => Math.floor(x),
  FRA: (x) => x - Math.floor(x),
  ROUND_INT: (x) => Math.round(x),
  CEIL: (x) => Math.ceil(x),
  SGN: (x) => Math.sign(x),
  EXP: (x) => Math.exp(x),
  LOG: (x) => Math.log10(x),
  MIN: (...a) => Math.min(...a),
  MAX: (...a) => Math.max(...a),
  NOT: (x) => (x ? 0 : 1),
  STR: (x, w, d) => (typeof x === 'string' ? x : Number(x).toFixed(d == null ? 2 : Math.max(0, d))),
  STRLEN: (s) => String(s).length,
  STRSUB: (s, a, n) => String(s).substr(Math.max(0, a - 1), n),
  STRSTR: (s, t) => String(s).indexOf(String(t)) + 1,
  'STR{2}': (x, w, d) => (typeof x === 'string' ? x : Number(x).toFixed(d == null ? 2 : Math.max(0, Math.round(d)))),
  STW: (s) => String(s).length * 0.6,
  // Localised text: the text itself.
  _: (s) => s,
  VARDIM1: (a) => (Array.isArray(a) ? Math.max(0, a.length - 1) : 0),
  VARDIM2: (a) => (Array.isArray(a) && Array.isArray(a[1]) ? Math.max(0, a[1].length - 1) : 0),
  VARTYPE: (x) => (typeof x === 'string' ? 2 : 1),
  BITTEST: (x, b) => ((Math.round(x) >> Math.round(b)) & 1),
  BITSET: (x, b, v = 1) => (v ? Math.round(x) | (1 << Math.round(b)) : Math.round(x) & ~(1 << Math.round(b))),
  LIBRARYGLOBAL: () => 0,
  REQUEST: () => 0,
  APPLICATION_QUERY: () => 0,
  SPLIT: () => 0,
  REQ: () => 0,
};

/**
 * This app's model view options, over the defaults stored in Archicad's
 * library global settings objects (read by LIBRARYGLOBAL). The stored
 * defaults draw doors, windows and skylights schematically in 3D (a flat
 * panel); a project's model view combination asks for full detail, as here.
 */
export const MODEL_VIEW_OPTIONS = {
  DW_MVOSETTINGS: { IDOOR3DDETLEVEL: 3, IWINDOW3DDETLEVEL: 3 },
  DWS_MVOSETTINGS_USA: { IDOOR3DDETLEVEL: 3, IWINDOW3DDETLEVEL: 3 },
  SKYLIGHT_MVOSETTINGS: { IDETLEVEL3D: 3 },
};

// RND: the same pseudo-random sequence every run, so an object looks the same each time.
let seed = 1;
FUNCS.RND = (x = 1) => {
  seed = (seed * 1103515245 + 12345) & 0x7fffffff;
  return (seed / 0x7fffffff) * x;
};

/** Texture coordinates projecting a triangle onto the coordinate plane it faces most. */
function boxUV(pts, tex) {
  const [a, b, c] = pts;
  const n = [(b[1] - a[1]) * (c[2] - a[2]) - (b[2] - a[2]) * (c[1] - a[1]), (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2]), (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])].map(Math.abs);
  const [i, j] = n[2] >= n[0] && n[2] >= n[1] ? [0, 1] : n[1] >= n[0] ? [0, 2] : [1, 2];
  return pts.map((p) => [p[i] / tex.w, p[j] / tex.h]);
}

/** Texture coordinates in a polygon's own texture system: origin and points on its x, y and z axes, placed. */
function frameUV(pts, [o, px, py, pz], tex) {
  const ax = [px, py, pz].map((q) => [q[0] - o[0], q[1] - o[1], q[2] - o[2]]);
  const [e1, e2, e3] = ax;
  const det = e1[0] * (e2[1] * e3[2] - e2[2] * e3[1]) - e2[0] * (e1[1] * e3[2] - e1[2] * e3[1]) + e3[0] * (e1[1] * e2[2] - e1[2] * e2[1]);
  if (Math.abs(det) < 1e-12) return null;
  // Solve p - o = u e1 + v e2 + w e3 for u and v (Cramer's rule).
  return pts.map((p) => {
    const d = [p[0] - o[0], p[1] - o[1], p[2] - o[2]];
    const u = (d[0] * (e2[1] * e3[2] - e2[2] * e3[1]) - e2[0] * (d[1] * e3[2] - d[2] * e3[1]) + e3[0] * (d[1] * e2[2] - d[2] * e2[1])) / det;
    const v = (e1[0] * (d[1] * e3[2] - d[2] * e3[1]) - d[0] * (e1[1] * e3[2] - e1[2] * e3[1]) + e3[0] * (e1[1] * d[2] - e1[2] * d[1])) / det;
    return [u / tex.w, v / tex.h];
  });
}

function copyValue(v) {
  return v && typeof v === 'object' && !v.spread ? structuredClone(v) : v;
}

function truthy(v) {
  return typeof v === 'string' ? v !== '' : !!v && Math.abs(v) > 1e-12;
}

const parsed = new Map();
function parseCached(src, lenient) {
  const key = (lenient ? 'L' : 'S') + src;
  let r = parsed.get(key);
  if (!r) {
    r = parse(src, { lenient });
    if (parsed.size > 400) parsed.clear();
    parsed.set(key, r);
  }
  return r;
}

/**
 * Run a GDL script. opts: { vars, mode ('3d' or '2d'), lenient (unknown
 * commands and functions are counted and passed over, as library parts
 * from Archicad use many this reader leaves out), macros (name -> { params,
 * scripts, binary } for CALL), maxSteps, maxTris, binary (section number ->
 * the bodies of its binary 3D data, for BINARY) }. Returns the run (see Runner).
 */
export function runGDL(src, { vars = {}, maxSteps = 2e6, maxTris = 400000, mode = '3d', lenient = false, macros = null, trace = null, binary = null, detail3D = null } = {}) {
  const r = new Runner(vars, { maxTris, mode, lenient, macros, budget: { steps: maxSteps }, trace, binary });
  r.detail3D = detail3D;
  r.exec(src);
  r.closeBody();
  return r;
}

function setIndexed(arr, idx, v) {
  let a = arr;
  for (let i = 0; i < idx.length - 1; i++) {
    const k = idx[i];
    if (!Array.isArray(a[k])) a[k] = [];
    a = a[k];
  }
  a[idx.at(-1)] = v;
}

function jumpTo(labels, target, line, lenient = false, end = 0) {
  const at = labels.get(String(target).toUpperCase()) ?? labels.get(String(target));
  if (at == null) {
    if (lenient) return end;
    throw new GdlError(`No label ${target}`, line);
  }
  return at;
}

// Geometry ------------------------------------------------------------------------------------

const samePoint = (p, q) => Math.abs(p[0] - q[0]) < 1e-9 && Math.abs(p[1] - q[1]) < 1e-9;
const I4 = () => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
function mul4(a, b) {
  const o = new Array(16).fill(0);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) for (let k = 0; k < 4; k++) o[c * 4 + r] += a[k * 4 + r] * b[c * 4 + k];
  return o;
}
/** The inverse of an affine transformation (column-major, as mul4 and ap4 take it). */
function inv4(m) {
  const [a, b, c, d, e, f, g, h, i] = [m[0], m[4], m[8], m[1], m[5], m[9], m[2], m[6], m[10]];
  const A = e * i - f * h;
  const B = -(d * i - f * g);
  const C = d * h - e * g;
  const det = a * A + b * B + c * C;
  if (Math.abs(det) < 1e-18) return I4();
  const r = [A / det, -(b * i - c * h) / det, (b * f - c * e) / det, B / det, (a * i - c * g) / det, -(a * f - c * d) / det, C / det, -(a * h - b * g) / det, (a * e - b * d) / det];
  const t = [m[12], m[13], m[14]];
  const o = I4();
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 3; col++) o[col * 4 + row] = r[row * 3 + col];
    o[12 + row] = -(r[row * 3] * t[0] + r[row * 3 + 1] * t[1] + r[row * 3 + 2] * t[2]);
  }
  return o;
}
const ap4 = (m, p) => [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]];
const tr4 = (x, y, z) => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1];
const sc4 = (x, y, z) => [x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1];
function rot4(axis, deg) {
  const c = Math.cos(deg * D2R);
  const s = Math.sin(deg * D2R);
  if (axis === 'x') return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1];
  if (axis === 'y') return [c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1];
  return [c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
}

/**
 * A polygon from GDL points with status codes: [x, y, s] each; arcs
 * (900 centre, 3000 to a point, 4000 by an angle) become short edges.
 */
export function gdlPolygon(pts, seg = 12) {
  const out = [];
  let centre = null;
  // The direction the outline runs at its last point (set by 800, else the last edge's).
  let tangent = null;
  const lastDir = () => {
    if (tangent) return tangent;
    if (out.length < 2) return null;
    const [a, b] = [out.at(-2), out.at(-1)];
    const l = Math.hypot(b[0] - a[0], b[1] - a[1]);
    return l > 1e-12 ? [(b[0] - a[0]) / l, (b[1] - a[1]) / l] : null;
  };
  // An arc from the last point about c through sweep radians; the outline runs on along its end.
  const arc = (c, sweep) => {
    const a = out.at(-1);
    const r = Math.hypot(a[0] - c[0], a[1] - c[1]);
    const a0 = Math.atan2(a[1] - c[1], a[0] - c[0]);
    const n = Math.max(2, Math.ceil((Math.abs(sweep) / (Math.PI * 2)) * seg * 4));
    for (let i = 1; i <= n; i++) out.push([c[0] + r * Math.cos(a0 + (sweep * i) / n), c[1] + r * Math.sin(a0 + (sweep * i) / n)]);
    const e = a0 + sweep;
    tangent = sweep > 0 ? [-Math.sin(e), Math.cos(e)] : [Math.sin(e), -Math.cos(e)];
  };
  for (const [x, y, s] of pts) {
    const code = Math.round(+s || 0);
    if (code >= 900 && code < 1000) {
      centre = [x, y];
      continue;
    }
    // 800: the tangent's direction for the arc that follows.
    if (code >= 800 && code < 900) {
      const l = Math.hypot(x, y);
      if (l > 1e-12) tangent = [x / l, y / l];
      continue;
    }
    if (code === 700) continue;
    // 100: a line by relative coordinates; 200: by length and direction.
    if (((code >= 100 && code < 200) || (code >= 200 && code < 300)) && out.length) {
      const a = out.at(-1);
      out.push(code < 200 ? [a[0] + x, a[1] + y] : [a[0] + x * Math.cos(y * D2R), a[1] + x * Math.sin(y * D2R)]);
      tangent = null;
      continue;
    }
    // 1000: an arc to (x, y) leaving the last point along the tangent.
    if (code >= 1000 && code < 2000 && out.length) {
      const a = out.at(-1);
      const t = lastDir();
      const d = [x - a[0], y - a[1]];
      const nrm = t && [-t[1], t[0]];
      const k = nrm ? d[0] * nrm[0] + d[1] * nrm[1] : 0;
      if (!t || Math.abs(k) < 1e-12) {
        out.push([x, y]);
        tangent = null;
        continue;
      }
      const r = (d[0] * d[0] + d[1] * d[1]) / (2 * k);
      const c = [a[0] + nrm[0] * r, a[1] + nrm[1] * r];
      // Sweep from the start to the end the way the tangent turns.
      let s0 = Math.atan2(a[1] - c[1], a[0] - c[0]);
      let s1 = Math.atan2(y - c[1], x - c[0]);
      let sweep = s1 - s0;
      if (r > 0) while (sweep <= 0) sweep += Math.PI * 2;
      else while (sweep >= 0) sweep -= Math.PI * 2;
      arc(c, sweep);
      out[out.length - 1] = [x, y];
      continue;
    }
    // 2000: an arc leaving along the tangent with radius x through y degrees.
    if (code >= 2000 && code < 3000 && out.length) {
      const a = out.at(-1);
      const t = lastDir();
      if (!t) continue;
      const side = y >= 0 ? 1 : -1;
      const c = [a[0] - t[1] * x * side, a[1] + t[0] * x * side];
      arc(c, y * D2R);
      continue;
    }
    if (code >= 3000 && code < 4000 && centre && out.length) {
      const a = out.at(-1);
      const r = Math.hypot(a[0] - centre[0], a[1] - centre[1]);
      const a0 = Math.atan2(a[1] - centre[1], a[0] - centre[0]);
      let a1 = Math.atan2(y - centre[1], x - centre[0]);
      // To a point about the centre: the shorter way round.
      while (a1 - a0 > Math.PI) a1 -= Math.PI * 2;
      while (a1 - a0 < -Math.PI) a1 += Math.PI * 2;
      for (let i = 1; i <= seg; i++) out.push([centre[0] + r * Math.cos(a0 + ((a1 - a0) * i) / seg), centre[1] + r * Math.sin(a0 + ((a1 - a0) * i) / seg)]);
      continue;
    }
    if (code >= 4000 && code < 5000 && centre && !out.length) {
      // No point yet: x is the radius about the centre and y the angle swept (a circle at 360).
      const r = x;
      const n = Math.max(3, Math.ceil((Math.abs(y) / 360) * seg * 4));
      const full = Math.abs(Math.abs(y) - 360) < 1e-9;
      for (let i = 0; i < (full ? n : n + 1); i++) out.push([centre[0] + r * Math.cos((y * D2R * i) / n), centre[1] + r * Math.sin((y * D2R * i) / n)]);
      continue;
    }
    if (code >= 4000 && code < 5000 && centre && out.length) {
      const a = out.at(-1);
      const r = Math.hypot(a[0] - centre[0], a[1] - centre[1]);
      const a0 = Math.atan2(a[1] - centre[1], a[0] - centre[0]);
      const sweep = y * D2R;
      const n = Math.max(2, Math.ceil((Math.abs(sweep) / (Math.PI * 2)) * seg * 4));
      for (let i = 1; i <= n; i++) out.push([centre[0] + r * Math.cos(a0 + (sweep * i) / n), centre[1] + r * Math.sin(a0 + (sweep * i) / n)]);
      continue;
    }
    out.push([x, y]);
    tangent = null;
  }
  // A closing point equal to the first goes.
  if (out.length > 2 && Math.hypot(out[0][0] - out.at(-1)[0], out[0][1] - out.at(-1)[1]) < 1e-9) out.pop();
  return out;
}

const area2 = (p) => {
  let a = 0;
  for (let i = 0; i < p.length; i++) {
    const q = p[(i + 1) % p.length];
    a += p[i][0] * q[1] - q[0] * p[i][1];
  }
  return a / 2;
};

/**
 * The state of a run: 3D triangles and edges (local metres, after the
 * transform stack), 2D lines, polygons and texts, hotspots, and the
 * current material and pen.
 */
const GLOBALS = { PI: Math.PI, GLOB_SCALE: 100, GLOB_HSTORY_HEIGHT: 3, GLOB_FRAME_NR: -1, SYMB_ROTANGLE: 0, SYMB_MIRRORED: 0, GLOB_PREVIEW_MODE: 0, GLOB_FEEDBACK_MODE: 0, GLOB_SEO_TOOL_MODE: 0, GLOB_VIEW_TYPE: 2, GLOB_MODPAR_NAME: '', GLOB_UI_BUTTON_ID: 0, GLOB_DRAWING_BGD_PEN: 0, GLOB_STRUCTURE_DISPLAY: 0, GLOB_CUTPLANES_INFO: [0, 1.1, 1.1, 0], AC_SYMB_DISPLAY_OPTION: 0 };

/** Names of the global variables Archicad sets for the element a part draws (besides GLOBALS). */
const GLOBAL_NAME = /^(GLOB_|WALL_|WIDO_|SYMB_|STAIR|TREAD_|RISER_|STRUCTURE_|RAIL|CWALL_|CWFRAME_|CWPANEL_|CWACCESS|SKYLIGHT|ROOF_|BEAM_|COLU_|SLAB_|MESH_|ZONE_|SHELL_|OPENING_)/;

class Runner {
  constructor(vars, { maxTris, mode, lenient = false, macros = null, budget = { steps: 2e6 }, depth = 0, shared = null, trace = null, binary = null }) {
    this.trace = trace || shared?.trace || null;
    this.binary = binary;
    this.detail3D = shared?.detail3D ?? null;
    // Global variables the host sets (the wall a window is in, a stair component's geometry) are seen by
    // the macros it calls too, as in Archicad: taken from the first run's variables by their names.
    this.globals = shared?.globals || Object.fromEntries(Object.entries(vars).filter(([k]) => k in GLOBALS || GLOBAL_NAME.test(k)));
    // GLOB_SCRIPT_TYPE: 2 for the 2D script, 3 for the 3D script (as the master script sees it).
    this.vars = { ...GLOBALS, ...this.globals, GLOB_CONTEXT: mode === '2d' ? 2 : 3, GLOB_SCRIPT_TYPE: mode === '2d' ? 2 : 3, ...vars };
    this.mode = mode;
    this.maxTris = maxTris;
    this.lenient = lenient;
    this.macros = macros;
    this.budget = budget;
    this.depth = depth;
    this.unknown = shared?.unknown || new Map();
    this.buffer = [];
    this.returned = null;
    this.groups = shared?.groups || new Map();
    this.groupStack = [];
    this.groupSeq = 0;
    // FOR loops' end and step, worked out as each starts.
    this.loops = new Map();
    // Channels of the GDL add-ons opened (INITADDONSCOPE), one set for an object and its macros.
    this.addons = shared?.addons || new Map();
    this.verts = [];
    this.vedges = [];
    this.pgons = [];
    this.stack = [];
    this.m = I4();
    this.stack2 = [];
    this.m2 = [1, 0, 0, 1, 0, 0];
    this.material = vars.__material ?? null;
    // Textures and materials the script defines, shared with the macros it calls.
    this.defs = shared?.defs || { textures: [], materials: new Map() };
    this.pen = 1;
    // Text styles (DEFINE STYLE) and the one in use: size in millimetres, the capitals' height.
    this.styles = shared?.styles || new Map();
    this.style = shared?.style || null;
    this.tris = [];
    this.edges = [];
    this.lines2 = [];
    this.polys2 = [];
    this.texts2 = [];
    this.pictures2 = [];
    // Cuts a door or window makes in its wall (WALLHOLE, WALLNICHE): { pts, dir, depth, status, method }.
    this.wallCuts = [];
    // What a door or window's 2D script does to its wall in plan (WALLHOLE2, WALLBLOCK2, WALLLINE2, WALLARC2):
    // holes cut out of the wall's cut polygon, blocks added to it, and lines drawn as part of it.
    this.wallHoles2 = [];
    this.wallBlocks2 = [];
    this.wallLines2 = [];
    this.hotspots = [];
    this.project2 = false;
  }

  /** Run a script's statements with this run's state. */
  exec(src) {
    const { prog, labels } = parseCached(src, this.lenient);
    let pc = 0;
    const stack = [];
    while (pc < prog.length) {
      if (--this.budget.steps < 0) throw new GdlError('The script runs too long (a loop that does not end?)');
      const s = prog[pc++];
      switch (s.k) {
        case 'set': {
          // Arrays and dictionaries are values in GDL: an assignment copies them.
          const v = copyValue(this.ev(s.e));
          if (s.path) this.setPath(s.name, s.path, v, s.line);
          else this.vars[s.name] = v;
          break;
        }
        case 'dim': {
          const n = (e) => (e ? Math.max(0, Math.round(this.ev(e))) : 0);
          const [rows, cols] = s.sizes;
          if (s.sizes.length < 2) this.vars[s.name] = new Array(n(rows) + 1).fill(0);
          else this.vars[s.name] = [[], ...Array.from({ length: n(rows) }, () => new Array(n(cols) + 1).fill(0))];
          break;
        }
        case 'dict':
          for (const n of s.names) this.vars[n] = this.vars[n] && typeof this.vars[n] === 'object' ? this.vars[n] : {};
          break;
        // A jump left unresolved by a statement the lenient reader passed over goes nowhere.
        // A condition that reads a key its dictionary does not have stops with an error in Archicad, and
        // what it guards is not done: here it counts as false.
        case 'jf':
          if (!this.cond(s.cond, !!s.until) && s.to >= 0) pc = s.to;
          break;
        case 'jt':
          if (this.cond(s.cond) && s.to >= 0) pc = s.to;
          break;
        case 'jmp':
          if (s.to >= 0) pc = s.to;
          break;
        case 'ifgoto':
          if (truthy(this.ev(s.cond))) pc = jumpTo(labels, this.label(s.target), s.line, this.lenient, prog.length);
          break;
        case 'goto':
          pc = jumpTo(labels, this.label(s.target), s.line, this.lenient, prog.length);
          break;
        case 'gosub':
          if (stack.length > 200) throw new GdlError('GOSUB goes too deep', s.line);
          stack.push(pc);
          pc = jumpTo(labels, this.label(s.target), s.line, this.lenient, prog.length);
          break;
        case 'return':
          if (!stack.length) pc = prog.length;
          else pc = stack.pop();
          break;
        case 'end':
          if (s.args?.length) this.returned = s.args.map((a) => this.ev(a));
          pc = prog.length;
          break;
        case 'forinit':
          this.loops.set(s.test, { to: this.ev(s.test.to), step: this.ev(s.test.step) });
          break;
        case 'fortest': {
          const v = +this.vars[s.name];
          const lim = this.loops.get(s) || { to: this.ev(s.to), step: this.ev(s.step) };
          if (lim.step >= 0 ? v > lim.to + 1e-9 : v < lim.to - 1e-9) pc = s.exit;
          break;
        }
        case 'forstep': {
          const lim = this.loops.get(s.test);
          this.vars[s.name] = +this.vars[s.name] + (lim ? lim.step : this.ev(s.step));
          break;
        }
        case 'cmd': {
          const args = this.args(s.args);
          this.trace?.('cmd', s.name, this.depth, this, args, s.line);
          this.cmd(s.name, args, s.line);
          break;
        }
        case 'call':
          this.call(s);
          break;
        default:
          break;
      }
    }
  }

  /** Set a value at a path of fields and indices under a variable, making what is missing on the way. */
  setPath(name, path, v, line) {
    const key = (step) => (step.field !== undefined ? step.field : Math.round(this.ev(step.index)));
    let holder = this.vars;
    let k = name;
    for (const step of path) {
      let cur = holder[k];
      if (cur === undefined || cur === 0 || typeof cur !== 'object') {
        if (cur !== undefined && cur !== 0 && !this.lenient) throw new GdlError(`${name} has no ${step.field ?? 'index'}`, line);
        cur = holder[k] = step.field !== undefined ? {} : [];
      }
      holder = cur;
      k = key(step);
    }
    holder[k] = v;
  }

  /** Evaluate a command's arguments; GET and USE spread their values in. */
  args(list) {
    const out = [];
    for (const a of list) {
      const v = this.ev(a, true);
      if (v && v.spread) out.push(...v.spread);
      else out.push(v);
    }
    return out;
  }

  /** CALL a macro: its master and current script with the parameters given, drawing into this run. */
  call(s) {
    const name = String(this.ev(s.name));
    const macro = this.macros?.(name);
    if (!macro) {
      if (!this.lenient) throw new GdlError(`No macro "${name}"`, s.line);
      this.unknown.set(`CALL ${name}`, (this.unknown.get(`CALL ${name}`) || 0) + 1);
      return;
    }
    if (this.depth > 24) throw new GdlError('Macros call each other too deep', s.line);
    const vars = {};
    for (const p of macro.params || []) vars[String(p.name).toUpperCase()] = p.value;
    if (s.all) for (const k of Object.keys(vars)) if (k in this.vars) vars[k] = copyValue(this.vars[k]);
    for (const k of ['A', 'B', 'ZZYZX']) if (s.all || !(k in vars)) vars[k] = this.vars[k];
    for (const a of s.assigns) vars[a.name] = copyValue(this.ev(a.e));
    s.positional.forEach((e, i) => {
      const p = macro.params?.[i];
      if (p) vars[String(p.name).toUpperCase()] = this.ev(e);
    });
    this.trace?.('call', name, this.depth);
    const child = new Runner(vars, { maxTris: this.maxTris, mode: this.mode, lenient: this.lenient, macros: this.macros, budget: this.budget, depth: this.depth + 1, shared: this, binary: macro.binary || null });
    // The macro draws into this run, from where this run's transformations stand.
    for (const k of ['tris', 'edges', 'lines2', 'polys2', 'texts2', 'pictures2', 'wallCuts', 'wallHoles2', 'wallBlocks2', 'wallLines2', 'hotspots']) child[k] = this[k];
    // Called inside GROUP ... ENDGROUP, its bodies go to that group (its own groups stay its own).
    child.groupStack = this.groupStack.slice();
    // The parameter buffer is one for the caller and its macros: a macro PUTs a profile its caller GETs,
    // or GETs the one its caller PUT.
    child.buffer = this.buffer;
    child.m = this.m;
    child.m2 = this.m2;
    child.material = this.material;
    // As in Archicad, the master script runs as the start of the script itself: its subroutines are
    // the script's (a GOSUB in the 3D script may go to a label in the master).
    const own = this.mode === '2d' ? macro.scripts?.script2d : macro.scripts?.script3d;
    const master = macro.scripts?.master || '';
    if (master || own) child.exec(own ? `${master}\n${own}` : master);
    child.closeBody();
    if (child.project2) this.project2 = true;
    this.trace?.('ret', name, this.depth, child, child.returned);
    if (s.returned.length && child.returned) s.returned.forEach((target, i) => {
      if (i >= child.returned.length || !target.name) return;
      if (target.path) this.setPath(target.name, target.path, child.returned[i], s.line);
      else this.vars[target.name] = child.returned[i];
    });
  }

  /** Primitives a script leaves without BODY make a body when it ends. */
  closeBody() {
    if (this.pgons.length) this.cmd('BODY', [], 0);
  }

  /** The edges defined since the last BASE or BODY, as point pairs. */
  edgesNow() {
    return this.vedges.filter(([i, j, st]) => this.verts[i] && this.verts[j] && !(st & 3)).map(([i, j]) => [this.verts[i], this.verts[j]]);
  }

  /** A jump's label, worked out when it is computed. */
  label(t) {
    if (typeof t === 'string') return t;
    const v = this.ev(t.e);
    return typeof v === 'number' ? String(v) : String(v).toUpperCase();
  }

  /** A condition's truth; one that reads a missing dictionary key is false (true for UNTIL, so the loop ends). */
  cond(e, missing = false) {
    this.missingKey = false;
    const v = truthy(this.ev(e));
    if (this.missingKey) {
      this.missingKey = false;
      return missing;
    }
    return v;
  }

  /** Whether a variable, or the field or index a path names under it, is there. */
  has(e) {
    if (!(e.name in this.vars)) return false;
    let v = this.vars[e.name];
    for (const step of e.path || []) {
      if (!v || typeof v !== 'object') return false;
      const k = step.field !== undefined ? step.field : Math.round(this.ev(step.index));
      if (!(k in v) || v[k] === undefined) return false;
      v = v[k];
    }
    return true;
  }

  /** Evaluate an expression; in a list (a command's or function's arguments) GET and USE give all their values. */
  ev(e, list = false) {
    if ('num' in e) return e.num;
    if ('str' in e) return e.str;
    if ('name' in e) {
      if (e.name === 'NSP') return this.buffer.length;
      let v = this.vars[e.name];
      for (const step of e.path || []) {
        if (!v || typeof v !== 'object') {
          if (step.field !== undefined) this.missingKey = true;
          return 0;
        }
        v = v[step.field !== undefined ? step.field : Math.round(this.ev(step.index))];
        if (v === undefined && step.field !== undefined) this.missingKey = true;
      }
      return v === undefined ? 0 : v;
    }
    if ('call' in e) {
      // IND(TEXTURE | MATERIAL | FILL ..., name): a defined texture's number; a material stands for itself by name.
      if (e.call === 'IND' && e.args[0] && 'name' in e.args[0]) {
        const what = e.args[0].name;
        const v = e.args[1] ? this.ev(e.args[1]) : 0;
        if (what === 'TEXTURE') return this.defs.textures.findIndex((x) => x.name === String(v).toUpperCase()) + 1;
        if (what === 'MATERIAL') return v;
        return 0;
      }
      // REQUEST{2}("Building_Material_info", material, "gs_bmat_surface", variable): the surface of a building
      // material, here the material itself (this app's materials are both).
      if ((e.call === 'REQUEST{2}' || e.call === 'REQUEST') && e.args.length >= 4 && /^building_material_info$/i.test(String(this.ev(e.args[0])))) {
        const what = String(this.ev(e.args[2]));
        const target = e.args[3];
        if (!/surface/i.test(what) || !target || !('name' in target)) return 0;
        const v = this.ev(e.args[1]);
        if (target.path) this.setPath(target.name, target.path, v, e.line);
        else this.vars[target.name] = v;
        return 1;
      }
      // NTR(): how many transformations are in force (DEL NTR() - n takes back those made since).
      if (e.call === 'NTR') return (this.mode === '2d' ? this.stack2 : this.stack).length;
      // GDL add-ons: Archicad's Polygon Operations extension (polyops.js) on a channel the object opens.
      if (e.call === 'INITADDONSCOPE') {
        if (!/^polyoperations$/i.test(String(this.ev(e.args[0])))) return 0;
        const ch = this.addons.size ? Math.max(...this.addons.keys()) + 1 : 1;
        this.addons.set(ch, new PolyOps());
        return ch;
      }
      if (e.call === 'PREPAREFUNCTION') {
        const a = this.args(e.args);
        return this.addons.get(Math.round(+a[0]))?.prepare(a[1], a[2], a.slice(3)) ?? 0;
      }
      if (e.call === 'CALLFUNCTION' && e.args.length >= 3) {
        const ops = this.addons.get(Math.round(+this.ev(e.args[0])));
        if (!ops) return 0;
        const out = [];
        const n = ops.call(this.ev(e.args[1]), this.ev(e.args[2]), out);
        // Its results into the variables given after the command and its argument (lists counted from 1).
        e.args.slice(3).forEach((target, i) => {
          if (out[i] === undefined || !target || !('name' in target)) return;
          const v = Array.isArray(out[i]) ? [0, ...out[i]] : out[i];
          if (target.path) this.setPath(target.name, target.path, v, e.line);
          else this.vars[target.name] = v;
        });
        return n;
      }
      // LIBRARYGLOBAL(object, parameter, variable): a value from a library global settings object (Archicad's
      // model view options, as the object's defaults), into the variable; 1 when it is there.
      if (e.call === 'LIBRARYGLOBAL' && e.args.length >= 3) {
        const obj = String(this.ev(e.args[0]));
        const want = String(this.ev(e.args[1])).toUpperCase();
        // The view's own detail level for doors, windows and skylights in 3D: 1 schematic, 2 simplified, 3 full.
        const viewLevel = this.detail3D && /^(IDOOR3DDETLEVEL|IWINDOW3DDETLEVEL|IDETLEVEL3D)$/.test(want) && /MVOSETTINGS/i.test(obj) ? this.detail3D : undefined;
        const own = viewLevel ?? MODEL_VIEW_OPTIONS[obj.toUpperCase()]?.[want];
        const holder = own === undefined ? this.macros?.(obj) : null;
        const p = own === undefined ? holder?.params?.find((q) => String(q.name).toUpperCase() === want) : { value: own };
        const target = e.args[2];
        if (!p || !target || !('name' in target)) return 0;
        const v = copyValue(p.value);
        if (target.path) this.setPath(target.name, target.path, v, e.line);
        else this.vars[target.name] = v;
        return 1;
      }
      // HASKEY looks at its argument's path without reading a missing key as 0.
      if (e.call === 'HASKEY') return e.args[0] && 'name' in e.args[0] && this.has(e.args[0]) ? 1 : 0;
      const args = e.call === 'GET' || e.call === 'USE' ? e.args.map((a) => this.ev(a)) : this.args(e.args);
      switch (e.call) {
        case 'GET':
        case 'USE': {
          const n = Math.max(0, Math.round(args[0] || 0));
          const got = e.call === 'GET' ? this.buffer.splice(0, n) : this.buffer.slice(0, n);
          return list ? { spread: got } : (got[0] ?? 0);
        }
        case 'ADDGROUP':
        case 'SUBGROUP':
        case 'ISECTGROUP':
        case 'ISECTLINES':
        case 'ADDGROUP{2}':
        case 'SUBGROUP{2}':
        case 'ISECTGROUP{2}':
        case 'ADDGROUP{3}':
        case 'SUBGROUP{3}':
        case 'ISECTGROUP{3}': {
          // Solid operations, without true booleans, into a new group: a union has both; a difference
          // keeps the first; an intersection the bodies of the smaller of the two that lie within the
          // other's box (an envelope that trims a body leaves the body), none when either is empty;
          // intersection lines none.
          const A = this.groups.get(String(args[0])) || [];
          const B = this.groups.get(String(args[1])) || [];
          // The {2} and {3} versions add how the result's edges and materials come out: the same bodies here.
          const op = e.call.replace(/\{\d\}$/, '');
          const name = `#${op}${++this.groupSeq}`;
          const box = (g) => {
            const lo = [Infinity, Infinity, Infinity];
            const hi = [-Infinity, -Infinity, -Infinity];
            for (const t of g) if (!t.edge) for (const p of [t.a, t.b, t.c]) for (let k = 0; k < 3; k++) (lo[k] = Math.min(lo[k], p[k])), (hi[k] = Math.max(hi[k], p[k]));
            return { lo, hi, size: lo[0] === Infinity ? 0 : (hi[0] - lo[0] + 1e-6) * (hi[1] - lo[1] + 1e-6) * (hi[2] - lo[2] + 1e-6) };
          };
          // An intersection keeps the smaller group's bodies that lie within the other's box.
          const isect = () => {
            const [a, b] = [box(A), box(B)];
            const [small, big] = b.size < a.size ? [B, a] : [A, b];
            const eps = 1e-6;
            const inBig = (p) => p.every((v, k) => v >= big.lo[k] - eps && v <= big.hi[k] + eps);
            return small.filter((t) => (t.edge ? t.edge.every(inBig) : inBig([(t.a[0] + t.b[0] + t.c[0]) / 3, (t.a[1] + t.b[1] + t.c[1]) / 3, (t.a[2] + t.b[2] + t.c[2]) / 3])));
          };
          const out = op === 'ADDGROUP' ? [...A, ...B] : op === 'SUBGROUP' ? [...A] : op === 'ISECTLINES' || !A.length || !B.length ? [] : isect();
          this.groups.set(name, out);
          return name;
        }
        default:
          break;
      }
      // STW(text): its width in millimetres in the style in use.
      if (e.call === 'STW' && this.style) {
        const t = this.ev(e.args[0]);
        return textAdvance(t, this.style) ?? String(t).length * 0.6 * this.style.size;
      }
      const f = FUNCS[e.call];
      if (!f) {
        if (!this.lenient) throw new GdlError(`Unknown function ${e.call}`, e.line);
        this.unknown.set(`${e.call}()`, (this.unknown.get(`${e.call}()`) || 0) + 1);
        return 0;
      }
      return f(...args);
    }
    const l = this.ev(e.l);
    switch (e.op) {
      case 'neg':
        return -l;
      case 'not':
        return truthy(l) ? 0 : 1;
      case 'and':
        return truthy(l) && truthy(this.ev(e.r)) ? 1 : 0;
      case 'or':
        return truthy(l) || truthy(this.ev(e.r)) ? 1 : 0;
      case 'xor':
        return truthy(l) !== truthy(this.ev(e.r)) ? 1 : 0;
      default:
        break;
    }
    const r = this.ev(e.r);
    switch (e.op) {
      case '+':
        return typeof l === 'string' || typeof r === 'string' ? `${l}${r}` : l + r;
      case '-':
        return l - r;
      case '*':
        return l * r;
      case '/':
        return r === 0 ? 0 : l / r;
      case 'mod':
        return r === 0 ? 0 : l - r * Math.floor(l / r);
      case '^':
        return l ** r;
      case '=':
        return typeof l === 'string' || typeof r === 'string' ? (String(l) === String(r) ? 1 : 0) : Math.abs(l - r) < 1e-9 ? 1 : 0;
      case '<>':
        return typeof l === 'string' || typeof r === 'string' ? (String(l) !== String(r) ? 1 : 0) : Math.abs(l - r) >= 1e-9 ? 1 : 0;
      case '<':
        return l < r ? 1 : 0;
      case '>':
        return l > r ? 1 : 0;
      case '<=':
        return l <= r + 1e-12 ? 1 : 0;
      case '>=':
        return l >= r - 1e-12 ? 1 : 0;
      default:
        throw new GdlError(`Unknown operator ${e.op}`);
    }
  }

  // 3D helpers.
  push3(t) {
    this.stack.push(this.m);
    this.m = mul4(this.m, t);
  }
  P(p) {
    return ap4(this.m, p);
  }
  /** The defined material in use: { rgb, alpha, tex: { pic, w, h } }, or null for a library or plain one. */
  matDef() {
    return typeof this.material === 'string' ? this.defs.materials.get(this.material.toUpperCase()) || null : null;
  }

  /** A triangle's look from a defined material: its colour, and texture coordinates for the points given. */
  dress(t, uv) {
    const d = this.matDef();
    if (!d) return t;
    if (d.rgb) t.rgb = d.rgb;
    if (d.alpha < 1) t.alpha = d.alpha;
    if (d.tex) {
      t.tex = d.tex;
      t.uv = uv();
    }
    return t;
  }

  tri(a, b, c) {
    if (this.tris.length >= this.maxTris) throw new GdlError('The object makes too many triangles');
    // Textures map onto the plane the triangle faces most, in the coordinates it was drawn in.
    const t = this.dress({ a: this.P(a), b: this.P(b), c: this.P(c), mat: this.material }, () => boxUV([a, b, c], this.matDef().tex));
    // Inside GROUP ... ENDGROUP bodies go to the group until it is placed.
    if (this.groupStack.length) this.toGroup(t);
    else this.tris.push(t);
  }
  /** A triangle or an edge (placed) into the group being made, in its own coordinates. */
  toGroup(t) {
    const g = this.groupStack.at(-1);
    const L = g.local || I4();
    if (t.edge) g.push({ edge: t.edge.map((q) => ap4(L, q)) });
    else g.push({ ...t, a: ap4(L, t.a), b: ap4(L, t.b), c: ap4(L, t.c) });
  }
  /** A planar polygon of 3D points (already placed), fan-triangulated. */
  face(pts, uvs = null) {
    for (let i = 1; i + 1 < pts.length; i++) {
      const t = this.dress({ a: pts[0], b: pts[i], c: pts[i + 1], mat: this.material }, () => (uvs ? [uvs[0], uvs[i], uvs[i + 1]] : boxUV([pts[0], pts[i], pts[i + 1]], this.matDef().tex)));
      if (this.groupStack.length) this.toGroup(t);
      else this.tris.push(t);
    }
  }
  quad(a, b, c, d) {
    this.tri(a, b, c);
    this.tri(a, c, d);
  }
  edge(a, b) {
    this.placedEdge([this.P(a), this.P(b)]);
  }
  /** An edge already placed: into the group being made, if any, as its triangles go. */
  placedEdge(e) {
    if (this.groupStack.length) this.toGroup({ edge: e });
    else this.edges.push(e);
  }
  /** A prism of a polygon from z0 to z1 (local), outlines drawn. */
  /**
   * The materials a command names for a body's top, bottom and sides (the C... prisms and slabs): those that
   * are materials here (names), else the one in use.
   */
  faceMats(a) {
    const pick = (m) => (typeof m === 'string' && m ? m : this.material);
    return { top: pick(a[0]), bottom: pick(a[1]), side: pick(a[2]) };
  }
  prism(poly0, z0, z1, mats = null, holes0 = []) {
    // A contour that repeats a point (its first again to close it, as scripts often do twice) has none twice here.
    const clean = (c) => c.filter((p, i) => !samePoint(p, c[(i + 1) % c.length]));
    const poly = clean(poly0);
    if (poly.length < 3) return;
    // The outline counterclockwise, its holes clockwise: their sides face out of the solid.
    const loop = area2(poly) < 0 ? poly.slice().reverse() : poly;
    const holes = holes0.map(clean).filter((h) => h.length >= 3).map((h) => (area2(h) > 0 ? h.slice().reverse() : h));
    const all = [loop, ...holes].flat();
    let ids;
    if (holes.length) {
      const starts = [];
      let at = loop.length;
      for (const h of holes) (starts.push(at), (at += h.length));
      ids = earcut(all.flatMap((p) => [p[0], p[1]]), starts, 2);
    } else ids = earcutLoop(loop);
    const keep = this.material;
    const use = (m) => {
      if (mats) this.material = m;
    };
    use(mats?.top);
    for (let i = 0; i < ids.length; i += 3) {
      const [a, b, c] = [all[ids[i]], all[ids[i + 1]], all[ids[i + 2]]];
      if (area2([a, b, c]) < 0) this.tri([a[0], a[1], z1], [c[0], c[1], z1], [b[0], b[1], z1]);
      else this.tri([a[0], a[1], z1], [b[0], b[1], z1], [c[0], c[1], z1]);
    }
    use(mats?.bottom);
    for (let i = 0; i < ids.length; i += 3) {
      const [a, b, c] = [all[ids[i]], all[ids[i + 1]], all[ids[i + 2]]];
      if (area2([a, b, c]) < 0) this.tri([a[0], a[1], z0], [b[0], b[1], z0], [c[0], c[1], z0]);
      else this.tri([a[0], a[1], z0], [c[0], c[1], z0], [b[0], b[1], z0]);
    }
    use(mats?.side);
    for (const c of [loop, ...holes])
      for (let i = 0; i < c.length; i++) {
        const a = c[i];
        const b = c[(i + 1) % c.length];
        this.quad([a[0], a[1], z0], [b[0], b[1], z0], [b[0], b[1], z1], [a[0], a[1], z1]);
        this.edge([a[0], a[1], z0], [b[0], b[1], z0]);
        this.edge([a[0], a[1], z1], [b[0], b[1], z1]);
      }
    this.material = keep;
  }
  /** A prism's points [x, y, status] split into its outline and holes (a status -1 point ends a contour). */
  contours(list) {
    const out = [];
    let cur = [];
    for (const q of list) {
      if (q[2] === -1) {
        if (cur.length) out.push(cur);
        cur = [];
      } else cur.push(q);
    }
    if (cur.length) out.push(cur);
    return out.map((c) => gdlPolygon(c));
  }
  /** prism() over points [x, y, status] that may hold holes. */
  holedPrism(list, z0, z1, mats) {
    const [outer, ...holes] = this.contours(list);
    if (outer) this.prism(outer, z0, z1, mats, holes);
  }
  /** A prism whose bottom and top heights vary by point: poly [x, y], z0 and z1 heights per point. */
  sheet(poly0, z0a, z1a) {
    const keep = poly0.map((p, i) => !samePoint(p, poly0[(i + 1) % poly0.length]));
    const poly = poly0.filter((_, i) => keep[i]);
    const z0 = z0a.filter((_, i) => keep[i]);
    const z1 = z1a.filter((_, i) => keep[i]);
    if (poly.length < 3) return;
    const rev = area2(poly) < 0;
    const order = poly.map((_, i) => (rev ? poly.length - 1 - i : i));
    const loop = order.map((i) => poly[i]);
    const lo = order.map((i) => z0[i]);
    const hi = order.map((i) => z1[i]);
    const ids = earcutLoop(loop);
    const at = (k, z) => [loop[k][0], loop[k][1], z[k]];
    for (let i = 0; i < ids.length; i += 3) {
      const [a, b, c] = [ids[i], ids[i + 1], ids[i + 2]];
      this.tri(at(a, hi), at(b, hi), at(c, hi));
      this.tri(at(a, lo), at(c, lo), at(b, lo));
    }
    for (let i = 0; i < loop.length; i++) {
      const j = (i + 1) % loop.length;
      this.quad(at(i, lo), at(j, lo), at(j, hi), at(i, hi));
      this.edge(at(i, lo), at(j, lo));
      this.edge(at(i, hi), at(j, hi));
    }
  }

  /** A body of revolution about local z: rings of [r, z] points; its end and widest rings drawn as edges. */
  lathe(profile, seg = 24, a0 = 0, sweep = 360) {
    if (!profile || profile.length < 2) return;
    const n = Math.max(3, Math.ceil((seg * Math.abs(sweep)) / 360));
    const ring = (k) => (a0 + (sweep * k) / n) * D2R;
    const p = (r, z, a) => [r * Math.cos(a), r * Math.sin(a), z];
    for (let j = 0; j + 1 < profile.length; j++) {
      const [r0, z0] = profile[j];
      const [r1, z1] = profile[j + 1];
      for (let k = 0; k < n; k++) this.quad(p(r0, z0, ring(k)), p(r0, z0, ring(k + 1)), p(r1, z1, ring(k + 1)), p(r1, z1, ring(k)));
    }
    let wide = 0;
    profile.forEach(([r], j) => r > profile[wide][0] && (wide = j));
    for (const j of new Set([0, profile.length - 1, wide])) {
      const [r, z] = profile[j];
      if (r <= 1e-9) continue;
      for (let k = 0; k < n; k++) this.edge(p(r, z, ring(k)), p(r, z, ring(k + 1)));
    }
  }

  cmd(name, a, line) {
    const need = (k) => {
      if (a.length >= k) return;
      if (!this.lenient) throw new GdlError(`${name} needs ${k} values`, line);
      while (a.length < k) a.push(0);
    };
    const pts = (from, per) => {
      const out = [];
      for (let i = from; i + per - 1 < a.length; i += per) out.push(a.slice(i, i + per));
      return out;
    };
    switch (name) {
      // Transformations.
      case 'ADDX':
        return this.push3(tr4(a[0] || 0, 0, 0));
      case 'ADDY':
        return this.push3(tr4(0, a[0] || 0, 0));
      case 'ADDZ':
        return this.push3(tr4(0, 0, a[0] || 0));
      case 'ADD':
        return this.push3(tr4(a[0] || 0, a[1] || 0, a[2] || 0));
      case 'ROTX':
        return this.push3(rot4('x', a[0] || 0));
      case 'ROTY':
        return this.push3(rot4('y', a[0] || 0));
      case 'ROTZ':
        return this.push3(rot4('z', a[0] || 0));
      case 'MULX':
        return this.push3(sc4(a[0] ?? 1, 1, 1));
      case 'MULY':
        return this.push3(sc4(1, a[0] ?? 1, 1));
      case 'MULZ':
        return this.push3(sc4(1, 1, a[0] ?? 1));
      case 'MUL':
        return this.push3(sc4(a[0] ?? 1, a[1] ?? 1, a[2] ?? 1));
      case 'DEL': {
        const two = this.mode === '2d';
        const st = two ? this.stack2 : this.stack;
        const n = a[0] === 'TOP' ? st.length : Math.max(1, Math.round(a[0] ?? 1));
        for (let i = 0; i < n && st.length; i++) {
          if (two) this.m2 = st.pop();
          else this.m = st.pop();
        }
        return;
      }
      case 'ADD2':
        return this.push2([1, 0, 0, 1, a[0] || 0, a[1] || 0]);
      case 'ROT2': {
        const c = Math.cos((a[0] || 0) * D2R);
        const s = Math.sin((a[0] || 0) * D2R);
        return this.push2([c, s, -s, c, 0, 0]);
      }
      case 'MUL2':
        return this.push2([a[0] ?? 1, 0, 0, a[1] ?? 1, 0, 0]);
      case 'MATERIAL':
      case 'SET MATERIAL':
        this.material = a[0];
        return;
      case 'PEN':
        this.pen = a[0];
        return;
      case 'RESOL':
      case 'TOLER':
      case 'MODEL':
      case 'CUTPLANE':
      case 'CUTPLANE{2}':
      case 'CUTPLANE{3}':
      case 'CUTEND':
      case 'CUTPOLY':
      case 'CUTPOLYA':
      case 'CUTFORM':
      case 'HOTLINE2':
      case 'HOTARC2':
      case 'HOTLINE':
      case 'HOTARC':
      case 'DRAWINDEX':
      case 'LINE_PROPERTY':
      case 'COOR':
      case 'COOR{2}':
      case 'COOR{3}':
      case 'VECT':
      case 'PIPG':
      case 'NURBSVERT':
      case 'FRAGMENT2':
      case 'SECT_FILL':
      case 'SECT_ATTRS':
      case 'SECT_ATTRS{2}':
      case 'BUILDING_MATERIAL':
      case 'VALUES{2}':
      case 'RADIUS':
      case 'UI_DIALOG':
      case 'UI_PAGE':
      case 'UI_CURRENT_PAGE':
      case 'FILE_DEPENDENCE':
      case 'PAGEVALUES':
      case 'CLOSEADDONSCOPE':
        this.addons.delete(Math.round(+a[0]));
        return;
      case 'PREPAREFUNCTION':
        // An add-on's setup: PREPAREFUNCTION channel, command, name, values...
        this.addons.get(Math.round(+a[0]))?.prepare(a[1], a[2], a.slice(3));
        return;
      case 'DEFINE TEXTURE': {
        // name, picture (its number in the part, or a file name), width, height, mask, angle.
        need(4);
        const def = { name: String(a[0]).toUpperCase(), pic: a[1], w: Math.abs(+a[2]) || 1, h: Math.abs(+a[3]) || 1 };
        const i = this.defs.textures.findIndex((x) => x.name === def.name);
        if (i >= 0) this.defs.textures[i] = def;
        else this.defs.textures.push(def);
        return;
      }
      case 'DEFINE MATERIAL': {
        // name, type, then the surface colour; types 20 and 21 also the transparency and a texture's number.
        need(2);
        const type = Math.round(a[1]);
        const rgb = a.length >= 5 ? [a[2], a[3], a[4]].map((v) => Math.max(0, Math.min(1, +v || 0))) : null;
        const def = { name: String(a[0]), color: rgb, rgb: rgb && rgb.some((v) => v > 0) ? rgb : null, alpha: 1, tex: null };
        if ((type === 20 || type === 21) && a.length >= 21) {
          def.alpha = Math.max(0, Math.min(1, 1 - (+a[8] || 0)));
          const tex = this.defs.textures[Math.round(a[20]) - 1];
          if (tex) def.tex = { pic: tex.pic, w: tex.w, h: tex.h };
        }
        this.defs.materials.set(String(a[0]).toUpperCase(), def);
        return;
      }
      case 'PICTURE': {
        // PICTURE picture, a, b, mask: the picture on an a by b rectangle in the x-y plane.
        need(3);
        if (this.mode !== '3d') return;
        const [w, h] = [+a[1] || 0, +a[2] || 0];
        if (!w || !h) return;
        const tex = { pic: a[0], w, h };
        const P = [[0, 0, 0], [w, 0, 0], [w, h, 0], [0, h, 0]].map((q) => this.P(q));
        const uv = [[0, 0], [1, 0], [1, 1], [0, 1]];
        for (const [i, j, k] of [[0, 1, 2], [0, 2, 3]]) this.tris.push({ a: P[i], b: P[j], c: P[k], mat: this.material, tex, uv: [uv[i], uv[j], uv[k]] });
        return;
      }
      case 'BINARY': {
        // BINARY mode, section[, body]: the part's binary 3D data, one body of it or all.
        const bodies = this.mode === '3d' && Math.round(a[0] ?? 0) === 0 ? this.binary?.(Math.round(a[1] ?? 1)) : null;
        if (!bodies) return;
        const pick = a.length > 2 ? [bodies[Math.round(a[2]) - 1]] : bodies;
        for (const b of pick) for (const loop of b?.polys || []) this.face(loop.map((q) => this.P(q)));
        return;
      }
      case 'DEFINE STYLE': {
        // DEFINE STYLE name font, size, anchor, face (DEFINE STYLE{2}: no anchor).
        const [nm, font, size, x, y] = a;
        const two = a.length < 5;
        this.styles.set(String(nm).toUpperCase(), { font: String(font || 'Arial'), size: +size || 0, anchor: two ? 1 : +x || 1, face: two ? +x || 0 : +y || 0 });
        return;
      }
      case 'SET STYLE':
      case 'STYLE':
        this.style = this.styles.get(String(a[0]).toUpperCase()) || this.style;
        return;
      case 'TEXT': {
        // TEXT d, 0, expression: the text as a solid d thick, in the style in use (its size in mm read as model mm).
        if (this.mode !== '3d') return;
        const st = this.style || { font: 'Arial', size: 10, anchor: 1, face: 0 };
        const val = a[2];
        const str = typeof val === 'number' ? String(+val.toFixed(6)) : String(val ?? '');
        const solid = textSolid(str, { ...st, size: st.size / 1000 }, Math.max(0, +a[0] || 0));
        if (!solid) return;
        for (const [p0, p1, p2] of solid.tris) this.tri(p0, p1, p2);
        for (const [p0, p1, p2, p3] of solid.quads) this.quad(p0, p1, p2, p3);
        for (const [p, q] of solid.edges) this.edge(p, q);
        return;
      }
      case 'UNID':
      case 'SURFACE3D':
      case 'LIGHT':
      case 'SHADOW':
      case 'FILL':
      case 'LINE_TYPE':
      case 'DEFINE':
      case 'SET':
      case 'PRINT':
        if (name === 'PRINT') gdlMessages.push(a.map((v) => (typeof v === 'number' ? Math.round(v * 1e6) / 1e6 : String(v))).join(' '));
      // falls through
      case 'VALUES':
      case 'LOCK':
      case 'HIDEPARAMETER':
        // The parameter script's lists of allowed values and locks, kept for Run Parameter Script.
        if (this.mode === 'params') (this.paramOut ||= []).push({ cmd: name, args: a });
        return;
      case 'PARAMETERS':
        return;
      // 3D bodies.
      case 'BLOCK':
      case 'BRICK':
        need(3);
        return this.prism([[0, 0], [a[0], 0], [a[0], a[1]], [0, a[1]]], 0, a[2]);
      case 'CYLIND':
        need(2);
        return this.lathe([[0, 0], [a[1], 0], [a[1], a[0]], [0, a[0]]]);
      case 'CONE':
        need(3);
        return this.lathe([[0, 0], [a[1], 0], [a[2], a[0]], [0, a[0]]]);
      case 'ELLIPS': {
        need(2);
        const prof = [];
        for (let i = 0; i <= 8; i++) {
          const t = (i / 8) * (Math.PI / 2);
          prof.push([a[1] * Math.cos(t), a[0] * Math.sin(t)]);
        }
        return this.lathe([[0, 0], ...prof]);
      }
      case 'SPHERE': {
        need(1);
        const prof = [];
        for (let i = 0; i <= 12; i++) {
          const t = -Math.PI / 2 + (i / 12) * Math.PI;
          prof.push([a[0] * Math.cos(t), a[0] * Math.sin(t)]);
        }
        return this.lathe(prof);
      }
      case 'PRISM': {
        need(2);
        const n = Math.round(a[0]);
        return this.prism(pts(2, 2).slice(0, n), 0, a[1]);
      }
      case 'PRISM_':
      case 'CPRISM_':
      case 'BPRISM_': {
        // BPRISM_ has the bending radius before its points; its prism is drawn unbent.
        const off = name === 'PRISM_' ? 0 : 3;
        need(off + 2);
        const n = Math.round(a[off]);
        const h = a[off + 1];
        const start = off + 2 + (name === 'BPRISM_' ? 1 : 0);
        return this.holedPrism(pts(start, 3).slice(0, n), Math.min(0, h), Math.max(0, h), off ? this.faceMats(a) : null);
      }
      case 'SLAB_':
      case 'CSLAB_': {
        // (CSLAB_: three materials first.) n, h, then points x, y, z, status: the polygon, inclined as its
        // points' heights say, and h thick along z.
        const off = name === 'CSLAB_' ? 3 : 0;
        need(off + 2);
        const n = Math.round(a[off]);
        const h = a[off + 1];
        const raw = pts(off + 2, 4).slice(0, n);
        if (raw.some((p) => Math.abs(p[2] - raw[0][2]) > 1e-9) && raw.every((p) => p[3] % 100 < 900)) {
          const poly = raw.map((p) => [p[0], p[1]]);
          const z = raw.map((p) => p[2]);
          return this.sheet(poly, z.map((v) => v + Math.min(0, h)), z.map((v) => v + Math.max(0, h)));
        }
        const z = raw.length ? raw[0][2] : 0;
        return this.holedPrism(raw.map((p) => [p[0], p[1], p[3]]), z + Math.min(0, h), z + Math.max(0, h), off ? this.faceMats(a) : null);
      }
      case 'MASS':
      case 'MASS{2}': {
        // Three materials, n, m, mask, h, then n points x, y, z, status of the top surface's outline and m inner
        // ridge points: the surface, with walls down to the height h and a base there.
        need(7);
        const n = Math.round(a[3]);
        const raw = pts(7, 4).slice(0, n).filter((p) => p[3] !== -1);
        if (raw.length < 3) return;
        const poly = raw.map((p) => [p[0], p[1]]);
        const h = a[6];
        const top = raw.map((p) => Math.max(p[2], h));
        const bottom = raw.map((p) => Math.min(p[2], h));
        return this.sheet(poly, bottom, top);
      }
      case 'CROOF_':
      case 'CROOF_{2}':
      case 'CROOF_{3}':
      case 'CROOF_{4}': {
        // Three materials, n, a reference line (xb, yb, xe, ye), its height, the roof's slope, its thickness,
        // then points x, y, edge angle, status: the outline lifted to the plane rising to the left of the line.
        need(11);
        const n = Math.round(a[3]);
        const [xb, yb, xe, ye, hz, ang, th] = a.slice(4, 11);
        const raw = pts(11, 4).slice(0, n);
        const poly = gdlPolygon(raw.map((p) => [p[0], p[1], p[3]]));
        const len = Math.hypot(xe - xb, ye - yb) || 1;
        const t = Math.tan(ang * D2R);
        const zAt = (p) => hz + (((xe - xb) * (p[1] - yb) - (ye - yb) * (p[0] - xb)) / len) * t;
        const thick = th / Math.max(0.05, Math.cos(ang * D2R));
        return this.sheet(poly, poly.map((p) => zAt(p) - thick), poly.map(zAt));
      }
      case 'CWALL_': {
        // left, right and side materials, height, x1..x4 (the ends of its two faces, at y 0 and t), t, four
        // masks, n openings (x start, z low, x end, z high, frame), m cutting planes: the wall in boxes around
        // its openings.
        need(14);
        const [hgt, x1, x2, x3, x4, t] = a.slice(3, 9);
        const n = Math.round(a[13]);
        const holes = pts(14, 5).slice(0, n).map((o) => ({ x0: Math.min(o[0], o[2]), x1: Math.max(o[0], o[2]), z0: Math.min(o[1], o[3]), z1: Math.max(o[1], o[3]) }));
        if (!holes.length) return this.prism([[x1, 0], [x2, 0], [x3, t], [x4, t]], 0, hgt);
        const lo = Math.min(x1, x4);
        const hi = Math.max(x2, x3);
        const xs = [...new Set([lo, hi, ...holes.flatMap((o) => [o.x0, o.x1])].filter((x) => x >= lo && x <= hi))].sort((p, q) => p - q);
        for (let i = 0; i + 1 < xs.length; i++) {
          const [xa, xb] = [xs[i], xs[i + 1]];
          const mid = (xa + xb) / 2;
          const cut = holes.filter((o) => o.x0 <= mid && o.x1 >= mid);
          const zs = [...new Set([0, hgt, ...cut.flatMap((o) => [o.z0, o.z1])].filter((z) => z >= 0 && z <= hgt))].sort((p, q) => p - q);
          for (let j = 0; j + 1 < zs.length; j++) {
            const zm = (zs[j] + zs[j + 1]) / 2;
            if (cut.some((o) => o.z0 <= zm && o.z1 >= zm)) continue;
            this.prism([[xa, 0], [xb, 0], [xb, t], [xa, t]], zs[j], zs[j + 1]);
          }
        }
        return;
      }
      case 'REVOLVE': {
        // REVOLVE n, alpha, mask, x1, y1, s1, ...: the profile in x (along the axis) and y (radius), about local x.
        need(3);
        const n = Math.round(a[0]);
        const prof = gdlPolygon(pts(3, 3).slice(0, n));
        // About the x axis: x along it, y the radius; the sweep starts in the x-y plane and turns towards +z.
        this.push3(rot4('y', 90));
        this.lathe(prof.map(([x, y]) => [y, x]), 24, 90, a[1] || 360);
        this.m = this.stack.pop();
        return;
      }
      case 'ROT': {
        // A rotation by alpha about the axis (x, y, z) through the origin.
        need(4);
        const l = Math.hypot(a[0], a[1], a[2]);
        if (l < 1e-12) return this.push3([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
        const [x, y, z] = [a[0] / l, a[1] / l, a[2] / l];
        const c = Math.cos(a[3] * D2R);
        const sn = Math.sin(a[3] * D2R);
        const k = 1 - c;
        return this.push3([c + x * x * k, y * x * k + z * sn, z * x * k - y * sn, 0, x * y * k - z * sn, c + y * y * k, z * y * k + x * sn, 0, x * z * k + y * sn, y * z * k - x * sn, c + z * z * k, 0, 0, 0, 0, 1]);
      }
      case 'XFORM': {
        need(12);
        return this.push3([a[0], a[4], a[8], 0, a[1], a[5], a[9], 0, a[2], a[6], a[10], 0, a[3], a[7], a[11], 1]);
      }
      case 'HPRISM_':
      case 'FPRISM_': {
        // Top, bottom, side and hill materials, then n, thickness, slope angle, hill height (and HPRISM_'s status), then the points.
        const head = name === 'HPRISM_' ? 9 : 8;
        need(head);
        const n = Math.round(a[4]);
        return this.prism(gdlPolygon(pts(head, 3).slice(0, n)), 0, a[5]);
      }
      case 'EXTRUDE': {
        // n, dx, dy, dz, mask, points: the polygon swept along a vector.
        need(5);
        const n = Math.round(a[0]);
        const poly = gdlPolygon(pts(5, 3).slice(0, n));
        const [dx, dy, dz] = [a[1], a[2], a[3]];
        if (poly.length < 3) return;
        const loop = area2(poly) < 0 ? poly.slice().reverse() : poly;
        const ids = earcutLoop(loop);
        for (let i = 0; i < ids.length; i += 3) {
          const [p, q, r] = [loop[ids[i]], loop[ids[i + 1]], loop[ids[i + 2]]];
          this.tri([p[0] + dx, p[1] + dy, dz], [q[0] + dx, q[1] + dy, dz], [r[0] + dx, r[1] + dy, dz]);
          this.tri([p[0], p[1], 0], [r[0], r[1], 0], [q[0], q[1], 0]);
        }
        for (let i = 0; i < loop.length; i++) {
          const p = loop[i];
          const q = loop[(i + 1) % loop.length];
          this.quad([p[0], p[1], 0], [q[0], q[1], 0], [q[0] + dx, q[1] + dy, dz], [p[0] + dx, p[1] + dy, dz]);
        }
        return;
      }
      case 'PYRAMID': {
        need(3);
        const n = Math.round(a[0]);
        const poly = gdlPolygon(pts(3, 3).slice(0, n));
        if (poly.length < 3) return;
        const loop = area2(poly) < 0 ? poly.slice().reverse() : poly;
        for (let i = 0; i < loop.length; i++) {
          const p = loop[i];
          const q = loop[(i + 1) % loop.length];
          this.tri([p[0], p[1], 0], [q[0], q[1], 0], [0, 0, a[1]]);
        }
        const ids = earcutLoop(loop);
        for (let i = 0; i < ids.length; i += 3) this.tri([loop[ids[i]][0], loop[ids[i]][1], 0], [loop[ids[i + 2]][0], loop[ids[i + 2]][1], 0], [loop[ids[i + 1]][0], loop[ids[i + 1]][1], 0]);
        return;
      }
      case 'RULED':
      case 'RULED{2}': {
        // n, mask, a polygon in the x-y plane, then n points in space: quads between them.
        need(2);
        const n = Math.round(a[0]);
        const lower = pts(2, 3).slice(0, n);
        const upper = pts(2 + 3 * n, 3).slice(0, n);
        for (let i = 0; i < n && upper.length === n; i++) {
          const j = (i + 1) % n;
          this.quad([lower[i][0], lower[i][1], 0], [lower[j][0], lower[j][1], 0], upper[j], upper[i]);
        }
        return;
      }
      case 'PLANE':
      case 'PLANE_': {
        need(1);
        const n = Math.round(a[0]);
        const raw = pts(1, name === 'PLANE' ? 3 : 4).slice(0, n);
        if (raw.length >= 3) this.face(raw.map((q) => this.P([q[0], q[1], q[2]])));
        return;
      }
      case 'TUBE{2}': {
        // Three materials, then as TUBE with a material after each profile point.
        need(6);
        const n = Math.round(a[3]);
        const prof = pts(6, 4).slice(0, n).flatMap((q) => [q[0], q[1], q[2]]);
        return this.cmd('TUBE', [a[3], a[4], a[5], ...prof, ...a.slice(6 + 4 * n)], line);
      }
      case 'TUBE':
      case 'TUBEA': {
        // n profile points (u, v, s) swept along m path points (x, y, z, twist); the first and last only set directions.
        need(3);
        const n = Math.round(a[0]);
        const m = Math.round(a[1]);
        const prof = gdlPolygon(pts(3, 3).slice(0, n));
        const path = pts(3 + 3 * n, 4).slice(0, m);
        if (prof.length < 2 || path.length < 3) return;
        const frame = (i) => {
          const p = path[i];
          const q = path[Math.min(path.length - 1, i + 1)];
          const o = path[Math.max(0, i - 1)];
          let t = [q[0] - o[0], q[1] - o[1], q[2] - o[2]];
          const l = Math.hypot(...t) || 1;
          t = t.map((x) => x / l);
          // The profile's u lies horizontal, v across it.
          let u = [-t[1], t[0], 0];
          const lu = Math.hypot(...u);
          u = lu < 1e-6 ? [1, 0, 0] : u.map((x) => x / lu);
          const v = [t[1] * u[2] - t[2] * u[1], t[2] * u[0] - t[0] * u[2], t[0] * u[1] - t[1] * u[0]];
          return prof.map(([pu, pv]) => [p[0] + u[0] * pu + v[0] * pv, p[1] + u[1] * pu + v[1] * pv, p[2] + u[2] * pu + v[2] * pv]);
        };
        let prev = frame(1);
        for (let i = 2; i < path.length - 1; i++) {
          const cur = frame(i);
          for (let k = 0; k < prof.length; k++) {
            const k2 = (k + 1) % prof.length;
            this.quad(prev[k], prev[k2], cur[k2], cur[k]);
          }
          prev = cur;
        }
        return;
      }
      case 'CPRISM_{2}':
      case 'CPRISM_{3}':
      case 'CPRISM_{4}': {
        // Three materials (and from {3} a mask), n, h; each point x, y, angle, status, side material.
        const off = name === 'CPRISM_{2}' ? 3 : 4;
        need(off + 2);
        const n = Math.round(a[off]);
        const h = a[off + 1];
        return this.holedPrism(pts(off + 2, 5).slice(0, n).map((q) => [q[0], q[1], q[3]]), Math.min(0, h), Math.max(0, h), this.faceMats(a));
      }
      case 'SPRISM_': {
        // Three materials, n, the cutting line (xb, yb, xe, ye), h, the plane's angle, then points x, y, status.
        need(10);
        const n = Math.round(a[3]);
        const h = a[8];
        return this.holedPrism(pts(10, 3).slice(0, n), Math.min(0, h), Math.max(0, h), this.faceMats(a));
      }
      case 'SPRISM_{2}': {
        // Three materials, n, a top and a bottom plane (a line, a height and an angle each), then points x, y,
        // status, material: the prism between the two heights, its planes drawn level.
        need(16);
        const n = Math.round(a[3]);
        const top = a[8];
        const bottom = a[14];
        return this.holedPrism(pts(16, 4).slice(0, n).map((q) => [q[0], q[1], q[2]]), Math.min(top, bottom), Math.max(top, bottom), this.faceMats(a));
      }
      case 'COONS': {
        // n, m, mask, then the four boundary curves (n, n, m, m points of x, y, z): a bilinearly blended patch.
        need(3);
        const n = Math.round(a[0]);
        const m = Math.round(a[1]);
        const c1 = pts(3, 3).slice(0, n);
        const c2 = pts(3 + 3 * n, 3).slice(0, n);
        const c3 = pts(3 + 6 * n, 3).slice(0, m);
        const c4 = pts(3 + 6 * n + 3 * m, 3).slice(0, m);
        if (c1.length < n || c2.length < n || c3.length < m || c4.length < m || n < 2 || m < 2) return;
        const P = (i, j) => {
          const u = i / (n - 1);
          const v = j / (m - 1);
          const out = [0, 0, 0];
          for (let k = 0; k < 3; k++) {
            out[k] = (1 - v) * c1[i][k] + v * c2[i][k] + (1 - u) * c3[j][k] + u * c4[j][k]
              - ((1 - u) * (1 - v) * c1[0][k] + u * (1 - v) * c1[n - 1][k] + (1 - u) * v * c2[0][k] + u * v * c2[n - 1][k]);
          }
          return out;
        };
        for (let i = 0; i + 1 < n; i++) for (let j = 0; j + 1 < m; j++) this.quad(P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1));
        return;
      }
      case 'ARC':
      case 'CIRCLE': {
        // Lines in the x-y plane: an arc of radius r from a1 to a2 degrees, or a whole circle.
        need(1);
        const r = a[0];
        const a0 = name === 'ARC' ? a[1] || 0 : 0;
        const a1 = name === 'ARC' ? a[2] || 0 : 360;
        const k = Math.max(4, Math.ceil(Math.abs(a1 - a0) / 10));
        for (let i = 0; i < k; i++) {
          const u = (a0 + ((a1 - a0) * i) / k) * D2R;
          const v = (a0 + ((a1 - a0) * (i + 1)) / k) * D2R;
          this.edge([r * Math.cos(u), r * Math.sin(u), 0], [r * Math.cos(v), r * Math.sin(v), 0]);
        }
        return;
      }
      case 'SWEEP': {
        // n, m, twist, scale, mask, the profile (u, v, s), then m path points (x, y, z): the profile carried along, turning and scaling.
        need(5);
        const n = Math.round(a[0]);
        const m = Math.round(a[1]);
        const prof = gdlPolygon(pts(5, 3).slice(0, n));
        const path = pts(5 + 3 * n, 3).slice(0, m);
        if (prof.length < 2 || path.length < 2) return;
        const ring = (i) => {
          const f = path.length > 1 ? i / (path.length - 1) : 0;
          const tw = a[2] * f * D2R;
          const k = 1 + (a[3] - 1) * f;
          const c = Math.cos(tw);
          const sn = Math.sin(tw);
          return prof.map(([u, v]) => [path[i][0] + k * (u * c - v * sn), path[i][1] + k * (u * sn + v * c), path[i][2]]);
        };
        let prev = ring(0);
        for (let i = 1; i < path.length; i++) {
          const cur = ring(i);
          for (let q = 0; q < prof.length; q++) {
            const q2 = (q + 1) % prof.length;
            this.quad(prev[q], prev[q2], cur[q2], cur[q]);
          }
          prev = cur;
        }
        return;
      }
      case 'MESH': {
        // a, b, m, n, mask, then m x n heights: a grid over a x b.
        need(5);
        const [A, B] = [a[0], a[1]];
        const m = Math.max(2, Math.round(a[2]));
        const n = Math.max(2, Math.round(a[3]));
        const z = (i, j) => a[5 + j * m + i] ?? 0;
        const P = (i, j) => [(A * i) / (m - 1), (B * j) / (n - 1), z(i, j)];
        for (let j = 0; j + 1 < n; j++) for (let i = 0; i + 1 < m; i++) this.quad(P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1));
        return;
      }
      case 'ARMC':
      case 'ARME': {
        // An arm (a cylinder of radius r1 and length l along z) joined to a larger body: drawn as the arm alone.
        need(3);
        const r1 = a[0];
        const l = a[2];
        return this.lathe([[0, 0], [r1, 0], [r1, l], [0, l]]);
      }
      case 'POLY':
      case 'POLY_': {
        need(1);
        const n = Math.round(a[0]);
        const raw = name === 'POLY' ? pts(1, 2).slice(0, n).map((p) => [p[0], p[1], 1]) : pts(1, 3).slice(0, n);
        const poly = gdlPolygon(raw);
        if (poly.length >= 3) this.face(poly.map((p) => this.P([p[0], p[1], 0])));
        return;
      }
      case 'RECT':
        need(2);
        this.quad([0, 0, 0], [a[0], 0, 0], [a[0], a[1], 0], [0, a[1], 0]);
        return;
      case 'LIN_':
        need(6);
        return this.edge([a[0], a[1], a[2]], [a[3], a[4], a[5]]);
      case 'HOTSPOT':
        need(3);
        this.hotspots.push(this.P([a[0], a[1], a[2]]));
        return;
      // 2D.
      case 'PROJECT2':
        this.project2 = true;
        return;
      case 'LINE2':
        need(4);
        return this.lines2.push([this.Q([a[0], a[1]]), this.Q([a[2], a[3]])]);
      case 'RECT2':
        need(4);
        return this.polys2.push({ pts: [[a[0], a[1]], [a[2], a[1]], [a[2], a[3]], [a[0], a[3]]].map((p) => this.Q(p)), fill: false });
      case 'POLY2':
      case 'POLY2_': {
        need(2);
        const n = Math.round(a[0]);
        const frameFill = Math.round(a[1]);
        const raw = name === 'POLY2' ? pts(2, 2).slice(0, n).map((p) => [p[0], p[1], 1]) : pts(2, 3).slice(0, n);
        return this.polys2.push({ pts: gdlPolygon(raw).map((p) => this.Q(p)), fill: (frameFill & 2) === 2, frame: (frameFill & 1) === 1 || frameFill === 0 });
      }
      case 'CIRCLE2': {
        need(3);
        const c = [];
        for (let i = 0; i < 32; i++) c.push(this.Q([a[0] + a[2] * Math.cos((i / 32) * Math.PI * 2), a[1] + a[2] * Math.sin((i / 32) * Math.PI * 2)]));
        return this.polys2.push({ pts: c, fill: false });
      }
      case 'ARC2': {
        need(5);
        let a1 = a[4];
        while (a1 < a[3]) a1 += 360;
        const n = Math.max(2, Math.ceil(((a1 - a[3]) / 360) * 32));
        for (let i = 0; i < n; i++) {
          const u = (a[3] + ((a1 - a[3]) * i) / n) * D2R;
          const v = (a[3] + ((a1 - a[3]) * (i + 1)) / n) * D2R;
          this.lines2.push([this.Q([a[0] + a[2] * Math.cos(u), a[1] + a[2] * Math.sin(u)]), this.Q([a[0] + a[2] * Math.cos(v), a[1] + a[2] * Math.sin(v)])]);
        }
        return;
      }
      case 'WALLHOLE':
      case 'WALLNICHE': {
        // WALLHOLE n, status, points x, y, mask [, direction x, y, z] (an infinite tube through the wall;
        // its status only sets the attributes of the cut faces); WALLNICHE n, method, status, the cut's
        // direction (rx, ry, rz) and depth, then the points x, y, mask [, material with status bit 256]
        // (status bits 8 + 16: infinite, 16: semi-infinite, neither: finite). Placed, they cut the wall the
        // opening is in.
        const niche = name === 'WALLNICHE';
        const off = niche ? 7 : 2;
        need(off);
        const n = Math.round(a[0]);
        const per = niche && Math.round(a[2]) & 256 ? 4 : 3;
        const poly = gdlPolygon(pts(off, per).slice(0, n).map((q) => q.slice(0, 3)));
        if (poly.length < 3) return;
        const tail = off + 3 * n;
        const dir = niche ? [a[3], a[4], a[5]] : a.length >= tail + 3 ? [a[tail], a[tail + 1], a[tail + 2]] : [0, 0, 1];
        const o = this.P([0, 0, 0]);
        const d = this.P(dir);
        this.wallCuts.push({
          pts: poly.map((q) => this.P([q[0], q[1], 0])),
          dir: [d[0] - o[0], d[1] - o[1], d[2] - o[2]],
          depth: niche ? +a[6] || 0 : Infinity,
          status: Math.round(niche ? a[2] : a[1]),
          method: niche ? Math.round(a[1]) : 0,
        });
        return;
      }
      case 'SPLINE2':
      case 'SPLINE2A': {
        // n, status (1: closed), then per point x, y, the tangent's direction and (SPLINE2A) the lengths of
        // its handles before and after: cubic curves between the points.
        need(2);
        const n = Math.round(a[0]);
        const per = name === 'SPLINE2A' ? 5 : 3;
        const P = pts(2, per).slice(0, n);
        if (P.length < 2) return;
        const closed = Math.round(a[1]) & 1;
        const dir = (q) => [Math.cos(q[2] * D2R), Math.sin(q[2] * D2R)];
        const segs = closed ? P.length : P.length - 1;
        let prev = this.Q([P[0][0], P[0][1]]);
        for (let i = 0; i < segs; i++) {
          const p0 = P[i];
          const p3 = P[(i + 1) % P.length];
          const len = Math.hypot(p3[0] - p0[0], p3[1] - p0[1]);
          const [l0, l1] = per === 5 ? [p0[4], p3[3]] : [len / 3, len / 3];
          const [d0, d1] = [dir(p0), dir(p3)];
          const c1 = [p0[0] + d0[0] * l0, p0[1] + d0[1] * l0];
          const c2 = [p3[0] - d1[0] * l1, p3[1] - d1[1] * l1];
          for (let k = 1; k <= 8; k++) {
            const t = k / 8;
            const u = 1 - t;
            const q = [0, 1].map((j) => u * u * u * p0[j] + 3 * u * u * t * c1[j] + 3 * u * t * t * c2[j] + t * t * t * p3[j]);
            const cur = this.Q(q);
            this.lines2.push([prev, cur]);
            prev = cur;
          }
        }
        return;
      }
      case 'PICTURE2':
      case 'PICTURE2{2}': {
        // PICTURE2 picture, a, b, mask: the picture on an a by b rectangle from the origin.
        need(3);
        const [w, h] = [+a[1] || 0, +a[2] || 0];
        if (w && h) this.pictures2.push({ pic: a[0], pts: [[0, 0], [w, 0], [w, h], [0, h]].map((q) => this.Q(q)) });
        return;
      }
      case 'TEXT2':
        need(3);
        return this.texts2.push({ at: this.Q([a[0], a[1]]), text: String(a[2]) });
      // Rich text: paragraphs of strings, text blocks of paragraphs, RICHTEXT2 places a block's lines.
      case 'PARAGRAPH':
        this.para = { name: String(a[0]), lines: [] };
        return;
      case 'PARATEXT':
        if (this.para) this.para.lines.push(a.map((x) => (typeof x === 'number' ? String(+x.toFixed(6)) : String(x))).join(''));
        return;
      case 'ENDPARAGRAPH':
        if (this.para) (this.paras ||= new Map()).set(this.para.name.toUpperCase(), this.para.lines.join(''));
        this.para = null;
        return;
      case 'TEXTBLOCK':
      case 'TEXTBLOCK_':
        (this.textBlocks ||= new Map()).set(String(a[0]).toUpperCase(), { anchor: a[2] || 1, angle: a[3] || 0, paras: a.slice(7).map((x) => String(x).toUpperCase()) });
        return;
      case 'RICHTEXT2': {
        need(3);
        const tb = this.textBlocks?.get(String(a[2]).toUpperCase());
        if (!tb) return;
        const lines = tb.paras.map((n) => this.paras?.get(n)).filter((x) => x != null && x !== '');
        // One line under another, about a 2.5 mm text's height apart at the drawing's scale.
        const step = (2.5 * (+this.vars.GLOB_SCALE || 100)) / 1000 * 1.3;
        lines.forEach((text, i) => this.texts2.push({ at: this.Q([a[0], a[1] - i * step]), text }));
        return;
      }
      case 'HOTSPOT2':
        need(2);
        this.hotspots.push([...this.Q([a[0], a[1]]), 0]);
        return;
      // Primitive bodies: vertices, edges, polygons, then BODY makes them.
      case 'VERT':
      case 'TEVE':
        this.verts.push(this.P([a[0] || 0, a[1] || 0, a[2] || 0]));
        return;
      case 'EDGE':
        // v1, v2, the polygons on its sides, status: 1 invisible, 2 an inner edge of a smooth surface.
        this.vedges.push([Math.round(a[0]) - 1, Math.round(a[1]) - 1, Math.round(a[4] || 0)]);
        return;
      case 'PGON':
      case 'PGON{2}':
      case 'PGON{3}': {
        // n, vect, status; PGON{2}/{3} add a wrapping method and, for some methods, a texture coordinate system
        // (origin and points on its x, y and z axes) before the edges.
        const n = Math.round(a[0]);
        let from = 3;
        let wrap = null;
        if (name !== 'PGON' && a.length >= 4 + n) {
          from = 4;
          const method = Math.round(a[3]) % 100;
          if (a.length >= 16 + n && method !== 0) {
            wrap = [0, 1, 2, 3].map((k) => this.P(a.slice(4 + 3 * k, 7 + 3 * k)));
            from = 16;
          }
          if (name === 'PGON{3}' && a.length > from + n) from = a.length - n;
        }
        const ids = a.slice(from, from + n).map((v) => Math.round(v));
        const pts = [];
        for (const id of ids) {
          const e = this.vedges[Math.abs(id) - 1];
          if (!e) continue;
          pts.push(this.verts[id > 0 ? e[0] : e[1]]);
        }
        if (pts.length >= 3 && pts.every(Boolean)) this.pgons.push({ pts, wrap });
        return;
      }
      case 'BODY':
        for (const pg of this.pgons) this.face(pg.pts, pg.wrap && this.matDef()?.tex ? frameUV(pg.pts, pg.wrap, this.matDef().tex) : null);
        // A body showing a picture (a tree's cut-out) has no outline: the picture's shape is its edge.
        if (!this.matDef()?.tex) for (const e of [...(this.baseEdges || []), ...this.edgesNow()]) this.placedEdge(e);
        this.verts = [];
        this.vedges = [];
        this.pgons = [];
        this.baseEdges = [];
        return;
      case 'BASE':
        // New numbering for vertices and edges; what is defined so far waits for BODY.
        this.baseEdges = [...(this.baseEdges || []), ...this.edgesNow()];
        this.verts = [];
        this.vedges = [];
        return;
      case 'GROUP': {
        // A group keeps its bodies in the coordinates it was defined in; PLACEGROUP puts them where the
        // transformations then in force say (a fixing defined once and placed along an edge).
        const name = String(a[0]);
        if (!this.groups.has(name)) this.groups.set(name, []);
        const g = this.groups.get(name);
        g.local = inv4(this.m);
        this.groupStack.push(g);
        return;
      }
      case 'ENDGROUP':
        this.groupStack.pop();
        return;
      case 'PLACEGROUP':
        for (const t of this.groups.get(String(a[0])) || []) {
          // Its triangles and edges, from the group's coordinates to where the current transformations put them.
          if (t.edge) this.placedEdge(t.edge.map((q) => ap4(this.m, q)));
          else this.tris.push({ ...t, a: ap4(this.m, t.a), b: ap4(this.m, t.b), c: ap4(this.m, t.c) });
        }
        return;
      case 'KILLGROUP':
        this.groups.delete(String(a[0]));
        return;
      case 'PUT':
        this.buffer.push(...a);
        return;
      case 'ELBOW': {
        // A bend of radius a[0] through a[1] degrees, a tube of radius a[2], in the x-z plane about the y axis.
        need(3);
        const [R, alpha, r] = a;
        const n = Math.max(4, Math.ceil(Math.abs(alpha) / 10));
        const ring = (t, k) => {
          const u = (k / 12) * Math.PI * 2;
          const cx = R - r * Math.cos(u);
          return [cx * Math.cos(t * D2R) - R, r * Math.sin(u), cx * Math.sin(t * D2R)];
        };
        for (let i = 0; i < n; i++)
          for (let k = 0; k < 12; k++) {
            const t0 = (alpha * i) / n;
            const t1 = (alpha * (i + 1)) / n;
            this.quad(ring(t0, k), ring(t1, k), ring(t1, k + 1), ring(t0, k + 1));
          }
        return;
      }
      case 'WALLHOLE2':
      case 'WALLHOLE2{2}':
      case 'WALLBLOCK2':
      case 'WALLBLOCK2{2}': {
        // n, then a header (WALLHOLE2: fill control, two pens, the fill's origin and angle; {2}: frame/fill,
        // category, distortion flags, two pens, origin, a 2 x 2 matrix and an inner radius), then x, y, status
        // per node as in POLY2_B. Only the cut part of the wall is affected.
        const head = name.endsWith('{2}') ? 13 : 7;
        need(head);
        const n = Math.round(a[0]);
        const poly = gdlPolygon(pts(head, 3).slice(0, n)).map((p) => this.Q(p));
        if (poly.length >= 3) (name.startsWith('WALLHOLE2') ? this.wallHoles2 : this.wallBlocks2).push(poly);
        return;
      }
      case 'WALLLINE2':
        need(4);
        return this.wallLines2.push([this.Q([a[0], a[1]]), this.Q([a[2], a[3]])]);
      case 'WALLARC2': {
        need(5);
        let a1 = a[4];
        while (a1 < a[3]) a1 += 360;
        const n = Math.max(2, Math.ceil(((a1 - a[3]) / 360) * 32));
        for (let i = 0; i < n; i++) {
          const u = (a[3] + ((a1 - a[3]) * i) / n) * D2R;
          const v = (a[3] + ((a1 - a[3]) * (i + 1)) / n) * D2R;
          this.wallLines2.push([this.Q([a[0] + a[2] * Math.cos(u), a[1] + a[2] * Math.sin(u)]), this.Q([a[0] + a[2] * Math.cos(v), a[1] + a[2] * Math.sin(v)])]);
        }
        return;
      }
      case 'POLY2_A':
      case 'POLY2_B':
      case 'POLY2_B{2}':
      case 'POLY2_B{3}':
      case 'POLY2_B{4}':
      case 'POLY2_B{5}':
      case 'POLY2_B{6}': {
        // Header values before the points: fill pens, then the fill's origin and direction in the later versions.
        const head = { POLY2_A: 3, POLY2_B: 4, 'POLY2_B{2}': 7, 'POLY2_B{3}': 10, 'POLY2_B{4}': 11, 'POLY2_B{5}': 13, 'POLY2_B{6}': 13 }[name];
        need(head);
        const n = Math.round(a[0]);
        const frameFill = Math.round(a[1]);
        const raw = pts(head, 3).slice(0, n);
        return this.polys2.push({ pts: gdlPolygon(raw).map((p) => this.Q(p)), fill: (frameFill & 2) === 2, frame: (frameFill & 1) === 1 || frameFill === 0 });
      }
      default:
        // Other SET and DEFINE forms (fills, line types, styles) do not change what this reader draws.
        if (/^(SET|DEFINE) /.test(name)) return;
        if (/^(PROJECT2|PROJECT2\{\d\})$/.test(name)) {
          this.project2 = true;
          return;
        }
        if (this.lenient) {
          this.unknown.set(name, (this.unknown.get(name) || 0) + 1);
          return;
        }
        throw new GdlError(`Unknown command ${name}`, line);
    }
  }

  push2(t) {
    this.stack2.push(this.m2);
    const [a, b, c, d, e, f] = this.m2;
    const [A, B, C, D, E, F] = t;
    this.m2 = [a * A + c * B, b * A + d * B, a * C + c * D, b * C + d * D, a * E + c * F + e, b * E + d * F + f];
  }
  Q(p) {
    const [a, b, c, d, e, f] = this.m2;
    return [a * p[0] + c * p[1] + e, b * p[0] + d * p[1] + f];
  }
}

/** Triangles of a simple counterclockwise polygon (ear clipping), as index triples. */
function earcutLoop(loop) {
  const idx = loop.map((_, i) => i);
  const out = [];
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const inside = (p, a, b, c) => cross(a, b, p) >= 0 && cross(b, c, p) >= 0 && cross(c, a, p) >= 0;
  let guard = 0;
  while (idx.length > 3 && guard++ < 10000) {
    let cut = false;
    for (let i = 0; i < idx.length; i++) {
      const ia = idx[(i - 1 + idx.length) % idx.length];
      const ib = idx[i];
      const ic = idx[(i + 1) % idx.length];
      const [a, b, c] = [loop[ia], loop[ib], loop[ic]];
      if (cross(a, b, c) <= 1e-12) continue;
      if (idx.some((j) => j !== ia && j !== ib && j !== ic && inside(loop[j], a, b, c))) continue;
      out.push(ia, ib, ic);
      idx.splice(i, 1);
      cut = true;
      break;
    }
    if (!cut) break;
  }
  if (idx.length === 3) out.push(...idx);
  return out;
}
