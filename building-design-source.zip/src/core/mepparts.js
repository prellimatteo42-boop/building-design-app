/**
 * More MEP, as in Archicad's MEP Modeler:
 *
 *   - in-line accessories on ducts and pipes (dampers, filters, silencers,
 *     fire dampers; valves, gate and check valves, meters): `mepAccessory`
 *     { hostId (the run), t (mm from the run's start), accessory, length? }
 *   - flexible segments between two connections: `mepFlex` { family:
 *     'duct' | 'pipe', levelId, points: [[x, y, z]] (control points),
 *     diameter, system }, a smooth curve through the points;
 *   - the Duct Size Optimizer and the Hydronics Optimizer: flows gathered
 *     from the terminals down each branch of a network, then sizes from a
 *     velocity limit (ducts: round diameter or rectangular width at the
 *     run's height; pipes: the nominal size from a list), with the friction
 *     loss per metre reported (Darcy-Weisbach, Swamee-Jain);
 *   - hydronic and electrical project settings.
 */
import { levelElevation } from './model.js';
import { mepSize, MEP_KINDS } from './mep.js';
import { runEnds, mepNetworks } from './mepnet.js';

// Accessories ---------------------------------------------------------------------------------------

export const ACCESSORIES = {
  duct: [
    { value: 'damper', label: 'Volume Damper', length: 200 },
    { value: 'fireDamper', label: 'Fire Damper', length: 300 },
    { value: 'filter', label: 'Filter', length: 400 },
    { value: 'silencer', label: 'Silencer', length: 900 },
  ],
  pipe: [
    { value: 'valve', label: 'Ball Valve', length: 3 },
    { value: 'gateValve', label: 'Gate Valve', length: 3 },
    { value: 'checkValve', label: 'Check Valve', length: 3.5 },
    { value: 'meter', label: 'Meter', length: 4 },
  ],
};

export const accessoryInfo = (family, value) => (ACCESSORIES[family] || []).find((a) => a.value === value) || ACCESSORIES[family]?.[0];

/**
 * Where an accessory sits: { c (3D centre), d (3D unit direction), size, length, family }. Pipe accessory lengths in
 * the list are multiples of the pipe diameter.
 */
export function accessoryFrame(doc, el) {
  const run = doc.get(el.hostId);
  if (!run || !MEP_KINDS.includes(run.kind)) return null;
  const [A, B] = runEnds(doc, run);
  const v = [B[0] - A[0], B[1] - A[1], B[2] - A[2]];
  const L = Math.hypot(v[0], v[1], v[2]);
  if (L < 1) return null;
  const d = [v[0] / L, v[1] / L, v[2] / L];
  const size = mepSize(doc, run);
  const family = run.kind === 'pipe' || run.kind === 'conduit' ? 'pipe' : 'duct';
  const info = accessoryInfo(family, el.accessory);
  const length = +el.length || (family === 'pipe' ? info.length * size.w : info.length);
  const t = Math.max(length / 2, Math.min(L - length / 2, el.t ?? L / 2));
  return { c: [A[0] + d[0] * t, A[1] + d[1] * t, A[2] + d[2] * t], d, size, length, family, run, info };
}

// Flexible segments ---------------------------------------------------------------------------------

/** Points along a Catmull-Rom curve (centripetal) through 3D control points. */
export function flexPath(points, perSpan = 12) {
  const P = points || [];
  if (P.length < 2) return P.slice();
  const out = [P[0]];
  const dist3 = (a, b) => Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
  for (let i = 0; i + 1 < P.length; i++) {
    const p0 = P[i - 1] || P[i].map((v, k) => 2 * v - P[i + 1][k]);
    const p1 = P[i];
    const p2 = P[i + 1];
    const p3 = P[i + 2] || p2.map((v, k) => 2 * v - p1[k]);
    const t1 = Math.sqrt(dist3(p0, p1)) || 1e-3;
    const t2 = t1 + (Math.sqrt(dist3(p1, p2)) || 1e-3);
    const t3 = t2 + (Math.sqrt(dist3(p2, p3)) || 1e-3);
    for (let s = 1; s <= perSpan; s++) {
      const t = t1 + ((t2 - t1) * s) / perSpan;
      const L = (a, b, ta, tb) => a.map((v, k) => (ta === tb ? v : ((tb - t) / (tb - ta)) * v + ((t - ta) / (tb - ta)) * b[k]));
      const A1 = L(p0, p1, 0, t1);
      const A2 = L(p1, p2, t1, t2);
      const A3 = L(p2, p3, t2, t3);
      const B1 = L(A1, A2, 0, t2);
      const B2 = L(A2, A3, t1, t3);
      out.push(L(B1, B2, t1, t2));
    }
  }
  return out;
}

/** Length of a flexible segment along its curve. */
export function flexLength(el) {
  const p = flexPath(el.points);
  let s = 0;
  for (let i = 1; i < p.length; i++) s += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1], p[i][2] - p[i - 1][2]);
  return s;
}

/** A connection point of an element for a flexible segment: { p (3D), dir (3D, pointing out) }, nearest `toward`. */
export function connectionOf(doc, el, toward) {
  if (MEP_KINDS.includes(el.kind)) {
    const [A, B] = runEnds(doc, el);
    const dA = Math.hypot(A[0] - toward[0], A[1] - toward[1]);
    const dB = Math.hypot(B[0] - toward[0], B[1] - toward[1]);
    const [p, q] = dA <= dB ? [A, B] : [B, A];
    const v = [p[0] - q[0], p[1] - q[1], p[2] - q[2]];
    const l = Math.hypot(v[0], v[1], v[2]) || 1;
    return { p, dir: [v[0] / l, v[1] / l, v[2] / l], size: mepSize(doc, el), system: el.system };
  }
  if (el.kind === 'component' && Array.isArray(el.at)) {
    const t = doc.get(el.typeId) || {};
    const z = levelElevation(doc, el.levelId) + (+(el.offset ?? el.elevation ?? t.elevation) || 0) + (+t.height || 0);
    return { p: [el.at[0], el.at[1], z], dir: [0, 0, 1], size: null, system: null };
  }
  return null;
}

/** A flexible segment (not added) joining two elements' nearest connections, leaving each along its direction. */
export function flexBetween(doc, a, b, family = 'duct') {
  const ca0 = connectionOf(doc, a, b.a || b.at || [0, 0]);
  const cb = ca0 && connectionOf(doc, b, ca0.p);
  const ca = cb && connectionOf(doc, a, cb.p);
  if (!ca || !cb) return null;
  const gap = Math.hypot(cb.p[0] - ca.p[0], cb.p[1] - ca.p[1], cb.p[2] - ca.p[2]);
  if (gap < 10) return null;
  const k = Math.min(gap / 3, 1500);
  const pts = [ca.p, ca.p.map((v, i) => v + ca.dir[i] * k), cb.p.map((v, i) => v + cb.dir[i] * k), cb.p].map((p) => p.map((v) => Math.round(v)));
  const d = (ca.size || cb.size)?.w || (family === 'pipe' ? 28 : 200);
  const lvl = a.levelId || b.levelId;
  // Control points are stored as heights above the level (like run offsets).
  const z0 = levelElevation(doc, lvl);
  return { kind: 'mepFlex', family, levelId: lvl, points: pts.map((p) => [p[0], p[1], p[2] - z0]), diameter: Math.round(d), system: ca.system || cb.system || undefined };
}

/** The 3D points of a flexible segment (absolute heights). */
export function flexPoints3D(doc, el) {
  const z0 = levelElevation(doc, el.levelId);
  return flexPath((el.points || []).map((p) => [p[0], p[1], (p[2] || 0) + z0]));
}

// Sizing ----------------------------------------------------------------------------------------------

export const HYDRONIC_DEFAULTS = { fluid: 'water', supply: 70, return: 55, maxVelocity: 1.0, maxDrop: 250 };
export const DUCT_SIZING_DEFAULTS = { maxVelocity: 5, terminalFlow: 150, round: false, step: 50 };
export const ELECTRICAL_DEFAULTS = { voltage: 230, phases: 1, threePhaseVoltage: 400, frequency: 50, powerFactor: 0.9, maxDrop: 4 };

export const FLUIDS = {
  water: { label: 'Water', rho: 977, cp: 4190, nu: 0.43e-6 },
  glycol30: { label: 'Ethylene glycol 30%', rho: 1040, cp: 3700, nu: 1.6e-6 },
  air: { label: 'Air', rho: 1.2, cp: 1005, nu: 15e-6 },
};

/** Nominal inside diameters of steel / copper pipes (mm), DN 10 to DN 150. */
export const PIPE_SIZES = [12.5, 16, 21.6, 27.3, 36, 41.9, 53.1, 68.9, 80.9, 105.3, 130, 155];

export const settingsOf = (project, key, defaults) => ({ ...defaults, ...(project?.[key] || {}) });

/** Friction loss per metre (Pa/m) of a flow in a round conduit: Darcy-Weisbach with Swamee-Jain. */
export function frictionPerMetre(velocity, diameterMm, fluid = FLUIDS.water, roughnessMm = 0.05) {
  const D = diameterMm / 1000;
  if (D <= 0 || velocity <= 0) return 0;
  const Re = (velocity * D) / fluid.nu;
  const f = Re < 2300 ? 64 / Re : 0.25 / Math.log10(roughnessMm / 1000 / (3.7 * D) + 5.74 / Re ** 0.9) ** 2;
  return (f / D) * ((fluid.rho * velocity * velocity) / 2);
}

/**
 * Flow carried by each run of a network: the sum of the terminal flows beyond it, seen from the root (the open end
 * or terminal named, else the network's first open end). flowOf(terminal) gives each terminal's flow.
 * Returns Map(runId -> flow).
 */
export function branchFlows(doc, net, flowOf, rootPoint = null) {
  const runs = net.runs.map((id) => doc.get(id));
  const ends = new Map(runs.map((r) => [r.id, runEnds(doc, r)]));
  const near = (p, q, tol = 5) => Math.abs(p[0] - q[0]) <= tol && Math.abs(p[1] - q[1]) <= tol && Math.abs(p[2] - q[2]) <= tol * 3;
  // Children of a run entered at one end: runs starting at its other end, and runs teeing into its length.
  const children = (r, exit) => {
    const er = ends.get(r.id);
    const out = [];
    for (const s of runs) {
      if (s.id === r.id) continue;
      const es = ends.get(s.id);
      const at = es.findIndex((q) => near(q, exit));
      if (at >= 0) out.push({ s, entry: es[at] });
      else {
        const t = es.findIndex((q) => onRun(q, er));
        if (t >= 0) out.push({ s, entry: es[t] });
        // A run this one tees into: entered at the tee, flowing both ways is not handled (treated as a child).
        else if (onRun(exit, es)) out.push({ s, entry: exit, through: true });
      }
    }
    return out;
  };
  const terminals = net.terminals.map((id) => doc.get(id)).filter(Boolean);
  // Each terminal hangs on its nearest run end.
  const at = new Map();
  for (const t of terminals) {
    let best = null;
    for (const r of runs) for (const p of ends.get(r.id)) {
      const d = Math.hypot(p[0] - t.at[0], p[1] - t.at[1]);
      if (!best || d < best.d) best = { d, id: r.id };
    }
    if (best) at.set(best.id, (at.get(best.id) || 0) + (+flowOf(t) || 0));
  }
  const root = rootPoint || net.openEnds[0]?.p || ends.get(runs[0].id)[0];
  const first = runs.reduce((b, r) => {
    const d = Math.min(...ends.get(r.id).map((p) => Math.hypot(p[0] - root[0], p[1] - root[1], p[2] - root[2])));
    return !b || d < b.d ? { r, d } : b;
  }, null).r;
  const flows = new Map();
  const seen = new Set();
  const visit = (r, entry) => {
    seen.add(r.id);
    const e = ends.get(r.id);
    const exit = near(e[0], entry, 50) ? e[1] : e[0];
    let q = at.get(r.id) || 0;
    for (const { s } of children(r, exit)) if (!seen.has(s.id)) q += visit(s, ends.get(s.id).reduce((b, p) => (Math.hypot(p[0] - exit[0], p[1] - exit[1], p[2] - exit[2]) < Math.hypot(b[0] - exit[0], b[1] - exit[1], b[2] - exit[2]) ? p : b)));
    flows.set(r.id, q);
    return q;
  };
  const fe = ends.get(first.id);
  visit(first, Math.hypot(fe[0][0] - root[0], fe[0][1] - root[1], fe[0][2] - root[2]) <= Math.hypot(fe[1][0] - root[0], fe[1][1] - root[1], fe[1][2] - root[2]) ? fe[0] : fe[1]);
  return flows;
}

function onRun(p, [a, b]) {
  const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const l2 = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];
  if (l2 < 1) return false;
  const t = ((p[0] - a[0]) * d[0] + (p[1] - a[1]) * d[1] + (p[2] - a[2]) * d[2]) / l2;
  if (t <= 0.01 || t >= 0.99) return false;
  return Math.hypot(a[0] + d[0] * t - p[0], a[1] + d[1] * t - p[1], a[2] + d[2] * t - p[2]) <= 50;
}

const ceilStep = (v, step) => Math.max(step, Math.ceil(v / step) * step);

/**
 * Duct Size Optimizer: sizes for the ducts of the networks (or of the given duct ids), from each air terminal's
 * flow (its `flow` in m³/h, else the default) and the velocity limit. Returns [{ id, flow, size: { diameter } |
 * { width, height }, velocity, drop }] (not applied).
 */
export function ductSizes(doc, ids = null, opts = DUCT_SIZING_DEFAULTS) {
  const o = { ...DUCT_SIZING_DEFAULTS, ...opts };
  const out = [];
  for (const net of mepNetworks(doc).filter((n) => n.kind === 'duct')) {
    if (ids && !net.runs.some((r) => ids.includes(r))) continue;
    const flows = branchFlows(doc, net, (t) => +t.flow || o.terminalFlow);
    for (const [id, q] of flows) {
      if (ids && !ids.includes(id)) continue;
      const run = doc.get(id);
      const qs = q / 3600; // m³/s
      if (qs <= 0) continue;
      const area = qs / o.maxVelocity; // m²
      const cur = mepSize(doc, run);
      let size;
      let dh;
      let a;
      if (cur.round || o.round) {
        const D = ceilStep(Math.sqrt((4 * area) / Math.PI) * 1000, o.step);
        size = { diameter: D };
        dh = D;
        a = (Math.PI * (D / 1000) ** 2) / 4;
      } else {
        const h = cur.h;
        const w = ceilStep((area / (h / 1000)) * 1000, o.step);
        size = { width: w, height: h };
        dh = (2 * w * h) / (w + h);
        a = (w / 1000) * (h / 1000);
      }
      const v = qs / a;
      out.push({ id, flow: Math.round(q), size, velocity: Math.round(v * 100) / 100, drop: Math.round(frictionPerMetre(v, dh, FLUIDS.air, 0.09) * 100) / 100 });
    }
  }
  return out;
}

/**
 * Hydronics Optimizer: pipe sizes for hydronic networks from the terminals' heat outputs (`power` in W, else
 * 1500 W), the temperature drop and the velocity and friction limits. Returns [{ id, flow (l/h), diameter,
 * velocity, drop }].
 */
export function pipeSizes(doc, ids = null, settings = HYDRONIC_DEFAULTS) {
  const s = { ...HYDRONIC_DEFAULTS, ...settings };
  const fluid = FLUIDS[s.fluid] || FLUIDS.water;
  const dT = Math.max(1, Math.abs(s.supply - s.return));
  const out = [];
  for (const net of mepNetworks(doc).filter((n) => n.kind === 'pipe')) {
    if (ids && !net.runs.some((r) => ids.includes(r))) continue;
    const runs = net.runs.map((id) => doc.get(id));
    if (!ids && !runs.some((r) => r.system === 'hydronic')) continue;
    const flows = branchFlows(doc, net, (t) => +t.power || 1500);
    for (const [id, P] of flows) {
      if (ids && !ids.includes(id)) continue;
      const m = P / (fluid.cp * dT); // kg/s
      const qs = m / fluid.rho; // m³/s
      if (qs <= 0) continue;
      let D = PIPE_SIZES.at(-1);
      let v = 0;
      let drop = 0;
      for (const d of PIPE_SIZES) {
        v = qs / ((Math.PI * (d / 1000) ** 2) / 4);
        drop = frictionPerMetre(v, d, fluid);
        if (v <= s.maxVelocity && drop <= s.maxDrop) {
          D = d;
          break;
        }
      }
      v = qs / ((Math.PI * (D / 1000) ** 2) / 4);
      out.push({ id, flow: Math.round(qs * 3.6e6), diameter: D, velocity: Math.round(v * 100) / 100, drop: Math.round(frictionPerMetre(v, D, fluid)) });
    }
  }
  return out;
}

/** Apply sizes from ductSizes / pipeSizes (inside a transaction). */
export function applySizes(doc, sizes) {
  for (const r of sizes) {
    const el = doc.get(r.id);
    if (!el) continue;
    if (r.size) doc.update(el.id, r.size.diameter ? { diameter: r.size.diameter, shape: 'round', flow: r.flow } : { width: r.size.width, height: r.size.height, flow: r.flow });
    else doc.update(el.id, { diameter: r.diameter, flow: r.flow });
  }
}

// Equipment ---------------------------------------------------------------------------------------

export const EQUIPMENT_CATEGORIES = [
  { value: 'mechanical', label: 'Mechanical equipment (ducts, pipes)' },
  { value: 'airTerminals', label: 'Air terminal (ducts)' },
  { value: 'plumbing', label: 'Plumbing fixture (pipes)' },
  { value: 'electricalEquipment', label: 'Electrical equipment (trays, conduits)' },
];

/** Convert Selection to Equipment: components that MEP runs connect to (their own category overrides the type's). */
export function convertToEquipment(doc, ids, category = 'mechanical') {
  let n = 0;
  for (const id of ids) {
    const el = doc.get(id);
    if (el?.kind !== 'component') continue;
    doc.update(id, { category, mepEquipment: true });
    n++;
  }
  return n;
}
