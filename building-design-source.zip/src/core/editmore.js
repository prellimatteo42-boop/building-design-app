/**
 * Edit menu helpers: Stretch (the points of elements inside a box move, the
 * rest stay) and hatch recognition (many parallel lines, evenly spaced, are
 * a hatch that a fill can stand for).
 */
const inBox = (p, b) => p[0] >= b.x0 && p[0] <= b.x1 && p[1] >= b.y0 && p[1] <= b.y1;
const moved = (p, d) => [p[0] + d[0], p[1] + d[1]];

const ENDS = ['wall', 'detailLine', 'modelLine', 'beam', 'brace', 'duct', 'pipe', 'cableTray', 'conduit', 'roomSeparator'];
const POLYS = ['region', 'floor', 'roof', 'ceiling', 'mass', 'propertyLine'];

/** Patches for the elements with points inside the box, moved by d: [{ id, patch }]. Elements wholly inside just move. */
export function stretchPatches(doc, ids, box, d) {
  const out = [];
  for (const id of ids) {
    const el = doc.get(id);
    if (!el) continue;
    if (ENDS.includes(el.kind) && el.a && el.b) {
      const patch = {};
      if (inBox(el.a, box)) patch.a = moved(el.a, d);
      if (inBox(el.b, box)) patch.b = moved(el.b, d);
      if (Object.keys(patch).length) out.push({ id, patch });
    } else if (el.path && (el.kind === 'polyline' || el.kind === 'spline')) {
      if (el.path.some((p) => inBox(p, box))) out.push({ id, patch: { path: el.path.map((p) => (inBox(p, box) ? moved(p, d) : p)) } });
    } else if (POLYS.includes(el.kind) && el.boundary) {
      if (el.boundary.some((p) => inBox(p, box))) out.push({ id, patch: { boundary: el.boundary.map((p) => (inBox(p, box) ? moved(p, d) : p)) } });
    }
  }
  return out;
}

const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);

/** The convex hull of points, counter-clockwise. */
export function convexHull(points) {
  const pts = [...points].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  if (pts.length < 3) return pts;
  const half = (list) => {
    const out = [];
    for (const p of list) {
      while (out.length >= 2 && cross(out[out.length - 2], out[out.length - 1], p) <= 0) out.pop();
      out.push(p);
    }
    out.pop();
    return out;
  };
  return [...half(pts), ...half(pts.reverse())];
}

/**
 * Hatches among lines [{ id, a, b, style }]: sets of at least minCount
 * parallel lines side by side at an even spacing: [{ ids, angle, spacing, outline }].
 */
export function findHatches(lines, { minCount = 6, maxSpacing = 1000, tolDeg = 0.5, tolRatio = 0.15 } = {}) {
  const groups = new Map();
  for (const l of lines) {
    const dx = l.b[0] - l.a[0];
    const dy = l.b[1] - l.a[1];
    if (Math.hypot(dx, dy) < 1) continue;
    let a = (Math.atan2(dy, dx) * 180) / Math.PI;
    if (a < 0) a += 180;
    if (a >= 180 - tolDeg) a -= 180;
    const k = `${l.style || ''}|${Math.round(a / tolDeg)}`;
    groups.set(k, [...(groups.get(k) || []), { l, a }]);
  }
  const out = [];
  for (const list of groups.values()) {
    if (list.length < minCount) continue;
    const ang = (list[0].a * Math.PI) / 180;
    const nrm = [-Math.sin(ang), Math.cos(ang)];
    const dir = [Math.cos(ang), Math.sin(ang)];
    const off = list.map(({ l }) => ({ l, h: l.a[0] * nrm[0] + l.a[1] * nrm[1], s0: Math.min(l.a[0] * dir[0] + l.a[1] * dir[1], l.b[0] * dir[0] + l.b[1] * dir[1]), s1: Math.max(l.a[0] * dir[0] + l.a[1] * dir[1], l.b[0] * dir[0] + l.b[1] * dir[1]) })).sort((a, b) => a.h - b.h);
    // Runs at one spacing, side by side.
    let start = 0;
    const flush = (end) => {
      if (end - start >= minCount) {
        const run = off.slice(start, end);
        const gaps = run.slice(1).map((r, i) => r.h - run[i].h);
        const spacing = gaps.reduce((s, g) => s + g, 0) / gaps.length;
        out.push({ ids: run.map((r) => r.l.id), angle: list[0].a, spacing, outline: convexHull(run.flatMap((r) => [r.l.a, r.l.b])) });
      }
    };
    let i = 2;
    while (i <= off.length) {
      if (i === off.length) {
        flush(i);
        break;
      }
      const ref = off[start + 1].h - off[start].h;
      const gap = off[i].h - off[i - 1].h;
      // A new stretch where the spacing breaks, or the line stops overlapping the one before.
      const overlaps = Math.min(off[i].s1, off[i - 1].s1) > Math.max(off[i].s0, off[i - 1].s0);
      if (ref <= 0 || ref > maxSpacing || gap > maxSpacing || Math.abs(gap - ref) > ref * tolRatio || !overlaps) {
        const taken = i - start >= minCount;
        flush(i);
        // The last line of a stretch too short to count can begin the next one.
        start = taken ? i : i - 1;
        i = start + 2;
      } else i++;
    }
  }
  return out;
}
