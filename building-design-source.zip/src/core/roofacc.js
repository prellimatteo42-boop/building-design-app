/**
 * Roof accessories, as Archicad's Roof Accessory objects: a fascia board
 * along the eaves, a gutter hung on it and downpipes from the gutter ends
 * to the ground, following the eaves of the roof (the outline edges at its
 * lowest height).
 */

/** Eave edges of a roof outline: [{ a, b, z, n }] with z the edge height and n the outward normal. */
export function eaveEdges(poly, hAt, tol = 1) {
  const n = poly.length;
  if (n < 3) return [];
  let s = 0;
  for (let i = 0; i < n; i++) s += poly[i][0] * poly[(i + 1) % n][1] - poly[(i + 1) % n][0] * poly[i][1];
  const ccw = s > 0;
  const zs = poly.map(hAt);
  const zmin = Math.min(...zs);
  const out = [];
  for (let i = 0; i < n; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % n];
    const za = zs[i];
    const zb = zs[(i + 1) % n];
    // Level along its whole length (a gable end is low only at its corners).
    if (Math.abs(za - zb) > tol || Math.abs(za - zmin) > tol || Math.abs(hAt([(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]) - za) > tol) continue;
    const d = [b[0] - a[0], b[1] - a[1]];
    const l = Math.hypot(d[0], d[1]);
    if (l < 1) continue;
    const nn = ccw ? [d[1] / l, -d[0] / l] : [-d[1] / l, d[0] / l];
    out.push({ a, b, z: za, n: nn });
  }
  return out;
}

/** A box swept along a horizontal segment: across u0..u1 (outward), up v0..v1 from z. */
function sweptBox(b, e, z, u0, u1, v0, v1, col) {
  const d = [e.b[0] - e.a[0], e.b[1] - e.a[1]];
  const P = (pt, u, v) => [pt[0] + e.n[0] * u, pt[1] + e.n[1] * u, z + v];
  const ring = (pt) => [P(pt, u0, v0), P(pt, u1, v0), P(pt, u1, v1), P(pt, u0, v1)];
  const A = ring(e.a);
  const B = ring(e.b);
  // Sides, wound to face outward whichever way the edge runs.
  const flip = d[0] * e.n[1] - d[1] * e.n[0] > 0;
  for (let k = 0; k < 4; k++) {
    const k2 = (k + 1) % 4;
    if (flip) b.quad(A[k], B[k], B[k2], A[k2], col);
    else b.quad(A[k], A[k2], B[k2], B[k], col);
  }
  if (flip) {
    b.quad(A[0], A[3], A[2], A[1], col);
    b.quad(B[0], B[1], B[2], B[3], col);
  } else {
    b.quad(A[0], A[1], A[2], A[3], col);
    b.quad(B[0], B[3], B[2], B[1], col);
  }
}

/**
 * Add fascia, gutters and downpipes to a roof mesh. opts: { fascia, gutters,
 * downpipes, top (roof thickness at the eave), ground (z), colors }.
 */
export function addRoofAccessories(b, edges, { fascia = false, gutters = false, downpipes = false, top = 250, ground = 0, colors }) {
  const fT = 25;
  const gw = 125;
  const gd = 110;
  for (const e of edges) {
    if (fascia) sweptBox(b, e, e.z, 0, fT, -60, top + 10, colors.fascia);
    if (gutters) {
      const u0 = fascia ? fT : 0;
      const zt = e.z + top - 20;
      sweptBox(b, e, zt, u0, u0 + gw, -gd, -gd + 6, colors.gutter);
      sweptBox(b, e, zt, u0, u0 + 6, -gd, 0, colors.gutter);
      sweptBox(b, e, zt, u0 + gw - 6, u0 + gw, -gd, -10, colors.gutter);
      if (downpipes) {
        const L = Math.hypot(e.b[0] - e.a[0], e.b[1] - e.a[1]);
        const d = [(e.b[0] - e.a[0]) / L, (e.b[1] - e.a[1]) / L];
        const u = u0 + gw / 2;
        for (const [pt, s] of [[e.a, 1], [e.b, -1]]) {
          const c = [pt[0] + d[0] * s * Math.min(200, L / 4) + e.n[0] * u, pt[1] + d[1] * s * Math.min(200, L / 4) + e.n[1] * u];
          b.cylinder(c, 40, ground, zt - gd, colors.gutter, { segments: 12 });
        }
      }
    }
  }
}
