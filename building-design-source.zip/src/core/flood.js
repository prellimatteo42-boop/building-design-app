/**
 * Rooms read the way a person reads a plan: the walls are painted solid on
 * a fine grid and the free floor is flooded from a point inside the room.
 * What the flood reaches is the room: its area, and its outline traced
 * around the painted cells.
 */
import { signedArea } from './geom.js';

/**
 * A grid over a box (mm) with cells of `cell` mm. paint(polys) fills
 * polygons solid (even-odd per polygon); flood(p) returns the free cells
 * reached from p, or null when the flood reaches the grid's edge (outside).
 */
export class FloorGrid {
  constructor(box, cell) {
    this.cell = cell;
    this.x0 = box.x0;
    this.y0 = box.y0;
    this.w = Math.max(1, Math.ceil((box.x1 - box.x0) / cell));
    this.h = Math.max(1, Math.ceil((box.y1 - box.y0) / cell));
    this.solid = new Uint8Array(this.w * this.h);
  }

  /** A copy to paint more on. */
  clone() {
    const g = Object.create(FloorGrid.prototype);
    Object.assign(g, this, { solid: this.solid.slice() });
    return g;
  }

  /** Paint polygons solid: each cell whose centre is inside. */
  paint(polys) {
    const { w, h, cell, x0, y0, solid } = this;
    for (const poly of polys) {
      if (poly.length < 3) continue;
      let ymin = Infinity;
      let ymax = -Infinity;
      for (const p of poly) {
        if (p[1] < ymin) ymin = p[1];
        if (p[1] > ymax) ymax = p[1];
      }
      const r0 = Math.max(0, Math.floor((ymin - y0) / cell));
      const r1 = Math.min(h - 1, Math.ceil((ymax - y0) / cell));
      for (let r = r0; r <= r1; r++) {
        const y = y0 + (r + 0.5) * cell;
        const xs = [];
        for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
          const a = poly[j];
          const b = poly[i];
          if ((a[1] > y) !== (b[1] > y)) xs.push(a[0] + ((y - a[1]) * (b[0] - a[0])) / (b[1] - a[1]));
        }
        xs.sort((p, q) => p - q);
        for (let k = 0; k + 1 < xs.length; k += 2) {
          const c0 = Math.max(0, Math.ceil((xs[k] - x0) / cell - 0.5));
          const c1 = Math.min(w - 1, Math.floor((xs[k + 1] - x0) / cell - 0.5));
          for (let c = c0; c <= c1; c++) solid[r * w + c] = 1;
        }
      }
    }
  }

  /** The free cells reached from p (a Uint32Array of indices), or null when it leaks out of the grid. */
  flood(p, limit = Infinity) {
    const { w, h, cell, x0, y0, solid } = this;
    const c = Math.floor((p[0] - x0) / cell);
    const r = Math.floor((p[1] - y0) / cell);
    if (c < 0 || r < 0 || c >= w || r >= h || solid[r * w + c]) return null;
    const seen = new Uint8Array(w * h);
    const stack = [r * w + c];
    seen[r * w + c] = 1;
    const out = [];
    while (stack.length) {
      const i = stack.pop();
      out.push(i);
      if (out.length > limit) return null;
      const x = i % w;
      const y = (i / w) | 0;
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) return null;
      for (const j of [i - 1, i + 1, i - w, i + w]) {
        if (!seen[j] && !solid[j]) {
          seen[j] = 1;
          stack.push(j);
        }
      }
    }
    return Uint32Array.from(out);
  }

  /** The free cells reachable from the grid's edge (1 = outside), as a mask. */
  outside() {
    const { w, h, solid } = this;
    const seen = new Uint8Array(w * h);
    const stack = [];
    const push = (i) => {
      if (!seen[i] && !solid[i]) {
        seen[i] = 1;
        stack.push(i);
      }
    };
    for (let x = 0; x < w; x++) {
      push(x);
      push((h - 1) * w + x);
    }
    for (let y = 0; y < h; y++) {
      push(y * w);
      push(y * w + w - 1);
    }
    while (stack.length) {
      const i = stack.pop();
      const x = i % w;
      if (x > 0) push(i - 1);
      if (x < w - 1) push(i + 1);
      if (i >= w) push(i - w);
      if (i < (h - 1) * w) push(i + w);
    }
    return seen;
  }

  /** Paint solid every cell set in a mask. */
  paintMask(mask) {
    for (let i = 0; i < mask.length; i++) if (mask[i]) this.solid[i] = 1;
  }

  /** Whether a solid cell lies within r mm of p. */
  solidNear(p, r) {
    const { w, h, cell, x0, y0, solid } = this;
    const n = Math.ceil(r / cell);
    const c = Math.floor((p[0] - x0) / cell);
    const q = Math.floor((p[1] - y0) / cell);
    for (let y = Math.max(0, q - n); y <= Math.min(h - 1, q + n); y++)
      for (let x = Math.max(0, c - n); x <= Math.min(w - 1, c + n); x++) if (solid[y * w + x]) return true;
    return false;
  }

  /** The outer outline (mm) of a set of cells, its corners only, simplified to tol mm. */
  outline(cells, tol = this.cell * 1.5) {
    const { w, cell, x0, y0 } = this;
    const inside = new Set(cells);
    // Directed boundary edges with the region on their left, by grid corner.
    const next = new Map();
    const key = (x, y) => y * (w + 1) + x;
    const add = (ax, ay, bx, by) => next.set(key(ax, ay), [bx, by]);
    for (const i of cells) {
      const x = i % w;
      const y = (i / w) | 0;
      if (!inside.has(i - w)) add(x, y, x + 1, y);
      if (!inside.has(i + 1)) add(x + 1, y, x + 1, y + 1);
      if (!inside.has(i + w)) add(x + 1, y + 1, x, y + 1);
      if (!inside.has(i - 1)) add(x, y + 1, x, y);
    }
    // Walk every loop; the outer one has the largest area.
    const used = new Set();
    let best = null;
    for (const [k0, first] of next) {
      if (used.has(k0)) continue;
      const loop = [];
      let k = k0;
      let p = [k0 % (w + 1), Math.floor(k0 / (w + 1))];
      for (let guard = 0; guard < next.size + 1 && !used.has(k); guard++) {
        used.add(k);
        loop.push(p);
        p = next.get(k);
        if (!p) break;
        k = key(p[0], p[1]);
      }
      const area = Math.abs(signedArea(loop));
      if (!best || area > best.area) best = { loop, area };
      void first;
    }
    if (!best) return [];
    const pts = best.loop.map(([x, y]) => [x0 + x * cell, y0 + y * cell]);
    return simplify(dropCollinear(pts), tol);
  }
}

function dropCollinear(pts) {
  return pts.filter((p, i) => {
    const a = pts[(i - 1 + pts.length) % pts.length];
    const b = pts[(i + 1) % pts.length];
    return Math.abs((p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0])) > 1e-6;
  });
}

/** Douglas-Peucker on a closed loop. */
export function simplify(pts, tol) {
  if (pts.length < 4) return pts;
  // Split at the two points furthest apart, simplify each half.
  let i0 = 0;
  let i1 = 0;
  let far = -1;
  for (let i = 0; i < pts.length; i++) {
    const d = (pts[i][0] - pts[0][0]) ** 2 + (pts[i][1] - pts[0][1]) ** 2;
    if (d > far) (far = d), (i1 = i);
  }
  const half = (from, to) => {
    const seq = [];
    for (let i = from; ; i = (i + 1) % pts.length) {
      seq.push(pts[i]);
      if (i === to) break;
    }
    return dp(seq, tol);
  };
  const a = half(i0, i1);
  const b = half(i1, i0);
  return [...a.slice(0, -1), ...b.slice(0, -1)];
}

function dp(seq, tol) {
  if (seq.length < 3) return seq;
  const a = seq[0];
  const b = seq.at(-1);
  const L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
  let idx = -1;
  let dmax = 0;
  for (let i = 1; i < seq.length - 1; i++) {
    const d = Math.abs((b[0] - a[0]) * (a[1] - seq[i][1]) - (a[0] - seq[i][0]) * (b[1] - a[1])) / L;
    if (d > dmax) (dmax = d), (idx = i);
  }
  if (dmax <= tol) return [a, b];
  return [...dp(seq.slice(0, idx + 1), tol).slice(0, -1), ...dp(seq.slice(idx), tol)];
}
