/**
 * Skylights, as in Archicad: windows in a roof. A skylight sits on the roof
 * face under its point `at`, `width` across the slope and `length` along it,
 * and cuts its own hole through the roof (the roof's holes plus its
 * skylights', roofHoles). Its frame and glass lie on the face's plane.
 * skylight { kind: 'skylight', hostId (roof), levelId, at, width, length }
 */
import { MeshBuilder } from './mesh.js';
import { add, scale, perp, pointInPolygon, ensureCCW } from './geom.js';
import { roofGeometry } from './build3d.js';
import { planeHeight, verticalThickness } from './roof.js';

/** The roof face under a point: its plane (null when flat) and geometry. */
function faceAt(doc, roof, p) {
  const g = roofGeometry(doc, roof);
  const f = g.faces.find((x) => pointInPolygon(p, x.poly)) || g.faces[0];
  return { g, plane: f?.plane ?? null };
}

/** Plan rectangle of a skylight's opening, with its up-slope direction. */
export function skylightGeometry(doc, sk) {
  const roof = doc.get(sk.hostId);
  if (!roof || roof.kind !== 'roof' || !roof.boundary?.length || !sk.at) return null;
  const { g, plane } = faceAt(doc, roof, sk.at);
  const up = plane ? plane.m : [0, 1];
  const across = perp(up);
  const w = (+sk.width || 780) / 2;
  // Its length lies along the slope: shorter seen from above.
  const l = ((+sk.length || 980) * (plane ? Math.cos((plane.slope * Math.PI) / 180) : 1)) / 2;
  const P = (a, b) => add(add(sk.at, scale(across, a)), scale(up, b));
  // Counterclockwise, as the roof's holes are cut (build3d.js).
  const poly = ensureCCW([P(-w, -l), P(w, -l), P(w, l), P(-w, l)]);
  const top = (p) => g.base + (plane ? planeHeight(plane, p) : 0) + verticalThickness(g.th, plane);
  return { roof, poly, plane, top };
}

/** Holes of a roof: its own and its skylights'. */
export function roofHoles(doc, roof) {
  const holes = (roof.holes || []).filter((h) => h.length >= 3);
  for (const el of doc.all('skylight')) {
    if (el.hostId !== roof.id) continue;
    const s = skylightGeometry(doc, el);
    if (s) holes.push(s.poly);
  }
  return holes;
}

/** Frame and glass on the roof's top surface. */
export function buildSkylight(doc, sk, frameCol, glassCol) {
  const s = skylightGeometry(doc, sk);
  if (!s) return null;
  const b = new MeshBuilder();
  const up3 = (p, dz) => [p[0], p[1], s.top(p) + dz];
  const F = 70; // frame width
  const H = 120; // frame height above the roof
  for (let i = 0; i < 4; i++) {
    const p = s.poly[i];
    const q = s.poly[(i + 1) % 4];
    const a = up3(p, H / 2);
    const c = up3(q, H / 2);
    b.beam3(a, c, F, H, frameCol);
  }
  // The glass, a little below the frame's top.
  const g = s.poly.map((p) => up3(p, H - 30));
  b.quad(g[0], g[1], g[2], g[3], glassCol);
  b.quad(g[3], g[2], g[1], g[0], glassCol);
  return b.build();
}
