/**
 * Trusses: chords and web members generated between two points.
 *
 *   truss      { levelId, a, b, offset, height?, typeId }
 *   trussType  { pattern, height, panels, chord, web, materialId }
 *
 * Patterns: 'pratt' and 'howe' (flat, verticals and diagonals), 'warren'
 * (flat, diagonals only), 'fink' and 'kingpost' (pitched, for roofs). The
 * bottom chord sits at the level plus the offset.
 *
 * TrussMaker and Edit Truss: a truss can carry its own members instead of
 * the pattern, truss.members [{ a: [s, z], b: [s, z], role: 'chord' | 'web',
 * size?, profileId? }] (s along the truss from a, z above the bottom chord),
 * from lines drawn as the truss's elevation or edited one by one. A member
 * with a complex profile (its own, or the type's chordProfileId /
 * webProfileId) is that section swept along it; otherwise a square bar.
 */
import { add, sub, scale, norm, perp, dist } from './geom.js';
import { MeshBuilder, hexToRgba } from './mesh.js';
import { levelElevation } from './model.js';
import { W } from './plan.js';
import { profilerMesh } from './profiler.js';

export const PATTERNS = [
  { value: 'pratt', label: 'Pratt (flat)' },
  { value: 'howe', label: 'Howe (flat)' },
  { value: 'warren', label: 'Warren (flat)' },
  { value: 'fink', label: 'Fink (pitched)' },
  { value: 'kingpost', label: 'King post (pitched)' },
];

/** Members as pairs of points in (s along the truss, z above the bottom chord). */
export function trussMembers(pattern, length, height, panels) {
  const n = Math.max(2, Math.round(panels) || 4);
  const L = length;
  const H = height;
  const out = { chords: [], webs: [] };
  const pitched = pattern === 'fink' || pattern === 'kingpost';
  const top = (s) => (pitched ? H * (1 - Math.abs(2 * s - L) / L) : H);
  out.chords.push([[0, 0], [L, 0]]);
  if (pitched) out.chords.push([[0, 0], [L / 2, H]], [[L / 2, H], [L, 0]]);
  else out.chords.push([[0, H], [L, H]], [[0, 0], [0, H]], [[L, 0], [L, H]]);
  if (pattern === 'kingpost') {
    out.webs.push([[L / 2, 0], [L / 2, H]]);
    return out;
  }
  if (pattern === 'fink') {
    // W-shaped webs.
    const q = [L / 3, (2 * L) / 3];
    out.webs.push([[q[0], 0], [L / 4, top(L / 4)]], [[q[0], 0], [L / 2, H]], [[q[1], 0], [L / 2, H]], [[q[1], 0], [(3 * L) / 4, top((3 * L) / 4)]]);
    return out;
  }
  const xs = Array.from({ length: n + 1 }, (_, i) => (L * i) / n);
  for (let i = 1; i < n; i++) if (pattern !== 'warren') out.webs.push([[xs[i], 0], [xs[i], H]]);
  for (let i = 0; i < n; i++) {
    const x0 = xs[i];
    const x1 = xs[i + 1];
    const leftHalf = (x0 + x1) / 2 < L / 2;
    if (pattern === 'warren') out.webs.push(i % 2 === 0 ? [[x0, 0], [x1, H]] : [[x0, H], [x1, 0]]);
    // Pratt diagonals slope down toward the middle, Howe ones up toward it.
    else if ((pattern === 'pratt') === leftHalf) out.webs.push([[x0, H], [x1, 0]]);
    else out.webs.push([[x0, 0], [x1, H]]);
  }
  return out;
}

/** The pattern's members as an editable list [{ a, b, role }]. */
export function memberList(members) {
  return [...members.chords.map(([a, b]) => ({ a: [...a], b: [...b], role: 'chord' })), ...members.webs.map(([a, b]) => ({ a: [...a], b: [...b], role: 'web' }))];
}

export function trussGeometry(doc, el) {
  const t = doc.get(el.typeId) || {};
  const L = dist(el.a, el.b);
  if (L < 100) return null;
  const H = +el.height || +t.height || 1500;
  const z0 = levelElevation(doc, el.levelId) + (+el.offset || 0);
  const dir = norm(sub(el.b, el.a));
  if (Array.isArray(el.members) && el.members.length) {
    const own = el.members.filter((m) => m?.a && m?.b);
    return { t, L, H: Math.max(...own.flatMap((m) => [m.a[1], m.b[1]]), 0), z0, dir, own, members: { chords: own.filter((m) => m.role === 'chord').map((m) => [m.a, m.b]), webs: own.filter((m) => m.role !== 'chord').map((m) => [m.a, m.b]) } };
  }
  const members = trussMembers(t.pattern || 'pratt', L, H, +t.panels || Math.max(2, Math.round(L / 1500)));
  return { t, L, H, z0, dir, own: memberList(members), members };
}

/** Section shapes of a complex profile centred on its middle (beam profiles stand on y = 0). */
function centredShapes(prof) {
  const pts = prof.shapes.flatMap((sh) => sh.poly);
  const cx = (Math.min(...pts.map((p) => p[0])) + Math.max(...pts.map((p) => p[0]))) / 2;
  const cy = (Math.min(...pts.map((p) => p[1])) + Math.max(...pts.map((p) => p[1]))) / 2;
  const mv = (p) => [p[0] - cx, p[1] - cy];
  return prof.shapes.map((sh) => ({ ...sh, poly: sh.poly.map(mv), holes: (sh.holes || []).map((h) => h.map(mv)) }));
}

/**
 * TrussMaker: members from lines drawn as the truss's elevation (x along, y up in the drawing), set between
 * plan points a and b. The lines are taken from the drawing's lowest, leftmost corner; lines on the drawing's
 * outline become chords, the others webs. Returns { members, length, height } or null.
 */
export function membersFromLines(lines, tol = 5) {
  const segs = lines.filter((l) => l?.a && l?.b && Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1]) > 1);
  if (!segs.length) return null;
  const xs = segs.flatMap((l) => [l.a[0], l.b[0]]);
  const ys = segs.flatMap((l) => [l.a[1], l.b[1]]);
  const x0 = Math.min(...xs);
  const y0 = Math.min(...ys);
  const x1 = Math.max(...xs);
  const y1 = Math.max(...ys);
  const loc = (p) => [Math.round(p[0] - x0), Math.round(p[1] - y0)];
  // Outline: lines on the box's sides, or along the hull of all end points.
  const pts = segs.flatMap((l) => [loc(l.a), loc(l.b)]);
  const hull = convexHull(pts);
  const onHull = (p, q) => {
    for (let i = 0; i < hull.length; i++) {
      const u = hull[i];
      const v = hull[(i + 1) % hull.length];
      const d = (r) => Math.abs((v[0] - u[0]) * (r[1] - u[1]) - (v[1] - u[1]) * (r[0] - u[0])) / (Math.hypot(v[0] - u[0], v[1] - u[1]) || 1);
      if (d(p) <= tol && d(q) <= tol) return true;
    }
    return false;
  };
  const members = segs.map((l) => {
    const a = loc(l.a);
    const b = loc(l.b);
    return { a, b, role: onHull(a, b) ? 'chord' : 'web' };
  });
  return { members, length: x1 - x0, height: y1 - y0 };
}

function convexHull(points) {
  const p = [...new Map(points.map((q) => [`${q[0]},${q[1]}`, q])).values()].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  if (p.length < 3) return p;
  const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lower = [];
  for (const q of p) {
    while (lower.length >= 2 && cr(lower.at(-2), lower.at(-1), q) <= 0) lower.pop();
    lower.push(q);
  }
  const upper = [];
  for (const q of p.slice().reverse()) {
    while (upper.length >= 2 && cr(upper.at(-2), upper.at(-1), q) <= 0) upper.pop();
    upper.push(q);
  }
  return [...lower.slice(0, -1), ...upper.slice(0, -1)];
}

export function buildTruss(ctx, el) {
  const g = trussGeometry(ctx.doc, el);
  if (!g) return null;
  const mat = ctx.material(g.t.materialId);
  const col = hexToRgba(mat?.color || '#8a8f96', 1);
  const P = ([s, z]) => [el.a[0] + g.dir[0] * s, el.a[1] + g.dir[1] * s, g.z0 + z];
  const b = new MeshBuilder();
  const n = perp(g.dir);
  const up = [n[0], n[1], 0];
  const chord = +g.t.chord || 120;
  const web = +g.t.web || 80;
  // Chords and webs are square members set side by side within the truss's plane, or their complex profiles.
  const parts = [];
  for (const m of g.own) {
    const pid = m.profileId || (m.role === 'chord' ? g.t.chordProfileId : g.t.webProfileId);
    const prof = pid ? ctx.doc.get(pid) : null;
    if (prof?.shapes?.length) {
      const r = profilerMesh(ctx.doc, { mode: 'extrude', shapes: centredShapes(prof), path: [P(m.a), P(m.b)] }, () => col);
      if (r) parts.push(r.mesh);
      continue;
    }
    const size = +m.size || (m.role === 'chord' ? chord : web);
    b.beam3(P(m.a), P(m.b), size, size, col, { up });
  }
  if (!parts.length) return b.build();
  const base = b.build();
  return mergeMeshes([base, ...parts]);
}

export function planTruss(pc, el, b) {
  if (el.levelId !== pc.view.levelId || pc.ceiling || !el.a || !el.b) return;
  const g = trussGeometry(pc.doc, el);
  if (!g) return;
  const w = (+g.t.chord || 120) / 2;
  const n = perp(g.dir);
  const poly = [add(el.a, scale(n, -w)), add(el.b, scale(n, -w)), add(el.b, scale(n, w)), add(el.a, scale(n, w))];
  b.poly(poly, true, W.light, 0);
  // Panel points along the truss.
  for (const [p, q] of g.members.webs) for (const s of [p[0], q[0]]) {
    const c = add(el.a, scale(g.dir, s));
    b.line(add(c, scale(n, -w)), add(c, scale(n, w)), W.thin);
  }
  const pad = Math.max(w, 1.2 * pc.scale);
  b.pick([add(el.a, scale(n, -pad)), add(el.b, scale(n, -pad)), add(el.b, scale(n, pad)), add(el.a, scale(n, pad))]);
}

/** One mesh from several built meshes (positions, normals, colours, edges and bounds). */
function mergeMeshes(list) {
  const ms = list.filter((m) => m?.pos?.length || m?.edges?.length);
  const total = (k) => ms.reduce((t, m) => t + (m[k]?.length || 0), 0);
  const pos = new Float32Array(total('pos'));
  const nrm = new Int8Array(total('nrm'));
  const col = new Uint8Array(total('col'));
  const edges = new Float32Array(total('edges'));
  const off = { pos: 0, nrm: 0, col: 0, edges: 0 };
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  for (const m of ms) {
    for (const [k, arr] of [['pos', pos], ['nrm', nrm], ['col', col], ['edges', edges]])
      if (m[k]?.length) {
        arr.set(m[k], off[k]);
        off[k] += m[k].length;
      }
    if (m.bounds)
      for (let i = 0; i < 3; i++) {
        min[i] = Math.min(min[i], m.bounds.min[i]);
        max[i] = Math.max(max[i], m.bounds.max[i]);
      }
  }
  return { pos, nrm, col, edges, bounds: Number.isFinite(min[0]) ? { min, max } : null };
}
