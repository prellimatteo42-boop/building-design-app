/**
 * Classification, as in Archicad's Classification Manager: classification
 * systems hold a tree of items (a code, a name and the IFC entity elements
 * of that item export as); each element has an item of each system, set by
 * hand or taken from its kind and category.
 *
 *   classSystem { kind: 'classSystem', name, edition, items: [{ code, name, parent, ifc, kinds, cats }] }
 *   element     classes: { [systemId]: code }, optional; without it, the item that matches the element
 */
import { categoryOf } from './catalog.js';
import { layered } from './layers.js';

const I = (code, name, ifc, match = {}, parent = null) => ({ code, name, parent, ifc, kinds: match.kinds || [], cats: match.cats || [] });

/** The project's own system, by element function, with IFC entities. */
function defaultItems() {
  return [
    I('10', 'Structure and Envelope', null),
    I('10.10', 'Wall', 'IfcWall', { kinds: ['wall'] }, '10'),
    I('10.11', 'Curtain Wall', 'IfcCurtainWall', {}, '10'),
    I('10.20', 'Slab', 'IfcSlab', { kinds: ['floor', 'footing', 'slabFoundation'] }, '10'),
    I('10.30', 'Roof', 'IfcRoof', { kinds: ['roof', 'shell'] }, '10'),
    I('10.40', 'Column', 'IfcColumn', { kinds: ['column'] }, '10'),
    I('10.50', 'Beam', 'IfcBeam', { kinds: ['beam', 'brace', 'truss'] }, '10'),
    I('10.60', 'Footing', 'IfcFooting', { kinds: ['wallFooting'], cats: ['structuralFoundations'] }, '10'),
    I('20', 'Openings', null),
    I('20.10', 'Door', 'IfcDoor', { kinds: ['door'] }, '20'),
    I('20.20', 'Window', 'IfcWindow', { kinds: ['window', 'skylight'] }, '20'),
    I('20.30', 'Opening', 'IfcOpeningElement', { kinds: ['opening', 'shaft'] }, '20'),
    I('30', 'Circulation', null),
    I('30.10', 'Stair', 'IfcStair', { kinds: ['stair'] }, '30'),
    I('30.20', 'Ramp', 'IfcRamp', { kinds: ['ramp'] }, '30'),
    I('30.30', 'Railing', 'IfcRailing', { kinds: ['railing'] }, '30'),
    I('40', 'Finishes', null),
    I('40.10', 'Ceiling', 'IfcCovering', { kinds: ['ceiling'] }, '40'),
    I('40.20', 'Covering', 'IfcCovering', { kinds: ['wallSweep', 'wallCladding', 'roofAccessory', 'roomAccessory', 'slabAccessory'] }, '40'),
    I('50', 'Furnishing and Equipment', null),
    I('50.10', 'Furniture', 'IfcFurniture', { cats: ['furniture', 'casework'] }, '50'),
    I('50.20', 'Sanitary Terminal', 'IfcSanitaryTerminal', { cats: ['plumbing'] }, '50'),
    I('50.30', 'Appliance', 'IfcElectricAppliance', { cats: ['equipment'] }, '50'),
    I('50.40', 'Light Fixture', 'IfcLightFixture', { cats: ['lighting'] }, '50'),
    I('50.50', 'Planting', 'IfcGeographicElement', { cats: ['planting'] }, '50'),
    I('50.60', 'Site Furnishing', 'IfcFurniture', { cats: ['site', 'parking', 'entourage'] }, '50'),
    I('60', 'Building Services', null),
    I('60.10', 'Duct Segment', 'IfcDuctSegment', { kinds: ['duct'] }, '60'),
    I('60.20', 'Pipe Segment', 'IfcPipeSegment', { kinds: ['pipe'] }, '60'),
    I('60.30', 'Cable Carrier', 'IfcCableCarrierSegment', { kinds: ['cableTray', 'conduit'] }, '60'),
    I('60.40', 'Air Terminal', 'IfcAirTerminal', { cats: ['airTerminals'] }, '60'),
    I('60.50', 'Fire Suppression Terminal', 'IfcFireSuppressionTerminal', { cats: ['sprinklers'] }, '60'),
    I('60.60', 'Mechanical Equipment', 'IfcUnitaryEquipment', { cats: ['mechanical'] }, '60'),
    I('60.70', 'Electrical Equipment', 'IfcElectricDistributionBoard', { cats: ['electricalEquipment'] }, '60'),
    I('60.80', 'Outlet or Switch', 'IfcOutlet', { cats: ['electricalFixtures'] }, '60'),
    I('70', 'Spaces and Site', null),
    I('70.10', 'Space', 'IfcSpace', { kinds: ['room', 'space'] }, '70'),
    I('70.20', 'Terrain', 'IfcGeographicElement', { kinds: ['topo'] }, '70'),
    I('90', 'General', null),
    I('90.10', 'Building Element', 'IfcBuildingElementProxy', { kinds: ['morph', 'mass', 'genericModel'] }, '90'),
  ];
}

/** Classification systems of a new project. */
export function defaultClassSystems() {
  return [{ id: 'cs-default', kind: 'classSystem', name: 'Building Design Classification', edition: '1.0', items: defaultItems() }];
}

/** Whether an element can be classified. */
export function classifiable(doc, el) {
  return layered(doc, el) && !['dimension', 'tag', 'text', 'detailLine', 'region', 'image', 'spot', 'symbol'].includes(el.kind) && el.kind !== 'grid' && el.kind !== 'level';
}

/** The item of a system that fits an element by its kind, then by its category. */
export function autoClass(doc, el, system) {
  const items = system?.items || [];
  const cat = categoryOf(el, doc);
  // Subtype - Classification Mapping: the project's own choice for this category comes first.
  const mapped = doc.get('project')?.subtypeMap?.[system?.id]?.[cat];
  if (mapped) {
    const it = items.find((i) => i.code === mapped);
    if (it) return it;
  }
  return items.find((i) => i.kinds?.includes(el.kind)) || items.find((i) => cat && i.cats?.includes(cat)) || null;
}

/** An element's item in a system: its own choice ('' for none), else the fitting one. */
export function classOf(doc, el, system) {
  if (!system) return null;
  const own = el.classes?.[system.id];
  if (own !== undefined) return own === '' ? null : system.items.find((i) => i.code === own) || null;
  return autoClass(doc, el, system);
}

/** Items in tree order with their depth: [{ item, depth }]. */
export function classTree(system) {
  const items = system?.items || [];
  const out = [];
  const walk = (parent, depth) => {
    for (const i of items.filter((x) => (x.parent || null) === parent).sort((a, b) => a.code.localeCompare(b.code, undefined, { numeric: true }))) {
      out.push({ item: i, depth });
      walk(i.code, depth + 1);
    }
  };
  walk(null, 0);
  // Items whose parent is missing still show, at the top.
  for (const i of items) if (!out.some((o) => o.item === i)) out.push({ item: i, depth: 0 });
  return out;
}

/** "10.10 Wall", or "" for none. */
export function classLabel(item) {
  return item ? `${item.code} ${item.name}` : '';
}

/**
 * Items read from CSV text: one per line, "code, name[, parent code[, IFC entity]]";
 * a parent is also taken from the code (10.10 sits under 10).
 */
export function parseClassCSV(text) {
  const items = [];
  for (const raw of String(text).split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const cells = line.split(/[;,\t]/).map((c) => c.trim().replace(/^"|"$/g, ''));
    if (!cells[0] || /^code$/i.test(cells[0])) continue;
    items.push({ code: cells[0], name: cells[1] || cells[0], parent: cells[2] || null, ifc: cells[3] || null, kinds: [], cats: [] });
  }
  const codes = new Set(items.map((i) => i.code));
  for (const i of items)
    if (!i.parent) {
      const m = /^(.*)[.\-_ ][^.\-_ ]+$/.exec(i.code);
      if (m && codes.has(m[1])) i.parent = m[1];
    }
  return items;
}
