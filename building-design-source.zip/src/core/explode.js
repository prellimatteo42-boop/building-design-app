/**
 * Explode, as in Archicad's Explode into Current View and Save as
 * Worksheet: the plan graphics of elements turned into drafting (detail
 * lines, fills and text) that can be edited freely, in the same view or in
 * a new drafting view.
 */
import { PATTERN, W } from './plan.js';

const PATTERN_NAME = Object.fromEntries(Object.entries(PATTERN).map(([k, v]) => [v, k]));

/** The built-in line style closest to a line's weight and dash. */
export function styleOfLine(l) {
  if (l.d === 1) return 'dashed';
  if (l.d === 2) return 'hidden';
  if (l.d === 3) return 'center';
  if (l.w >= W.cut) return 'wide';
  if (l.w >= W.medium) return 'medium';
  return 'thin';
}

const key = (p) => `${Math.round(p[0])},${Math.round(p[1])}`;

/**
 * Drafting items from plan builders drawn at a view scale: { lines: [{ a, b, style }],
 * fills: [{ boundary, holes, pattern }], texts: [{ at, text, size, rotation, align, bold }] }.
 * Masks and faint colour washes are left out; repeated lines are kept once.
 */
export function explodeGraphics(builders, scale = 100) {
  const out = { lines: [], fills: [], texts: [] };
  const seen = new Set();
  for (const g of builders) {
    if (!g) continue;
    for (const l of g.lines || []) {
      const k = [key(l.a), key(l.b)].sort().join('|');
      if (seen.has(k) || (Math.abs(l.a[0] - l.b[0]) < 0.5 && Math.abs(l.a[1] - l.b[1]) < 0.5)) continue;
      seen.add(k);
      out.lines.push({ a: [...l.a], b: [...l.b], style: styleOfLine(l) });
    }
    for (const f of g.fills || []) {
      const c = f.color || [];
      const mask = c[0] === -2;
      const pat = f.pattern ? PATTERN_NAME[f.pattern] || null : null;
      // Plain ink fills become a gray tone or solid by how dark they are; colour washes are left out.
      const tone = c[0] === -1 ? (c[3] >= 180 ? 'solid' : c[3] >= 80 ? 'none' : null) : null;
      if (mask || !(pat || tone)) continue;
      out.fills.push({ boundary: f.poly.map((p) => [...p]), holes: (f.holes || []).map((hh) => hh.map((p) => [...p])), pattern: pat || tone });
    }
    for (const t of g.texts || []) {
      if (!t.text) continue;
      out.texts.push({ at: [...t.at], text: t.text, size: Math.round((t.size / scale) * 10) / 10 || 2.5, rotation: ((t.rot || 0) * 180) / Math.PI, align: t.align || 'center', bold: !!t.bold });
    }
  }
  return out;
}

/** Add exploded drafting to a view (inside a transaction); returns the new ids. */
export function addExploded(doc, viewId, parts) {
  const ids = [];
  for (const l of parts.lines) ids.push(doc.add({ kind: 'detailLine', viewId, a: l.a, b: l.b, style: l.style }).id);
  for (const f of parts.fills) ids.push(doc.add({ kind: 'region', viewId, boundary: f.boundary, holes: f.holes, pattern: f.pattern, outline: false }).id);
  for (const t of parts.texts) ids.push(doc.add({ kind: 'text', viewId, at: t.at, text: t.text, size: t.size, rotation: t.rotation, align: t.align, bold: t.bold }).id);
  return ids;
}
