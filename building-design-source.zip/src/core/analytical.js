/**
 * Structural analytical model, as Archicad's: the load-bearing elements
 * reduced to what a structural analysis program takes. Columns, beams and
 * braces become curve members on their axes (with a rectangular or round
 * section and a material); walls and slabs become surface members on their
 * mid-planes (with a thickness); their ends meet in shared nodes. As
 * Archicad's model does, members are moved to meet: a wall or column ends
 * on the mid-plane of the slab it reaches, and a beam end near a column
 * lands on the column's axis. Supports and loads of the physical model
 * (structural.js) attach to nodes and members.
 *
 * Exported as SAF (Structural Analysis Format, saf.guide): an Excel
 * workbook with one sheet per kind of object, in metres, read by most
 * analysis programs.
 *
 * Which walls and slabs carry load: those marked Structural; when no wall
 * or slab is marked, all of them.
 */
import { safCases, loadCombinations, combinationRows } from './structcombos.js';
import { verticalExtent, levelElevation, wallAxis } from './model.js';
import { typeThickness } from './catalog.js';
import { pointInPolygon } from './geom.js';
import { selfWeight } from './structural.js';

/**
 * Generation rules (Archicad: Structural Analytical Model Generation Rules), kept in project.analyticalRules:
 * tol, how near ends share a node (mm); bearing, which walls and slabs carry load ('auto': the marked ones, or all
 * when none is marked; 'marked'; 'all'); meetSlabs, walls and columns end on slab mid-planes; beamsToColumns, beam
 * ends near a column land on its axis.
 */
/** The depth and width standing for a member that varies: by the end, the average or the larger end. */
export function varyingSection(mode, d0, w0, d1, w1) {
  if (mode === 'start') return [d0, w0];
  if (mode === 'end') return [d1, w1];
  if (mode === 'max') return [Math.max(d0, d1), Math.max(w0, w1)];
  return [(d0 + d1) / 2, (w0 + w1) / 2];
}

export const ANALYTICAL_RULES = { tol: 20, bearing: 'auto', meetSlabs: true, beamsToColumns: true, varyingProfile: 'average' };

/** How a member's ends connect: rigid, or hinged (free to rotate about its cross-section axes). */
export const END_RELEASES = [
  { value: 'rigid', label: 'Rigid at both ends' },
  { value: 'begin', label: 'Hinged at start' },
  { value: 'end', label: 'Hinged at end' },
  { value: 'both', label: 'Hinged at both ends' },
];

const MAT_KIND = [
  [/concrete|cls|calcestruzzo|cement/i, 'Concrete', 'C25/30', 31000, 2500],
  [/steel|acciaio|metal|iron/i, 'Steel', 'S235', 210000, 7850],
  [/alumin/i, 'Aluminium', 'EN-AW 6060', 70000, 2700],
  [/wood|timber|lumber|legno|glulam|clt|plywood/i, 'Timber', 'C24', 11000, 420],
  [/brick|block|masonry|mattone|laterizio|stone|pietra/i, 'Masonry', 'M10', 5000, 1800],
];

/** SAF material of a building material: type, quality, E modulus (MPa) and density (kg/m³). */
export function safMaterial(mat) {
  const name = mat?.name || 'Concrete';
  const hit = MAT_KIND.find(([re]) => re.test(`${name} ${mat?.class || ''}`)) || [null, 'Other', 'Default', 10000, +mat?.density || 2000];
  return { name, type: hit[1], quality: hit[2], e: hit[3], density: +mat?.density || hit[4] };
}

/** Whether a point lies within d of a polygon's outline. */
function nearOutline(p, poly, d) {
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const l2 = dx * dx + dy * dy || 1;
    const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2));
    if (Math.hypot(p[0] - a[0] - dx * t, p[1] - a[1] - dy * t) <= d) return true;
  }
  return false;
}

/** The load-bearing material of a layered type: its structure layer, else its thickest. */
function coreLayer(type) {
  const layers = type?.layers || [];
  return layers.find((l) => l.function === 'structure') || [...layers].sort((a, b) => (+b.thickness || 0) - (+a.thickness || 0))[0] || null;
}

/** Thickness that carries load: the structure layers, else the whole type. */
function coreThickness(type) {
  const s = (type?.layers || []).filter((l) => l.function === 'structure').reduce((t, l) => t + (+l.thickness || 0), 0);
  return s || typeThickness(type) || 200;
}

/**
 * The analytical model: { nodes: [{ name, p }], members, surfaces, supports, edgeSupports, loads, materials, sections, notes }.
 * Lengths in mm, as the rest of the model. opts.tol: how near two ends must be to share a node (mm).
 */
export function analyticalModel(doc, opts = {}) {
  const rules = { ...ANALYTICAL_RULES, ...doc.get('project')?.analyticalRules, ...opts };
  const tol = +rules.tol || 20;
  const notes = [];
  const walls = doc.all('wall');
  const floors = doc.all('floor');
  const marked = [...walls, ...floors].some((el) => el.structural);
  if (rules.bearing === 'auto' && !marked && (walls.length || floors.length)) notes.push('No wall or slab is marked Structural: all of them are taken as load-bearing.');
  const bearing = (el) => (rules.bearing === 'all' ? el.structural !== false : rules.bearing === 'marked' || marked ? !!el.structural : el.structural !== false);

  // Slab mid-planes, used to meet walls and columns.
  const slabs = floors.filter(bearing).map((f) => {
    const type = doc.get(f.typeId);
    const top = levelElevation(doc, f.levelId) + (+f.offset || 0);
    const t = typeThickness(type) || 200;
    return { el: f, top, t, z: top - t / 2, boundary: f.boundary || [] };
  });
  /** The mid-plane height an end at (x, y, z) reaches: a slab whose thickness it touches, else z itself. */
  const meet = (p, z) => {
    if (!rules.meetSlabs) return z;
    let best = null;
    for (const s of slabs) {
      if (s.boundary.length < 3 || !(pointInPolygon(p, s.boundary) || nearOutline(p, s.boundary, 300))) continue;
      // An end reaches a slab when it stops within the slab's thickness (or just past it).
      const near = z >= s.top - s.t - 50 && z <= s.top + 50;
      if (near && (!best || Math.abs(s.z - z) < Math.abs(best.z - z))) best = s;
    }
    return best ? best.z : z;
  };

  const nodes = [];
  const node = (p) => {
    for (const n of nodes) if (Math.abs(n.p[0] - p[0]) <= tol && Math.abs(n.p[1] - p[1]) <= tol && Math.abs(n.p[2] - p[2]) <= tol) return n.name;
    const name = `N${nodes.length + 1}`;
    nodes.push({ name, p: p.map((v) => Math.round(v * 10) / 10) });
    return name;
  };

  const materials = new Map();
  const materialOf = (matId) => {
    const m = safMaterial(doc.get(matId));
    if (!materials.has(m.name)) materials.set(m.name, m);
    return m.name;
  };
  const sections = new Map();
  const sectionOf = (shape, params, mat) => {
    const name = `${shape === 'Circle' ? 'D' : 'R'}${params.join('x')} ${mat}`;
    if (!sections.has(name)) sections.set(name, { name, shape, params, material: mat });
    return name;
  };

  // Columns: axis from base to top, ends moved to the slabs they reach.
  const members = [];
  const columns = [];
  for (const c of doc.all('column')) {
    if (c.structural === false || !c.at) continue;
    const type = doc.get(c.typeId) || {};
    const { base, top } = verticalExtent(doc, c);
    const z0 = meet(c.at, base);
    const z1 = meet(c.at, top);
    const w = +type.width || 450;
    const d = +type.depth || w;
    const mat = materialOf(type.materialId || 'mat-concrete');
    const sec = type.shape === 'round' ? sectionOf('Circle', [w], mat) : sectionOf('Rectangle', [d, w], mat);
    const r = ((+c.rotation || 0) * Math.PI) / 180;
    const m = { name: `C${columns.length + 1}`, id: c.id, type: 'Column', a: [c.at[0], c.at[1], z0], b: [c.at[0], c.at[1], z1], section: sec, y: [Math.cos(r), Math.sin(r), 0], internal: [], half: Math.max(w, d) / 2 };
    columns.push(m);
    members.push(m);
  }
  // Beams and braces: centroid axis; an end close to a column lands on its axis.
  let nb = 0;
  for (const b of [...doc.all('beam'), ...doc.all('brace')]) {
    if (b.structural === false || !b.a || !b.b) continue;
    const type = doc.get(b.typeId) || {};
    const w = +type.width || 300;
    const d = +type.depth || 600;
    const lv = levelElevation(doc, b.levelId);
    let za;
    let zb;
    if (b.kind === 'brace') {
      za = lv + (+b.offset || 0);
      zb = lv + (+(b.endOffset ?? b.topOffset ?? 3000));
    } else {
      za = lv + (+b.offset || 0) - d / 2;
      zb = b.endOffset != null ? lv + +b.endOffset - d / 2 : za;
    }
    const ends = [
      [b.a[0], b.a[1], za],
      [b.b[0], b.b[1], zb],
    ].map((p) => {
      for (const c of rules.beamsToColumns ? columns : []) {
        const dxy = Math.hypot(p[0] - c.a[0], p[1] - c.a[1]);
        if (dxy <= c.half + w / 2 + 1 && p[2] >= c.a[2] - 1 && p[2] <= c.b[2] + 1) {
          const q = [c.a[0], c.a[1], p[2]];
          if (Math.abs(p[2] - c.a[2]) > tol && Math.abs(p[2] - c.b[2]) > tol) c.internal.push(q);
          return q;
        }
      }
      return p;
    });
    const dir = [ends[1][0] - ends[0][0], ends[1][1] - ends[0][1]];
    const L = Math.hypot(...dir) || 1;
    const mat = materialOf(type.materialId || 'mat-concrete');
    const [secD, secW] = varyingSection(rules.varyingProfile, d, w, +b.endDepth || d, +b.endWidth || w);
    members.push({ name: `B${++nb}`, id: b.id, type: b.kind === 'brace' ? 'WallBracing' : 'Beam', a: ends[0], b: ends[1], section: sectionOf('Rectangle', [secD, secW], mat), y: [-dir[1] / L, dir[0] / L, 0], internal: [], release: b.endRelease && b.endRelease !== 'rigid' ? b.endRelease : null });
  }

  // Surfaces: walls on their mid-plane from the slab below to the slab above; slabs at mid-depth.
  const surfaces = [];
  let nw = 0;
  for (const w of walls) {
    if (!bearing(w) || !w.a || !w.b) continue;
    const type = doc.get(w.typeId);
    const ax = wallAxis(doc, w);
    const mid = [(ax.a[0] + ax.b[0]) / 2, (ax.a[1] + ax.b[1]) / 2];
    const { base, top } = verticalExtent(doc, w);
    const z0 = meet(mid, base);
    const z1 = meet(mid, top);
    const corners = [
      [ax.a[0], ax.a[1], z0],
      [ax.b[0], ax.b[1], z0],
      [ax.b[0], ax.b[1], z1],
      [ax.a[0], ax.a[1], z1],
    ];
    surfaces.push({ name: `W${++nw}`, id: w.id, type: 'Wall', corners, thickness: coreThickness(type), material: materialOf(coreLayer(type)?.materialId || 'mat-concrete'), x: [ax.dir[0], ax.dir[1], 0] });
  }
  let ns = 0;
  for (const s of slabs) {
    if (s.boundary.length < 3) continue;
    const type = doc.get(s.el.typeId);
    surfaces.push({ name: `S${++ns}`, id: s.el.id, type: 'Plate', corners: s.boundary.map((p) => [p[0], p[1], s.z]), thickness: coreThickness(type), material: materialOf(coreLayer(type)?.materialId || 'mat-concrete'), x: [1, 0, 0], selfWeight: selfWeight(doc, type) });
  }

  // Nodes, shared where ends meet.
  for (const m of members) {
    m.nodes = [node(m.a), node(m.b)];
    m.internalNodes = [...new Set(m.internal.map(node))].filter((n) => !m.nodes.includes(n));
    m.length = Math.hypot(m.b[0] - m.a[0], m.b[1] - m.a[1], m.b[2] - m.a[2]);
  }
  for (const s of surfaces) s.nodes = s.corners.map(node);

  // Structural links (Archicad's Structural Link): rigid connections between two points, with hinges.
  const links = [];
  for (const l of doc.all('structuralLink')) {
    if (!Array.isArray(l.a) || !Array.isArray(l.b)) continue;
    const na = node(l.a);
    const nb = node(l.b);
    if (na !== nb) links.push({ name: `RL${links.length + 1}`, id: l.id, nodes: [na, nb], hinge: l.hinge || 'none' });
  }

  // Supports: at a node (point) or along the bottom edge of a wall (line).
  const supports = [];
  const edgeSupports = [];
  const nearestNode = (p, max = 300) => {
    let best = null;
    let bd = max;
    for (const n of nodes) {
      const d = Math.hypot(n.p[0] - p[0], n.p[1] - p[1], n.p[2] - p[2]);
      if (d <= bd) (bd = d), (best = n.name);
    }
    return best;
  };
  for (const s of doc.all('structuralSupport')) {
    const z = levelElevation(doc, s.levelId) + (+s.offset || 0);
    const host = surfaces.find((x) => x.id === s.hostId && x.type === 'Wall');
    if (host) {
      edgeSupports.push({ name: `ES${edgeSupports.length + 1}`, surface: host.name, edge: 1, fixity: s.fixity || 'pinned' });
      continue;
    }
    const pts = s.at ? [[s.at[0], s.at[1], z]] : s.a && s.b ? [[s.a[0], s.a[1], z], [s.b[0], s.b[1], z]] : [];
    for (const p of pts) {
      let n = nearestNode(p);
      // A support under a column foot meets the column's lowest node.
      if (!n) {
        const col = columns.find((c) => Math.hypot(c.a[0] - p[0], c.a[1] - p[1]) <= c.half + 1);
        if (col) n = col.nodes[0];
      }
      if (n && !supports.some((x) => x.node === n)) supports.push({ name: `PS${supports.length + 1}`, node: n, fixity: s.fixity || 'fixed' });
      else if (!n) notes.push('A support was not near any node and was left out.');
    }
  }

  // Loads: surface loads on their slab, point loads at the nearest node. Self-weight is the program's.
  const loads = [];
  for (const l of doc.all('structuralLoad')) {
    if (l.auto && l.loadCase === 'dead') continue;
    const value = +l.value || 0;
    if (!value) continue;
    if (l.type === 'surface') {
      const host = surfaces.find((x) => x.id === l.hostId) || surfaces.find((x) => x.type === 'Plate' && l.boundary?.length && pointInPolygon(l.boundary[0], x.corners.map((c) => [c[0], c[1]])));
      if (host) loads.push({ name: `SA${loads.length + 1}`, kind: 'surface', surface: host.name, value, loadCase: l.loadCase || 'live' });
      else notes.push('A surface load is not on a load-bearing slab and was left out.');
    } else if (l.type === 'point' && l.at) {
      const n = nearestNode([l.at[0], l.at[1], levelElevation(doc, l.levelId) + (+l.offset || 0)], 500);
      if (n) loads.push({ name: `PA${loads.length + 1}`, kind: 'point', node: n, value, loadCase: l.loadCase || 'live' });
      else notes.push('A point load is not at a node and was left out.');
    } else if (l.type === 'line' && l.a && l.b) {
      // On the beam it lies on, else on the top edge of the wall under it.
      const beam = members.find((m) => m.id === l.hostId && m.type !== 'Column');
      const wall = surfaces.find((x) => x.id === l.hostId && x.type === 'Wall');
      if (beam) loads.push({ name: `LA${loads.length + 1}`, kind: 'line', member: beam.name, value, loadCase: l.loadCase || 'live' });
      else if (wall) loads.push({ name: `LA${loads.length + 1}`, kind: 'line', surface: wall.name, edge: 3, value, loadCase: l.loadCase || 'live' });
      else {
        const mid = [(l.a[0] + l.b[0]) / 2, (l.a[1] + l.b[1]) / 2];
        const under = surfaces.find((x) => x.type === 'Wall' && nearOutline(mid, [x.corners[0], x.corners[1]].map((c) => [c[0], c[1]]), 300));
        if (under) loads.push({ name: `LA${loads.length + 1}`, kind: 'line', surface: under.name, edge: 3, value, loadCase: l.loadCase || 'live' });
        else notes.push('A line load is not on a beam or a load-bearing wall and was left out.');
      }
    }
  }
  const used = [...new Set(loads.map((l) => l.loadCase))];
  const combinations = loadCombinations(doc.get('project'), used);
  return { nodes, members, surfaces, supports, edgeSupports, loads, links, combinations, materials: [...materials.values()], sections: [...sections.values()], notes: [...new Set(notes)] };
}

const M = (v) => Math.round(v) / 1000; // mm to m, to the millimetre

/** The SAF units table (saf.guide, annexes): metric unit -> imperial unit and how many of it make one metric. */
const SAF_IMPERIAL = { m: ['ft', 1 / 0.3048], mm: ['in', 1 / 25.4], kN: ['kip', 0.22480894], 'kN/m': ['kip/ft', 0.22480894 * 0.3048], 'kN/m2': ['kip/ft2', 0.22480894 * 0.3048 ** 2], 'kg/m3': ['lb/ft3', 0.06242796], MPa: ['ksi', 0.14503774] };

/** Convert one sheet's columns that carry a metric unit in their header. */
function safImperial(header) {
  const factor = header.map((h) => SAF_IMPERIAL[/\[([^\]]+)\]$/.exec(String(h))?.[1]]?.[1] || 0);
  const conv = (v, f) => {
    if (!f || v === '' || v == null) return v;
    if (typeof v === 'number') return Math.round(v * f * 1e6) / 1e6;
    if (typeof v === 'string' && /^[-\d.; ]+$/.test(v)) return v.split(';').map((x) => Math.round(+x * f * 1e6) / 1e6).join('; ');
    return v;
  };
  return { header: header.map((h) => String(h).replace(/\[([^\]]+)\]$/, (m, u) => (SAF_IMPERIAL[u] ? `[${SAF_IMPERIAL[u][0]}]` : m))), row: (r) => r.map((v, i) => conv(v, factor[i])) };
}
const FIX = {
  fixed: ['Rigid', 'Rigid', 'Rigid', 'Rigid', 'Rigid', 'Rigid', 'Fixed'],
  pinned: ['Rigid', 'Rigid', 'Rigid', 'Free', 'Free', 'Free', 'Hinged'],
  roller: ['Free', 'Free', 'Rigid', 'Free', 'Free', 'Free', 'Sliding'],
};

/** The SAF workbook sheets ({ name, rows: [{ cells }] } for writeXLSX) of an analytical model. */
export function safSheets(model, { projectName = 'Project', application = 'Building Design', imperial = false, cases = safCases(null) } = {}) {
  const sheet = (name, header, rows) => {
    const conv = imperial ? safImperial(header) : null;
    const head = conv ? conv.header : header;
    const body = conv ? rows.map(conv.row) : rows;
    return { name, rows: [{ cells: head, bold: true }, ...body.map((cells) => ({ cells }))], widths: head.map((h) => Math.max(10, String(h).length + 2)) };
  };
  const today = new Date().toISOString().slice(0, 10);
  const out = [
    // Project and Model list their properties down the first column, values beside them.
    { name: 'Project', rows: [['Name', projectName], ['Created', today], ['Last update', today]].map((cells) => ({ cells })), widths: [16, 30] },
    {
      name: 'Model',
      rows: [['SAF Version', '2.1.0'], ['Global coordinate system', 'Z vertical'], ['LCS of cross-section', 'ZYX'], ['System of units', imperial ? 'Imperial' : 'Metric'], ['National code', 'EC-Standard-EN'], ['Name', projectName], ['Discipline', 'Load-bearing structure'], ['Created', today], ['Source application', application]].map((cells) => ({ cells })),
      widths: [26, 30],
    },
    sheet('StructuralMaterial', ['Name', 'Type', 'Quality', 'Unit mass [kg/m3]', 'E modulus [MPa]'], model.materials.map((m) => [m.name, m.type, m.quality, m.density, m.e])),
    sheet('StructuralCrossSection', ['Name', 'Material', 'Cross-section type', 'Shape', 'Parameters [mm]'], model.sections.map((s) => [s.name, s.material, 'Parametric', s.shape, s.params.join('; ')])),
    sheet('StructuralPointConnection', ['Name', 'Coordinate X [m]', 'Coordinate Y [m]', 'Coordinate Z [m]'], model.nodes.map((n) => [n.name, M(n.p[0]), M(n.p[1]), M(n.p[2])])),
    sheet(
      'StructuralCurveMember',
      ['Name', 'Type', 'Cross section', 'Nodes', 'Segments', 'Internal nodes', 'Length [m]', 'LCS', 'LCS Rotation [deg]', 'Coordinate X [m]', 'Coordinate Y [m]', 'Coordinate Z [m]', 'System line', 'Analysis Y Eccentricity of Beg Node [mm]', 'Analysis Z Eccentricity of Beg Node [mm]', 'Analysis Y Eccentricity of End Node [mm]', 'Analysis Z Eccentricity of End Node [mm]', 'Behaviour in analysis', 'Id'],
      model.members.map((m) => [m.name, m.type, m.section, m.nodes.join('; '), 'Line', m.internalNodes.join('; '), M(m.length), 'y by vector', 0, ...m.y.map((v) => Math.round(v * 1e6) / 1e6), 'Centre', 0, 0, 0, 0, 'Standard', m.id]),
    ),
    sheet(
      'StructuralSurfaceMember',
      ['Name', 'Type', 'Material', 'Thickness type', 'Thickness [mm]', 'System plane at', 'Nodes', 'Edges', 'LCS Type', 'Coordinate X [m]', 'Coordinate Y [m]', 'Coordinate Z [m]', 'LCS Rotation [deg]', 'Analysis Z Eccentricity [mm]', 'Shape', 'Behavior in analysis', 'Id'],
      model.surfaces.map((s) => [s.name, s.type, s.material, 'Constant', Math.round(s.thickness), 'Centre', s.nodes.join('; '), s.nodes.map(() => 'Line').join('; '), 'x by vector', ...s.x.map((v) => Math.round(v * 1e6) / 1e6), 0, 0, 'Flat', 'Isotropic', s.id]),
    ),
    sheet(
      'StructuralPointSupport',
      ['Name', 'Type', 'Boundary condition', 'Node', 'ux', 'uy', 'uz', 'fix', 'fiy', 'fiz'],
      model.supports.map((s) => {
        const f = FIX[s.fixity] || FIX.fixed;
        return [s.name, f[6], 'In node', s.node, ...f.slice(0, 6)];
      }),
    ),
    sheet(
      'StructuralEdgeConnection',
      ['Name', 'Type', 'Boundary condition', '2D Member', 'Edge', 'ux', 'uy', 'uz', 'fix', 'fiy', 'fiz', 'Coordinate system', 'Coordinate definition', 'Origin', 'Start point [m]', 'End point [m]'],
      model.edgeSupports.map((s) => {
        const f = FIX[s.fixity] || FIX.pinned;
        return [s.name, f[6], 'On edge', s.surface, s.edge, ...f.slice(0, 6), 'Global', 'Relative', 'From start', 0, 1];
      }),
    ),
  ];
  // Hinged member ends: free to rotate about the section's y and z axes.
  out.push(
    sheet(
      'RelConnectsStructuralMember',
      ['Name', 'Member', 'Position', 'ux', 'uy', 'uz', 'fix', 'fiy', 'fiz'],
      model.members.filter((m) => m.release).map((m, i) => [`H${i + 1}`, m.name, { begin: 'Begin', end: 'End', both: 'Both' }[m.release], 'Rigid', 'Rigid', 'Rigid', 'Rigid', 'Free', 'Free']),
    ),
  );
  const used = [...new Set(model.loads.map((l) => l.loadCase))].filter((c) => cases[c]);
  const caseRows = [{ name: 'G1', desc: 'Self weight', action: 'Permanent', group: 'LG1', type: 'Self weight' }, ...used.map((c) => cases[c])];
  const groups = [...new Map(caseRows.map((c) => [c.group, c])).values()];
  out.push(
    sheet('StructuralLoadGroup', ['Name', 'Load group type', 'Relation', 'Load type'], groups.map((c) => [c.group, c.action, c.action === 'Permanent' ? 'Together' : 'Exclusive', c.action === 'Variable' ? (c.type === 'Static' ? 'Domestic' : c.type) : ''])),
    sheet('StructuralLoadCase', ['Name', 'Description', 'Action type', 'Load group', 'Load type', 'Duration'], caseRows.map((c) => [c.name, c.desc, c.action, c.group, c.type, c.duration || ''])),
    sheet('StructuralSurfaceAction', ['Name', 'Direction', 'Type', 'Force action', 'Value [kN/m2]', '2D Member', 'Load case', 'Coordinate system', 'Location'], model.loads.filter((l) => l.kind === 'surface').map((l) => [l.name, 'Z', 'Standard', 'On 2D member', -Math.abs(l.value), l.surface, cases[l.loadCase]?.name ?? 'Q', 'Global', 'Length'])),
    sheet(
      'StructuralCurveAction',
      ['Name', 'Type', 'Force action', 'Distribution', 'Direction', 'Value 1 [kN/m]', 'Member', '2D Member', 'Edge', 'Load case', 'Coordinate system', 'Location', 'Coordinate definition', 'Origin', 'Extent', 'Start point [m]', 'End point [m]', 'Eccentricity ey [mm]', 'Eccentricity ez [mm]'],
      model.loads.filter((l) => l.kind === 'line').map((l) => [l.name, 'Standard', l.member ? 'On beam' : 'On edge', 'Uniform', 'Z', -Math.abs(l.value), l.member || '', l.surface || '', l.edge || '', cases[l.loadCase]?.name ?? 'Q', 'Global', 'Length', 'Relative', 'From start', 'Full Span', 0, 1, 0, 0]),
    ),
    sheet('StructuralPointAction', ['Name', 'Type', 'Direction', 'Force action', 'Reference node', 'Value [kN]', 'Load case', 'Coordinate system'], model.loads.filter((l) => l.kind === 'point').map((l) => [l.name, 'Standard', 'Z', 'In node', l.node, -Math.abs(l.value), cases[l.loadCase]?.name ?? 'Q', 'Global'])),
  );
  if (model.combinations?.length) {
    const { header, rows } = combinationRows(model.combinations);
    out.push(sheet('StructuralLoadCombination', header, rows));
  }
  if (model.links?.length) {
    const HINGE = { none: 'None', begin: 'Begin', end: 'End', both: 'Both' };
    const free = (h) => (h === 'none' ? 'Rigid' : 'Free');
    out.push(sheet('RelConnectsRigidLink', ['Name', 'Nodes', 'Hinge position', 'ux', 'uy', 'uz', 'fix', 'fiy', 'fiz'], model.links.map((l) => [l.name, l.nodes.join('; '), HINGE[l.hinge] || 'None', 'Rigid', 'Rigid', 'Rigid', free(l.hinge), free(l.hinge), free(l.hinge)])));
  }
  return out;
}

/**
 * Structural Analytical Model Quality: problems of an analytical model, each { check, message, ids (elements) }:
 * member ends connected to nothing, very short members, members and surfaces with no section or thickness, and a
 * model with no supports.
 */
export function analyticalQuality(model, { minLength = 200 } = {}) {
  const out = [];
  const uses = new Map();
  const use = (n) => uses.set(n, (uses.get(n) || 0) + 1);
  for (const m of model.members) m.nodes.forEach(use), (m.internalNodes || []).forEach(use);
  for (const s of model.surfaces) s.nodes.forEach(use);
  for (const l of model.links || []) l.nodes.forEach(use);
  const supported = new Set(model.supports.map((x) => x.node));
  for (const m of model.members) {
    if (m.length < minLength) out.push({ check: 'short', message: `${m.name} is only ${Math.round(m.length)} mm long.`, ids: [m.id] });
    const loose = m.nodes.filter((n) => uses.get(n) === 1 && !supported.has(n));
    // A beam or column end touching nothing (a surface edge counts only through shared nodes).
    if (loose.length === 2) out.push({ check: 'free', message: `${m.name} is connected to nothing at either end.`, ids: [m.id] });
    else if (loose.length === 1 && m.type !== 'Column') out.push({ check: 'free', message: `${m.name} has a free end (${loose[0]}).`, ids: [m.id] });
    if (!m.section) out.push({ check: 'section', message: `${m.name} has no cross-section.`, ids: [m.id] });
  }
  for (const s of model.surfaces) {
    if (!(s.thickness > 0)) out.push({ check: 'thickness', message: `${s.name} has no thickness.`, ids: [s.id] });
    if (new Set(s.nodes).size < 3) out.push({ check: 'degenerate', message: `${s.name} has fewer than three corners.`, ids: [s.id] });
  }
  if ((model.members.length || model.surfaces.length) && !model.supports.length && !model.edgeSupports.length) out.push({ check: 'supports', message: 'The model has no supports.', ids: [] });
  return out;
}

/**
 * Create Structural Links: between each pair of the given elements, a link joining their two nearest analytical
 * nodes when they are apart (more than the node tolerance) and closer than maxGap. Returns links (not added):
 * [{ kind: 'structuralLink', a, b, hinge }].
 */
export function linksBetween(model, ids, { maxGap = 1500, hinge = 'none' } = {}) {
  const at = new Map(model.nodes.map((n) => [n.name, n.p]));
  const nodesOf = (id) => [...model.members.filter((m) => m.id === id).flatMap((m) => m.nodes), ...model.surfaces.filter((s) => s.id === id).flatMap((s) => s.nodes)];
  const out = [];
  for (let i = 0; i < ids.length; i++)
    for (let j = i + 1; j < ids.length; j++) {
      const A = nodesOf(ids[i]);
      const B = nodesOf(ids[j]);
      if (A.some((n) => B.includes(n))) continue;
      let best = null;
      for (const a of A)
        for (const b of B) {
          const p = at.get(a);
          const q = at.get(b);
          const d = Math.hypot(p[0] - q[0], p[1] - q[1], p[2] - q[2]);
          if (d <= maxGap && (!best || d < best.d)) best = { d, a: p, b: q };
        }
      if (best) out.push({ kind: 'structuralLink', a: best.a, b: best.b, hinge });
    }
  return out;
}
