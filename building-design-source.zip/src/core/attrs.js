/**
 * Attributes in one place: what the project has of each kind, how often each
 * is used, and the project's own pen table, MEP systems and operation
 * profiles.
 */
import { SYSTEMS } from './mep.js';
import { PROFILES } from './energyhourly.js';
import { DEFAULT_WEIGHTS_MM } from './pens.js';

export const ATTRIBUTE_KINDS = [
  { kind: 'material', label: 'Building Materials', cmd: 'materials' },
  { kind: 'fillType', label: 'Fills', cmd: 'fillTypes' },
  { kind: 'lineStyle', label: 'Line Types', cmd: 'lineStyles' },
  { kind: 'profile', label: 'Complex Profiles', cmd: 'profiles' },
  { kind: 'zoneCategory', label: 'Zone Categories', cmd: 'zoneCategories' },
  { kind: 'layer', label: 'Layers', cmd: 'layerSettings' },
];

/** How many items refer to each attribute: Map(id → count). */
export function attributeUses(doc) {
  const ids = new Set();
  for (const a of ATTRIBUTE_KINDS) for (const x of doc.all(a.kind)) ids.add(x.id);
  const uses = new Map([...ids].map((id) => [id, 0]));
  const seen = (v, self) => {
    if (typeof v === 'string') {
      if (v !== self && uses.has(v)) uses.set(v, uses.get(v) + 1);
    } else if (Array.isArray(v)) v.forEach((x) => seen(x, self));
    else if (v && typeof v === 'object') Object.values(v).forEach((x) => seen(x, self));
  };
  for (const el of doc.items.values()) seen(el, el.id);
  return uses;
}

/** Attributes as rows: [{ kind, label, id, name, uses, builtIn }]. */
export function attributeRows(doc) {
  const uses = attributeUses(doc);
  return ATTRIBUTE_KINDS.flatMap((a) => doc.all(a.kind).map((x) => ({ kind: a.kind, label: a.label, id: x.id, name: x.name || x.id, uses: uses.get(x.id) || 0 })));
}

/** Attributes as a transfer file. */
export function exportAttributes(doc, ids = null) {
  const set = ids ? new Set(ids) : null;
  const kinds = new Set(ATTRIBUTE_KINDS.map((a) => a.kind));
  return { format: 'bd-attributes', items: [...doc.items.values()].filter((x) => kinds.has(x.kind) && (!set || set.has(x.id))) };
}

/** Read a transfer file into the project (inside a transaction): new ones are added, existing ones replaced if asked. */
export function importAttributes(doc, file, { replace = false } = {}) {
  let added = 0;
  let replaced = 0;
  for (const it of file?.items || []) {
    if (!ATTRIBUTE_KINDS.some((a) => a.kind === it.kind)) continue;
    if (doc.has(it.id)) {
      if (!replace) continue;
      const { id, ...rest } = it;
      doc.update(id, rest);
      replaced++;
    } else {
      doc.add(it);
      added++;
    }
  }
  return { added, replaced };
}

// Pens ----------------------------------------------------------------------------------------

/** A default table of 255 pens: repeating widths and colours. */
export function defaultPens() {
  const hues = ['#000000', '#c83232', '#2f9e44', '#1f6fff', '#c88a1f', '#8a3fbf', '#1fa8a8', '#777777'];
  const widths = [0.13, 0.18, 0.25, 0.35, 0.5, 0.7, 1.0];
  return Array.from({ length: 255 }, (_, i) => ({ color: hues[i % hues.length], mm: widths[Math.floor(i / hues.length) % widths.length] }));
}

export const penTable = (project) => (Array.isArray(project?.penTable) && project.penTable.length === 255 ? project.penTable : defaultPens());

/** The printed width of each line weight class from the pens assigned to the classes, where there are. */
export function classWeights(project, base = DEFAULT_WEIGHTS_MM) {
  const map = project?.penClasses;
  if (!map) return null;
  const pens = penTable(project);
  return base.map((d, i) => (map[i] ? pens[map[i] - 1]?.mm || d : d));
}

/** The colours of the line weight classes as eight RGB triples, or null when none is set. */
export function classColors(project) {
  const map = project?.penClasses;
  if (!map || !project.penColors) return null;
  const pens = penTable(project);
  const out = new Float32Array(32);
  let any = false;
  for (let i = 0; i < 8; i++) {
    const hex = map[i] ? pens[map[i] - 1]?.color : null;
    if (hex) {
      any = true;
      out[i * 4] = parseInt(hex.slice(1, 3), 16) / 255;
      out[i * 4 + 1] = parseInt(hex.slice(3, 5), 16) / 255;
      out[i * 4 + 2] = parseInt(hex.slice(5, 7), 16) / 255;
      out[i * 4 + 3] = 1;
    }
  }
  return any ? out : null;
}

// Systems and profiles --------------------------------------------------------------------------

const BUILT_IN = structuredClone(SYSTEMS);

/** The project's MEP systems take effect: built-in ones, plus or replaced by its own. */
export function applyMepSystems(project) {
  for (const k of Object.keys(SYSTEMS)) SYSTEMS[k].splice(0, SYSTEMS[k].length, ...(project?.mepSystems?.[k]?.length ? project.mepSystems[k] : BUILT_IN[k]));
}

const BUILT_IN_PROFILES = new Set(Object.keys(PROFILES));

/** The project's operation profiles take effect beside the built-in ones. */
export function applyOperationProfiles(project) {
  for (const k of Object.keys(PROFILES)) if (!BUILT_IN_PROFILES.has(k)) delete PROFILES[k];
  Object.assign(PROFILES, project?.operationProfiles || {});
}

/** Whether a profile is the project's own. */
export const isOwnProfile = (k) => !BUILT_IN_PROFILES.has(k);
