/**
 * Automatic level dimensions in a section or elevation: the heights of slab
 * tops, of the roof's ridge and eaves and of wall tops that the view shows,
 * as level dimensions (spots) on one vertical chain beside the building,
 * each with a leader to the point it measures. Heights within 5 mm of one
 * another are measured once.
 */
import { viewFrame, toView } from './elevation.js';

/** The u range and the points to measure ([{ u, z }]) of the bodies a view shows. */
function heights(doc, frame, meshOf) {
  const pts = [];
  let u0 = Infinity;
  let u1 = -Infinity;
  const L = frame.look;
  const c = L[0] * frame.origin[0] + L[1] * frame.origin[1];
  for (const el of doc.all('wall', 'floor', 'roof', 'shell', 'morph')) {
    const m = meshOf(el);
    if (!m?.bounds) continue;
    const { min, max } = m.bounds;
    // In front of the view (between its plane and its far depth).
    const corners = [[min[0], min[1]], [max[0], min[1]], [max[0], max[1]], [min[0], max[1]]];
    const depths = corners.map((p) => L[0] * p[0] + L[1] * p[1] - c);
    if (Math.max(...depths) < frame.near || Math.min(...depths) > frame.far) continue;
    const us = corners.map((p) => toView(frame, p)[0]);
    let lo = Math.min(...us);
    let hi = Math.max(...us);
    if (frame.u0 != null) {
      lo = Math.max(lo, frame.u0);
      hi = Math.min(hi, frame.u1);
      if (hi <= lo) continue;
    }
    u0 = Math.min(u0, lo);
    u1 = Math.max(u1, hi);
    const mid = (lo + hi) / 2;
    if (el.kind === 'floor') pts.push({ u: mid, z: max[2], what: 'slab' });
    else if (el.kind === 'wall') pts.push({ u: hi, z: max[2], what: 'wall' });
    else {
      pts.push({ u: mid, z: max[2], what: 'ridge' });
      if (el.kind === 'roof') pts.push({ u: hi, z: min[2], what: 'eaves' });
    }
  }
  return { u0, u1, pts };
}

/** Spots (not yet added) for a section or elevation view. scale: the view's. */
export function levelDimensions(doc, view, meshOf) {
  const frame = viewFrame(view);
  const { u1, pts } = heights(doc, frame, meshOf);
  if (!pts.length) return [];
  const scale = +view.scale || 100;
  const chainU = u1 + 12 * scale;
  const seen = [];
  const out = [];
  for (const p of pts.sort((a, b) => a.z - b.z)) {
    if (seen.some((z) => Math.abs(z - p.z) < 5)) continue;
    seen.push(p.z);
    out.push({ kind: 'spot', viewId: view.id, mode: 'elevation', at: [p.u, p.z], leader: [chainU, p.z], origin: 'project', auto: true });
  }
  return out;
}
