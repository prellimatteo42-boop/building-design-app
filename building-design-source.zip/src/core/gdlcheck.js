/**
 * Checks of GDL scripts (Library Developer): what a script cannot do as
 * written, found by reading it, without running it. Unbalanced blocks, jumps
 * to labels that do not exist, a main part that runs on into its
 * subroutines, macros that are not there, and parse errors. Also the list
 * of the parts a placed element uses.
 */
import { parse } from './gdl.js';

export const SCRIPT_KEYS = [
  ['master', 'Master'],
  ['script2d', '2D'],
  ['script3d', '3D'],
  ['paramScript', 'Parameter'],
  ['scriptParams', 'Parameter'],
  ['scriptUI', 'Interface'],
];

/** The script without its strings' contents and comments, line by line. */
function codeLines(src) {
  return String(src).split('\n').map((raw) => {
    let out = '';
    let q = null;
    for (const c of raw) {
      if (q) {
        if (c === q) q = null;
        continue;
      }
      if (c === '!') break;
      if (c === '"' || c === "'" || c === '`' || c === '“' || c === '”') {
        q = c === '“' ? '”' : c;
        out += '""';
        continue;
      }
      out += c;
    }
    return out;
  });
}

const PAIRS = [
  ['FOR', 'NEXT'],
  ['WHILE', 'ENDWHILE'],
  ['REPEAT', 'UNTIL'],
  ['GROUP', 'ENDGROUP'],
];

const MISSING_OK = new Set(['resize_a_b_zzyzx']);

/** Labels defined in a script: numbers and "strings" followed by a colon at the start of a line. */
function labelsOf(src) {
  const out = new Set();
  for (const raw of String(src).split('\n')) {
    const m = /^\s*(\d+(?:\.\d+)?|"[^"]+"|'[^']+')\s*:/.exec(raw);
    if (m) out.add(m[1].replace(/['"]/g, ''));
  }
  return out;
}

/**
 * Issues of one script: [{ line, level: 'error' | 'warning', message }].
 * context: { master: text whose labels also count, hasMacro(name), parameter
 * scripts are read the same way }.
 */
export function scriptIssues(src, { master = '', hasMacro = null } = {}) {
  const out = [];
  if (!String(src).trim()) return out;
  // The parser reads the commands of the 2D and 3D scripts; lists of values and interface scripts are not its job.
  if (!/\b(VALUES|PARAMETERS|LOCK|HIDEPARAMETER|UI_[A-Z]+)\b/i.test(src))
    try {
      parse(src, { lenient: false });
    } catch (err) {
      out.push({ line: err.line || 1, level: 'error', message: String(err.message).replace(/^Line \d+: /, '') });
    }
  const lines = codeLines(src);
  const raw = String(src).split('\n');
  const labels = new Set([...labelsOf(src), ...labelsOf(master)]);
  // Subroutines: labels some GOSUB reaches.
  const called = new Set();
  for (const r of raw) for (const m of r.replace(/!.*$/, '').matchAll(/\bGOSUB\s+("[^"]+"|'[^']+'|\d+(?:\.\d+)?)/gi)) called.add(m[1].replace(/['"]/g, ''));
  const open = PAIRS.map(() => []);
  const ifs = [];
  const dos = [];
  let firstLabel = null;
  let ended = false;
  lines.forEach((text, i) => {
    const line = i + 1;
    const upper = text.toUpperCase().replace(/\s+$/, '');
    const lab = /^\s*(\d+(?:\.\d+)?|"")\s*:/.exec(raw[i].replace(/^(\s*)["'`]([^"'`]*)["'`]/, '$1"$2"').replace(/"[^"]*"/, '""'));
    if (lab && firstLabel == null) {
      firstLabel = line;
      const name = /^\s*(\d+(?:\.\d+)?|"[^"]+"|'[^']+')/.exec(raw[i])?.[1].replace(/['"]/g, '');
      if (!ended && called.has(name)) out.push({ line, level: 'warning', message: 'The main part runs on into this subroutine: END is missing before it' });
    }
    const words = upper.match(/[A-Z_][A-Z0-9_~.]*/g) || [];
    // A line ending in THEN opens a block, even when its IF began on the line before.
    const inline = words.includes('THEN') && words.includes('ENDIF');
    if (/\bTHEN\s*:?\s*$/.test(upper)) ifs.push(line);
    if (!inline) for (const w of words) if (w === 'ENDIF' && !ifs.pop()) out.push({ line, level: 'warning', message: 'ENDIF without an IF' });
    PAIRS.forEach(([a, b], k) => {
      let opened = words.filter((w) => w === a).length;
      const closed = words.filter((w) => w === b).length;
      // GROUP also names operations and functions: it opens only as a statement.
      if (a === 'GROUP' && !/(^|:)\s*GROUP\b/.test(upper)) opened = 0;
      if (a === 'WHILE') {
        // WHILE c DO ... ENDWHILE, or DO ... WHILE c.
        const bareDo = /(^|:)\s*DO\s*($|:)/.test(upper);
        if (bareDo) dos.push(line);
        if (opened && !words.includes('DO')) {
          if (dos.pop()) opened--;
          else opened = 0;
        }
      }
      for (let n = 0; n < opened; n++) open[k].push(line);
      for (let n = 0; n < closed; n++) if (!open[k].pop()) out.push({ line, level: 'warning', message: `${b} without a ${a}` });
    });
    if (firstLabel == null && /(^|:)\s*(END|EXIT|RETURN)\b/.test(upper)) ended = true;
    if (firstLabel == null && /\bGOTO\b/.test(upper)) ended = true;
    // Jumps to fixed labels (not computed ones such as 100 + i).
    for (const m of raw[i].replace(/!.*$/, '').matchAll(/\b(?:GOSUB|GOTO)\s+("[^"]+"|'[^']+'|\d+(?:\.\d+)?)\s*(?=$|:|\bELSE\b)/gi)) {
      const tgt = m[1].replace(/['"]/g, '');
      if (!labels.has(tgt)) out.push({ line, level: 'warning', message: `Jump to a label that does not exist: ${tgt}` });
    }
    if (hasMacro)
      for (const m of raw[i].replace(/!.*$/, '').matchAll(/\bCALL\s+(?:"([^"]+)"|'([^']+)')/gi)) {
        const name = (m[1] || m[2]).replace(/\.gsm$/i, '');
        if (!MISSING_OK.has(name.toLowerCase()) && !hasMacro(name)) out.push({ line, level: 'warning', message: `Macro not in the loaded libraries: ${name}` });
      }
  });
  for (const l of ifs) out.push({ line: l, level: 'warning', message: 'IF without an ENDIF' });
  PAIRS.forEach(([a, b], k) => open[k].forEach((l) => out.push({ line: l, level: 'warning', message: `${a} without a ${b}` })));
  return out.sort((a, b) => a.line - b.line);
}

/** Issues of a part's scripts: [{ script, line, level, message }]. scripts: { master, script3d, ... }. */
export function partIssues(scripts, { hasMacro = null } = {}) {
  const out = [];
  for (const [key, label] of SCRIPT_KEYS) {
    const src = scripts?.[key];
    if (!src) continue;
    for (const it of scriptIssues(src, { master: key === 'master' ? '' : scripts.master || '', hasMacro })) out.push({ script: label, ...it });
  }
  return out;
}

/** Issues of parts: [{ name, issues }] for those that have any. parts: [{ name, scripts }]. */
export function libraryIssues(parts, opts = {}) {
  const out = [];
  for (const p of parts) {
    const issues = partIssues(p.scripts, opts);
    if (issues.length) out.push({ name: p.name, issues });
  }
  return out;
}

/** The scripts of a GDL type in the form partIssues reads. */
export const typeScripts = (type) => ({ master: type?.gdl?.master, script2d: type?.gdl?.script2d, script3d: type?.gdl?.script3d, paramScript: type?.gdl?.paramScript, scriptParams: type?.gdl?.scriptParams, scriptUI: type?.gdl?.scriptUI });

/** The parts an object uses, itself first: [{ name, role, scripts: { key: text } }]. */
export function partsOfType(type) {
  const g = type?.gdl;
  if (!g) return [];
  const pick = (x) => Object.fromEntries(SCRIPT_KEYS.map(([k]) => [k, x[k]]).filter(([, v]) => v));
  const out = [{ name: type.name || type.id, role: 'Object', scripts: pick(g), path: g.source || '' }];
  for (const [key, m] of Object.entries(g.macros || {}).sort(([a], [b]) => a.localeCompare(b))) out.push({ name: m.name || key, role: 'Macro', scripts: pick(m), path: m.path || '' });
  return out;
}
