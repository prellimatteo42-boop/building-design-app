/**
 * Layer joins in plan. Where walls meet, their layers settle who takes the
 * joint by priority, so a partition's structure runs through the finish of
 * the wall it meets and stops at that wall's structure:
 *
 *   - Each layer has a priority: its own `priority` (0-999), its building
 *     material's, or the one of its function (structure 800, substrate 600,
 *     insulation and air 400, finish 200, membrane 100). Higher is stronger.
 *   - Across a wall, a layer weaker than layers on both sides of it counts as
 *     the lower of the two, so the layers between two stronger ones move as
 *     one block.
 *   - At a T or a two-wall corner, each layer of the wall that ends there
 *     continues past its end into the other wall, crossing that wall's layers
 *     from the side it comes from, and stops at the first one at least as
 *     strong. What it crosses is taken out of the other wall.
 *   - Walls that cross without a join overlap; where two layers overlap, the
 *     stronger keeps the overlap (on a tie, the wall drawn first).
 *
 * With equal priorities nothing moves, so the result is the joins of
 * walls.js drawn layer by layer. Pieces stay convex: a convex polygon minus a
 * convex polygon splits along the cutter's edges into convex parts.
 *
 * Per wall the result has its pieces { poly, layer, materialId, structure,
 * solid } and its lines { a, b, weight }: 'cut' where a piece borders
 * nothing, 'light' or 'thin' between pieces of different materials, none
 * between pieces of the same material. Openings are left to the caller.
 */
import { materialPriority } from './materials.js';
import { add, sub, scale, dot, cross, perp, clipHalfPlane, signedArea, ensureCCW, cleanPolygon, bbox, bboxIntersects } from './geom.js';

/** Priority of each layer function; higher is stronger. */
export const LAYER_PRIORITY = { structure: 800, substrate: 600, insulation: 400, air: 400, finish: 200, membrane: 100 };

const TOL = 0.05; // mm: edges closer than this lie on one line
const MIN_AREA = 1; // mm²: smaller pieces are dropped
const MIN_SIN = 0.2; // walls closer to parallel than ~12° do not reach into each other

/** A layer's priority: its own, its building material's (materials.js), or its function's. */
export function layerPriority(layer, doc = null) {
  const p = layer?.priority;
  if (p !== undefined && p !== null && p !== '' && Number.isFinite(+p)) return Math.max(0, Math.min(999, +p));
  const m = doc && layer?.materialId ? materialPriority(doc.get(layer.materialId)) : null;
  if (m !== null) return m;
  return LAYER_PRIORITY[layer?.function] ?? LAYER_PRIORITY.structure;
}

/** Raise each value enclosed by larger ones to the lower of the two (valleys filled). */
export function fillValleys(values) {
  const n = values.length;
  const left = new Array(n);
  const right = new Array(n);
  for (let i = 0; i < n; i++) left[i] = Math.max(values[i], i ? left[i - 1] : -Infinity);
  for (let i = n - 1; i >= 0; i--) right[i] = Math.max(values[i], i < n - 1 ? right[i + 1] : -Infinity);
  return values.map((v, i) => Math.max(v, Math.min(left[i], right[i])));
}

/**
 * Partial Structure Display, as in Archicad: which layers of walls a view
 * shows. Layers left out are taken away before the outlines are drawn, so
 * what remains gets cut lines where it now borders nothing.
 */
export const STRUCTURE_DISPLAY = [
  { value: 'entire', label: 'Entire Model' },
  { value: 'withoutFinishes', label: 'Without Finishes' },
  { value: 'core', label: 'Core Only' },
  { value: 'coreLoadBearing', label: 'Core of Load-Bearing Elements Only' },
];

/** Whether a layer of wall w shows under a structure display mode. */
export function layerShown(show, layer, w) {
  if (!show || show === 'entire') return true;
  if (show === 'withoutFinishes') return layer.function !== 'finish';
  if (show === 'coreLoadBearing' && !w.structural) return false;
  return layer.function === 'structure';
}

/**
 * Offsets across wall w (along its axis normal, the wall being 2 * half
 * thick) between which the layers a structure display shows lie:
 * { lo, hi }, or null when it shows none.
 */
export function shownSpan(doc, w, show, half) {
  const layers = doc.get(w.typeId)?.layers || [];
  if (!show || show === 'entire' || !layers.length) return { lo: -half, hi: half };
  if (layers.length === 1) return layerShown(show, layers[0], w) ? { lo: -half, hi: half } : null;
  const total = layers.reduce((sum, l) => sum + (+l.thickness || 0), 0) || 1;
  const ext = w.flipped ? -1 : 1;
  let acc = 0;
  let lo = Infinity;
  let hi = -Infinity;
  for (const l of layers) {
    const a = ext * (half - (2 * half * acc) / total);
    acc += +l.thickness || 0;
    const b = ext * (half - (2 * half * acc) / total);
    if (!layerShown(show, l, w)) continue;
    lo = Math.min(lo, a, b);
    hi = Math.max(hi, a, b);
  }
  return hi < lo ? null : { lo, hi };
}

/** The layer joins of a wall in a plan context, cached per level, cut height and structure display. */
export function joinedLayers(pc, w) {
  if (!pc?.walls?.derived || w.levelId == null) return null;
  const z = pc.cutZ;
  const show = pc.structure || 'entire';
  return pc.walls.derived(w.levelId, `layers@${z}:${show}`, (solved) => solveLayerJoins(pc.doc, solved, z, show)).get(w.id) ?? null;
}

/**
 * Layer pieces and lines of the walls of a solved level (see walls.js) that
 * the plane at height z cuts, with the layers a structure display mode
 * shows. Returns Map<wallId, { pieces, lines, sig }>.
 */
export function solveLayerJoins(doc, solved, z, show = 'entire') {
  const ws = [];
  for (const g of solved.walls.values()) {
    if (!(g.base <= z && g.top > z)) continue;
    const type = doc.get(g.wall.typeId);
    // Curved walls draw their layers as arcs (plan.js), outside the joins.
    if (type?.curtain || g.axis.curve) continue;
    const home = clean([g.R0, g.R1, g.L1, g.L0]);
    if (!home || !convex(home)) continue;
    const stack = layerStack(doc, type, g);
    ws.push({ id: g.id, g, home, box: bbox(home), stack, extra: stack.map(() => []), cutters: [] });
  }
  const byId = new Map(ws.map((w) => [w.id, w]));

  // A wall ending at a T (on one wall, or where two run through) or a two-wall corner reaches into the other wall.
  for (const w of ws) {
    for (let e = 0; e < 2; e++) {
      const end = w.g.ends[e];
      const others = end.kind === 'tee' ? (end.hosts ?? [end.host]) : end.kind === 'corner' && end.with?.length === 1 ? end.with : [];
      for (const otherId of others) {
        const o = byId.get(otherId);
        if (o && Math.abs(cross(w.g.axis.dir, o.g.axis.dir)) >= MIN_SIN) reachInto(w, e, o);
      }
    }
  }

  // Walls that overlap without a join: each overlap of two layers goes to the stronger.
  for (let i = 0; i < ws.length; i++) {
    for (let j = i + 1; j < ws.length; j++) {
      const A = ws[i];
      const B = ws[j];
      if (!bboxIntersects(A.box, B.box) || joinedTo(A, B) || joinedTo(B, A) || A.g.group !== B.g.group) continue;
      const overlap = intersectConvex(A.home, B.home);
      if (!overlap) continue;
      for (const sa of A.stack) {
        const rowA = band(overlap, A.g.axis, sa.lo, sa.hi);
        if (rowA.length < 3) continue;
        for (const sb of B.stack) {
          const cell = clean(band(rowA, B.g.axis, sb.lo, sb.hi));
          if (cell) (sb.prio > sa.prio ? A : B).cutters.push(cell);
        }
      }
    }
  }

  // Pieces: each layer's part of its wall, less what others took, plus what it took.
  const items = [];
  for (const w of ws) {
    w.pieces = [];
    for (const s of w.stack) {
      let polys = [band(w.home, w.g.axis, s.lo, s.hi)];
      for (const c of w.cutters) polys = polys.flatMap((p) => subtractConvex(p, c));
      // Layers the structure display leaves out still took their share of the joins above.
      if (!layerShown(show, s.layer, w.g.wall)) continue;
      for (const p of [...polys, ...w.extra[s.k]]) {
        const poly = clean(p);
        if (!poly) continue;
        const piece = { poly, layer: s.k, materialId: s.layer.materialId ?? null, structure: s.layer.function === 'structure', solid: w.stack.length === 1 };
        w.pieces.push(piece);
        items.push({ poly, wall: w, mat: piece.solid ? `solid:${piece.materialId}` : piece.materialId, structure: piece.structure });
      }
    }
  }
  // Hubs are filled by their owner; nothing is drawn along their edges.
  for (const hub of solved.hubs || []) if (hub.ids.some((id) => byId.has(id))) items.push({ poly: ensureCCW(hub.poly), hub: true });

  for (const w of ws) w.lines = [];
  outlineLines(items);

  const out = new Map();
  for (const w of ws) {
    const sig = [...w.pieces.map((p) => `${p.layer}:${p.materialId}:${p.poly.map(fmt).join(';')}`), ...w.lines.map((l) => `${l.weight}:${fmt(l.a)}>${fmt(l.b)}`)].join('|');
    out.set(w.id, { pieces: w.pieces, lines: w.lines, sig });
  }
  return out;
}

/**
 * Layers across a wall: { k, layer, prio, lo, hi }, lo/hi being offsets from
 * the axis along axis.n. The first layer is on the exterior face (left unless
 * flipped), as in the type.
 */
function layerStack(doc, type, g) {
  const layers = type?.layers?.length ? type.layers : [{ thickness: 1, function: 'structure', materialId: null }];
  const total = layers.reduce((s, l) => s + (+l.thickness || 0), 0) || 1;
  const prios = fillValleys(layers.map((l) => layerPriority(l, doc)));
  const half = g.axis.half;
  const ext = g.wall.flipped ? -1 : 1;
  let o = 0;
  return layers.map((layer, k) => {
    const s0 = ext * (half - (2 * half * o) / total);
    o += +layer.thickness || 0;
    const s1 = ext * (half - (2 * half * o) / total);
    return { k, layer, prio: prios[k], lo: Math.min(s0, s1), hi: Math.max(s0, s1) };
  });
}

/** Layers of wall w continue past end e into wall o, through o's weaker layers. */
function reachInto(w, e, o) {
  const g = w.g;
  const L = e === 0 ? g.L0 : g.L1;
  const R = e === 0 ? g.R0 : g.R1;
  const body = add(g.axis.a, scale(g.axis.dir, g.axis.length / 2));
  // Normal of the end line, pointing into the wall's body.
  let m = perp(sub(R, L));
  if (dot(m, sub(body, L)) < 0) m = scale(m, -1);
  const beyond = clipHalfPlane(o.home, m, dot(m, L));
  if (beyond.length < 3) return;
  // The face of o that w comes from, and o's layers in the order w crosses them.
  const side = dot(o.g.axis.n, sub(body, o.g.axis.a)) >= 0 ? 1 : -1;
  const face = side * o.g.axis.half;
  const order = o.stack.slice().sort((a, b) => (side > 0 ? b.hi - a.hi : a.lo - b.lo));
  for (const s of w.stack) {
    const stop = order.find((t) => t.prio >= s.prio);
    const depth = stop ? (side > 0 ? stop.hi : stop.lo) : -face;
    if (Math.abs(face - depth) < TOL) continue;
    const piece = clean(band(band(beyond, g.axis, s.lo, s.hi), o.g.axis, Math.min(face, depth), Math.max(face, depth)));
    if (!piece) continue;
    w.extra[s.k].push(piece);
    o.cutters.push(piece);
  }
}

/** Whether a's ends join b. */
function joinedTo(a, b) {
  return a.g.ends.some((end) => end.host === b.id || end.hosts?.includes(b.id) || end.with?.includes(b.id));
}

/** The part of a polygon between offsets lo and hi from an axis (along axis.n). */
function band(poly, axis, lo, hi) {
  const c = dot(axis.n, axis.a);
  const p = clipHalfPlane(poly, axis.n, c + hi);
  return p.length < 3 ? [] : clipHalfPlane(p, scale(axis.n, -1), -(c + lo));
}

/** A counterclockwise polygon without repeated points, or null if it has no area. */
function clean(poly) {
  if (!poly || poly.length < 3) return null;
  const p = cleanPolygon(poly, 0.01);
  if (p.length < 3 || Math.abs(signedArea(p)) < MIN_AREA) return null;
  return ensureCCW(p);
}

function convex(poly) {
  let sign = 0;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const c = poly[(i + 2) % poly.length];
    const k = cross(sub(b, a), sub(c, b));
    if (Math.abs(k) < 1e-9) continue;
    if (sign && Math.sign(k) !== sign) return false;
    sign = Math.sign(k);
  }
  return true;
}

/** Intersection of two convex polygons (b counterclockwise), or null. */
function intersectConvex(a, b) {
  let p = a;
  for (let i = 0; i < b.length && p.length >= 3; i++) {
    const q = b[i];
    const inward = perp(sub(b[(i + 1) % b.length], q));
    p = clipHalfPlane(p, scale(inward, -1), -dot(inward, q));
  }
  return clean(p);
}

/** Convex polygon minus a counterclockwise convex polygon, as convex parts. */
export function subtractConvex(poly, cut) {
  // Polygons that only touch keep their piece whole.
  if (!bboxIntersects(bbox(poly), bbox(cut)) || !intersectConvex(poly, cut)) return [poly];
  const out = [];
  let rest = poly;
  for (let i = 0; i < cut.length; i++) {
    const q = cut[i];
    const inward = perp(sub(cut[(i + 1) % cut.length], q));
    const c = dot(inward, q);
    const outside = clean(clipHalfPlane(rest, inward, c));
    if (outside) out.push(outside);
    rest = clipHalfPlane(rest, scale(inward, -1), -c);
    if (!clean(rest)) return out;
  }
  return out;
}

/**
 * Lines along piece edges: an edge (or part of it) that touches no other
 * piece is outline ('cut'); one shared with a piece of another material is
 * drawn once, 'light' next to structure and 'thin' otherwise.
 */
function outlineLines(items) {
  const CELL = 500;
  const grid = new Map();
  const edges = [];
  items.forEach((it, i) => {
    const n = it.poly.length;
    for (let k = 0; k < n; k++) {
      const a = it.poly[k];
      const b = it.poly[(k + 1) % n];
      const e = { a, b, i };
      edges.push(e);
      const x0 = Math.floor(Math.min(a[0], b[0]) / CELL);
      const x1 = Math.floor(Math.max(a[0], b[0]) / CELL);
      const y0 = Math.floor(Math.min(a[1], b[1]) / CELL);
      const y1 = Math.floor(Math.max(a[1], b[1]) / CELL);
      for (let x = x0; x <= x1; x++)
        for (let y = y0; y <= y1; y++) {
          const key = `${x},${y}`;
          if (!grid.has(key)) grid.set(key, []);
          grid.get(key).push(e);
        }
    }
  });
  for (const e of edges) {
    const it = items[e.i];
    if (it.hub) continue;
    const d = sub(e.b, e.a);
    const length = Math.hypot(d[0], d[1]);
    if (length < TOL) continue;
    const u = scale(d, 1 / length);
    // Parts of this edge shared with other pieces: [t0, t1, item].
    const shared = [];
    const seen = new Set();
    const x0 = Math.floor(Math.min(e.a[0], e.b[0]) / CELL);
    const x1 = Math.floor(Math.max(e.a[0], e.b[0]) / CELL);
    const y0 = Math.floor(Math.min(e.a[1], e.b[1]) / CELL);
    const y1 = Math.floor(Math.max(e.a[1], e.b[1]) / CELL);
    for (let x = x0; x <= x1; x++)
      for (let y = y0; y <= y1; y++) {
        for (const f of grid.get(`${x},${y}`) || []) {
          if (f.i === e.i || seen.has(f)) continue;
          seen.add(f);
          if (Math.abs(cross(u, sub(f.a, e.a))) > TOL || Math.abs(cross(u, sub(f.b, e.a))) > TOL) continue;
          const t0 = Math.max(0, Math.min(dot(u, sub(f.a, e.a)), dot(u, sub(f.b, e.a))));
          const t1 = Math.min(length, Math.max(dot(u, sub(f.a, e.a)), dot(u, sub(f.b, e.a))));
          if (t1 - t0 > TOL) shared.push([t0, t1, items[f.i], f.i]);
        }
      }
    shared.sort((p, q) => p[0] - q[0]);
    const at = (t) => add(e.a, scale(u, t));
    const push = (t0, t1, weight) => {
      if (t1 - t0 > TOL) it.wall.lines.push({ a: at(t0), b: at(t1), weight });
    };
    let t = 0;
    for (const [t0, t1, other, j] of shared) {
      if (t0 > t) push(t, t0, 'cut');
      const from = Math.max(t, t0);
      if (t1 > from && !other.hub && other.mat !== it.mat && e.i < j) push(from, t1, it.structure || other.structure ? 'light' : 'thin');
      t = Math.max(t, t1);
    }
    if (t < length) push(t, length, 'cut');
  }
}

const fmt = (p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`;
