/**
 * Roof framing, as Archicad's RoofMaker: timber members under a roof's
 * planes. Rafters run up each plane at a spacing, their tops on its
 * underside; a ridge beam lies along each level ridge, hip and valley
 * rafters along the sloping ones; wall plates (eaves purlins) along the
 * pivot lines where the planes start; and purlins across long planes, under
 * the rafters at mid-run. Members are beams whose ends may lie at different
 * heights (offset, endOffset). As RoofMaker's further commands: collar beams
 * (level ties between opposite rafters two thirds of the way up), tie beams
 * (between the feet of opposite rafters, at the wall plates) and trimmers
 * round the roof's openings (the rafters there cut and carried on headers
 * between doubled rafters each side).
 */
import { roofFaces, planeHeight, roofHeightAt } from './roof.js';
import { roofHoles } from './skylight.js';
import { pointInPolygon } from './geom.js';
import { levelElevation } from './model.js';
import { dist, dot, sub, add, scale } from './geom.js';

export const FRAMING = {
  rafter: { name: 'Timber Rafter 80 x 200', width: 80, depth: 200 },
  ridge: { name: 'Timber Ridge Beam 160 x 260', width: 160, depth: 260 },
  hip: { name: 'Timber Hip Rafter 100 x 240', width: 100, depth: 240 },
  plate: { name: 'Timber Wall Plate 140 x 140', width: 140, depth: 140 },
  purlin: { name: 'Timber Purlin 140 x 200', width: 140, depth: 200 },
  collar: { name: 'Timber Collar Beam 60 x 160', width: 60, depth: 160 },
  tie: { name: 'Timber Tie Beam 80 x 200', width: 80, depth: 200 },
  trimmer: { name: 'Timber Trimmer 80 x 200', width: 80, depth: 200 },
  header: { name: 'Timber Header 80 x 200', width: 80, depth: 200 },
};

/**
 * The members for a roof: [{ role, a, b, za, zb }] with plan points and the
 * heights of the member's top at each end (absolute, mm).
 * opts: { spacing (rafters, mm), purlinRun (a plane longer than this up the
 * slope gets a purlin at mid-run), collars, ties (bools; the roof's own
 * framing settings otherwise), collarAt (fraction of the rise, 2/3) }.
 */
export function roofFraming(doc, roof, opts = {}) {
  const { spacing = 600, purlinRun = 3500 } = opts;
  const collars = opts.collars ?? !!roof?.framing?.collars;
  const ties = opts.ties ?? !!roof?.framing?.ties;
  const collarAt = Math.min(0.9, Math.max(0.3, +(opts.collarAt ?? roof?.framing?.collarAt ?? 2 / 3)));
  if (!roof?.boundary || roof.boundary.length < 3) return [];
  const base = levelElevation(doc, roof.levelId) + (+roof.baseOffset || 0);
  const { poly, planes, faces, ridges } = roofFaces(roof.boundary, roof.slopes, { levels: roof.levels, overhangs: roof.overhangs });
  if (!planes.length) return [];
  const out = [];
  const zAt = (p) => base + roofHeightAt(planes, p);
  const holes = roofHoles(doc, roof);
  for (const f of faces) {
    const pl = f.plane;
    if (!pl || !(pl.k > 0)) continue;
    const m = pl.m;
    const e = [-m[1], m[0]];
    // Rafters: lines up the plane, across the face at the spacing, centred on its width.
    const ss = f.poly.map((p) => dot(sub(p, pl.p), e));
    const s0 = Math.min(...ss);
    const s1 = Math.max(...ss);
    const n = Math.max(1, Math.floor((s1 - s0) / spacing));
    const first = s0 + (s1 - s0 - (n - 1) * spacing) / 2;
    // Openings in this face, in its coordinates: across (s) and up the slope (t), widened by a rafter.
    const rw = FRAMING.trimmer.width;
    const openings = holes
      .filter((h) => h.some((q) => pointInPolygon(q, f.poly)) || pointInPolygon(f.poly[0], h))
      .map((h) => {
        const hs = h.map((q) => dot(sub(q, pl.p), e));
        const ht = h.map((q) => dot(sub(q, pl.p), m));
        return { s0: Math.min(...hs) - rw / 2, s1: Math.max(...hs) + rw / 2, t0: Math.min(...ht) - rw / 2, t1: Math.max(...ht) + rw / 2 };
      });
    const member = (role, a, b) => out.push({ role, a, b, za: base + planeHeight(pl, a), zb: base + planeHeight(pl, b), plane: pl });
    const at0 = (sv, tv) => add(pl.p, add(scale(e, sv), scale(m, tv)));
    for (let i = 0; i < n; i++) {
      const sv = first + i * spacing;
      const at = add(pl.p, scale(e, sv));
      for (const [a, b] of clipLine(at, m, f.poly)) {
        if (dist(a, b) < 300) continue;
        // A rafter through an opening stops at its headers.
        const o = openings.find((x) => sv > x.s0 && sv < x.s1);
        if (!o) {
          member('rafter', a, b);
          continue;
        }
        const ta = dot(sub(a, pl.p), m);
        const tb = dot(sub(b, pl.p), m);
        const [lo, hi] = ta < tb ? [a, b] : [b, a];
        const tlo = Math.min(ta, tb);
        const thi = Math.max(ta, tb);
        if (o.t0 - tlo > 100) member('rafter', lo, at0(sv, o.t0));
        if (thi - o.t1 > 100) member('rafter', at0(sv, o.t1), hi);
      }
    }
    // Each opening: doubled rafters (trimmers) up both sides, headers across its top and bottom between them.
    for (const o of openings) {
      for (const sv of [o.s0 - rw / 2, o.s1 + rw / 2])
        for (const [a, b] of clipLine(add(pl.p, scale(e, sv)), m, f.poly)) if (dist(a, b) >= 300) member('trimmer', a, b);
      for (const tv of [o.t0 - rw / 2, o.t1 + rw / 2]) member('header', at0(o.s0 - rw, tv), at0(o.s1 + rw, tv));
    }
    // A purlin across a long plane, at mid-run, under the rafters.
    const ts = f.poly.map((p) => dot(sub(p, pl.p), m));
    const t0 = Math.max(0, Math.min(...ts));
    const t1 = Math.max(...ts);
    if (t1 - t0 > purlinRun) {
      const at = add(pl.p, scale(m, (t0 + t1) / 2));
      const drop = FRAMING.rafter.depth / Math.cos(Math.atan(pl.k));
      for (const [a, b] of clipLine(at, e, f.poly)) if (dist(a, b) >= 300) out.push({ role: 'purlin', a, b, za: base + planeHeight(pl, a) - drop, zb: base + planeHeight(pl, b) - drop });
    }
  }
  // Collar and tie beams: across each pair of opposite planes, along each of the first plane's rafter lines.
  if (collars || ties)
    for (let i = 0; i < planes.length; i++)
      for (let j = i + 1; j < planes.length; j++) {
        const A = planes[i];
        const B = planes[j];
        if (A.level || B.level || dot(A.m, B.m) > -0.99) continue;
        const faceA = faces.find((f) => f.plane === A);
        const faceB = faces.find((f) => f.plane === B);
        if (!faceA || !faceB) continue;
        const e = [-A.m[1], A.m[0]];
        const ss = faceA.poly.map((p) => dot(sub(p, A.p), e));
        const s0 = Math.min(...ss);
        const s1 = Math.max(...ss);
        const n = Math.max(1, Math.floor((s1 - s0) / spacing));
        const first = s0 + (s1 - s0 - (n - 1) * spacing) / 2;
        for (let r = 0; r < n; r++) {
          const at = add(A.p, scale(e, first + r * spacing));
          // Along the line up A: A's height rises, B's falls; they meet at the ridge.
          const hA = (t) => planeHeight(A, add(at, scale(A.m, t)));
          const kA = A.k;
          const kB = B.k * dot(B.m, A.m);
          const h0A = hA(0);
          const h0B = planeHeight(B, at);
          const tR = (h0B - h0A) / (kA - kB);
          if (!(tR > 0)) continue;
          const hR = h0A + kA * tR;
          const point = (h, plane) => {
            // Where plane's height along the line is h.
            const t = plane === A ? (h - h0A) / kA : (h - h0B) / kB;
            return add(at, scale(A.m, t));
          };
          const pairs = [];
          if (collars) pairs.push(['collar', hR * collarAt]);
          if (ties && r % 2 === 0) pairs.push(['tie', 0]);
          for (const [role, h] of pairs) {
            const pa = point(h, A);
            const pb = point(h, B);
            const inside = (p, f) => pointInPolygon(p, f.poly) || f.poly.some((q, k) => dist(p, q) < 5 || distLine(p, q, f.poly[(k + 1) % f.poly.length]) < 5);
            if (dist(pa, pb) < 300 || !inside(pa, faceA) || !inside(pb, faceB)) continue;
            out.push({ role, a: pa, b: pb, za: base + h, zb: base + h });
          }
        }
      }
  // Ridge beams (level) and hip or valley rafters (sloping), where two planes meet.
  for (const [a, b] of ridges) {
    const za = zAt(a);
    const zb = zAt(b);
    out.push({ role: Math.abs(za - zb) < 10 ? 'ridge' : 'hip', a, b, za, zb });
  }
  // Wall plates along the pivot lines of the planes that start at height 0 (the eaves).
  const pivot = roof.boundary.length > 1 && dist(roof.boundary[0], roof.boundary.at(-1)) < 1e-6 ? roof.boundary.slice(0, -1) : roof.boundary;
  for (let i = 0; i < pivot.length; i++) {
    const a = pivot[i];
    const b = pivot[(i + 1) % pivot.length];
    const s = Array.isArray(roof.slopes) ? +roof.slopes[i] : 0;
    if (!(s > 0) || dist(a, b) < 300) continue;
    out.push({ role: 'plate', a, b, za: base + roofHeightAt(planes, a), zb: base + roofHeightAt(planes, b) });
  }
  // Nothing outside the roof's outline.
  return out.filter((x) => x.za >= base - 1 && x.zb >= base - 1 && poly.length >= 3).map(({ plane, ...x }) => x);
}

function distLine(p, a, b) {
  const d = sub(b, a);
  const l2 = dot(d, d) || 1;
  const t = Math.max(0, Math.min(1, dot(sub(p, a), d) / l2));
  return dist(p, add(a, scale(d, t)));
}

/** The pieces of the line through p along d that lie inside a polygon. */
function clipLine(p, d, poly) {
  const ts = [];
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const r = sub(b, a);
    const den = d[0] * r[1] - d[1] * r[0];
    if (Math.abs(den) < 1e-12) continue;
    const w = sub(a, p);
    const t = (w[0] * r[1] - w[1] * r[0]) / den;
    const u = (w[0] * d[1] - w[1] * d[0]) / den;
    if (u >= -1e-9 && u < 1 - 1e-9) ts.push(t);
  }
  ts.sort((x, y) => x - y);
  const out = [];
  for (let i = 0; i + 1 < ts.length; i += 2) if (ts[i + 1] - ts[i] > 1) out.push([add(p, scale(d, ts[i])), add(p, scale(d, ts[i + 1]))]);
  return out;
}

/**
 * Make (or remake) the framing of a roof in a document: beams on the roof's
 * level, with timber beam types made on first use, tagged with the roof
 * (framingOf) so a second run replaces them. Returns the beam ids.
 */
export function makeRoofFraming(doc, roof, opts) {
  // Members placed one by one (framingManual) stay when the framing is made again.
  for (const old of doc.all('beam').filter((x) => x.framingOf === roof.id && !x.framingManual)) doc.remove(old.id);
  return addFramingMembers(doc, roof, roofFraming(doc, roof, opts));
}

/** Add framing members [{ role, a, b, za, zb }] of a roof as beams (inside a transaction). Returns their ids. */
export function addFramingMembers(doc, roof, members, { manual = false } = {}) {
  const types = {};
  const typeFor = (role) => {
    if (types[role]) return types[role];
    const spec = FRAMING[role] || FRAMING.rafter;
    const t = doc.all('beamType').find((x) => x.name === spec.name) || doc.add({ kind: 'beamType', familyName: 'Beam', name: spec.name, width: spec.width, depth: spec.depth, materialId: 'mat-wood' });
    return (types[role] = t);
  };
  const lev = levelElevation(doc, roof.levelId);
  return members.map((x) => doc.add({ kind: 'beam', typeId: typeFor(x.role).id, levelId: roof.levelId, a: x.a, b: x.b, offset: Math.round(x.za - lev), endOffset: Math.round(x.zb - lev), framingOf: roof.id, framingRole: x.role, ...(manual ? { framingManual: true } : {}) }).id);
}

// Members placed one by one (RoofMaker's Create a rafter / hip or valley rafter / purlin / eaves purlin / trimmer,
// Create multiple rafters) -----------------------------------------------------------------------------------

/** The roof whose outline holds a plan point (the highest when several do), or null. */
export function roofAt(doc, p) {
  const rs = doc.all('roof').filter((r) => r.boundary?.length >= 3 && pointInPolygon(p, r.boundary));
  return rs.sort((a, b) => levelElevation(doc, b.levelId) + (+b.baseOffset || 0) - (levelElevation(doc, a.levelId) + (+a.baseOffset || 0)))[0] || null;
}

/**
 * One member of a role from a to b, its top on the roof's planes there: rafters, hip and valley rafters, trimmers
 * and eaves purlins on the plane, purlins under the rafters (one rafter depth lower, measured square to the slope).
 */
export function roofMember(doc, roof, role, a, b) {
  const base = levelElevation(doc, roof.levelId) + (+roof.baseOffset || 0);
  const { planes } = roofFaces(roof.boundary, roof.slopes, { levels: roof.levels, overhangs: roof.overhangs });
  if (!planes.length) return null;
  const z = (p) => base + roofHeightAt(planes, p);
  let drop = 0;
  if (role === 'purlin') {
    const m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    const pl = planes.reduce((best, q) => (planeHeight(q, m) < planeHeight(best, m) ? q : best), planes[0]);
    drop = FRAMING.rafter.depth / Math.cos(Math.atan(pl.k || 0));
  }
  return { role, a, b, za: z(a) - drop, zb: z(b) - drop };
}

/**
 * Rafters at a spacing on the roof face under the middle of a→b, between the two clicked points measured across
 * the slope, each running the face's full length up the slope.
 */
export function rafterRow(doc, roof, a, b, spacing = 600) {
  const base = levelElevation(doc, roof.levelId) + (+roof.baseOffset || 0);
  const { faces } = roofFaces(roof.boundary, roof.slopes, { levels: roof.levels, overhangs: roof.overhangs });
  const mid = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  const f = faces.find((x) => x.plane?.k > 0 && pointInPolygon(mid, x.poly)) || faces.find((x) => x.plane?.k > 0);
  if (!f) return [];
  const pl = f.plane;
  const e = [-pl.m[1], pl.m[0]];
  const s0 = Math.min(dot(sub(a, pl.p), e), dot(sub(b, pl.p), e));
  const s1 = Math.max(dot(sub(a, pl.p), e), dot(sub(b, pl.p), e));
  const out = [];
  const step = Math.max(100, spacing);
  for (let sv = s0; sv <= s1 + 1e-6; sv += step)
    for (const [p, q] of clipLine(add(pl.p, scale(e, sv)), pl.m, f.poly)) if (dist(p, q) >= 300) out.push({ role: 'rafter', a: p, b: q, za: base + planeHeight(pl, p), zb: base + planeHeight(pl, q) });
  return out;
}
