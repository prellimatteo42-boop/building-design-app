/**
 * Go to the last view of a kind (Archicad's Navigate menu): the one last
 * shown, or else the last made; and the trace aids that have no document
 * behind them.
 */
const INDEX = new Set(['sheetList', 'viewList']);

/** The group a view belongs to for "Last ...": section, elevation, interior, detail, worksheet, schedule, index or null. */
export function lastViewKey(view) {
  if (!view) return null;
  if (view.kind === 'section') return 'section';
  if (view.kind === 'elevation') return view.interiorOf ? 'interior' : 'elevation';
  if (view.kind === 'schedule') return INDEX.has(view.category) ? 'index' : 'schedule';
  if (view.calloutOf) return 'detail';
  if (view.kind === 'drafting' && !view.doc3d) return 'worksheet';
  return null;
}

/** The view to go to: the one remembered for the key if it is still there, else the newest of its group. */
export function lastViewOf(doc, key, remembered = null) {
  const r = remembered && doc.get(remembered);
  if (r && lastViewKey(r) === key) return r;
  let found = null;
  for (const v of doc.items.values()) if (lastViewKey(v) === key) found = v;
  return found;
}

/** Layer states as text and back: for Undo and Redo Layer Change. */
export const layerSnapshot = (doc) => JSON.stringify(doc.all('layer').map((l) => [l.id, !!l.hidden, !!l.locked, !!l.wireframe]));

/** A history of layer states apart from the general undo. */
export class LayerHistory {
  constructor() {
    this.undoStack = [];
    this.redoStack = [];
    this.current = null;
  }

  /** Note the state after a change; a new state goes on the history. */
  observe(state) {
    if (this.current === null) this.current = state;
    if (state === this.current) return false;
    this.undoStack.push(this.current);
    if (this.undoStack.length > 100) this.undoStack.shift();
    this.redoStack.length = 0;
    this.current = state;
    return true;
  }

  undo() {
    if (!this.undoStack.length) return null;
    this.redoStack.push(this.current);
    this.current = this.undoStack.pop();
    return this.current;
  }

  redo() {
    if (!this.redoStack.length) return null;
    this.undoStack.push(this.current);
    this.current = this.redoStack.pop();
    return this.current;
  }
}
