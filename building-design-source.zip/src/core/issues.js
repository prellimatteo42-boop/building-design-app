/**
 * Issues, as in Archicad's Issue Manager and BCF: a topic with a status,
 * priority, assignee and comments, and a viewpoint (the view, its camera
 * and the selected elements) to go back to.
 *
 *   issue { kind: 'issue', guid, title, type, status, priority, assignedTo, author, created, modified,
 *           description, comments: [{ guid, author, date, text }],
 *           viewpoint: { viewId, camera, selection: [id] }, snapshot: data URL }
 */
export const ISSUE_TYPES = ['Issue', 'Clash', 'Request', 'Remark'];
export const ISSUE_STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed'];
export const ISSUE_PRIORITIES = ['Low', 'Normal', 'High', 'Critical'];

export function uuid() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  const h = () => Math.floor(Math.random() * 0x10000).toString(16).padStart(4, '0');
  return `${h()}${h()}-${h()}-4${h().slice(1)}-${((Math.random() * 4) | 8).toString(16)}${h().slice(1)}-${h()}${h()}${h()}`;
}

const IFC_CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$';

/** A stable IFC GlobalId for an element id, so BCF viewpoints and IFC files name elements alike. */
export function ifcGuidFor(id) {
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  const out = [];
  const s = String(id);
  for (let round = 0; out.length < 22; round++) {
    for (let i = 0; i < s.length; i++) {
      h1 = Math.imul(h1 ^ s.charCodeAt(i), 0x01000193) >>> 0;
      h2 = Math.imul(h2 ^ (s.charCodeAt(i) + round * 31), 0x5bd1e995) >>> 0;
    }
    h1 = Math.imul(h1 ^ (h2 >>> 13), 0x01000193) >>> 0;
    out.push(IFC_CHARS[(h1 ^ h2) & 63], IFC_CHARS[(h1 >>> 6) & 63], IFC_CHARS[(h2 >>> 12) & 63]);
  }
  out[0] = IFC_CHARS[(h1 >>> 3) & 3];
  return out.slice(0, 22).join('');
}

/** Our orbit camera (mm, target/dist/yaw/pitch) as a BCF camera in metres: { eye, dir, up, fov }. */
export function cameraToBCF(cam) {
  const { target, dist, yaw, pitch } = cam;
  const f = [Math.cos(pitch) * Math.cos(yaw), Math.cos(pitch) * Math.sin(yaw), Math.sin(pitch)];
  const eye = [target[0] + dist * f[0], target[1] + dist * f[1], target[2] + dist * f[2]].map((v) => v / 1000);
  const dir = f.map((v) => -v);
  const up = [-Math.sin(pitch) * Math.cos(yaw), -Math.sin(pitch) * Math.sin(yaw), Math.cos(pitch)];
  return { eye, dir, up, fov: cam.fov || 45, persp: cam.persp !== false };
}

/** A BCF camera (metres) as our orbit camera, its target `dist` mm ahead of the eye. */
export function cameraFromBCF({ eye, dir, fov = 45, persp = true }, dist = 15000) {
  const l = Math.hypot(...dir) || 1;
  const d = dir.map((v) => v / l);
  const pitch = Math.asin(Math.max(-1, Math.min(1, -d[2])));
  const yaw = Math.atan2(-d[1], -d[0]);
  const e = eye.map((v) => v * 1000);
  return { target: [e[0] + d[0] * dist, e[1] + d[1] * dist, e[2] + d[2] * dist], dist, yaw, pitch, persp, fov };
}

/** Issues in list order, newest first, optionally of one status. */
export function issuesInOrder(doc, status = null) {
  return doc
    .all('issue')
    .filter((i) => !status || i.status === status)
    .sort((a, b) => String(b.created).localeCompare(String(a.created)));
}
