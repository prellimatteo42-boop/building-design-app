/**
 * Construction Simulation (Archicad's 4D): a schedule of tasks, each with a
 * start and end date and the elements it builds, demolishes or puts up for
 * a while. At a date of the simulation an element not yet built is hidden,
 * one being built or demolished is coloured, a demolished one is gone and a
 * temporary one shows only during its task. Elements in no task always
 * show. The schedule lives in the project and saves to its own file.
 *
 *   project.construction = { name, tasks: [{ id, name, start: 'YYYY-MM-DD', end, action: 'build' | 'demolish' |
 *     'temporary', ids: [elementId] }] }
 */
export const ACTIONS = [
  { value: 'build', label: 'Build' },
  { value: 'demolish', label: 'Demolish' },
  { value: 'temporary', label: 'Temporary' },
];

export const SIM_COLORS = { building: [60, 170, 90], demolishing: [210, 70, 60], temporary: [230, 180, 40] };

export const scheduleOf = (project) => ({ name: 'Construction schedule', tasks: [], ...(project?.construction || {}) });

const day = (d) => (d ? Date.parse(`${d}T00:00:00Z`) : NaN);
export const isoDay = (ms) => new Date(ms).toISOString().slice(0, 10);

/** First start and last end of the tasks: { start, end } (ISO days) or null. */
export function scheduleSpan(project) {
  const t = scheduleOf(project).tasks.filter((x) => Number.isFinite(day(x.start)) && Number.isFinite(day(x.end)));
  if (!t.length) return null;
  return { start: isoDay(Math.min(...t.map((x) => day(x.start)))), end: isoDay(Math.max(...t.map((x) => day(x.end)))) };
}

/** Map element id -> its tasks. Hosted elements follow their host unless they have tasks of their own. */
export function tasksByElement(project) {
  const m = new Map();
  for (const t of scheduleOf(project).tasks) for (const id of t.ids || []) (m.get(id) || m.set(id, []).get(id)).push(t);
  return m;
}

/**
 * State of an element at a date: 'none' (in no task), 'hidden', 'building', 'built', 'demolishing', 'temporary'.
 * byElement from tasksByElement; hostId the element's host.
 */
export function simState(byElement, id, date, hostId = null) {
  const tasks = byElement.get(id) || (hostId ? byElement.get(hostId) : null);
  if (!tasks?.length) return 'none';
  const t = day(date);
  let state = 'built';
  // Build tasks decide when it appears, then demolition when it goes; temporary ones show only during the task.
  const builds = tasks.filter((x) => x.action === 'build' || !x.action);
  const demolish = tasks.filter((x) => x.action === 'demolish');
  const temps = tasks.filter((x) => x.action === 'temporary');
  if (temps.length && !builds.length) {
    const on = temps.find((x) => t >= day(x.start) && t <= day(x.end));
    return on ? 'temporary' : 'hidden';
  }
  if (builds.length) {
    const s = Math.min(...builds.map((x) => day(x.start)));
    const e = Math.max(...builds.map((x) => day(x.end)));
    if (t < s) return 'hidden';
    if (t <= e) state = 'building';
  }
  for (const x of demolish) {
    if (t > day(x.end)) return 'hidden';
    if (t >= day(x.start)) state = 'demolishing';
  }
  return state;
}

/** Dates for an animation: n frames from the start to the end of the schedule. */
export function frameDates(project, n = 30) {
  const sp = scheduleSpan(project);
  if (!sp) return [];
  const a = day(sp.start);
  const b = day(sp.end);
  const out = [];
  for (let i = 0; i < n; i++) out.push(isoDay(a + ((b - a) * i) / Math.max(1, n - 1)));
  return out;
}

/** The schedule as a file (JSON), with each element's IFC GlobalId too so it reopens in a copy of the model. */
export function scheduleFile(doc) {
  const s = scheduleOf(doc.project);
  return JSON.stringify({ format: 'building-design-construction', version: 1, name: s.name, tasks: s.tasks.map((t) => ({ ...t, guids: (t.ids || []).map((id) => doc.get(id)?.ifcGuid || null) })) }, null, 1);
}

/** Read a schedule file into this project's element ids (by id, else by IFC GlobalId). Returns { schedule, missing }. */
export function readScheduleFile(doc, text) {
  const data = JSON.parse(text);
  if (data?.format !== 'building-design-construction') throw new Error('This is not a construction schedule file.');
  const byGuid = new Map();
  for (const el of doc.items.values()) if (el.ifcGuid) byGuid.set(el.ifcGuid, el.id);
  let missing = 0;
  const tasks = (data.tasks || []).map((t) => {
    const ids = [];
    (t.ids || []).forEach((id, i) => {
      const own = doc.has(id) ? id : t.guids?.[i] ? byGuid.get(t.guids[i]) : null;
      if (own) ids.push(own);
      else missing++;
    });
    const { guids: _g, ...rest } = t;
    void _g;
    return { ...rest, ids };
  });
  return { schedule: { name: data.name || 'Construction schedule', tasks }, missing };
}
