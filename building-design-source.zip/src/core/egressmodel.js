/**
 * The escape check on a level of the model (core/egress.js): its walls (as solved, with columns), the doors and
 * openings in them as gaps, its zones with their occupants. Exits on the lowest level are what leads outside; on the
 * levels above, doors marked as exits (`exit`) and those that lead onto a stair standing outside the building.
 * The results go on the zones (`egress`) and, drawn, on the level's plan: each zone's longest way out as a route
 * with an arrow and its length (green when it meets the profile's limits, red when not).
 */
import { egressAnalysis, zoneOccupants, RVITA } from './egress.js';
import { typeThickness } from './catalog.js';
import { columnOutline } from './plan.js';
import { stairFlights, flightOutline } from './stairs.js';
import { levelElevation } from './model.js';
import { withComma } from './units.js';

const STYLE = { ok: { name: 'Escape route', color: '#1f9d55' }, fail: { name: 'Escape route - not compliant', color: '#d03030' } };

/** A gap across a wall at an opening (door or opening element): the polygon the escape walk may pass. */
function gapPoly(doc, wall, el) {
  const L = Math.hypot(wall.b[0] - wall.a[0], wall.b[1] - wall.a[1]) || 1;
  const d = [(wall.b[0] - wall.a[0]) / L, (wall.b[1] - wall.a[1]) / L];
  const n = [-d[1], d[0]];
  const width = +el.width || +doc.get(el.typeId)?.width || 900;
  const half = (typeThickness(doc.get(wall.typeId)) || 200) / 2 + 150;
  // The wall's axis as drawn may be a face (location line): the gap spans both faces whichever it is.
  const off = wall.locationLine === 'exterior' || wall.locationLine === 'left' ? half - 150 : wall.locationLine === 'interior' || wall.locationLine === 'right' ? -(half - 150) : 0;
  const c = [wall.a[0] + d[0] * el.t + n[0] * off, wall.a[1] + d[1] * el.t + n[1] * off];
  const P = (s, w) => [c[0] + d[0] * s + n[0] * w, c[1] + d[1] * s + n[1] * w];
  return { poly: [P(-width / 2, -half), P(width / 2, -half), P(width / 2, half), P(-width / 2, half)], center: c, width };
}

/** What the check needs from a level: { barriers, openings, exits, rooms }. */
export function egressInputs(doc, scene, levelId) {
  const solved = scene.walls.level(levelId);
  const barriers = [...solved.walls.entries()].filter(([id]) => !doc.get(id)?.demolishedId).map(([, g]) => g.poly || [g.R0, g.R1, g.L1, g.L0]).filter((p) => p?.length >= 3);
  for (const c of doc.all('column')) if (c.levelId === levelId) try { const o = columnOutline(doc, c); if (o?.length >= 3) barriers.push(o); } catch { /* a column without an outline */ }
  const levels = doc.levels();
  const lowest = levels.length && levelElevation(doc, levelId) <= Math.min(...levels.map((l) => levelElevation(doc, l.id))) + 1;
  // Stairs outside: their flights and landings, on any level (an external stair reaches the level from below).
  const stairPolys = [];
  for (const s of doc.all('stair')) {
    if (!s.external) continue;
    try {
      const f = stairFlights(doc, s);
      for (const fl of f.flights) stairPolys.push(flightOutline(fl, f.width));
      for (const ld of f.landings) stairPolys.push(ld.poly);
    } catch { /* a stair without flights */ }
  }
  const near = (p) => stairPolys.some((poly) => poly.some((q) => Math.hypot(q[0] - p[0], q[1] - p[1]) < 3000));
  const openings = [];
  const exits = [];
  const maybe = [];
  // What the project takes down is not there to walk through (a door demolished and replaced by a wider one).
  for (const el of [...doc.all('door'), ...doc.all('opening')]) {
    if (el.demolishedId) continue;
    const wall = doc.get(el.hostId);
    if (!wall || wall.kind !== 'wall' || wall.levelId !== levelId || wall.arc) continue;
    const g = gapPoly(doc, wall, el);
    openings.push({ id: el.id, poly: g.poly, width: g.width });
    if (el.exit === true) exits.push(el.id);
    else if (!lowest && near(g.center)) maybe.push(el.id);
  }
  const rooms = doc.all('room').filter((r) => r.levelId === levelId && !r.demolishedId).map((r) => {
    const g = scene.rooms.room(r);
    return g?.outer ? { id: r.id, name: `${r.number ? `${r.number} ` : ''}${r.name || ''}`.trim(), poly: g.outer, occupants: zoneOccupants(r.name, g.area, { occupants: r.occupants, beds: r.beds }) } : null;
  }).filter(Boolean);
  return { barriers, openings, exits: lowest ? null : exits, maybeExits: maybe, rooms, lowest };
}

/** Run the check on a level: the result (core/egress.js) with the exits' names. */
export function checkLevel(doc, scene, levelId, profile = 'Ciii2', { cell = 150 } = {}) {
  const inp = egressInputs(doc, scene, levelId);
  const res = egressAnalysis({ ...inp, profile, cell });
  for (const e of res.exits) {
    const el = doc.get(e.id);
    e.name = el?.mark ? `${el.kind === 'door' ? 'Door' : 'Opening'} ${el.mark}` : el?.kind || e.id;
  }
  return { ...res, levelId, lowest: inp.lowest };
}

/** Write the results on the zones and draw the routes on the level's plan (inside a transaction). */
export function applyEgress(doc, res, planView) {
  for (const r of res.rooms) doc.update(r.id, { egress: { les: Math.round(r.les * 100) / 100, lcc: Math.round(r.lcc * 100) / 100, occupants: r.occupants, ok: r.ok, profile: res.profile } });
  if (!planView) return 0;
  // The earlier drawing goes.
  for (const el of [...doc.items.values()]) if (el.egressMark && el.viewId === planView.id) doc.remove(el.id);
  const styleId = (k) => {
    const s = STYLE[k];
    let st = doc.all('lineStyle').find((x) => x.name === s.name);
    if (!st) st = doc.add({ kind: 'lineStyle', name: s.name, weight: 3, dash: k === 'ok' ? 0 : 6, color: s.color });
    return st.id;
  };
  let n = 0;
  const scale = +planView.scale || 100;
  for (const r of res.rooms) {
    if (r.path.length < 2 || !(r.occupants > 0 || !r.ok)) continue;
    const style = styleId(r.ok ? 'ok' : 'fail');
    for (let i = 0; i + 1 < r.path.length; i++) doc.add({ kind: 'detailLine', viewId: planView.id, a: r.path[i], b: r.path[i + 1], style, egressMark: true });
    // An arrow at the exit end.
    const b = r.path.at(-1);
    const a = r.path.at(-2);
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
    const u = [(b[0] - a[0]) / L, (b[1] - a[1]) / L];
    const s = 2.5 * scale;
    for (const k of [-1, 1]) doc.add({ kind: 'detailLine', viewId: planView.id, a: b, b: [b[0] - u[0] * s - u[1] * s * 0.5 * k, b[1] - u[1] * s + u[0] * s * 0.5 * k], style, egressMark: true });
    const f = r.path[0];
    doc.add({ kind: 'text', viewId: planView.id, at: [f[0], f[1]], text: `${withComma(r.les.toFixed(1), doc.units)} m`, size: 1.8, align: 'left', egressMark: true });
    n++;
  }
  return n;
}

export { RVITA };
