/**
 * Lamps that light the 3D model (Archicad's Lamp tool: light sources in
 * lighting fixtures, reimplemented): every lighting fixture component is a
 * point light with its own on/off switch, luminous flux, colour temperature
 * and reach. The renderer takes the brightest lamps near the camera and adds
 * their light to the sun and sky; the fixtures themselves glow when lit.
 *
 * Element settings (component): lightOn (default true), lightLumens,
 * lightKelvin, lightRange (mm; 0 = from the flux), lightZ (emitter height
 * above the fixture's base, mm; default by the fixture).
 */

export const LAMP_DEFAULTS = { lumens: 800, kelvin: 3000, range: 0 };
/** How many lamps the renderer can take at once. */
export const MAX_LAMPS = 16;

/** Whether an element is a lamp: a component of a lighting fixture type (or an Archicad light). */
export function isLamp(doc, el) {
  if (el?.kind !== 'component') return false;
  const t = doc.get(el.typeId);
  if (!t) return false;
  if (t.category === 'lighting') return true;
  return t.family === 'gdl' && /\b(lamp|light|luce|lampada)\b/i.test(t.name || '');
}

/**
 * Colour of a black body at a temperature (K), as 0..1 RGB (Tanner Helland's
 * fit of the CIE data, good from 1000 to 40000 K).
 */
export function kelvinColor(k) {
  const t = Math.min(40000, Math.max(1000, +k || 3000)) / 100;
  let r;
  let g;
  let b;
  if (t <= 66) {
    r = 255;
    g = 99.4708025861 * Math.log(t) - 161.1195681661;
    b = t <= 19 ? 0 : 138.5177312231 * Math.log(t - 10) - 305.0447927307;
  } else {
    r = 329.698727446 * Math.pow(t - 60, -0.1332047592);
    g = 288.1221695283 * Math.pow(t - 60, -0.0755148492);
    b = 255;
  }
  const c = (x) => Math.min(1, Math.max(0, x / 255));
  return [c(r), c(g), c(b)];
}

/** Reach of a lamp (mm): its own, or grown with the square root of its flux (800 lm reach 4 m). */
export function lampRange(el) {
  const own = +el.lightRange;
  if (own > 0) return own;
  const lm = Math.max(1, +el.lightLumens || LAMP_DEFAULTS.lumens);
  return 4000 * Math.sqrt(lm / LAMP_DEFAULTS.lumens);
}

/**
 * Where a lamp's light comes from, from its fixture's 3D bounds: under a
 * fixture hung or set in the ceiling (base 1 m or more above its level),
 * just under the top of a standing one (floor lamps, street lights), or at
 * lightZ above the base when given. lift: the fixture's base above its level.
 */
export function lampEmitter(el, bounds, lift = +el.offset || 0) {
  if (!bounds) return null;
  const { min, max } = bounds;
  const x = (min[0] + max[0]) / 2;
  const y = (min[1] + max[1]) / 2;
  if (Number.isFinite(+el.lightZ) && el.lightZ !== null && el.lightZ !== '') return [x, y, min[2] + +el.lightZ];
  const hung = lift >= 1000;
  if (hung) return [x, y, min[2] - 30];
  return [x, y, max[2] - Math.min(150, (max[2] - min[2]) * 0.15)];
}

/**
 * The lamps that light a view: [{ id, pos, color, range }], at most MAX_LAMPS,
 * the strongest at the camera first. color is the lamp's colour times its
 * strength (1 for 800 lm). boundsOf(el) gives an element's 3D bounds.
 */
export function lampSources(doc, boundsOf, { eye = null, hidden = null, max = MAX_LAMPS } = {}) {
  const out = [];
  for (const el of doc.all('component')) {
    if (el.lightOn === false || !isLamp(doc, el) || hidden?.(el)) continue;
    const lift = (+el.offset || 0) + (+doc.get(el.typeId)?.elevation || 0);
    const pos = lampEmitter(el, boundsOf(el), lift);
    if (!pos) continue;
    const lm = Math.max(0, +el.lightLumens || LAMP_DEFAULTS.lumens);
    if (!lm) continue;
    const k = lm / LAMP_DEFAULTS.lumens;
    const col = kelvinColor(el.lightKelvin || LAMP_DEFAULTS.kelvin).map((c) => c * k);
    const range = lampRange(el);
    const d = eye ? Math.hypot(pos[0] - eye[0], pos[1] - eye[1], pos[2] - eye[2]) : 0;
    // Fixtures hung or set in the ceiling shine down; wall and standing lamps all round.
    const down = lift >= 1000 && !/wall|sconce/i.test(doc.get(el.typeId)?.name || '') ? 1 : 0;
    out.push({ id: el.id, pos, color: col, range, down, score: k / (1 + (d / range) ** 2) });
  }
  out.sort((a, b) => b.score - a.score);
  return out.slice(0, max).map(({ score: _s, ...rest }) => rest);
}

/** Time of day of a rendering: how much of the sun and sky stays. */
export const DAYLIGHT = [
  { value: 'day', label: 'Day', amount: 1 },
  { value: 'dusk', label: 'Dusk', amount: 0.45 },
  { value: 'night', label: 'Night', amount: 0.14 },
];

/**
 * Light reaching a point from the lamps (what the shader computes): the sum of
 * colour × cos(angle) × spread × fall-off, the fall-off 3 (1 − (d / range)²)² / (1 + (d / 2 m)²),
 * the spread 1 all round or 0.1 + 1.6 cos(angle from straight down) for a downlight.
 */
export function lampLightAt(lamps, p, n) {
  const out = [0, 0, 0];
  for (const l of lamps) {
    const v = [l.pos[0] - p[0], l.pos[1] - p[1], l.pos[2] - p[2]];
    const d = Math.hypot(...v);
    if (d >= l.range || d < 1e-6) continue;
    const c = Math.max(0, (v[0] * n[0] + v[1] * n[1] + v[2] * n[2]) / d);
    const down = l.down || 0;
    const e = 1 + (0.1 + 1.6 * Math.max(0, v[2] / d) - 1) * down;
    const f = (3 * (1 - (d / l.range) ** 2) ** 2) / (1 + (d / 2000) ** 2);
    for (let k = 0; k < 3; k++) out[k] += l.color[k] * c * e * f;
  }
  return out;
}
