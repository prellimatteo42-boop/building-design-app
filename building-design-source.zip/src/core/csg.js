/**
 * Constructive solid geometry on closed triangle meshes with BSP trees:
 * union, subtraction and intersection. Each polygon keeps its vertices'
 * colours and a `part` (a wall layer index), so results draw and cut in
 * sections like the meshes they came from.
 *
 * The method: each solid becomes a BSP tree of its polygons; one solid's
 * polygons are clipped by the other's tree (removing what lies inside or
 * outside), and the remaining pieces of both are combined.
 */

const EPS = 1e-3; // mm: points this close to a plane lie on it

const COPLANAR = 0;
const FRONT = 1;
const BACK = 2;
const SPANNING = 3;

const sub3 = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const lerp3 = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

function planeOf(ps) {
  const n = cross3(sub3(ps[1], ps[0]), sub3(ps[2], ps[0]));
  const l = Math.hypot(n[0], n[1], n[2]);
  if (l < 1e-12) return null;
  const nn = [n[0] / l, n[1] / l, n[2] / l];
  return { n: nn, w: dot3(nn, ps[0]) };
}

/** A polygon: vertices { p, c (rgba) }, its plane, and its part. */
function polygon(vs, part, plane = null) {
  return { vs, part, plane: plane || planeOf(vs.map((v) => v.p)) };
}

function flip(poly) {
  return { vs: poly.vs.slice().reverse(), part: poly.part, plane: { n: poly.plane.n.map((x) => -x), w: -poly.plane.w } };
}

/** Split a polygon by a plane into the four lists. */
function split(plane, poly, coplanarFront, coplanarBack, front, back) {
  let type = 0;
  const types = poly.vs.map((v) => {
    const t = dot3(plane.n, v.p) - plane.w;
    const k = t < -EPS ? BACK : t > EPS ? FRONT : COPLANAR;
    type |= k;
    return k;
  });
  if (type === COPLANAR) (dot3(plane.n, poly.plane.n) > 0 ? coplanarFront : coplanarBack).push(poly);
  else if (type === FRONT) front.push(poly);
  else if (type === BACK) back.push(poly);
  else {
    const f = [];
    const b = [];
    const n = poly.vs.length;
    for (let i = 0; i < n; i++) {
      const j = (i + 1) % n;
      const ti = types[i];
      const tj = types[j];
      const vi = poly.vs[i];
      const vj = poly.vs[j];
      if (ti !== BACK) f.push(vi);
      if (ti !== FRONT) b.push(vi);
      if ((ti | tj) === SPANNING) {
        const t = (plane.w - dot3(plane.n, vi.p)) / dot3(plane.n, sub3(vj.p, vi.p));
        const v = { p: lerp3(vi.p, vj.p, t), c: vi.c.map((x, k) => x + (vj.c[k] - x) * t) };
        f.push(v);
        b.push(v);
      }
    }
    if (f.length >= 3) front.push(polygon(f, poly.part, poly.plane));
    if (b.length >= 3) back.push(polygon(b, poly.part, poly.plane));
  }
}

class Node {
  constructor(polys) {
    this.plane = null;
    this.front = null;
    this.back = null;
    this.polys = [];
    if (polys) this.build(polys);
  }

  invert() {
    // Iterative, to keep deep trees off the call stack.
    const stack = [this];
    while (stack.length) {
      const n = stack.pop();
      n.polys = n.polys.map(flip);
      if (n.plane) n.plane = { n: n.plane.n.map((x) => -x), w: -n.plane.w };
      [n.front, n.back] = [n.back, n.front];
      if (n.front) stack.push(n.front);
      if (n.back) stack.push(n.back);
    }
  }

  /** Polygons of `polys` outside this solid. */
  clipPolygons(polys) {
    if (!this.plane) return polys.slice();
    let front = [];
    let back = [];
    for (const p of polys) split(this.plane, p, front, back, front, back);
    if (this.front) front = this.front.clipPolygons(front);
    back = this.back ? this.back.clipPolygons(back) : [];
    return front.concat(back);
  }

  clipTo(bsp) {
    const stack = [this];
    while (stack.length) {
      const n = stack.pop();
      n.polys = bsp.clipPolygons(n.polys);
      if (n.front) stack.push(n.front);
      if (n.back) stack.push(n.back);
    }
  }

  allPolygons() {
    const out = [];
    const stack = [this];
    while (stack.length) {
      const n = stack.pop();
      out.push(...n.polys);
      if (n.front) stack.push(n.front);
      if (n.back) stack.push(n.back);
    }
    return out;
  }

  build(polys) {
    if (!polys.length) return;
    // Breadth over a work list instead of recursion.
    const work = [[this, polys]];
    while (work.length) {
      const [node, list] = work.pop();
      if (!node.plane) node.plane = list[0].plane;
      const front = [];
      const back = [];
      for (const p of list) split(node.plane, p, node.polys, node.polys, front, back);
      if (front.length) work.push([(node.front ??= new Node()), front]);
      if (back.length) work.push([(node.back ??= new Node()), back]);
    }
  }
}

/** Polygons of a mesh (pos, col, optional parts), one per triangle. */
export function meshPolygons(mesh) {
  const out = [];
  const P = mesh.pos;
  const C = mesh.col;
  for (let t = 0; t < P.length / 9; t++) {
    const vs = [];
    for (let k = 0; k < 3; k++) {
      const i = t * 3 + k;
      vs.push({ p: [P[i * 3], P[i * 3 + 1], P[i * 3 + 2]], c: [C[i * 4], C[i * 4 + 1], C[i * 4 + 2], C[i * 4 + 3]] });
    }
    const poly = polygon(vs, mesh.parts ? mesh.parts[t] : 0);
    if (poly.plane) out.push(poly);
  }
  return out;
}

export function union(a, b) {
  const A = new Node(a);
  const B = new Node(b);
  A.clipTo(B);
  B.clipTo(A);
  B.invert();
  B.clipTo(A);
  B.invert();
  A.build(B.allPolygons());
  return A.allPolygons();
}

export function subtract(a, b) {
  const A = new Node(a);
  const B = new Node(b);
  A.invert();
  A.clipTo(B);
  B.clipTo(A);
  B.invert();
  B.clipTo(A);
  B.invert();
  A.build(B.allPolygons());
  A.invert();
  return A.allPolygons();
}

export function intersect(a, b) {
  const A = new Node(a);
  const B = new Node(b);
  A.invert();
  B.clipTo(A);
  B.invert();
  A.clipTo(B);
  B.clipTo(A);
  A.build(B.allPolygons());
  A.invert();
  return A.allPolygons();
}

/**
 * A mesh from polygons: triangles (fans), flat normals, colours, parts,
 * and feature edges where faces meet at an angle or a surface ends.
 */
export function polygonsMesh(polys, { edgeAngle = 0.35 } = {}) {
  const pos = [];
  const nrm = [];
  const col = [];
  const parts = [];
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  // Edges keyed by their rounded end points, with the normals of the faces on them.
  const key = (p) => `${Math.round(p[0] * 10)},${Math.round(p[1] * 10)},${Math.round(p[2] * 10)}`;
  const edges = new Map();
  for (const poly of polys) {
    const n = poly.plane.n;
    for (let i = 1; i + 1 < poly.vs.length; i++)
      for (const v of [poly.vs[0], poly.vs[i], poly.vs[i + 1]]) {
        pos.push(v.p[0], v.p[1], v.p[2]);
        nrm.push(Math.round(n[0] * 127), Math.round(n[1] * 127), Math.round(n[2] * 127));
        col.push(Math.round(v.c[0]), Math.round(v.c[1]), Math.round(v.c[2]), Math.round(v.c[3]));
        for (let k = 0; k < 3; k++) {
          if (v.p[k] < min[k]) min[k] = v.p[k];
          if (v.p[k] > max[k]) max[k] = v.p[k];
        }
      }
    for (let i = 1; i + 1 < poly.vs.length; i++) parts.push(poly.part ?? 0);
    for (let i = 0; i < poly.vs.length; i++) {
      const a = poly.vs[i].p;
      const b = poly.vs[(i + 1) % poly.vs.length].p;
      const ka = key(a);
      const kb = key(b);
      if (ka === kb) continue;
      const k = ka < kb ? `${ka}|${kb}` : `${kb}|${ka}`;
      if (!edges.has(k)) edges.set(k, { a, b, ns: [] });
      edges.get(k).ns.push(n);
    }
  }
  const out = [];
  for (const e of edges.values()) {
    // Split edges (T vertices) show up once: they are on a boundary of a coplanar split, not a feature.
    let feature = e.ns.length < 2;
    for (let i = 0; i < e.ns.length && !feature; i++)
      for (let j = i + 1; j < e.ns.length; j++) if (dot3(e.ns[i], e.ns[j]) < Math.cos(edgeAngle)) feature = true;
    if (feature && e.ns.length >= 2) out.push(e.a[0], e.a[1], e.a[2], e.b[0], e.b[1], e.b[2]);
  }
  return {
    pos: new Float32Array(pos),
    nrm: new Int8Array(nrm),
    col: new Uint8Array(col),
    edges: new Float32Array(out),
    parts: new Uint8Array(parts),
    bounds: pos.length ? { min, max } : null,
  };
}
