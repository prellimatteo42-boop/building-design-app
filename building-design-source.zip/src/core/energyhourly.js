/**
 * Hourly climate and hourly energy simulation (Archicad's Energy Evaluation
 * uses hourly weather data and a dynamic simulation; this is a simplified,
 * reimplemented counterpart):
 *
 *   - climate: an EnergyPlus weather file (EPW, 8760 hours of dry-bulb
 *     temperature and global, direct normal and diffuse irradiation), or
 *     hours made up from the monthly means (a daily temperature swing and a
 *     clear-sky sun scaled by the clearness index, split by Erbs);
 *   - sun position and irradiance on any tilted, oriented surface
 *     (isotropic sky, ground reflection);
 *   - a single-node thermal model per thermal block, stepped hour by hour
 *     with an implicit (backward Euler) step: the node floats between the
 *     heating and cooling set points and the systems hold it at them.
 */

const RAD = Math.PI / 180;
const DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
const MID = [17, 47, 75, 105, 135, 162, 198, 228, 258, 288, 318, 344];
export const HOURS = 8760;
const MONTH_OF_HOUR = (() => {
  const out = new Uint8Array(HOURS);
  let h = 0;
  DAYS.forEach((d, m) => {
    for (let i = 0; i < d * 24; i++) out[h++] = m;
  });
  return out;
})();
export const monthOfHour = (h) => MONTH_OF_HOUR[h];

// Weather -------------------------------------------------------------------------------------------

/**
 * Read an EPW file: { name, lat, lon, tz, elevation, t, ghi, dni, dhi } with
 * 8760 hourly values (°C, Wh/m²). Leap-year files lose 29 February.
 */
export function parseEPW(text) {
  const lines = String(text).split(/\r?\n/);
  const loc = (lines[0] || '').split(',');
  if (loc[0]?.trim().toUpperCase() !== 'LOCATION') throw new Error('Not an EPW weather file (no LOCATION line)');
  const out = { name: [loc[1], loc[3]].map((x) => (x || '').trim()).filter((x) => x && x !== '-').join(', ') || 'EPW climate', lat: +loc[6], lon: +loc[7], tz: +loc[8], elevation: +loc[9] };
  const t = [];
  const ghi = [];
  const dni = [];
  const dhi = [];
  for (const line of lines.slice(8)) {
    const f = line.split(',');
    if (f.length < 16) continue;
    if (+f[1] === 2 && +f[2] === 29) continue;
    t.push(+f[6]);
    ghi.push(Math.max(0, +f[13] || 0));
    dni.push(Math.max(0, +f[14] || 0));
    dhi.push(Math.max(0, +f[15] || 0));
  }
  if (t.length < HOURS) throw new Error(`The weather file has ${t.length} hours, 8760 needed`);
  return { ...out, t: t.slice(0, HOURS), ghi: ghi.slice(0, HOURS), dni: dni.slice(0, HOURS), dhi: dhi.slice(0, HOURS) };
}

const round1 = (a) => a.map((x) => Math.round(x * 10) / 10);

/** A project climate from an EPW file: monthly means (for the monthly method) and the hours. */
export function climateFromEPW(epw) {
  const temps = Array(12).fill(0);
  const n = Array(12).fill(0);
  epw.t.forEach((x, h) => {
    temps[MONTH_OF_HOUR[h]] += x;
    n[MONTH_OF_HOUR[h]]++;
  });
  // Mean clearness: measured global over the extraterrestrial on the horizontal.
  let g = 0;
  let g0 = 0;
  for (let h = 0; h < HOURS; h++) {
    const s = sunAt(epw.lat, h, { lon: epw.lon, tz: epw.tz });
    if (s.cosZ > 0.05) {
      g += epw.ghi[h];
      g0 += s.g0 * s.cosZ;
    }
  }
  return {
    name: epw.name,
    lat: epw.lat,
    lon: epw.lon,
    tz: epw.tz,
    source: 'epw',
    temps: temps.map((x, m) => Math.round((x / n[m]) * 10) / 10),
    kt: g0 ? Math.round((g / g0) * 100) / 100 : 0.5,
    hourly: { t: round1(epw.t), ghi: epw.ghi.map(Math.round), dni: epw.dni.map(Math.round), dhi: epw.dhi.map(Math.round) },
  };
}

/**
 * The sun at the middle of hour h of the year: { cosZ, az (compass, degrees), g0 (extraterrestrial
 * normal W/m²) }. With lon/tz the hour is clock time, else solar time.
 */
export function sunAt(lat, h, { lon = null, tz = null } = {}) {
  const day = Math.floor(h / 24) + 1;
  const B = ((day - 81) * 2 * Math.PI) / 364;
  const eot = 9.87 * Math.sin(2 * B) - 7.53 * Math.cos(B) - 1.5 * Math.sin(B); // minutes
  let solar = (h % 24) + 0.5;
  if (lon != null && tz != null && Number.isFinite(lon) && Number.isFinite(tz)) solar += (4 * (lon - 15 * tz) + eot) / 60;
  const dec = 23.45 * RAD * Math.sin((2 * Math.PI * (284 + day)) / 365);
  const phi = lat * RAD;
  const w = (solar - 12) * 15 * RAD;
  const cosZ = Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.cos(w);
  const sinZ = Math.sqrt(Math.max(0, 1 - cosZ * cosZ));
  // Azimuth from north, clockwise.
  let az = 180;
  if (sinZ > 1e-6) {
    const c = (Math.sin(dec) * Math.cos(phi) - Math.cos(dec) * Math.sin(phi) * Math.cos(w)) / sinZ;
    az = (Math.acos(Math.max(-1, Math.min(1, c))) * 180) / Math.PI;
    if (w > 0) az = 360 - az;
  }
  return { cosZ, az, g0: 1367 * (1 + 0.033 * Math.cos((2 * Math.PI * day) / 365)) };
}

/** Diffuse fraction of the global horizontal by the hour's clearness (Erbs et al.). */
export function erbs(kt) {
  if (kt <= 0.22) return 1 - 0.09 * kt;
  if (kt <= 0.8) return 0.9511 - 0.1604 * kt + 4.388 * kt ** 2 - 16.638 * kt ** 3 + 12.336 * kt ** 4;
  return 0.165;
}

/**
 * The climate's hours: { t, ghi, dni, dhi, lat, lon, tz } — the file's, or made up from the monthly
 * means: the daily mean follows the months smoothly, swinging ±(2.5 + 5 kt) °C with its peak at 15:00.
 */
export function hourlyClimate(climate) {
  const lat = climate.lat ?? 45;
  if (climate.hourly?.t?.length === HOURS) return { ...climate.hourly, lat, lon: climate.lon, tz: climate.tz };
  const temps = climate.temps;
  const kt = climate.kt ?? 0.5;
  const swing = 2.5 + 5 * kt;
  const t = new Array(HOURS);
  const ghi = new Array(HOURS);
  const dni = new Array(HOURS);
  const dhi = new Array(HOURS);
  for (let h = 0; h < HOURS; h++) {
    const day = Math.floor(h / 24);
    // Daily mean between the two nearest month middles.
    let m1 = MID.findIndex((d) => d > day);
    if (m1 < 0) m1 = 12;
    const m0 = m1 - 1;
    const d0 = m0 < 0 ? MID[11] - 365 : MID[m0];
    const d1 = m1 > 11 ? MID[0] + 365 : MID[m1];
    const T0 = temps[(m0 + 12) % 12];
    const T1 = temps[m1 % 12];
    const mean = T0 + ((T1 - T0) * (day - d0)) / (d1 - d0);
    t[h] = mean + swing * Math.cos(((h % 24) + 0.5 - 15) * ((2 * Math.PI) / 24));
    const s = sunAt(lat, h);
    if (s.cosZ <= 0.01) {
      ghi[h] = dni[h] = dhi[h] = 0;
      continue;
    }
    const G = kt * s.g0 * s.cosZ;
    const D = erbs(kt) * G;
    ghi[h] = G;
    dhi[h] = D;
    dni[h] = (G - D) / s.cosZ;
  }
  return { t, ghi, dni, dhi, lat };
}

/**
 * Irradiance (W/m²) on a surface in hour h: tilt in degrees from horizontal, azimuth compass degrees
 * (null for horizontal). Beam on the surface, isotropic sky diffuse, ground reflection.
 */
export function surfaceIrradiance(hc, h, tilt, azimuth, albedo = 0.2) {
  const G = hc.ghi[h];
  if (G <= 0) return 0;
  const s = sunAt(hc.lat, h, { lon: hc.lon, tz: hc.tz });
  const b = tilt * RAD;
  const cosT = s.cosZ * Math.cos(b) + Math.sqrt(Math.max(0, 1 - s.cosZ * s.cosZ)) * Math.sin(b) * Math.cos((s.az - (azimuth ?? 180)) * RAD);
  return hc.dni[h] * Math.max(0, cosT) * (s.cosZ > 0 ? 1 : 0) + (hc.dhi[h] * (1 + Math.cos(b))) / 2 + (G * albedo * (1 - Math.cos(b))) / 2;
}

/** Yearly and monthly irradiation (kWh/m²) on a surface. */
export function irradiationOn(hc, tilt, azimuth) {
  const months = Array(12).fill(0);
  for (let h = 0; h < HOURS; h++) months[MONTH_OF_HOUR[h]] += surfaceIrradiance(hc, h, tilt, azimuth) / 1000;
  return { months, year: months.reduce((a, b) => a + b, 0) };
}

// Simulation -------------------------------------------------------------------------------------------

/** Internal gains profiles: a factor for each hour of the day (weekday, weekend). */
export const PROFILES = {
  constant: { label: 'Constant', weekday: Array(24).fill(1), weekend: Array(24).fill(1) },
  residential: {
    label: 'Residential',
    weekday: [0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.9, 1.3, 0.9, 0.6, 0.6, 0.6, 0.8, 0.8, 0.6, 0.6, 0.8, 1.2, 1.6, 1.8, 1.8, 1.6, 1.2, 0.8],
    weekend: [0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.7, 1.0, 1.3, 1.3, 1.2, 1.2, 1.4, 1.3, 1.1, 1.1, 1.2, 1.3, 1.6, 1.8, 1.8, 1.6, 1.2, 0.8],
  },
  office: {
    label: 'Office',
    weekday: [0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.3, 0.9, 2.2, 2.4, 2.4, 2.4, 1.8, 2.2, 2.4, 2.4, 2.3, 1.8, 0.7, 0.3, 0.2, 0.2, 0.2, 0.2],
    weekend: Array(24).fill(0.2),
  },
};

/**
 * Simulate one thermal block for a year. b: { H (W/K), Cm (J/K), area (m²), windows: [{ area, g, azimuth }],
 * inside, cooling (°C, null = no cooling), setback (°C at night or null), internalGains (W/m²), profile,
 * shading, frame, horizonFactor, maxHeating (W, default 1.5 × the design load) }. Returns monthly sums (kWh) { heating, cooling, loss, solar, internal },
 * peaks (W), the hours over the cooling set point and the yearly range of the inside temperature.
 */
export function simulateBlock(hc, b) {
  const dt = 3600;
  const C = b.Cm / dt;
  const H = b.H;
  const prof = PROFILES[b.profile] || PROFILES.constant;
  const months = Array.from({ length: 12 }, () => ({ heating: 0, cooling: 0, loss: 0, solar: 0, internal: 0 }));
  let peakHeating = 0;
  let peakCooling = 0;
  let over = 0;
  let tmin = Infinity;
  let tmax = -Infinity;
  const winFactor = (b.shading ?? 0.9) * (1 - (b.frame ?? 0.25)) * (b.horizonFactor ?? 1);
  // Window irradiance by orientation (one surface per distinct azimuth).
  const groups = new Map();
  for (const w of b.windows || []) {
    const k = Math.round(w.azimuth ?? -1);
    groups.set(k, (groups.get(k) || 0) + w.area * w.g);
  }
  const gainsAt = (h) => {
    let solar = 0;
    for (const [az, ag] of groups) solar += ag * surfaceIrradiance(hc, h, az < 0 ? 0 : 90, az < 0 ? null : az);
    solar *= winFactor;
    const day = Math.floor(h / 24);
    // 1 January counted a Monday.
    const weekend = day % 7 >= 5;
    const internal = (b.internalGains || 0) * b.area * (weekend ? prof.weekend : prof.weekday)[h % 24];
    return { solar, internal };
  };
  const step = (theta, h, record) => {
    const te = hc.t[h];
    const { solar, internal } = gainsAt(h);
    const phi = solar + internal;
    const night = h % 24 < 6 || h % 24 >= 22;
    // A night setback only ever lowers the set point.
    const heatSet = b.setback != null && night && b.setback < b.inside ? b.setback : b.inside;
    let next = (theta * C + H * te + phi) / (C + H);
    let q = 0;
    if (next < heatSet) {
      q = heatSet * (C + H) - theta * C - H * te - phi;
      next = heatSet;
      // The plant's power is limited: after a setback the room comes back up over some hours.
      if (q > qMax) {
        q = qMax;
        next = (theta * C + H * te + phi + q) / (C + H);
      }
    } else if (b.cooling != null && next > b.cooling) {
      q = b.cooling * (C + H) - theta * C - H * te - phi;
      next = b.cooling;
    }
    if (record) {
      const m = months[MONTH_OF_HOUR[h]];
      if (q > 0) {
        m.heating += q / 1000;
        peakHeating = Math.max(peakHeating, q);
      } else if (q < 0) {
        m.cooling += -q / 1000;
        peakCooling = Math.max(peakCooling, -q);
      }
      m.loss += (H * Math.max(0, next - te)) / 1000;
      m.solar += solar / 1000;
      m.internal += internal / 1000;
      if (next > (b.cooling ?? 26) + 0.5) over++;
      tmin = Math.min(tmin, next);
      tmax = Math.max(tmax, next);
    }
    return next;
  };
  // Heating power: 1.5 × the design load at the coldest hour (or b.maxHeating, W).
  let teMin = Infinity;
  for (let h = 0; h < HOURS; h++) teMin = Math.min(teMin, hc.t[h]);
  const qMax = +b.maxHeating > 0 ? +b.maxHeating : Math.max(500, 1.5 * H * Math.max(1, b.inside - teMin));
  // Warm up on the last two weeks of the year, then the year.
  let theta = b.inside;
  for (let h = HOURS - 336; h < HOURS; h++) theta = step(theta, h, false);
  for (let h = 0; h < HOURS; h++) theta = step(theta, h, true);
  return { months, peakHeating, peakCooling, overheatingHours: over, tmin, tmax };
}
