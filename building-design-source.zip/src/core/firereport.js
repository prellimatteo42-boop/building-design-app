/**
 * Fire safety technical report after the Italian fire code (Codice di prevenzione incendi, D.M. 3 agosto 2015, as
 * amended): the activity classified from the model, the performance levels of the ten measures S.1 to S.10 from
 * their attribution criteria and, for tourist accommodation with more than 25 beds, the vertical rule V.5. What the
 * model can show is checked on it: escape (S.4, core/egress.js), the reach of extinguishers (table S.6-5), detectors
 * in the zones (S.7), the enclosure of areas that must be protected (S.3, table V.5-2), the fire rating of what is
 * rated (S.2, table V.5-1), smoke outlets against the floor area (table S.8-5), escape stairs (tables S.4-29, S.4-30).
 *
 * The text is Italian, as the report is filed with the Italian fire service. It is a draft for the engineer who signs
 * it: what the model cannot know (fire load, materials, management) is stated as an assumption or left to check.
 */
import { checkLevel, egressInputs } from './egressmodel.js';
import { RVITA, zoneOccupants, reachAnalysis } from './egress.js';
import { levelElevation, stairLayout } from './model.js';

/** Fire rating text ("REI 60", "EI2 60-C", "R 30") → { r, e, i, minutes, selfClosing, smoke }. */
export function parseRating(text) {
  const s = String(text || '').toUpperCase();
  const m = /\b(R?E?I?W?)\s*(\d{2,3})\b/.exec(s.replace(/EI2|EI1/g, 'EI '));
  if (!m) return null;
  const letters = m[1];
  return { r: letters.includes('R'), e: letters.includes('E'), i: letters.includes('I'), minutes: +m[2], selfClosing: /-\s*C|\bC\d?\b/.test(s), smoke: /SA|S200/.test(s) };
}

/** Areas of an accommodation activity (V.5.2): TA staff, TB common, TC sleeping, TM stores, TO crowded, TK high fire load, TT technical, TZ other. */
export const AREA_NAMES = {
  TA: 'spazi riservati al personale', TB: 'spazi comuni', TC: 'spazi di riposo', TM: 'depositi e archivi (> 25 m², qf > 600 MJ/m²)', TO: 'locali con affollamento > 100 persone', TK: 'locali con qf > 1200 MJ/m²', TT: 'locali tecnici', TZ: 'altre aree',
};

/** The area type of a zone from its own `fireArea`, else from what it is (name, beds, occupants, area). */
export function zoneArea(room, area, occupants) {
  if (AREA_NAMES[room.fireArea]) return { cls: room.fireArea, why: 'assegnata nel modello' };
  const n = String(room.name || '').toLowerCase();
  const m2 = area / 1e6;
  if (occupants > 100) return { cls: 'TO', why: `affollamento ${occupants} > 100` };
  if (+room.beds > 0 || /camer|bedroom|stanza|dormitor|suite/.test(n)) return { cls: 'TC', why: 'locale di riposo' };
  if (/cucin|kitchen|cottura|lavander|laundry|stirer/.test(n)) return { cls: 'TZ', why: 'area a rischio specifico (V.5.2 c.3)', risk: true };
  if (/deposit|magazz|archiv|dispens|storage|store|ripostigl/.test(n)) return m2 > 25 ? { cls: 'TM', why: `deposito di ${m2.toFixed(0)} m² (qf da verificare)` } : { cls: 'TZ', why: 'piccolo deposito' };
  if (/tecnic|central|quadr|server|cabin|plant|caldai|boiler|ced\b/.test(n)) return { cls: 'TT', why: 'locale tecnico' };
  if (/uffic|office|personal|staff|spogliat|direzion/.test(n)) return { cls: 'TA', why: 'spazio del personale' };
  return { cls: 'TB', why: 'spazio comune' };
}

/** Rvita of an area of an accommodation activity (G.3, δα = 2 assumed): staff awake and familiar, guests not, sleeping guests. */
const AREA_RVITA = { TA: 'A2', TB: 'B2', TC: 'Ciii2', TM: 'A2', TO: 'B2', TK: 'A2', TT: 'A2', TZ: 'A2' };

/** Classification by beds (V.5.2 a) and floor height (V.5.2 b). */
export function bedsClass(p) {
  if (p <= 25) return 'p ≤ 25';
  return p <= 50 ? 'PA' : p <= 100 ? 'PB' : p <= 500 ? 'PC' : p <= 1000 ? 'PD' : 'PE';
}
export function heightClass(h) {
  return h <= 12 ? 'HA' : h <= 24 ? 'HB' : h <= 32 ? 'HC' : h <= 54 ? 'HD' : 'HE';
}

/** Fire resistance class of compartments (table V.5-1). */
export function v5Resistance(H, underground) {
  if (underground) return H === 'HA' || H === 'HB' ? 60 : 90;
  return H === 'HA' ? 30 : H === 'HB' ? 60 : 90;
}
/** Fire control level (table V.5-3); TK areas III, IV if deep or large. */
export function v5Control(P, H) {
  if (P === 'PA' || P === 'PB') return H === 'HA' ? 'II' : 'III';
  if (P === 'PC') return 'III';
  return H === 'HA' ? 'III' : H === 'HB' || H === 'HC' ? 'IV' : 'V';
}
/** Detection and alarm level (table V.5-6). */
export function v5Detection(P, H) {
  if (P === 'PD' || P === 'PE') return 'IV';
  if (P === 'PC' && (H === 'HD' || H === 'HE')) return 'IV';
  return 'III';
}
/** Hydrant network parameters (table V.5-4), or null where none is asked. */
export function v5Hydrants(P, H) {
  if (H === 'HD' || H === 'HE') return { hazard: 2, external: true, supply: 'doppia' };
  if (P === 'PA' || P === 'PB') return H === 'HB' || H === 'HC' ? { hazard: 1, external: false, supply: 'singola' } : null;
  if (P === 'PC') return { hazard: 2, external: false, supply: 'singola' };
  return { hazard: 2, external: true, supply: 'singola superiore' };
}

/** Max distance to an extinguisher of class A and its minimum rating (table S.6-5). */
export function extinguisherReach(rvita) {
  const k = String(rvita).replace(/^C(ii|iii)/, 'C');
  if (/^A[12]$/.test(k)) return { m: 40, rating: '13 A' };
  if (/^(A4|B3|C3|E3)$/.test(k)) return { m: 20, rating: '27 A' };
  return { m: 30, rating: '21 A' };
}

/** Unit width of a vertical escape route (table S.4-29) for the floors it serves, mm per person. */
const S429 = {
  A1: [4.0, 3.6, 3.25, 3.0, 2.75, 2.55, 2.4, 2.25, 2.1, 2.0],
  B1: [4.25, 3.8, 3.4, 3.1, 2.85, 2.65, 2.45, 2.3, 2.15, 2.05],
  A2: [4.55, 4.0, 3.6, 3.25, 3.0, 2.75, 2.55, 2.4, 2.25, 2.1],
  B2: [4.9, 4.3, 3.8, 3.45, 3.15, 2.9, 2.65, 2.5, 2.3, 2.15],
  A3: [5.5, 4.75, 4.2, 3.75, 3.35, 3.1, 2.85, 2.6, 2.45, 2.3],
  B3: [7.3, 6.4, 5.7, 5.15, 4.7, 4.3, 4.0, 3.7, 3.45, 3.25],
  A4: [14.6, 11.4, 9.35, 7.95, 6.9, 6.1, 5.45, 4.95, 4.5, 4.15],
};
export function verticalUnitWidth(rvita, floors) {
  const k = String(rvita).replace(/^C(ii|iii)/, 'C');
  const row = /^(B1|C1|E1)$/.test(k) ? 'B1' : /^(B2|C2|D1|E2)$/.test(k) ? 'B2' : /^(B3|C3|D2|E3)$/.test(k) ? 'B3' : S429[k] ? k : 'B2';
  return S429[row][Math.min(9, Math.max(1, floors) - 1)];
}
/** Increase of the unit width for the steps (table S.4-30): fraction, or null where the steps are not allowed. */
export function stepIncrease(riser, tread) {
  const a = riser / 10;
  const p = tread / 10;
  if (p < 22 || a > 22) return null;
  const col = p >= 30 ? 0 : p >= 25 ? 1 : 2;
  const row = a <= 17 ? 0 : a <= 18 ? 1 : a <= 19 ? 2 : 3;
  return [[0, 0.1, 0.25], [0.05, 0.15, 0.5], [0.15, 0.25, 1], [0.25, 1, 2]][row][col];
}

const EQUIPMENT = [
  ['extinguisher', /estint|extinguish/i, 'Estintori'],
  ['hose', /naspo|idrant|hose|hydrant/i, 'Naspi e idranti'],
  ['detector', /rivelat|detector|smoke|fumo/i, 'Rivelatori'],
  ['callpoint', /pulsant|call ?point|manual alarm|break glass|^fire alarm$|handfirealarm/i, 'Pulsanti di allarme'],
  ['sign', /emergency exit|uscita di emergenza|exit sign|escape door/i, 'Cartelli di uscita'],
  ['light', /illuminazione di emergenza|emergency light|lampada di emergenza/i, 'Luci di emergenza'],
  ['sounder', /siren|sounder|targa ottic|horn/i, 'Avvisatori ottico-acustici'],
  ['gas', /range gas|gas range|fornell.*gas|cucina a gas|gas cooktop|gas hob/i, 'Apparecchi di cottura a gas'],
  ['lift', /elevator|ascensor|lift\b/i, 'Ascensori'],
];

function inPoly(p, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const b = poly[j];
    if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < ((b[0] - a[0]) * (p[1] - a[1])) / (b[1] - a[1]) + a[0]) inside = !inside;
  }
  return inside;
}

/** Equipment placed in the model, by kind: [{ id, kind, levelId, at, name }]. */
export function fireEquipment(doc) {
  const out = [];
  for (const el of doc.all('component')) {
    if (el.demolishedId) continue;
    const t = doc.get(el.typeId);
    const names = [t?.name || '', el.name || ''].filter(Boolean);
    const hit = EQUIPMENT.find(([, re]) => names.some((n) => re.test(n)));
    if (hit && el.at) out.push({ id: el.id, kind: hit[0], levelId: el.levelId, at: el.at, name: t?.name || el.name || hit[2] });
  }
  return out;
}

/** Distance from a point to a polygon's outline. */
function edgeDistance(p, poly) {
  let best = Infinity;
  for (let k = 0; k < poly.length; k++) {
    const a = poly[k];
    const b = poly[(k + 1) % poly.length];
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy || 1)));
    best = Math.min(best, Math.hypot(p[0] - a[0] - dx * t, p[1] - a[1] - dy * t));
  }
  return best;
}

/** The walls around a zone (sampled along its outline, just outside it), how much of the outline they close, and its doorways. */
export function zoneEnclosure(doc, scene, levelId, poly) {
  const solved = scene.walls.level(levelId);
  const walls = [...solved.walls.entries()].filter(([id]) => !doc.get(id)?.demolishedId).map(([id, g]) => ({ id, poly: g.poly || [g.R0, g.R1, g.L1, g.L0] })).filter((w) => w.poly?.every(Boolean));
  // Outward is away from the polygon's inside: test both sides of each edge.
  const found = new Set();
  let hit = 0;
  let n = 0;
  for (let k = 0; k < poly.length; k++) {
    const a = poly[k];
    const b = poly[(k + 1) % poly.length];
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
    if (L < 1) continue;
    const t = [(b[0] - a[0]) / L, (b[1] - a[1]) / L];
    const nrm = [-t[1], t[0]];
    const steps = Math.max(1, Math.round(L / 200));
    for (let s = 0; s < steps; s++) {
      const c = [a[0] + t[0] * L * ((s + 0.5) / steps), a[1] + t[1] * L * ((s + 0.5) / steps)];
      const pIn = [c[0] + nrm[0] * 30, c[1] + nrm[1] * 30];
      const sign = inPoly(pIn, poly) ? -1 : 1;
      const q = [c[0] + nrm[0] * 60 * sign, c[1] + nrm[1] * 60 * sign];
      n++;
      const w = walls.find((x) => inPoly(q, x.poly));
      if (w) (hit++, found.add(w.id));
    }
  }
  const wallIds = [...found];
  // The doorways of this zone: in its walls and along its outline (a long wall also has the next rooms' doors).
  const doors = [...doc.all('door'), ...doc.all('opening')].filter((d) => {
    if (d.demolishedId || !wallIds.includes(d.hostId)) return false;
    const w = doc.get(d.hostId);
    const L = Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]) || 1;
    const c = [w.a[0] + ((w.b[0] - w.a[0]) * d.t) / L, w.a[1] + ((w.b[1] - w.a[1]) * d.t) / L];
    return edgeDistance(c, poly) < 600;
  }).map((d) => d.id);
  return { wallIds, doors, closed: n ? hit / n : 0 };
}

const fmt = (v, d = 1) => (Number.isFinite(v) ? v.toFixed(d).replace('.', ',') : '—');

/**
 * The report: { title, data, measures: [{ code, title, level, why, requirements, checks: [{ text, status, detail }] }],
 * checks (all, flat), limits }. Options: profile (reference Rvita for escape, default the project's or Ciii2),
 * rbeni (1-4), activity ('auto' | 'V.5' | 'RTO').
 */
export function fireReport(doc, scene, { profile = null, rbeni = 1, activity = 'auto', cell = 150 } = {}) {
  const pj = doc.project || {};
  const ref = profile || pj.egressProfile || 'Ciii2';
  const levels = doc.levels().slice().sort((a, b) => levelElevation(doc, a.id) - levelElevation(doc, b.id));
  const roomsAll = doc.all('room').filter((r) => !r.demolishedId);
  const withRooms = levels.filter((l) => roomsAll.some((r) => r.levelId === l.id));
  const ground = withRooms.length ? Math.min(...withRooms.map((l) => levelElevation(doc, l.id))) : 0;
  const lv = withRooms.map((l) => {
    const zones = roomsAll.filter((r) => r.levelId === l.id).map((r) => {
      const g = scene.rooms.room(r);
      const area = g?.area || 0;
      const occ = zoneOccupants(r.name, area, { occupants: r.occupants, beds: r.beds });
      const a = zoneArea(r, area, occ);
      return { id: r.id, name: `${r.number ? `${r.number} ` : ''}${r.name || ''}`.trim() || r.id, area, occ, beds: +r.beds || 0, poly: g?.outer, ...a, rvita: AREA_RVITA[a.cls] };
    });
    return { id: l.id, name: l.name, h: (levelElevation(doc, l.id) - ground) / 1000, zones, area: zones.reduce((s, z) => s + z.area, 0) / 1e6, occ: zones.reduce((s, z) => s + z.occ, 0), beds: zones.reduce((s, z) => s + z.beds, 0) };
  });
  const beds = lv.reduce((s, l) => s + l.beds, 0);
  const occTot = lv.reduce((s, l) => s + l.occ, 0);
  const hMax = lv.length ? Math.max(...lv.map((l) => l.h)) : 0;
  const hMin = lv.length ? Math.min(...lv.map((l) => l.h)) : 0;
  const P = bedsClass(beds);
  const H = heightClass(hMax);
  const v5 = activity === 'V.5' || (activity === 'auto' && beds > 25);
  const small = v5 && beds <= 25;
  const sleeping = /^C/.test(ref) || lv.some((l) => l.zones.some((z) => z.cls === 'TC'));
  const ciii = /^Ciii/.test(ref) || sleeping;
  const equipment = fireEquipment(doc);
  const eqOn = (k, levelId) => equipment.filter((e) => e.kind === k && (!levelId || e.levelId === levelId));
  const classReq = v5 ? v5Resistance(H, hMin < -1) : null;

  const measures = [];
  const M = (code, title, level, why, requirements = [], checks = []) => measures.push({ code, title, level, why, requirements, checks });
  const C = (text, status, detail = '') => ({ text, status, detail });

  // S.1 Reazione al fuoco
  M('S.1', 'Reazione al fuoco', 'III vie d’esodo, II altri locali', `Rvita di riferimento ${ref} (tabelle S.1-2 e S.1-3).`, [
    'Vie d’esodo (corridoi, atri, scale, filtri, spazi calmi): materiali del gruppo GM2 (S.1.4.2).',
    'Altri locali: materiali del gruppo GM3 (S.1.4.1).',
    ...(v5 ? ['Aree TC: mobili imbottiti e tendaggi del gruppo GM2 (V.5.4.1 c.1).', 'Fuori dalle aree TC, rivestimenti in legno GM4 ammessi fino al 25% della superficie lorda interna (V.5.4.1 c.2).'] : []),
  ], [C('Classi di reazione al fuoco dei materiali', 'check', 'Il modello non contiene le classi di reazione al fuoco: da attestare con le certificazioni dei prodotti.')]);

  // S.2 Resistenza al fuoco
  const rated = [];
  for (const k of ['wall', 'floor', 'column', 'beam', 'door', 'roof']) for (const el of doc.all(k)) if (!el.demolishedId && el.fireRating) rated.push(el);
  const under = rated.filter((el) => el.kind !== 'door' && classReq && (parseRating(el.fireRating)?.minutes || 0) < classReq);
  const structural = ['column', 'beam', 'floor'].reduce((s, k) => s + doc.all(k).filter((e) => !e.demolishedId && !e.fireRating).length, 0);
  M('S.2', 'Resistenza al fuoco', 'III', v5 ? `Attività ${P}, ${H}: classe minima ${classReq} (tabella V.5-1).` : 'Opera non ricompresa nei livelli I e II (tabella S.2-2).', [
    classReq ? `Classe di resistenza al fuoco dei compartimenti non inferiore a ${classReq} (R ${classReq} per le strutture portanti, REI/EI ${classReq} per quelle separanti).` : 'Classe da determinare con il carico di incendio specifico di progetto qf,d (S.2.4).',
    ...(v5 && lv.length === 1 && hMin >= -1 && hMax < 1 ? ['Attività su un unico piano a quota tra -1 e 1 m: ammessa la classe 15 alle condizioni di V.5.4.2 c.2.'] : []),
  ], [
    C(`Elementi con resistenza al fuoco dichiarata: ${rated.length}`, under.length ? 'ko' : rated.length ? 'ok' : 'check', under.length ? `Sotto la classe ${classReq}: ${under.map((e) => `${e.kind} ${e.mark || e.id} (${e.fireRating})`).join(', ')}.` : ''),
    C('Strutture portanti (pilastri, travi, solai) senza classe dichiarata', structural ? 'check' : 'ok', structural ? `${structural} elementi: da attestare (tabellare, analitico o sperimentale, S.2.4).` : ''),
  ]);

  // S.3 Compartimentazione
  const protectedZones = [];
  for (const l of lv) for (const z of l.zones) {
    const need = ['TO', 'TT', 'TM', 'TK'].includes(z.cls) || (z.risk && /cucin|kitchen|cottura|lavander|laundry|stirer/i.test(z.name));
    if (!need || !z.poly) continue;
    const enc = zoneEnclosure(doc, scene, l.id, z.poly);
    const wallsBad = enc.wallIds.filter((id) => (parseRating(doc.get(id)?.fireRating)?.minutes || 0) < (classReq || 30));
    const doors = enc.doors.map((id) => doc.get(id));
    const doorsBad = doors.filter((d) => {
      const r = parseRating(d.fireRating);
      return d.kind === 'opening' || !r || r.minutes < (classReq || 30) || !r.selfClosing;
    });
    protectedZones.push({ z, level: l.name, enc, wallsBad, doors, doorsBad });
  }
  M('S.3', 'Compartimentazione', ciii ? 'II (III applicabile per occupanti addormentati)' : 'II', 'Attività soggetta (tabella S.3-2).', [
    'Ogni piano costituisce compartimento salvo diversa suddivisione di progetto; superficie massima dei compartimenti secondo tabella S.3-6.',
    ...(v5 ? ['Aree TA, TB, TC: nessun requisito aggiuntivo; TO, TT, TM: di tipo protetto; TK: di tipo protetto con chiusure Sa e resto dell’attività a prova di fumo; lavanderie, stirerie e locali cottura almeno di tipo protetto (tabella V.5-2).'] : []),
    'Chiusure dei vani di comunicazione dei compartimenti e delle aree protette: E/EI con classe del compartimento e dispositivo di autochiusura (-C).',
  ], protectedZones.length ? protectedZones.map((p) => C(`${p.z.name} (${p.level}, ${p.z.cls}): di tipo protetto`, p.enc.closed < 0.6 || p.wallsBad.length || p.doorsBad.length ? 'ko' : 'ok',
    [p.enc.closed < 0.6 ? `pareti trovate solo sul ${Math.round(p.enc.closed * 100)}% del contorno` : `pareti attorno al ${Math.round(p.enc.closed * 100)}% del contorno (il resto sono vani)`, p.wallsBad.length ? `${p.wallsBad.length} pareti senza EI ${classReq || 30}` : 'pareti con classe sufficiente', p.doorsBad.length ? `${p.doorsBad.length} chiusure senza EI ${classReq || 30}-C (${p.doorsBad.map((d) => d.mark || d.id).join(', ')})` : `${p.doors.length} chiusure EI-C`].join('; '))) : [C('Aree di tipo protetto', 'ok', 'Nessuna area del modello richiede la compartimentazione di tipo protetto.')]);

  // S.4 Esodo
  const esc = lv.map((l) => ({ l, r: checkLevel(doc, scene, l.id, ref, { cell }) }));
  const stairs = doc.all('stair').filter((s) => !s.demolishedId);
  const stairChecks = [];
  const upperOcc = lv.filter((l) => l.h > 0.5).reduce((s, l) => s + l.occ, 0);
  const extStairs = stairs.filter((s) => s.external);
  const count = { true: 0, false: 0 };
  for (const s of stairs) {
    let lay;
    try { lay = stairLayout(doc, s); } catch { continue; }
    const inc = stepIncrease(lay.riserHeight, lay.tread);
    const W = +lay.width || +s.width || 0;
    const k = ++count[!!s.external];
    const name = `Scala ${s.mark || `${s.external ? 'esterna' : 'interna'} ${k}`} (${lv.find((l) => l.id === s.levelId)?.name || ''})`;
    if (inc === null) stairChecks.push(C(`${name}: gradini ${fmt(lay.riserHeight / 10)} × ${fmt(lay.tread / 10)} cm`, s.external ? 'ko' : 'check', 'Pedata < 22 cm o alzata > 22 cm: non utilizzabile come via d’esodo (tabella S.4-30).'));
    else {
      const floors = Math.max(1, lv.filter((l) => l.h > 0.5).length);
      const share = s.external && extStairs.length ? Math.ceil(upperOcc / extStairs.length) : 0;
      const LU = verticalUnitWidth(ref, floors) * (1 + inc);
      const need = Math.max(share > 300 ? 1000 : 900, Math.ceil(LU * share));
      stairChecks.push(C(`${name}: gradini ${fmt(lay.riserHeight / 10)} × ${fmt(lay.tread / 10)} cm, larghezza ${Math.round(W)} mm`, !s.external || W >= need ? 'ok' : 'ko', s.external ? `LV = ${fmt(LU, 2)} mm/persona × ${share} occupanti = ${Math.ceil(LU * share)} mm; minima ${need} mm (tabelle S.4-29, S.4-30, S.4-32).` : 'Scala interna non considerata via d’esodo nel calcolo.'));
    }
  }
  M('S.4', 'Esodo', 'I', 'Tutte le attività (tabella S.4-2).', [
    `Profilo di riferimento ${ref}: lunghezza d’esodo Les ≤ ${RVITA[ref]?.les} m, corridoio cieco Lcc ≤ ${RVITA[ref]?.lcc} m (tabelle S.4-25 e S.4-18), larghezza unitaria ${fmt(RVITA[ref]?.unit, 1)} mm/persona (tabella S.4-27).`,
    'Almeno due vie d’esodo indipendenti da ogni piano (S.4.8.1), salvo corridoio cieco ammesso.',
    ...(v5 ? ['Camere e appartamenti con affollamento ≤ 10 occupanti: larghezze delle vie d’esodo secondo le disposizioni specifiche di S.4 (V.5.4.4).'] : []),
  ], [
    ...esc.map(({ l, r }) => C(`${l.name}: ${r.rooms.length} zone, ${r.exits.length} uscite, Les max ${fmt(Math.max(0, ...r.rooms.map((x) => x.les).filter(Number.isFinite)))} m, Lcc max ${fmt(Math.max(0, ...r.rooms.map((x) => x.lcc).filter(Number.isFinite)))} m`, r.ok && r.exits.length >= 2 ? 'ok' : 'ko',
      [r.exits.length < 2 ? 'meno di due uscite' : '', ...r.rooms.filter((x) => !x.ok).map((x) => `${x.name}: Les ${fmt(x.les)} m, Lcc ${fmt(x.lcc)} m`), ...r.exits.filter((e) => !e.ok).map((e) => `uscita ${e.name}: ${e.width} mm, servono ${e.required} mm`)].filter(Boolean).join('; '))),
    ...stairChecks,
  ]);

  // S.5 Gestione
  const s5 = ciii && beds > 100 ? 'III' : 'II';
  M('S.5', 'Gestione della sicurezza antincendio', s5, s5 === 'III' ? 'Oltre 100 posti letto con Rvita Ciii (tabella S.5-2).' : 'Attività non ricompresa nei livelli I e III (tabella S.5-2).', [
    'Responsabile dell’attività, addetti al servizio antincendio, registro dei controlli, piano di manutenzione dei presidi.',
    s5 === 'III' ? 'Struttura di supporto dedicata, centro di gestione delle emergenze, coordinatore degli addetti (S.5.7).' : 'Struttura di supporto, piano di emergenza, formazione e informazione degli occupanti (S.5.6).',
    ...(v5 ? ['In ogni camera: planimetrie del sistema d’esodo e delle attrezzature antincendio, istruzioni multilingue (V.5.4.5).'] : []),
  ], [C('Organizzazione, piano di emergenza, registro', 'check', 'Misure gestionali: da redigere con il responsabile dell’attività.')]);

  // S.6 Controllo dell'incendio
  const s6 = v5 ? v5Control(P, H) : 'II';
  const reach = extinguisherReach(ref);
  const s6checks = [];
  for (const l of lv) {
    const ex = eqOn('extinguisher', l.id);
    if (!ex.length) { s6checks.push(C(`${l.name}: estintori`, 'ko', 'Nessun estintore sul piano (S.6.6.2.1 c.4: almeno uno per piano).')); continue; }
    const inp = egressInputs(doc, scene, l.id);
    const far = reachAnalysis({ barriers: inp.barriers, openings: inp.openings, rooms: inp.rooms, sources: ex.map((e) => e.at), cell }).filter((x) => Number.isFinite(x.max) || x.max === Infinity);
    const bad = far.filter((x) => !(x.max <= reach.m));
    const worst = far.reduce((m, x) => (x.max > m.max ? x : m), { max: 0, name: '' });
    s6checks.push(C(`${l.name}: ${ex.length} estintori, distanza massima di raggiungimento ${fmt(worst.max)} m (${worst.name})`, bad.length ? 'ko' : 'ok', bad.length ? `Oltre ${reach.m} m: ${bad.map((x) => `${x.name} ${fmt(x.max)} m`).join(', ')}.` : `Limite ${reach.m} m (tabella S.6-5).`));
  }
  const hyd = v5 ? v5Hydrants(P, H) : null;
  const hoses = eqOn('hose');
  if (['III', 'IV', 'V'].includes(s6)) s6checks.push(C(`Rete idranti UNI 10779: ${hoses.length} naspi/idranti nel modello`, hoses.length ? 'check' : 'ko', hyd ? `Livello di pericolosità ${hyd.hazard}, protezione esterna ${hyd.external ? 'sì' : 'non richiesta'}, alimentazione ${hyd.supply} (tabella V.5-4); copertura da verificare con il progetto dell’impianto.` : 'Da progettare secondo UNI 10779.'));
  else if (hoses.length) s6checks.push(C(`Naspi/idranti: ${hoses.length} nel modello`, 'ok', 'Non richiesti dal livello II: presidio aggiuntivo.'));
  const kitchens = lv.flatMap((l) => l.zones.filter((z) => /cucin|kitchen|cottura/i.test(z.name)));
  if (kitchens.length) s6checks.push(C(`Locali cottura (${kitchens.map((z) => z.name).join(', ')}): estintori per fuochi di classe F`, 'check', 'Numero e capacità in funzione della superficie delle apparecchiature con oli (tabella S.6-7).'));
  M('S.6', 'Controllo dell’incendio', s6, v5 ? `Attività ${P}, ${H} (tabella V.5-3).` : 'Tabella S.6-2.', [
    `Estintori di classe A estesi a tutta l’attività, capacità minima ${reach.rating}, almeno 6 kg o 6 litri, distanza di raggiungimento ≤ ${reach.m} m, almeno uno per piano (tabella S.6-5); vicino alle uscite e alle aree a rischio specifico, impugnatura a circa 110 cm.`,
    ...(['III', 'IV', 'V'].includes(s6) ? ['Rete idranti secondo UNI 10779 (S.6.8).'] : []),
    ...(['IV', 'V'].includes(s6) ? ['Impianto automatico di controllo o estinzione (sprinkler UNI EN 12845) esteso a porzioni (IV) o a tutta l’attività (V).'] : []),
  ], s6checks);

  // S.7 Rivelazione ed allarme
  const s7 = v5 ? v5Detection(P, H) : 'III';
  const det = eqOn('detector');
  const missing = [];
  for (const l of lv) for (const z of l.zones) {
    if (!z.poly || /bagn|w\.?c\b|toilet|bath|servizi|doccia/i.test(z.name)) continue;
    if (!det.some((d) => d.levelId === l.id && inPoly(d.at, z.poly))) missing.push(`${z.name} (${l.name})`);
  }
  const calls = eqOn('callpoint');
  M('S.7', 'Rivelazione ed allarme', s7, v5 ? `Attività ${P}, ${H} (tabella V.5-6).` : 'Tabella S.7-2.', [
    'IRAI secondo UNI 9795 con funzioni A, B, D, L, C (rivelazione automatica, segnalazione manuale, centrale, alimentazione, allarme) estese a spazi comuni, vie d’esodo, aree con occupanti addormentati e aree a rischio specifico (tabella S.7-3).',
    ...(s7 === 'IV' ? ['Sorveglianza dell’intera attività e sistema EVAC (V.5.4.7 c.2).'] : []),
    ...(v5 ? ['Nelle aree TC con apparecchi a fiamma libera, rivelatori di monossido di carbonio (V.5.4.7 c.3).'] : []),
  ], [
    C(`Rivelatori nel modello: ${det.length}`, missing.length ? 'ko' : det.length ? 'ok' : 'ko', missing.length ? `Zone senza rivelatore: ${missing.slice(0, 40).join(', ')}${missing.length > 40 ? ` e altre ${missing.length - 40}` : ''}.` : 'Ogni zona (bagni esclusi) ha almeno un rivelatore; posizione e numero secondo UNI 9795.'),
    C(`Pulsanti di segnalazione manuale: ${calls.length}`, calls.length ? 'ok' : 'ko', calls.length ? '' : 'Funzione B: pulsanti lungo le vie d’esodo e vicino alle uscite, non presenti nel modello.'),
  ]);

  // S.8 Controllo di fumi e calore
  const s8checks = lv.map((l) => {
    let se = 0;
    for (const w of doc.all('window')) {
      const host = doc.get(w.hostId);
      if (w.demolishedId || host?.levelId !== l.id) continue;
      const t = doc.get(w.typeId);
      se += ((+w.width || +t?.width || 0) * (+w.height || +t?.height || 0)) / 1e6;
    }
    const need = l.area / 40;
    return C(`${l.name}: serramenti ${fmt(se, 1)} m² su ${fmt(l.area, 0)} m² (SE ≥ A/40 = ${fmt(need, 1)} m²)`, se >= need ? 'ok' : 'ko', se >= need ? 'Area lorda dei serramenti: la superficie utile apribile va verificata (S.8.5).' : 'Aperture di smaltimento insufficienti per il dimensionamento SE1.');
  });
  M('S.8', 'Controllo di fumi e calore', 'II', 'Compartimenti non ricompresi nel livello I (tabella S.8-2).', ['Aperture di smaltimento di fumo e calore d’emergenza: SE1 = A/40 per qf ≤ 600 MJ/m² (tabella S.8-5), distribuite nella parte alta dei locali (S.8.5.3).'], s8checks);

  // S.9 Operatività antincendio
  const s9 = ciii && beds > 100 ? 'IV' : 'III';
  M('S.9', 'Operatività antincendio', s9, s9 === 'IV' ? 'Oltre 100 posti letto con Rvita Ciii (tabella S.9-2).' : 'Opera non ricompresa nei livelli II e IV (tabella S.9-2).', [
    'Accostabilità dei mezzi di soccorso ad almeno un accesso; pronta disponibilità di agenti estinguenti (idrante esterno o naspo) entro 500 m; possibilità di arrestare gli impianti tecnologici e di sicurezza da posizione segnalata (S.9.4).',
    ...(s9 === 'IV' ? ['Accessibilità protetta per i Vigili del fuoco a tutti i piani e comunicazione affidabile per i soccorritori.'] : []),
  ], [C('Accesso dei mezzi di soccorso e idrante esterno', 'check', 'Da verificare sulla planimetria generale.')]);

  // S.10 Impianti
  const gas = eqOn('gas');
  const lifts = eqOn('lift');
  M('S.10', 'Sicurezza degli impianti tecnologici e di servizio', 'I', 'Tutte le attività (S.10.3).', [
    'Impianti realizzati a regola d’arte, con arresto in emergenza segnalato; alimentazione di sicurezza dei servizi di sicurezza (tabella S.10-2).',
    ...(v5 ? ['Gas refrigeranti negli impianti di climatizzazione in aree TA, TB, TC, TO classificati A1 o A2L (ISO 817, V.5.4.8).'] : []),
  ], [
    ...(gas.length ? [C(`Apparecchi di cottura a gas: ${gas.length}`, 'check', 'Verificare la portata termica complessiva: oltre 116 kW il locale costituisce attività n. 74 del D.P.R. 151/2011 (regola tecnica del D.M. 8/11/2019).')] : []),
    ...(lifts.length ? [C(`Ascensori: ${lifts.length}`, 'check', 'Non utilizzabili per l’esodo salvo ascensori antincendio o di soccorso (S.4, V.3).')] : []),
  ]);

  const checks = measures.flatMap((m) => m.checks.map((c) => ({ ...c, code: m.code })));
  const title = 'Relazione tecnica di prevenzione incendi';
  return {
    title,
    data: {
      project: pj.name || 'Progetto', client: pj.client || '', address: pj.address || '', number: pj.number || '',
      activity: v5 ? (small ? 'Attività ricettiva in opera da costruzione con non più di 25 posti letto (V.5.5)' : 'Attività ricettiva turistico-alberghiera con oltre 25 posti letto (regola tecnica verticale V.5)') : 'Attività trattata con la sola regola tecnica orizzontale',
      dpr: v5 && !small ? `n. 66 dell’Allegato I al D.P.R. 151/2011 (strutture ricettive con oltre 25 posti letto): categoria ${beds <= 50 ? 'A' : beds <= 100 ? 'B' : 'C'} da confermare sull’Allegato` : '',
      beds, P: v5 ? P : '—', H, hMax, hMin, occTot, ref, rbeni, levels: lv.map(({ id, name, h, area, occ, beds: b, zones }) => ({ id, name, h, area, occ, beds: b, zones: zones.map(({ poly, ...z }) => z) })),
      equipment: EQUIPMENT.map(([k, , label]) => ({ kind: k, label, count: eqOn(k).length })).filter((e) => e.count),
      escape: esc.map(({ l, r }) => ({ level: l.name, rooms: r.rooms.map(({ path, farthest, ...x }) => x), exits: r.exits })),
    },
    measures,
    checks,
    limits: [
      'Velocità caratteristica di crescita dell’incendio δα = 2 (media) assunta per tutte le aree; Rbeni = ' + rbeni + ' (opera non vincolata né strategica), Rambiente non significativo.',
      'Il carico di incendio specifico qf non è nel modello: si assume qf ≤ 600 MJ/m² dove le tabelle lo richiedono; i depositi oltre 25 m² sono classificati TM da verificare.',
      'Quote dei piani misurate dal piano più basso del modello con zone; larghezze delle uscite dal vano netto delle porte.',
      'Le tabelle V.5-3, V.5-4 e V.5-6 sono applicate per classi di posti letto e di quota come lette dal testo coordinato: verificare i casi al limite.',
      'Documento di supporto generato dal modello: non sostituisce la relazione firmata dal professionista antincendio (D.M. 7/8/2012, D.M. 5/8/2011).',
    ],
  };
}

const STATUS = { ok: 'Conforme', ko: 'Non conforme', check: 'Da verificare' };

/** The report as Markdown. */
export function fireReportMarkdown(rep) {
  const d = rep.data;
  const L = [];
  L.push(`# ${rep.title}`, '', `**${d.project}**${d.number ? ` (${d.number})` : ''}${d.client ? `  \nCommittente: ${d.client}` : ''}${d.address ? `  \n${d.address}` : ''}`, '');
  L.push('## 1. Attività e classificazione', '', `- ${d.activity}.`);
  if (d.dpr) L.push(`- Attività ${d.dpr}.`);
  L.push(`- Posti letto: ${d.beds} → **${d.P}**; massima quota dei piani h = ${fmt(d.hMax, 2)} m → **${d.H}** (V.5.2).`, `- Affollamento complessivo: ${d.occTot} occupanti.`, `- Profili di rischio: Rvita di riferimento **${d.ref}**, Rbeni ${d.rbeni}, Rambiente non significativo (G.3).`, '');
  L.push('| Piano | Quota | Superficie | Occupanti | Posti letto |', '|---|---:|---:|---:|---:|');
  for (const l of d.levels) L.push(`| ${l.name} | ${fmt(l.h, 2)} m | ${fmt(l.area, 1)} m² | ${l.occ} | ${l.beds} |`);
  L.push('', '## 2. Aree dell’attività', '', '| Piano | Zona | Superficie | Occupanti | Area | Rvita | Motivo |', '|---|---|---:|---:|---|---|---|');
  for (const l of d.levels) for (const z of l.zones) L.push(`| ${l.name} | ${z.name} | ${fmt(z.area / 1e6, 1)} m² | ${z.occ} | ${z.cls} | ${z.rvita} | ${z.why} |`);
  L.push('', '## 3. Strategia antincendio', '', '| Misura | Livello di prestazione | Criterio |', '|---|---|---|');
  for (const m of rep.measures) L.push(`| ${m.code} ${m.title} | ${m.level} | ${m.why} |`);
  for (const m of rep.measures) {
    L.push('', `### ${m.code} ${m.title} — livello ${m.level}`, '', ...m.requirements.map((r) => `- ${r}`));
    if (m.checks.length) {
      L.push('', '| Verifica sul modello | Esito | Note |', '|---|---|---|');
      for (const c of m.checks) L.push(`| ${c.text} | ${STATUS[c.status]} | ${c.detail.replace(/\|/g, '/')} |`);
    }
  }
  L.push('', '## 4. Esodo per piano', '');
  for (const e of d.escape) {
    L.push(`### ${e.level}`, '', '| Zona | Occupanti | Les | Lcc | Esito |', '|---|---:|---:|---:|---|');
    for (const r of e.rooms) L.push(`| ${r.name} | ${r.occupants} | ${fmt(r.les)} m | ${fmt(r.lcc)} m | ${r.ok ? 'OK' : 'Non conforme'} |`);
    L.push('', '| Uscita | Occupanti | Larghezza | Necessaria | Esito |', '|---|---:|---:|---:|---|');
    for (const x of e.exits) L.push(`| ${x.name} | ${x.occupants} | ${x.width} mm | ${x.required} mm | ${x.ok ? 'OK' : 'Stretta'} |`);
    L.push('');
  }
  if (d.equipment.length) {
    L.push('## 5. Presidi nel modello', '', '| Presidio | Numero |', '|---|---:|');
    for (const e of d.equipment) L.push(`| ${e.label} | ${e.count} |`);
    L.push('');
  }
  const n = (s) => rep.checks.filter((c) => c.status === s).length;
  L.push('## 6. Sintesi delle verifiche', '', `Conformi ${n('ok')}, non conformi ${n('ko')}, da verificare ${n('check')}.`, '');
  for (const c of rep.checks.filter((x) => x.status === 'ko')) L.push(`- **${c.code}** ${c.text}: ${c.detail}`);
  L.push('', '## 7. Ipotesi e limiti', '', ...rep.limits.map((x) => `- ${x}`), '');
  return L.join('\n');
}

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

/** The report as a standalone HTML page (from the Markdown, tables and headings only). */
export function fireReportHTML(rep) {
  return reportPage(fireReportMarkdown(rep), rep.title);
}

/** A Markdown report (headings, lists, paragraphs, tables, bold) as a standalone printable page. */
export function reportPage(md, title) {
  const out = [];
  const lines = md.split('\n');
  const inline = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (l.startsWith('|')) {
      const rows = [];
      while (i < lines.length && lines[i].startsWith('|')) rows.push(lines[i++]);
      i--;
      const cells = (r) => r.slice(1, -1).split('|').map((c) => c.trim());
      const head = cells(rows[0]);
      const body = rows.slice(2).map(cells);
      out.push(`<table><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join('')}</tr></thead><tbody>${body.map((r) => `<tr>${r.map((c) => `<td class="${c === 'Non conforme' || c === 'Stretta' ? 'ko' : c === 'Conforme' || c === 'OK' ? 'ok' : c === 'Da verificare' ? 'chk' : ''}">${inline(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>`);
    } else if (/^#{1,3} /.test(l)) {
      const k = l.match(/^#+/)[0].length;
      out.push(`<h${k}>${inline(l.slice(k + 1))}</h${k}>`);
    } else if (l.startsWith('- ')) {
      const items = [];
      while (i < lines.length && lines[i].startsWith('- ')) items.push(lines[i++].slice(2));
      i--;
      out.push(`<ul>${items.map((x) => `<li>${inline(x)}</li>`).join('')}</ul>`);
    } else if (l.trim()) {
      const p = [l];
      while (i + 1 < lines.length && lines[i + 1].trim() && !/^(#|\||- )/.test(lines[i + 1])) p.push(lines[++i]);
      out.push(`<p>${p.map((x) => (/ {2}$/.test(x) ? `${inline(x.trimEnd())}<br>` : `${inline(x)} `)).join('').trim()}</p>`);
    }
  }
  return `<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>
body{font:14px/1.45 -apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#1c1c1c;max-width:1000px;margin:24px auto;padding:0 16px;background:#fff}
h1{font-size:22px;margin:0 0 8px}h2{font-size:17px;margin:28px 0 8px;border-bottom:1px solid #ccc;padding-bottom:4px}h3{font-size:15px;margin:18px 0 6px}
table{border-collapse:collapse;width:100%;margin:8px 0 12px;font-size:12.5px}th,td{border:1px solid #d4d4d4;padding:4px 6px;text-align:left;vertical-align:top}th{background:#f2f2f2}
td.ok{color:#17803d;font-weight:600}td.ko{color:#c02626;font-weight:600}td.chk{color:#a16207;font-weight:600}
@media print{body{margin:0;max-width:none}h2{page-break-after:avoid}table{page-break-inside:auto}tr{page-break-inside:avoid}}
</style></head><body>${out.join('\n')}</body></html>`;
}
