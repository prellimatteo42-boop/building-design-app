/**
 * Drawings Archicad exported element by element (its DWG translator can write each wall, door, window, opening and zone
 * as a block of its own): the blocks say what each thing is, where the drawing's geometry alone would leave it to guess.
 * A wall's block holds its cut fills and, nested in it, the blocks of the doors and windows it hosts (named after their
 * library parts, on layers named after them); a zone's block is named "Name_Number_n". Archicad names the blocks in the
 * language it runs in, so the words below cover the languages it ships in.
 */
const WORDS = {
  wall: ['wall', 'muro', 'mur', 'wand', 'pared', 'parede', 'стена', 'стіна', 'ściana', 'zeď', 'stena', 'muur', 'vägg', 'væg', 'seinä', 'τοίχος', 'duvar', '壁', '墙'],
  doorway: ['doorway', 'door opening', 'vano porta', 'dverní otvor', 'дверной проем', 'дверной проём', 'дверний проріз', 'türöffnung', 'baie de porte', 'hueco de puerta', 'vão de porta', 'otwór drzwiowy'],
  opening: ['opening', 'apertura', 'öffnung', 'ouverture', 'hueco', 'abertura', 'отверстие', 'отвір', 'otwór', 'otvor', 'opening'],
  door: ['door', 'porta', 'porte', 'tür', 'tuer', 'puerta', 'дверь', 'двері', 'двер', 'drzwi', 'dveře', 'ajtó', 'deur', 'dörr', 'dør', 'ovi', 'πόρτα', 'kapı', 'ドア', '门'],
  window: ['window', 'finestra', 'fenêtre', 'fenetre', 'fenster', 'ventana', 'janela', 'окно', 'вікно', 'okno', 'ablak', 'raam', 'fönster', 'vindue', 'ikkuna', 'παράθυρο', 'pencere', '窓', '窗'],
  stair: ['stair', 'scala', 'treppe', 'escalier', 'escalera', 'escada', 'лестница', 'сходи', 'schody', 'trappa'],
};
const has = (text, kind) => {
  const t = String(text || '').toLowerCase();
  return WORDS[kind].some((w) => t.includes(w));
};
/** What an element block is from its name (and layer): wall, door, window, doorway, opening, stair, or null. */
export function elementKind(name, layer = '') {
  const n = String(name || '').replace(/_\d+$/, '');
  // A window before a door: a French window (portafinestra, Fenstertür) is a window.
  for (const k of ['doorway', 'window', 'door', 'stair', 'wall', 'opening']) if (has(n, k)) return k;
  for (const k of ['window', 'door']) if (has(layer, k)) return k;
  return null;
}

/** Whether a drawn item belongs to a wall element block (in an element-by-element export: a title block's frame does not). */
export function wallBlockTest(flat) {
  const ins = flat.inserts || [];
  const memo = new Map();
  const isWall = (k) => {
    if (k < 0) return false;
    if (memo.has(k)) return memo.get(k);
    let t = k;
    while (ins[t].parent >= 0) t = ins[t].parent;
    const r = elementKind(ins[t].name) === 'wall';
    memo.set(k, r);
    return r;
  };
  return (item) => isWall(item.ins ?? -1);
}

/** Whether a flattened drawing was written by Archicad element by element: several top-level wall blocks named "Wall_n". */
export function isElementExport(flat) {
  const ins = flat.inserts || [];
  return ins.filter((x) => x.parent < 0 && /_\d+$/.test(x.name) && elementKind(x.name) === 'wall').length >= 3;
}

/**
 * The doors, windows and openings of an element-by-element export: [{ kind, at, ext, d, swing, name }], at the middle of
 * what each block draws, ext its length along d (the direction of the wall it sits in, from that wall block's fills),
 * swing [{ hinge, dir }] from a door's leaf arc.
 */
export function exportedOpenings(flat) {
  const ins = flat.inserts || [];
  // The top-level ancestor of every insert, and each insert's own items.
  const top = ins.map((_, i) => { let k = i; while (ins[k].parent >= 0) k = ins[k].parent; return k; });
  const under = (item, i) => { let k = item.ins; while (k >= 0) { if (k === i) return true; k = ins[k].parent; } return false; };
  const out = [];
  for (const [i, x] of ins.entries()) {
    const host = ins[top[i]];
    const nested = x.parent >= 0;
    let kind = nested ? elementKind(x.name, x.layer) : null;
    // A top-level opening block (Archicad's Opening tool) is a hole in a wall.
    if (!nested && /_\d+$/.test(x.name) && elementKind(x.name) === 'opening') kind = 'opening';
    if (!kind || !['door', 'window', 'doorway', 'opening'].includes(kind)) continue;
    // Not a part nested in another opening (a door's own handle block).
    if (nested && ins[x.parent] && elementKind(ins[x.parent].name, ins[x.parent].layer) && ['door', 'window', 'doorway'].includes(elementKind(ins[x.parent].name, ins[x.parent].layer))) continue;
    const lines = flat.lines.filter((l) => under(l, i));
    const arcs = flat.arcs.filter((a) => under(a, i));
    const pts = [...lines.flatMap((l) => [l.a, l.b]), ...arcs.map((a) => a.c)];
    if (!pts.length) continue;
    // The wall's direction: the longest straight line of its wall block (fills or outline), else its own longest line.
    const hostLines = nested ? flat.lines.filter((l) => l.ins >= 0 && top[l.ins] === top[i] && !under(l, i)) : [];
    const fills = nested ? flat.fills.filter((f) => f.ins >= 0 && top[f.ins] === top[i] && !under(f, i)) : [];
    // The direction most of the drawing runs in (by length, wall block and opening together): glass, frames and faces
    // run along the wall, reveals and an open leaf across it, and a wall block only as long as its window has longer
    // reveals than faces.
    const edges = [...hostLines.map((l) => [l.a, l.b]), ...fills.flatMap((f) => f.poly.map((p, k) => [p, f.poly[(k + 1) % f.poly.length]])), ...lines.map((l) => [l.a, l.b])];
    const bins = new Map();
    for (const [p, q] of edges) {
      const L = Math.hypot(q[0] - p[0], q[1] - p[1]);
      if (L < 1) continue;
      let a = Math.atan2(q[1] - p[1], q[0] - p[0]);
      if (a < 0) a += Math.PI;
      const k = Math.round((a * 180) / Math.PI) % 180;
      const bin = bins.get(k) || bins.set(k, { w: 0, c: 0, s: 0 }).get(k);
      bin.w += L;
      // Doubled angles average across the 0/180 seam.
      bin.c += L * Math.cos(2 * a);
      bin.s += L * Math.sin(2 * a);
    }
    let d = null;
    let best = 0;
    for (const [k, b] of bins) {
      const w = b.w + (bins.get((k + 1) % 180)?.w || 0) + (bins.get((k + 179) % 180)?.w || 0);
      if (w > best) {
        best = w;
        const a = Math.atan2(b.s, b.c) / 2;
        d = [Math.cos(a), Math.sin(a)];
      }
    }
    // A door with its leaf drawn open: the leaf (a line as long as the arc's radius, from the hinge) runs across the wall.
    // (A casement window's sash arc may sweep out of the wall at any angle: windows go by their glass.)
    for (const a of kind === 'door' ? arcs : []) {
      if (a.r < 300) continue;
      const leaf = lines.find((l) => {
        const L = Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1]);
        return Math.abs(L - a.r) < 0.12 * a.r && Math.min(Math.hypot(l.a[0] - a.c[0], l.a[1] - a.c[1]), Math.hypot(l.b[0] - a.c[0], l.b[1] - a.c[1])) < 80;
      });
      if (!leaf) continue;
      const L = Math.hypot(leaf.b[0] - leaf.a[0], leaf.b[1] - leaf.a[1]);
      d = [-(leaf.b[1] - leaf.a[1]) / L, (leaf.b[0] - leaf.a[0]) / L];
      break;
    }
    if (!d) continue;
    const n = [-d[1], d[0]];
    // Along the wall: the extent of the straight lines (arcs reach out from the hinge).
    const ts = (lines.length ? lines.flatMap((l) => [l.a, l.b]) : pts).map((p) => p[0] * d[0] + p[1] * d[1]);
    const ss = pts.map((p) => p[0] * n[0] + p[1] * n[1]);
    const t0 = Math.min(...ts);
    const t1 = Math.max(...ts);
    const s = (Math.min(...ss) + Math.max(...ss)) / 2;
    const at = [d[0] * (t0 + t1) / 2 + n[0] * s, d[1] * (t0 + t1) / 2 + n[1] * s];
    // A door's leaf arc: centred on the hinge, its middle on the side the door opens to.
    const swing = arcs
      .filter((a) => a.r > 300)
      .map((a) => {
        const m = (a.a0 + a.a1) / 2 + (a.a1 < a.a0 ? Math.PI : 0);
        const dir = [Math.cos(m), Math.sin(m)];
        return { hinge: a.c, dir, r: a.r };
      });
    // What the block draws, as segments (arcs by their chords), for finding the gap it fills.
    const segs = [...lines.map((l) => ({ a: l.a, b: l.b })), ...arcs.map((a) => ({ a: [a.c[0] + a.r * Math.cos(a.a0), a.c[1] + a.r * Math.sin(a.a0)], b: [a.c[0] + a.r * Math.cos(a.a1), a.c[1] + a.r * Math.sin(a.a1)] }))];
    // The wall block it sits in, as a wall (axis, length and thickness from its lines): a wall only as long as its
    // door leaves no piece beside it to be found from the drawing alone.
    let hostWall = null;
    if (nested && hostLines.length) {
      // Its faces: the block's lines along the wall; the thickness is how far apart they lie.
      const along = hostLines.filter((l) => {
        const L = Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1]);
        return L > 20 && Math.abs(((l.b[0] - l.a[0]) * n[0] + (l.b[1] - l.a[1]) * n[1]) / L) < 0.02;
      });
      const ht = hostLines.flatMap((l) => [l.a, l.b]).map((p) => p[0] * d[0] + p[1] * d[1]);
      // The faces beside the opening (a long wall block may turn corners and hold other faces far off).
      const T = (p) => p[0] * d[0] + p[1] * d[1];
      const beside = along.filter((l) => Math.min(T(l.a), T(l.b)) <= t1 + 300 && Math.max(T(l.a), T(l.b)) >= t0 - 300);
      const hs = beside.flatMap((l) => [l.a, l.b]).map((p) => p[0] * n[0] + p[1] * n[1]).filter((v) => Math.abs(v - s) < 1000);
      if (ht.length && hs.length) {
        const a0 = Math.min(...ht);
        const a1 = Math.max(...ht);
        const s0 = Math.min(...hs);
        const s1 = Math.max(...hs);
        const sm = (s0 + s1) / 2;
        if (s1 - s0 >= 50 && a1 - a0 >= 100) hostWall = { a: [d[0] * a0 + n[0] * sm, d[1] * a0 + n[1] * sm], b: [d[0] * a1 + n[0] * sm, d[1] * a1 + n[1] * sm], thickness: s1 - s0 };
      }
    }
    // A wall block its window fills end to end (a facet of a glazed polygonal front): the window is the wall.
    if (nested && !hostWall && lines.length) {
      const par = lines.filter((l) => {
        const L = Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1]);
        return L > 20 && Math.abs(((l.b[0] - l.a[0]) * n[0] + (l.b[1] - l.a[1]) * n[1]) / L) < 0.05;
      });
      const sl = (par.length ? par : lines).flatMap((l) => [l.a, l.b]).map((p) => p[0] * n[0] + p[1] * n[1]);
      const s0 = Math.min(...sl);
      const s1 = Math.max(...sl);
      const sm = (s0 + s1) / 2;
      if (t1 - t0 >= 300) hostWall = { a: [d[0] * t0 + n[0] * sm, d[1] * t0 + n[1] * sm], b: [d[0] * t1 + n[0] * sm, d[1] * t1 + n[1] * sm], thickness: Math.max(60, s1 - s0) };
    }
    // On the wall's axis, where the wall is known (a door's open leaf pulls the middle of its drawing to one side).
    if (hostWall) {
      const sm = (hostWall.a[0] * n[0] + hostWall.a[1] * n[1]);
      at[0] = d[0] * (t0 + t1) / 2 + n[0] * sm;
      at[1] = d[1] * (t0 + t1) / 2 + n[1] * sm;
    }
    out.push({ kind: kind === 'doorway' ? 'opening' : kind, doorway: kind === 'doorway', at, ext: [t0, t1], d, swing, segs, hostWall, name: x.name, base: x.name.replace(/_\d+$/, ''), host: host?.name });
  }
  return out;
}

/** Zone names from Archicad's zone blocks ("Camera 1_A.1_4"): Map number -> name. */
export function exportedZoneNames(flat) {
  const out = new Map();
  for (const x of flat.inserts || []) {
    if (x.parent >= 0) continue;
    const m = /^(.+)_([^_]+?)\s*_(\d+)$/.exec(x.name);
    if (!m) continue;
    const name = m[1].trim();
    const number = m[2].trim();
    if (!/\p{L}{2,}/u.test(name) || out.has(number)) continue;
    out.set(number, name);
  }
  return out;
}

/** The stair blocks of an element-by-element export: [{ ins (the block's insert), lines, arcs }]. */
export function exportedStairs(flat) {
  const ins = flat.inserts || [];
  const topOf = (k) => { while (k >= 0 && ins[k].parent >= 0) k = ins[k].parent; return k; };
  const out = [];
  for (const [i, x] of ins.entries()) {
    if (x.parent >= 0 || elementKind(x.name) !== 'stair') continue;
    out.push({ ins: i, lines: flat.lines.filter((l) => l.ins >= 0 && topOf(l.ins) === i), arcs: flat.arcs.filter((a) => a.ins >= 0 && topOf(a.ins) === i) });
  }
  return out;
}
