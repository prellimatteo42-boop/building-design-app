/**
 * Drawings Archicad exported element by element (its DWG translator can write each wall, door, window, opening and zone
 * as a block of its own): the blocks say what each thing is, where the drawing's geometry alone would leave it to guess.
 * A wall's block holds its cut fills and, nested in it, the blocks of the doors and windows it hosts (named after their
 * library parts, on layers named after them); a zone's block is named "Name_Number_n". Archicad names the blocks in the
 * language it runs in, so the words below cover the languages it ships in.
 */
const WORDS = {
  wall: ['wall', 'muro', 'mur', 'wand', 'pared', 'parede', 'стена', 'стіна', 'ściana', 'zeď', 'stena', 'muur', 'vägg', 'væg', 'seinä', 'τοίχος', 'duvar', '壁', '墙'],
  doorway: ['doorway', 'door opening', 'vano porta', 'dverní otvor', 'дверной проем', 'дверной проём', 'дверний проріз', 'türöffnung', 'baie de porte', 'hueco de puerta', 'vão de porta', 'otwór drzwiowy'],
  opening: ['opening', 'apertura', 'öffnung', 'ouverture', 'hueco', 'abertura', 'отверстие', 'отвір', 'otwór', 'otvor', 'opening'],
  door: ['door', 'porta', 'porte', 'tür', 'tuer', 'puerta', 'дверь', 'двері', 'двер', 'drzwi', 'dveře', 'ajtó', 'deur', 'dörr', 'dør', 'ovi', 'πόρτα', 'kapı', 'ドア', '门'],
  window: ['window', 'finestra', 'fenêtre', 'fenetre', 'fenster', 'ventana', 'janela', 'окно', 'вікно', 'okno', 'ablak', 'raam', 'fönster', 'vindue', 'ikkuna', 'παράθυρο', 'pencere', '窓', '窗'],
  stair: ['stair', 'scala', 'treppe', 'escalier', 'escalera', 'escada', 'лестница', 'сходи', 'schody', 'trappa'],
  railing: ['railing', 'ringhiera', 'parapetto', 'balaustra', 'geländer', 'gelaender', 'garde-corps', 'barandilla', 'guarda-corpo', 'corrimão', 'ограждение', 'огорожа', 'перила', 'balustrada', 'poręcz', 'zábradlí', 'räcke', 'rekkverk', 'gelænder'],
  lift: ['elevator', 'lift', 'ascensore', 'aufzug', 'ascenseur', 'ascensor', 'elevador', 'лифт', 'ліфт', 'winda', 'výtah', 'hiss', 'heis', 'elevaattori'],
  column: ['column', 'colonna', 'pilastro', 'stütze', 'stuetze', 'säule', 'poteau', 'columna', 'pilar', 'колонна', 'колона', 'kolumna', 'sloup', 'pylväs', 'pilier', 'zuil'],
};
const has = (text, kind) => {
  const t = String(text || '').toLowerCase();
  return WORDS[kind].some((w) => t.includes(w));
};
/** What an element block is from its name (and layer): wall, door, window, doorway, opening, stair, or null. */
export function elementKind(name, layer = '') {
  const n = String(name || '').replace(/_\d+$/, '');
  // A window before a door: a French window (portafinestra, Fenstertür) is a window.
  for (const k of ['doorway', 'window', 'door', 'railing', 'stair', 'lift', 'column', 'wall', 'opening']) if (has(n, k)) return k;
  for (const k of ['window', 'door']) if (has(layer, k)) return k;
  return null;
}

/** Whether a drawn item belongs to a wall element block (in an element-by-element export: a title block's frame does not). */
export function wallBlockTest(flat) {
  const ins = flat.inserts || [];
  const memo = new Map();
  const isWall = (k) => {
    if (k < 0) return false;
    if (memo.has(k)) return memo.get(k);
    let t = k;
    while (ins[t].parent >= 0) t = ins[t].parent;
    const r = elementKind(ins[t].name) === 'wall';
    memo.set(k, r);
    return r;
  };
  return (item) => isWall(item.ins ?? -1);
}

/** Whether a flattened drawing was written by Archicad element by element: several top-level wall blocks named "Wall_n". */
export function isElementExport(flat) {
  const ins = flat.inserts || [];
  return ins.filter((x) => x.parent < 0 && /_\d+$/.test(x.name) && elementKind(x.name) === 'wall').length >= 3;
}

/**
 * The doors, windows and openings of an element-by-element export: [{ kind, at, ext, d, swing, name }], at the middle of
 * what each block draws, ext its length along d (the direction of the wall it sits in, from that wall block's fills),
 * swing [{ hinge, dir }] from a door's leaf arc.
 */
export function exportedOpenings(flat) {
  const ins = flat.inserts || [];
  // The top-level ancestor of every insert, and each insert's own items.
  const top = ins.map((_, i) => { let k = i; while (ins[k].parent >= 0) k = ins[k].parent; return k; });
  const under = (item, i) => { let k = item.ins; while (k >= 0) { if (k === i) return true; k = ins[k].parent; } return false; };
  const out = [];
  for (const [i, x] of ins.entries()) {
    const host = ins[top[i]];
    const nested = x.parent >= 0;
    let kind = nested ? elementKind(x.name, x.layer) : null;
    // A top-level opening block (Archicad's Opening tool) is a hole in a wall.
    if (!nested && /_\d+$/.test(x.name) && elementKind(x.name) === 'opening') kind = 'opening';
    if (!kind || !['door', 'window', 'doorway', 'opening'].includes(kind)) continue;
    // Not a part nested in another opening (a door's own handle block).
    if (nested && ins[x.parent] && elementKind(ins[x.parent].name, ins[x.parent].layer) && ['door', 'window', 'doorway'].includes(elementKind(ins[x.parent].name, ins[x.parent].layer))) continue;
    const lines = flat.lines.filter((l) => under(l, i));
    const arcs = flat.arcs.filter((a) => under(a, i));
    const pts = [...lines.flatMap((l) => [l.a, l.b]), ...arcs.map((a) => a.c)];
    if (!pts.length) continue;
    // The wall's direction: the longest straight line of its wall block (fills or outline), else its own longest line.
    const hostLines = nested ? flat.lines.filter((l) => l.ins >= 0 && top[l.ins] === top[i] && !under(l, i)) : [];
    const fills = nested ? flat.fills.filter((f) => f.ins >= 0 && top[f.ins] === top[i] && !under(f, i)) : [];
    // The direction most of the drawing runs in (by length, wall block and opening together): glass, frames and faces
    // run along the wall, reveals and an open leaf across it, and a wall block only as long as its window has longer
    // reveals than faces.
    const edges = [...hostLines.map((l) => [l.a, l.b]), ...fills.flatMap((f) => f.poly.map((p, k) => [p, f.poly[(k + 1) % f.poly.length]])), ...lines.map((l) => [l.a, l.b])];
    const bins = new Map();
    for (const [p, q] of edges) {
      const L = Math.hypot(q[0] - p[0], q[1] - p[1]);
      if (L < 1) continue;
      let a = Math.atan2(q[1] - p[1], q[0] - p[0]);
      if (a < 0) a += Math.PI;
      const k = Math.round((a * 180) / Math.PI) % 180;
      const bin = bins.get(k) || bins.set(k, { w: 0, c: 0, s: 0 }).get(k);
      bin.w += L;
      // Doubled angles average across the 0/180 seam.
      bin.c += L * Math.cos(2 * a);
      bin.s += L * Math.sin(2 * a);
    }
    let d = null;
    let best = 0;
    for (const [k, b] of bins) {
      const w = b.w + (bins.get((k + 1) % 180)?.w || 0) + (bins.get((k + 179) % 180)?.w || 0);
      if (w > best) {
        best = w;
        const a = Math.atan2(b.s, b.c) / 2;
        d = [Math.cos(a), Math.sin(a)];
      }
    }
    // A door with its leaf drawn open: the leaf (a line as long as the arc's radius, from the hinge) runs across the wall.
    // (A casement window's sash arc may sweep out of the wall at any angle: windows go by their glass.)
    for (const a of kind === 'door' ? arcs : []) {
      if (a.r < 300) continue;
      const leaf = lines.find((l) => {
        const L = Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1]);
        return Math.abs(L - a.r) < 0.12 * a.r && Math.min(Math.hypot(l.a[0] - a.c[0], l.a[1] - a.c[1]), Math.hypot(l.b[0] - a.c[0], l.b[1] - a.c[1])) < 80;
      });
      if (!leaf) continue;
      const L = Math.hypot(leaf.b[0] - leaf.a[0], leaf.b[1] - leaf.a[1]);
      d = [-(leaf.b[1] - leaf.a[1]) / L, (leaf.b[0] - leaf.a[0]) / L];
      break;
    }
    if (!d) continue;
    const n = [-d[1], d[0]];
    // Along the wall: the extent of the straight lines (arcs reach out from the hinge).
    const ts = (lines.length ? lines.flatMap((l) => [l.a, l.b]) : pts).map((p) => p[0] * d[0] + p[1] * d[1]);
    const ss = pts.map((p) => p[0] * n[0] + p[1] * n[1]);
    const t0 = Math.min(...ts);
    const t1 = Math.max(...ts);
    const s = (Math.min(...ss) + Math.max(...ss)) / 2;
    const at = [d[0] * (t0 + t1) / 2 + n[0] * s, d[1] * (t0 + t1) / 2 + n[1] * s];
    // A door's leaf arc: centred on the hinge, its middle on the side the door opens to.
    const swing = arcs
      .filter((a) => a.r > 300)
      .map((a) => {
        const m = (a.a0 + a.a1) / 2 + (a.a1 < a.a0 ? Math.PI : 0);
        const dir = [Math.cos(m), Math.sin(m)];
        return { hinge: a.c, dir, r: a.r };
      });
    // What the block draws, as segments (arcs by their chords), for finding the gap it fills.
    const segs = [...lines.map((l) => ({ a: l.a, b: l.b })), ...arcs.map((a) => ({ a: [a.c[0] + a.r * Math.cos(a.a0), a.c[1] + a.r * Math.sin(a.a0)], b: [a.c[0] + a.r * Math.cos(a.a1), a.c[1] + a.r * Math.sin(a.a1)] }))];
    // The wall block it sits in, as a wall (axis, length and thickness from its lines): a wall only as long as its
    // door leaves no piece beside it to be found from the drawing alone.
    let hostWall = null;
    if (nested && hostLines.length) {
      // Its faces: the block's lines along the wall; the thickness is how far apart they lie.
      const along = hostLines.filter((l) => {
        const L = Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1]);
        return L > 20 && Math.abs(((l.b[0] - l.a[0]) * n[0] + (l.b[1] - l.a[1]) * n[1]) / L) < 0.02;
      });
      const ht = hostLines.flatMap((l) => [l.a, l.b]).map((p) => p[0] * d[0] + p[1] * d[1]);
      // The faces beside the opening (a long wall block may turn corners and hold other faces far off).
      const T = (p) => p[0] * d[0] + p[1] * d[1];
      const beside = along.filter((l) => Math.min(T(l.a), T(l.b)) <= t1 + 300 && Math.max(T(l.a), T(l.b)) >= t0 - 300);
      const hs = beside.flatMap((l) => [l.a, l.b]).map((p) => p[0] * n[0] + p[1] * n[1]).filter((v) => Math.abs(v - s) < 1000);
      if (ht.length && hs.length) {
        const a0 = Math.min(...ht);
        const a1 = Math.max(...ht);
        const s0 = Math.min(...hs);
        const s1 = Math.max(...hs);
        const sm = (s0 + s1) / 2;
        if (s1 - s0 >= 50 && a1 - a0 >= 100) hostWall = { a: [d[0] * a0 + n[0] * sm, d[1] * a0 + n[1] * sm], b: [d[0] * a1 + n[0] * sm, d[1] * a1 + n[1] * sm], thickness: s1 - s0 };
      }
    }
    // A wall block its window fills end to end (a facet of a glazed polygonal front): the window is the wall.
    if (nested && !hostWall && lines.length) {
      const par = lines.filter((l) => {
        const L = Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1]);
        return L > 20 && Math.abs(((l.b[0] - l.a[0]) * n[0] + (l.b[1] - l.a[1]) * n[1]) / L) < 0.05;
      });
      const sl = (par.length ? par : lines).flatMap((l) => [l.a, l.b]).map((p) => p[0] * n[0] + p[1] * n[1]);
      const s0 = Math.min(...sl);
      const s1 = Math.max(...sl);
      const sm = (s0 + s1) / 2;
      if (t1 - t0 >= 300) hostWall = { a: [d[0] * t0 + n[0] * sm, d[1] * t0 + n[1] * sm], b: [d[0] * t1 + n[0] * sm, d[1] * t1 + n[1] * sm], thickness: Math.max(60, s1 - s0) };
    }
    // On the wall's axis, where the wall is known (a door's open leaf pulls the middle of its drawing to one side).
    if (hostWall) {
      const sm = (hostWall.a[0] * n[0] + hostWall.a[1] * n[1]);
      at[0] = d[0] * (t0 + t1) / 2 + n[0] * sm;
      at[1] = d[1] * (t0 + t1) / 2 + n[1] * sm;
    }
    out.push({ kind: kind === 'doorway' ? 'opening' : kind, doorway: kind === 'doorway', at, ext: [t0, t1], d, swing, segs, hostWall, name: x.name, base: x.name.replace(/_\d+$/, ''), host: host?.name });
  }
  return out;
}

/** Zone names from Archicad's zone blocks ("Camera 1_A.1_4"): Map number -> name. */
export function exportedZoneNames(flat) {
  const out = new Map();
  for (const x of flat.inserts || []) {
    if (x.parent >= 0) continue;
    const m = /^(.+)_([^_]+?)\s*_(\d+)$/.exec(x.name);
    if (!m) continue;
    const name = m[1].trim();
    const number = m[2].trim();
    if (!/\p{L}{2,}/u.test(name) || out.has(number)) continue;
    out.set(number, name);
  }
  return out;
}

/** The top-level blocks of one kind in an element-by-element export: [{ ins (the block's insert), name, lines, arcs, fills }]. */
export function exportedBlocks(flat, kind) {
  const ins = flat.inserts || [];
  const topOf = (k) => { while (k >= 0 && ins[k].parent >= 0) k = ins[k].parent; return k; };
  const want = new Set();
  for (const [i, x] of ins.entries()) if (x.parent < 0 && elementKind(x.name) === kind) want.add(i);
  if (!want.size) return [];
  const by = new Map([...want].map((i) => [i, { ins: i, name: ins[i].name, lines: [], arcs: [], fills: [] }]));
  for (const k of ['lines', 'arcs', 'fills']) for (const x of flat[k] || []) if (x.ins >= 0) by.get(topOf(x.ins))?.[k].push(x);
  return [...by.values()];
}

/** The stair blocks of an element-by-element export: [{ ins (the block's insert), lines, arcs }]. */
export function exportedStairs(flat) {
  return exportedBlocks(flat, 'stair');
}

const sub2 = (a, b) => [a[0] - b[0], a[1] - b[1]];
const dot2 = (a, b) => a[0] * b[0] + a[1] * b[1];

/** The direction most of a set of segments run along (by length, in 1° bins over 180°), as a unit vector. */
function mainDirection(segs) {
  const bins = new Float64Array(180);
  for (const s of segs) {
    const L = Math.hypot(s.b[0] - s.a[0], s.b[1] - s.a[1]);
    if (L < 1) continue;
    const deg = ((Math.atan2(s.b[1] - s.a[1], s.b[0] - s.a[0]) * 180) / Math.PI + 360) % 180;
    bins[Math.round(deg) % 180] += L;
  }
  let best = 0;
  for (let i = 1; i < 180; i++) if (bins[i] + bins[(i + 1) % 180] + bins[(i + 179) % 180] > bins[best] + bins[(best + 1) % 180] + bins[(best + 179) % 180]) best = i;
  // The exact angle: the length-weighted mean of the segments within 2 degrees of that bin.
  let sx = 0;
  let sy = 0;
  for (const s of segs) {
    const L = Math.hypot(s.b[0] - s.a[0], s.b[1] - s.a[1]);
    if (L < 1) continue;
    let deg = ((Math.atan2(s.b[1] - s.a[1], s.b[0] - s.a[0]) * 180) / Math.PI + 360) % 180;
    if (deg - best > 90) deg -= 180;
    if (best - deg > 90) deg += 180;
    if (Math.abs(deg - best) > 2) continue;
    // Doubled angles average directions without the 180-degree ambiguity.
    sx += L * Math.cos((deg * Math.PI) / 90);
    sy += L * Math.sin((deg * Math.PI) / 90);
  }
  const r = sx || sy ? Math.atan2(sy, sx) / 2 : (best * Math.PI) / 180;
  return [Math.cos(r), Math.sin(r)];
}

/** The box a set of points fills along a direction: { at (centre), w (along d), d (across), d0 (the direction) }. */
function orientedBox(pts, dir) {
  const n = [-dir[1], dir[0]];
  let u0 = Infinity, u1 = -Infinity, v0 = Infinity, v1 = -Infinity;
  for (const p of pts) {
    const u = dot2(p, dir);
    const v = dot2(p, n);
    u0 = Math.min(u0, u); u1 = Math.max(u1, u); v0 = Math.min(v0, v); v1 = Math.max(v1, v);
  }
  const uc = (u0 + u1) / 2;
  const vc = (v0 + v1) / 2;
  return { at: [dir[0] * uc + n[0] * vc, dir[1] * uc + n[1] * vc], w: u1 - u0, d: v1 - v0, dir };
}

/**
 * The column blocks of an export: [{ ins, at, w, d, round, rotation }]. A circle drawn as many short lines (Archicad
 * writes round columns as polygons, with a hatch whose outline may be coarser) is round; else the box along the
 * block's main direction.
 */
export function exportedColumns(flat) {
  const out = [];
  for (const b of exportedBlocks(flat, 'column')) {
    const pts = [...b.lines.flatMap((l) => [l.a, l.b]), ...b.fills.flatMap((f) => f.poly || [])];
    for (const a of b.arcs) for (let k = 0; k <= 8; k++) { const t = a.a0 + ((a.a1 - a.a0) * k) / 8; pts.push([a.c[0] + a.r * Math.cos(t), a.c[1] + a.r * Math.sin(t)]); }
    if (pts.length < 3) continue;
    const cx = pts.reduce((s, p) => s + p[0], 0) / pts.length;
    const cy = pts.reduce((s, p) => s + p[1], 0) / pts.length;
    const linePts = [...b.lines.flatMap((l) => [l.a, l.b])];
    const radii = linePts.map((p) => Math.hypot(p[0] - cx, p[1] - cy));
    const r = radii.length ? radii.reduce((s, v) => s + v, 0) / radii.length : 0;
    const round = (b.arcs.length && !b.lines.length) || (b.lines.length >= 12 && r > 0 && radii.every((v) => Math.abs(v - r) < 0.04 * r));
    if (round) {
      const R = b.arcs.length && !b.lines.length ? b.arcs[0].r : r;
      out.push({ ins: b.ins, at: [cx, cy], w: 2 * R, d: 2 * R, round: true, rotation: 0 });
      continue;
    }
    const box = orientedBox(pts, mainDirection(b.lines.length ? b.lines : (b.fills[0]?.poly || []).map((p, i, a) => ({ a: p, b: a[(i + 1) % a.length] }))));
    out.push({ ins: b.ins, at: box.at, w: box.w, d: box.d, round: false, rotation: (Math.atan2(box.dir[1], box.dir[0]) * 180) / Math.PI });
  }
  return out;
}

/** The lift blocks of an export: [{ ins, name, at, w, d, rotation }] (the car's box along the block's main direction). */
export function exportedLifts(flat) {
  return exportedBlocks(flat, 'lift').filter((b) => b.lines.length).map((b) => {
    const box = orientedBox(b.lines.flatMap((l) => [l.a, l.b]), mainDirection(b.lines));
    return { ins: b.ins, name: b.name, at: box.at, w: box.w, d: box.d, rotation: (Math.atan2(box.dir[1], box.dir[0]) * 180) / Math.PI };
  });
}

/**
 * The railing blocks of an export: [{ ins, paths: [[x, y], ...][] }]. A railing is drawn as the two faces of its rail
 * (and short posts across them): each pair of parallel faces 20-200 mm apart gives the centre line over their overlap;
 * the centre lines are joined end to end into paths (corners where two meet). A railing drawn as single lines keeps them.
 */
export function exportedRailings(flat) {
  const out = [];
  for (const b of exportedBlocks(flat, 'railing')) {
    const segs = b.lines.map((l) => {
      const L = Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1]);
      return L < 1 ? null : { a: l.a, b: l.b, L, d: [(l.b[0] - l.a[0]) / L, (l.b[1] - l.a[1]) / L] };
    }).filter(Boolean);
    const long = segs.filter((s) => s.L >= 150);
    const centres = [];
    const used = new Set();
    for (let i = 0; i < long.length; i++) for (let j = i + 1; j < long.length; j++) {
      const p = long[i];
      const q = long[j];
      if (Math.abs(Math.abs(dot2(p.d, q.d)) - 1) > 0.002) continue;
      const n = [-p.d[1], p.d[0]];
      const off = dot2(sub2(q.a, p.a), n);
      if (Math.abs(off) < 20 || Math.abs(off) > 200) continue;
      const t = (x) => dot2(sub2(x, p.a), p.d);
      const lo = Math.max(0, Math.min(t(q.a), t(q.b)));
      const hi = Math.min(p.L, Math.max(t(q.a), t(q.b)));
      if (hi - lo < 150) continue;
      const P = (u) => [p.a[0] + p.d[0] * u + (n[0] * off) / 2, p.a[1] + p.d[1] * u + (n[1] * off) / 2];
      centres.push({ a: P(lo), b: P(hi), w: Math.abs(off) });
      used.add(i).add(j);
    }
    // Centre lines on one axis that touch or overlap become one.
    const merged = [];
    for (const c of centres.sort((x, y) => dot2(x.a, [1, 0.001]) - dot2(y.a, [1, 0.001]))) {
      const d = [(c.b[0] - c.a[0]), (c.b[1] - c.a[1])];
      const L = Math.hypot(d[0], d[1]);
      const u = [d[0] / L, d[1] / L];
      const m = merged.find((o) => Math.abs(Math.abs(dot2(o.u, u)) - 1) < 0.002 && Math.abs(dot2(sub2(c.a, o.a), [-o.u[1], o.u[0]])) < 25);
      if (m) {
        const ts = [c.a, c.b, m.a, m.b].map((p) => dot2(sub2(p, m.a), m.u));
        const t0 = Math.min(...ts);
        const t1 = Math.max(...ts);
        // A gap longer than a post's width along the axis is a real break.
        const cs = [dot2(sub2(c.a, m.a), m.u), dot2(sub2(c.b, m.a), m.u)].sort((x, y) => x - y);
        const ms = [0, Math.hypot(m.b[0] - m.a[0], m.b[1] - m.a[1])];
        if (cs[0] > ms[1] + 300 || cs[1] < ms[0] - 300) { merged.push({ a: c.a, b: c.b, u }); continue; }
        const base = m.a;
        m.a = [base[0] + m.u[0] * t0, base[1] + m.u[1] * t0];
        m.b = [base[0] + m.u[0] * t1, base[1] + m.u[1] * t1];
      } else merged.push({ a: c.a, b: c.b, u });
    }
    const pieces = merged.length ? merged : long.filter((s) => s.L >= 300).map((s) => ({ a: s.a, b: s.b, u: s.d }));
    // Join pieces end to end: an end within 250 mm of another's end makes a corner where their lines cross.
    const cross = (p, q) => {
      const den = p.u[0] * q.u[1] - p.u[1] * q.u[0];
      if (Math.abs(den) < 1e-6) return null;
      const t = ((q.a[0] - p.a[0]) * q.u[1] - (q.a[1] - p.a[1]) * q.u[0]) / den;
      return [p.a[0] + p.u[0] * t, p.a[1] + p.u[1] * t];
    };
    const left = [...pieces];
    const paths = [];
    while (left.length) {
      const first = left.shift();
      let path = [first.a, first.b];
      let ends = [first, first];
      for (let grow = true; grow;) {
        grow = false;
        for (const [k, q] of left.entries()) {
          for (const [atEnd, endP, endPiece] of [[true, path.at(-1), ends[1]], [false, path[0], ends[0]]]) {
            const near = Math.hypot(q.a[0] - endP[0], q.a[1] - endP[1]) < 250 ? 'a' : Math.hypot(q.b[0] - endP[0], q.b[1] - endP[1]) < 250 ? 'b' : null;
            if (!near) continue;
            const corner = cross(endPiece, q) || endP;
            const far = near === 'a' ? q.b : q.a;
            if (atEnd) { path[path.length - 1] = corner; path.push(far); ends[1] = q; } else { path[0] = corner; path.unshift(far); ends[0] = q; }
            left.splice(k, 1);
            grow = true;
            break;
          }
          if (grow) break;
        }
      }
      if (path.length >= 2 && path.reduce((s, p, i) => s + (i ? Math.hypot(p[0] - path[i - 1][0], p[1] - path[i - 1][1]) : 0), 0) >= 300) paths.push(path);
    }
    if (paths.length) out.push({ ins: b.ins, name: b.name, paths });
  }
  return out;
}
