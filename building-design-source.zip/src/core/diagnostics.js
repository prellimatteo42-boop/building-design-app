/**
 * Drawing Manager and Action Center (Archicad's, reimplemented):
 *   - drawingsList: every drawing placed on a layout (views in viewports and
 *     external drawings) with its source, layout, scale and status;
 *   - performance: what weighs on the project (elements, triangles, the
 *     heaviest bodies, embedded pictures);
 *   - libraryIssues: GDL parts that do not draw or use commands or materials
 *     the project lacks.
 */
import { MODEL_KINDS } from './scene.js';
import { testLibraryParts, missingAttributes } from './libtools.js';

/**
 * Drawings on layouts: [{ id, kind: 'view' | 'external', name, number, source, sourceKind, layoutId, layout, scale,
 * status: 'auto' | 'missing' | 'external', linked }].
 */
export function drawingsList(doc) {
  const out = [];
  for (const vp of doc.all('viewport')) {
    const sheet = doc.get(vp.viewId);
    const src = doc.get(vp.placedId);
    out.push({
      id: vp.id,
      kind: 'view',
      name: vp.title || src?.name || '(missing view)',
      number: vp.detailNumber ?? '',
      source: src?.name || '—',
      sourceKind: src?.kind || null,
      sourceId: src?.id || null,
      layoutId: sheet?.id || null,
      layout: sheet ? `${sheet.number ? `${sheet.number} ` : ''}${sheet.name || ''}`.trim() : '—',
      scale: src?.scale ? `1:${src.scale}` : '—',
      status: src ? 'auto' : 'missing',
    });
  }
  for (const im of doc.all('image')) {
    const sheet = doc.get(im.viewId);
    if (sheet?.kind !== 'sheet') continue;
    out.push({ id: im.id, kind: 'external', name: im.name || 'Picture', number: '', source: im.name || '', sourceKind: 'file', layoutId: sheet.id, layout: `${sheet.number ? `${sheet.number} ` : ''}${sheet.name || ''}`.trim(), scale: '—', status: 'external', linked: !!im.linked, extLink: im.extLink || null });
  }
  return out;
}

/** What weighs on the project: { elements, kinds: [[kind, n]], triangles, heaviest: [{ id, kind, triangles }], pictures (bytes) }. */
export function performance(doc, scene) {
  const counts = new Map();
  let elements = 0;
  for (const el of doc.items.values()) {
    if (el.kind.endsWith('Type') || el.kind === 'project') continue;
    elements++;
    counts.set(el.kind, (counts.get(el.kind) || 0) + 1);
  }
  let triangles = 0;
  const heavy = [];
  for (const k of MODEL_KINDS)
    for (const el of doc.all(k)) {
      let m = null;
      try {
        m = scene?.mesh(el);
      } catch {
        m = null;
      }
      const t = m?.pos ? m.pos.length / 9 : 0;
      triangles += t;
      if (t) heavy.push({ id: el.id, kind: el.kind, triangles: t });
    }
  heavy.sort((a, b) => b.triangles - a.triangles);
  let pictures = 0;
  for (const el of doc.items.values()) if (typeof el.src === 'string' && el.src.startsWith('data:')) pictures += Math.round((el.src.length * 3) / 4);
  return { elements, kinds: [...counts].sort((a, b) => b[1] - a[1]), triangles, heaviest: heavy.slice(0, 8), pictures };
}

/** GDL parts with problems: [{ id, name, problem }] (no geometry, unknown commands, missing materials). */
export function libraryIssues(doc) {
  const out = [];
  for (const r of testLibraryParts(doc)) {
    if (r.error) out.push({ id: r.id, name: r.name, problem: `does not run: ${r.error}` });
    else if (!r.ok) out.push({ id: r.id, name: r.name, problem: 'draws nothing' });
    else if (r.unknown.length) out.push({ id: r.id, name: r.name, problem: `commands not read: ${r.unknown.slice(0, 5).join(', ')}` });
  }
  for (const m of missingAttributes(doc)) out.push({ id: m.id, name: m.name, problem: `materials the project lacks: ${m.missing.slice(0, 5).join(', ')}` });
  return out;
}
