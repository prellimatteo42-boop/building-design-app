/**
 * Model recognition from a PDF floor plan exported by a CAD program (the
 * vectors read by io/pdfread.js, in paper millimetres): the drawing scale
 * from the title block, walls from the cut fills (the fill colour that
 * reads as walls is found by trying each), doors and windows in the gaps
 * between wall pieces (a door has its leaf or swing beside the gap), and
 * rooms at the zone stamps, named and numbered from the texts around them.
 */
import { wallsFromPolygons, wallsFromFaces } from './convert.js';
import { polygonBoolean } from './polybool.js';
import { stackedSizes, openingLabel, nearestSill, writtenDimensions, stampExtras, dashedWindows, leaderTarget, windowFrames } from './recognizelabels.js';
import { bridgeOpenings, closingWalls, cornerDoors, mainBuilding, nameRoomsFromLegend, isZoneCode } from './recognize.js';
import { FloorGrid } from './flood.js';
import { dist, dot, sub, norm, signedArea, pointInPolygon, offsetPolygon } from './geom.js';

const STANDARD_SCALES = [1, 2, 5, 10, 20, 25, 40, 50, 70, 75, 100, 105, 125, 150, 200, 250, 300, 400, 500, 1000];

/** The scales a sheet states (1:100, Scala 1:50, М 1:200), most often first. */
export function statedScales(texts) {
  const n = new Map();
  for (const t of texts) {
    // M=1:75, Scale 1:50, SCALA: 1:100, (1:200).
    const m = /(?:^|[\s:=(])1\s*:\s*(\d{1,4})(?=$|[\s),;])/.exec(` ${t.text} `);
    if (m && +m[1] >= 1) n.set(+m[1], (n.get(+m[1]) || 0) + 1);
  }
  return [...n].sort((a, b) => b[1] - a[1]).map(([s]) => s);
}

/** An area written in a zone stamp ("21,10 m²", "9.5 m2", "12,3 мкв"), in m², else null. */
export function stampArea(text) {
  const m = /^\s*(\d{1,4}(?:[.,]\d{1,3})?)\s*(m²|m2|м²|м2|мкв|mq)\s*$/i.exec(text);
  return m ? +m[1].replace(',', '.') : null;
}

const lum = (hex) => {
  const v = parseInt(hex.slice(1), 16);
  return (0.299 * (v >> 16) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255)) / 255;
};

/**
 * Pairs of triangles sharing an edge, as one four-sided shape: some programs
 * export every filled rectangle as two triangles, and a triangle alone looks
 * like a slanting wall. The other polygons pass through.
 */
export function mergeTriangles(polys, tol = 1e-3) {
  const closed = polys.map((q) => (q.length > 3 && Math.hypot(q[0][0] - q.at(-1)[0], q[0][1] - q.at(-1)[1]) <= tol ? q.slice(0, -1) : q));
  const out = closed.filter((q) => q.length !== 3);
  const tris = closed.filter((q) => q.length === 3);
  const key = (p) => `${Math.round(p[0] / tol)},${Math.round(p[1] / tol)}`;
  const edges = new Map();
  tris.forEach((t, i) => {
    for (let k = 0; k < 3; k++) {
      const [a, b] = [t[k], t[(k + 1) % 3]];
      const id = [key(a), key(b)].sort().join('|');
      edges.set(id, [...(edges.get(id) || []), { i, k, len: dist(a, b) }]);
    }
  });
  const used = new Set();
  // The diagonal of a rectangle is the longest edge of both its triangles.
  for (const list of [...edges.values()].filter((l) => l.length === 2).sort((x, y) => y[0].len - x[0].len)) {
    const [e, f] = list;
    if (used.has(e.i) || used.has(f.i)) continue;
    used.add(e.i).add(f.i);
    const t = tris[e.i];
    const u = tris[f.i];
    // Round the outside: t's far corner, then one end of the shared edge, u's far corner, the other end.
    out.push([t[(e.k + 2) % 3], t[e.k], u[(f.k + 2) % 3], t[(e.k + 1) % 3]]);
  }
  tris.forEach((t, i) => used.has(i) || out.push(t));
  return out;
}

/** Polygons joined where they touch: [{ boundary, holes }], with their corners on a 0.1 mm grid so shared edges meet exactly. */
export function unionPolygons(polys) {
  const snap = (q) => q.map((p) => [Math.round(p[0] * 10) / 10, Math.round(p[1] * 10) / 10]);
  const box = (sh) => {
    const pts = sh.boundary;
    const xs = pts.map((p) => p[0]);
    const ys = pts.map((p) => p[1]);
    return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
  };
  const touch = (a, b) => a[0] <= b[2] + 0.2 && b[0] <= a[2] + 0.2 && a[1] <= b[3] + 0.2 && b[1] <= a[3] + 0.2;
  let shapes = [];
  for (const q of polys) {
    let cur = { boundary: snap(q), holes: [] };
    if (Math.abs(signedArea(cur.boundary)) < 1) continue;
    const rest = [];
    for (const s of shapes) {
      if (!touch(box(cur), box(s))) {
        rest.push(s);
        continue;
      }
      const u = polygonBoolean(cur, s, 'union');
      if (u.length === 1) cur = u[0];
      else rest.push(s);
    }
    shapes = [...rest, cur];
  }
  return shapes;
}

/** Walls from fills drawn in fragments: the fragments joined, then opposite faces paired as usual. */
export function wallsFromFragments(polys, opts) {
  const parts = polys.map((poly) => {
    const xs = poly.map((q) => q[0]);
    const ys = poly.map((q) => q[1]);
    return { poly, x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) };
  });
  const solid = (p) => parts.some((s) => p[0] >= s.x0 - 1 && p[0] <= s.x1 + 1 && p[1] >= s.y0 - 1 && p[1] <= s.y1 + 1 && pointInPolygon(p, s.poly));
  const loops = unionPolygons(polys).flatMap((s) => [s.boundary, ...(s.holes || [])]);
  const pieces = wallsFromFaces(loops, solid, opts);
  // At a junction the fill is also "thick" the wrong way: a piece wider than it is long, beside a wall, is part of that wall.
  const axis = (w) => {
    const L = dist(w.a, w.b) || 1;
    return { d: [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L], L };
  };
  const onLine = (o, c, d) => Math.abs(cross2(sub(c, o.a), d)) <= 40;
  const out = [];
  for (const w of pieces) {
    const { d, L } = axis(w);
    const stub = w.thickness > L && pieces.some((o) => o !== w && o.thickness < w.thickness && dist(o.a, o.b) > o.thickness && Math.min(dist(o.a, w.a), dist(o.b, w.a), dist(o.a, w.b), dist(o.b, w.b)) < w.thickness);
    if (!stub) {
      out.push(w);
      continue;
    }
    // A jamb: another piece of the same thickness on its line, beyond a doorway.
    const c = [(w.a[0] + w.b[0]) / 2, (w.a[1] + w.b[1]) / 2];
    if (pieces.some((o) => o !== w && Math.abs(o.thickness - w.thickness) <= 30 && Math.abs(Math.abs(dot(axis(o).d, d)) - 1) < 0.01 && onLine(o, c, axis(o).d))) {
      out.push(w);
      continue;
    }
    // The end of a wall running the other way: this piece is as wide as that wall is thick, on its line.
    const n = [-d[1], d[0]];
    if (pieces.some((o) => o !== w && Math.abs(o.thickness - L) <= Math.max(30, 0.1 * L) && Math.abs(dot(axis(o).d, n)) > 0.99 && onLine(o, c, axis(o).d))) {
      const h = w.thickness / 2;
      out.push({ ...w, a: [c[0] - n[0] * h, c[1] - n[1] * h], b: [c[0] + n[0] * h, c[1] + n[1] * h], thickness: L });
    }
  }
  return out;
}

const cross2 = (a, b) => a[0] * b[1] - a[1] * b[0];

/**
 * The fill colours that read as cut walls: the ones whose shapes are mostly
 * explained as strips min..max thick (in paper mm here). [{ color, walls, share }]
 */
export function wallFillColors(paths, { min, max }) {
  const by = new Map();
  for (const p of paths) {
    if (!p.fill || p.pts.length < 3 || lum(p.fillColor) > 0.93) continue;
    if (!by.has(p.fillColor)) by.set(p.fillColor, []);
    by.get(p.fillColor).push(p.pts);
  }
  const out = [];
  for (const [color, raw] of by) {
    const polys = mergeTriangles(raw);
    const area = polys.reduce((s, q) => s + Math.abs(signedArea(q)), 0);
    if (!(area > 0)) continue;
    const walls = wallsFromPolygons(polys, { min, max });
    const explained = walls.reduce((s, w) => s + dist(w.a, w.b) * w.thickness, 0);
    out.push({ color, walls: walls.length, share: explained / area, polys, fragmented: raw.filter((q) => q.length === 3).length >= 8 });
  }
  return out.filter((c) => c.walls >= 3 && c.share > 0.45).sort((a, b) => b.share * b.walls - a.share * a.walls);
}

/**
 * Recognise a plan from PDF vectors at scale 1:scale (null: the stated one).
 * Returns { scale, stated, plan: { walls, doors, windows, rooms, newTypes }, wallColors, counts }
 * in model millimetres, or { error }.
 */
export function recognizePDF(vec, { scale = null } = {}) {
  const stated = statedScales(vec.texts);
  const k = +scale || stated[0];
  if (!k) return { error: 'The sheet does not state its scale (1:N); give it.', stated };
  const T = (p) => [p[0] * k, p[1] * k];
  // Walls 50 mm to 1.5 m thick, in paper millimetres at this scale.
  const colors = wallFillColors(vec.paths, { min: 50 / k, max: 1500 / k });
  if (!colors.length) return { error: 'No filled wall shapes were found on this page.', stated, scale: k };
  const shapes = colors.filter((c) => c.share > 0.6 || c === colors[0]).flatMap((c) => c.polys).map((q) => q.map(T));
  // Compact shapes 150 mm to 1.2 m across are columns, not walls.
  const columns = [];
  const wallPolys = [];
  const boxes = shapes.map((q) => {
    const xs = q.map((p) => p[0]);
    const ys = q.map((p) => p[1]);
    return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
  });
  // A pier at a wall's end touches the wall's fill; a column stands free.
  const touches = (i) => shapes.some((q, j) => j !== i && boxes[j][0] <= boxes[i][2] + 5 && boxes[j][2] >= boxes[i][0] - 5 && boxes[j][1] <= boxes[i][3] + 5 && boxes[j][3] >= boxes[i][1] - 5 && shapes[i].some((p) => q.some((r) => dist(p, r) < 5) || onEdge(p, q)));
  for (const [i, q] of shapes.entries()) {
    const xs = q.map((p) => p[0]);
    const ys = q.map((p) => p[1]);
    const w = Math.max(...xs) - Math.min(...xs);
    const h = Math.max(...ys) - Math.min(...ys);
    const area = Math.abs(signedArea(q));
    const r = Math.sqrt(area / Math.PI);
    const compact = area > 0.6 * w * h || (q.length > 12 && area > 0.7 * Math.PI * r * r);
    const tilted = Math.min(w, h) > 0.5 * Math.max(w, h);
    if (compact && tilted && Math.max(w, h) >= 150 && Math.max(w, h) <= 1200 && !touches(i)) {
      const c = [(Math.max(...xs) + Math.min(...xs)) / 2, (Math.max(...ys) + Math.min(...ys)) / 2];
      if (!columns.some((x) => dist(x.at, c) < 50))
        columns.push({
          at: c,
          w: Math.sqrt(area),
          d: Math.sqrt(area),
          round: q.length > 12,
        });
    } else wallPolys.push(q);
  }
  // Fills exported in fragments (triangle pairs, strips at each junction) are read as the shapes they make together.
  const fragmented = colors.some((c) => c.fragmented);
  const pieces = fragmented ? wallsFromFragments(wallPolys, { min: 50, max: 1500 }) : wallsFromPolygons(wallPolys, { min: 50, max: 1500 });
  // Symbols: drawn strokes, not hairline hatching.
  const strokes = vec.segments.map((s) => ({
    a: T([s[0], s[1]]),
    b: T([s[2], s[3]]),
  }));
  // Doors are 0.5 to 2.6 m wide (two leaves at most), windows up to 6 m.
  // Where the drawing's fills are clean the arcs can be asked for exactly.
  const looksLikeDoor = (gap) => (fragmented ? !!doorSwing(gap, strokes) || (hasHeadLines(gap, strokes) && !isWindow(gap, strokes)) : isDoor(gap, strokes));
  // A gap with fill standing in it (a niche, a thinner wall running through) holds no window, whatever lines cross it.
  const fillBoxes = wallPolys.map((q) => [Math.min(...q.map((p) => p[0])), Math.min(...q.map((p) => p[1])), Math.max(...q.map((p) => p[0])), Math.max(...q.map((p) => p[1]))]);
  const inFill = (p) => wallPolys.some((q, i) => p[0] >= fillBoxes[i][0] && p[0] <= fillBoxes[i][2] && p[1] >= fillBoxes[i][1] && p[1] <= fillBoxes[i][3] && pointInPolygon(p, q));
  const filled = (gap) => {
    let hit = 0;
    let all = 0;
    for (let i = -3; i <= 3; i++)
      for (let j = -3; j <= 3; j++) {
        all++;
        if (inFill([gap.at[0] + (gap.d[0] * i * gap.width * 0.4) / 3 + (gap.n[0] * j * gap.thickness * 0.4) / 3, gap.at[1] + (gap.d[1] * i * gap.width * 0.4) / 3 + (gap.n[1] * j * gap.thickness * 0.4) / 3])) hit++;
      }
    return hit / all;
  };
  // Fills of other colours (a renovation plan's yellow for what is taken down) standing in a gap.
  const wallColors = new Set(colors.map((c) => c.color));
  const otherFills = vec.paths.filter((p) => p.fill && p.pts.length >= 3 && !wallColors.has(p.fillColor) && lum(p.fillColor) < 0.93).map((p) => p.pts.map(T));
  const otherFilled = (gap) => otherFills.some((q) => pointInPolygon(gap.at, q));
  const classify = (gap) => {
    if (gap.width >= 500 && gap.width <= 2600 && looksLikeDoor(gap)) return 'door';
    // A leaf narrower than the gap where a fill of another colour stands in it (a renovation plan's stretch of wall to
    // take down, the new door drawn in it): a door, even though the fill's outline reads as a window's lines. Elsewhere
    // such arcs are as often a window's casements.
    if (!fragmented && gap.width >= 550 && gap.width <= 1300 && otherFilled(gap) && isDoor(gap, strokes, true)) return 'door';
    return gap.width >= 300 && isWindow(gap, strokes) && !(fragmented && filled(gap) > 0.15) ? 'window' : null;
  };
  const bridged = bridgeOpenings(pieces, { window: strokes }, { classify, maxGap: 6000 });
  // Doors between a wall's end and a wall across (beside a corner).
  const corner = cornerDoors(bridged.walls, (gap) => (gap.width >= 500 && looksLikeDoor(gap) ? 'door' : null));
  bridged.walls = corner.walls;
  // A corner opening spans from the wall's free end, which the fill may pass: it is as wide as the clear part of its axis.
  if (fragmented)
    for (const o of corner.openings) {
      const d = norm(o.d || [0, 0]);
      const clear = (s) => {
        let t = 0;
        while (t < o.width / 2 && !inFill([o.at[0] + d[0] * s * (t + 10), o.at[1] + d[1] * s * (t + 10)])) t += 10;
        return t;
      };
      const [lo, hi] = [clear(-1), clear(1)];
      if (lo + hi >= 300 && lo + hi < o.width - 15) {
        o.at = [o.at[0] + (d[0] * (hi - lo)) / 2, o.at[1] + (d[1] * (hi - lo)) / 2];
        o.width = lo + hi;
      }
    }
  bridged.openings.push(...corner.openings);
  // The building itself: legend tables and title blocks with shaded cells are left out.
  const main = mainBuilding(bridged.walls);
  const inBox = (p, m = 3000) => main.box && p[0] >= main.box.x0 - m && p[0] <= main.box.x1 + m && p[1] >= main.box.y0 - m && p[1] <= main.box.y1 + m;
  const plan = {
    walls: main.walls,
    doors: [],
    windows: [],
    rooms: [],
    newTypes: 'exact',
  };
  for (const o of bridged.openings)
    if (inBox(o.at, 500))
      (o.kind === 'door' ? plan.doors : plan.windows).push({
        at: o.at,
        width: Math.round(o.width),
      });
  for (let i = columns.length - 1; i >= 0; i--) if (!inBox(columns[i].at)) columns.splice(i, 1);
  // Rooms at the zone stamps: the area text, with a name and a number around it.
  const texts = vec.texts.map((t) => ({ ...t, at: T(t.at), size: t.size * k }));
  // What is written by the openings, and how doors swing.
  const usedLabels = new Set();
  const stacks = stackedSizes(texts);
  for (const o of plan.doors) {
    const host = nearestWall(o.at, plan.walls);
    if (host) {
      const d = norm(sub(host.b, host.a));
      const sw = doorSwing({ at: o.at, width: o.width, thickness: host.thickness, d, n: [-d[1], d[0]] }, strokes);
      // Drawn with its leaf the full width of the gap, the door's frame is not in the gap.
      if (sw) Object.assign(o, sw, fragmented ? { frameWidth: 0 } : {});
      else if (hasHeadLines({ at: o.at, width: o.width, thickness: host.thickness, d, n: [-d[1], d[0]] }, strokes)) Object.assign(o, { family: 'opening', frameWidth: 0 });
      else o.drop = fragmented;
    }
  }
  // From clean fragments the swing is reliable: a "door" with no arcs and no head is something else, such as a niche.
  plan.doors = plan.doors.filter((o) => !o.drop);
  for (const o of [...plan.doors, ...plan.windows]) {
    const l = openingLabel(o, stacks, usedLabels);
    if (l) Object.assign(o, l);
  }
  plan.windows.push(...dashedWindows(plan.walls, strokes, stacks, usedLabels, texts));
  for (const o of plan.windows) {
    const sill = nearestSill(o, texts, usedLabels);
    if (sill) o.sill = sill;
    const host = nearestWall(o.at, plan.walls);
    if (host && !o.aboveCut) {
      const d = norm(sub(host.b, host.a));
      Object.assign(o, windowFrames(o, d, [-d[1], d[0]], host.thickness / 2, strokes));
    }
  }
  const dims = writtenDimensions(texts.filter((t) => inBox(t.at, 3000)), strokes, usedLabels, plan.walls);
  const dimTexts = new Set(dims.map((x) => x.t));
  const stampTexts = new Set();
  // The building's extent: its walls and columns, with a margin for rooms closed by glazing.
  const ends = [...plan.walls.flatMap((w) => [w.a, w.b]), ...columns.map((c) => c.at)];
  const box = {
    x0: Math.min(...ends.map((p) => p[0])) - 1000,
    x1: Math.max(...ends.map((p) => p[0])) + 1000,
    y0: Math.min(...ends.map((p) => p[1])) - 1000,
    y1: Math.max(...ends.map((p) => p[1])) + 1000,
  };
  const hull = convexHull(ends);
  for (const t of texts) {
    const area = stampArea(t.text);
    // Totals in a legend or title block lie outside the building.
    if (area == null || area < 0.5 || t.at[0] < box.x0 || t.at[0] > box.x1 || t.at[1] < box.y0 || t.at[1] > box.y1) continue;
    // A stamp in a room lies within the building's outline, with walls or columns on two sides at least.
    if (!pointInPolygon(t.at, hull) || enclosedSides(t.at, plan.walls, columns) < 2) continue;
    // A stamp stacks its name and number above the area, about centred on it.
    // Its lines are centred on one another (text width taken as about half its size per letter).
    const mid = (u) => u.at[0] + u.text.length * u.size * 0.27;
    const near = texts.filter((u) => u !== t && !dimTexts.has(u) && !usedLabels.has(u) && stampArea(u.text) == null && Math.abs(mid(u) - mid(t)) < t.size * 1.5 && u.at[1] - t.at[1] > t.size * 0.3 && u.at[1] - t.at[1] < t.size * 5);
    const name = near.filter((u) => /\p{L}{2,}/u.test(u.text) && !/^\d/.test(u.text) && !isZoneCode(u.text)).sort((p, q) => dist(p.at, t.at) - dist(q.at, t.at))[0];
    const number = near.filter((u) => isZoneCode(u.text)).sort((p, q) => dist(p.at, t.at) - dist(q.at, t.at))[0];
    // Lines under the area: height and floor finish.
    const below = texts.filter((u) => u !== t && Math.abs(u.at[0] - t.at[0]) < 2.5 * t.size && t.at[1] - u.at[1] > 0 && t.at[1] - u.at[1] < 3.5 * t.size);
    const extras = stampExtras(below.map((u) => u.text));
    stampTexts.add(t);
    if (name) stampTexts.add(name);
    if (number) stampTexts.add(number);
    // A stamp set outside its room points into it with a line.
    const leader = leaderTarget(name || t, strokes) || leaderTarget(t, strokes);
    const stampAt = [t.at[0] + t.size, t.at[1] + t.size / 2];
    plan.rooms.push({
      at: stampAt,
      leaderAt: leader,
      name: name?.text || 'Room',
      number: number?.text,
      stampArea: area,
      ...(extras.height ? { height: extras.height } : {}),
      ...(extras.finish ? { floorFinish: extras.finish } : {}),
    });
  }
  // Names from the sheet's room schedule, for stamps that give a number only.
  nameRoomsFromLegend(plan.rooms, texts);
  // Each room as the floor flooded from its stamp, inside the wall fills and
  // the walls made, with every gap up to 3 m between pieces of one wall
  // closed (as a zone's outline runs across a doorway along the wall's
  // line); kept when it measures as the stamp says.
  if (plan.rooms.length) {
    const span = Math.max(box.x1 - box.x0, box.y1 - box.y0);
    const grid = new FloorGrid(box, Math.max(10, span / 3000));
    grid.paint(shapes);
    // The same floor with the doorways closed instead (where gaps along walls are not doors, closing them
    // all can cut a room across): a room that does not measure right in the first may in this one.
    const base = grid.clone();
    const doorsOnly = grid.clone();
    const closures = plan.doors.map((d) => doorClosure(d, plan.walls, grid.cell)).filter(Boolean);
    doorsOnly.paint(closures);
    const doorways = plan.doors.map((d) => doorClosure(d, plan.walls, grid.cell, true)).filter(Boolean);
    grid.paint(closingWalls(plan.walls).map((w) => wallRect(w)));
    const measures = (cells, r) => Math.abs((cells.length * grid.cell ** 2) / 1e6 - r.stampArea) <= 0.04 * r.stampArea + 0.1;
    // Zones are checked to 2%: a room taken within 4% only stays open to a better outline later.
    const exact = (cells, r) => Math.abs((cells.length * grid.cell ** 2) / 1e6 - r.stampArea) <= 0.02 * r.stampArea + 0.05;
    // A line from a stamp may lead into its room, or merely pass by: the floor's size says which.
    for (const r of plan.rooms) {
      if (!r.leaderAt) continue;
      const limit = (r.stampArea * 3e6) / grid.cell ** 2;
      const here = grid.flood(r.at, limit);
      const there = here && measures(here, r) ? null : grid.flood(r.leaderAt, limit);
      if (there && measures(there, r)) Object.assign(r, { tagAt: r.at, at: r.leaderAt });
      delete r.leaderAt;
    }
    const owner = new Int32Array(grid.w * grid.h).fill(-1);
    plan.rooms.forEach((r, i) => {
      const cells = grid.flood(r.at, (r.stampArea * 3e6) / grid.cell ** 2);
      if (!cells) return;
      // Two stamps in one flooded space: an open plan the walls do not split.
      const other = owner[cells[0]];
      if (other >= 0) {
        plan.rooms[other].outline = null;
        return;
      }
      for (const c of cells) owner[c] = i;
      if (measures(cells, r)) {
        r.outline = grid.outline(cells);
        r.loose = !exact(cells, r);
      }
    });
    const cellOf = (p) => Math.floor((p[1] - grid.y0) / grid.cell) * grid.w + Math.floor((p[0] - grid.x0) / grid.cell);
    const stamps = plan.rooms.map((r) => cellOf(r.at));
    const stampSet = new Set(stamps);
    // Each cell's room (index + 1), and each room's cells.
    const taken = new Int32Array(grid.w * grid.h);
    const own = new Map();
    const claim = (i, cells, g) => {
      for (const c of own.get(i) || []) if (taken[c] === i + 1) taken[c] = 0;
      for (const c of cells) taken[c] = i + 1;
      own.set(i, cells);
      plan.rooms[i].outline = g.outline(cells);
      plan.rooms[i].loose = !exact(cells, plan.rooms[i]);
    };
    plan.rooms.forEach((r, i) => {
      if (!r.outline) return;
      const cells = grid.flood(r.at, Infinity);
      if (cells) {
        for (const c of cells) taken[c] = i + 1;
        own.set(i, cells);
      }
    });
    // A flood room i may take: no other stamp in it, no other room's floor.
    const free = (i, cells) => {
      const set = new Set(cells);
      return !stamps.some((c, j) => j !== i && set.has(c)) && !cells.some((c) => taken[c] && taken[c] !== i + 1);
    };
    // Rooms still to find, or found only loosely (then only an exact outline replaces theirs).
    const tryGrid = (g) =>
      plan.rooms.forEach((r, i) => {
        if (r.outline && !r.loose) return;
        const cells = g.flood(r.at, (r.stampArea * 3e6) / grid.cell ** 2);
        if (!cells || !(r.outline ? exact(cells, r) : measures(cells, r)) || !free(i, cells)) return;
        claim(i, cells, g);
      });
    tryGrid(doorsOnly);
    // Rooms the wall fills leave open: to the outside, where the facade is
    // glazing drawn as lines, and to one another, where a zone's boundary
    // across an open plan is a dashed line. The outside is what a flood from
    // the edge reaches with every drawn line as a barrier; dashed lines that
    // run from wall to wall split the floor.
    if (plan.rooms.some((r) => !r.outline || r.loose)) {
      const lines = doorsOnly.clone();
      lines.paint(strokes.map((s) => wallRect({ a: s.a, b: s.b, thickness: grid.cell * 2 })));
      const outside = lines.outside();
      // The lines the outside stops at (the glazing) are solid too.
      for (let step = 0; step < 4; step++) {
        const add = [];
        for (let i = 0; i < outside.length; i++) {
          if (outside[i] || !lines.solid[i] || doorsOnly.solid[i]) continue;
          const x = i % lines.w;
          if ((x > 0 && outside[i - 1]) || (x < lines.w - 1 && outside[i + 1]) || outside[i - lines.w] || outside[i + lines.w]) add.push(i);
        }
        if (!add.length) break;
        for (const i of add) outside[i] = 1;
      }
      const open = doorsOnly.clone();
      open.paintMask(outside);
      const reach = Math.max(150, grid.cell * 3);
      // Mullions and piers along the glazing, drawn as small filled shapes (white or hatched), are solid.
      const out = Object.assign(open.clone(), { solid: outside });
      const piers = vec.paths
        .filter((p) => p.fill && p.pts.length >= 3)
        .map((p) => p.pts.map(T))
        .filter((q) => {
          const xs = q.map((p) => p[0]);
          const ys = q.map((p) => p[1]);
          const w = Math.max(...xs) - Math.min(...xs);
          const h = Math.max(...ys) - Math.min(...ys);
          return Math.min(w, h) >= 30 && Math.min(w, h) <= 500 && Math.max(w, h) <= 1200 && inBox(q[0], 0) && q.some((p) => out.solidNear(p, Math.max(60, grid.cell * 3)));
        });
      // Everything painted on the floor besides the walls and door closures, for the last pass.
      const rest = base.clone();
      rest.paintMask(outside);
      // Piers grown by their outline's pen and a little more, to meet the glazing line.
      const grown = piers.map((q) => {
        const g = offsetPolygon(signedArea(q) < 0 ? [...q].reverse() : q, Math.max(40, grid.cell * 2));
        return g?.length >= 3 ? g : q;
      });
      open.paint(grown);
      rest.paint(grown);
      // A zone ends at the facade's inner line, across the inner faces of the
      // mullions: the strip between two neighbouring piers (up to 3.5 m apart,
      // the glazing between them) is outside the room too.
      const linedOpen = open.clone();
      const centre = (q) => q.reduce((m, p) => [m[0] + p[0] / q.length, m[1] + p[1] / q.length], [0, 0]);
      const cs = piers.map(centre);
      const depth = piers.map((q) => Math.max(...q.map((p) => dist(p, cs[piers.indexOf(q)]))));
      for (let i = 0; i < piers.length; i++) {
        const near = cs
          .map((c, j) => [j, dist(c, cs[i])])
          .filter(([j, d]) => j !== i && d < 3500)
          .sort((p, q) => p[1] - q[1])
          .slice(0, 2);
        for (const [j] of near) {
          const mid = [(cs[i][0] + cs[j][0]) / 2, (cs[i][1] + cs[j][1]) / 2];
          if (!out.solidNear(mid, Math.max(depth[i], depth[j]) + 60)) continue;
          linedOpen.paint([convexHull([...piers[i], ...piers[j]])]);
          rest.paint([convexHull([...piers[i], ...piers[j]])]);
        }
      }
      // A strip (a door closure, a dashed boundary) with stamped floor, or a room found, on both sides.
      const stampedBothSides = (g, strip) => {
        const trial = g.clone();
        trial.paint([strip]);
        const m = strip.reduce((a, p) => [a[0] + p[0] / strip.length, a[1] + p[1] / strip.length], [0, 0]);
        const e = sub(strip[3], strip[0]);
        const L = Math.hypot(e[0], e[1]) || 1;
        const n = [(e[0] / L) * (L / 2 + grid.cell * 4), (e[1] / L) * (L / 2 + grid.cell * 4)];
        const stamped = (p) => {
          const cells = trial.flood(p, 400e6 / grid.cell ** 2);
          return !cells || cells.some((c) => stampSet.has(c));
        };
        return stamped([m[0] + n[0], m[1] + n[1]]) && stamped([m[0] - n[0], m[1] - n[1]]);
      };
      let dashes = dashedLines(vec, k).filter((d) => inBox(d.a, 0) || inBox(d.b, 0));
      // A boundary may end on another: take them in rounds.
      for (let round = 0; round < 3; round++) {
        const ok = dashes.filter((d) => open.solidNear(d.a, reach) && open.solidNear(d.b, reach));
        if (!ok.length) break;
        const strips = [];
        for (const d of ok) {
          const L = dist(d.a, d.b) || 1;
          const u = [((d.b[0] - d.a[0]) / L) * reach, ((d.b[1] - d.a[1]) / L) * reach];
          const strip = wallRect({ a: [d.a[0] - u[0], d.a[1] - u[1]], b: [d.b[0] + u[0], d.b[1] + u[1]], thickness: grid.cell * 2 });
          // A zone boundary has a zone on either side: a dashed line that cuts off floor with no stamp is
          // something else (a beam, a hidden edge, a threshold).
          if (!stampedBothSides(open, strip)) continue;
          open.paint([strip]);
          strips.push(strip);
        }
        linedOpen.paint(strips);
        rest.paint(strips);
        dashes = dashes.filter((d) => !ok.includes(d));
      }
      // Debugging aid: the grids, when a caller asks for them.
      if (globalThis.__pdfDebug) Object.assign(globalThis.__pdfDebug, { open, linedOpen, grid, doorsOnly });
      tryGrid(linedOpen);
      tryGrid(open);
      // The floor that is left: the rooms found so far solid, doorways open (a
      // doorway closed across a corridor would cut it), for a corridor or hall
      // that is whatever the rooms about it leave.
      const left = () => {
        const g = rest.clone();
        for (let c = 0; c < taken.length; c++) if (taken[c]) g.solid[c] = 1;
        return g;
      };
      const leftPass = () => {
        if (!plan.rooms.some((r) => !r.outline)) return;
        const g = left();
        // Doorways closed again through the wall's whole thickness (a zone stops at the wall's face), but
        // not across a corridor (stampless floor on one side).
        g.paint(doorways.filter((q) => stampedBothSides(g, q)));
        if (globalThis.__pdfDebug) globalThis.__pdfDebug.left = g;
        plan.rooms.forEach((r, i) => {
          if (r.outline) return;
          const cells = g.flood(r.at, (r.stampArea * 3e6) / grid.cell ** 2);
          if (cells && exact(cells, r) && free(i, cells)) claim(i, cells, g);
        });
        return g;
      };
      leftPass();
      // Open plans: a zone's boundary across the floor runs where the line of
      // a wall that stops there would carry on (its faces or its axis, or
      // square from its end). For a room still unmeasured, try each such line
      // from the wall ends about its floor, and keep the cut that makes it
      // measure as its stamp says (to 2%, as zones are checked).
      const cuts = (g) => {
        for (let round = 0; round < 4; round++) {
          let progress = false;
          plan.rooms.forEach((r, i) => {
            if (r.outline && !r.loose) return;
            const region = g.flood(r.at, (r.stampArea * 20e6) / grid.cell ** 2);
            if (!region) return;
            const inRegion = new Uint8Array(g.w * g.h);
            for (const c of region) inRegion[c] = 1;
            const fits = () => {
              const cells = g.flood(r.at, (r.stampArea * 1.1e6) / grid.cell ** 2);
              return cells && exact(cells, r) && free(i, cells) ? cells : null;
            };
            let best = null;
            const err = (cells) => Math.abs((cells.length * grid.cell ** 2) / 1e6 - r.stampArea);
            for (const ray of wallLines(plan.walls, g, inRegion)) {
              for (const c of ray) g.solid[c] = 1;
              const cells = fits();
              for (const c of ray) g.solid[c] = 0;
              if (cells && (!best || err(cells) < best.e)) best = { ray, e: err(cells) };
            }
            if (!best) return;
            for (const c of best.ray) g.solid[c] = 1;
            claim(i, fits(), g);
            progress = true;
          });
          if (!progress) break;
        }
      };
      cuts(linedOpen);
      const g2 = leftPass();
      if (g2) cuts(g2);
    }
  }
  for (const r of plan.rooms) delete r.loose;
  // Everything else written on the plan stays as text; written dimensions become dimensions.
  const labels = texts.filter((t) => inBox(t.at, 3000) && !stampTexts.has(t) && !dimTexts.has(t)).map((t) => ({ at: t.at, text: t.text, size: t.size / k, angle: t.angle || 0 }));
  const dimensions = dims.map(({ a, b, text, value }) => ({ a, b, text, value }));
  return {
    labels,
    dimensions,
    scale: k,
    stated,
    plan,
    columns,
    wallColors: colors.map((c) => c.color),
    counts: {
      walls: plan.walls.length,
      doors: plan.doors.length,
      windows: plan.windows.length,
      rooms: plan.rooms.length,
      columns: columns.length,
    },
  };
}

/**
 * Dashed lines (mm, at the drawing's scale k): strokes drawn with a dash
 * pattern, and runs of three or more short collinear strokes evenly spaced
 * (a CAD program that writes each dash as its own stroke).
 */
export function dashedLines(vec, k) {
  const out = [];
  const T = (p) => [p[0] * k, p[1] * k];
  for (const p of vec.paths || []) {
    if (!p.dash || !p.stroke || p.fill) continue;
    for (let i = 1; i < p.pts.length; i++) out.push({ a: T(p.pts[i - 1]), b: T(p.pts[i]) });
  }
  // Short strokes (0.2 to 6 paper mm) by direction, then by offset across it.
  const byDir = new Map();
  for (const s of vec.segments) {
    const dx = s[2] - s[0];
    const dy = s[3] - s[1];
    const L = Math.hypot(dx, dy);
    if (L < 0.2 || L > 6) continue;
    let ang = Math.atan2(dy, dx);
    if (ang < 0) ang += Math.PI;
    if (ang >= Math.PI - 1e-9) ang = 0;
    const key = Math.round((ang * 180) / Math.PI) % 180;
    const u = [Math.cos(ang), Math.sin(ang)];
    const t0 = s[0] * u[0] + s[1] * u[1];
    const t1 = s[2] * u[0] + s[3] * u[1];
    const off = -s[0] * u[1] + s[1] * u[0];
    if (!byDir.has(key)) byDir.set(key, []);
    byDir.get(key).push({ u, off, lo: Math.min(t0, t1), hi: Math.max(t0, t1), len: L });
  }
  for (const list of byDir.values()) {
    list.sort((p, q) => p.off - q.off);
    for (let i = 0; i < list.length;) {
      let j = i + 1;
      while (j < list.length && list[j].off - list[j - 1].off < 0.15) j++;
      const line = list.slice(i, j).sort((p, q) => p.lo - q.lo);
      i = j;
      let run = [line[0]];
      const flush = () => {
        if (run.length >= 3) {
          const { u, off } = run[0];
          const n = [-u[1], u[0]];
          const at = (t) => T([u[0] * t + n[0] * off, u[1] * t + n[1] * off]);
          out.push({ a: at(run[0].lo), b: at(run.at(-1).hi) });
        }
      };
      for (const d of line.slice(1)) {
        const prev = run.at(-1);
        const gap = d.lo - prev.hi;
        // Even dashes with gaps no longer than two dashes.
        if (gap > -0.05 && gap < Math.max(2 * prev.len, 0.6) && Math.abs(d.len - prev.len) < 0.5 * Math.max(d.len, prev.len)) run.push(d);
        else {
          flush();
          run = [d];
        }
      }
      flush();
    }
  }
  return out;
}

/**
 * The cells of each line a zone boundary could follow from the walls that
 * stop on a region of free floor (inRegion, a cell mask of grid g): from a
 * wall's end on along its faces and axis, and square from its end both ways,
 * each across free floor only until it meets something solid (8 m at most).
 */
function wallLines(walls, g, inRegion) {
  const { cell, w, h, x0, y0, solid } = g;
  const idx = (p) => {
    const c = Math.floor((p[0] - x0) / cell);
    const r = Math.floor((p[1] - y0) / cell);
    return c < 0 || r < 0 || c >= w || r >= h ? -1 : r * w + c;
  };
  const near = (p, rad) => {
    const n = Math.ceil(rad / cell);
    const c = Math.floor((p[0] - x0) / cell);
    const r = Math.floor((p[1] - y0) / cell);
    for (let y = Math.max(0, r - n); y <= Math.min(h - 1, r + n); y++) for (let x = Math.max(0, c - n); x <= Math.min(w - 1, c + n); x++) if (inRegion[y * w + x]) return true;
    return false;
  };
  // Walk from p along u: past the solid it starts in (1 m at most), then over free cells to the next solid.
  const ray = (p, u) => {
    const step = cell / 2;
    let t = 0;
    let i = idx(p);
    while (i >= 0 && solid[i] && t < 1000) {
      t += step;
      i = idx([p[0] + u[0] * t, p[1] + u[1] * t]);
    }
    if (i < 0 || solid[i]) return null;
    const t0 = t;
    const seen = new Set();
    while (true) {
      const q = [p[0] + u[0] * t, p[1] + u[1] * t];
      i = idx(q);
      if (i < 0) return null;
      if (solid[i]) break;
      if (t - t0 > 8000) return null;
      // Two cells wide, so no flood slips through diagonally.
      for (const j of [i, idx([q[0] + cell * 0.7, q[1]]), idx([q[0], q[1] + cell * 0.7])]) if (j >= 0 && !solid[j] && !seen.has(j)) seen.add(j);
      t += step;
    }
    return seen.size >= 2 ? [...seen] : null;
  };
  const out = [];
  const keys = new Set();
  for (const wl of walls) {
    const L = dist(wl.a, wl.b);
    if (L < 1) continue;
    for (const [e, o] of [
      [wl.b, wl.a],
      [wl.a, wl.b],
    ]) {
      if (!near(e, wl.thickness / 2 + cell * 4)) continue;
      const u = [(e[0] - o[0]) / L, (e[1] - o[1]) / L];
      const n = [-u[1], u[0]];
      const half = wl.thickness / 2;
      const starts = [];
      for (const off of [-half + cell, 0, half - cell]) starts.push([[e[0] + n[0] * off, e[1] + n[1] * off], u]);
      for (const sgn of [-1, 1]) {
        const at = [e[0] - u[0] * cell * 2 + n[0] * sgn * (half - cell), e[1] - u[1] * cell * 2 + n[1] * sgn * (half - cell)];
        starts.push([at, [n[0] * sgn, n[1] * sgn]]);
      }
      for (const [p, d] of starts) {
        const r = ray(p, d);
        if (!r) continue;
        const key = r.length + ':' + r[0] + ':' + r.at(-1);
        if (keys.has(key)) continue;
        keys.add(key);
        out.push(r);
      }
    }
  }
  return out;
}

/** A thin strip across a doorway: the door's width along the wall nearest its middle (within 600 mm); full, the wall's whole thickness. */
function doorClosure(door, walls, cell, full = false) {
  let best = null;
  let th = 0;
  let bd = 600;
  for (const w of walls) {
    const L = dist(w.a, w.b);
    if (L < 1) continue;
    const d = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
    const t = (door.at[0] - w.a[0]) * d[0] + (door.at[1] - w.a[1]) * d[1];
    const off = Math.abs((door.at[0] - w.a[0]) * -d[1] + (door.at[1] - w.a[1]) * d[0]);
    if (off < bd && Math.max(0, -t, t - L) < 1.5 * door.width) {
      bd = off;
      best = d;
      th = w.thickness;
    }
  }
  if (!best) return null;
  const h = door.width / 2;
  return wallRect({
    a: [door.at[0] - best[0] * h, door.at[1] - best[1] * h],
    b: [door.at[0] + best[0] * h, door.at[1] + best[1] * h],
    thickness: full ? Math.max(th, cell * 1.5) : cell * 1.5,
  });
}

/** A wall's footprint rectangle from its centre line and thickness. */
function wallRect(w) {
  const L = dist(w.a, w.b) || 1;
  const n = [(-(w.b[1] - w.a[1]) / L) * (w.thickness / 2), ((w.b[0] - w.a[0]) / L) * (w.thickness / 2)];
  return [[w.a[0] + n[0], w.a[1] + n[1]], [w.b[0] + n[0], w.b[1] + n[1]], [w.b[0] - n[0], w.b[1] - n[1]], [w.a[0] - n[0], w.a[1] - n[1]]];
}

/** The convex hull of points (counter-clockwise). */
function convexHull(pts) {
  const p = [...pts].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  if (p.length < 3) return p;
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lower = [];
  for (const q of p) {
    while (lower.length >= 2 && cross(lower.at(-2), lower.at(-1), q) <= 0) lower.pop();
    lower.push(q);
  }
  const upper = [];
  for (const q of p.reverse()) {
    while (upper.length >= 2 && cross(upper.at(-2), upper.at(-1), q) <= 0) upper.pop();
    upper.push(q);
  }
  return [...lower.slice(0, -1), ...upper.slice(0, -1)];
}

/** On how many of the four sides (left, right, below, above) a wall or column lies within 20 m of p. */
function enclosedSides(p, walls, columns) {
  const reach = 20000;
  let n = 0;
  for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    const q = [p[0] + dx * reach, p[1] + dy * reach];
    const hit = walls.some((w) => crosses(p, q, w.a, w.b)) || columns.some((c) => Math.abs(dx ? c.at[1] - p[1] : c.at[0] - p[0]) < c.w && (dx ? (c.at[0] - p[0]) * dx : (c.at[1] - p[1]) * dy) > 0);
    if (hit) n++;
  }
  return n;
}

function crosses(p, q, a, b) {
  const o = (u, v, w) => Math.sign((v[0] - u[0]) * (w[1] - u[1]) - (v[1] - u[1]) * (w[0] - u[0]));
  return o(p, q, a) !== o(p, q, b) && o(a, b, p) !== o(a, b, q);
}

function onEdge(p, q) {
  for (let i = 0; i < q.length; i++) {
    const a = q[i];
    const b = q[(i + 1) % q.length];
    const L = dist(a, b);
    if (L < 1) continue;
    const t = dot(sub(p, a), sub(b, a)) / (L * L);
    if (t > 0 && t < 1 && Math.abs((b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])) / L < 5) return true;
  }
  return false;
}

/**
 * A door has its swing beside the opening: an arc about a hinge at a
 * corner of the opening, as wide as the opening (one leaf) or half of it
 * (two leaves), drawn as many short strokes, or a leaf from a hinge as
 * long as that radius.
 */
function isDoor(o, strokes, narrow = false) {
  const half = o.thickness / 2;
  const w = o.width;
  const hinges = [];
  for (const sa of [-1, 1]) for (const sn of [-1, 1]) hinges.push([o.at[0] + o.d[0] * sa * w / 2 + o.n[0] * sn * half, o.at[1] + o.d[1] * sa * w / 2 + o.n[1] * sn * half]);
  const near = strokes.filter((s) => {
    const m = [(s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2];
    return Math.abs(dot(sub(m, o.at), o.n)) < half + w * 1.1 && Math.abs(dot(sub(m, o.at), o.d)) < w;
  });
  // A leaf as wide as the gap or two half leaves; with narrow, one a little narrower than the gap (a frame round it).
  for (const R of narrow ? [0.92 * w, 0.85 * w] : [w, w / 2]) {
    if (R < 350 || R > 1300) continue;
    for (const h of hinges) {
      // The swing lies outside the wall and sweeps a real angle.
      const angles = [];
      let leaf = 0;
      for (const s of near) {
        const ra = dist(s.a, h);
        const rb = dist(s.b, h);
        const len = dist(s.a, s.b);
        const m = [(s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2];
        const outside = Math.abs(dot(sub(m, o.at), o.n)) > half + 0.1 * R;
        if (outside && Math.abs(ra - R) < 0.06 * R && Math.abs(rb - R) < 0.06 * R && len < 0.5 * R) angles.push(Math.atan2(dot(sub(m, h), o.n), dot(sub(m, h), o.d)));
        if (outside && Math.min(ra, rb) < 0.08 * R && Math.abs(Math.max(ra, rb) - R) < 0.1 * R && Math.abs(len - R) < 0.12 * R) leaf++;
      }
      const sweep = angles.length ? Math.max(...angles) - Math.min(...angles) : 0;
      if ((angles.length >= 4 && sweep > 0.6) || (leaf > 0 && angles.length >= 2)) return true;
    }
  }
  return false;
}

/** The wall nearest a point. */
function nearestWall(p, walls) {
  let best = null;
  for (const w of walls) {
    const L = dist(w.a, w.b) || 1;
    const d = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
    const t = Math.max(0, Math.min(L, dot(sub(p, w.a), d)));
    const q = [w.a[0] + d[0] * t, w.a[1] + d[1] * t];
    const e = dist(p, q);
    if (!best || e < best.e) best = { e, w };
  }
  return best?.w || null;
}

/** How a door swings, from its arcs: { swing: [{ hinge, dir }], family: 'single' | 'double' }, or null. */
export function doorSwing(o, strokes) {
  const half = o.thickness / 2;
  const w = o.width;
  const near = strokes.filter((s) => {
    const m = [(s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2];
    return Math.abs(dot(sub(m, o.at), o.n)) < half + w * 1.1 && Math.abs(dot(sub(m, o.at), o.d)) < w * 1.1;
  });
  // Pieces of a circle of radius R round the hinge, on the swing's side, that run on from one another through at least 60 degrees.
  const fits = (h, R, sn) => {
    if (R < 300 || R > 1400) return 0;
    const side = [o.n[0] * sn, o.n[1] * sn];
    const angle = (p) => Math.atan2(dot(sub(p, h), o.d), dot(sub(p, h), side));
    const spans = [];
    for (const s of near) {
      const m = [(s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2];
      if (dot(sub(m, o.at), o.n) * sn <= half + 0.02 * R) continue;
      if (Math.abs(dist(s.a, h) - R) < 0.05 * R && Math.abs(dist(s.b, h) - R) < 0.05 * R && dist(s.a, s.b) < 0.6 * R) spans.push([angle(s.a), angle(s.b)].sort((p, q) => p - q));
    }
    spans.sort((p, q) => p[0] - q[0]);
    let run = null;
    let sweep = 0;
    let pieces = 0;
    let count = 0;
    for (const sp of spans) {
      if (run && sp[0] <= run[1] + 0.08) {
        run[1] = Math.max(run[1], sp[1]);
        count++;
      } else {
        run = [...sp];
        count = 1;
      }
      if (run[1] - run[0] > sweep) {
        sweep = run[1] - run[0];
        pieces = count;
      }
    }
    return sweep >= Math.PI / 3 ? pieces : 0;
  };
  const corner = (sa, sn) => [o.at[0] + o.d[0] * sa * w / 2 + o.n[0] * sn * half, o.at[1] + o.d[1] * sa * w / 2 + o.n[1] * sn * half];
  let best = null;
  for (const sn of [-1, 1]) {
    // Two leaves from the two jambs on one side, each half the opening.
    const both = Math.min(fits(corner(-1, sn), w / 2, sn), fits(corner(1, sn), w / 2, sn));
    if (both >= 2 && (!best || both > best.score)) best = { score: both + 0.5, swing: [-1, 1].map((sa) => ({ hinge: corner(sa, sn), dir: [o.n[0] * sn, o.n[1] * sn] })), family: 'double' };
    for (const sa of [-1, 1]) {
      const n = fits(corner(sa, sn), w, sn);
      if (n >= 3 && (!best || n > best.score)) best = { score: n, swing: [{ hinge: corner(sa, sn), dir: [o.n[0] * sn, o.n[1] * sn] }], family: 'single' };
    }
  }
  return best && { swing: best.swing, family: best.family };
}

/** A doorway with no leaf: short dashes along both faces of the wall across the gap (the head above the cut). */
function hasHeadLines(o, strokes) {
  const half = o.thickness / 2;
  const cover = [0, 0];
  for (const s of strokes) {
    const L = dist(s.a, s.b);
    if (L > 300 || L < 40 || Math.abs(dot(sub(s.b, s.a), o.d)) / L < 0.99) continue;
    const m = [(s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2];
    if (Math.abs(dot(sub(m, o.at), o.d)) > o.width / 2) continue;
    const e = dot(sub(m, o.at), o.n);
    if (Math.abs(Math.abs(e) - half) > 15) continue;
    cover[e > 0 ? 0 : 1] += L;
  }
  return Math.min(...cover) >= 0.3 * o.width;
}

/** A window has glass and frame lines along the wall inside its thickness, across most of the gap. */
function isWindow(o, strokes) {
  const half = o.thickness / 2;
  const spans = [];
  for (const s of strokes) {
    const len = dist(s.a, s.b);
    if (len < o.width * 0.2) continue;
    const along = Math.abs(dot(sub(s.b, s.a), o.d)) / len;
    if (along < 0.98) continue;
    if (Math.abs(dot(sub(s.a, o.at), o.n)) > half + 10 || Math.abs(dot(sub(s.b, s.a), o.n)) > 5) continue;
    const t0 = dot(sub(s.a, o.at), o.d);
    const t1 = dot(sub(s.b, o.at), o.d);
    const lo = Math.max(-o.width / 2, Math.min(t0, t1));
    const hi = Math.min(o.width / 2, Math.max(t0, t1));
    if (hi > lo) spans.push([lo, hi]);
  }
  // Glass and frame lines (two at least) along most of the opening; a long
  // glazed band may be several windows side by side.
  if (spans.length < 2) return false;
  spans.sort((p, q) => p[0] - q[0]);
  let covered = 0;
  let end = -Infinity;
  for (const [lo, hi] of spans) {
    if (hi <= end) continue;
    covered += hi - Math.max(lo, end);
    end = hi;
  }
  return covered >= o.width * 0.6;
}
