/**
 * Profile Editor helpers (pure): snapping to the editing grid, finding the
 * vertex or edge under the cursor, inserting and removing vertices, and
 * a closed outline's orientation.
 */

/** A point on the grid of `step` mm (no snapping when step is 0). */
export const snapTo = (p, step) => (step > 0 ? [Math.round(p[0] / step) * step, Math.round(p[1] / step) * step] : [p[0], p[1]]);

/** The vertex of any loop within tol: { shape, loop (0 outline, 1+ holes), index } or null. */
export function vertexAt(shapes, p, tol) {
  let best = null;
  shapes.forEach((s, si) =>
    [s.poly, ...(s.holes || [])].forEach((loop, li) =>
      loop.forEach((q, qi) => {
        const d = Math.hypot(q[0] - p[0], q[1] - p[1]);
        if (d <= tol && (!best || d < best.d)) best = { shape: si, loop: li, index: qi, d };
      }),
    ),
  );
  return best;
}

/** The edge of any loop within tol: { shape, loop, index (edge from index to index + 1), at } or null. */
export function edgeAt(shapes, p, tol) {
  let best = null;
  shapes.forEach((s, si) =>
    [s.poly, ...(s.holes || [])].forEach((loop, li) => {
      for (let i = 0; i < loop.length; i++) {
        const a = loop[i];
        const b = loop[(i + 1) % loop.length];
        const dx = b[0] - a[0];
        const dy = b[1] - a[1];
        const l2 = dx * dx + dy * dy || 1;
        const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2));
        const q = [a[0] + dx * t, a[1] + dy * t];
        const d = Math.hypot(q[0] - p[0], q[1] - p[1]);
        if (d <= tol && (!best || d < best.d)) best = { shape: si, loop: li, index: i, at: q, d };
      }
    }),
  );
  return best;
}

const loopOf = (s, li) => (li === 0 ? s.poly : s.holes[li - 1]);
const withLoop = (s, li, loop) => (li === 0 ? { ...s, poly: loop } : { ...s, holes: s.holes.map((h, k) => (k === li - 1 ? loop : h)) });

/** Shapes with a vertex moved. */
export function moveVertex(shapes, ref, p) {
  return shapes.map((s, si) => (si !== ref.shape ? s : withLoop(s, ref.loop, loopOf(s, ref.loop).map((q, i) => (i === ref.index ? [p[0], p[1]] : q)))));
}

/** Shapes with a vertex put on an edge (after ref.index). */
export function insertVertex(shapes, ref, p) {
  return shapes.map((s, si) => {
    if (si !== ref.shape) return s;
    const loop = loopOf(s, ref.loop).slice();
    loop.splice(ref.index + 1, 0, [p[0], p[1]]);
    return withLoop(s, ref.loop, loop);
  });
}

/** Shapes with a vertex removed; a loop needs three, so a hole that would be left with two goes. */
export function removeVertex(shapes, ref) {
  return shapes.map((s, si) => {
    if (si !== ref.shape) return s;
    const loop = loopOf(s, ref.loop).filter((_, i) => i !== ref.index);
    if (loop.length >= 3) return withLoop(s, ref.loop, loop);
    if (ref.loop === 0) return s;
    return { ...s, holes: s.holes.filter((_, k) => k !== ref.loop - 1) };
  });
}

/** Signed area (positive counterclockwise). */
export const signedArea = (loop) => loop.reduce((t, p, i) => t + p[0] * loop[(i + 1) % loop.length][1] - loop[(i + 1) % loop.length][0] * p[1], 0) / 2;
