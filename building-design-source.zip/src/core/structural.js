/**
 * Structural supports and loads, as Archicad's Structural Support, Structural
 * Point / Line / Surface Load tools and its Create Structural Supports and
 * Create/Update Loads commands (the analytical side of the model).
 *
 *   structuralSupport { levelId, offset, at | a + b, fixity: 'fixed' | 'pinned' | 'roller', hostId? }
 *   structuralLoad    { levelId, offset, type: 'point' | 'line' | 'surface', at | a + b | boundary,
 *                       value (kN, kN/m or kN/m²), loadCase: 'dead' | 'live' | 'snow' | 'wind', hostId?, auto? }
 *
 * Created supports sit under the columns and walls of the lowest level;
 * created loads lie on each slab and roof: its self-weight (from its layers'
 * densities) as a dead load, and an imposed load (live on slabs, snow on roofs).
 */
import { structuralUnits, loadToDisplay, loadUnitLabel } from './projectprefs.js';
import { levelElevation, wallAxis } from './model.js';
import { typeThickness } from './catalog.js';
import { thermalProperties } from './materials.js';
import { MeshBuilder } from './mesh.js';
import { area as polyArea, pointInPolygon } from './geom.js';
import { roofGeometry } from './build3d.js';
import { W } from './plan.js';

export const FIXITY = [
  { value: 'fixed', label: 'Fixed' },
  { value: 'pinned', label: 'Pinned' },
  { value: 'roller', label: 'Roller' },
];
export const LOAD_CASES = [
  { value: 'dead', label: 'Dead (G)' },
  { value: 'live', label: 'Imposed (Q)' },
  { value: 'snow', label: 'Snow (S)' },
  { value: 'wind', label: 'Wind (W)' },
];
/** The standard load cases under their names in this project, then the project's own. */
export function loadCases(project) {
  const names = project?.loadCaseLabels || {};
  return [...LOAD_CASES.map((c) => ({ ...c, label: names[c.value] || c.label })), ...(project?.customLoadCases || [])];
}
const CASE_COLOR = { dead: [90, 100, 120, 255], live: [214, 120, 30, 255], snow: [70, 150, 210, 255], wind: [90, 170, 90, 255] };
const G = 9.81 / 1000; // kN per kg

/** The height the support or load sits at. */
/** The letter of a load case on the drawing: G, Q, or what its name says. */
function caseMark(project, value) {
  const label = loadCases(project).find((c) => c.value === value)?.label || 'G';
  return label.match(/\((.)\)/)?.[1] || label[0];
}

const zOf = (doc, el) => levelElevation(doc, el.levelId) + (+el.offset || 0);

/** Self-weight of a slab or roof type in kN/m² (its layers' densities), or a fallback of 25 kN/m³ concrete. */
export function selfWeight(doc, type) {
  const t = thermalProperties(doc, type);
  if (t?.mass > 0) return t.mass * G;
  const th = (typeThickness(type) || 200) / 1000;
  return 25 * th;
}

/**
 * Create Structural Supports: under each column and wall standing on the
 * lowest level, unless it has one. Columns fixed at a point, walls pinned
 * along their length. Returns the new elements (to add).
 */
export function supportsFor(doc) {
  const levels = doc.levels();
  if (!levels.length) return [];
  const low = levels.reduce((a, b) => (a.elevation <= b.elevation ? a : b));
  const have = new Set(doc.all('structuralSupport').map((s) => s.hostId).filter(Boolean));
  const out = [];
  for (const c of doc.all('column')) {
    if (c.levelId !== low.id || have.has(c.id) || !c.at) continue;
    out.push({ kind: 'structuralSupport', levelId: low.id, offset: +c.baseOffset || 0, at: [c.at[0], c.at[1]], fixity: 'fixed', hostId: c.id });
  }
  for (const w of doc.all('wall')) {
    if (w.levelId !== low.id || have.has(w.id) || w.arc) continue;
    const ax = wallAxis(doc, w);
    out.push({ kind: 'structuralSupport', levelId: low.id, offset: +w.baseOffset || 0, a: ax.a, b: ax.b, fixity: 'pinned', hostId: w.id });
  }
  return out;
}

/**
 * Create/Update Loads: on each slab its self-weight and an imposed load, on
 * each roof its self-weight and snow, as surface loads over its outline.
 * opts: { live (kN/m², 2.0: EN 1991-1-1 category A), snow (kN/m², 1.0) }.
 */
export function loadsFor(doc, { live = 2, snow = 1 } = {}) {
  const out = [];
  for (const s of doc.all('floor')) {
    if (!s.boundary || s.boundary.length < 3) continue;
    const base = { kind: 'structuralLoad', levelId: s.levelId, offset: +s.offset || 0, type: 'surface', boundary: s.boundary.map((p) => [p[0], p[1]]), hostId: s.id, auto: true };
    out.push({ ...base, loadCase: 'dead', value: round(selfWeight(doc, doc.get(s.typeId))) });
    if (live > 0) out.push({ ...base, loadCase: 'live', value: live });
  }
  for (const r of doc.all('roof')) {
    if (!r.boundary || r.boundary.length < 3) continue;
    const g = roofGeometry(doc, r);
    const top = Math.max(...g.poly.map((p) => (g.planes.length ? g.planes.reduce((h, pl) => Math.min(h, (pl.h || 0) + pl.k * ((p[0] - pl.p[0]) * pl.m[0] + (p[1] - pl.p[1]) * pl.m[1])), Infinity) : 0)));
    const base = { kind: 'structuralLoad', levelId: r.levelId, offset: (+r.baseOffset || 0) + Math.max(0, top) + 300, type: 'surface', boundary: g.poly.map((p) => [p[0], p[1]]), hostId: r.id, auto: true };
    out.push({ ...base, loadCase: 'dead', value: round(selfWeight(doc, doc.get(r.typeId))) });
    if (snow > 0) out.push({ ...base, loadCase: 'snow', value: snow });
  }
  return out;
}

const round = (v) => Math.round(v * 100) / 100;

/** The total force of a load in kN: value times length or area. */
export function loadTotal(el) {
  const v = +el.value || 0;
  if (el.type === 'line' && el.a && el.b) return (v * Math.hypot(el.b[0] - el.a[0], el.b[1] - el.a[1])) / 1000;
  if (el.type === 'surface' && el.boundary?.length >= 3) return (v * polyArea(el.boundary)) / 1e6;
  return v;
}

/** Totals per load case over the model, in kN. */
export function loadSummary(doc) {
  const out = {};
  for (const l of doc.all('structuralLoad')) out[l.loadCase || 'dead'] = (out[l.loadCase || 'dead'] || 0) + loadTotal(l);
  return out;
}

// 3D ---------------------------------------------------------------------------------------------------------------

/** An arrow down onto p from `len` above it. */
function arrow(b, p, z, len, col) {
  const s = 25;
  const head = Math.min(150, len / 3);
  const box = (x0, x1, y0, y1, z0, z1) => b.prism([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], [], z0, z1, col, { edges: false });
  box(p[0] - s / 2, p[0] + s / 2, p[1] - s / 2, p[1] + s / 2, z + head, z + len);
  // The head: a four-sided pyramid with its tip on the point.
  const r = 70;
  const tip = [p[0], p[1], z];
  const ring = [[r, 0], [0, r], [-r, 0], [0, -r]].map(([dx, dy]) => [p[0] + dx, p[1] + dy, z + head]);
  for (let i = 0; i < 4; i++) b.tri(tip, ring[(i + 1) % 4], ring[i], col);
  b.quad(ring[0], ring[1], ring[2], ring[3], col);
}

export function buildStructural(ctx, el) {
  const doc = ctx.doc;
  const z = zOf(doc, el);
  const b = new MeshBuilder();
  if (el.kind === 'structuralSupport') {
    const col = [40, 120, 70, 255];
    const sym = (p) => {
      // A pyramid under the point; fixed adds a base block, a roller its rollers.
      const r = 180;
      const h = 220;
      const tip = [p[0], p[1], z];
      const ring = [[-r, -r], [r, -r], [r, r], [-r, r]].map(([dx, dy]) => [p[0] + dx, p[1] + dy, z - h]);
      for (let i = 0; i < 4; i++) b.tri(tip, ring[i], ring[(i + 1) % 4], col);
      b.quad(ring[3], ring[2], ring[1], ring[0], col);
      for (const q of ring) b.edge(tip, q);
      if (el.fixity === 'fixed') b.prism([[p[0] - 260, p[1] - 260], [p[0] + 260, p[1] - 260], [p[0] + 260, p[1] + 260], [p[0] - 260, p[1] + 260]], [], z - h - 60, z - h, col);
      if (el.fixity === 'roller') for (const dx of [-110, 110]) b.prism([[p[0] + dx - 40, p[1] - r], [p[0] + dx + 40, p[1] - r], [p[0] + dx + 40, p[1] + r], [p[0] + dx - 40, p[1] + r]], [], z - h - 80, z - h, col);
    };
    if (el.at) sym(el.at);
    else if (el.a && el.b) {
      const L = Math.hypot(el.b[0] - el.a[0], el.b[1] - el.a[1]);
      const n = Math.max(1, Math.round(L / 1000));
      for (let k = 0; k <= n; k++) sym([el.a[0] + ((el.b[0] - el.a[0]) * k) / n, el.a[1] + ((el.b[1] - el.a[1]) * k) / n]);
    }
    return b.build();
  }
  const col = CASE_COLOR[el.loadCase] || CASE_COLOR.dead;
  const len = 300 + Math.min(900, 150 * Math.sqrt(Math.max(0, +el.value || 0)));
  // Loads of different cases on one host stand at different heights so they do not overlap.
  const lift = ({ dead: 0, live: 1, snow: 1, wind: 2 }[el.loadCase] ?? 1) * 60;
  const zz = z + 20 + lift;
  if (el.type === 'point' && el.at) arrow(b, el.at, zz, len, col);
  else if (el.type === 'line' && el.a && el.b) {
    const L = Math.hypot(el.b[0] - el.a[0], el.b[1] - el.a[1]);
    const n = Math.max(1, Math.round(L / 500));
    for (let k = 0; k <= n; k++) arrow(b, [el.a[0] + ((el.b[0] - el.a[0]) * k) / n, el.a[1] + ((el.b[1] - el.a[1]) * k) / n], zz, len, col);
    b.edge([el.a[0], el.a[1], zz + len], [el.b[0], el.b[1], zz + len]);
  } else if (el.type === 'surface' && el.boundary?.length >= 3) {
    const xs = el.boundary.map((p) => p[0]);
    const ys = el.boundary.map((p) => p[1]);
    const step = Math.max(600, Math.sqrt(polyArea(el.boundary) / 60));
    const off = ({ dead: 0, live: 0.5, snow: 0.5, wind: 0.25 }[el.loadCase] ?? 0.5) * step;
    for (let x = Math.min(...xs) + step / 2 + off; x < Math.max(...xs); x += step)
      for (let y = Math.min(...ys) + step / 2; y < Math.max(...ys); y += step) if (pointInPolygon([x, y], el.boundary)) arrow(b, [x, y], zz, len, col);
    for (let i = 0; i < el.boundary.length; i++) {
      const p = el.boundary[i];
      const q = el.boundary[(i + 1) % el.boundary.length];
      b.edge([p[0], p[1], zz + len], [q[0], q[1], zz + len]);
    }
  }
  return b.build();
}

// Plan -------------------------------------------------------------------------------------------------------------

export function planStructural(pc, el, b) {
  if (el.levelId !== pc.view.levelId) return;
  const s = pc.scale || 1;
  if (el.kind === 'structuralSupport') {
    const col = [40, 120, 70, 255];
    const tri = (p) => {
      const r = 2.2 * s;
      const pts = [[p[0], p[1] + r], [p[0] - r, p[1] - r], [p[0] + r, p[1] - r]];
      b.poly(pts, true, W.medium, 0, col);
      if (el.fixity === 'fixed') b.fill(pts, [], col);
      if (el.fixity === 'roller') b.line([p[0] - r, p[1] - r * 1.5], [p[0] + r, p[1] - r * 1.5], W.medium, 0, col);
      b.pick(pts);
    };
    if (el.at) tri(el.at);
    else if (el.a && el.b) {
      b.line(el.a, el.b, W.medium, 0, col);
      tri(el.a);
      tri(el.b);
      b.pick([el.a, el.b, [el.b[0] + 1, el.b[1] + 1], [el.a[0] + 1, el.a[1] + 1]]);
    }
    return;
  }
  const col = CASE_COLOR[el.loadCase] || CASE_COLOR.dead;
  const lu = structuralUnits(pc.doc.get('project'));
  const label = `${caseMark(pc.doc.get('project'), el.loadCase)} ${loadToDisplay(+el.value || 0, el.type, lu).toFixed(2)} ${loadUnitLabel(el.type, lu)}`;
  const lift = { dead: 0, live: 1, snow: 1, wind: 2 }[el.loadCase] * 4.5 * s;
  if (el.type === 'surface' && el.boundary?.length >= 3) {
    b.poly(el.boundary, true, W.thin, 2, col);
    const xs = el.boundary.map((p) => p[0]);
    const ys = el.boundary.map((p) => p[1]);
    // In the outline's top left corner, one row per load case (a roof's in the top right, clear of its slab's).
    const right = pc.doc.get(el.hostId)?.kind === 'roof';
    b.text([right ? Math.max(...xs) - 4 * s : Math.min(...xs) + 4 * s, Math.max(...ys) - 5 * s - lift], label, { size: 2.5 * s, color: col, align: right ? 'right' : 'left' });
    b.pick(el.boundary);
  } else if (el.type === 'line' && el.a && el.b) {
    b.line(el.a, el.b, W.medium, 2, col);
    b.text([(el.a[0] + el.b[0]) / 2, (el.a[1] + el.b[1]) / 2 + 3 * s], label, { size: 2.5 * s, color: col });
    b.pick([el.a, el.b, [el.b[0] + 1, el.b[1] + 1], [el.a[0] + 1, el.a[1] + 1]]);
  } else if (el.at) {
    const r = 1.5 * s;
    b.line([el.at[0], el.at[1] + 6 * s], el.at, W.medium, 0, col);
    b.poly([[el.at[0] - r, el.at[1] + r * 1.6], el.at, [el.at[0] + r, el.at[1] + r * 1.6]], false, W.medium, 0, col);
    b.text([el.at[0], el.at[1] + 8 * s], label, { size: 2.5 * s, color: col });
    b.pick([[el.at[0] - r, el.at[1] - r], [el.at[0] + r, el.at[1] - r], [el.at[0] + r, el.at[1] + r], [el.at[0] - r, el.at[1] + r]]);
  }
}
