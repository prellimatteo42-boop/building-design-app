/**
 * A stair read from its plan drawing: flights are runs of tread lines (parallel, as long as each other, evenly spaced),
 * the walking line's arrow says which way it climbs. One flight is a straight stair, two side by side running opposite
 * ways a U (half-turn) stair, two at a right angle an L. Lengths in drawing units (mm).
 */
const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1];
const len = (a) => Math.hypot(a[0], a[1]);

/** The flights among a stair's lines: [{ d (across the treads), u (along them), s0, s1, c, width, count, tread }]. */
export function flightsFromLines(lines, { minTreads = 4 } = {}) {
  const cand = lines
    .map((l) => ({ l, L: len(sub(l.b, l.a)) }))
    .filter((x) => x.L >= 500 && x.L <= 4000)
    .map((x) => {
      let u = [(x.l.b[0] - x.l.a[0]) / x.L, (x.l.b[1] - x.l.a[1]) / x.L];
      if (u[0] < -1e-9 || (Math.abs(u[0]) < 1e-9 && u[1] < 0)) u = [-u[0], -u[1]];
      return { ...x, u };
    });
  const groups = [];
  for (const x of cand) {
    const g = groups.find((g) => Math.abs(dot(g.u, x.u)) > 0.999 && Math.abs(g.L - x.L) <= 0.04 * g.L);
    if (g) g.items.push(x);
    else groups.push({ u: x.u, L: x.L, items: [x] });
  }
  const flights = [];
  for (const g of groups) {
    if (g.items.length < minTreads) continue;
    const d = [-g.u[1], g.u[0]];
    // Lines along one line through the flight: their middles project alike along the treads (two flights of a U stair
    // have their treads at the same places, one beside the other).
    const all = g.items.map((x) => {
      const m = [(x.l.a[0] + x.l.b[0]) / 2, (x.l.a[1] + x.l.b[1]) / 2];
      return { x, s: dot(m, d), c: dot(m, g.u) };
    });
    const lanes = [];
    for (const r of all) {
      const lane = lanes.find((ln) => Math.abs(ln.c - r.c) <= 0.05 * g.L);
      if (lane) lane.rows.push(r);
      else lanes.push({ c: r.c, rows: [r] });
    }
    for (const lane of lanes) {
      const before = flights.length;
      runsOf(lane.rows.sort((p, q) => p.s - q.s), d, g);
      // One flight broken by the cut line (its tread lines stop where the break is drawn): runs in one lane with the
      // same going, a few treads apart, are one flight, its risers counted by its length.
      const mine = flights.splice(before).sort((p, q) => p.s0 - q.s0);
      for (const f of mine) {
        const prev = flights.length > before ? flights.at(-1) : null;
        const gapTreads = prev ? (f.s0 - prev.s1) / prev.tread : Infinity;
        if (prev && Math.abs(f.tread - prev.tread) <= 0.1 * prev.tread && gapTreads > 0.5 && gapTreads <= 8) {
          prev.s1 = f.s1;
          prev.count = Math.round((prev.s1 - prev.s0) / prev.tread) + 1;
        } else flights.push(f);
      }
    }
  }
  return flights.sort((p, q) => q.count - p.count);

  function runsOf(rows, d, g) {
    // Runs of lines lined up (same middle along the treads) and evenly spaced.
    let run = [];
    const flush = () => {
      if (run.length >= minTreads) {
        const steps = run.slice(1).map((r, i) => r.s - run[i].s);
        const sorted = [...steps].sort((p, q) => p - q);
        const med = sorted[Math.floor(sorted.length / 2)];
        flights.push({ d, u: g.u, s0: run[0].s, s1: run.at(-1).s, c: run.reduce((a, r) => a + r.c, 0) / run.length, width: g.L, count: run.length, tread: med });
      }
      run = [];
    };
    for (const r of rows) {
      const last = run.at(-1);
      if (!last) { run.push(r); continue; }
      const step = r.s - last.s;
      // The same tread drawn twice (two pens) counts once.
      if (step < 1) continue;
      const prev = run.length >= 2 ? last.s - run.at(-2).s : null;
      const even = step >= 150 && step <= 450 && (prev == null || Math.abs(step - prev) <= 0.15 * prev);
      if (even) run.push(r);
      else {
        flush();
        run.push(r);
      }
    }
    flush();
  }
}

/** The walking line's arrow tip: where two short lines meet at an angle, with a longer line ending there. */
export function arrowTip(lines) {
  const short = lines.filter((l) => { const L = len(sub(l.b, l.a)); return L >= 80 && L <= 800; });
  const ends = (l) => [l.a, l.b];
  for (let i = 0; i < short.length; i++)
    for (let j = i + 1; j < short.length; j++)
      for (const p of ends(short[i]))
        for (const q of ends(short[j])) {
          if (len(sub(p, q)) > 15) continue;
          const o1 = ends(short[i]).find((e) => e !== p);
          const o2 = ends(short[j]).find((e) => e !== q);
          const v1 = sub(o1, p);
          const v2 = sub(o2, q);
          const cos = dot(v1, v2) / (len(v1) * len(v2));
          if (cos < -0.5 || cos > 0.8) continue;
          // The shaft: a longer line ending at the tip, running back between the two barbs.
          const back = [(v1[0] / len(v1) + v2[0] / len(v2)) / 2, (v1[1] / len(v1) + v2[1] / len(v2)) / 2];
          const shaft = lines.some((l) => {
            const L = len(sub(l.b, l.a));
            if (L < 500) return false;
            for (const [e, f] of [[l.a, l.b], [l.b, l.a]]) if (len(sub(e, p)) < 20 && dot(sub(f, e), back) / L > 0.8 * len(back)) return true;
            return false;
          });
          if (shaft) return { at: p, back };
        }
  return null;
}

/**
 * A stair from its lines, as the stair tool's element wants it: { a (middle of the first riser), dir, width, tread,
 * risers, shape, splitRisers, turn, gap, riser }; null when no flight is found. The riser height is not in a plan: it is
 * taken from the going by the step rule (2 risers + 1 going = 630 mm), within 150 and 190 mm.
 */
export function stairFromLines(lines, arcs = []) {
  const fl = flightsFromLines(lines);
  if (!fl.length) return null;
  const tip = arrowTip(lines);
  // The walking line starts with a small circle (Archicad's symbol): its flight is the first, climbing away from it.
  // (Drawn whole or as arcs round one centre that together go most of the way round.)
  const round = [];
  for (const a of arcs) {
    if (a.r < 40 || a.r > 250) continue;
    let sw = a.a1 - a.a0;
    while (sw <= 0) sw += 2 * Math.PI;
    const k = round.find((x) => len(sub(x.c, a.c)) < 10 && Math.abs(x.r - a.r) < 10);
    if (k) k.sw += sw;
    else round.push({ c: a.c, r: a.r, sw });
  }
  const circles = round.filter((x) => x.sw >= (300 * Math.PI) / 180).map((x) => x.c);
  const box = (f) => ({ in: (p) => dot(p, f.d) >= f.s0 - 300 && dot(p, f.d) <= f.s1 + 300 && Math.abs(dot(p, f.u) - f.c) <= f.width / 2 + 300 });
  const mid = (f, s) => [f.d[0] * s + f.u[0] * f.c, f.d[1] * s + f.u[1] * f.c];
  const riserOf = (td) => Math.round(Math.max(150, Math.min(190, (630 - td) / 2)));
  const f1 = fl[0];
  const f2 = fl.find((f) => f !== f1 && f.count >= 4 && Math.abs(f.width - f1.width) <= 0.1 * f1.width);
  const holds = (f, p) => box(f).in(p);
  const startOf = (f) => circles.find((c) => holds(f, c));
  if (!f2) {
    // One flight: it climbs away from the circle, or towards the arrow.
    const c = startOf(f1);
    const up = c ? dot(c, f1.d) < (f1.s0 + f1.s1) / 2 : tip ? dot(tip.at, f1.d) > (f1.s0 + f1.s1) / 2 : true;
    const dir = up ? f1.d : [-f1.d[0], -f1.d[1]];
    const a = mid(f1, up ? f1.s0 : f1.s1);
    return { a, dir, width: f1.width, tread: f1.tread, risers: f1.count, shape: 'straight', riser: riserOf(f1.tread) };
  }
  const par = Math.abs(dot(f1.d, f2.d)) > 0.95;
  // The first flight is the one the walking line starts in; else the arrow's flight is the last.
  let first = f1;
  let last = f2;
  if (startOf(f2) && !startOf(f1)) [first, last] = [f2, f1];
  else if (!startOf(f1) && tip && holds(f1, tip.at) && !holds(f2, tip.at)) [first, last] = [f2, f1];
  const td = (first.tread + last.tread) / 2;
  if (par) {
    // A U stair: both flights end at the landing. The first climbs away from its circle (or, without one, opposite the
    // way the last climbs to the arrow).
    let dir;
    const c = startOf(first);
    if (c) dir = dot(c, first.d) < (first.s0 + first.s1) / 2 ? first.d : [-first.d[0], -first.d[1]];
    else {
      const lastUp = tip ? dot(tip.at, last.d) > (last.s0 + last.s1) / 2 : false;
      dir = lastUp ? [-last.d[0], -last.d[1]] : last.d;
    }
    const sgn = dot(dir, first.d) > 0 ? 1 : -1;
    // Measured along dir: the first's start, the landing's edge (the farther of the two flights' ends: a tread line
    // broken by the cut line is missing), the last's top.
    const a = mid(first, sgn > 0 ? first.s0 : first.s1);
    const start = dot(a, dir);
    const ends = (f) => [mid(f, f.s0), mid(f, f.s1)].map((p) => dot(p, dir));
    const landing = Math.max(...ends(first), ...ends(last));
    const top = Math.min(...ends(last));
    const r1 = Math.round((landing - start) / td) + 1;
    const r2 = Math.round((landing - top) / td) + 1;
    const across = dot(sub(mid(last, (last.s0 + last.s1) / 2), mid(first, (first.s0 + first.s1) / 2)), [-dir[1], dir[0]]);
    return { a, dir, width: first.width, tread: td, risers: r1 + r2, splitRisers: r1, shape: 'u', turn: across > 0 ? 'left' : 'right', gap: Math.max(0, Math.abs(across) - first.width), riser: riserOf(td) };
  }
  // An L stair: the first runs towards the last's line.
  const toLast = sub(mid(last, (last.s0 + last.s1) / 2), mid(first, (first.s0 + first.s1) / 2));
  const dir = dot(toLast, first.d) > 0 ? first.d : [-first.d[0], -first.d[1]];
  const s0 = dot(dir, first.d) > 0 ? first.s0 : first.s1;
  const a = mid(first, s0);
  const cross = dir[0] * toLast[1] - dir[1] * toLast[0];
  return { a, dir, width: first.width, tread: (first.tread + last.tread) / 2, risers: first.count + last.count, splitRisers: first.count, shape: 'l', turn: cross > 0 ? 'left' : 'right', landingDepth: first.width, riser: riserOf(first.tread) };
}
