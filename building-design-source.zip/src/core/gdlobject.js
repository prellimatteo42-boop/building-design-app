/**
 * Library parts written in GDL (gdl.js) as component types: a type with
 * family 'gdl' carries { params: [{ name, kind, value, label }], script3d,
 * script2d }. Lengths are millimetres in the app and metres in the script,
 * as in Archicad; A, B and ZZYZX are the type's width, depth and height.
 * The object's box is centred on its insertion point.
 */
import { runGDL } from './gdl.js';
import { read3DBinary } from '../io/binary3d.js';
import { unionAll } from './polybool.js';
import { signedArea } from './geom.js';

// Binary 3D data a type carries (base64 by number), read once per type and section.
const binaryCache = new WeakMap();
function binaryFor(holder) {
  if (!holder?.binaries) return null;
  let read = binaryCache.get(holder);
  if (!read) binaryCache.set(holder, (read = new Map()));
  return (id) => {
    if (!read.has(id)) {
      const b64 = holder.binaries[id];
      let bodies = null;
      if (b64) {
        const bin = atob(b64);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        bodies = read3DBinary(bytes);
      }
      read.set(id, bodies);
    }
    return read.get(id);
  };
}

/** The script's variables for a type (and an instance's own values). */
export function gdlVars(type, own = {}) {
  // A placed object can have its own size (own.A, own.B, own.ZZYZX, in mm).
  const t = { width: +own.A || +type.width || 1000, depth: +own.B || +type.depth || 1000, height: +own.ZZYZX || +type.height || 1000 };
  const vars = { A: t.width / 1000, B: t.depth / 1000, ZZYZX: t.height / 1000 };
  for (const p of type.gdl?.params || []) {
    const v = own[p.name] ?? p.value;
    vars[String(p.name).toUpperCase()] = Array.isArray(v) ? v : p.kind === 'length' ? (+v || 0) / 1000 : p.kind === 'boolean' ? (v ? 1 : 0) : p.kind === 'number' || p.kind === 'integer' || p.kind === 'angle' ? +v || 0 : v ?? '';
  }
  return vars;
}

/**
 * Run a GDL type's scripts. Returns { tris, edges, lines, polys, texts, error }
 * in the object's local millimetres (box centred on the origin). `globals`
 * are the global variables its host sets (in GDL's units and arrays).
 */
export function runGdlType(type, own = {}, globals = {}) {
  // Globals a host element sets (a stair's tread polygon for its tread component) come after the parameters.
  const vars = { ...gdlVars(type, own), ...globals };
  // This app's own GDL objects have their box centred on the insertion point; Archicad's keep their origin there.
  const dx = type.gdl?.lenient ? 0 : -vars.A / 2;
  const dy = type.gdl?.lenient ? 0 : -vars.B / 2;
  const m = (p) => [(p[0] + dx) * 1000, (p[1] + dy) * 1000, (p[2] ?? 0) * 1000];
  const out = { tris: [], edges: [], lines: [], polys: [], texts: [], pictures: [], error: null, unknown: null };
  // Objects from Archicad run leniently, with their master script first and their macros with them.
  const g = type.gdl || {};
  const macro = (n) => {
    const m = g.macros?.[String(n).toLowerCase()];
    return m ? { ...m, binary: binaryFor(m) } : null;
  };
  const opts = g.lenient ? { lenient: true, maxSteps: 3e6, macros: macro, binary: binaryFor(g) } : {};
  const withMaster = (src) => (g.master ? `${g.master}\n${src}` : src);
  try {
    const r3 = runGDL(withMaster(type.gdl?.script3d || ''), { vars, mode: '3d', ...opts });
    if (r3.unknown?.size) out.unknown = Object.fromEntries(r3.unknown);
    // A triangle keeps a defined material's colour and transparency, and the picture its texture shows.
    out.tris = r3.tris.map((t) => {
      const o = { a: m(t.a), b: m(t.b), c: m(t.c), mat: t.mat };
      if (t.rgb) o.rgb = t.rgb;
      if (t.alpha !== undefined) o.alpha = t.alpha;
      const src = t.tex && g.pictures?.[t.tex.pic];
      if (src) {
        o.src = src;
        o.uv = t.uv;
      }
      return o;
    });
    // Pictures that turn to face the eye (trees, people) cannot in a model seen from anywhere: a second copy
    // a quarter turn round makes them stand as a cross.
    const pics = out.tris.filter((t) => t.src);
    if (pics.length && /GLOB_EYEPOS/i.test(`${g.master || ''}\n${g.script3d || ''}`)) {
      const xs = pics.flatMap((t) => [t.a[0], t.b[0], t.c[0]]);
      const ys = pics.flatMap((t) => [t.a[1], t.b[1], t.c[1]]);
      const cx = (Math.min(...xs) + Math.max(...xs)) / 2;
      const cy = (Math.min(...ys) + Math.max(...ys)) / 2;
      const turn = (p) => [cx - (p[1] - cy), cy + (p[0] - cx), p[2]];
      for (const t of pics) out.tris.push({ ...t, a: turn(t.a), b: turn(t.b), c: turn(t.c) });
    }
    out.edges = r3.edges.map(([a, b]) => [m(a), m(b)]);
    const src2 = type.gdl?.script2d || '';
    let r2 = null;
    try {
      r2 = src2.trim() ? runGDL(withMaster(src2), { vars, mode: '2d', ...opts }) : null;
    } catch (err) {
      if (!g.lenient) throw err;
    }
    if (r2) {
      out.lines = r2.lines2.map(([a, b]) => [m(a), m(b)]);
      out.polys = r2.polys2.map((q) => ({ ...q, pts: q.pts.map(m) }));
      out.texts = r2.texts2.map((x) => ({ ...x, at: m(x.at) }));
      // Pictures in the plan (a tree seen from above), where the type carries them.
      out.pictures = r2.pictures2.filter((q) => g.pictures?.[q.pic]).map((q) => ({ src: g.pictures[q.pic], pts: q.pts.map((p) => m(p).slice(0, 2)) }));
    }
    // Without a 2D script, with PROJECT2, or with a 2D drawing this reader cannot show: the 3D seen from above.
    if (!r2 || r2.project2 || (!out.lines.length && !out.polys.length)) for (const [a, b] of out.edges) if (Math.hypot(a[0] - b[0], a[1] - b[1]) > 0.5) out.lines.push([a, b]);
    if (!out.lines.length && !out.polys.length && out.tris.length) out.polys.push({ pts: footprint(out.tris), fill: false });
  } catch (err) {
    out.error = err.message || String(err);
  }
  return out;
}

/** The box around triangles seen from above, as a polygon. */
function footprint(tris) {
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (const t of tris)
    for (const p of [t.a, t.b, t.c]) {
      x0 = Math.min(x0, p[0]);
      y0 = Math.min(y0, p[1]);
      x1 = Math.max(x1, p[0]);
      y1 = Math.max(y1, p[1]);
    }
  return [[x0, y0, 0], [x1, y0, 0], [x1, y1, 0], [x0, y1, 0]];
}

/**
 * Build a GDL component (families.js calls this): 3D into the context's
 * builder, the plan symbol into plan. x is the FamilyContext.
 */
export function buildGdlFamily(type, own, x, plan) {
  const r = runGdlType(type, own);
  const w = +type.width || 1000;
  const d = +type.depth || 1000;
  const h = +type.height || 1000;
  if (r.error || (!r.tris.length && !r.lines.length && !r.polys.length && !r.pictures?.length)) {
    // A script that fails shows as its box, so the object can still be found and fixed.
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, '#e0a0a0');
    plan.loops.push({ pts: [[-w / 2, -d / 2], [w / 2, -d / 2], [w / 2, d / 2], [-w / 2, d / 2]], closed: true });
    plan.loops.push({ pts: [[-w / 2, -d / 2], [w / 2, d / 2]] });
    plan.error = r.error;
    return plan;
  }
  if (x.b) {
    const f = x.frame;
    const W = (p) => {
      const q = f.apply(p);
      return [q[0], q[1], f.z + p[2]];
    };
    const colors = new Map();
    const colorOf = (mat) => {
      if (!colors.has(mat)) colors.set(mat, x.color(typeof mat === 'string' && mat ? mat : 'mat-default'));
      return colors.get(mat);
    };
    const look = (t) => (t.rgb ? [...t.rgb.map((v) => Math.round(v * 255)), Math.round((t.alpha ?? 1) * 255)] : colorOf(t.mat));
    for (const t of r.tris) {
      if (t.src && x.b.texTri) x.b.texTri(W(t.a), W(t.b), W(t.c), t.uv, t.src, [255, 255, 255, Math.round((t.alpha ?? 1) * 255)]);
      else x.b.tri(W(t.a), W(t.b), W(t.c), look(t));
    }
    for (const [a, b] of r.edges) x.b.edge(W(a), W(b));
  }
  // The pick outline: the drawing's own box when the origin is not its middle.
  if (type.gdl?.lenient && r.tris.length) plan.outline = footprint(r.tris).map((p) => p.slice(0, 2));
  for (const [a, b] of r.lines) plan.loops.push({ pts: [a.slice(0, 2), b.slice(0, 2)] });
  for (const q of r.polys) plan.loops.push({ pts: q.pts.map((p) => p.slice(0, 2)), closed: true });
  plan.texts = r.texts;
  // A picture in plan is the symbol's own fill: no blank under it.
  if (r.pictures?.length) {
    plan.pictures = r.pictures;
    plan.noFill = true;
  }
  return plan;
}

/**
 * Run a GDL door or window (from Archicad) for an opening of this size in
 * a wall this thick (mm). Returns its 3D (x along the wall from the
 * opening's middle, y up from its bottom, z out of the wall from its
 * reveal face) and its 2D (x along the wall, y from the reveal face
 * inwards), in millimetres; parts far outside the opening are left out.
 */
// Runs of a door or window per type, size and own values: the wall and the opening both ask.
const openingRuns = new WeakMap();

export function runGdlOpening(type, size, own = {}, detail3D = null) {
  let runs = openingRuns.get(type);
  if (!runs) openingRuns.set(type, (runs = new Map()));
  const key = `${size.width}|${size.height}|${size.thickness}|${size.wallHeight ?? 3000}|${JSON.stringify(own)}|${detail3D ?? ''}`;
  if (!runs.has(key)) {
    if (runs.size > 64) runs.clear();
    runs.set(key, computeGdlOpening(type, size, own, detail3D));
  }
  return runs.get(key);
}

/** Whether a GDL wall cut goes right through the wall: a WALLHOLE, or a WALLNICHE that is infinite. */
export function throughCut(c) {
  return c.method === 0 || (c.status & 24) === 24;
}

/**
 * The span of a cut across its wall, as depths (mm) from the face the
 * opening is placed on (its origin; its z runs into the wall): [from, to],
 * unbounded ends as infinities. A finite niche runs from its polygon's
 * plane to its depth along its direction, a semi-infinite one from its
 * depth back the other way (GDL's WALLNICHE status bits 8 and 16).
 */
function cutSpan(c) {
  if (throughCut(c)) return [-Infinity, Infinity];
  const dz = Math.sign(c.dir[2]);
  const d = +c.depth || 0;
  const z0 = c.pts[0][2] || 0;
  const [lo, hi] = c.status & 16 ? (dz > 0 ? [-Infinity, z0 + d] : [z0 - d, Infinity]) : [Math.min(z0, z0 + d * dz), Math.max(z0, z0 + d * dz)];
  return [lo, hi];
}

const centroid = (loop) => [loop.reduce((t, p) => t + p[0], 0) / loop.length, loop.reduce((t, p) => t + p[1], 0) / loop.length];

function pointIn(p, poly) {
  let r = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const c = poly[j];
    if (a[1] > p[1] !== c[1] > p[1] && p[0] < ((c[0] - a[0]) * (p[1] - a[1])) / (c[1] - a[1]) + a[0]) r = !r;
  }
  return r;
}

/** Whether intervals together cover [a, b] (within half a millimetre). */
function covers(spans, a, b) {
  let at = a;
  for (const [lo, hi] of [...spans].sort((x, y) => x[0] - y[0])) {
    if (lo > at + 0.5) break;
    at = Math.max(at, hi);
  }
  return at >= b - 0.5;
}

/** The biggest piece of the union of loops, counterclockwise, with its area. */
function biggestUnion(loops) {
  const merged = loops.length > 1 ? unionAll(loops.map((l) => ({ boundary: l, holes: [] }))).map((x) => x.boundary) : loops;
  let best = null;
  let area = 0;
  for (const l of merged) {
    const a = Math.abs(signedArea(l));
    if (a > area) (area = a), (best = signedArea(l) < 0 ? [...l].reverse() : l);
  }
  return best && { loop: best, area };
}

/**
 * What a GDL door or window cuts out of its wall, across it (along its z):
 *   shape    the outline of the hole through the wall (the union of the
 *            cuts that go right through), as [x, y] points in mm, x along
 *            the wall from the opening's middle, y up from its bottom; null
 *            when that is the plain rectangle of its size
 *   recess   with no cut through, a niche into one face: { outline, depth
 *            (mm), opposite (true when from the face the opening is not
 *            placed on) }; null when there is none
 */
export function gdlOpeningCut(type, size, own = {}) {
  const r = runGdlOpening(type, size, own);
  const T = size.thickness;
  const through = [];
  const near = [];
  const far = [];
  const all = [];
  for (const c of r.cuts || []) {
    if (Math.abs(c.dir[2]) < 0.9 * Math.hypot(...c.dir)) continue;
    const pts = c.pts.map((p) => [p[0], p[1]]);
    const loop = signedArea(pts) < 0 ? pts.reverse() : pts;
    const span = cutSpan(c);
    const [lo, hi] = span;
    if (hi <= 0 || lo >= T) continue;
    all.push({ loop, span, area: Math.abs(signedArea(loop)) });
    if (lo <= 0.5 && hi >= T - 0.5) through.push(loop);
    else if (lo <= 0.5) near.push({ loop, depth: hi });
    else if (hi >= T - 0.5) far.push({ loop, depth: T - lo });
  }
  // Niches from both faces and between them that together reach through (a fire door's rebates and
  // its hole): a hole as big as the narrowest of those over the same place.
  if (!through.length && all.length > 1)
    for (const big of [...all].sort((a, b) => b.area - a.area)) {
      const c = centroid(big.loop);
      const stack = all.filter((x) => x === big || pointIn(c, x.loop));
      if (stack.length > 1 && covers(stack.map((x) => x.span), 0, T)) {
        through.push(stack.reduce((a, b) => (b.area < a.area ? b : a)).loop);
        break;
      }
    }
  let shape = null;
  const hole = through.length ? biggestUnion(through) : null;
  if (hole) {
    const xs = hole.loop.map((p) => p[0]);
    const ys = hole.loop.map((p) => p[1]);
    // A rectangle (or close to one) cuts as the plain opening does.
    if (hole.area < 0.985 * (Math.max(...xs) - Math.min(...xs)) * (Math.max(...ys) - Math.min(...ys))) shape = hole.loop;
  }
  let recess = null;
  if (!through.length)
    for (const [list, opposite] of [[near, false], [far, true]]) {
      if (!list.length) continue;
      const u = biggestUnion(list.map((x) => x.loop));
      if (u && (!recess || u.area > recess.area)) recess = { outline: u.loop, area: u.area, depth: Math.max(...list.map((x) => x.depth)), opposite };
    }
  if (recess) delete recess.area;
  return { shape, recess };
}

/** The outline of the hole a GDL door or window cuts through its wall (gdlOpeningCut's shape). */
export function gdlOpeningShape(type, size, own = {}) {
  return gdlOpeningCut(type, size, own).shape;
}

function computeGdlOpening(type, { width, height, thickness, wallHeight = 3000 }, own = {}, detail3D = null) {
  const vars = { ...gdlVars({ ...type, width, height }, own), A: width / 1000, B: height / 1000, WALL_THICKNESS: thickness / 1000, WALL_HEIGHT: wallHeight / 1000, WIDO_SILL: 0, WIDO_REVEAL_ON: 0, WIDO_FRAME_THICKNESS: 0.05 };
  // Archicad's parameter script keeps these in step with the opening's size: moved by as much as the size is.
  const dW = (width - (+type.width || width)) / 1000;
  const dH = (height - (+type.height || height)) / 1000;
  const ownKeys = new Set(Object.keys(own).map((k) => k.toUpperCase()));
  for (const [key, delta] of [['AC_WALLHOLE_WIDTH', dW], ['AC_UNIT_WIDTH', dW], ['AC_REVEAL_WIDTH', dW], ['AC_WALLHOLE_HEIGHT', dH], ['AC_UNIT_HEIGHT', dH], ['AC_REVEAL_HEIGHT', dH]])
    if (delta && typeof vars[key] === 'number' && !ownKeys.has(key)) vars[key] += delta;
  const g = type.gdl || {};
  const opts = { detail3D, lenient: true, maxSteps: 3e6, macros: (n) => (g.macros?.[String(n).toLowerCase()] ? { ...g.macros[String(n).toLowerCase()], binary: binaryFor(g.macros[String(n).toLowerCase()]) } : null), binary: binaryFor(g) };
  const withMaster = (src) => (g.master ? `${g.master}\n${src}` : src);
  const reach = Math.max(width, height, thickness) * 2 / 1000;
  const sane = (p) => p.every((v) => Math.abs(v) <= reach + 1);
  const mm = (p) => p.map((v) => v * 1000);
  const out = { tris: [], edges: [], lines: [], polys: [], cuts: [], wallHoles: [], wallBlocks: [], wallLines: [], error: null };
  try {
    const r3 = runGDL(withMaster(g.script3d || ''), { vars, mode: '3d', ...opts });
    out.tris = r3.tris.filter((t) => sane(t.a) && sane(t.b) && sane(t.c)).map((t) => ({ a: mm(t.a), b: mm(t.b), c: mm(t.c), mat: t.mat }));
    out.edges = r3.edges.filter(([a, b]) => sane(a) && sane(b)).map(([a, b]) => [mm(a), mm(b)]);
    out.cuts = r3.wallCuts.filter((c) => c.pts.every(sane)).map((c) => ({ ...c, pts: c.pts.map(mm), depth: c.depth * 1000 }));
  } catch (err) {
    out.error = err.message || String(err);
  }
  try {
    const r2 = runGDL(withMaster(g.script2d || ''), { vars, mode: '2d', ...opts });
    out.lines = r2.lines2.filter(([a, b]) => sane(a) && sane(b)).map(([a, b]) => [mm(a), mm(b)]);
    out.polys = r2.polys2.filter((q) => q.pts.every(sane)).map((q) => ({ ...q, pts: q.pts.map(mm) }));
    out.wallHoles = r2.wallHoles2.filter((q) => q.every(sane)).map((q) => q.map(mm));
    out.wallBlocks = r2.wallBlocks2.filter((q) => q.every(sane)).map((q) => q.map(mm));
    out.wallLines = r2.wallLines2.filter(([a, b]) => sane(a) && sane(b)).map(([a, b]) => [mm(a), mm(b)]);
  } catch (err) {
    out.error ||= err.message || String(err);
  }
  return out;
}
