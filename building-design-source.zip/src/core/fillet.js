/**
 * Fillet and Chamfer, as in Archicad: round or cut the corners of polygons
 * (slabs, ceilings, fills, masses...), or join two lines with an arc or a
 * bevel, trimming them back to it. Radius 0 just meets the two lines.
 */
import { add, sub, scale, dot, norm, len, dist, angleOf, lineIntersect } from './geom.js';

/** A polygon with every corner filleted (an arc of `segs` pieces) or chamfered by r. */
export function filletPolygon(poly, r, mode = 'fillet', segs = 8) {
  const n = poly.length;
  if (n < 3 || !(r > 0)) return poly.map((p) => [...p]);
  const out = [];
  for (let i = 0; i < n; i++) {
    const prev = poly[(i - 1 + n) % n];
    const p = poly[i];
    const next = poly[(i + 1) % n];
    const u1 = norm(sub(prev, p));
    const u2 = norm(sub(next, p));
    const cos = Math.max(-1, Math.min(1, dot(u1, u2)));
    const theta = Math.acos(cos);
    if (theta < 1e-3 || Math.PI - theta < 1e-3) {
      out.push([...p]);
      continue;
    }
    // Room on each side: half of each neighbouring edge, so neighbours never cross.
    const room = Math.min(dist(prev, p), dist(next, p)) / 2;
    let d = mode === 'chamfer' ? r : r / Math.tan(theta / 2);
    d = Math.min(d, room);
    const t1 = add(p, scale(u1, d));
    const t2 = add(p, scale(u2, d));
    if (mode === 'chamfer') {
      out.push(t1, t2);
      continue;
    }
    const rr = d * Math.tan(theta / 2);
    const bis = norm(add(u1, u2));
    const c = add(p, scale(bis, rr / Math.sin(theta / 2)));
    const a0 = angleOf(sub(t1, c));
    let sweep = angleOf(sub(t2, c)) - a0;
    while (sweep > Math.PI) sweep -= Math.PI * 2;
    while (sweep < -Math.PI) sweep += Math.PI * 2;
    for (let k = 0; k <= segs; k++) {
      const a = a0 + (sweep * k) / segs;
      out.push([c[0] + Math.cos(a) * rr, c[1] + Math.sin(a) * rr]);
    }
  }
  return out;
}

/**
 * Join two lines { a, b } at their meeting point with an arc of radius r
 * ('fillet') or a bevel set back r along each ('chamfer'). The ends nearer
 * the meeting point move; returns { first, second, arc?: { c, r, a0, a1 }, bevel?: [p, q] }
 * or null when the lines are parallel.
 */
export function filletLines(l1, l2, r, mode = 'fillet') {
  const hit = lineIntersect(l1.a, sub(l1.b, l1.a), l2.a, sub(l2.b, l2.a));
  if (!hit) return null;
  const X = hit.point;
  // Keep the end of each line farther from the meeting point.
  const keep1 = dist(l1.a, X) >= dist(l1.b, X) ? 'a' : 'b';
  const keep2 = dist(l2.a, X) >= dist(l2.b, X) ? 'a' : 'b';
  const u1 = norm(sub(l1[keep1], X));
  const u2 = norm(sub(l2[keep2], X));
  const theta = Math.acos(Math.max(-1, Math.min(1, dot(u1, u2))));
  const move = (l, keep, p) => (keep === 'a' ? { a: l.a, b: p } : { a: p, b: l.b });
  if (!(r > 0) || theta < 1e-6) return { first: move(l1, keep1, X), second: move(l2, keep2, X) };
  const d = mode === 'chamfer' ? r : r / Math.tan(theta / 2);
  if (d >= len(sub(l1[keep1], X)) || d >= len(sub(l2[keep2], X))) return null;
  const t1 = add(X, scale(u1, d));
  const t2 = add(X, scale(u2, d));
  const out = { first: move(l1, keep1, t1), second: move(l2, keep2, t2) };
  if (mode === 'chamfer') return { ...out, bevel: [t1, t2] };
  const c = add(X, scale(norm(add(u1, u2)), r / Math.sin(theta / 2)));
  let a0 = angleOf(sub(t1, c));
  let a1 = angleOf(sub(t2, c));
  // The short way round, counterclockwise from a0 to a1.
  let sweep = a1 - a0;
  while (sweep < 0) sweep += Math.PI * 2;
  if (sweep > Math.PI) [a0, a1] = [a1, a0];
  while (a1 <= a0) a1 += Math.PI * 2;
  return { ...out, arc: { c, r, a0, a1 } };
}

/** Element kinds whose outline can be filleted: polygons without per-edge or per-corner data. */
export const FILLET_KINDS = new Set(['floor', 'ceiling', 'region', 'mass', 'shaft', 'opening', 'revisionCloud']);
/** Line kinds that can be joined by a fillet or chamfer. */
export const FILLET_LINES = new Set(['detailLine', 'modelLine', 'roomSeparator', 'areaBoundary']);

/**
 * Fillet or chamfer the selection (inside a transaction): every corner of
 * the selected polygons, or the meeting of exactly two selected lines.
 * Returns { polygons, lines } counts, or { error }.
 */
export function applyFillet(doc, ids, { mode = 'fillet', r = 0 } = {}) {
  const els = ids.map((id) => doc.get(id)).filter(Boolean);
  const polys = els.filter((e) => FILLET_KINDS.has(e.kind) && Array.isArray(e.boundary) && e.boundary.length >= 3);
  const lines = els.filter((e) => FILLET_LINES.has(e.kind) && e.a && e.b);
  if (polys.length) {
    if (!(r > 0)) return { error: 'Give a radius or distance larger than zero.' };
    for (const e of polys) {
      const patch = { boundary: filletPolygon(e.boundary, r, mode) };
      if (Array.isArray(e.holes)) patch.holes = e.holes.map((hole) => filletPolygon(hole, r, mode));
      doc.update(e.id, patch);
    }
    return { polygons: polys.length, lines: 0 };
  }
  if (lines.length === 2) {
    const [l1, l2] = lines;
    const res = filletLines(l1, l2, r, mode);
    if (!res) return { error: 'The lines are parallel, or too short for that radius.' };
    doc.update(l1.id, res.first);
    doc.update(l2.id, res.second);
    const { id: _id, a: _a, b: _b, ...base } = l1;
    if (res.bevel) doc.add({ ...base, a: res.bevel[0], b: res.bevel[1] });
    if (res.arc) {
      if (l1.kind === 'detailLine') doc.add({ kind: 'detailArc', viewId: l1.viewId, ...res.arc, style: l1.style });
      else {
        // Other kinds of lines follow the arc in short straight pieces.
        const n = Math.max(4, Math.ceil(((res.arc.a1 - res.arc.a0) * 180) / Math.PI / 10));
        for (let k = 0; k < n; k++) {
          const a = res.arc.a0 + ((res.arc.a1 - res.arc.a0) * k) / n;
          const b = res.arc.a0 + ((res.arc.a1 - res.arc.a0) * (k + 1)) / n;
          doc.add({ ...base, a: [res.arc.c[0] + Math.cos(a) * res.arc.r, res.arc.c[1] + Math.sin(a) * res.arc.r], b: [res.arc.c[0] + Math.cos(b) * res.arc.r, res.arc.c[1] + Math.sin(b) * res.arc.r] });
        }
      }
    }
    return { polygons: 0, lines: 2 };
  }
  return { error: 'Select slabs, ceilings, fills or other polygons, or exactly two lines.' };
}
