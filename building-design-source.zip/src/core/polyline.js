/**
 * Polyline (Archicad's Polyline tool): one 2D element made of straight and
 * arc segments. An arc is stored as the bulge of its segment, the tangent of
 * a quarter of its sweep (positive counter-clockwise), as in DXF.
 *
 *   polyline { kind: 'polyline', viewId, path: [[x, y], ...], bulges: [b, ...], closed, style }
 */
import { add, sub, scale, perp, norm, dist, dot, angleOf, mid, rotate } from './geom.js';

const cross = (a, b) => a[0] * b[1] - a[1] * b[0];

/** Segments in order: [{ a, b, bulge, i }]; a closed polyline has one more, back to its start. */
export function polylineSegments(el) {
  const pts = el.path || [];
  const out = [];
  const n = el.closed ? pts.length : pts.length - 1;
  for (let i = 0; i < n; i++) out.push({ a: pts[i], b: pts[(i + 1) % pts.length], bulge: +el.bulges?.[i] || 0, i });
  return out;
}

/** The arc of a segment with a bulge: { c, r, a0, sweep }. */
export function arcOfBulge(a, b, bulge) {
  const sweep = 4 * Math.atan(bulge);
  const L = dist(a, b);
  const off = L / 2 / Math.tan(sweep / 2);
  const c = add(mid(a, b), scale(perp(norm(sub(b, a))), off));
  return { c, r: Math.abs(L / 2 / Math.sin(sweep / 2)), a0: angleOf(sub(a, c)), sweep };
}

/** Points along a polyline, arcs in steps of about stepDeg degrees. A closed one ends where it began. */
export function polylinePoints(el, stepDeg = 7.5) {
  const out = [];
  for (const s of polylineSegments(el)) {
    if (!out.length) out.push(s.a);
    if (Math.abs(s.bulge) < 1e-9 || dist(s.a, s.b) < 1e-9) {
      out.push(s.b);
      continue;
    }
    const { c, r, a0, sweep } = arcOfBulge(s.a, s.b, s.bulge);
    const n = Math.max(2, Math.ceil(Math.abs(sweep) / ((stepDeg * Math.PI) / 180)));
    for (let k = 1; k < n; k++) out.push(add(c, scale([Math.cos(a0 + (sweep * k) / n), Math.sin(a0 + (sweep * k) / n)], r)));
    out.push(s.b);
  }
  return out;
}

/** Length along the polyline. */
export function polylineLength(el) {
  return polylineSegments(el).reduce((t, s) => {
    if (Math.abs(s.bulge) < 1e-9) return t + dist(s.a, s.b);
    const { r, sweep } = arcOfBulge(s.a, s.b, s.bulge);
    return t + r * Math.abs(sweep);
  }, 0);
}

/** Bulge of the arc from p to q leaving p along the direction `tangent`. */
export function tangentBulge(p, tangent, q) {
  const d = sub(q, p);
  const sweep = 2 * Math.atan2(cross(tangent, d), dot(tangent, d));
  return Math.tan(sweep / 4);
}

/** Direction of travel at the end of a segment. */
export function endTangent(a, b, bulge = 0) {
  return rotate(norm(sub(b, a)), 2 * Math.atan(bulge));
}

/** Bulge of the segment a-b whose arc passes through the point p level with its middle. */
export function bulgeThrough(a, b, p) {
  const L = dist(a, b);
  if (L < 1e-9) return 0;
  const h = dot(sub(p, mid(a, b)), perp(norm(sub(b, a))));
  const bulge = (-2 * h) / L;
  return Math.abs(bulge) < 0.02 ? 0 : bulge;
}

/** The point halfway along a segment. */
export function segmentMiddle(s) {
  if (Math.abs(s.bulge) < 1e-9) return mid(s.a, s.b);
  const { c, r, a0, sweep } = arcOfBulge(s.a, s.b, s.bulge);
  return add(c, scale([Math.cos(a0 + sweep / 2), Math.sin(a0 + sweep / 2)], r));
}

/** The polyline as separate detail lines and arcs. */
export function explodePolyline(el) {
  return polylineSegments(el).map((s) => {
    if (Math.abs(s.bulge) < 1e-9) return { kind: 'detailLine', viewId: el.viewId, a: s.a, b: s.b, style: el.style };
    const { c, r, a0, sweep } = arcOfBulge(s.a, s.b, s.bulge);
    return { kind: 'detailArc', viewId: el.viewId, c, r, a0: sweep > 0 ? a0 : a0 + sweep, a1: sweep > 0 ? a0 + sweep : a0, style: el.style };
  });
}

/**
 * Detail lines and arcs joined end to end into { path, bulges, closed } (ends
 * within tol meet), or null when they do not make one chain.
 */
export function chainToPolyline(items, tol = 1) {
  const left = items.map((e) => {
    if (e.kind === 'detailArc') {
      const a0 = e.a0 ?? 0;
      const a1 = e.a1 ?? Math.PI * 2;
      const P = (t) => add(e.c, scale([Math.cos(t), Math.sin(t)], e.r));
      return { a: P(a0), b: P(a1), bulge: Math.tan((a1 - a0) / 4) };
    }
    return { a: e.a, b: e.b, bulge: 0 };
  });
  if (!left.length) return null;
  const first = left.shift();
  const chain = [first];
  while (left.length) {
    const end = chain.at(-1).b;
    const start = chain[0].a;
    let i = left.findIndex((s) => dist(s.a, end) <= tol || dist(s.b, end) <= tol);
    if (i >= 0) {
      const [s] = left.splice(i, 1);
      chain.push(dist(s.a, end) <= tol ? s : { a: s.b, b: s.a, bulge: -s.bulge });
      continue;
    }
    i = left.findIndex((s) => dist(s.a, start) <= tol || dist(s.b, start) <= tol);
    if (i < 0) return null;
    const [s] = left.splice(i, 1);
    chain.unshift(dist(s.b, start) <= tol ? s : { a: s.b, b: s.a, bulge: -s.bulge });
  }
  const closed = chain.length > 1 && dist(chain[0].a, chain.at(-1).b) <= tol;
  const path = chain.map((s) => s.a);
  if (!closed) path.push(chain.at(-1).b);
  const bulges = chain.map((s) => s.bulge);
  if (!closed) bulges.push(0);
  return { path, bulges, closed };
}
