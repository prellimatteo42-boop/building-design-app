/**
 * SiteMaker's Create New Site (reimplemented from the user guide's options):
 * a terrain mesh from survey points with
 *   - precision: points thinned to one per grid cell (fine keeps them all);
 *   - outline: the points' convex hull, their bounding rectangle grown by a
 *     margin (corners at the height of the nearest point), or a lot polygon;
 *   - ground thickness and contour interval.
 * And Mesh from an outline: a contour whose corners have their own heights,
 * with ridges inside it (topo.boundary, topo.ridges).
 */
import { topoBoundary } from './topo.js';

export const PRECISIONS = [
  { value: 'fine', label: 'Fine (every point)', cell: 0 },
  { value: 'medium', label: 'Medium (one point per metre)', cell: 1000 },
  { value: 'coarse', label: 'Coarse (one point per 3 m)', cell: 3000 },
];
export const OUTLINES = [
  { value: 'hull', label: 'Around the points' },
  { value: 'rect', label: 'Rectangle round the points, with a margin' },
  { value: 'lot', label: 'The selected lot outline' },
];

/** One point per grid cell: the one nearest the cell's centre. */
export function thinPoints(points, cell) {
  if (!(cell > 0)) return points.slice();
  const best = new Map();
  for (const p of points) {
    const i = Math.floor(p[0] / cell);
    const j = Math.floor(p[1] / cell);
    const k = `${i},${j}`;
    const cx = (i + 0.5) * cell;
    const cy = (j + 0.5) * cell;
    const d = Math.hypot(p[0] - cx, p[1] - cy);
    const cur = best.get(k);
    if (!cur || d < cur.d) best.set(k, { p, d });
  }
  return [...best.values()].map((x) => x.p);
}

/** Height of the point nearest to a plan point. */
export function nearestHeight(points, q) {
  let best = null;
  for (const p of points) {
    const d = Math.hypot(p[0] - q[0], p[1] - q[1]);
    if (!best || d < best.d) best = { d, z: p[2] };
  }
  return best ? best.z : 0;
}

/**
 * The terrain (topo fields, not added) for Create New Site. opts: { precision, outline, margin (mm),
 * lot ([[x, y]] for 'lot'), thickness, contour, materialId }.
 */
export function newSite(points, opts = {}) {
  const cell = PRECISIONS.find((p) => p.value === opts.precision)?.cell ?? 0;
  const pts = thinPoints(points, cell);
  if (pts.length < 3) return null;
  const site = { kind: 'topo', points: pts, thickness: +opts.thickness || 1000, contour: +opts.contour || 500, materialId: opts.materialId || 'mat-earth' };
  if (opts.outline === 'rect') {
    const m = Math.max(0, +opts.margin || 0);
    const xs = pts.map((p) => p[0]);
    const ys = pts.map((p) => p[1]);
    const box = [
      [Math.min(...xs) - m, Math.min(...ys) - m],
      [Math.max(...xs) + m, Math.min(...ys) - m],
      [Math.max(...xs) + m, Math.max(...ys) + m],
      [Math.min(...xs) - m, Math.max(...ys) + m],
    ];
    site.boundary = box.map((q) => [q[0], q[1], nearestHeight(pts, q)]);
  } else if (opts.outline === 'lot' && opts.lot?.length >= 3) {
    site.boundary = opts.lot.map((q) => [q[0], q[1], q[2] ?? nearestHeight(pts, q)]);
  }
  return site;
}

/**
 * Mesh from an outline: { kind: 'topo', boundary, ridges, points: [] } with the corner heights given
 * (default z) and ridges as [[x, y, z]] lines.
 */
export function meshFromOutline(outline, { z = 0, heights = [], ridges = [], thickness = 500, contour = 250, materialId = 'mat-earth' } = {}) {
  if (!outline || outline.length < 3) return null;
  return {
    kind: 'topo',
    points: [],
    boundary: outline.map((p, i) => [p[0], p[1], Number.isFinite(+heights[i]) && heights[i] !== '' && heights[i] != null ? +heights[i] : z]),
    ridges: ridges.filter((r) => r?.length >= 2).map((r) => r.map((p) => [p[0], p[1], p[2] ?? z])),
    thickness,
    contour,
    materialId,
  };
}

/** The plan outline of a terrain (re-exported for the dialogs). */
export const siteOutline = topoBoundary;
