/**
 * Create Openings From Selection (Archicad's, for MEP): where a duct, pipe,
 * cable tray or conduit passes through a wall or a slab, an opening with a
 * clearance all round. Walls get a rectangular wall opening sized to the
 * run's section as it crosses the wall at an angle; slabs get a hole (round
 * for round runs) of the run's footprint at the slab. The openings remember
 * their run (`mepRunId`), so running the command again replaces them.
 */
import { sub, cross, dot, norm, len, pointInPolygon, arcPoints } from './geom.js';
import { wallAxis, verticalExtent, levelElevation } from './model.js';
import { typeThickness } from './catalog.js';
import { MEP_KINDS, mepSize } from './mep.js';
import { runEnds } from './mepnet.js';

const lerp3 = (a, b, s) => [a[0] + (b[0] - a[0]) * s, a[1] + (b[1] - a[1]) * s, a[2] + (b[2] - a[2]) * s];

/** Wall openings for one run: [{ hostId, t, width, height, sill, mepRunId }]. */
export function wallCrossings(doc, run, clearance = 50) {
  const [A, B] = runEnds(doc, run);
  const pd = [B[0] - A[0], B[1] - A[1]];
  const pl = len(pd);
  if (pl < 1) return [];
  const d = [pd[0] / pl, pd[1] / pl];
  const size = mepSize(doc, run);
  const out = [];
  for (const w of doc.all('wall')) {
    if (w.arc || doc.get(w.typeId)?.curtain) continue;
    const ax = wallAxis(doc, w);
    if (ax.length < 1) continue;
    const sin = cross(d, ax.dir);
    if (Math.abs(sin) < 0.2) continue;
    // Run point p = A + s·pd crosses the wall axis at u along it.
    const r = sub(ax.a, A);
    const s = cross(r, ax.dir) / cross(pd, ax.dir);
    const u = cross(r, pd) / cross(pd, ax.dir);
    if (s < 0 || s > 1 || u < 0 || u > ax.length) continue;
    // The run must actually go through the thickness (not end inside the wall).
    const ds = ax.half / Math.abs(sin) / pl;
    if (s - ds < -1e-6 || s + ds > 1 + 1e-6) continue;
    const z = lerp3(A, B, s)[2];
    const { base, top } = verticalExtent(doc, w);
    const H = size.h + 2 * clearance;
    if (z - H / 2 < base - 1 || z + H / 2 > top + 1) continue;
    const cos = Math.abs(dot(d, ax.dir));
    const W = size.w / Math.abs(sin) + (2 * ax.half * cos) / Math.abs(sin) + 2 * clearance;
    out.push({ hostId: w.id, t: Math.round(u), width: Math.round(W), height: Math.round(H), sill: Math.round(z - H / 2 - base), mepRunId: run.id });
  }
  return out;
}

/** The rectangle (or circle) a run cuts through a slab between heights z0 < z1, or null. */
function slabHole(doc, run, z0, z1, clearance) {
  const [A, B] = runEnds(doc, run);
  const zlo = Math.min(A[2], B[2]);
  const zhi = Math.max(A[2], B[2]);
  if (zlo > z0 || zhi < z1) return null; // must pass right through
  const dz = B[2] - A[2];
  if (Math.abs(dz) < 1) return null;
  const s = ((z0 + z1) / 2 - A[2]) / dz;
  const c = lerp3(A, B, s);
  const size = mepSize(doc, run);
  const pd = [B[0] - A[0], B[1] - A[1]];
  const pl = len(pd);
  const L3 = Math.hypot(pl, dz);
  const sinPhi = Math.abs(dz) / L3; // 1 for a riser
  const cotPhi = pl / Math.abs(dz);
  const dir = pl > 1 ? norm(pd) : [1, 0];
  const n = [-dir[1], dir[0]];
  const along = Math.min(5000, size.h / sinPhi + (z1 - z0) * cotPhi) / 2 + clearance;
  const across = size.w / 2 + clearance;
  if (size.round && pl < 1) return { c: [c[0], c[1]], poly: arcPoints([c[0], c[1]], across, 0, Math.PI * 2, Math.PI / 12).slice(0, -1) };
  const P = (x, y) => [Math.round(c[0] + dir[0] * x + n[0] * y), Math.round(c[1] + dir[1] * x + n[1] * y)];
  return { c: [c[0], c[1]], poly: [P(-along, -across), P(along, -across), P(along, across), P(-along, across)] };
}

/** Slab holes for one run: [{ slabId, poly, mepRunId }]. */
export function slabCrossings(doc, run, clearance = 50) {
  const out = [];
  for (const f of doc.all('floor')) {
    if (!f.boundary || f.boundary.length < 3) continue;
    const top = levelElevation(doc, f.levelId) + (+f.offset || 0);
    const th = Math.max(1, typeThickness(doc.get(f.typeId)) || 300);
    const h = slabHole(doc, run, top - th, top, clearance);
    if (!h || !pointInPolygon(h.c, f.boundary)) continue;
    out.push({ slabId: f.id, poly: h.poly, mepRunId: run.id });
  }
  return out;
}

/**
 * Create (or recreate) the openings of runs (inside a transaction). ids: the runs (default: every run).
 * Returns { walls, slabs } counts.
 */
export function createMepOpenings(doc, ids = null, { clearance = 50 } = {}) {
  const runs = MEP_KINDS.flatMap((k) => doc.all(k)).filter((r) => !ids || ids.includes(r.id));
  const runIds = new Set(runs.map((r) => r.id));
  removeMepOpenings(doc, runIds);
  let walls = 0;
  let slabs = 0;
  for (const r of runs) {
    for (const o of wallCrossings(doc, r, clearance)) (doc.add({ kind: 'opening', ...o }), walls++);
    for (const s of slabCrossings(doc, r, clearance)) {
      const f = doc.get(s.slabId);
      doc.update(f.id, { holes: [...(f.holes || []), s.poly], mepHoles: [...(f.mepHoles || []), { runId: r.id, poly: s.poly }] });
      slabs++;
    }
  }
  return { walls, slabs };
}

/** Remove the openings made for runs (a Set of run ids; default: all of them). Returns the number removed. */
export function removeMepOpenings(doc, runIds = null) {
  let n = 0;
  for (const o of doc.all('opening')) if (o.mepRunId && (!runIds || runIds.has(o.mepRunId))) (doc.remove(o.id), n++);
  for (const f of doc.all('floor')) {
    if (!f.mepHoles?.length) continue;
    const gone = f.mepHoles.filter((m) => !runIds || runIds.has(m.runId));
    if (!gone.length) continue;
    const keys = new Set(gone.map((m) => JSON.stringify(m.poly)));
    doc.update(f.id, { holes: (f.holes || []).filter((hl) => !keys.has(JSON.stringify(hl))), mepHoles: f.mepHoles.filter((m) => !gone.includes(m)) });
    n += gone.length;
  }
  return n;
}
