/**
 * Library parts of another language's library (a Russian project's "Обеденный Стул 03 27") matched to the parts of
 * the libraries installed here ("Dining Chair 03"). The project keeps only their names: their GUIDs differ from one
 * language to another and the placed objects keep their parameters without names. So the names are matched by
 * meaning: what was matched before (kept in this browser), the built-in table, then the AI over the catalogue of
 * the installed libraries. Objects that came in as boxes of their size then get the matched part.
 */
import { internationalPart } from './aclib.js';

const STORE = 'bd.partMatches';

/** Matches made before: { local name: { name, pack } | null (none) }. */
export function savedMatches() {
  try {
    const v = JSON.parse(localStorage.getItem(STORE) || '{}');
    return v && typeof v === 'object' ? v : {};
  } catch {
    return {};
  }
}

export function saveMatches(m) {
  try {
    localStorage.setItem(STORE, JSON.stringify({ ...savedMatches(), ...m }));
  } catch {
    /* private window: matched again next time */
  }
}

/** The installed part a local name is known to be: matched before, else the built-in table. undefined: not known yet. */
export function knownMatch(name, saved = savedMatches()) {
  if (!name) return null;
  if (Object.prototype.hasOwnProperty.call(saved, name)) return saved[name];
  return internationalPart(name) || undefined;
}

/** The question for the AI: the names to match (with their size) and the catalogue ({ package: [names] }). */
export function matchRequest(missing, catalog) {
  const system =
    'You match Archicad library part names across languages. A project made with a localised Archicad library names its objects in that language, often with the Archicad version as a last number (25, 26, 27). For each name, choose the object of the installed catalogue that is the same thing (same purpose, same kind of shape); a near one of the same kind (another dining chair, another single bed) is better than none. Use null only when nothing of that kind is there. Answer with JSON only: an object whose keys are the given names exactly and whose values are {"name": catalogue name, "pack": its package} or null.';
  const lines = missing.map((m) => JSON.stringify(m.size ? { name: m.name, size_mm: m.size.map((v) => Math.round(v)) } : { name: m.name }));
  const cat = Object.entries(catalog)
    .map(([pack, names]) => `## ${pack}\n${names.join('; ')}`)
    .join('\n');
  return { system, message: `Names to match (the keys of your answer are these names, without the size):\n${lines.join('\n')}\n\nInstalled catalogue, by package:\n${cat}` };
}

/** The AI's answer as matches, keeping only catalogue names (in their own spelling and package). */
export function parseMatches(text, missing, catalog) {
  const s = String(text || '');
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a < 0 || b <= a) return {};
  let raw;
  try {
    raw = JSON.parse(s.slice(a, b + 1));
  } catch {
    return {};
  }
  const where = new Map();
  for (const [pack, names] of Object.entries(catalog)) for (const n of names) if (!where.has(n.toLowerCase())) where.set(n.toLowerCase(), { name: n, pack });
  // Keys as given, or with the size the question showed after them.
  const answers = new Map();
  for (const [k, v] of Object.entries(raw)) answers.set(k.replace(/\s*\([^()]*\bmm\)\s*$/i, '').trim(), v);
  const out = {};
  for (const m of missing) {
    if (!answers.has(m.name)) continue;
    const v = answers.get(m.name);
    const hit = v && typeof v === 'object' && typeof v.name === 'string' ? where.get(v.name.toLowerCase()) : typeof v === 'string' ? where.get(v.toLowerCase()) : null;
    out[m.name] = hit || null;
  }
  return out;
}

/** The objects that came in as boxes for a part no library had: { name: { size, ids } }. */
export function unmatchedObjects(doc) {
  const out = new Map();
  for (const el of doc.all('component')) {
    if (!el.acOrigin) continue;
    const t = doc.get(el.typeId);
    if (!t?.acPart) continue;
    if (!out.has(t.acPart)) out.set(t.acPart, { name: t.acPart, size: el.acSize?.[2] ? null : [el.acSize?.[0] || t.width, el.acSize?.[1] || t.depth], ids: [] });
    out.get(t.acPart).ids.push(el.id);
  }
  return out;
}

/**
 * Gives the boxes their matched parts: typeFor(local name) → a type spec or null. Placed at their origin (boxes stand
 * on their centre), with A and B of their size (or its ratio to the new part). Returns how many objects changed.
 */
export function swapMatchedParts(doc, typeFor) {
  const made = new Map();
  let n = 0;
  const boxes = new Set();
  for (const el of doc.all('component')) {
    if (!el.acOrigin) continue;
    const box = doc.get(el.typeId);
    if (!box?.acPart) continue;
    if (!made.has(box.acPart)) {
      let t = null;
      try {
        const spec = typeFor(box.acPart);
        t = spec ? doc.add(spec) : null;
      } catch {
        t = null;
      }
      made.set(box.acPart, t);
    }
    const type = made.get(box.acPart);
    if (!type) continue;
    const [w, d, ratio] = el.acSize || [];
    const sized = (v, own) => (v ? (ratio ? (v / 1000) * own : v) : null);
    const own = {};
    const W = sized(w, +type.width || 600);
    const D = sized(d, +type.depth || 600);
    if (W) own.A = Math.round(W * 10) / 10;
    if (D) own.B = Math.round(D * 10) / 10;
    doc.update(el.id, { typeId: type.id, at: el.acOrigin, acOrigin: undefined, acSize: undefined, ...(type.family === 'gdl' && Object.keys(own).length ? { gdlValues: own } : {}) });
    boxes.add(box.id);
    n++;
  }
  // Box types nothing uses any more.
  const used = new Set(doc.all('component').map((c) => c.typeId));
  for (const id of boxes) if (!used.has(id)) doc.remove(id);
  return n;
}
