/**
 * Finishes for elements: a colour or a picture laid on an element as a paint material, so a wall, a floor or a
 * library object takes the look asked for without changing its type.
 */
import { colorOf } from './furniture.js';

const hex2 = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0');

/** #rrggbb from a colour name or #rrggbb; null when it is neither. */
export function hexOf(color) {
  const c = colorOf(color, null);
  return c ? `#${c.map(hex2).join('')}` : null;
}

/** The paint material of a plain colour, made the first time it is asked for. Inside a transaction. */
export function paintOf(doc, hex) {
  const key = hex.toLowerCase();
  const found = doc.all('material').find((m) => m.paint === true && !m.surface?.image && String(m.color).toLowerCase() === key);
  return found || doc.add({ kind: 'material', name: `Paint ${key}`, color: key, opacity: 1, paint: true });
}

/**
 * A colour no other material of the project has: textures are found by the colour of the faces,
 * so a textured material must not share its colour with anything else.
 */
export function freeColor(doc, hex) {
  const used = doc.all('material').map((m) => String(m.color).toLowerCase());
  const n = parseInt(hex.slice(1), 16);
  for (let k = 0; k < 64; k++) {
    const blue = Math.max(0, Math.min(255, (n & 255) + (k % 2 ? -3 : 3) * Math.ceil(k / 2)));
    const c = `#${((n & 0xffff00) | blue).toString(16).padStart(6, '0')}`;
    if (!used.some((u) => near(u, c))) return c;
  }
  return hex;
}

const near = (a, b) => {
  if (!/^#[0-9a-f]{6}/.test(a)) return false;
  return [1, 3, 5].every((i) => Math.abs(parseInt(a.slice(i, i + 2), 16) - parseInt(b.slice(i, i + 2), 16)) <= 2);
};

/** A material showing a picture: surface { image, w, h, angle, origin, flipU } in mm. Inside a transaction. */
export function pictureMaterial(doc, name, hex, surface) {
  return doc.add({ kind: 'material', name, color: freeColor(doc, hex), opacity: 1, paint: true, surface });
}

/** A small repeatable random sequence. */
function random(seed) {
  let s = seed >>> 0 || 1;
  return () => {
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    s >>>= 0;
    return s / 4294967296;
  };
}

/**
 * Where the boards of a floor lie on one tile of size w x h (mm): rows along x, the joints staggered, and every board
 * wrapped round the tile's end so the tile repeats. [{ row, x0, x1, tone }], x in 0..w; a board past w continues at 0.
 */
export function boardLayout(w, rows, seed = 7) {
  const rnd = random(seed);
  const out = [];
  for (let row = 0; row < rows; row++) {
    let x = rnd() * w;
    const start = x;
    while (x < start + w - 1) {
      const len = Math.min(start + w - x, w * (0.35 + rnd() * 0.3));
      out.push({ row, x0: x, x1: x + len, tone: (rnd() - 0.5) * 0.16 });
      x += len;
    }
  }
  return out;
}

/** A tiling picture of wooden boards in a base colour: { image (data URL), w, h } in mm. In the browser only. */
export function planksPicture(hex, { plank = 180, length = 2400 } = {}) {
  const rows = Math.max(4, Math.round(1800 / plank));
  const px = 1024;
  const cv = document.createElement('canvas');
  cv.width = cv.height = px;
  const g = cv.getContext('2d');
  const [R, G, B] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
  const rowH = px / rows;
  const rnd = random(11);
  const scale = px / length;
  for (const b of boardLayout(length, rows)) {
    const k = 1 + b.tone;
    g.fillStyle = `rgb(${Math.min(255, R * k)}, ${Math.min(255, G * k)}, ${Math.min(255, B * k)})`;
    const y = b.row * rowH;
    const x0 = b.x0 * scale;
    const x1 = b.x1 * scale;
    for (const shift of [0, -px]) {
      g.fillRect(x0 + shift, y, x1 - x0, rowH);
      g.fillStyle = 'rgba(40, 25, 12, 0.55)';
      g.fillRect(x0 + shift, y, 1.2, rowH);
      g.fillStyle = `rgb(${Math.min(255, R * k)}, ${Math.min(255, G * k)}, ${Math.min(255, B * k)})`;
    }
  }
  // The grain: thin, wandering lines along the boards.
  for (let i = 0; i < rows * 26; i++) {
    const y = rnd() * px;
    g.strokeStyle = `rgba(50, 30, 14, ${0.04 + rnd() * 0.1})`;
    g.lineWidth = 0.6 + rnd();
    g.beginPath();
    const wob = rnd() * 3;
    const ph = rnd() * 6.28;
    for (let x = 0; x <= px; x += 32) g.lineTo(x, y + Math.sin(x / 90 + ph) * wob);
    g.stroke();
  }
  // The joints between the rows, drawn last so that the grain does not cross them.
  g.fillStyle = 'rgba(40, 25, 12, 0.6)';
  for (let row = 0; row < rows; row++) g.fillRect(0, row * rowH, px, 1.4);
  return { image: cv.toDataURL('image/jpeg', 0.86), w: length, h: plank * rows };
}
