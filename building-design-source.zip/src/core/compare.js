/**
 * Model Compare, as in Archicad: what differs between two versions of a
 * project, element by element: new, deleted and modified (with what
 * changed: geometry, type, or other properties), grouped by category.
 */
import { categoryOf, KIND_LABEL, CATEGORIES } from './catalog.js';
import { isView, VIEW_LABEL } from './doc.js';

/** Colours of changes in the views: new green, modified orange. */
export const COMPARE_COLORS = { added: [34, 160, 80], modified: [236, 130, 20] };

const GEOMETRY = new Set(['a', 'b', 'at', 'boundary', 'holes', 'path', 'points', 't', 'c', 'r', 'a0', 'a1', 'arc', 'height', 'baseOffset', 'topOffset', 'offset', 'rotation', 'levelId', 'topLevelId', 'elevation', 'width', 'sill', 'w', 'h', 'tris', 'heights', 'slopes', 'edges', 'hostId', 'flipped', 'flipFacing', 'flipHand', 'upperOffset']);

function same(x, y) {
  if (x === y) return true;
  if (typeof x === 'number' && typeof y === 'number') return Math.abs(x - y) < 1e-6;
  return JSON.stringify(x) === JSON.stringify(y);
}

/** What kind of difference a changed field is. */
export function fieldClass(key) {
  if (key === 'typeId') return 'type';
  return GEOMETRY.has(key) ? 'geometry' : 'properties';
}

/** The group an item is listed under. */
function groupOf(doc, el) {
  if (isView(el)) return 'Views and Sheets';
  if (el.kind.endsWith('Type') || ['material', 'fillType', 'layer', 'layerCombo', 'profile', 'classSystem', 'zoneCategory', 'masterLayout', 'projectParam', 'propertyGroup', 'lineStyle', 'phase'].includes(el.kind)) return 'Types and Settings';
  const cat = categoryOf(el, doc);
  return CATEGORIES.find((c) => c.id === cat)?.label || null;
}

/** A label for an item in the results. */
export function compareLabel(doc, el) {
  const type = doc.get(el.typeId);
  const base = KIND_LABEL[el.kind] || VIEW_LABEL[el.kind] || el.kind;
  const name = el.name || el.number || el.mark || type?.name || '';
  return name ? `${base}: ${name}` : base;
}

/**
 * Differences from `base` to `cur` (two Docs): { added, removed, modified }
 * lists of { id, group, label, classes?: Set, fields?: [key] }, skipping the
 * project record, issues and things that are not elements or settings.
 */
export function compareDocs(base, cur) {
  const out = { added: [], removed: [], modified: [] };
  const skip = (el) => !el || el.id === 'project' || el.kind === 'issue' || el.kind === 'selectionSet';
  for (const el of cur.items.values()) {
    if (skip(el)) continue;
    const group = groupOf(cur, el);
    if (!group) continue;
    const old = base.get(el.id);
    if (!old) {
      out.added.push({ id: el.id, group, label: compareLabel(cur, el) });
      continue;
    }
    const keys = new Set([...Object.keys(old), ...Object.keys(el)]);
    const fields = [...keys].filter((k) => k !== 'id' && !same(old[k], el[k]));
    if (fields.length) out.modified.push({ id: el.id, group, label: compareLabel(cur, el), fields, classes: new Set(fields.map(fieldClass)) });
  }
  for (const el of base.items.values()) {
    if (skip(el) || cur.has(el.id)) continue;
    const group = groupOf(base, el);
    if (group) out.removed.push({ id: el.id, group, label: compareLabel(base, el), el });
  }
  const order = (a, b) => a.group.localeCompare(b.group) || a.label.localeCompare(b.label, undefined, { numeric: true });
  out.added.sort(order);
  out.removed.sort(order);
  out.modified.sort(order);
  return out;
}

/** Counts per group: [{ group, added, removed, modified }]. */
const short = (v) => {
  if (v === undefined || v === null) return '';
  if (typeof v === 'number') return String(Math.round(v * 100) / 100);
  if (typeof v === 'string') return v;
  const s = JSON.stringify(v);
  return s.length > 60 ? `${s.slice(0, 57)}...` : s;
};

/** Each changed parameter of the modified elements: [{ id, group, label, field, from, to }]. */
export function changeDetails(diff, base, cur) {
  const out = [];
  for (const m of diff.modified) {
    const old = base.get(m.id);
    const now = cur.get(m.id);
    for (const f of m.fields) out.push({ id: m.id, group: m.group, label: m.label, field: f, from: short(old?.[f]), to: short(now?.[f]) });
  }
  return out;
}

export function compareSummary(diff) {
  const m = new Map();
  for (const k of ['added', 'removed', 'modified'])
    for (const d of diff[k]) {
      if (!m.has(d.group)) m.set(d.group, { group: d.group, added: 0, removed: 0, modified: 0 });
      m.get(d.group)[k]++;
    }
  return [...m.values()].sort((a, b) => a.group.localeCompare(b.group));
}
