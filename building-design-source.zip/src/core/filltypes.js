/**
 * Fill types, as in Archicad's Fill Types: vectorial hatches made of
 * families of parallel lines (each with an angle, spacing, shift between
 * lines and an optional dash pattern, like CAD hatch patterns), sized in
 * the model (brick courses, tiles) or on paper (fine diagonals). They draw
 * as real lines, so exports carry them too.
 *
 *   fillType { kind: 'fillType', name, scale: 'model' | 'paper', orientation: 'element' | 'project',
 *              families: [{ angle (deg), origin: [x, y], shift, spacing, dashes: [on, -off, ...] }] }
 */

const F = (angle, spacing, shift = 0, dashes = [], origin = [0, 0]) => ({ angle, origin, shift, spacing, dashes });

/** Fill types of a new project. */
export function defaultFillTypes() {
  return [
    { id: 'ft-brick', kind: 'fillType', name: 'Brick Running Bond', scale: 'model', families: [F(0, 75), F(90, 112.5, 75, [75, -75])] },
    { id: 'ft-block', kind: 'fillType', name: 'Concrete Block 400 x 200', scale: 'model', families: [F(0, 200), F(90, 400, 200, [200, -200])] },
    { id: 'ft-tile', kind: 'fillType', name: 'Tiles 300 x 300', scale: 'model', families: [F(0, 300), F(90, 300)] },
    { id: 'ft-plank', kind: 'fillType', name: 'Floor Boards', scale: 'model', families: [F(0, 140), F(90, 140, 600, [1200, -1200])] },
    { id: 'ft-stone', kind: 'fillType', name: 'Stone Ashlar', scale: 'model', families: [F(0, 300), F(90, 300, 250, [300, -300])] },
    { id: 'ft-fine-diag', kind: 'fillType', name: 'Fine Diagonal (paper)', scale: 'paper', families: [F(45, 1)] },
    { id: 'ft-cross-paper', kind: 'fillType', name: 'Crosshatch (paper)', scale: 'paper', families: [F(45, 2), F(135, 2)] },
    { id: 'ft-dashed-diag', kind: 'fillType', name: 'Dashed Diagonal (paper)', scale: 'paper', families: [F(45, 2, 0, [2, -1])] },
  ];
}

const MAX_SEGMENTS = 20000;

/**
 * The hatch lines of a fill type over a polygon with holes, sizes times k
 * (the view scale for paper fill types): [[a, b], ...]. frame { angle (deg),
 * origin } turns and places the pattern, for fills that follow an element.
 */
export function hatchSegments(poly, holes, fillType, k = 1, frame = null) {
  const loops = [poly, ...(holes || [])].filter((l) => l && l.length >= 3);
  if (!loops.length) return [];
  const out = [];
  for (const fam of fillType?.families || []) {
    const sp = Math.abs(+fam.spacing || 0) * k;
    if (!(sp > 0)) continue;
    const fa = ((+frame?.angle || 0) * Math.PI) / 180;
    const a = ((+fam.angle || 0) * Math.PI) / 180 + fa;
    const u = [Math.cos(a), Math.sin(a)];
    const n = [-u[1], u[0]];
    const lo0 = [(fam.origin?.[0] || 0) * k, (fam.origin?.[1] || 0) * k];
    const fo = frame?.origin || [0, 0];
    const o = [fo[0] + lo0[0] * Math.cos(fa) - lo0[1] * Math.sin(fa), fo[1] + lo0[0] * Math.sin(fa) + lo0[1] * Math.cos(fa)];
    const shift = (+fam.shift || 0) * k;
    const dashes = (fam.dashes || []).map((d) => +d * k).filter((d) => d !== 0);
    const period = dashes.reduce((s, d) => s + Math.abs(d), 0);
    let lo = Infinity;
    let hi = -Infinity;
    for (const l of loops)
      for (const p of l) {
        const d = (p[0] - o[0]) * n[0] + (p[1] - o[1]) * n[1];
        lo = Math.min(lo, d);
        hi = Math.max(hi, d);
      }
    const i0 = Math.ceil(lo / sp);
    const i1 = Math.floor(hi / sp);
    if (i1 - i0 > MAX_SEGMENTS) continue;
    for (let i = i0; i <= i1; i++) {
      const base = [o[0] + n[0] * sp * i + u[0] * shift * i, o[1] + n[1] * sp * i + u[1] * shift * i];
      // Where the line crosses the outline: parameters along u.
      const ts = [];
      for (const l of loops)
        for (let j = 0; j < l.length; j++) {
          const p = l[j];
          const q = l[(j + 1) % l.length];
          const dp = (p[0] - base[0]) * n[0] + (p[1] - base[1]) * n[1];
          const dq = (q[0] - base[0]) * n[0] + (q[1] - base[1]) * n[1];
          if ((dp > 0) === (dq > 0) || dp === dq) continue;
          const s = dp / (dp - dq);
          const x = [p[0] + (q[0] - p[0]) * s, p[1] + (q[1] - p[1]) * s];
          ts.push((x[0] - base[0]) * u[0] + (x[1] - base[1]) * u[1]);
        }
      ts.sort((x, y) => x - y);
      for (let j = 0; j + 1 < ts.length; j += 2) {
        const ta = ts[j];
        const tb = ts[j + 1];
        const P = (t) => [base[0] + u[0] * t, base[1] + u[1] * t];
        if (!period) {
          out.push([P(ta), P(tb)]);
        } else {
          let t = Math.floor(ta / period) * period;
          while (t < tb && out.length < MAX_SEGMENTS) {
            for (const d of dashes) {
              const len = Math.abs(d);
              if (d > 0) {
                const s0 = Math.max(t, ta);
                const s1 = Math.min(t + len, tb);
                if (s1 - s0 > 1e-6) out.push([P(s0), P(s1)]);
              }
              t += len;
              if (t >= tb) break;
            }
          }
        }
        if (out.length >= MAX_SEGMENTS) return out;
      }
    }
  }
  return out;
}

/** Dashes as text ("75 -25") and back. */
export function dashText(d) {
  return (d || []).join(' ');
}

export function parseDashes(text) {
  return String(text || '')
    .split(/[\s,;]+/)
    .map(Number)
    .filter((v) => Number.isFinite(v) && v !== 0);
}
