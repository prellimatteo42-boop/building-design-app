/**
 * Surfaces from Archicad's Surface Catalog (Library Developer: Import All
 * Surfaces from Catalog, Redefine All Surfaces from Catalog, Save All
 * Surfaces as GSM). Each catalog part's master script defines a material
 * (DEFINE MATERIAL with its colour, transparency and texture); running it
 * gives this app's materials: colour, opacity and the texture's file and
 * size (the images themselves stay in the user's library).
 */
import { runGDL } from './gdl.js';
import { partVars } from './aclib.js';

const hex = (rgb) => `#${rgb.map((v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0')).join('')}`;
const unhex = (c) => {
  const n = parseInt(String(c || '#808080').slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => v / 255);
};

/** Catalog parts of a library: those in a "Surface Catalog" folder (or every part when none is). */
export function catalogParts(lib) {
  const all = [...lib.parts.values()];
  const cat = all.filter((e) => /surface catalog/i.test(e.path));
  return cat.length ? cat : all;
}

/** The surfaces a part's master script defines: [{ name, color, opacity, texture: { file, w, h } | null, source }]. */
export function partSurfaces(lib, e) {
  const part = lib.get(e.name);
  const master = part?.lp?.scripts?.master;
  if (!master || !/define\s+material/i.test(master)) return [];
  let r;
  try {
    r = runGDL(master, { vars: partVars(part.lp), lenient: true, mode: '3d', maxSteps: 2e5, macros: () => null });
  } catch {
    return [];
  }
  const out = [];
  for (const def of r.defs.materials.values()) {
    if (!def.color) continue;
    const tex = def.tex && typeof def.tex.pic === 'string' ? { file: def.tex.pic, w: Math.round(def.tex.w * 1000), h: Math.round(def.tex.h * 1000) } : null;
    out.push({ name: def.name, color: hex(def.color), opacity: Math.round(def.alpha * 100) / 100, texture: tex, source: part.path });
  }
  return out;
}

/** Every surface of the catalog, by name (the first part to define a name wins). */
export function catalogSurfaces(lib) {
  const seen = new Map();
  for (const e of catalogParts(lib)) for (const s of partSurfaces(lib, e)) if (!seen.has(s.name.toLowerCase())) seen.set(s.name.toLowerCase(), s);
  return [...seen.values()].sort((a, b) => a.name.localeCompare(b.name));
}

const materialPatch = (s) => ({ color: s.color, opacity: s.opacity, catalogSource: s.source, ...(s.texture ? { texture: s.texture } : {}) });

/**
 * Add the catalog's surfaces as materials (inside a transaction). Existing materials of the same name are left as
 * they are, or with `redefine` set to the catalog's definition (and none added). Returns { added, redefined }.
 */
export function importSurfaces(doc, surfaces, { redefine = false } = {}) {
  const have = new Map(doc.all('material').map((m) => [String(m.name).toLowerCase(), m]));
  let added = 0;
  let redefined = 0;
  for (const s of surfaces) {
    const m = have.get(s.name.toLowerCase());
    if (m) {
      if (redefine) (doc.update(m.id, materialPatch(s)), redefined++);
    } else if (!redefine) {
      doc.add({ kind: 'material', name: s.name, cut: 'none', ...materialPatch(s) });
      added++;
    }
  }
  return { added, redefined };
}

const q = (s) => `"${String(s).replace(/"/g, "'")}"`;

/** A material as a surface library part's master script (DEFINE MATERIAL type 20, with its texture when it has one). */
export function surfaceScript(m) {
  const [r, g, b] = unhex(m.color);
  const f = (v) => (+v).toFixed(4);
  const tr = 1 - (m.opacity ?? 1);
  const lines = [`! Surface ${m.name}, saved by Building Design`];
  if (m.texture?.file) lines.push(`define texture "Texture1" ${q(m.texture.file)}, ${f((m.texture.w || 1000) / 1000)}, ${f((m.texture.h || 1000) / 1000)}, 256, 0`);
  lines.push(
    `define material ${q(m.name)} 20,`,
    `\t${f(r)}, ${f(g)}, ${f(b)},`,
    `\t0.7, 0.8, ${f(m.surface?.reflection ?? 0.2)}, ${f(tr)}, ${Math.round((m.surface?.shininess ?? 0.1) * 100)}, 1,`,
    `\t0.8, 0.8, 0.8,`,
    `\t0, 0, 0, 0,`,
    `\t0, 0, ${m.texture?.file ? 'ind(texture, "Texture1")' : 0}`,
  );
  return `${lines.join('\n')}\n`;
}
