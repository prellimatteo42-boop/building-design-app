/**
 * Run Parameter Script (Archicad's Library Developer command): a library part's parameter script (VLSC, with its
 * master script) run with the values of a placed object. What it sets with PARAMETERS becomes the object's own
 * values, and a value its VALUES lists do not allow moves to the first allowed one. Lengths are metres in GDL and
 * millimetres in the app.
 */
import { runGDL } from './gdl.js';
import { gdlVars } from './gdlobject.js';

const toApp = (p, v) => (p?.kind === 'length' && typeof v === 'number' ? Math.round(v * 1000 * 1000) / 1000 : v);

/** { values: { NAME: [allowed] }, changed: { name: value } } for a type and an object's own values. */
export function runParamScript(type, own = {}) {
  const g = type?.gdl;
  if (!g?.paramScript) return null;
  const vars = gdlVars(type, own);
  const before = { ...vars };
  const r = runGDL(`${g.master || ''}\n${g.paramScript}`, { vars, mode: 'params', lenient: true, maxSteps: 1e6 });
  const params = new Map((g.params || []).map((p) => [String(p.name).toUpperCase(), p]));
  // NAME → allowed values (null when open: a range or custom values).
  const values = {};
  for (const o of r.paramOut || []) {
    if (o.cmd !== 'VALUES' || !o.args.length) continue;
    const name = String(o.args[0]).toUpperCase();
    // A RANGE or CUSTOM entry (marked by the parser) leaves the list open: nothing to snap to then.
    const list = o.args.slice(1);
    values[name] = list.some((v) => typeof v === 'string' && v.startsWith('\u0000')) ? null : list.filter((v) => typeof v === 'number' || typeof v === 'string');
  }
  const changed = {};
  for (const [NAME, p] of params) {
    let v = r.vars?.[NAME];
    const allowed = values[NAME];
    if (allowed?.length && !allowed.some((x) => (typeof x === 'number' && typeof v === 'number' ? Math.abs(x - v) < 1e-9 : x === v))) v = allowed[0];
    const same = typeof v === 'number' && typeof before[NAME] === 'number' ? Math.abs(v - before[NAME]) < 1e-7 : JSON.stringify(v) === JSON.stringify(before[NAME]);
    if (v !== undefined && !same) changed[p.name] = toApp(p, v);
  }
  return { values, changed };
}

/** Run the parameter scripts of placed objects (inside a transaction). Returns how many changed. */
export function runParamScripts(doc, ids = null) {
  let n = 0;
  for (const el of doc.all('component', 'door', 'window')) {
    if (ids && !ids.includes(el.id)) continue;
    const type = doc.get(el.typeId);
    const res = runParamScript(type, el.gdlValues || {});
    if (!res || !Object.keys(res.changed).length) continue;
    doc.update(el.id, { gdlValues: { ...(el.gdlValues || {}), ...res.changed } });
    n++;
  }
  return n;
}
