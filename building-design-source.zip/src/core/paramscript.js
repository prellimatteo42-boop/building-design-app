/**
 * Run Parameter Script (Archicad's Library Developer command): a library part's parameter script (VLSC, with its
 * master script) run with the values of a placed object. What it sets with PARAMETERS becomes the object's own
 * values, and a value its VALUES lists do not allow moves to the first allowed one. Lengths are metres in GDL and
 * millimetres in the app.
 */
import { runGDL } from './gdl.js';
import { gdlVars } from './gdlobject.js';

const toApp = (p, v) => (p?.kind === 'length' && typeof v === 'number' ? Math.round(v * 1000 * 1000) / 1000 : v);

/**
 * { values: { NAME: [allowed] }, changed: { name: value } } for a type and an object's own values. `modified` names
 * the parameter just changed (GLOB_MODPAR_NAME): many library parts size themselves from it (a kitchen cabinet's
 * width follows A only when A is the one changed). An object with no parameter script of its own still runs its
 * master script, whose macros may have theirs.
 */
export function runParamScript(type, own = {}, { modified = '' } = {}) {
  const g = type?.gdl;
  if (!g?.paramScript && !g?.master) return null;
  const vars = gdlVars(type, own);
  const before = { ...vars };
  vars.GLOB_MODPAR_NAME = modified;
  // The macros it calls run their own parameter scripts (carried with the type).
  const macros = (n) => g.macros?.[String(n).toLowerCase()] || null;
  const r = runGDL(`${g.master || ''}\n${g.paramScript || ''}`, { vars, mode: 'params', lenient: true, maxSteps: 3e6, macros });
  const params = new Map((g.params || []).map((p) => [String(p.name).toUpperCase(), p]));
  // NAME → allowed values (null when open: a range or custom values).
  const values = {};
  for (const o of r.paramOut || []) {
    if (o.cmd !== 'VALUES' || !o.args.length) continue;
    const name = String(o.args[0]).toUpperCase();
    // A RANGE or CUSTOM entry (marked by the parser) leaves the list open: nothing to snap to then.
    const list = o.args.slice(1);
    values[name] = list.some((v) => typeof v === 'string' && v.startsWith('\u0000')) ? null : list.filter((v) => typeof v === 'number' || typeof v === 'string');
  }
  const changed = {};
  for (const [NAME, p] of params) {
    // What PARAMETERS set (here or in a macro called with PARAMETERS ALL), else the variable as the script left it.
    let v = r.paramSets?.has(NAME) ? r.paramSets.get(NAME) : r.paramSets?.has(p.name) ? r.paramSets.get(p.name) : r.vars?.[NAME];
    const allowed = values[NAME];
    if (allowed?.length && !allowed.some((x) => (typeof x === 'number' && typeof v === 'number' ? Math.abs(x - v) < 1e-9 : x === v))) v = allowed[0];
    const same = typeof v === 'number' && typeof before[NAME] === 'number' ? Math.abs(v - before[NAME]) < 1e-7 : JSON.stringify(v) === JSON.stringify(before[NAME]);
    if (v !== undefined && !same) changed[p.name] = toApp(p, v);
  }
  return { values, changed };
}

/** Run the parameter scripts of placed objects (inside a transaction). Returns how many changed. */
export function runParamScripts(doc, ids = null) {
  let n = 0;
  for (const el of doc.all('component', 'door', 'window')) {
    if (ids && !ids.includes(el.id)) continue;
    const type = doc.get(el.typeId);
    const res = runParamScript(type, el.gdlValues || {});
    if (!res || !Object.keys(res.changed).length) continue;
    doc.update(el.id, { gdlValues: { ...(el.gdlValues || {}), ...res.changed } });
    n++;
  }
  return n;
}

/**
 * New values for a placed object, as Archicad applies them: each changed parameter in turn, with the parameter script
 * run for it (A, B and ZZYZX first), so that the parameters that follow it (a cabinet's carcass width, a lamp's shade)
 * follow. Returns the object's own values afterwards.
 */
export function applyGdlChange(type, own = {}, changes = {}) {
  let out = { ...own, ...changes };
  const keys = Object.keys(changes).sort((a, b) => ['A', 'B', 'ZZYZX'].indexOf(b) - ['A', 'B', 'ZZYZX'].indexOf(a));
  for (const k of keys) {
    let res = null;
    try { res = runParamScript(type, out, { modified: k }); } catch { res = null; }
    if (res?.changed) out = { ...out, ...res.changed, [k]: res.changed[k] ?? changes[k] };
  }
  return out;
}
