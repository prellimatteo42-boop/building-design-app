/**
 * Close rooms at their doorways: for a room whose stamp is not in an area closed by walls and room separators, room
 * separators across the doorways round it (between facing wall ends a door's width apart, or from a wall's end straight
 * on to the wall across), the fewest that close it. Doorways are found on the walls as built (their outlines), and a
 * room is closed when the floor flooded from its stamp no longer reaches the edge of the level's drawing.
 */
import { FloorGrid } from './flood.js';
import { dist } from './geom.js';

const DOOR_MIN = 450;
const DOOR_MAX = 1400;

const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1];

function nearestOnSegment(p, a, b) {
  const d = sub(b, a);
  const L2 = dot(d, d) || 1;
  const t = Math.max(0, Math.min(1, dot(sub(p, a), d) / L2));
  return [a[0] + d[0] * t, a[1] + d[1] * t];
}

function band(a, b, half) {
  const L = dist(a, b) || 1;
  const n = [(-(b[1] - a[1]) / L) * half, ((b[0] - a[0]) / L) * half];
  return [[a[0] + n[0], a[1] + n[1]], [b[0] + n[0], b[1] + n[1]], [b[0] - n[0], b[1] - n[1]], [a[0] - n[0], a[1] - n[1]]];
}

/**
 * Candidate separators across doorways: walls = [{ a, b, thickness }] (axes). Each is { a, b } from a wall's end:
 * to a facing end of another wall, or straight on along its wall to the face of the wall it meets.
 */
export function doorwayCandidates(walls) {
  const out = [];
  const ends = walls.flatMap((w) => [{ p: w.a, o: w.b, w }, { p: w.b, o: w.a, w }]);
  const inBand = (q, w) => dist(q, nearestOnSegment(q, w.a, w.b)) <= w.thickness / 2 + 1;
  const key = (a, b) => [a, b].map((p) => p.map((v) => Math.round(v / 20)).join(',')).sort().join('|');
  const seen = new Set();
  const push = (a, b) => {
    const k = key(a, b);
    if (seen.has(k)) return;
    seen.add(k);
    out.push({ a: a.map(Math.round), b: b.map(Math.round) });
  };
  for (let i = 0; i < ends.length; i++) {
    const e = ends[i];
    // Straight on: from the end along its wall to the first wall across, a door's width away.
    const L = dist(e.p, e.o) || 1;
    const u = [(e.p[0] - e.o[0]) / L, (e.p[1] - e.o[1]) / L];
    for (let t = 50; t <= DOOR_MAX; t += 20) {
      const q = [e.p[0] + u[0] * t, e.p[1] + u[1] * t];
      const hit = walls.find((o) => o !== e.w && inBand(q, o));
      if (!hit) continue;
      if (t >= DOOR_MIN) push(e.p, q);
      break;
    }
    // Facing ends of other walls, the jambs of a doorway.
    for (let j = i + 1; j < ends.length; j++) {
      const f = ends[j];
      if (f.w === e.w) continue;
      const d = dist(e.p, f.p);
      if (d >= DOOR_MIN && d <= DOOR_MAX && !walls.some((o) => o !== e.w && o !== f.w && inBand([(e.p[0] + f.p[0]) / 2, (e.p[1] + f.p[1]) / 2], o))) push(e.p, f.p);
    }
  }
  return out;
}

/**
 * The separators that close a room whose stamp is at `at`: barriers = polygons (walls, columns) and segments (room
 * separators already there); candidates as doorwayCandidates gives. Returns the chosen candidates, or null when they
 * cannot close it.
 */
export function closingSeparators(at, barriers, segments, candidates, { cell = 20, others = [] } = {}) {
  const pts = [...barriers.flat(), ...segments.flatMap((s) => [s.a, s.b]), at];
  const box = { x0: Math.min(...pts.map((p) => p[0])) - 500, y0: Math.min(...pts.map((p) => p[1])) - 500, x1: Math.max(...pts.map((p) => p[0])) + 500, y1: Math.max(...pts.map((p) => p[1])) + 500 };
  const span = Math.max(box.x1 - box.x0, box.y1 - box.y0);
  const size = Math.max(cell, span / 2500);
  const base = new FloorGrid(box, size);
  base.paint(barriers);
  base.paint(segments.map((s) => band(s.a, s.b, size)));
  const cellOf = (p) => Math.floor((p[1] - base.y0) / base.cell) * base.w + Math.floor((p[0] - base.x0) / base.cell);
  const otherCells = others.map(cellOf);
  // Closed: the floor round the stamp does not reach the edge, nor another room's stamp.
  const closed = (list) => {
    const g = base.clone();
    g.paint(list.map((s) => band(s.a, s.b, size)));
    const cells = g.flood(at);
    if (!cells) return false;
    const set = new Set(cells);
    return !otherCells.some((c) => set.has(c));
  };
  if (closed([])) return [];
  // Nearest first, until the floor round the stamp stops reaching the edge.
  const ranked = candidates.map((c) => ({ c, d: dist(at, nearestOnSegment(at, c.a, c.b)) })).sort((x, y) => x.d - y.d).map((x) => x.c);
  const chosen = [];
  for (const c of ranked) {
    chosen.push(c);
    if (closed(chosen)) break;
  }
  if (!closed(chosen)) return null;
  // Then the fewest: each one the room stays closed without is left out.
  for (let i = chosen.length - 1; i >= 0; i--) {
    const without = chosen.filter((_, k) => k !== i);
    if (closed(without)) chosen.splice(i, 1);
  }
  return chosen;
}
