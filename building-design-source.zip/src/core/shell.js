/**
 * Shells, as in Archicad: thin curved bodies. Shapes:
 *   - vault: a circular arch of `span` and `rise` across the axis a-b,
 *     extruded along it (a barrel vault);
 *   - dome: a spherical cap of base `radius` and `rise` over `at`;
 *   - extruded: a free profile [[u, z]] (across the axis a-b) extruded along it;
 *   - revolved: a profile [[r, z]] turned about the vertical axis at `at` by `sweep` degrees;
 *   - ruled: straight lines from a profile at a to another at b (profile, profileEnd).
 * Profiles come from presets (arch, parabola, gable, wave) of `span` and `rise` unless given.
 * The shape describes the outer surface; `thickness` goes inward. The base
 * sits at the level plus baseOffset.
 */
import { MeshBuilder } from './mesh.js';
import { sub, add, scale, norm, perp, len, arcPoints } from './geom.js';
import { levelElevation } from './model.js';

const STEPS = 24;

/** Radius and centre height (relative to the base) of the arc through a chord and a rise. */
function arch(span, rise) {
  const h = Math.max(1, Math.min(rise, span * 2));
  const R = (span * span) / 4 / (2 * h) + h / 2;
  return { R, zc: h - R, a0: Math.asin(Math.min(1, span / 2 / R)) };
}

function base(doc, el) {
  return levelElevation(doc, el.levelId) + (+el.baseOffset || 0);
}

/** Footprint in plan (for picking and drawing). */
export function shellOutline(el) {
  if (el.shape === 'revolved') {
    const r = Math.max(...(el.profile || shellProfile(el, 'revolved')).map((q) => q[0]), 100);
    const sw = Math.min(360, Math.abs(+el.sweep || 360));
    const pts = arcPoints(el.at || [0, 0], r, 0, (sw * Math.PI) / 180, Math.PI / 24);
    return sw >= 359.9 ? pts.slice(0, -1) : [el.at || [0, 0], ...pts];
  }
  if (el.shape === 'extruded' || el.shape === 'ruled') {
    const us = [...(el.profile || shellProfile(el)), ...(el.profileEnd || [])].map((q) => q[0]);
    const d = norm(sub(el.b, el.a));
    const n = perp(d);
    const u0 = Math.min(...us);
    const u1 = Math.max(...us);
    return [add(el.a, scale(n, u0)), add(el.b, scale(n, u0)), add(el.b, scale(n, u1)), add(el.a, scale(n, u1))];
  }
  if (el.shape === 'dome') return arcPoints(el.at || [0, 0], +el.radius || 3000, 0, Math.PI * 2, Math.PI / 24).slice(0, -1);
  const d = norm(sub(el.b, el.a));
  const n = perp(d);
  const w = (+el.span || 4000) / 2;
  return [add(el.a, scale(n, -w)), add(el.b, scale(n, -w)), add(el.b, scale(n, w)), add(el.a, scale(n, w))];
}

export const PROFILE_PRESETS = [
  { value: 'arch', label: 'Arch' },
  { value: 'parabola', label: 'Parabola' },
  { value: 'gable', label: 'Gable' },
  { value: 'wave', label: 'Wave' },
];

/** A profile from a preset: [[u, z]] across -span/2..span/2 (for revolved: [[r, z]] from the rim to the axis). */
export function shellProfile(el, shape = el.shape, preset = el.preset || 'arch', n = STEPS) {
  const span = +el.span || (shape === 'revolved' ? 2 * (+el.radius || 3000) : 4000);
  const rise = +el.rise || 1500;
  const out = [];
  for (let i = 0; i <= n; i++) {
    const x = -1 + (2 * i) / n;
    let z;
    if (preset === 'parabola') z = rise * (1 - x * x);
    else if (preset === 'gable') z = rise * (1 - Math.abs(x));
    else if (preset === 'wave') z = (rise / 2) * (1 + Math.cos(Math.PI * 2 * x));
    else {
      const { R, zc } = arch(span, rise);
      z = zc + Math.sqrt(Math.max(0, R * R - (x * span) ** 2 / 4));
    }
    out.push([(x * span) / 2, Math.max(0, z)]);
  }
  // Revolved: the half from the rim (r = span/2) to the axis.
  return shape === 'revolved' ? out.filter((q) => q[0] >= -1e-9).reverse().map(([u, z]) => [Math.abs(u), z]) : out;
}

/** Resample a profile to n + 1 points equally spaced along its length. */
function resample(pts, n) {
  const L = [0];
  for (let i = 1; i < pts.length; i++) L.push(L[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const total = L.at(-1) || 1;
  const out = [];
  for (let k = 0, i = 1; k <= n; k++) {
    const s = (total * k) / n;
    while (i < pts.length - 1 && L[i] < s) i++;
    const f = (s - L[i - 1]) / (L[i] - L[i - 1] || 1);
    out.push([pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * f, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * f]);
  }
  return out;
}

/** The outer surface of a free-form shell as a grid of 3D points: rows[i][j]; { rows, closed } (closed across j). */
export function shellGrid(el, z0 = 0) {
  if (el.shape === 'revolved') {
    const prof = el.profile || shellProfile(el, 'revolved');
    const c = el.at || [0, 0];
    const sw = Math.min(360, Math.abs(+el.sweep || 360));
    const k = Math.max(8, Math.ceil(sw / 7.5));
    const closed = sw >= 359.9;
    const rows = prof.map(([r, z]) => {
      const row = [];
      for (let j = 0; j < (closed ? k : k + 1); j++) {
        const t = ((sw * Math.PI) / 180) * (j / k);
        row.push([c[0] + r * Math.cos(t), c[1] + r * Math.sin(t), z0 + z]);
      }
      return row;
    });
    return { rows, closed };
  }
  const d = norm(sub(el.b, el.a));
  const n = perp(d);
  const L = len(sub(el.b, el.a));
  const P = (s, [u, z]) => {
    const q = add(add(el.a, scale(d, s)), scale(n, u));
    return [q[0], q[1], z0 + z];
  };
  const p0 = el.profile || shellProfile(el);
  if (el.shape === 'ruled') {
    const p1 = el.profileEnd || shellProfile({ ...el, rise: (+el.rise || 1500) / 2 }, 'extruded', el.presetEnd || el.preset);
    const m = Math.max(p0.length, p1.length, 12) - 1;
    const a = resample(p0, m);
    const b = resample(p1, m);
    return { rows: a.map((q, i) => [P(0, q), P(L, b[i])]), closed: false };
  }
  return { rows: p0.map((q) => [P(0, q), P(L, q)]), closed: false };
}

/** A grid surface with a thickness t below it (along each point's normal, away from the sky). */
function buildGridSolid(b, { rows, closed }, t, color) {
  const I = rows.length;
  const J = rows[0]?.length || 0;
  if (I < 2 || J < 2) return;
  const at = (i, j) => rows[Math.max(0, Math.min(I - 1, i))][closed ? (j + J) % J : Math.max(0, Math.min(J - 1, j))];
  const normal = (i, j) => {
    const du = sub3(at(i + 1, j), at(i - 1, j));
    const dv = sub3(at(i, j + 1), at(i, j - 1));
    let nn = cross3(du, dv);
    const l = Math.hypot(...nn) || 1;
    nn = nn.map((v) => v / l);
    return nn[2] < 0 ? nn.map((v) => -v) : nn;
  };
  const inner = rows.map((row, i) => row.map((p, j) => {
    const nn = normal(i, j);
    return [p[0] - nn[0] * t, p[1] - nn[1] * t, p[2] - nn[2] * t];
  }));
  const jMax = closed ? J : J - 1;
  for (let i = 0; i < I - 1; i++)
    for (let j = 0; j < jMax; j++) {
      const j1 = (j + 1) % J;
      b.quad(rows[i][j], rows[i + 1][j], rows[i + 1][j1], rows[i][j1], color);
      b.quad(inner[i][j1], inner[i + 1][j1], inner[i + 1][j], inner[i][j], color);
    }
  // Edges round the open sides: the first and last rows, and (open across) the first and last columns.
  const side = (pts, ins, flip) => {
    for (let k = 0; k + 1 < pts.length; k++) {
      if (flip) b.quad(pts[k], ins[k], ins[k + 1], pts[k + 1], color);
      else b.quad(pts[k + 1], ins[k + 1], ins[k], pts[k], color);
      b.edge(pts[k], pts[k + 1]);
      b.edge(ins[k], ins[k + 1]);
    }
  };
  const wrap = (row) => (closed ? [...row, row[0]] : row);
  side(wrap(rows[0]), wrap(inner[0]), false);
  side(wrap(rows[I - 1]), wrap(inner[I - 1]), true);
  if (!closed) {
    side(rows.map((r) => r[0]), inner.map((r) => r[0]), true);
    side(rows.map((r) => r[J - 1]), inner.map((r) => r[J - 1]), false);
  }
}
const sub3 = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];

export function buildShell(ctx, el, color) {
  const z0 = base(ctx.doc, el);
  const t = Math.max(1, +el.thickness || 150);
  const rise = +el.rise || 1500;
  const b = new MeshBuilder();
  if (el.shape === 'extruded' || el.shape === 'revolved' || el.shape === 'ruled') {
    buildGridSolid(b, shellGrid(el, z0), t, color);
    return b.build();
  }
  if (el.shape === 'dome') {
    const r = +el.radius || 3000;
    const { R, zc, a0 } = arch(2 * r, rise);
    const c = el.at || [0, 0];
    // Rings from the top (phi = 0) down to the base (phi = a0); inner surface t below.
    const P = (rad, phi, th) => [c[0] + rad * Math.sin(phi) * Math.cos(th), c[1] + rad * Math.sin(phi) * Math.sin(th), z0 + zc + rad * Math.cos(phi)];
    const rings = Math.max(4, Math.ceil(a0 / (Math.PI / 36)));
    const seg = STEPS * 2;
    for (let i = 0; i < rings; i++) {
      const p0 = (a0 * i) / rings;
      const p1 = (a0 * (i + 1)) / rings;
      for (let j = 0; j < seg; j++) {
        const t0 = (2 * Math.PI * j) / seg;
        const t1 = (2 * Math.PI * (j + 1)) / seg;
        b.quad(P(R, p0, t0), P(R, p1, t0), P(R, p1, t1), P(R, p0, t1), color);
        b.quad(P(R - t, p0, t1), P(R - t, p1, t1), P(R - t, p1, t0), P(R - t, p0, t0), color);
      }
    }
    for (let j = 0; j < seg; j++) {
      const t0 = (2 * Math.PI * j) / seg;
      const t1 = (2 * Math.PI * (j + 1)) / seg;
      b.quad(P(R - t, a0, t0), P(R - t, a0, t1), P(R, a0, t1), P(R, a0, t0), color);
      b.edge(P(R, a0, t0), P(R, a0, t1));
      b.edge(P(R - t, a0, t0), P(R - t, a0, t1));
    }
    return b.build();
  }
  // Vault: arcs across the axis at both ends, joined along it.
  const span = +el.span || 4000;
  const { R, zc, a0 } = arch(span, rise);
  const d = norm(sub(el.b, el.a));
  const n = perp(d);
  const L = len(sub(el.b, el.a));
  const P = (u, rad, ang) => {
    const q = add(add(el.a, scale(d, u)), scale(n, rad * Math.sin(ang)));
    return [q[0], q[1], z0 + zc + rad * Math.cos(ang)];
  };
  const angs = [];
  for (let i = 0; i <= STEPS; i++) angs.push(-a0 + (2 * a0 * i) / STEPS);
  for (let i = 0; i < STEPS; i++) {
    const [g0, g1] = [angs[i], angs[i + 1]];
    b.quad(P(0, R, g1), P(0, R, g0), P(L, R, g0), P(L, R, g1), color);
    b.quad(P(0, R - t, g0), P(0, R - t, g1), P(L, R - t, g1), P(L, R - t, g0), color);
    // End faces (the arch's section) at both ends.
    b.quad(P(0, R, g0), P(0, R, g1), P(0, R - t, g1), P(0, R - t, g0), color);
    b.quad(P(L, R, g1), P(L, R, g0), P(L, R - t, g0), P(L, R - t, g1), color);
    for (const u of [0, L]) {
      b.edge(P(u, R, g0), P(u, R, g1));
      b.edge(P(u, R - t, g0), P(u, R - t, g1));
    }
  }
  // Springing faces along both sides.
  for (const g of [-a0, a0]) {
    const s = g < 0 ? -1 : 1;
    if (s < 0) b.quad(P(0, R - t, g), P(L, R - t, g), P(L, R, g), P(0, R, g), color);
    else b.quad(P(0, R, g), P(L, R, g), P(L, R - t, g), P(0, R - t, g), color);
    b.edge(P(0, R, g), P(L, R, g));
    b.edge(P(0, R - t, g), P(L, R - t, g));
    b.edge(P(0, R, g), P(0, R - t, g));
    b.edge(P(L, R, g), P(L, R - t, g));
  }
  return b.build();
}
