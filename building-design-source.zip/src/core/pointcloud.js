/**
 * Point clouds (Archicad's Import Point Clouds): survey points shown in the
 * 3D view as a reference to model over. Text clouds (XYZ, PTS, TXT, CSV:
 * x y z [intensity] [r g b]) and LAS 1.0–1.4 (point formats 0–3, 6–8 with
 * their scale and offset) are read; the points are kept packed in the
 * element (positions as float32 in mm relative to the cloud's origin,
 * colours as bytes), thinned to at most `max` points.
 *
 *   pointCloud { name, at: [x, y, z] (mm), count, xyz (base64 float32), rgb (base64 uint8) }
 */

const b64 = (bytes) => {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
};
const unb64 = (str) => {
  const s = atob(str);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
};

/** Read a text cloud: { xyz: Float32Array (units as in the file × scale), rgb: Uint8Array|null, count }. */
export function readTextCloud(text, { scale = 1000, max = 400000 } = {}) {
  const lines = text.split(/\r?\n/);
  const pts = [];
  let colour = false;
  for (const raw of lines) {
    const t = raw.trim();
    if (!t || t.startsWith('#') || t.startsWith('//')) continue;
    const v = t.split(/[\s,;]+/).map(Number);
    // PTS files start with the point count on a line of its own.
    if (v.length < 3 || v.slice(0, 3).some((x) => !Number.isFinite(x))) continue;
    const c = v.length >= 6 ? v.slice(v.length - 3) : null;
    if (c && c.every((x) => Number.isInteger(x) && x >= 0 && x <= 255)) colour = true;
    pts.push([v[0] * scale, v[1] * scale, v[2] * scale, c, v.length === 4 || v.length === 7 ? v[3] : null]);
  }
  return pack(pts, colour, max);
}

/** Read a LAS file (ArrayBuffer): the same shape as readTextCloud. LAS coordinates are usually metres. */
export function readLAS(buffer, { scale = 1000, max = 400000 } = {}) {
  const dv = new DataView(buffer);
  if (String.fromCharCode(dv.getUint8(0), dv.getUint8(1), dv.getUint8(2), dv.getUint8(3)) !== 'LASF') throw new Error('Not a LAS file.');
  const minor = dv.getUint8(25);
  const offsetToPoints = dv.getUint32(96, true);
  const format = dv.getUint8(104) & 0x3f;
  const recLen = dv.getUint16(105, true);
  let n = dv.getUint32(107, true);
  if (!n && minor >= 4 && dv.byteLength > 255) n = Number(dv.getBigUint64(247, true));
  const sx = dv.getFloat64(131, true);
  const sy = dv.getFloat64(139, true);
  const sz = dv.getFloat64(147, true);
  const ox = dv.getFloat64(155, true);
  const oy = dv.getFloat64(163, true);
  const oz = dv.getFloat64(171, true);
  // Where the colour sits in each record: formats 2, 3 after the fixed part (and GPS time for 3); 7, 8 at 30.
  const rgbAt = { 2: 20, 3: 28, 5: 28, 7: 30, 8: 30 }[format] ?? null;
  const step = Math.max(1, Math.ceil(n / max));
  const pts = [];
  for (let i = 0; i < n; i += step) {
    const o = offsetToPoints + i * recLen;
    if (o + 12 > dv.byteLength) break;
    const x = dv.getInt32(o, true) * sx + ox;
    const y = dv.getInt32(o + 4, true) * sy + oy;
    const z = dv.getInt32(o + 8, true) * sz + oz;
    const inten = dv.getUint16(o + 12, true);
    let c = null;
    if (rgbAt != null && o + rgbAt + 6 <= dv.byteLength) {
      const r = dv.getUint16(o + rgbAt, true);
      const g = dv.getUint16(o + rgbAt + 2, true);
      const b = dv.getUint16(o + rgbAt + 4, true);
      // 16-bit colours (most files) or 8-bit ones.
      const k = Math.max(r, g, b) > 255 ? 1 / 257 : 1;
      c = [Math.round(r * k), Math.round(g * k), Math.round(b * k)];
    }
    pts.push([x * scale, y * scale, z * scale, c, inten]);
  }
  return pack(pts, rgbAt != null, Infinity);
}

function pack(pts, colour, max) {
  const step = Math.max(1, Math.ceil(pts.length / max));
  const keep = step === 1 ? pts : pts.filter((_, i) => i % step === 0);
  const count = keep.length;
  const xyz = new Float32Array(count * 3);
  const rgb = new Uint8Array(count * 3);
  // Shades of grey from the intensity when there is no colour.
  const ints = keep.map((p) => p[4]).filter((v) => v != null);
  const imax = ints.length ? Math.max(...ints.slice(0, 50000), 1) : 1;
  let x0 = Infinity;
  let y0 = Infinity;
  let z0 = Infinity;
  for (const p of keep) (x0 = Math.min(x0, p[0])), (y0 = Math.min(y0, p[1])), (z0 = Math.min(z0, p[2]));
  keep.forEach((p, i) => {
    xyz[i * 3] = p[0] - x0;
    xyz[i * 3 + 1] = p[1] - y0;
    xyz[i * 3 + 2] = p[2] - z0;
    const c = colour && p[3] ? p[3] : p[4] != null ? Array(3).fill(Math.round(60 + (p[4] / imax) * 180)) : [120, 130, 140];
    rgb.set(c, i * 3);
  });
  return { xyz, rgb, count, origin: count ? [x0, y0, z0] : [0, 0, 0] };
}

/** The element (not added) for a read cloud. originAt: where its lowest corner goes (default: where it was). */
export function cloudElement(name, cloud, levelId, { relativeTo = null } = {}) {
  const o = relativeTo ? [cloud.origin[0] - relativeTo[0], cloud.origin[1] - relativeTo[1], cloud.origin[2] - relativeTo[2]] : cloud.origin;
  return { kind: 'pointCloud', name, levelId, at: o.map((v) => Math.round(v)), count: cloud.count, xyz: b64(new Uint8Array(cloud.xyz.buffer)), rgb: b64(cloud.rgb) };
}

const cache = new WeakMap();

/** The points of an element, unpacked (cached per element version): { xyz: Float32Array, rgb: Uint8Array }. */
export function cloudPoints(el) {
  let c = cache.get(el);
  if (!c) {
    const bytes = unb64(el.xyz || '');
    c = { xyz: new Float32Array(bytes.buffer, 0, Math.floor(bytes.length / 4)), rgb: unb64(el.rgb || '') };
    cache.set(el, c);
  }
  return c;
}

/** Bounding box of a cloud element in model mm. */
export function cloudBounds(el) {
  const { xyz } = cloudPoints(el);
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < xyz.length; i += 3) for (let k = 0; k < 3; k++) (min[k] = Math.min(min[k], xyz[i + k])), (max[k] = Math.max(max[k], xyz[i + k]));
  const a = el.at || [0, 0, 0];
  return { min: min.map((v, k) => v + a[k]), max: max.map((v, k) => v + a[k]) };
}
