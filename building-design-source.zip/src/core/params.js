/**
 * Project parameters (custom properties, as in Archicad's Property Manager):
 * fields the user adds to categories of elements, such as "Fire Rating" on
 * walls and doors. Their values live in each element's `params` map and show
 * in the properties palette, schedules, filters and IFC property sets.
 *
 *   projectParam  { name, type, categories: [categoryId], classes: [{ system, code }], group, description,
 *                   options: [string] (option sets), default, expression, result }
 *   propertyGroup { name, description }  a group of the user's own
 *
 * Types: text, number, length (mm), area (mm²), volume (mm³), angle (degrees),
 * bool, choice (one option of a set), multi (several options of a set),
 * list (a list of texts) and expression. A property is available for an
 * element when its category is ticked or its classification item (or an
 * item above it) is one of `classes`.
 *
 * An expression parameter is not stored on elements: its value is computed
 * from the element's other fields (expressions.js), as in Archicad's
 * expression-defined properties.
 */
import { categoryOf } from './catalog.js';
import { parseExpression, evaluate, ExpressionError } from './expressions.js';
import { autotextFields } from './autotext.js';
import { formatLength, formatArea, formatVolume } from './units.js';
import { classOf } from './classify.js';

export const PARAM_TYPES = [
  { value: 'text', label: 'Text' },
  { value: 'number', label: 'Number' },
  { value: 'length', label: 'Length' },
  { value: 'area', label: 'Area' },
  { value: 'volume', label: 'Volume' },
  { value: 'angle', label: 'Angle' },
  { value: 'bool', label: 'Yes/No' },
  { value: 'choice', label: 'Option Set' },
  { value: 'multi', label: 'Option Set (multiple choice)' },
  { value: 'list', label: 'Text List' },
  { value: 'expression', label: 'Expression' },
];

const NUMERIC = new Set(['number', 'length', 'area', 'volume', 'angle']);
const LISTS = new Set(['multi', 'list']);

export const RESULT_TYPES = [
  { value: 'number', label: 'Number' },
  { value: 'length', label: 'Length (m)' },
  { value: 'area', label: 'Area (m²)' },
  { value: 'volume', label: 'Volume (m³)' },
  { value: 'text', label: 'Text' },
  { value: 'bool', label: 'Yes/No' },
];

// Expressions see lengths in metres, areas in m² and volumes in m³.
const SI = { length: 1e-3, area: 1e-6, volume: 1e-9 };

/**
 * The value of an expression parameter for an element, in stored units
 * (mm, mm², mm³): { value } or { error }. ctx: { doc, scene }.
 */
export function expressionValue(ctx, el, p, seen = new Set()) {
  if (seen.has(p.id)) return { error: 'The expression refers to itself' };
  let tree;
  try {
    tree = parseExpression(p.expression);
  } catch (err) {
    return { error: err.message };
  }
  const doc = ctx.doc;
  const fields = autotextFields(el);
  const params = paramsForElement(doc, el);
  const field = (name) => {
    const k = name.toLowerCase();
    const q = params.find((x) => x.name.toLowerCase() === k);
    if (q) {
      if (q.type === 'expression') {
        const r = expressionValue(ctx, el, q, new Set([...seen, p.id]));
        if (r.error) throw new ExpressionError(`{${q.name}}: ${r.error}`);
        return SI[q.result] ? r.value * SI[q.result] : r.value;
      }
      const v = storedValue(el, q);
      if (SI[q.type]) return (+v || 0) * SI[q.type];
      if (NUMERIC.has(q.type)) return +v || 0;
      if (q.type === 'bool') return !!v;
      if (LISTS.has(q.type)) return (v || []).join('; ');
      return v ?? '';
    }
    const f = fields.find((x) => x.label.toLowerCase() === k || x.id.toLowerCase() === k);
    if (!f) return undefined;
    let v;
    try {
      v = f.project ? f.get(doc) : f.get(el, ctx);
    } catch {
      v = '';
    }
    return SI[f.type] ? (+v || 0) * SI[f.type] : v;
  };
  try {
    const v = evaluate(tree, field);
    if (SI[p.result]) return { value: (typeof v === 'number' ? v : parseFloat(v) || 0) / SI[p.result] };
    if (p.result === 'number') return { value: typeof v === 'number' ? v : parseFloat(v) || 0 };
    if (p.result === 'bool') return { value: !!v && v !== 'No' };
    return { value: typeof v === 'number' ? String(Math.round(v * 1e6) / 1e6) : typeof v === 'boolean' ? (v ? 'Yes' : 'No') : String(v ?? '') };
  } catch (err) {
    return { error: err.message };
  }
}

/** An expression parameter's value as text in the project's units (or its error). */
export function expressionText(ctx, el, p) {
  const r = expressionValue(ctx, el, p);
  if (r.error) return `Error: ${r.error}`;
  const u = ctx.doc.units;
  if (p.result === 'length') return formatLength(r.value, u);
  if (p.result === 'area') return formatArea(r.value, u);
  if (p.result === 'volume') return formatVolume(r.value, u);
  if (p.result === 'number') return String(Math.round(r.value * 1000) / 1000);
  if (p.result === 'bool') return r.value ? 'Yes' : 'No';
  return r.value;
}

export const PARAM_GROUPS = ['Identity Data', 'Constraints', 'Construction', 'Dimensions', 'Other'];

export function projectParams(doc) {
  return doc.all('projectParam').sort((a, b) => String(a.name).localeCompare(String(b.name)));
}

/** Built-in groups then the user's own: [{ id?, name, description, userDefined }]. */
export function propertyGroups(doc) {
  const own = doc.all('propertyGroup').sort((a, b) => String(a.name).localeCompare(String(b.name)));
  return [...PARAM_GROUPS.map((name) => ({ name, description: '', userDefined: false })), ...own.map((g) => ({ id: g.id, name: g.name, description: g.description || '', userDefined: true }))];
}

/** Whether a project parameter applies to an element, by its category or classification. */
export function paramApplies(doc, el, p) {
  const cat = categoryOf(el, doc);
  if (cat && (p.categories?.includes(cat) || p.categories?.includes('*'))) return true;
  if (!p.classes?.length) return false;
  for (const { system, code } of p.classes) {
    const sys = doc.get(system) || doc.all('classSystem').find((s) => s.name === system);
    const item = classOf(doc, el, sys);
    if (!item) continue;
    // The item itself or one under it (10.10 is under 10).
    for (let c = item; c; c = c.parent ? sys.items.find((i) => i.code === c.parent) : null) if (c.code === code) return true;
  }
  return false;
}

/** Project parameters that apply to an element (by its category or classification). */
export function paramsForElement(doc, el) {
  if (!categoryOf(el, doc) && !el.classes) return projectParams(doc).filter((p) => p.classes?.length && paramApplies(doc, el, p));
  return projectParams(doc).filter((p) => paramApplies(doc, el, p));
}

/** An element's stored value of a parameter, or the parameter's default. */
export function storedValue(el, p) {
  const v = el.params?.[p.id];
  if (v !== undefined && v !== null && v !== '') return v;
  if (p.default !== undefined && p.default !== null && p.default !== '') return p.default;
  return v;
}

/**
 * A value made fit for a parameter (stored units), or an Error: numbers,
 * yes/no from text, an option of the set (any case), lists from arrays or
 * text separated by ";".
 */
export function coerceParamValue(p, value) {
  if (p.type === 'expression') return new Error('An expression property is computed and cannot be set');
  if (value === null || value === undefined || value === '') return LISTS.has(p.type) ? [] : null;
  if (NUMERIC.has(p.type)) {
    const n = typeof value === 'number' ? value : parseFloat(String(value).replace(',', '.'));
    return Number.isFinite(n) ? n : new Error(`"${value}" is not a number`);
  }
  if (p.type === 'bool') {
    if (typeof value === 'boolean') return value;
    const t = String(value).trim().toLowerCase();
    if (['yes', 'true', '1', 'y', 'sì', 'si'].includes(t)) return true;
    if (['no', 'false', '0', 'n'].includes(t)) return false;
    return new Error(`"${value}" is not yes or no`);
  }
  const items = Array.isArray(value) ? value.map(String) : LISTS.has(p.type) ? String(value).split(';') : [String(value)];
  const clean = items.map((x) => x.trim()).filter(Boolean);
  if (p.type === 'choice' || p.type === 'multi') {
    const out = [];
    for (const x of clean) {
      const o = (p.options || []).find((y) => y.toLowerCase() === x.toLowerCase());
      if (!o) return new Error(`"${x}" is not one of the options: ${(p.options || []).join(', ')}`);
      if (!out.includes(o)) out.push(o);
    }
    if (p.type === 'choice') return out.length > 1 ? new Error('Only one option can be chosen') : out[0] ?? null;
    return out;
  }
  if (p.type === 'list') return clean;
  return String(value);
}

/** The value of a parameter for an element in stored units (expressions computed): { value } or { error }. */
export function paramValueOf(ctx, el, p) {
  if (p.type === 'expression') return expressionValue(ctx, el, p);
  const v = storedValue(el, p);
  if (LISTS.has(p.type)) return { value: Array.isArray(v) ? v : v ? [String(v)] : [] };
  if (p.type === 'bool') return { value: !!v };
  return { value: v ?? (NUMERIC.has(p.type) ? null : '') };
}

/** A parameter's value as text, in the project's units. */
export function paramText(ctx, el, p) {
  if (p.type === 'expression') return expressionText(ctx, el, p);
  const { value: v } = paramValueOf(ctx, el, p);
  const u = ctx.doc.units;
  if (v === null || v === undefined) return '';
  if (p.type === 'length') return formatLength(+v, u);
  if (p.type === 'area') return formatArea(+v, u);
  if (p.type === 'volume') return formatVolume(+v, u);
  if (p.type === 'angle') return `${Math.round(+v * 1000) / 1000}°`;
  if (p.type === 'bool') return v ? 'Yes' : 'No';
  if (LISTS.has(p.type)) return v.join('; ');
  return String(v);
}

/** Properties-palette descriptors for an element's project parameters. */
export function paramDescriptors(doc, el) {
  return paramsForElement(doc, el).map((p) => {
    if (p.type === 'expression') return { key: `param:${p.id}`, label: p.name, group: p.group || 'Identity Data', type: 'readonly', format: 'text', get: (e, c) => expressionText({ doc: c?.doc ?? doc, scene: c?.scene }, e, p) };
    const key = `param:${p.id}`;
    const group = p.group || 'Identity Data';
    const set = (e, v) => {
      const c = coerceParamValue(p, v);
      return c instanceof Error ? null : { params: { ...(e.params || {}), [p.id]: c } };
    };
    // Areas and volumes are typed in m² and m³.
    const SQ = { area: 1e6, volume: 1e9 };
    if (SQ[p.type])
      return { key, label: `${p.name} (${p.type === 'area' ? 'm²' : 'm³'})`, group, type: 'number', get: (e) => (storedValue(e, p) == null ? null : Math.round((+storedValue(e, p) / SQ[p.type]) * 1e4) / 1e4), set: (e, v) => set(e, +v * SQ[p.type]) };
    if (p.type === 'choice') return { key, label: p.name, group, type: 'select', options: () => [{ value: '', label: '—' }, ...(p.options || []).map((o) => ({ value: o, label: o }))], get: (e) => storedValue(e, p) ?? '', set };
    if (LISTS.has(p.type)) return { key, label: p.name, group, type: 'text', hint: () => (p.type === 'multi' ? `Options: ${(p.options || []).join('; ')}` : 'Separate items with ;'), get: (e) => (storedValue(e, p) || []).join('; '), set };
    return {
      key,
      label: p.name,
      group,
      type: p.type === 'bool' ? 'bool' : p.type === 'length' ? 'length' : p.type === 'angle' ? 'angle' : p.type === 'number' ? 'number' : 'text',
      get: (e) => storedValue(e, p) ?? (p.type === 'bool' ? false : p.type === 'text' ? '' : null),
      set,
    };
  });
}

/** A schedule (and autotext) field for a project parameter. */
function paramField(p) {
  if (p.type === 'expression')
    return {
      id: `param:${p.id}`,
      label: p.name,
      get: (el, c) => {
        const r = expressionValue(c, el, p);
        if (r.error) return '';
        return p.result === 'bool' ? (r.value ? 'Yes' : 'No') : r.value;
      },
      type: SI[p.result] ? p.result : p.result === 'number' ? 'number' : 'text',
      editParam: null,
    };
  return {
    id: `param:${p.id}`,
    label: p.name,
    get: (el) => {
      const v = storedValue(el, p);
      if (p.type === 'bool') return v ? 'Yes' : 'No';
      if (LISTS.has(p.type)) return (v || []).join('; ');
      return v ?? '';
    },
    type: ['length', 'area', 'volume'].includes(p.type) ? p.type : NUMERIC.has(p.type) ? 'number' : 'text',
    editParam: p.type === 'text' ? p.id : null,
  };
}

/** Fields for the project parameters of one element. */
export function paramFieldsFor(doc, el) {
  return paramsForElement(doc, el).map(paramField);
}

/** Schedule fields for the project parameters of the categories an element kind belongs to. */
export function paramFields(doc, kinds, categoryOfKind) {
  const cats = new Set(kinds.map(categoryOfKind).filter(Boolean));
  return projectParams(doc)
    .filter((p) => p.categories?.some((c) => cats.has(c) || cats.has('*')) || p.classes?.length)
    .map(paramField);
}
