/**
 * Procedural component families: furniture, casework, fixtures, equipment,
 * planting and lighting. Each family builds its 3D geometry and its plan
 * symbol from the type's overall width (x), depth (y) and height (z).
 *
 * Local frame: origin at the center of the footprint, +y is the back (the
 * side placed against a wall), the front faces -y.
 */
import { hexToRgba } from './mesh.js';
import { buildGdlFamily } from './gdlobject.js';

const ELLIPSE_SEGS = 28;

function ellipse(cx, cy, rx, ry, n = ELLIPSE_SEGS) {
  const out = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    out.push([cx + Math.cos(a) * rx, cy + Math.sin(a) * ry]);
  }
  return out;
}

function rect(x0, y0, x1, y1) {
  return [
    [x0, y0],
    [x1, y0],
    [x1, y1],
    [x0, y1],
  ];
}

/**
 * Collects geometry in the family's local frame and emits it through a
 * placement frame. `b` is a MeshBuilder; plan is { loops: [{ pts, closed, dash }], outline }.
 */
class FamilyContext {
  constructor(b, frame, mats) {
    this.b = b;
    this.frame = frame;
    this.mats = mats;
  }

  color(id, fallback = '#c8c8c8') {
    if (typeof id === 'string' && id.startsWith('#')) return hexToRgba(id);
    const m = this.mats(id);
    return hexToRgba(m?.color || fallback, m?.opacity ?? 1);
  }

  box(x0, y0, z0, x1, y1, z1, mat) {
    if (!this.b) return;
    const loop = rect(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1)).map((p) => this.frame.apply(p));
    this.b.prism(loop, [], this.frame.z + Math.min(z0, z1), this.frame.z + Math.max(z0, z1), typeof mat === 'string' ? this.color(mat) : mat);
  }

  prism(loop, z0, z1, mat, opts) {
    if (!this.b) return;
    this.b.prism(
      loop.map((p) => this.frame.apply(p)),
      [],
      this.frame.z + z0,
      this.frame.z + z1,
      typeof mat === 'string' ? this.color(mat) : mat,
      opts,
    );
  }

  cyl(cx, cy, r, z0, z1, mat, opts = {}) {
    if (!this.b) return;
    const c = this.frame.apply([cx, cy]);
    this.b.cylinder(c, r, this.frame.z + z0, this.frame.z + z1, typeof mat === 'string' ? this.color(mat) : mat, opts);
  }

  sphere(cx, cy, cz, r, mat, opts) {
    if (!this.b) return;
    const c = this.frame.apply([cx, cy]);
    this.b.sphere([c[0], c[1], this.frame.z + cz], r, typeof mat === 'string' ? this.color(mat) : mat, opts);
  }
}

const F = {
  bed(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    const hw = w / 2;
    const hd = d / 2;
    x.box(-hw, -hd, 0, hw, hd, h * 0.55, 'mat-wood');
    x.box(-hw + 20, -hd + 20, h * 0.55, hw - 20, hd - 60, h, 'mat-fabric-warm');
    x.box(-hw, hd - 60, 0, hw, hd, h + 450, 'mat-wood');
    const pillows = w > 1200 ? 2 : 1;
    const pw = (w - 120 - (pillows - 1) * 60) / pillows;
    for (let i = 0; i < pillows; i++) {
      const px = -hw + 60 + i * (pw + 60);
      x.box(px, hd - 120 - 380, h, px + pw, hd - 120, h + 120, 'mat-porcelain');
      plan.loops.push({ pts: rect(px, hd - 120 - 380, px + pw, hd - 120), closed: true });
    }
    plan.loops.push({ pts: rect(-hw, -hd, hw, hd), closed: true });
    plan.loops.push({ pts: rect(-hw, hd - 60, hw, hd), closed: true });
    plan.loops.push({ pts: [[-hw, hd - d * 0.36], [hw, hd - d * 0.36]] });
    plan.loops.push({ pts: [[-hw, hd - d * 0.36], [-hw + w * 0.18, hd - d * 0.28]] });
  },
  cabinet(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-wood-light');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: [[-w / 2, -d / 2 + 25], [w / 2, -d / 2 + 25]] });
    if (w > 700) plan.loops.push({ pts: [[0, -d / 2], [0, -d / 2 + 25]] });
  },
  sofa(t, x, plan, seats = 3) {
    const { width: w, depth: d, height: h } = t;
    const arm = Math.min(180, w * 0.12);
    const back = Math.min(220, d * 0.25);
    const seatH = Math.min(440, h * 0.55);
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, seatH - 120, 'mat-fabric');
    x.box(-w / 2 + arm, -d / 2 + 30, seatH - 120, w / 2 - arm, d / 2 - back, seatH, 'mat-fabric');
    x.box(-w / 2, d / 2 - back, 0, w / 2, d / 2, h, 'mat-fabric');
    x.box(-w / 2, -d / 2, 0, -w / 2 + arm, d / 2, seatH + 180, 'mat-fabric');
    x.box(w / 2 - arm, -d / 2, 0, w / 2, d / 2, seatH + 180, 'mat-fabric');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: [[-w / 2 + arm, d / 2 - back], [w / 2 - arm, d / 2 - back]] });
    plan.loops.push({ pts: [[-w / 2 + arm, -d / 2], [-w / 2 + arm, d / 2 - back]] });
    plan.loops.push({ pts: [[w / 2 - arm, -d / 2], [w / 2 - arm, d / 2 - back]] });
    const sw = (w - 2 * arm) / seats;
    for (let i = 1; i < seats; i++) plan.loops.push({ pts: [[-w / 2 + arm + i * sw, -d / 2 + 30], [-w / 2 + arm + i * sw, d / 2 - back]] });
  },
  armchair(t, x, plan) {
    F.sofa(t, x, plan, 1);
  },
  table(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    const leg = 50;
    const ins = 40;
    x.box(-w / 2, -d / 2, h - 35, w / 2, d / 2, h, 'mat-wood');
    for (const sx of [-1, 1])
      for (const sy of [-1, 1]) {
        const cx = sx * (w / 2 - ins - leg / 2);
        const cy = sy * (d / 2 - ins - leg / 2);
        x.box(cx - leg / 2, cy - leg / 2, 0, cx + leg / 2, cy + leg / 2, h - 35, 'mat-wood');
      }
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
  },
  roundTable(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, w / 2, h - 35, h, 'mat-wood', { segments: 40 });
    x.cyl(0, 0, 45, 30, h - 35, 'mat-wood', { segments: 12 });
    x.cyl(0, 0, w * 0.22, 0, 30, 'mat-wood', { segments: 24 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 40), closed: true });
  },
  chair(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    const seat = Math.min(460, h * 0.53);
    const leg = 35;
    x.box(-w / 2, -d / 2, seat - 40, w / 2, d / 2, seat, 'mat-wood');
    x.box(-w / 2, d / 2 - 40, seat, w / 2, d / 2, h, 'mat-wood');
    for (const sx of [-1, 1])
      for (const sy of [-1, 1]) {
        const cx = sx * (w / 2 - leg / 2);
        const cy = sy * (d / 2 - leg / 2);
        x.box(cx - leg / 2, cy - leg / 2, 0, cx + leg / 2, cy + leg / 2, seat - 40, 'mat-wood');
      }
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: [[-w / 2, d / 2 - 40], [w / 2, d / 2 - 40]] });
  },
  desk(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, h - 30, w / 2, d / 2, h, 'mat-wood-light');
    x.box(-w / 2, -d / 2 + 20, 0, -w / 2 + 30, d / 2 - 20, h - 30, 'mat-wood-light');
    x.box(w / 2 - 30, -d / 2 + 20, 0, w / 2, d / 2 - 20, h - 30, 'mat-wood-light');
    x.box(-w / 2 + 30, d / 2 - 60, h * 0.35, w / 2 - 30, d / 2 - 40, h - 30, 'mat-wood-light');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
  },
  shelf(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    const th = 20;
    x.box(-w / 2, -d / 2, 0, -w / 2 + th, d / 2, h, 'mat-wood-light');
    x.box(w / 2 - th, -d / 2, 0, w / 2, d / 2, h, 'mat-wood-light');
    x.box(-w / 2 + th, d / 2 - 8, 0, w / 2 - th, d / 2, h, 'mat-wood-light');
    const n = Math.max(2, Math.round(h / 350));
    for (let i = 0; i <= n; i++) {
      const z = i === n ? h - th : (i * (h - th)) / n;
      x.box(-w / 2 + th, -d / 2, z, w / 2 - th, d / 2 - 8, z + th, 'mat-wood-light');
    }
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: [[-w / 2, -d / 2], [w / 2, d / 2]] });
  },
  counter(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2 + 60, 0, w / 2, d / 2, 100, 'mat-wood-frame');
    x.box(-w / 2, -d / 2 + 20, 100, w / 2, d / 2, h - 40, 'mat-paint-white');
    x.box(-w / 2, -d / 2, h - 40, w / 2, d / 2, h, 'mat-stone');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: [[-w / 2, -d / 2 + 20], [w / 2, -d / 2 + 20]], dash: 2 });
  },
  upperCabinet(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-paint-white');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true, dash: 2 });
    plan.loops.push({ pts: [[-w / 2, -d / 2], [w / 2, d / 2]], dash: 2 });
    plan.loops.push({ pts: [[-w / 2, d / 2], [w / 2, -d / 2]], dash: 2 });
    plan.noFill = true;
  },
  fridge(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-aluminum');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: [[-w / 2, -d / 2 + 50], [w / 2, -d / 2 + 50]] });
    plan.loops.push({ pts: [[0, -d / 2], [0, -d / 2 + 50]] });
  },
  range(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-aluminum');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    for (const sx of [-1, 1])
      for (const sy of [-1, 1]) {
        const cx = (sx * w) / 4.4;
        const cy = (sy * d) / 4.4;
        const r = Math.min(w, d) * 0.15;
        x.cyl(cx, cy, r, h, h + 8, '#2b2f35', { segments: 20 });
        plan.loops.push({ pts: ellipse(cx, cy, r, r, 20), closed: true });
      }
  },
  washer(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-porcelain');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: ellipse(0, 0, w * 0.3, w * 0.3, 24), closed: true });
  },
  toilet(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    const tankD = Math.min(200, d * 0.28);
    x.box(-w / 2, d / 2 - tankD, 0, w / 2, d / 2, h, 'mat-porcelain');
    const bowl = ellipse(0, d / 2 - tankD - (d - tankD) / 2 + 20, w * 0.48, (d - tankD) / 2, 24);
    x.prism(bowl, 0, 400, 'mat-porcelain', { edgeAngle: 0.5 });
    plan.loops.push({ pts: rect(-w / 2, d / 2 - tankD, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: bowl, closed: true });
    plan.loops.push({ pts: ellipse(0, d / 2 - tankD - (d - tankD) / 2 + 30, w * 0.34, (d - tankD) * 0.36, 24), closed: true });
  },
  vanity(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2 + 20, 0, w / 2, d / 2, h - 30, 'mat-wood-light');
    x.box(-w / 2, -d / 2, h - 30, w / 2, d / 2, h, 'mat-stone');
    const basin = ellipse(0, -20, w * 0.22, d * 0.28, 24);
    x.prism(basin, h, h + 3, '#d7dde2', { edges: true, edgeAngle: 1 });
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: basin, closed: true });
  },
  kitchenSink(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    const gap = 40;
    const bw = (w - gap * 3) / 2;
    for (const i of [0, 1]) {
      const x0 = -w / 2 + gap + i * (bw + gap);
      x.box(x0, -d / 2 + gap, h - 10, x0 + bw, d / 2 - gap, h, '#9aa3ab');
      plan.loops.push({ pts: rect(x0, -d / 2 + gap, x0 + bw, d / 2 - gap), closed: true });
    }
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.noFill = true;
  },
  bathtub(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-porcelain');
    const inner = rect(-w / 2 + 80, -d / 2 + 80, w / 2 - 80, d / 2 - 80);
    x.prism(inner, h, h + 2, '#dfe5ea');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: inner, closed: true });
    plan.loops.push({ pts: ellipse(-w / 2 + 180, 0, 30, 30, 12), closed: true });
  },
  shower(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, 60, 'mat-porcelain');
    x.box(-w / 2, -d / 2, 60, -w / 2 + 10, d / 2, h, 'mat-glass');
    x.box(-w / 2, -d / 2, 60, w / 2, -d / 2 + 10, h, 'mat-glass');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: [[-w / 2, -d / 2], [w / 2, d / 2]] });
    plan.loops.push({ pts: [[-w / 2, d / 2], [w / 2, -d / 2]] });
    plan.loops.push({ pts: ellipse(0, 0, 40, 40, 12), closed: true });
  },
  tree(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, Math.max(60, w * 0.04), 0, h * 0.45, 'mat-wood', { segments: 10 });
    x.sphere(0, 0, h * 0.62, w / 2, 'mat-foliage', { segments: 14, rings: 9, sz: (h * 0.38) / (w / 2) });
    const n = 14;
    const pts = [];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      const r = (w / 2) * (i % 2 ? 0.86 : 1);
      pts.push([Math.cos(a) * r, Math.sin(a) * r]);
    }
    plan.loops.push({ pts, closed: true });
    plan.loops.push({ pts: [[-w * 0.12, 0], [w * 0.12, 0]] });
    plan.loops.push({ pts: [[0, -w * 0.12], [0, w * 0.12]] });
    plan.fillColor = [110, 160, 90, 60];
  },
  shrub(t, x, plan) {
    const { width: w, height: h } = t;
    x.sphere(0, 0, h / 2, w / 2, 'mat-foliage', { segments: 12, rings: 7, sz: h / w });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 18), closed: true });
    plan.fillColor = [110, 160, 90, 60];
  },
  pendant(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, 4, h, h + 600, 'mat-steel', { segments: 6, edges: false });
    x.cyl(0, 0, w / 2, 0, h, 'mat-paint-white', { r1: w * 0.12, segments: 24 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 24), closed: true, dash: 2 });
    plan.loops.push({ pts: [[-w / 2, 0], [w / 2, 0]], dash: 2 });
    plan.loops.push({ pts: [[0, -w / 2], [0, w / 2]], dash: 2 });
    plan.noFill = true;
  },
  floorLamp(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, w * 0.35, 0, 25, 'mat-steel', { segments: 20 });
    x.cyl(0, 0, 12, 25, h - 300, 'mat-steel', { segments: 8 });
    x.cyl(0, 0, w / 2, h - 300, h, 'mat-fabric-warm', { r1: w * 0.32, segments: 24 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 24), closed: true });
    plan.loops.push({ pts: ellipse(0, 0, w * 0.1, w * 0.1, 10), closed: true });
  },
  downlight(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, w / 2, h - 20, h, 'mat-paint-white', { segments: 20 });
    x.cyl(0, 0, w * 0.38, 0, h - 20, 'mat-aluminum', { segments: 16 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 20), closed: true });
    plan.loops.push({ pts: [[-w * 0.35, -w * 0.35], [w * 0.35, w * 0.35]] }, { pts: [[-w * 0.35, w * 0.35], [w * 0.35, -w * 0.35]] });
    plan.noFill = true;
  },
  sprinkler(t, x, plan) {
    // Pendant head: a deflector disc under a short body, hanging below the ceiling.
    const { width: w, height: h } = t;
    x.cyl(0, 0, w / 2, 0, 6, 'mat-steel', { segments: 16 });
    x.cyl(0, 0, w * 0.18, 6, h, 'mat-steel', { segments: 10 });
    x.cyl(0, 0, w * 0.3, h - 12, h, 'mat-paint-white', { segments: 14 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 16), closed: true });
    plan.loops.push({ pts: [[-w * 0.5, 0], [w * 0.5, 0]] }, { pts: [[0, -w * 0.5], [0, w * 0.5]] });
    plan.noFill = true;
  },
  diffuser(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, h - 20, w / 2, d / 2, h, 'mat-paint-white');
    x.box(-w * 0.3, -d * 0.3, 0, w * 0.3, d * 0.3, h - 20, 'mat-aluminum');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: rect(-w * 0.3, -d * 0.3, w * 0.3, d * 0.3), closed: true });
    plan.loops.push({ pts: [[-w / 2, -d / 2], [w / 2, d / 2]] }, { pts: [[-w / 2, d / 2], [w / 2, -d / 2]] });
    plan.noFill = true;
  },
  grille(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, h - 20, w / 2, d / 2, h, 'mat-paint-white');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    for (let i = 1; i < 6; i++) plan.loops.push({ pts: [[-w / 2 + (w * i) / 6, -d / 2], [-w / 2 + (w * i) / 6, d / 2]] });
    plan.noFill = true;
  },
  mechUnit(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, '#b9c2cb');
    x.cyl(w * 0.22, 0, Math.min(w, d) * 0.3, h, h + 20, 'mat-steel', { segments: 20 });
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: ellipse(w * 0.22, 0, Math.min(w, d) * 0.3, Math.min(w, d) * 0.3, 20), closed: true });
    plan.loops.push({ pts: [[-w / 2, -d / 2], [w * 0.22 - Math.min(w, d) * 0.3, 0]] }, { pts: [[-w / 2, d / 2], [w * 0.22 - Math.min(w, d) * 0.3, 0]] });
  },
  waterHeater(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, w / 2, 0, h, 'mat-paint-white', { segments: 24 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 24), closed: true });
    plan.loops.push({ pts: ellipse(0, 0, w * 0.15, w * 0.15, 12), closed: true });
  },
  panel(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, '#8a939c');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.fillColor = [60, 66, 74, 220];
  },
  receptacle(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, d / 2 - 15, 0, w / 2, d / 2, h, 'mat-paint-white');
    // Plan symbol: a circle with two parallel strokes, drawn at a readable size.
    const r = 110;
    plan.loops.push({ pts: ellipse(0, d / 2 - r, r, r, 16), closed: true });
    plan.loops.push({ pts: [[-r * 1.5, d / 2 - r * 0.6], [r * 1.5, d / 2 - r * 0.6]] }, { pts: [[-r * 1.5, d / 2 - r * 1.4], [r * 1.5, d / 2 - r * 1.4]] });
    plan.noFill = true;
  },
  switch(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, d / 2 - 15, 0, w / 2, d / 2, h, 'mat-paint-white');
    const r = 110;
    plan.loops.push({ pts: ellipse(0, d / 2 - r, r, r, 16), closed: true });
    plan.loops.push({ pts: [[0, d / 2 - r * 2], [r * 1.4, d / 2 - r * 3]] });
    plan.noFill = true;
  },
  bench(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    for (const sx of [-1, 1]) x.box(sx * (w / 2 - 120) - 40, -d / 2 + 40, 0, sx * (w / 2 - 120) + 40, d / 2 - 40, h - 60, 'mat-steel');
    x.box(-w / 2, -d / 2, h - 60, w / 2, d / 2, h, 'mat-wood');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    for (let i = 1; i < 4; i++) plan.loops.push({ pts: [[-w / 2, -d / 2 + (d * i) / 4], [w / 2, -d / 2 + (d * i) / 4]] });
  },
  bollard(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, w / 2, 0, h, 'mat-concrete', { segments: 18 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 18), closed: true });
  },
  parking(t, x, plan) {
    const { width: w, depth: d } = t;
    // Painted stripes on the ground: the two sides and the end.
    const s = 100;
    x.box(-w / 2, -d / 2, 0, -w / 2 + s, d / 2, 2, 'mat-paint-white');
    x.box(w / 2 - s, -d / 2, 0, w / 2, d / 2, 2, 'mat-paint-white');
    plan.loops.push({ pts: [[-w / 2, -d / 2], [-w / 2, d / 2], [w / 2, d / 2], [w / 2, -d / 2]] });
    plan.noFill = true;
  },
  person(t, x, plan) {
    // Standing figure: legs, torso, shoulders and head, scaled to the height.
    const { width: w, depth: d, height: h } = t;
    const k = h / 1750;
    for (const sx of [-1, 1]) x.cyl(sx * w * 0.12, 0, 65 * k, 0, h * 0.48, '#4b5563', { segments: 10, edges: false });
    x.prism(ellipse(0, 0, w * 0.4, d * 0.42, 16), h * 0.48, h * 0.8, '#7b8794', { edgeAngle: 0.5 });
    x.sphere(0, 0, h * 0.89, 100 * k, '#c9a88a', { segments: 12, rings: 8, sz: 1.15 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, d / 2, 20), closed: true });
    plan.loops.push({ pts: ellipse(0, 0, 100 * k, 110 * k, 14), closed: true });
  },
  car(t, x, plan) {
    // Hatchback massing: body, glazed cabin, four wheels. Front is -y.
    const { width: w, depth: d, height: h } = t;
    const wr = Math.min(330, h * 0.24);
    x.box(-w / 2, -d / 2, wr * 0.6, w / 2, d / 2, h * 0.55, '#8a9bb0');
    x.box(-w / 2 + 70, -d / 2 + d * 0.3, h * 0.55, w / 2 - 70, d / 2 - d * 0.12, h, 'mat-glass');
    // Wheels as tyre blocks seen side on (cylinders here only stand upright).
    for (const sx of [-1, 1])
      for (const sy of [-1, 1]) {
        const x0 = sx > 0 ? w / 2 - 230 : -w / 2 + 10;
        const cy = sy * (d / 2 - d * 0.18);
        x.box(x0, cy - wr, 0, x0 + 220, cy + wr, wr * 2, '#222222');
      }
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: rect(-w / 2 + 70, -d / 2 + d * 0.3, w / 2 - 70, d / 2 - d * 0.12), closed: true });
    plan.loops.push({ pts: [[-w / 2 + 70, -d / 2 + d * 0.38], [w / 2 - 70, -d / 2 + d * 0.38]] });
  },
  bicycle(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    const r = Math.min(d * 0.2, h * 0.37);
    for (const sy of [-1, 1]) x.box(-15, sy * (d / 2 - r) - r, 0, 15, sy * (d / 2 - r) + r, r * 2, '#333333');
    x.box(-15, -d / 2 + r, r, 15, d / 2 - r, r + 40, 'mat-steel');
    x.box(-w / 2, -d / 2 + r * 0.8, h - 30, w / 2, -d / 2 + r * 0.8 + 30, h, 'mat-steel');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true, dash: 2 });
    plan.loops.push({ pts: [[0, -d / 2], [0, d / 2]] });
    plan.loops.push({ pts: [[-w / 2, -d / 2 + r * 0.8], [w / 2, -d / 2 + r * 0.8]] });
    plan.noFill = true;
  },
  island(t, x, plan) {
    // Kitchen island: base cabinets with a worktop overhanging on the seating side.
    const { width: w, depth: d, height: h } = t;
    const over = Math.min(300, d * 0.3);
    x.box(-w / 2 + 20, -d / 2 + 20, 0, w / 2 - 20, d / 2 - over, 100, '#555555');
    x.box(-w / 2 + 20, -d / 2 + 20, 100, w / 2 - 20, d / 2 - over, h - 40, 'mat-wood-light');
    x.box(-w / 2, -d / 2, h - 40, w / 2, d / 2, h, 'mat-stone');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: [[-w / 2 + 20, d / 2 - over], [w / 2 - 20, d / 2 - over]], dash: 1 });
  },
  hob(t, x, plan) {
    // Cooktop on a worktop: a glass plate with four rings.
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, h - 6, w / 2, d / 2, h, '#1f2226');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    const rr = Math.min(w, d) * 0.17;
    for (const [cx, cy, s] of [[-w * 0.24, -d * 0.2, 1], [w * 0.24, -d * 0.2, 0.75], [-w * 0.24, d * 0.22, 0.75], [w * 0.24, d * 0.22, 1]]) plan.loops.push({ pts: ellipse(cx, cy, rr * s, rr * s, 16), closed: true });
    plan.noFill = true;
  },
  tallCabinet(t, x, plan) {
    // Oven housing: a full-height unit with a built-in oven at working height.
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2 + 20, 0, w / 2, d / 2, h, 'mat-wood-light');
    x.box(-w / 2 + 30, -d / 2, 800, w / 2 - 30, -d / 2 + 20, 1400, '#2b2f33');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: [[-w / 2, -d / 2], [w / 2, d / 2]] });
  },
  bidet(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    const bowl = ellipse(0, -d * 0.05, w / 2, d * 0.45, 24);
    x.prism(bowl, 0, h, 'mat-porcelain', { edgeAngle: 0.5 });
    plan.loops.push({ pts: bowl, closed: true });
    plan.loops.push({ pts: ellipse(0, -d * 0.08, w * 0.32, d * 0.3, 20), closed: true });
    plan.loops.push({ pts: ellipse(0, d * 0.3, 18, 18, 10), closed: true });
  },
  urinal(t, x, plan) {
    // Wall hung: the bowl projects from the back.
    const { width: w, depth: d, height: h } = t;
    const loop = [...ellipse(0, d * 0.05, w / 2, d * 0.45, 20).filter(([, py]) => py < d * 0.05), [w / 2, d / 2], [-w / 2, d / 2]];
    x.prism(loop, 0, h, 'mat-porcelain', { edgeAngle: 0.5 });
    plan.loops.push({ pts: loop, closed: true });
    plan.loops.push({ pts: ellipse(0, 0, w * 0.3, d * 0.28, 16), closed: true });
  },
  basin(t, x, plan) {
    // Wall hung washbasin with a tap at the back.
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-porcelain');
    const bowl = ellipse(0, -d * 0.08, w * 0.38, d * 0.32, 24);
    x.prism(bowl, h, h + 2, '#d7dde2');
    x.cyl(0, d / 2 - 50, 15, h, h + 160, 'mat-steel', { segments: 8, edges: false });
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: bowl, closed: true });
    plan.loops.push({ pts: ellipse(0, d / 2 - 50, 20, 20, 8), closed: true });
  },
  radiator(t, x, plan) {
    // Panel radiator: vertical fins between two headers, hung off the wall.
    const { width: w, depth: d, height: h } = t;
    const n = Math.max(3, Math.round(w / 60));
    const fw = w / n;
    for (let i = 0; i < n; i++) x.box(-w / 2 + i * fw + 5, -d / 2, 0, -w / 2 + (i + 1) * fw - 5, d / 2, h, 'mat-paint-white');
    x.box(-w / 2, -d / 2 + 10, h * 0.05, w / 2, d / 2 - 10, h * 0.12, 'mat-paint-white');
    x.box(-w / 2, -d / 2 + 10, h * 0.88, w / 2, d / 2 - 10, h * 0.95, 'mat-paint-white');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    for (let i = 1; i < n; i++) plan.loops.push({ pts: [[-w / 2 + i * fw, -d / 2], [-w / 2 + i * fw, d / 2]] });
  },
  fireplace(t, x, plan) {
    // Chimney breast with a firebox opening and a hearth in front.
    const { width: w, depth: d, height: h } = t;
    const hearth = Math.min(400, d * 0.4);
    const bd = d - hearth;
    x.box(-w / 2, -d / 2, 0, w / 2, -d / 2 + hearth, 50, 'mat-stone');
    x.box(-w / 2, -d / 2 + hearth, 0, -w * 0.3, d / 2, h, 'mat-masonry-brick');
    x.box(w * 0.3, -d / 2 + hearth, 0, w / 2, d / 2, h, 'mat-masonry-brick');
    x.box(-w * 0.3, -d / 2 + hearth + bd * 0.5, 0, w * 0.3, d / 2, h, 'mat-masonry-brick');
    x.box(-w * 0.3, -d / 2 + hearth, h * 0.45, w * 0.3, -d / 2 + hearth + bd * 0.5, h, 'mat-masonry-brick');
    plan.loops.push({ pts: rect(-w / 2, -d / 2 + hearth, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, -d / 2 + hearth), closed: true });
    plan.loops.push({ pts: [[-w * 0.3, -d / 2 + hearth], [-w * 0.3, -d / 2 + hearth + bd * 0.5], [w * 0.3, -d / 2 + hearth + bd * 0.5], [w * 0.3, -d / 2 + hearth]] });
  },
  tv(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, '#151719');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.fillColor = [30, 30, 30, 200];
  },
  rug(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-fabric-warm');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true, dash: 1 });
    plan.loops.push({ pts: rect(-w / 2 + 80, -d / 2 + 80, w / 2 - 80, d / 2 - 80), closed: true, dash: 1 });
    plan.noFill = true;
  },
  stool(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, w * 0.35, 0, 15, 'mat-steel', { segments: 16 });
    x.cyl(0, 0, 25, 15, h - 50, 'mat-steel', { segments: 8 });
    x.cyl(0, 0, w / 2, h - 50, h, 'mat-wood', { segments: 20 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 20), closed: true });
  },
  pottedPlant(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, w * 0.3, 0, h * 0.35, '#a0603a', { r1: w * 0.38, segments: 16 });
    x.sphere(0, 0, h * 0.68, w / 2, 'mat-foliage', { segments: 12, rings: 8, sz: (h * 0.32) / (w / 2) });
    plan.loops.push({ pts: ellipse(0, 0, w * 0.38, w * 0.38, 16), closed: true });
    const n = 10;
    const pts = [];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      const r = (w / 2) * (i % 2 ? 0.7 : 1);
      pts.push([Math.cos(a) * r, Math.sin(a) * r]);
    }
    plan.loops.push({ pts, closed: true });
    plan.fillColor = [110, 160, 90, 60];
  },
  conifer(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, Math.max(50, w * 0.05), 0, h * 0.2, 'mat-wood', { segments: 8 });
    x.cyl(0, 0, w / 2, h * 0.15, h, 'mat-foliage', { r1: 1, segments: 14 });
    plan.loops.push({ pts: ellipse(0, 0, w / 2, w / 2, 16), closed: true });
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      plan.loops.push({ pts: [[0, 0], [Math.cos(a) * w * 0.5, Math.sin(a) * w * 0.5]] });
    }
    plan.fillColor = [80, 130, 80, 70];
  },
  hedge(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-foliage');
    const pts = [];
    const n = Math.max(4, Math.round(w / 300));
    for (let i = 0; i <= n; i++) pts.push([-w / 2 + (w * i) / n, -d / 2 + (i % 2 ? 40 : 0)]);
    for (let i = n; i >= 0; i--) pts.push([-w / 2 + (w * i) / n, d / 2 - (i % 2 ? 40 : 0)]);
    plan.loops.push({ pts, closed: true });
    plan.fillColor = [110, 160, 90, 60];
  },
  streetLight(t, x, plan) {
    // Pole with a luminaire arm reaching to the front.
    const { width: w, height: h } = t;
    x.cyl(0, 0, 130, 0, 400, 'mat-concrete', { segments: 12 });
    x.cyl(0, 0, 50, 400, h, 'mat-steel', { r1: 35, segments: 10 });
    x.box(-25, -w * 0.45, h - 60, 25, 0, h - 20, 'mat-steel');
    x.box(-120, -w * 0.5, h - 110, 120, -w * 0.3, h - 50, 'mat-paint-white');
    plan.loops.push({ pts: ellipse(0, 0, 130, 130, 12), closed: true });
    plan.loops.push({ pts: [[0, 0], [0, -w * 0.4]] });
    plan.loops.push({ pts: ellipse(0, -w * 0.4, w * 0.1, w * 0.1, 12), closed: true });
  },
  wallLight(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, d / 2 - 20, 0, w / 2, d / 2, h, 'mat-steel');
    x.cyl(0, 0, Math.min(w, d) / 2, h * 0.2, h * 0.8, 'mat-paint-white', { r1: Math.min(w, d) * 0.3, segments: 16 });
    plan.loops.push({ pts: [[-w / 2, d / 2], ...ellipse(0, 0, w / 2, d / 2, 16).filter(([, py]) => py < 0), [w / 2, d / 2]], closed: true });
    plan.loops.push({ pts: [[-w * 0.3, -d * 0.3], [w * 0.3, d * 0.3]] }, { pts: [[-w * 0.3, d * 0.3], [w * 0.3, -d * 0.3]] });
    plan.noFill = true;
  },
  linearLight(t, x, plan) {
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, 'mat-aluminum');
    x.box(-w / 2 + 10, -d / 2 + 10, -2, w / 2 - 10, d / 2 - 10, 0, '#fff7d6');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true, dash: 2 });
    plan.loops.push({ pts: [[-w / 2, 0], [w / 2, 0]], dash: 2 });
    plan.noFill = true;
  },
  ceilingFan(t, x, plan) {
    const { width: w, height: h } = t;
    x.cyl(0, 0, 12, h * 0.4, h, 'mat-steel', { segments: 8, edges: false });
    x.cyl(0, 0, 90, 0, h * 0.4, 'mat-paint-white', { segments: 16 });
    for (let i = 0; i < 4; i++) {
      const a = (i * Math.PI) / 2;
      const c = Math.cos(a);
      const s = Math.sin(a);
      const blade = [[90, -60], [w / 2, -70], [w / 2, 70], [90, 60]].map(([u, v]) => [u * c - v * s, u * s + v * c]);
      x.prism(blade, h * 0.15, h * 0.15 + 12, 'mat-wood');
      plan.loops.push({ pts: blade, closed: true, dash: 2 });
    }
    plan.loops.push({ pts: ellipse(0, 0, 90, 90, 16), closed: true, dash: 2 });
    plan.noFill = true;
  },
  elevator(t, x, plan) {
    // Lift car in its shaft: car outline with the usual diagonal cross and a door at the front.
    const { width: w, depth: d, height: h } = t;
    const g = 100;
    x.box(-w / 2 + g, -d / 2 + g, 0, w / 2 - g, d / 2 - g, 60, 'mat-steel');
    x.box(-w / 2 + g, d / 2 - g - 30, 60, w / 2 - g, d / 2 - g, h, 'mat-steel');
    for (const sx of [-1, 1]) x.box(sx * (w / 2 - g) - (sx > 0 ? 30 : 0), -d / 2 + g, 60, sx * (w / 2 - g) + (sx < 0 ? 30 : 0), d / 2 - g, h, 'mat-steel');
    x.box(-w / 2 + g, -d / 2 + g, h - 60, w / 2 - g, d / 2 - g, h, 'mat-steel');
    plan.loops.push({ pts: rect(-w / 2 + g, -d / 2 + g, w / 2 - g, d / 2 - g), closed: true });
    plan.loops.push({ pts: [[-w / 2 + g, -d / 2 + g], [w / 2 - g, d / 2 - g]] }, { pts: [[-w / 2 + g, d / 2 - g], [w / 2 - g, -d / 2 + g]] });
    plan.loops.push({ pts: [[-w * 0.25, -d / 2], [w * 0.25, -d / 2]] });
    plan.noFill = true;
  },
  solarPanel(t, x, plan) {
    // A frame of photovoltaic modules lying on the surface it is placed on.
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2, 0, w / 2, d / 2, h, '#1d2a44');
    const nx = Math.max(1, Math.round(w / 1000));
    const ny = Math.max(1, Math.round(d / 1700));
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    for (let i = 1; i < nx; i++) plan.loops.push({ pts: [[-w / 2 + (w * i) / nx, -d / 2], [-w / 2 + (w * i) / nx, d / 2]] });
    for (let j = 1; j < ny; j++) plan.loops.push({ pts: [[-w / 2, -d / 2 + (d * j) / ny], [w / 2, -d / 2 + (d * j) / ny]] });
    plan.fillColor = [40, 60, 110, 90];
  },
  pool(t, x, plan) {
    // Swimming pool: a coping kerb around the water, the basin sunk below the placement level.
    const { width: w, depth: d, height: h } = t;
    const c = 300;
    x.box(-w / 2, -d / 2, -h, w / 2, -d / 2 + c, 0, 'mat-stone');
    x.box(-w / 2, d / 2 - c, -h, w / 2, d / 2, 0, 'mat-stone');
    x.box(-w / 2, -d / 2 + c, -h, -w / 2 + c, d / 2 - c, 0, 'mat-stone');
    x.box(w / 2 - c, -d / 2 + c, -h, w / 2, d / 2 - c, 0, 'mat-stone');
    x.box(-w / 2 + c, -d / 2 + c, -h, w / 2 - c, d / 2 - c, -h + 100, 'mat-tile');
    x.box(-w / 2 + c, -d / 2 + c, -150, w / 2 - c, d / 2 - c, -140, '#4fa3d9');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: rect(-w / 2 + c, -d / 2 + c, w / 2 - c, d / 2 - c), closed: true });
    plan.fillColor = [79, 163, 217, 70];
  },
  pergola(t, x, plan) {
    // Four posts, two beams across the width and rafters along the depth.
    const { width: w, depth: d, height: h } = t;
    const p = 120;
    for (const sx of [-1, 1]) for (const sy of [-1, 1]) x.box(sx * (w / 2 - p) - p / 2, sy * (d / 2 - p) - p / 2, 0, sx * (w / 2 - p) + p / 2, sy * (d / 2 - p) + p / 2, h - 200, 'mat-wood');
    for (const sy of [-1, 1]) x.box(-w / 2, sy * (d / 2 - p) - 40, h - 200, w / 2, sy * (d / 2 - p) + 40, h - 50, 'mat-wood');
    const n = Math.max(3, Math.round(w / 500));
    for (let i = 0; i <= n; i++) {
      const cx = -w / 2 + 40 + ((w - 80) * i) / n;
      x.box(cx - 25, -d / 2, h - 50, cx + 25, d / 2, h, 'mat-wood');
      plan.loops.push({ pts: [[cx, -d / 2], [cx, d / 2]], dash: 2 });
    }
    for (const sx of [-1, 1]) for (const sy of [-1, 1]) plan.loops.push({ pts: rect(sx * (w / 2 - p) - p / 2, sy * (d / 2 - p) - p / 2, sx * (w / 2 - p) + p / 2, sy * (d / 2 - p) + p / 2), closed: true });
    plan.noFill = true;
  },
  workstation(t, x, plan) {
    // Office desk with a privacy screen at the back and a pedestal on the right.
    const { width: w, depth: d, height: h } = t;
    const top = 740;
    x.box(-w / 2, -d / 2, top - 25, w / 2, d / 2, top, 'mat-wood-light');
    for (const sx of [-1, 1]) x.box(sx * (w / 2) - (sx > 0 ? 30 : 0), -d / 2 + 50, 0, sx * (w / 2) + (sx < 0 ? 30 : 0), d / 2 - 50, top - 25, 'mat-steel');
    x.box(w / 2 - 450, -d / 2 + 60, 0, w / 2 - 40, d / 2 - 60, 600, 'mat-paint-white');
    x.box(-w / 2, d / 2 - 30, top, w / 2, d / 2, Math.max(h, top + 300), 'mat-fabric');
    plan.loops.push({ pts: rect(-w / 2, -d / 2, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: rect(-w / 2, d / 2 - 30, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: rect(w / 2 - 450, -d / 2 + 60, w / 2 - 40, d / 2 - 60), closed: true, dash: 1 });
  },
  piano(t, x, plan) {
    // Upright piano: case, keyboard shelf at the front.
    const { width: w, depth: d, height: h } = t;
    x.box(-w / 2, -d / 2 + 250, 0, w / 2, d / 2, h, '#1b1b1b');
    x.box(-w / 2 + 40, -d / 2, 680, w / 2 - 40, -d / 2 + 250, 740, '#f2f2f2');
    plan.loops.push({ pts: rect(-w / 2, -d / 2 + 250, w / 2, d / 2), closed: true });
    plan.loops.push({ pts: rect(-w / 2 + 40, -d / 2, w / 2 - 40, -d / 2 + 250), closed: true });
    const n = 12;
    for (let i = 1; i < n; i++) plan.loops.push({ pts: [[-w / 2 + 40 + ((w - 80) * i) / n, -d / 2], [-w / 2 + 40 + ((w - 80) * i) / n, -d / 2 + 120]] });
  },
};

export const FAMILIES = Object.keys(F);

/**
 * A family made in the project: solids ({ loop, z0, z1, materialId }) around
 * the insertion point, stretched to the type's width, depth and height.
 */
function buildCustom(type, t, x, plan) {
  const sx = t.width / (+type.baseWidth || t.width);
  const sy = t.depth / (+type.baseDepth || t.depth);
  const sz = t.height / (+type.baseHeight || t.height);
  for (const s of type.solids || []) {
    const loop = s.loop.map(([px, py]) => [px * sx, py * sy]);
    x.prism(loop, s.z0 * sz, s.z1 * sz, s.materialId || 'mat-default');
    plan.loops.push({ pts: loop, closed: true });
  }
  plan.outline = rect(-t.width / 2, -t.depth / 2, t.width / 2, t.depth / 2);
  return plan;
}

/** Solids of a custom family from masses: relative to their combined centre and lowest base. */
export function solidsFromMasses(masses, baseOf) {
  const pts = masses.flatMap((m) => m.boundary);
  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  const cx = (Math.min(...xs) + Math.max(...xs)) / 2;
  const cy = (Math.min(...ys) + Math.max(...ys)) / 2;
  const z0 = Math.min(...masses.map(baseOf));
  const solids = masses.map((m) => ({ loop: m.boundary.map((p) => [p[0] - cx, p[1] - cy]), z0: baseOf(m) - z0, z1: baseOf(m) - z0 + (+m.height || 1000), materialId: m.materialId || 'mat-default' }));
  const width = Math.max(...xs) - Math.min(...xs);
  const depth = Math.max(...ys) - Math.min(...ys);
  const height = Math.max(...solids.map((s) => s.z1));
  return { solids, center: [cx, cy], base: z0, width, depth, height };
}

/**
 * Build a component: emits 3D geometry into `builder` (may be null) and
 * returns its plan symbol in local coordinates.
 */
export function buildFamily(type, frame, builder, materialOf, own = {}) {
  const plan = { loops: [], noFill: false, fillColor: null };
  const t = { width: +type?.width || 600, depth: +type?.depth || 600, height: +type?.height || 900 };
  if (type?.family === 'custom') return buildCustom(type, t, new FamilyContext(builder, frame, materialOf), plan);
  if (type?.family === 'gdl') {
    buildGdlFamily(type, own, new FamilyContext(builder, frame, materialOf), plan);
    plan.outline ||= rect(-t.width / 2, -t.depth / 2, t.width / 2, t.depth / 2);
    return plan;
  }
  const fn = F[type?.family] || F.cabinet;
  fn(t, new FamilyContext(builder, frame, materialOf), plan);
  plan.outline = rect(-t.width / 2, -t.depth / 2, t.width / 2, t.depth / 2);
  if (['roundTable', 'tree', 'shrub', 'pendant', 'floorLamp', 'downlight', 'waterHeater', 'bollard', 'sprinkler', 'stool', 'pottedPlant', 'conifer', 'ceilingFan'].includes(type?.family)) plan.outline = ellipse(0, 0, t.width / 2, t.depth / 2, 24);
  return plan;
}
