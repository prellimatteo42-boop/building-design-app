/** Layout Book settings: how layouts are numbered, and the subsets they fall into. */
export const BOOK_DEFAULTS = { prefix: 'A', start: 101, digits: 3, subsets: [] };

export const bookSettings = (project) => ({ ...BOOK_DEFAULTS, ...(project?.bookSettings || {}) });

/** The ID of the layout at a place in the book (from 0). */
export function layoutId(settings, i) {
  return `${settings.prefix}${String(settings.start + i).padStart(+settings.digits || 1, '0')}`;
}

/** The next free ID for a new layout. */
export function nextLayoutId(doc) {
  const s = bookSettings(doc.project);
  const used = new Set(doc.all('sheet').map((x) => x.number));
  let i = doc.all('sheet').length;
  while (used.has(layoutId(s, i))) i++;
  return layoutId(s, i);
}

/** Patches giving the layouts their IDs in book order, within each subset's own run when it has a prefix. */
export function renumberPatches(sheets, settings) {
  const counts = new Map();
  return sheets.map((sh) => {
    const sub = (settings.subsets || []).find((x) => x.name === sh.subset);
    const key = sub?.prefix ? sub.name : '';
    const i = counts.get(key) || 0;
    counts.set(key, i + 1);
    return { id: sh.id, number: layoutId({ ...settings, prefix: sub?.prefix || settings.prefix }, i) };
  });
}
