/**
 * 3D geometry for model elements. Each builder returns a mesh (see
 * mesh.js) in absolute project coordinates, or null.
 *
 * ctx: { doc, walls: WallSolver, material(id) }
 */
import { slantShear, shearMesh } from './slant.js';
import { eaveEdges, addRoofAccessories } from './roofacc.js';
import { MeshBuilder, Frame, hexToRgba } from './mesh.js';
import { add, scale, sub, dot, norm, perp, len, clipHalfPlane, triangulate, pointInPolygon, signedArea } from './geom.js';
import { verticalExtent, openingSize, hostedBy, levelElevation, stairLayout, wallAxis, rampLayout, wallThickness, doorFrameDepth, isHingedDoor, windowAssemblies } from './model.js';
import { cutFace, segmentInside, segmentOutside } from './roofcut.js';
import { buildSweep } from './sweeps.js';
import { buildCladding } from './cladding.js';
import { buildAccessory } from './accessories.js';
import { buildStructural } from './structural.js';
import { buildTruss } from './truss.js';
import { buildImported } from './imported.js';
import { buildModelText } from './modeltext.js';
import { axisParam, hubsOf, axisPoint, axisTangent } from './walls.js';
import { arcSteps } from './arc.js';
import { typeThickness } from './catalog.js';
import { layerShown, shownSpan } from './layerjoins.js';
import { roofFaces, roofHeightAt, verticalThickness, planeHeight, edgeProfile } from './roof.js';
import { runGdlOpening, gdlOpeningCut } from './gdlobject.js';
import { runStairPart, treadGlobals, riserGlobals, structureGlobals, landingPolyFlag, postGlobals, railGlobals, panelGlobals } from './stairparts.js';
import { buildFamily } from './families.js';
import { stairFlights, flightOutline, SPIRAL_CORE } from './stairs.js';
import { mepSize, mepPlan, systemOf, fittingTrim } from './mep.js';
import { fittingSegments } from './mepfittings.js';
import { accessoryFrame, flexPoints3D } from './mepparts.js';
import { accessoryBoxes, junctionPost, glazingGeometry } from './curtainmore.js';
import { schemeLines, parsePattern, frameFor, frameRoles, frameSection, panelFor } from './cwscheme.js';
import { wallEndShape } from './sitetools.js';
import { delaunay, topoSurface } from './topo.js';
import { buildShell } from './shell.js';
import { buildMorph } from './morph.js';
import { buildSkylight, roofHoles } from './skylight.js';
import { profileOf, buildProfiledWall, buildProfiledBeam, buildProfiledColumn } from './profiles.js';

/** How a material shines: 0 matte, 1 satin, 2 glossy. Its own setting, else judged from its name. */
export function materialGloss(m) {
  if (m?.gloss != null) return Math.max(0, Math.min(2, Math.round(+m.gloss)));
  const n = `${m?.id || ''} ${m?.name || ''}`.toLowerCase();
  if (/steel|alumin|metal|chrome|brass|copper|mirror/.test(n)) return 2;
  if (/tile|ceramic|porcelain|marble|paint|lacquer|polish|varnish/.test(n)) return 1;
  return 0;
}

export function materialColor(ctx, id, fallback = '#c8c8c8') {
  const m = id ? ctx.material(id) : null;
  const c = hexToRgba(m?.color || fallback, m?.opacity ?? 1);
  // An opaque surface's shine travels in the last steps of its alpha (255 matte, 254 satin, 253 glossy): the renderer reads it back.
  if (c[3] === 255) c[3] -= materialGloss(m);
  return c;
}

/** Colour of the layer with a given function, or of the thickest layer. */
function layerColor(ctx, type, which) {
  const layers = type?.layers || [];
  if (!layers.length) return materialColor(ctx, null);
  if (which === 'first') return materialColor(ctx, layers[0].materialId);
  if (which === 'last') return materialColor(ctx, layers.at(-1).materialId);
  const core = layers.find((l) => l.function === 'structure') || layers.reduce((a, b) => (b.thickness > a.thickness ? b : a), layers[0]);
  return materialColor(ctx, core.materialId);
}

export function build3D(ctx, el) {
  switch (el.kind) {
    case 'wall': {
      // Slanted walls are built upright, then sheared (slant.js).
      const m = buildWall(ctx, el);
      const F = m && slantShear(ctx.doc, el);
      return F ? shearMesh(m, F) : m;
    }
    case 'wallSweep':
      return buildSweep(ctx, el);
    case 'wallCladding':
      return buildCladding(ctx, el);
    case 'slabAccessory':
    case 'roofAccessory':
    case 'roomAccessory':
      return buildAccessory(ctx, el);
    case 'structuralSupport':
    case 'structuralLoad':
      return buildStructural(ctx, el);
    case 'truss':
      return buildTruss(ctx, el);
    case 'importedModel':
      return buildImported(el);
    case 'modelText':
      return buildModelText(ctx, el);
    case 'floor':
      return buildSlab(ctx, el, 'floor');
    case 'ceiling':
      return buildSlab(ctx, el, 'ceiling');
    case 'roof':
      return buildRoof(ctx, el);
    case 'door':
      return buildDoor(ctx, el);
    case 'window':
      return buildWindow(ctx, el);
    case 'column':
      return buildColumn(ctx, el);
    case 'beam':
      return buildBeam(ctx, el);
    case 'stair':
      return buildStair(ctx, el);
    case 'railing':
      return buildRailing(ctx, el);
    case 'component':
      return buildComponent(ctx, el);
    case 'ramp':
      return buildRamp(ctx, el);
    case 'modelLine':
      return buildModelLine(ctx, el);
    case 'footing':
      return buildFooting(ctx, el);
    case 'wallFooting':
      return buildWallFooting(ctx, el);
    case 'brace':
      return buildBrace(ctx, el);
    case 'mepFitting':
      return buildFitting(ctx, el);
    case 'mepAccessory':
      return buildMepAccessory(ctx, el);
    case 'cwJunction':
      return buildJunction(ctx, el);
    case 'wallEnd': {
      const s = wallEndShape(ctx.doc, el);
      if (!s) return null;
      const w = ctx.doc.get(el.wallId);
      const b = new MeshBuilder();
      b.prism(s.outline, [], s.base, s.top, layerColor(ctx, ctx.doc.get(w.typeId), 'core'));
      return b.build();
    }
    case 'glazedRoof':
      return buildGlazedRoof(ctx, el);
    case 'mepFlex':
      return buildFlex(ctx, el);
    case 'duct':
    case 'pipe':
    case 'cableTray':
    case 'conduit':
      return buildMep(ctx, el);
    case 'topo':
      return buildTopo(ctx, el);
    case 'mass':
      return buildMass(ctx, el);
    case 'shell':
      return buildShell(ctx, el, materialColor(ctx, el.materialId || 'mat-concrete'));
    case 'skylight':
      return buildSkylight(ctx.doc, el, materialColor(ctx, 'mat-aluminum'), materialColor(ctx, 'mat-glass'));
    case 'morph':
      return buildMorph(ctx, el, el.tris ? null : materialColor(ctx, el.materialId || 'mat-default'));
    default:
      return null;
  }
}

// Foundations, bracing, services, site and masses ------------------------------------------------

/** Plan outline of an isolated footing. */
export function footingOutline(doc, el) {
  const t = doc.get(el.typeId) || {};
  const w = +t.width || 1200;
  const l = +t.length || w;
  const fr = new Frame(el.at, ((+el.rotation || 0) * Math.PI) / 180);
  return [
    [-w / 2, -l / 2],
    [w / 2, -l / 2],
    [w / 2, l / 2],
    [-w / 2, l / 2],
  ].map((p) => fr.apply(p));
}

function buildFooting(ctx, el) {
  const t = ctx.doc.get(el.typeId) || {};
  const top = levelElevation(ctx.doc, el.levelId) + (+el.offset || 0);
  const b = new MeshBuilder();
  b.prism(footingOutline(ctx.doc, el), [], top - (+t.thickness || 450), top, materialColor(ctx, t.materialId || 'mat-concrete'));
  return b.build();
}

/** Plan outline of a wall foundation: the strip under its wall, past the free ends. */
export function wallFootingOutline(doc, el) {
  const w = doc.get(el.wallId);
  // Wall footings follow straight walls only.
  if (!w || w.arc) return null;
  const t = doc.get(el.typeId) || {};
  const width = +t.width || 600;
  const ax = wallAxis(doc, w);
  const ext = width / 2 - ax.half;
  const a = sub(ax.a, scale(ax.dir, Math.max(0, ext)));
  const c = add(ax.b, scale(ax.dir, Math.max(0, ext)));
  const hw = scale(ax.n, width / 2);
  return [sub(a, hw), sub(c, hw), add(c, hw), add(a, hw)];
}

function buildWallFooting(ctx, el) {
  const w = ctx.doc.get(el.wallId);
  const outline = wallFootingOutline(ctx.doc, el);
  if (!w || !outline) return null;
  const t = ctx.doc.get(el.typeId) || {};
  const { base } = verticalExtent(ctx.doc, w);
  const b = new MeshBuilder();
  b.prism(outline, [], base - (+t.thickness || 300), base, materialColor(ctx, t.materialId || 'mat-concrete'));
  return b.build();
}

/** End heights of a brace. */
export function braceHeights(doc, el) {
  const z0 = levelElevation(doc, el.levelId) + (+el.baseOffset || 0);
  const z1 = el.topLevelId && doc.get(el.topLevelId) ? levelElevation(doc, el.topLevelId) + (+el.topOffset || 0) : z0 + (+el.height || 3000);
  return { z0, z1 };
}

function buildBrace(ctx, el) {
  const t = ctx.doc.get(el.typeId) || {};
  const { z0, z1 } = braceHeights(ctx.doc, el);
  const b = new MeshBuilder();
  b.beam3([el.a[0], el.a[1], z0], [el.b[0], el.b[1], z1], +t.width || 200, +t.depth || 200, materialColor(ctx, t.materialId || 'mat-steel'));
  return b.build();
}

function buildMep(ctx, el) {
  if (!el.a || !el.b) return null;
  const { round, w, h } = mepSize(ctx.doc, el);
  const z = levelElevation(ctx.doc, el.levelId) + (+el.offset || 0);
  // A sloping run ends at endOffset; one with both ends at the same plan point is a riser.
  const zEnd = el.endOffset != null ? levelElevation(ctx.doc, el.levelId) + +el.endOffset : z;
  const col = hexToRgba(systemOf(el).color);
  const b = new MeshBuilder();
  if (Math.hypot(el.b[0] - el.a[0], el.b[1] - el.a[1]) < 1) {
    if (Math.abs(zEnd - z) < 1) return null;
    const lo = Math.min(z, zEnd) - (round ? 0 : 0);
    const hi = Math.max(z, zEnd);
    if (round) b.tube([el.a[0], el.a[1], lo], [el.a[0], el.a[1], hi], w / 2, col, { segments: el.kind === 'conduit' ? 8 : 16 });
    else b.beam3([el.a[0], el.a[1], lo], [el.a[0], el.a[1], hi], w, h, col, { up: [1, 0, 0] });
    return b.build();
  }
  const { a, b: e } = mepPlan(ctx.doc, el);
  // The slope carries over the extensions at the ends.
  const L = Math.hypot(el.b[0] - el.a[0], el.b[1] - el.a[1]);
  const zAt = (p) => z + ((zEnd - z) * ((p[0] - el.a[0]) * (el.b[0] - el.a[0]) + (p[1] - el.a[1]) * (el.b[1] - el.a[1]))) / (L * L);
  if (round) b.tube([a[0], a[1], zAt(a)], [e[0], e[1], zAt(e)], w / 2, col, { segments: el.kind === 'conduit' ? 8 : 16 });
  else b.beam3([a[0], a[1], zAt(a)], [e[0], e[1], zAt(e)], w, h, col);
  // Fittings where runs meet: a sleeve on this run, and the joint itself
  // (drawn by one of the runs that meet there).
  if (el.kind === 'duct' || el.kind === 'pipe') {
    const len = Math.hypot(el.b[0] - el.a[0], el.b[1] - el.a[1]);
    const d = len > 1e-6 ? [(el.b[0] - el.a[0]) / len, (el.b[1] - el.a[1]) / len] : [1, 0];
    const fit = [Math.round(col[0] * 0.82), Math.round(col[1] * 0.82), Math.round(col[2] * 0.82), col[3]];
    for (const [p, into] of [
      [el.a, d],
      [el.b, [-d[0], -d[1]]],
    ]) {
      if (fittingTrim(ctx.doc, el, p === el.a ? 0 : 1) != null) continue;
      const others = ctx.doc.all(el.kind).filter((o) => o.id !== el.id && o.levelId === el.levelId && ((Math.abs(o.a[0] - p[0]) < 1 && Math.abs(o.a[1] - p[1]) < 1) || (Math.abs(o.b[0] - p[0]) < 1 && Math.abs(o.b[1] - p[1]) < 1)));
      if (!others.length) continue;
      const pz = p === el.a ? z : zEnd;
      const at = (s) => [p[0] + into[0] * s, p[1] + into[1] * s, pz];
      if (round) {
        const r = w / 2;
        b.tube(at(r * 0.9), at(r * 1.6), r * 1.15, fit, { segments: 16 });
        if (others.every((o) => o.id > el.id)) b.sphere([p[0], p[1], pz], r * 1.12, fit, { segments: 16, rings: 10 });
      } else {
        b.beam3(at(w / 2), at(w / 2 + 60), w + 30, h + 30, fit);
        if (others.every((o) => o.id > el.id)) b.beam3([p[0] - w * 0.55 * into[0], p[1] - w * 0.55 * into[1], pz], [p[0] + w * 0.55 * into[0], p[1] + w * 0.55 * into[1], pz], w * 1.1, h * 1.05, fit);
      }
    }
  }
  return b.build();
}

/** An MEP fitting (mepfittings.js): its pieces, with a collar where each run joins. */
function buildFitting(ctx, f) {
  const col = hexToRgba(systemOf({ kind: f.family, system: f.system }).color);
  const cuff = [Math.round(col[0] * 0.82), Math.round(col[1] * 0.82), Math.round(col[2] * 0.82), col[3]];
  const b = new MeshBuilder();
  const piece = (a, c, size, color, grow = 1) => {
    if (Math.hypot(c[0] - a[0], c[1] - a[1], c[2] - a[2]) < 0.5) return;
    if (size.round) b.tube(a, c, (size.w / 2) * grow, color, { segments: f.family === 'conduit' ? 8 : 16 });
    else b.beam3(a, c, size.w * grow, size.h * grow, color);
  };
  for (const sgm of fittingSegments(f)) piece(sgm.a, sgm.b, sgm.size, col);
  const p = [f.at[0], f.at[1], f.z];
  // An end cap: a plate a little larger than the run.
  if (f.fittingType === 'cap') {
    const e = f.ends[0];
    const t = 6;
    piece([f.at[0] - e.dir[0] * t, f.at[1] - e.dir[1] * t, f.z - e.dir[2] * t], [f.at[0], f.at[1], f.z], e.size, cuff, 1.1);
  }
  if (f.fittingType === 'tee' || f.fittingType === 'cross' || f.fittingType === 'wye') {
    if (f.size.round) b.sphere(p, (f.size.w / 2) * 1.04, col, { segments: 16, rings: 10 });
    else b.beam3([p[0], p[1], p[2] - (f.size.h / 2) * 1.02], [p[0], p[1], p[2] + (f.size.h / 2) * 1.02], f.size.w * 1.02, f.size.w * 1.02, col, { up: [1, 0, 0] });
  }
  for (const e of f.ends) {
    const q = [p[0] + e.dir[0] * e.trim, p[1] + e.dir[1] * e.trim, p[2] + e.dir[2] * e.trim];
    const L = Math.min(40, e.trim / 3);
    piece([q[0] - e.dir[0] * L, q[1] - e.dir[1] * L, q[2] - e.dir[2] * L], q, e.size, cuff, 1.08);
  }
  return b.build();
}

/** An in-line accessory: a housing a little larger than its run, with a handle or a wheel on valves. */
function buildMepAccessory(ctx, el) {
  const f = accessoryFrame(ctx.doc, el);
  if (!f) return null;
  const col = hexToRgba(systemOf(f.run).color);
  const body = [Math.round(col[0] * 0.7), Math.round(col[1] * 0.7), Math.round(col[2] * 0.7), col[3]];
  const b = new MeshBuilder();
  const h = f.length / 2;
  const a = [f.c[0] - f.d[0] * h, f.c[1] - f.d[1] * h, f.c[2] - f.d[2] * h];
  const c = [f.c[0] + f.d[0] * h, f.c[1] + f.d[1] * h, f.c[2] + f.d[2] * h];
  const grow = f.family === 'pipe' ? 1.5 : 1.12;
  if (f.size.round) b.tube(a, c, (f.size.w / 2) * grow, body, { segments: 16 });
  else b.beam3(a, c, f.size.w * grow, f.size.h * grow, body);
  const top = (f.size.h / 2) * grow;
  if (['valve', 'gateValve', 'damper', 'fireDamper'].includes(f.info.value)) {
    // A stem up from the body, and a handwheel or lever on it.
    const s0 = [f.c[0], f.c[1], f.c[2] + top];
    const s1 = [f.c[0], f.c[1], f.c[2] + top + Math.max(40, f.size.w * (f.family === 'pipe' ? 1.2 : 0.25))];
    b.tube(s0, s1, Math.max(4, f.size.w * 0.08), body, { segments: 8 });
    const r = f.family === 'pipe' ? f.size.w * 0.9 : Math.min(120, f.size.w * 0.3);
    b.cylinder([s1[0], s1[1]], r, s1[2], s1[2] + Math.max(6, r * 0.15), body, { segments: 16 });
  }
  return b.build();
}

/** A flexible segment: a tube along its curve. */
function buildFlex(ctx, el) {
  const pts = flexPoints3D(ctx.doc, el);
  if (pts.length < 2) return null;
  const col = hexToRgba(systemOf({ kind: el.family, system: el.system }).color);
  const r = (+el.diameter || 200) / 2;
  const b = new MeshBuilder();
  for (let i = 1; i < pts.length; i++) b.tube(pts[i - 1], pts[i], r, col, { segments: 12, edges: false, caps: i === 1 || i === pts.length - 1 });
  // Corrugation rings every diameter or so on ducts.
  if (el.family === 'duct')
    for (let i = 2; i < pts.length - 1; i += 2) {
      const p = pts[i];
      const q = pts[i + 1];
      const m = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2, (p[2] + q[2]) / 2];
      const d = [q[0] - p[0], q[1] - p[1], q[2] - p[2]];
      const l = Math.hypot(d[0], d[1], d[2]) || 1;
      const e = Math.min(r * 0.08, l / 4);
      b.tube([m[0] - (d[0] / l) * e, m[1] - (d[1] / l) * e, m[2] - (d[2] / l) * e], [m[0] + (d[0] / l) * e, m[1] + (d[1] / l) * e, m[2] + (d[2] / l) * e], r * 1.04, col, { segments: 12 });
    }
  return b.build();
}

function buildTopo(ctx, el) {
  const { P, tris } = topoSurface(el);
  if (P.length < 3 || !tris.length) return null;
  const col = materialColor(ctx, el.materialId || 'mat-earth');
  const zMin = Math.min(...P.map((p) => p[2])) - (+el.thickness || 1000);
  const b = new MeshBuilder();
  const count = new Map();
  for (const [i, j, k] of tris) {
    const A = P[i];
    const C = P[j];
    const D = P[k];
    orientedTri(b, A, C, D, col, true);
    orientedTri(b, [A[0], A[1], zMin], [C[0], C[1], zMin], [D[0], D[1], zMin], col, false);
    for (const [u, v] of [
      [i, j],
      [j, k],
      [k, i],
    ]) {
      const key = u < v ? `${u},${v}` : `${v},${u}`;
      count.set(key, (count.get(key) || 0) + 1);
    }
  }
  // Skirt along the outer edges (used by one triangle only).
  for (const [key, n] of count) {
    if (n !== 1) continue;
    const [u, v] = key.split(',').map(Number);
    const p = P[u];
    const q = P[v];
    b.quad([p[0], p[1], zMin], [q[0], q[1], zMin], q, p, col);
    b.edge(p, q);
    b.edge([p[0], p[1], zMin], [q[0], q[1], zMin]);
  }
  // Ridges are drawn as edges (on the surface between their divided points).
  for (const r of el.ridges || []) for (let i = 0; i + 1 < r.length; i++) b.edge([r[i][0], r[i][1], r[i][2] ?? 0], [r[i + 1][0], r[i + 1][1], r[i + 1][2] ?? 0]);
  return b.build();
}

function buildMass(ctx, el) {
  if (!el.boundary || el.boundary.length < 3) return null;
  const base = levelElevation(ctx.doc, el.levelId) + (+el.baseOffset || 0);
  const b = new MeshBuilder();
  b.prism(el.boundary, el.holes || [], base, base + (+el.height || 10000), [176, 190, 214, 110]);
  return b.build();
}

// Ramps and model lines -------------------------------------------------------------------

function buildRamp(ctx, el) {
  const g = rampLayout(ctx.doc, el);
  if (g.run < 1) return null;
  const type = ctx.doc.get(el.typeId) || {};
  const col = materialColor(ctx, type.materialId || 'mat-concrete');
  const b = new MeshBuilder();
  const origin = add(el.a, scale(g.side, -g.width / 2));
  const th = g.thickness;
  b.extrudeProfile(
    [
      [0, g.base - th],
      [g.run, g.top - th],
      [g.run, g.top],
      [0, g.base],
    ],
    origin,
    g.dir,
    g.width,
    col,
  );
  if (el.railings !== false) {
    const rail = materialColor(ctx, 'mat-steel');
    const H = 900;
    for (const off of [50, g.width - 50]) {
      const p0 = add(origin, scale(g.side, off));
      b.extrudeProfile(
        [
          [0, g.base + H - 40],
          [g.run, g.top + H - 40],
          [g.run, g.top + H],
          [0, g.base + H],
        ],
        add(p0, scale(g.side, -20)),
        g.dir,
        40,
        rail,
      );
      const posts = Math.max(2, Math.round(g.run / 1200) + 1);
      for (let i = 0; i < posts; i++) {
        const s = (g.run * i) / (posts - 1);
        const z = g.base + (g.rise * s) / g.run;
        b.cylinder(add(p0, scale(g.dir, s)), 15, z, z + H - 40, rail, { segments: 8, edges: false });
      }
    }
  }
  return b.build();
}

function buildModelLine(ctx, el) {
  if (!el.a || !el.b) return null;
  const z = levelElevation(ctx.doc, el.levelId) + (+el.offset || 0);
  const b = new MeshBuilder();
  b.edge([el.a[0], el.a[1], z], [el.b[0], el.b[1], z]);
  return b.build();
}

// Walls -----------------------------------------------------------------------------

/**
 * Openings of a wall as axis intervals and absolute heights; a GDL door or
 * window whose hole is not a rectangle (round, arched) also has its outline
 * as `shape`: [u, z] points. A GDL niche that does not go through (a wall
 * niche object) is left out, unless `recesses` asks for it: then it comes
 * with `recess: { side, depth }`, side the wall's face it is cut into (+1
 * along the wall's left normal, -1 the right).
 */
export function wallOpenings(doc, wall, base, top, { recesses = false } = {}) {
  const out = [];
  for (const el of hostedBy(doc, wall.id)) {
    const { width, height, sill } = openingSize(doc, el);
    const z0 = base + sill;
    const z1 = Math.min(top, z0 + height);
    if (z1 - z0 < 1 || width < 1) continue;
    const o = { id: el.id, u0: el.t - width / 2, u1: el.t + width / 2, z0: Math.max(base, z0), z1, kind: el.kind };
    // A corner window opens its wall right to the end at the corner (el.corner: 'a' or 'b'), through the joint.
    if (el.kind === 'window' && (el.corner === 'a' || el.corner === 'b')) o.corner = el.corner;
    const type = doc.get(el.typeId);
    if (type?.family === 'gdl' && el.kind !== 'opening') {
      const { shape, recess } = gdlOpeningCut(type, { width, height, thickness: wallThickness(doc, wall), wallHeight: top - base }, el.gdlValues || {});
      if (recess) {
        if (!recesses) continue;
        const pts = recess.outline.map(([x, y]) => [el.t + x, z0 + y]);
        const us = pts.map((p) => p[0]);
        const zs = pts.map((p) => p[1]);
        // Inside the wall's height only: a niche reaching its base or top is left out.
        if (Math.min(...zs) <= base + 0.5 || Math.max(...zs) >= top - 0.5) continue;
        const face = (el.flipFacing ? -1 : 1) * (wall.flipped ? -1 : 1);
        Object.assign(o, { u0: Math.min(...us), u1: Math.max(...us), z0: Math.min(...zs), z1: Math.max(...zs), shape: pts, recess: { side: recess.opposite ? -face : face, depth: recess.depth } });
      } else if (shape && z0 + height <= top + 0.5) o.shape = shape.map(([x, y]) => [el.t + x, z0 + y]);
    }
    out.push(o);
  }
  return out.sort((a, b) => a.u0 - b.u0);
}

/**
 * The sides of an opening's hole in (u, z), for its reveals and edges: its
 * outline's edges (but not along the wall's base or top, which it opens),
 * or a rectangle's four.
 */
function openingSides(o, base, top) {
  const pts = o.shape || [[o.u0, o.z0], [o.u1, o.z0], [o.u1, o.z1], [o.u0, o.z1]];
  const out = [];
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    const q = pts[(i + 1) % pts.length];
    if (Math.hypot(q[0] - p[0], q[1] - p[1]) < 0.01) continue;
    // A corner window has no jamb at the corner: the wall ends there.
    if (o.corner && Math.abs(p[0] - q[0]) < 0.01 && Math.abs(p[0] - (o.corner === 'a' ? o.u0 : o.u1)) < 0.01) continue;
    if (p[1] <= base + 0.5 && q[1] <= base + 0.5) continue;
    if (p[1] >= top - 0.5 && q[1] >= top - 0.5) continue;
    out.push([p, q]);
  }
  return out;
}

/**
 * Where an opening touching the wall's base takes a notch out of a face's
 * outline: the points from its bottom left, up and over, to its bottom right.
 */
function notchPath(o, base) {
  if (!o.shape) return [[o.u0, base], [o.u0, o.z1], [o.u1, o.z1], [o.u1, base]];
  const pts = o.shape;
  const low = pts.map((p, i) => [p, i]).filter(([p]) => p[1] <= base + 0.5);
  if (low.length < 2) return [[o.u0, base], [o.u0, o.z1], [o.u1, o.z1], [o.u1, base]];
  const left = low.reduce((a, b) => (b[0][0] < a[0][0] ? b : a))[1];
  const right = low.reduce((a, b) => (b[0][0] > a[0][0] ? b : a))[1];
  // Walk from the bottom left the way that rises first.
  const n = pts.length;
  const walk = (step) => {
    const path = [];
    for (let k = 0, i = left; k <= n; k++, i = (i + step + n) % n) {
      path.push([pts[i][0], Math.max(base, pts[i][1])]);
      if (i === right) return path;
    }
    return null;
  };
  const a = walk(1);
  const b = walk(-1);
  const rises = (path) => path && path.length > 2 && path.slice(1, -1).some((p) => p[1] > base + 0.5);
  const path = rises(a) ? a : rises(b) ? b : null;
  return path ? [[path[0][0], base], ...path.slice(1, -1), [path.at(-1)[0], base]] : [[o.u0, base], [o.u0, o.z1], [o.u1, o.z1], [o.u1, base]];
}

function buildWall(ctx, w) {
  const g = ctx.walls.wall(w.id);
  if (!g) return null;
  const type = ctx.doc.get(w.typeId);
  if (type?.curtain) return buildCurtainWall(ctx, w, g, type);
  // A profiled wall (profiles.js) is its profile along the reference line, openings cut through.
  const prof = profileOf(ctx.doc, w);
  if (prof && !g.axis.curve) return buildProfiledWall(ctx.doc, w, prof, g.base, g.top, wallOpenings(ctx.doc, w, g.base, g.top));
  const b = new MeshBuilder();
  const { axis, base, top } = g;
  const { dir, n, half } = axis;
  const ext = layerColor(ctx, type, 'first');
  const int = layerColor(ctx, type, 'last');
  const core = layerColor(ctx, type, 'core');
  const leftCol = w.flipped ? int : ext;
  const rightCol = w.flipped ? ext : int;

  const uL0 = axisParam(axis, g.L0);
  const uL1 = axisParam(axis, g.L1);
  const uR0 = axisParam(axis, g.R0);
  const uR1 = axisParam(axis, g.R1);
  const lo = Math.max(uL0, uR0) + 1;
  const hi = Math.min(uL1, uR1) - 1;
  const all = wallOpenings(ctx.doc, w, base, top, { recesses: true })
    .map((o) => ({ ...o, u0: o.corner === 'a' ? Math.min(uL0, uR0) - 1 : Math.max(o.u0, lo), u1: o.corner === 'b' ? Math.max(uL1, uR1) + 1 : Math.min(o.u1, hi) }))
    .filter((o) => o.u1 - o.u0 > 1);
  // Niches into one face (wall niche objects): built on a plain straight wall, left out elsewhere.
  const ops = all.filter((o) => !o.recess);
  const niches = all.filter((o) => o.recess && o.recess.depth < 2 * half - 1);

  const P = (u, side, z) => [axis.a[0] + dir[0] * u + n[0] * side * half, axis.a[1] + dir[1] * u + n[1] * side * half, z];

  // Partial structure display (layerjoins.js): only some layers, or none.
  const show = ctx.show || 'entire';
  const partial = show !== 'entire';
  const layers = type?.layers || [];
  if (partial && !(layers.length ? layers : [{ function: 'structure' }]).some((l) => layerShown(show, l, w))) return null;

  if (axis.curve) return buildCurvedWall(ctx, w, g, ops, { leftCol, rightCol, core, show });

  const roofTop = attachedTop(ctx.doc, w, base);
  if (roofTop) {
    buildAttachedWall(b, { g, axis, base, top, ops, P, roofTop, leftCol, rightCol, core, uL0, uL1, uR0, uR1 });
    for (const hub of hubsOf(ctx.walls.level(w.levelId), w.id)) b.prism(hub.poly, [], hub.base, hub.top, core, { edges: false });
    return b.build();
  }

  const topCuts = ops.filter((o) => o.z1 >= top - 0.5).map((o) => [o.u0, o.u1]);
  const botCuts = ops.filter((o) => o.z0 <= base + 0.5).map((o) => [o.u0, o.u1]);
  const layered = layers.length > 1;
  if (layered) layeredSolids(ctx, b, w, g, layers, ops, topCuts, botCuts, partial ? (l) => layerShown(show, l, w) : null, niches);
  else {
    // Side faces, each with the niches cut into it.
    const right = faceLoops(uR0, uR1, base, top, [...ops, ...niches.filter((o) => o.recess.side < 0)]);
    const left = faceLoops(uL0, uL1, base, top, [...ops, ...niches.filter((o) => o.recess.side > 0)]);
    const oR = [axis.a[0] - n[0] * half, axis.a[1] - n[1] * half, 0];
    const oL = [axis.a[0] + n[0] * half, axis.a[1] + n[1] * half, 0];
    for (const f of right) b.planar(oR, [dir[0], dir[1], 0], [0, 0, 1], f.outer, f.holes, rightCol);
    for (const f of left)
      b.planar(
        oL,
        [-dir[0], -dir[1], 0],
        [0, 0, 1],
        f.outer.map((p) => [-p[0], p[1]]),
        f.holes.map((hh) => hh.map((p) => [-p[0], p[1]])),
        leftCol,
      );

    // Reveals, along each side of the hole.
    for (const o of ops) for (const [p, q] of openingSides(o, base, top)) b.quad(P(p[0], -1, p[1]), P(q[0], -1, q[1]), P(q[0], 1, q[1]), P(p[0], 1, p[1]), core);
    // Niches: their sides from the face to their depth, and their back.
    for (const o of niches) {
      const s0 = o.recess.side;
      const s1 = s0 * (1 - o.recess.depth / half);
      for (const [p, q] of openingSides(o, base, top)) s0 > 0 ? b.quad(P(p[0], s1, p[1]), P(q[0], s1, q[1]), P(q[0], s0, q[1]), P(p[0], s0, p[1]), core) : b.quad(P(p[0], s0, p[1]), P(q[0], s0, q[1]), P(q[0], s1, q[1]), P(p[0], s1, p[1]), core);
      const o0 = [axis.a[0] + n[0] * s1 * half, axis.a[1] + n[1] * s1 * half, 0];
      if (s0 < 0) b.planar(o0, [dir[0], dir[1], 0], [0, 0, 1], o.shape, [], core);
      else b.planar(o0, [-dir[0], -dir[1], 0], [0, 0, 1], o.shape.map((p) => [-p[0], p[1]]), [], core);
    }

    // Top and bottom, interrupted by openings that reach them.
    const poly = [g.R0, g.R1, g.L1, g.L0];
    for (const part of splitByCuts(poly, axis, topCuts)) b.horizontal(part, [], top, true, core);
    for (const part of splitByCuts(poly, axis, botCuts)) b.horizontal(part, [], base, false, core);

    // Square ends.
    if (g.ends[0].kind === 'free') b.quad([g.L0[0], g.L0[1], base], [g.R0[0], g.R0[1], base], [g.R0[0], g.R0[1], top], [g.L0[0], g.L0[1], top], core);
    if (g.ends[1].kind === 'free') b.quad([g.R1[0], g.R1[1], base], [g.L1[0], g.L1[1], base], [g.L1[0], g.L1[1], top], [g.R1[0], g.R1[1], top], core);
  }

  // Hubs owned by this wall, in its core.
  if (layered) b.part = Math.max(0, layers.findIndex((l) => l.function === 'structure'));
  for (const hub of hubsOf(ctx.walls.level(w.levelId), w.id)) b.prism(hub.poly, [], hub.base, hub.top, core, { edges: false });
  // Shown layers carry their own edges.
  if (partial && layered) {
    const mesh = b.build();
    mesh.partMaterials = layers.map((l) => l.materialId ?? null);
    return mesh;
  }

  // Edges.
  const faceEdges = (side, u0, u1) => {
    for (const z of [base, top]) {
      const cuts = z === top ? topCuts : botCuts;
      for (const [s0, s1] of keepIntervals(u0, u1, cuts)) b.edge(P(s0, side, z), P(s1, side, z));
    }
  };
  faceEdges(1, uL0, uL1);
  faceEdges(-1, uR0, uR1);
  const endEdges = (e, L, R) => {
    const info = g.ends[e];
    if (info.kind === 'free') {
      b.edge([L[0], L[1], base], [R[0], R[1], base]);
      b.edge([L[0], L[1], top], [R[0], R[1], top]);
    }
    if (info.kind !== 'corner' || info.angle > 0.05) {
      b.edge([L[0], L[1], base], [L[0], L[1], top]);
      b.edge([R[0], R[1], base], [R[0], R[1], top]);
    }
  };
  endEdges(0, g.L0, g.R0);
  endEdges(1, g.L1, g.R1);
  for (const o of ops) for (const side of [-1, 1]) for (const [p, q] of openingSides(o, base, top)) b.edge(P(p[0], side, p[1]), P(q[0], side, q[1]));
  for (const o of niches) for (const side of [o.recess.side, o.recess.side * (1 - o.recess.depth / half)]) for (const [p, q] of openingSides(o, base, top)) b.edge(P(p[0], side, p[1]), P(q[0], side, q[1]));
  const mesh = b.build();
  // Which material each part is, for section cuts (elevation.js).
  if (layered) mesh.partMaterials = layers.map((l) => l.materialId ?? null);
  return mesh;
}

/**
 * A curved wall: its faces as strips along the arc (split at openings),
 * curved top and bottom bands, radial reveals and ends. Partial structure
 * display keeps the span of the layers it shows.
 */
function buildCurvedWall(ctx, w, g, ops, { leftCol, rightCol, core, show }) {
  const { axis, base, top } = g;
  const span = shownSpan(ctx.doc, w, show, axis.half);
  if (!span) return null;
  const b = new MeshBuilder();
  const oL = span.hi;
  const oR = span.lo;
  const uL0 = axisParam(axis, g.L0);
  const uL1 = axisParam(axis, g.L1);
  const uR0 = axisParam(axis, g.R0);
  const uR1 = axisParam(axis, g.R1);
  const P = (u, off, z) => {
    const p = axisPoint(axis, u, off);
    return [p[0], p[1], z];
  };
  // Samples along [u0, u1] with the opening edges among them.
  const samples = (u0, u1) => {
    const us = new Set(arcSteps(axis.curve, u0, u1));
    for (const o of ops) for (const u of [o.u0, o.u1]) if (u > u0 && u < u1) us.add(u);
    return [...us].sort((x, y) => x - y);
  };
  // Heights left open at u by openings: [z0, z1] intervals of wall.
  const solid = (u) => {
    let parts = [[base, top]];
    for (const o of ops)
      if (u > o.u0 && u < o.u1) parts = parts.flatMap(([a, c]) => [[a, Math.min(c, o.z0)], [Math.max(a, o.z1), c]]).filter(([a, c]) => c - a > 0.5);
    return parts;
  };
  const face = (u0, u1, off, col, left) => {
    const us = samples(u0, u1);
    for (let i = 0; i + 1 < us.length; i++) {
      const [ua, ub] = [us[i], us[i + 1]];
      for (const [z0, z1] of solid((ua + ub) / 2)) {
        if (left) b.quad(P(ub, off, z0), P(ua, off, z0), P(ua, off, z1), P(ub, off, z1), col);
        else b.quad(P(ua, off, z0), P(ub, off, z0), P(ub, off, z1), P(ua, off, z1), col);
      }
    }
    // Edges along the top and bottom of the face.
    for (let i = 0; i + 1 < us.length; i++) {
      b.edge(P(us[i], off, top), P(us[i + 1], off, top));
      b.edge(P(us[i], off, base), P(us[i + 1], off, base));
    }
  };
  face(uL0, uL1, oL, leftCol, true);
  face(uR0, uR1, oR, rightCol, false);
  // Top and bottom bands, the faces' ends following the joins.
  const lo = Math.min(uL0, uR0);
  const hi = Math.max(uL1, uR1);
  const clampL = (u) => Math.max(uL0, Math.min(uL1, u));
  const clampR = (u) => Math.max(uR0, Math.min(uR1, u));
  const us = samples(lo, hi);
  for (let i = 0; i + 1 < us.length; i++) {
    const [ua, ub] = [us[i], us[i + 1]];
    const m = (ua + ub) / 2;
    const quad = [axisPoint(axis, clampR(ua), oR), axisPoint(axis, clampR(ub), oR), axisPoint(axis, clampL(ub), oL), axisPoint(axis, clampL(ua), oL)];
    const reachTop = ops.some((o) => m > o.u0 && m < o.u1 && o.z1 >= top - 0.5);
    const reachBase = ops.some((o) => m > o.u0 && m < o.u1 && o.z0 <= base + 0.5);
    if (!reachTop) b.horizontal(quad, [], top, true, core);
    if (!reachBase) b.horizontal(quad, [], base, false, core);
  }
  // Reveals of openings: jambs across the wall, head and sill as bands.
  for (const o of ops) {
    b.quad(P(o.u0, oR, o.z0), P(o.u0, oL, o.z0), P(o.u0, oL, o.z1), P(o.u0, oR, o.z1), core);
    b.quad(P(o.u1, oL, o.z0), P(o.u1, oR, o.z0), P(o.u1, oR, o.z1), P(o.u1, oL, o.z1), core);
    const os = arcSteps(axis.curve, o.u0, o.u1);
    for (let i = 0; i + 1 < os.length; i++) {
      const [ua, ub] = [os[i], os[i + 1]];
      if (o.z1 < top - 0.5) b.quad(P(ua, oR, o.z1), P(ua, oL, o.z1), P(ub, oL, o.z1), P(ub, oR, o.z1), core);
      if (o.z0 > base + 0.5) b.quad(P(ua, oR, o.z0), P(ub, oR, o.z0), P(ub, oL, o.z0), P(ua, oL, o.z0), core);
    }
    for (const off of [oL, oR]) {
      b.edge(P(o.u0, off, o.z0), P(o.u0, off, o.z1));
      b.edge(P(o.u1, off, o.z0), P(o.u1, off, o.z1));
    }
  }
  // Free ends.
  if (g.ends[0].kind === 'free') {
    b.quad(P(uL0, oL, base), P(uR0, oR, base), P(uR0, oR, top), P(uL0, oL, top), core);
    b.edge(P(uL0, oL, base), P(uL0, oL, top));
    b.edge(P(uR0, oR, base), P(uR0, oR, top));
  }
  if (g.ends[1].kind === 'free') {
    b.quad(P(uR1, oR, base), P(uL1, oL, base), P(uL1, oL, top), P(uR1, oR, top), core);
    b.edge(P(uL1, oL, base), P(uL1, oL, top));
    b.edge(P(uR1, oR, base), P(uR1, oR, top));
  }
  for (const hub of hubsOf(ctx.walls.level(w.levelId), w.id)) b.prism(hub.poly, [], hub.base, hub.top, core, { edges: false });
  return b.build();
}

/**
 * A wall of several layers as one closed solid per layer in the layer's
 * material: its two faces, the reveals of openings, top, bottom and free
 * ends. Layer ends follow the wall's joined ends (the segment from R to L at
 * each end), as in plan. Each triangle carries its layer index (mesh parts).
 * With `keep` only the layers it accepts are built, each with its outline
 * edges (the wall's own edges are on faces that may be left out).
 */
function layeredSolids(ctx, b, w, g, layers, ops, topCuts, botCuts, keep = null, niches = []) {
  const { axis, base, top } = g;
  const { dir, n, half } = axis;
  const total = layers.reduce((sum, l) => sum + (+l.thickness || 0), 0) || 1;
  // The first layer is on the exterior face: left (+n) unless flipped.
  const ext = w.flipped ? -1 : 1;
  const Q = (u, o, z) => [axis.a[0] + dir[0] * u + n[0] * o, axis.a[1] + dir[1] * u + n[1] * o, z];
  const endAt = (o, e) => {
    const L = e ? g.L1 : g.L0;
    const R = e ? g.R1 : g.R0;
    const t = (o + half) / (2 * half);
    return [R[0] + (L[0] - R[0]) * t, R[1] + (L[1] - R[1]) * t];
  };
  const up3 = (p, z) => [p[0], p[1], z];
  b.parts = [];
  let acc = 0;
  layers.forEach((layer, k) => {
    const oa = ext * (half - (2 * half * acc) / total);
    acc += +layer.thickness || 0;
    const ob = ext * (half - (2 * half * acc) / total);
    const lo = Math.min(oa, ob);
    const hi = Math.max(oa, ob);
    if (hi - lo < 0.01 || (keep && !keep(layer))) return;
    b.part = k;
    const col = materialColor(ctx, layer.materialId);
    // Niches into a face, where they reach this layer: [a, b] their span across the wall, `back` their
    // inner plane when it lies within the layer.
    const cuts = niches
      .map((o) => {
        const face = o.recess.side * half;
        const inner = o.recess.side * (half - o.recess.depth);
        const [a, c] = [Math.min(face, inner), Math.max(face, inner)];
        if (c <= lo + 0.01 || a >= hi - 0.01) return null;
        return { o, a: Math.max(a, lo), c: Math.min(c, hi), atHi: c >= hi - 0.01, atLo: a <= lo + 0.01, back: inner > lo + 0.01 && inner < hi - 0.01 ? inner : null };
      })
      .filter(Boolean);
    // Faces: at hi facing +n, at lo facing -n.
    const hiFaces = faceLoops(axisParam(axis, endAt(hi, 0)), axisParam(axis, endAt(hi, 1)), base, top, [...ops, ...cuts.filter((x) => x.atHi).map((x) => x.o)]);
    for (const f of hiFaces) b.planar(Q(0, hi, 0), [-dir[0], -dir[1], 0], [0, 0, 1], f.outer.map((q) => [-q[0], q[1]]), f.holes.map((hh) => hh.map((q) => [-q[0], q[1]])), col);
    const loFaces = faceLoops(axisParam(axis, endAt(lo, 0)), axisParam(axis, endAt(lo, 1)), base, top, [...ops, ...cuts.filter((x) => x.atLo).map((x) => x.o)]);
    for (const f of loFaces) b.planar(Q(0, lo, 0), [dir[0], dir[1], 0], [0, 0, 1], f.outer, f.holes, col);
    for (const o of ops) for (const [p, q] of openingSides(o, base, top)) b.quad(Q(p[0], lo, p[1]), Q(q[0], lo, q[1]), Q(q[0], hi, q[1]), Q(p[0], hi, p[1]), col);
    for (const x of cuts) {
      for (const [p, q] of openingSides(x.o, base, top)) b.quad(Q(p[0], x.a, p[1]), Q(q[0], x.a, q[1]), Q(q[0], x.c, q[1]), Q(p[0], x.c, p[1]), col);
      // The niche's back, facing out of the face it is cut into.
      if (x.back == null) continue;
      if (x.o.recess.side > 0) b.planar(Q(0, x.back, 0), [-dir[0], -dir[1], 0], [0, 0, 1], x.o.shape.map((q) => [-q[0], q[1]]), [], col);
      else b.planar(Q(0, x.back, 0), [dir[0], dir[1], 0], [0, 0, 1], x.o.shape, [], col);
    }
    const strip = [endAt(lo, 0), endAt(lo, 1), endAt(hi, 1), endAt(hi, 0)];
    for (const part of splitByCuts(strip, axis, topCuts)) b.horizontal(part, [], top, true, col);
    for (const part of splitByCuts(strip, axis, botCuts)) b.horizontal(part, [], base, false, col);
    if (g.ends[0].kind === 'free') b.quad(up3(endAt(hi, 0), base), up3(endAt(lo, 0), base), up3(endAt(lo, 0), top), up3(endAt(hi, 0), top), col);
    if (g.ends[1].kind === 'free') b.quad(up3(endAt(lo, 1), base), up3(endAt(hi, 1), base), up3(endAt(hi, 1), top), up3(endAt(lo, 1), top), col);
    if (!keep) return;
    for (const part of splitByCuts(strip, axis, topCuts)) b.edgeLoop(part.map((q) => up3(q, top)));
    for (const part of splitByCuts(strip, axis, botCuts)) b.edgeLoop(part.map((q) => up3(q, base)));
    for (const e of [0, 1]) for (const o of [lo, hi]) b.edge(up3(endAt(o, e), base), up3(endAt(o, e), top));
    for (const op of ops) for (const o of [lo, hi]) for (const [p, q] of openingSides(op, base, top)) b.edge(Q(p[0], o, p[1]), Q(q[0], o, q[1]));
    for (const x of cuts) for (const o of [x.a, x.c]) for (const [p, q] of openingSides(x.o, base, top)) b.edge(Q(p[0], o, p[1]), Q(q[0], o, q[1]));
  });
}

/**
 * Top of a wall attached to a roof: a function of the plan point giving the
 * roof underside (or null when the wall is not attached).
 */
export function attachedTop(doc, w, base) {
  if (!w.attachTopId) return null;
  const roof = doc.get(w.attachTopId);
  if (!roof || roof.kind !== 'roof' || !roof.boundary?.length) return null;
  const g = roofGeometry(doc, roof);
  return (p) => {
    // Crop to Single-plane Roof: the roof plane without end.
    const inside = (w.attachTopMode === 'plane' && g.planes.length <= 1) || pointInPoly(p, g.poly);
    if (!inside) return null;
    const z = g.base + (g.planes.length ? roofHeightAt(g.planes, p) : 0);
    return z > base + 10 ? z : null;
  };
}

function pointInPoly(p, poly) {
  let r = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const c = poly[j];
    if (a[1] > p[1] !== c[1] > p[1] && p[0] < ((c[0] - a[0]) * (p[1] - a[1])) / (c[1] - a[1]) + a[0]) r = !r;
  }
  return r;
}

/** Side faces sampled along the wall so their tops follow the roof. */
function buildAttachedWall(b, { g, axis, base, top, ops, P, roofTop, leftCol, rightCol, core, uL0, uL1, uR0, uR1 }) {
  const step = 150;
  const zAt = (u, side) => {
    const p = P(u, side, 0);
    return roofTop([p[0], p[1]]) ?? top;
  };
  const samples = (u0, u1) => {
    const out = [];
    const n = Math.max(1, Math.ceil((u1 - u0) / step));
    for (let i = 0; i <= n; i++) out.push(u0 + ((u1 - u0) * i) / n);
    return out;
  };
  const face = (side, u0, u1, col) => {
    const us = samples(u0, u1);
    const bottom = ops.filter((o) => o.z0 <= base + 0.5).sort((x, y) => x.u0 - y.u0);
    const outer = [[u0, base]];
    for (const o of bottom) outer.push(...notchPath(o, base));
    outer.push([u1, base]);
    for (let i = us.length - 1; i >= 0; i--) outer.push([us[i], zAt(us[i], side)]);
    const holes = ops
      .filter((o) => o.z0 > base + 0.5)
      .map((o) => [
        [o.u0, o.z0],
        [o.u1, o.z0],
        [o.u1, o.z1],
        [o.u0, o.z1],
      ]);
    const origin = P(0, side, 0);
    if (side < 0) b.planar(origin, [axis.dir[0], axis.dir[1], 0], [0, 0, 1], dedupe(outer), holes, col);
    else b.planar(origin, [-axis.dir[0], -axis.dir[1], 0], [0, 0, 1], dedupe(outer).map((q) => [-q[0], q[1]]), holes.map((hh) => hh.map((q) => [-q[0], q[1]])), col);
    for (let i = 0; i + 1 < us.length; i++) b.edge(P(us[i], side, zAt(us[i], side)), P(us[i + 1], side, zAt(us[i + 1], side)));
    b.edge(P(u0, side, base), P(u1, side, base));
    b.edge(P(u0, side, base), P(u0, side, zAt(u0, side)));
    b.edge(P(u1, side, base), P(u1, side, zAt(u1, side)));
    for (const o of ops) {
      if (o.z0 > base + 0.5) b.edge(P(o.u0, side, o.z0), P(o.u1, side, o.z0));
      b.edge(P(o.u0, side, o.z1), P(o.u1, side, o.z1));
      b.edge(P(o.u0, side, o.z0), P(o.u0, side, o.z1));
      b.edge(P(o.u1, side, o.z0), P(o.u1, side, o.z1));
    }
  };
  face(-1, uR0, uR1, rightCol);
  face(1, uL0, uL1, leftCol);
  // Reveals.
  for (const o of ops) {
    b.quad(P(o.u0, -1, o.z0), P(o.u0, 1, o.z0), P(o.u0, 1, o.z1), P(o.u0, -1, o.z1), core);
    b.quad(P(o.u1, 1, o.z0), P(o.u1, -1, o.z0), P(o.u1, -1, o.z1), P(o.u1, 1, o.z1), core);
    b.quad(P(o.u0, -1, o.z1), P(o.u0, 1, o.z1), P(o.u1, 1, o.z1), P(o.u1, -1, o.z1), core);
    if (o.z0 > base + 0.5) b.quad(P(o.u0, -1, o.z0), P(o.u1, -1, o.z0), P(o.u1, 1, o.z0), P(o.u0, 1, o.z0), core);
  }
  // Top: a strip between the two faces.
  const lo = Math.min(uL0, uR0);
  const hi = Math.max(uL1, uR1);
  const us = samples(lo, hi);
  const clampL = (u) => Math.max(uL0, Math.min(uL1, u));
  const clampR = (u) => Math.max(uR0, Math.min(uR1, u));
  for (let i = 0; i + 1 < us.length; i++) {
    const a0 = clampR(us[i]);
    const a1 = clampR(us[i + 1]);
    const c0 = clampL(us[i]);
    const c1 = clampL(us[i + 1]);
    b.quad(P(a0, -1, zAt(a0, -1)), P(a1, -1, zAt(a1, -1)), P(c1, 1, zAt(c1, 1)), P(c0, 1, zAt(c0, 1)), core);
  }
  // Bottom.
  b.horizontal([g.R0, g.R1, g.L1, g.L0], [], base, false, core);
  // Square ends.
  if (g.ends[0].kind === 'free') b.quad([g.L0[0], g.L0[1], base], [g.R0[0], g.R0[1], base], [g.R0[0], g.R0[1], zAt(uR0, -1)], [g.L0[0], g.L0[1], zAt(uL0, 1)], core);
  if (g.ends[1].kind === 'free') b.quad([g.R1[0], g.R1[1], base], [g.L1[0], g.L1[1], base], [g.L1[0], g.L1[1], zAt(uL1, 1)], [g.R1[0], g.R1[1], zAt(uR1, -1)], core);
}

/** Keep the parts of [u0, u1] outside the cut intervals. */
export function keepIntervals(u0, u1, cuts) {
  const out = [];
  let cur = u0;
  for (const [a, b] of cuts.slice().sort((x, y) => x[0] - y[0])) {
    if (b <= cur || a >= u1) continue;
    if (a > cur) out.push([cur, a]);
    cur = Math.max(cur, b);
  }
  if (u1 > cur) out.push([cur, u1]);
  return out;
}

/** Split a wall outline across its axis, leaving out the cut intervals. */
export function splitByCuts(poly, axis, cuts) {
  if (!cuts.length) return [poly];
  const us = poly.map((p) => axisParam(axis, p));
  const lo = Math.min(...us);
  const hi = Math.max(...us);
  const out = [];
  const off = dot(axis.dir, axis.a);
  for (const [s0, s1] of keepIntervals(lo, hi, cuts)) {
    let p = clipHalfPlane(poly, scale(axis.dir, -1), -(s0 + off));
    p = clipHalfPlane(p, axis.dir, s1 + off);
    if (p.length >= 3) out.push(p);
  }
  return out;
}

/**
 * Face outline in (u, z) between u0 and u1 with rectangular openings.
 * Openings touching the bottom or top become notches; an opening spanning
 * the full height splits the face.
 */
function faceLoops(u0, u1, base, top, ops) {
  const full = ops.filter((o) => o.z0 <= base + 0.5 && o.z1 >= top - 0.5);
  const ranges = keepIntervals(u0, u1, full.map((o) => [o.u0, o.u1]));
  const faces = [];
  for (const [a, c] of ranges) {
    const inside = ops.filter((o) => !full.includes(o) && o.u0 >= a - 0.01 && o.u1 <= c + 0.01);
    const bottom = inside.filter((o) => o.z0 <= base + 0.5).sort((x, y) => x.u0 - y.u0);
    const topN = inside.filter((o) => o.z1 >= top - 0.5).sort((x, y) => y.u0 - x.u0);
    // Openings running past the face's end (a corner window) take a notch out of its side there.
    const atEnd = (o) => !full.includes(o) && !inside.includes(o) && o.z0 > base + 0.5 && o.z1 < top - 0.5;
    const rightN = ops.filter((o) => atEnd(o) && o.u1 > c && o.u0 < c).sort((x, y) => x.z0 - y.z0);
    const leftN = ops.filter((o) => atEnd(o) && o.u0 < a && o.u1 > a).sort((x, y) => y.z0 - x.z0);
    const outer = [[a, base]];
    for (const o of bottom) outer.push(...notchPath(o, base));
    outer.push([c, base]);
    for (const o of rightN) outer.push([c, o.z0], [Math.max(a, o.u0), o.z0], [Math.max(a, o.u0), o.z1], [c, o.z1]);
    outer.push([c, top]);
    for (const o of topN) outer.push([o.u1, top], [o.u1, o.z0], [o.u0, o.z0], [o.u0, top]);
    outer.push([a, top]);
    for (const o of leftN) outer.push([a, o.z1], [Math.min(c, o.u1), o.z1], [Math.min(c, o.u1), o.z0], [a, o.z0]);
    const holes = inside
      .filter((o) => o.z0 > base + 0.5 && o.z1 < top - 0.5)
      .map(
        (o) =>
          o.shape || [
            [o.u0, o.z0],
            [o.u1, o.z0],
            [o.u1, o.z1],
            [o.u0, o.z1],
          ],
      );
    faces.push({ outer: dedupe(outer), holes });
  }
  return faces;
}

function dedupe(loop) {
  const out = [];
  for (const p of loop) if (!out.length || Math.abs(out.at(-1)[0] - p[0]) > 1e-6 || Math.abs(out.at(-1)[1] - p[1]) > 1e-6) out.push(p);
  if (out.length > 1 && Math.abs(out[0][0] - out.at(-1)[0]) < 1e-6 && Math.abs(out[0][1] - out.at(-1)[1]) < 1e-6) out.pop();
  return out;
}

/**
 * Curtain wall grid line positions: `us` along the wall and `vs` up from
 * its base, both including the two ends. The type spaces panels equally;
 * a wall's own grid lines (curtainU, curtainV) replace that layout.
 */
export function curtainGrid(axisLength, height, type, wall = null) {
  const c = type.curtain || {};
  const lines = (own, total, spacing, scheme) => {
    if (own?.length) return [0, ...[...new Set(own.map((x) => Math.round(+x)))].filter((x) => x > 1 && x < total - 1).sort((a, b) => a - b), total];
    if (parsePattern(scheme?.pattern).length) return schemeLines(total, scheme);
    const n = Math.max(1, Math.round(total / spacing));
    return Array.from({ length: n + 1 }, (_, i) => (total * i) / n);
  };
  const us = lines(wall?.curtainU, axisLength, +c.hSpacing || 1500, c.uScheme);
  const vs = lines(wall?.curtainV, height, +c.vSpacing || 1200, c.vScheme);
  return { us, vs, nu: us.length - 1, nv: vs.length - 1 };
}

function buildCurtainWall(ctx, w, g, type) {
  const b = new MeshBuilder();
  const { axis, base, top } = g;
  const { dir } = axis;
  const c = type.curtain || {};
  const mul = materialColor(ctx, c.materialId || 'mat-aluminum');
  const glass = materialColor(ctx, 'mat-glass');
  const L = axis.length;
  const H = top - base;
  const { us, vs, nu, nv } = curtainGrid(L, H, type, w);
  const frame = new Frame(axis.a, Math.atan2(dir[1], dir[0]), base);
  // (u along the wall, y across it) in plan: on a curved wall along the arc, panels and transoms as chords between
  // the mullions (as Archicad facets a curved curtain wall).
  const toW = (u, y) => (axis.curve ? axisPoint(axis, u, y) : frame.apply([u, y]));
  const box = (x0, y0, z0, x1, y1, z1, col, opts) => {
    if (x1 - x0 < 0.5 || y1 - y0 < 0.5 || z1 - z0 < 0.5) return;
    b.prism([[x0, y0], [x1, y0], [x1, y1], [x0, y1]].map(([u, y]) => toW(u, y)), [], base + z0, base + z1, col, opts);
  };
  const frameCol = (f) => (f.materialId ? materialColor(ctx, f.materialId) : mul);
  // Exterior is +y unless the wall is flipped: profiles are drawn with their outside at +y.
  const ys = w.flipped ? -1 : 1;
  const yy = (y0, y1) => [Math.min(ys * y0, ys * y1), Math.max(ys * y0, ys * y1)];
  // Mullion segments can be removed one by one (wall.mullionsOff: 'v:i:j' and 'h:j:i').
  const off = new Set(w.mullionsOff || []);
  const half = (key) => (off.has(key) ? 0 : (+frameFor(c, w, key, nu, nv).width || 50) / 2);
  for (let i = 0; i <= nu; i++)
    for (let j = 0; j < nv; j++) {
      const key = `v:${i}:${j}`;
      if (off.has(key)) continue;
      const f = frameFor(c, w, key, nu, nv);
      const fw = +f.width || 50;
      const u = Math.min(L - fw / 2, Math.max(fw / 2, us[i]));
      for (const [a0, y0, a1, y1] of frameSection(f)) {
        const [p, q] = yy(y0, y1);
        box(u + a0, p, vs[j], u + a1, q, vs[j + 1], frameCol(f));
      }
    }
  for (let j = 0; j <= nv; j++)
    for (let i = 0; i < nu; i++) {
      const key = `h:${j}:${i}`;
      if (off.has(key)) continue;
      const f = frameFor(c, w, key, nu, nv);
      const fw = +f.width || 50;
      const z = Math.min(H - fw / 2, Math.max(fw / 2, vs[j]));
      // Transoms run between the vertical frames on either side.
      const u0 = us[i] + Math.max(half(`v:${i}:${Math.min(j, nv - 1)}`), half(`v:${i}:${Math.max(0, j - 1)}`));
      const u1 = us[i + 1] - Math.max(half(`v:${i + 1}:${Math.min(j, nv - 1)}`), half(`v:${i + 1}:${Math.max(0, j - 1)}`));
      for (const [a0, y0, a1, y1] of frameSection(f)) {
        const [p, q] = yy(y0 + 1, y1 - 1);
        box(u0, p, z + a0, u1, q, z + a1, frameCol(f));
      }
    }
  // Panels: their class (wall.panels['i:j'] = a built-in kind or a class of the type).
  const solidDefault = materialColor(ctx, c.panelMaterialId || 'mat-paint-white');
  for (let i = 0; i < nu; i++)
    for (let j = 0; j < nv; j++) {
      const pc = panelFor(c, w, i, j);
      const kind = pc.kind;
      if (kind === 'empty') continue;
      const x0 = us[i] + half(`v:${i}:${j}`);
      const x1 = us[i + 1] - half(`v:${i + 1}:${j}`);
      const z0 = vs[j] + half(`h:${j}:${i}`);
      const z1 = vs[j + 1] - half(`h:${j + 1}:${i}`);
      if (x1 - x0 < 1 || z1 - z0 < 1) continue;
      const t = Math.max(2, +pc.thickness || 12) / 2;
      const own = pc.materialId ? materialColor(ctx, pc.materialId) : null;
      if (kind === 'solid') {
        box(x0, -t, z0, x1, t, z1, own || solidDefault);
        continue;
      }
      if (kind === 'spandrel') {
        box(x0, -t, z0, x1, t, z1, own || materialColor(ctx, 'mat-roof-metal'), { edges: false });
        continue;
      }
      if (kind === 'louvre') {
        // Inclined blades in a thin frame.
        const fcol = own || mul;
        const f = Math.min(40, (x1 - x0) / 8);
        box(x0, -30, z0, x0 + f, 30, z1, fcol);
        box(x1 - f, -30, z0, x1, 30, z1, fcol);
        const step = 120;
        const nn = axis.curve ? perp(axisTangent(axis, (x0 + x1) / 2)) : axis.n;
        for (let z = z0 + step / 2; z < z1 - 20; z += step) b.beam3([...toW(x0 + f, 0), base + z], [...toW(x1 - f, 0), base + z], 80, 10, fcol, { up: [Math.sin(0.5) * nn[0] * ys, Math.sin(0.5) * nn[1] * ys, Math.cos(0.5)] });
        continue;
      }
      if (kind === 'door') {
        // A glazed door leaf: a frame round the glass and a pull handle.
        const f = Math.min(80, (x1 - x0) / 6);
        const dcol = own || mul;
        box(x0, -25, z0, x0 + f, 25, z1, dcol);
        box(x1 - f, -25, z0, x1, 25, z1, dcol);
        box(x0 + f, -25, z0, x1 - f, 25, z0 + f * 1.5, dcol);
        box(x0 + f, -25, z1 - f, x1 - f, 25, z1, dcol);
        box(x1 - f * 2.2, 25, z0 + (z1 - z0) * 0.35, x1 - f * 1.8, 70, z0 + (z1 - z0) * 0.6, dcol);
        box(x0 + f, -6, z0 + f * 1.5, x1 - f, 6, z1 - f, glass, { edges: false });
        continue;
      }
      box(x0, -t / 2, z0, x1, t / 2, z1, own || glass, { edges: false });
    }
  // Accessories on the frames, out of the exterior face.
  const mf = frameRoles(c).mullion;
  for (const [u0, y0, z0, u1, y1, z1] of accessoryBoxes(w.cwAccessory, us, vs, +mf.width || 50, +mf.depth || 150, off)) box(u0, Math.min(ys * y0, ys * y1), z0, u1, Math.max(ys * y0, ys * y1), z1, mul);
  return b.build();
}

/** A curtain wall junction: the corner post. */
function buildJunction(ctx, el) {
  const p = junctionPost(ctx.doc, el);
  if (!p) return null;
  const b = new MeshBuilder();
  b.prism(p.outline, [], p.base, p.top, materialColor(ctx, p.materialId));
  return b.build();
}

/** A glazed roof (ArchiGlazing): glass on each face, bars on top of it. */
function buildGlazedRoof(ctx, el) {
  const g = glazingGeometry(ctx.doc, el);
  if (!g) return null;
  const b = new MeshBuilder();
  const glass = materialColor(ctx, 'mat-glass');
  const metal = materialColor(ctx, el.materialId || 'mat-aluminum');
  const bw = +el.barWidth || 60;
  const bd = +el.barDepth || 120;
  for (const f of g.faces) {
    const { points, tris } = triangulate(f.poly, []);
    for (let i = 0; i < tris.length; i += 3) {
      const [a, c, d] = [points[tris[i]], points[tris[i + 1]], points[tris[i + 2]]];
      orientedTri(b, [a[0], a[1], g.z(a, f.plane) + bd / 2], [c[0], c[1], g.z(c, f.plane) + bd / 2], [d[0], d[1], g.z(d, f.plane) + bd / 2], glass, true);
    }
  }
  for (const bar of g.bars) {
    const w = bar.kind === 'edge' ? bw * 1.4 : bar.kind === 'transom' ? bw * 0.8 : bw;
    b.beam3([bar.a[0], bar.a[1], bar.a[2] + bd / 2], [bar.b[0], bar.b[1], bar.b[2] + bd / 2], w, bd, metal);
  }
  return b.build();
}

// Slabs ------------------------------------------------------------------------------

function buildSlab(ctx, el, what) {
  if (!el.boundary || el.boundary.length < 3) return null;
  const type = ctx.doc.get(el.typeId);
  const th = Math.max(1, typeThickness(type) || (what === 'floor' ? 300 : 20));
  const z = levelElevation(ctx.doc, el.levelId) + (+el.offset || 0);
  const b = new MeshBuilder();
  const topCol = layerColor(ctx, type, what === 'floor' ? 'first' : 'last');
  const coreCol = layerColor(ctx, type, 'core');
  const botCol = layerColor(ctx, type, what === 'floor' ? 'last' : 'first');
  if (what === 'floor') b.prism(el.boundary, el.holes || [], z - th, z, coreCol, { top: topCol, bottom: botCol, sides: coreCol });
  else b.prism(el.boundary, el.holes || [], z, z + th, coreCol, { top: topCol, bottom: botCol, sides: coreCol });
  return b.build();
}

// Roofs -------------------------------------------------------------------------------

export function roofGeometry(doc, el) {
  const type = doc.get(el.typeId);
  const th = Math.max(1, typeThickness(type) || 300);
  const base = levelElevation(doc, el.levelId) + (+el.baseOffset || 0);
  const rf = roofFaces(el.boundary, el.slopes, { levels: el.levels, overhangs: el.overhangs });
  return { ...rf, th, base, type };
}

function buildRoof(ctx, el) {
  if (!el.boundary || el.boundary.length < 3) return null;
  const { poly, planes, faces, th, base, type } = roofGeometry(ctx.doc, el);
  const b = new MeshBuilder();
  const topCol = layerColor(ctx, type, 'first');
  const coreCol = layerColor(ctx, type, 'core');
  const zb = (p, pl) => base + (pl ? planeHeight(pl, p) : 0);
  // Its holes and its skylights' (skylight.js).
  const holes = roofHoles(ctx.doc, el);
  for (const f of faces) {
    const vt = verticalThickness(th, f.plane);
    // Openings inside the face are holes; openings across its edge take a notch out of it.
    const { pieces, inner, crossing } = cutFace(f.poly, holes);
    for (const piece of pieces) {
      const { points, tris } = triangulate(piece.outer, piece.holes);
      for (let i = 0; i < tris.length; i += 3) {
        const [a, c, d] = [points[tris[i]], points[tris[i + 1]], points[tris[i + 2]]];
        const A = [a[0], a[1], zb(a, f.plane) + vt];
        const C = [c[0], c[1], zb(c, f.plane) + vt];
        const D = [d[0], d[1], zb(d, f.plane) + vt];
        orientedTri(b, A, C, D, topCol, true);
        orientedTri(b, [a[0], a[1], zb(a, f.plane)], [c[0], c[1], zb(c, f.plane)], [d[0], d[1], zb(d, f.plane)], coreCol, false);
      }
    }
    const lerp = (p, q, t) => [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t];
    const top = (p) => [p[0], p[1], zb(p, f.plane) + vt];
    // The face outline, except where openings cross it.
    for (let i = 0; i < f.poly.length; i++) {
      const p = f.poly[i];
      const q = f.poly[(i + 1) % f.poly.length];
      for (const [t0, t1] of crossing.length ? segmentOutside(p, q, crossing) : [[0, 1]]) b.edge(top(lerp(p, q, t0)), top(lerp(p, q, t1)));
    }
    // Sides of openings cut through this face (only the part of each side on this face).
    for (const h of [...inner, ...crossing]) {
      const whole = inner.includes(h);
      for (let i = 0; i < h.length; i++) {
        const hp = h[i];
        const hq = h[(i + 1) % h.length];
        for (const [t0, t1] of whole ? [[0, 1]] : segmentInside(hp, hq, f.poly)) {
          const p = lerp(hp, hq, t0);
          const q = lerp(hp, hq, t1);
          const P0 = [p[0], p[1], zb(p, f.plane)];
          const Q0 = [q[0], q[1], zb(q, f.plane)];
          b.quad(Q0, P0, [p[0], p[1], P0[2] + vt], [q[0], q[1], Q0[2] + vt], coreCol);
          b.edge([p[0], p[1], P0[2] + vt], [q[0], q[1], Q0[2] + vt]);
          b.edge(P0, Q0);
        }
      }
    }
  }
  // Sides along the footprint.
  const activeAt = (p) => {
    if (!planes.length) return null;
    let best = null;
    let h = Infinity;
    for (const pl of planes) {
      const v = planeHeight(pl, p);
      if (v < h - 1e-6) {
        h = v;
        best = pl;
      }
    }
    return best;
  };
  const hAt = (p) => base + (planes.length ? roofHeightAt(planes, p) : 0);
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const c = poly[(i + 1) % poly.length];
    const pts = edgeProfile(faces, a, c);
    for (let k = 0; k + 1 < pts.length; k++) {
      const p = pts[k];
      const q = pts[k + 1];
      const pl = activeAt([(p[0] + q[0]) / 2, (p[1] + q[1]) / 2]);
      const vt = verticalThickness(th, pl);
      const P0 = [p[0], p[1], hAt(p)];
      const Q0 = [q[0], q[1], hAt(q)];
      const Q1 = [q[0], q[1], hAt(q) + vt];
      const P1 = [p[0], p[1], hAt(p) + vt];
      b.quad(P0, Q0, Q1, P1, coreCol);
      b.edge(P0, Q0);
    }
    const z0 = hAt(a);
    b.edge([a[0], a[1], z0], [a[0], a[1], z0 + verticalThickness(th, activeAt(a))]);
  }
  // Fascia, gutters and downpipes along the eaves (roofacc.js).
  if (el.fascia || el.gutters) {
    const edges = eaveEdges(poly, hAt);
    const ground = Math.min(...ctx.doc.levels().map((l) => l.elevation), 0);
    const top = edges.length ? verticalThickness(th, activeAt([(edges[0].a[0] + edges[0].b[0]) / 2, (edges[0].a[1] + edges[0].b[1]) / 2])) : th;
    addRoofAccessories(b, edges, { fascia: !!el.fascia, gutters: !!el.gutters, downpipes: el.downpipes !== false && !!el.gutters, top, ground, colors: { fascia: materialColor(ctx, el.fasciaMaterialId || 'mat-paint-white'), gutter: materialColor(ctx, el.gutterMaterialId || 'mat-aluminum') } });
  }
  return b.build();
}

function orientedTri(b, A, C, D, col, up) {
  const nz = (C[0] - A[0]) * (D[1] - A[1]) - (C[1] - A[1]) * (D[0] - A[0]);
  if ((nz >= 0) === up) b.tri(A, C, D, col);
  else b.tri(A, D, C, col);
}

// Doors and windows -------------------------------------------------------------------

function hostFrame(ctx, el) {
  const host = ctx.doc.get(el.hostId);
  if (!host || host.kind !== 'wall') return null;
  const axis = wallAxis(ctx.doc, host);
  const { base, top } = verticalExtent(ctx.doc, host);
  // Under a partial structure display (ctx.show) the opening spans only the wall layers shown.
  const span = shownSpan(ctx.doc, host, ctx.show, axis.half);
  if (!span) return null;
  // Along the wall at the opening (the tangent there on a curved wall).
  const dir = axisTangent(axis, el.t);
  const at = axisPoint(axis, el.t, (span.lo + span.hi) / 2);
  const frame = new Frame(at, Math.atan2(dir[1], dir[0]), base);
  return { host, axis, base, top, frame, thick: span.hi - span.lo, extSign: host.flipped ? -1 : 1 };
}

function frameBox(b, frame, x0, y0, z0, x1, y1, z1, col, opts) {
  const lx = Math.min(x0, x1);
  const hx = Math.max(x0, x1);
  const ly = Math.min(y0, y1);
  const hy = Math.max(y0, y1);
  if (hx - lx < 0.01 || hy - ly < 0.01 || Math.abs(z1 - z0) < 0.01) return;
  b.prism(
    [
      [lx, ly],
      [hx, ly],
      [hx, hy],
      [lx, hy],
    ].map((p) => frame.apply(p)),
    [],
    frame.z + Math.min(z0, z1),
    frame.z + Math.max(z0, z1),
    col,
    opts,
  );
}

/**
 * A door or window written in GDL (an Archicad one): its own 3D in the
 * opening, x along the wall, its height up from the sill, its z into the
 * wall from the face it is placed on (GDL's door and window origin). The
 * wall's hole is the opening's, as for any door or window.
 */
function buildGdlOpening(ctx, el, hf, type) {
  const { width: W, height: H, sill = 0 } = openingSize(ctx.doc, el);
  const r = runGdlOpening(type, { width: W, height: H, thickness: hf.thick, wallHeight: hf.top - hf.base }, el.gdlValues || {}, DETAIL_LEVEL[ctx.detail] ?? null);
  const b = new MeshBuilder();
  const f = hf.frame;
  const ext = (el.flipFacing ? -1 : 1) * hf.extSign;
  const z0 = el.kind === 'window' ? sill : 0;
  const P = (p) => {
    const q = f.apply([p[0], ext * (hf.thick / 2 - p[2])]);
    return [q[0], q[1], f.z + z0 + p[1]];
  };
  const colors = new Map();
  const col = (m) => {
    if (!colors.has(m)) colors.set(m, materialColor(ctx, typeof m === 'string' && m ? m : el.kind === 'window' ? 'mat-paint-white' : 'mat-door'));
    return colors.get(m);
  };
  // A mirror (one sign flipped) turns faces inside out: keep their order facing out.
  for (const t of r.tris) ext > 0 ? b.tri(P(t.a), P(t.b), P(t.c), col(t.mat)) : b.tri(P(t.a), P(t.c), P(t.b), col(t.mat));
  for (const [a, c] of r.edges) b.edge(P(a), P(c));
  return b.build();
}

/** A view's detail for doors and windows in 3D (Model View Options), as Archicad's libraries number it. */
const DETAIL_LEVEL = { schematic: 1, simplified: 2, detailed: 3 };

function buildDoor(ctx, el) {
  const hf = hostFrame(ctx, el);
  if (!hf) return null;
  const type = ctx.doc.get(el.typeId) || {};
  if (type.family === 'gdl') return buildGdlOpening(ctx, el, hf, type);
  const { width: W, height: Hraw } = openingSize(ctx.doc, el);
  const H = Math.min(Hraw, hf.top - hf.base);
  const b = new MeshBuilder();
  const f = hf.frame;
  const fw = el.frameWidth != null ? +el.frameWidth : +type.frameWidth || 50;
  const fd = doorFrameDepth(type, hf.thick);
  const frameCol = materialColor(ctx, type.frameMaterialId || 'mat-wood-light');
  const panelCol = materialColor(ctx, type.panelMaterialId || 'mat-door');
  const glass = materialColor(ctx, 'mat-glass');
  const fam = type.family || 'single';
  const hinged = isHingedDoor(fam) && fam !== 'opening';
  // The side the door opens to, as in plan; a hinged door's frame and leaf stand at that face.
  const face = el.flipFacing ? -1 : 1;
  const yf = hinged ? face * (hf.thick / 2 - fd / 2) : 0;
  if (fam !== 'overhead') {
    frameBox(b, f, -W / 2, yf - fd / 2, 0, -W / 2 + fw, yf + fd / 2, H, frameCol);
    frameBox(b, f, W / 2 - fw, yf - fd / 2, 0, W / 2, yf + fd / 2, H, frameCol);
    frameBox(b, f, -W / 2, yf - fd / 2, H - fw, W / 2, yf + fd / 2, H, frameCol);
  }
  const pt = +type.thickness || 44;
  const hand = el.flipHand ? -1 : 1;
  const yc = hinged ? face * (hf.thick / 2 - pt / 2) : 0;
  // The trim round a hinged door, on each wall face the frame reaches.
  const casing = ctx.detail && ctx.detail !== 'detailed' ? 0 : type.casing != null ? +type.casing : 60;
  if (hinged && casing > 0)
    for (const side of fd >= hf.thick - 1 ? [1, -1] : [face]) {
      const [y0, y1] = [(side * hf.thick) / 2, side * (hf.thick / 2 + 15)];
      frameBox(b, f, -W / 2 - casing, y0, 0, -W / 2, y1, H + casing, frameCol);
      frameBox(b, f, W / 2, y0, 0, W / 2 + casing, y1, H + casing, frameCol);
      frameBox(b, f, -W / 2, y0, H, W / 2, y1, H + casing, frameCol);
    }
  // A lever on each side of a leaf, turned toward its hinge.
  const steel = materialColor(ctx, 'mat-steel');
  const lever = (x, toHinge) => {
    if (ctx.detail && ctx.detail !== 'detailed') return;
    const z = Math.min(1050, H * 0.48);
    for (const s of [-1, 1]) {
      const y = yc + (s * pt) / 2;
      frameBox(b, f, x - 25, y, z - 25, x + 25, y + s * 6, z + 25, steel);
      frameBox(b, f, x - 9, y, z - 9, x + 9, y + s * 48, z + 9, steel);
      frameBox(b, f, x - 9, y + s * 34, z - 8, x + toHinge * 115, y + s * 48, z + 8, steel);
    }
  };
  const x0 = -W / 2 + fw;
  const x1 = W / 2 - fw;
  const ph = H - fw;
  // A leaf standing open (Open Angle): built along its own axes from the hinge, at the face it opens to.
  const open = (Math.max(0, Math.min(90, +(el.openAngle ?? type.openAngle ?? 0))) * Math.PI) / 180;
  const openLeaf = (hx, dirx, L, glazed) => {
    const hy = (face * hf.thick) / 2;
    const [c, s] = [Math.cos(open), Math.sin(open)];
    const P = (u, v) => [hx + dirx * c * u + dirx * s * v, hy + face * s * u - face * c * v];
    const box = (u0, u1, v0, v1, z0, z1, col, opts) => {
      let q = [P(u0, v0), P(u1, v0), P(u1, v1), P(u0, v1)];
      if (signedArea(q) < 0) q = q.reverse();
      b.prism(q.map((p) => f.apply(p)), [], f.z + z0, f.z + z1, col, opts);
    };
    if (!glazed) box(0, L, 0, pt, 0, ph - 3, panelCol);
    else {
      const st = Math.min(110, L / 4);
      box(0, st, 0, pt, 0, ph - 3, panelCol);
      box(L - st, L, 0, pt, 0, ph - 3, panelCol);
      box(st, L - st, 0, pt, 0, 220, panelCol);
      box(st, L - st, 0, pt, ph - 3 - st, ph - 3, panelCol);
      box(st, L - st, pt / 2 - 4, pt / 2 + 4, 220, ph - 3 - st, glass, { edges: false });
    }
    const z = Math.min(1050, H * 0.48);
    const u = L - 70;
    for (const [v0, sg] of [[0, -1], [pt, 1]]) {
      box(u - 25, u + 25, v0, v0 + sg * 6, z - 25, z + 25, steel);
      box(u - 9, u + 9, v0, v0 + sg * 48, z - 9, z + 9, steel);
      box(u - 115, u + 9, v0 + sg * 34, v0 + sg * 48, z - 8, z + 8, steel);
    }
  };
  const panel = (a, c, y, glazed) => {
    if (!glazed) return frameBox(b, f, a, y - pt / 2, 0, c, y + pt / 2, ph - 3, panelCol);
    const st = Math.min(110, (c - a) / 4);
    frameBox(b, f, a, y - pt / 2, 0, a + st, y + pt / 2, ph - 3, panelCol);
    frameBox(b, f, c - st, y - pt / 2, 0, c, y + pt / 2, ph - 3, panelCol);
    frameBox(b, f, a + st, y - pt / 2, 0, c - st, y + pt / 2, 220, panelCol);
    frameBox(b, f, a + st, y - pt / 2, ph - 3 - st, c - st, y + pt / 2, ph - 3, panelCol);
    frameBox(b, f, a + st, y - 4, 220, c - st, y + 4, ph - 3 - st, glass, { edges: false });
  };
  switch (fam) {
    case 'double': {
      const m = (x0 + x1) / 2;
      if (open > 0) {
        openLeaf(x0, 1, m - 2 - x0, type.glazing);
        openLeaf(x1, -1, x1 - m - 2, type.glazing);
        break;
      }
      panel(x0, m - 2, yc, type.glazing);
      panel(m + 2, x1, yc, type.glazing);
      lever(m - 70, -1);
      lever(m + 70, 1);
      break;
    }
    case 'sliding': {
      const m = (x0 + x1) / 2;
      panel(x0, m + 40, yc - pt * 0.6 * face, true);
      panel(m - 40, x1, yc + pt * 0.6 * face, true);
      break;
    }
    case 'bifold': {
      const n = 4;
      const wpan = (x1 - x0) / n;
      for (let i = 0; i < n; i++) frameBox(b, f, x0 + i * wpan + 1, -15, 0, x0 + (i + 1) * wpan - 1, 15, ph - 3, panelCol);
      break;
    }
    case 'overhead': {
      frameBox(b, f, -W / 2, -fd / 2, 0, -W / 2 + 40, fd / 2, H, frameCol);
      frameBox(b, f, W / 2 - 40, -fd / 2, 0, W / 2, fd / 2, H, frameCol);
      const sections = 4;
      for (let i = 0; i < sections; i++) frameBox(b, f, -W / 2 + 40, -20, (i * H) / sections + 1, W / 2 - 40, 20, ((i + 1) * H) / sections - 1, panelCol);
      break;
    }
    case 'opening':
      break;
    case 'pivot': {
      // One wide leaf turning on a pivot a quarter of its width in, shown slightly open.
      panel(x0, x1, yc, false);
      frameBox(b, f, x0 + (x1 - x0) * 0.25 - 10, -10, -5, x0 + (x1 - x0) * 0.25 + 10, 10, ph, materialColor(ctx, 'mat-steel'));
      break;
    }
    case 'dutch': {
      // Two leaves, upper and lower, split at 1050 mm.
      const zs = Math.min(1050, ph * 0.5);
      frameBox(b, f, x0, yc - pt / 2, 0, x1, yc + pt / 2, zs - 2, panelCol);
      frameBox(b, f, x0, yc - pt / 2, zs + 2, x1, yc + pt / 2, ph - 3, panelCol);
      frameBox(b, f, x0, yc - pt / 2 - 20 * face, zs - 25, x1, yc + pt / 2, zs, frameCol);
      lever(hand * (x1 - 70), -hand);
      break;
    }
    case 'barn': {
      // A leaf hung on a rail across the wall face, wider than the opening.
      const yf = face * (hf.thick / 2 + pt / 2 + 10);
      frameBox(b, f, -W / 2 - 60, yf - pt / 2, 0, W / 2 + 60, yf + pt / 2, H + 40, panelCol);
      frameBox(b, f, -W - 100, yf + face * pt / 2, H + 60, W + 100, yf + face * (pt / 2 + 25), H + 100, materialColor(ctx, 'mat-steel'));
      break;
    }
    case 'sidelight': {
      // A leaf with a fixed glazed panel beside it, 300 mm wide.
      const sl = Math.min(400, (x1 - x0) * 0.3);
      panel(x0, x1 - sl - fw, yc, type.glazing);
      frameBox(b, f, x1 - sl - fw, yf - fd / 2, 0, x1 - sl, yf + fd / 2, H, frameCol);
      frameBox(b, f, x1 - sl, yf - 4, 0, x1, yf + 4, ph, glass, { edges: false });
      lever(x1 - sl - fw - 70, -1);
      break;
    }
    case 'revolving': {
      // Four glass wings on a centre post inside a glass drum.
      const r = (x1 - x0) / 2;
      const c = [0, 0];
      frameBox(b, f, -15, -15, 0, 15, 15, ph, frameCol);
      for (const [dx, dy] of [[1, 0], [0, 1], [-1, 0], [0, -1]]) {
        const p0 = [dx * 15, dy * 15];
        const p1 = [dx * (r - 20), dy * (r - 20)];
        frameBox(b, f, Math.min(p0[0], p1[0]) - (dx ? 0 : 6), Math.min(p0[1], p1[1]) - (dy ? 0 : 6), 0, Math.max(p0[0], p1[0]) + (dx ? 0 : 6), Math.max(p0[1], p1[1]) + (dy ? 0 : 6), ph - 3, glass, { edges: false });
      }
      const ring = [];
      for (let i = 0; i <= 16; i++) {
        const a = Math.PI * 0.6 + (Math.PI * 0.8 * i) / 16;
        ring.push([c[0] + Math.cos(a) * r, c[1] + Math.sin(a) * r]);
      }
      for (const sy of [1, -1])
        for (let i = 0; i + 1 < ring.length; i++) {
          const a = ring[i];
          const q = ring[i + 1];
          b.quad(...[[a[0], sy * a[1], 0], [q[0], sy * q[1], 0], [q[0], sy * q[1], ph], [a[0], sy * a[1], ph]].map(([x, y, z]) => [...f.apply([x, y]), f.z + z]), glass);
        }
      break;
    }
    default:
      if (open > 0) {
        openLeaf(hand * -x1, hand, x1 - x0, type.glazing);
        break;
      }
      panel(x0, x1, yc, type.glazing);
      lever(hand * (x1 - 70), -hand);
  }
  return b.build();
}

function buildWindow(ctx, el) {
  const hf = hostFrame(ctx, el);
  if (!hf) return null;
  const type = ctx.doc.get(el.typeId) || {};
  if (type.family === 'gdl') return buildGdlOpening(ctx, el, hf, type);
  const { width: W, height: H, sill } = openingSize(ctx.doc, el);
  const b = new MeshBuilder();
  const f = hf.frame;
  const { fw, fd, offsets } = windowAssemblies(el, type, hf.thick);
  const col = materialColor(ctx, type.frameMaterialId || 'mat-paint-white');
  const glass = materialColor(ctx, 'mat-glass');
  const z0 = sill;
  const z1 = Math.min(sill + H, hf.top - hf.base);
  const ext = (el.flipFacing ? -1 : 1) * hf.extSign;
  // The frame's place across the wall, from the exterior face.
  const yc = ext * (hf.thick / 2 - offsets[0]);
  const y0 = yc - fd / 2;
  const y1 = yc + fd / 2;
  // A corner window: no jamb at the corner; its head, sill and glass run on to meet the other window's there.
  const sx = el.corner === 'b' ? 1 : el.corner === 'a' ? -1 : 0;
  const reach = sx ? cornerReach(ctx, el, hf, yc, W, sx) : 0;
  const xl = sx < 0 ? -W / 2 - reach : -W / 2 + fw;
  const xr = sx > 0 ? W / 2 + reach : W / 2 - fw;
  const frame = (y) => {
    if (sx >= 0) frameBox(b, f, -W / 2, y - fd / 2, z0, -W / 2 + fw, y + fd / 2, z1, col);
    if (sx <= 0) frameBox(b, f, W / 2 - fw, y - fd / 2, z0, W / 2, y + fd / 2, z1, col);
    frameBox(b, f, xl, y - fd / 2, z0, xr, y + fd / 2, z0 + fw, col);
    frameBox(b, f, xl, y - fd / 2, z1 - fw, xr, y + fd / 2, z1, col);
  };
  // Schematic: the frame and one pane, as Archicad's schematic windows.
  if (ctx.detail === 'schematic') {
    frame(yc);
    frameBox(b, f, xl, yc - 4, z0 + fw, xr, yc + 4, z1 - fw, glass, { edges: false });
    return b.build();
  }
  frame(yc);
  if (sx) {
    frameBox(b, f, xl, yc - 4, z0 + fw, xr, yc + 4, z1 - fw, glass, { edges: false });
    const yo = ext * hf.thick / 2;
    frameBox(b, f, sx < 0 ? xl : -W / 2 - 30, yo, z0 - 30, sx > 0 ? xr : W / 2 + 30, yo + ext * 50, z0, col);
    return b.build();
  }
  const fam = type.family || 'fixed';
  const yo = ext * hf.thick / 2;
  const exteriorSill = () => el.sillBoard !== false && (!ctx.detail || ctx.detail === 'detailed') && frameBox(b, f, -W / 2 - 30, yo, z0 - 30, W / 2 + 30, yo + ext * 50, z0, col);
  if (fam === 'louvre') {
    // Horizontal slats instead of a pane.
    const n = Math.max(3, Math.round((z1 - z0 - 2 * fw) / 90));
    for (let i = 0; i < n; i++) {
      const z = z0 + fw + ((z1 - z0 - 2 * fw) * (i + 0.5)) / n;
      frameBox(b, f, -W / 2 + fw, yc - 30, z - 6, W / 2 - fw, yc + 30, z + 6, col);
    }
    exteriorSill();
    return b.build();
  }
  // Bars: columns of leaves across, rows up the height. An instance's own transom height comes first.
  const mullion = fw * 0.8;
  const zLo = z0 + fw;
  const zHi = z1 - fw;
  const xLo = -W / 2 + fw;
  const xHi = W / 2 - fw;
  const cols = fam === 'triple' ? [-W / 6, W / 6] : fam === 'sliding' || ((fam === 'casement' || fam === 'tiltTurn') && W > 1000) ? [0] : [];
  const rows = +el.transomAt > 0 && z0 + +el.transomAt < zHi - 100 ? [z0 + +el.transomAt] : fam === 'doubleHung' || fam === 'awning' || fam === 'hopper' ? [(z0 + z1) / 2] : fam === 'transom' ? [z1 - (z1 - z0) * 0.25] : [];
  const operable = ['casement', 'tiltTurn', 'awning', 'hopper', 'doubleHung', 'sliding', 'transom'].includes(fam);
  const assembly = (y, interior) => {
    for (const x of cols) frameBox(b, f, x - mullion / 2, y - fd / 2 + 5, zLo, x + mullion / 2, y + fd / 2 - 5, zHi, col);
    for (const z of rows) frameBox(b, f, xLo, y - fd / 2 + 5, z - mullion / 2, xHi, y + fd / 2 - 5, z + mullion / 2, col);
    const xs = [xLo, ...cols.flatMap((x) => [x - mullion / 2, x + mullion / 2]), xHi];
    const zs = [zLo, ...rows.flatMap((z) => [z - mullion / 2, z + mullion / 2]), zHi];
    const sash = operable && fd >= 40 ? Math.min(55, fw) : 0;
    for (let i = 0; i + 1 < xs.length; i += 2)
      for (let j = 0; j + 1 < zs.length; j += 2) {
        const [a, c, d, e] = [xs[i], xs[i + 1], zs[j], zs[j + 1]];
        if (sash && c - a > 2.5 * sash && e - d > 2.5 * sash) {
          const [p, q] = [y - fd / 2 + 8, y + fd / 2 - 8];
          frameBox(b, f, a, p, d, a + sash, q, e, col);
          frameBox(b, f, c - sash, p, d, c, q, e, col);
          frameBox(b, f, a + sash, p, d, c - sash, q, d + sash, col);
          frameBox(b, f, a + sash, p, e - sash, c - sash, q, e, col);
          frameBox(b, f, a + sash, y - 4, d + sash, c - sash, y + 4, e - sash, glass, { edges: false });
          // The handle, inside, on the leaf's free side, on the main row only.
          if (interior && j === 0 && (fam === 'casement' || fam === 'tiltTurn') && (!ctx.detail || ctx.detail === 'detailed')) {
            const hx = i === 0 && cols.length ? c - sash / 2 : i > 0 ? a + sash / 2 : c - sash / 2;
            const yh = y - ext * (fd / 2 - 8);
            const zh = Math.min(d + 1100 - fw, (d + e) / 2);
            frameBox(b, f, hx - 10, yh, zh - 10, hx + 10, yh - ext * 30, zh + 10, materialColor(ctx, 'mat-steel'));
            frameBox(b, f, hx - 9, yh - ext * 22, zh - 110, hx + 9, yh - ext * 34, zh + 10, materialColor(ctx, 'mat-steel'));
          }
        } else frameBox(b, f, a, y - 4, d, c, y + 4, e, glass, { edges: false });
      }
  };
  const ycs = offsets.map((o) => ext * (hf.thick / 2 - o));
  ycs.forEach((y, i) => {
    if (i) frame(y);
    assembly(y, i === ycs.length - 1);
  });
  exteriorSill();
  // A board on the sill inside, across the rest of the wall's depth.
  const inner = ycs.at(-1) - ext * fd / 2;
  const face = -ext * hf.thick / 2;
  if (el.sillBoard !== false && sill > 100 && Math.abs(face - inner) > 30) frameBox(b, f, -W / 2 - 20, inner, z0, W / 2 + 20, face - ext * 20, z0 + 25, col);
  return b.build();
}

/**
 * How far a corner window's glass runs on past its width (negative: stops
 * short of it), at the corner, to meet the glass of the window on the other
 * wall (el.cornerWith): where the two glass lines cross. Half the wall's
 * thickness when there is none.
 */
function cornerReach(ctx, el, hf, yc, W, sx) {
  const other = el.cornerWith && ctx.doc.get(el.cornerWith);
  const hf2 = other && hostFrame(ctx, other);
  if (!hf2) return hf.thick / 2;
  const t2 = ctx.doc.get(other.typeId) || {};
  const fd2 = Math.min(hf2.thick, +t2.frameDepth || 100);
  const ext2 = (other.flipFacing ? -1 : 1) * hf2.extSign;
  const p = hf.frame.apply([0, yc]);
  const q = hf2.frame.apply([0, ext2 * (hf2.thick / 2 - fd2 / 2)]);
  const d = [hf.frame.c, hf.frame.s];
  const e = [hf2.frame.c, hf2.frame.s];
  const den = d[0] * e[1] - d[1] * e[0];
  if (Math.abs(den) < 1e-6) return hf.thick / 2;
  const t = ((q[0] - p[0]) * e[1] - (q[1] - p[1]) * e[0]) / den;
  // Past its width at an outer corner, short of it at an inner one.
  return Math.max(-hf.thick, Math.min(hf.thick * 2, sx * t - W / 2));
}

// Structure ------------------------------------------------------------------------------

function buildColumn(ctx, el) {
  const type = ctx.doc.get(el.typeId) || {};
  const { base, top } = verticalExtent(ctx.doc, el);
  const prof = profileOf(ctx.doc, el);
  if (prof) return buildProfiledColumn(ctx.doc, el, prof, base, top);
  const b = new MeshBuilder();
  const col = materialColor(ctx, type.materialId || 'mat-concrete');
  const w = +type.width || 450;
  const d = +type.depth || w;
  // Trimmed to a roof (Trim to Roof): its top follows the roof's underside over its section.
  // A tapered column: a smaller section at its top (Top Width, Top Depth).
  const tw = +el.topWidth || w;
  const td = +el.topDepth || (type.shape === 'round' ? tw : d);
  if (tw !== w || td !== d) {
    if (type.shape === 'round') b.cylinder(el.at, w / 2, base, top, col, { r1: tw / 2, segments: 32 });
    else {
      const fr = new Frame(el.at, ((+el.rotation || 0) * Math.PI) / 180, 0);
      const ring = (hw, hd, z) => [[-hw, -hd], [hw, -hd], [hw, hd], [-hw, hd]].map((p) => [...fr.apply(p), z]);
      const lo = ring(w / 2, d / 2, base);
      const up = ring(tw / 2, td / 2, top);
      for (let i = 0; i < 4; i++) {
        const j = (i + 1) % 4;
        b.quad(lo[i], lo[j], up[j], up[i], col);
        b.edge(lo[i], up[i]);
      }
      b.quad(lo[3], lo[2], lo[1], lo[0], col);
      b.quad(up[0], up[1], up[2], up[3], col);
      b.edgeLoop(lo);
      b.edgeLoop(up);
    }
    return b.build();
  }
  const roofTop = attachedTop(ctx.doc, el, base);
  if (roofTop) {
    const fr = new Frame(el.at, ((+el.rotation || 0) * Math.PI) / 180, 0);
    const n = type.shape === 'round' ? 32 : 4;
    const poly = type.shape === 'round'
      ? Array.from({ length: n }, (_, k) => [el.at[0] + (w / 2) * Math.cos((2 * Math.PI * k) / n), el.at[1] + (w / 2) * Math.sin((2 * Math.PI * k) / n)])
      : [[-w / 2, -d / 2], [w / 2, -d / 2], [w / 2, d / 2], [-w / 2, d / 2]].map((p) => fr.apply(p));
    prismUnder(b, poly, base, poly.map((p) => roofTop(p) ?? top), col);
    return b.build();
  }
  if (type.shape === 'round') b.cylinder(el.at, w / 2, base, top, col, { segments: 32 });
  else {
    const fr = new Frame(el.at, ((+el.rotation || 0) * Math.PI) / 180, 0);
    b.prism(
      [
        [-w / 2, -d / 2],
        [w / 2, -d / 2],
        [w / 2, d / 2],
        [-w / 2, d / 2],
      ].map((p) => fr.apply(p)),
      [],
      base,
      top,
      col,
    );
  }
  return b.build();
}

/** A vertical prism over a convex counterclockwise polygon from base up to a height at each corner. */
function prismUnder(b, poly, base, tops, col) {
  const P = (i, z) => [poly[i][0], poly[i][1], z];
  b.horizontal(poly, [], base, false, col);
  for (let i = 1; i + 1 < poly.length; i++) b.tri(P(0, tops[0]), P(i, tops[i]), P(i + 1, tops[i + 1]), col);
  for (let i = 0; i < poly.length; i++) {
    const j = (i + 1) % poly.length;
    b.quad(P(i, base), P(j, base), P(j, tops[j]), P(i, tops[i]), col);
    b.edge(P(i, base), P(j, base));
    b.edge(P(i, tops[i]), P(j, tops[j]));
  }
  if (poly.length <= 8) for (let i = 0; i < poly.length; i++) b.edge(P(i, base), P(i, tops[i]));
}

/**
 * A beam with its ends brought back to the face of the columns they stand in (a column has priority over a beam).
 * Only the solid changes: the element's own ends stay where they were drawn.
 */
export function trimmedBeam(doc, el) {
  const L = len(sub(el.b, el.a));
  if (L < 1) return el;
  const depth = +doc.get(el.typeId)?.depth || 600;
  const z0 = levelElevation(doc, el.levelId) + (+el.offset || 0);
  const z1 = el.endOffset != null ? levelElevation(doc, el.levelId) + +el.endOffset : z0;
  const cut = (p, q, z) => {
    const d = norm(sub(q, p));
    let far = 0;
    for (const c of doc.all('column')) {
      const { base, top } = verticalExtent(doc, c);
      if (!(base < z && top > z - depth)) continue;
      const type = doc.get(c.typeId) || {};
      const w = +type.width || 450;
      const h = +type.depth || w;
      const fr = new Frame(c.at, ((+c.rotation || 0) * Math.PI) / 180, 0);
      const poly = type.shape === 'round' ? Array.from({ length: 32 }, (_, i) => [c.at[0] + (w / 2) * Math.cos((i * Math.PI) / 16), c.at[1] + (w / 2) * Math.sin((i * Math.PI) / 16)]) : [[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]].map((v) => fr.apply(v));
      if (!pointInPolygon(p, poly)) continue;
      for (let i = 0; i < poly.length; i++) {
        const a = poly[i];
        const e = sub(poly[(i + 1) % poly.length], a);
        const den = d[0] * e[1] - d[1] * e[0];
        if (Math.abs(den) < 1e-9) continue;
        const r = sub(a, p);
        const t = (r[0] * e[1] - r[1] * e[0]) / den;
        const u = (r[0] * d[1] - r[1] * d[0]) / den;
        if (t > 0 && u >= 0 && u <= 1) far = Math.max(far, t);
      }
    }
    return far;
  };
  const ta = cut(el.a, el.b, z0);
  const tb = cut(el.b, el.a, z1);
  if ((!ta && !tb) || L - ta - tb < 1) return el;
  const d = norm(sub(el.b, el.a));
  const dz = (z1 - z0) / L;
  return {
    ...el,
    a: add(el.a, scale(d, ta)),
    b: add(el.b, scale(d, -tb)),
    offset: (+el.offset || 0) + dz * ta,
    ...(el.endOffset != null ? { endOffset: +el.endOffset - dz * tb } : {}),
  };
}

function buildBeam(ctx, drawn) {
  const el = trimmedBeam(ctx.doc, drawn);
  const type = ctx.doc.get(el.typeId) || {};
  const l = len(sub(el.b, el.a));
  if (l < 1) return null;
  const zt = levelElevation(ctx.doc, el.levelId) + (+el.offset || 0);
  const prof = profileOf(ctx.doc, el);
  if (prof) return buildProfiledBeam(ctx.doc, el, prof, zt);
  const w = +type.width || 300;
  const d = +type.depth || 600;
  const dir = norm(sub(el.b, el.a));
  const n = perp(dir);
  const col = materialColor(ctx, type.materialId || 'mat-concrete');
  const b = new MeshBuilder();
  // A varying beam: its width and depth change from end to end (End Width, End Depth).
  const w1 = +el.endWidth || w;
  const d1 = +el.endDepth || d;
  if (w1 !== w || d1 !== d) {
    const z1 = el.endOffset != null ? levelElevation(ctx.doc, el.levelId) + +el.endOffset : zt;
    const A = (s, k) => [el.a[0] + n[0] * s, el.a[1] + n[1] * s, zt - k];
    const B = (s, k) => [el.b[0] + n[0] * s, el.b[1] + n[1] * s, z1 - k];
    const [a0, a1, b0, b1] = [A(-w / 2, 0), A(w / 2, 0), B(-w1 / 2, 0), B(w1 / 2, 0)];
    const [a2, a3, b2, b3] = [A(w / 2, d), A(-w / 2, d), B(w1 / 2, d1), B(-w1 / 2, d1)];
    b.quad(a0, b0, b1, a1, col);
    b.quad(a2, b2, b3, a3, col);
    b.quad(a3, b3, b0, a0, col);
    b.quad(a1, b1, b2, a2, col);
    b.quad(a0, a1, a2, a3, col);
    b.quad(b1, b0, b3, b2, col);
    b.edgeLoop([a0, a1, a2, a3]);
    b.edgeLoop([b0, b1, b2, b3]);
    for (const [x, y] of [[a0, b0], [a1, b1], [a2, b2], [a3, b3]]) b.edge(x, y);
    return b.build();
  }
  // A sloping beam (a rafter): its top from offset at a to endOffset at b, its section square to its axis.
  if (el.endOffset != null && Math.abs(+el.endOffset - (+el.offset || 0)) > 0.5) {
    const z1 = levelElevation(ctx.doc, el.levelId) + +el.endOffset;
    const ax = [el.b[0] - el.a[0], el.b[1] - el.a[1], z1 - zt];
    const L = Math.hypot(...ax);
    const u = ax.map((v) => v / L);
    const side = [n[0], n[1], 0];
    // Down, square to the axis: side x axis, pointing below.
    let down = [side[1] * u[2] - side[2] * u[1], side[2] * u[0] - side[0] * u[2], side[0] * u[1] - side[1] * u[0]];
    if (down[2] > 0) down = down.map((v) => -v);
    // A beam's ends are cut plumb, as Archicad's; the members of a roof's framing stay square to their axis.
    const cos = Math.hypot(ax[0], ax[1]) / L;
    const plumb = !el.framingOf && el.endCut !== 'square' && cos > 0.01;
    const P = (p, z, s, k) => (plumb ? [p[0] + side[0] * s, p[1] + side[1] * s, z - k / cos] : [p[0] + side[0] * s + down[0] * k, p[1] + side[1] * s + down[1] * k, z + side[2] * s + down[2] * k]);
    const A = (s, k) => P(el.a, zt, s, k);
    const B = (s, k) => P(el.b, z1, s, k);
    const h = w / 2;
    b.quad(A(-h, 0), B(-h, 0), B(h, 0), A(h, 0), col);
    b.quad(A(h, d), B(h, d), B(-h, d), A(-h, d), col);
    b.quad(A(-h, d), B(-h, d), B(-h, 0), A(-h, 0), col);
    b.quad(A(h, 0), B(h, 0), B(h, d), A(h, d), col);
    b.quad(A(-h, 0), A(h, 0), A(h, d), A(-h, d), col);
    b.quad(B(h, 0), B(-h, 0), B(-h, d), B(h, d), col);
    for (const [s, k] of [[-h, 0], [h, 0], [h, d], [-h, d]]) b.edge(A(s, k), B(s, k));
    b.edgeLoop([A(-h, 0), A(h, 0), A(h, d), A(-h, d)]);
    b.edgeLoop([B(-h, 0), B(h, 0), B(h, d), B(-h, d)]);
    return b.build();
  }
  const pts = [add(el.a, scale(n, -w / 2)), add(el.b, scale(n, -w / 2)), add(el.b, scale(n, w / 2)), add(el.a, scale(n, w / 2))];
  b.prism(pts, [], zt - d, zt, col);
  return b.build();
}

// Stairs and railings ----------------------------------------------------------------------

export function stairGeometry(doc, el) {
  const lay = stairLayout(doc, el);
  const d = sub(el.b, el.a);
  const dir = len(d) > 1 ? norm(d) : [1, 0];
  return { ...lay, dir, side: perp(dir) };
}

function buildStair(ctx, el) {
  const type = ctx.doc.get(el.typeId) || {};
  const g = stairFlights(ctx.doc, el);
  const th = +type.thickness || 150;
  const col = materialColor(ctx, type.materialId || 'mat-concrete');
  const b = new MeshBuilder();
  if (g.spiral) {
    // Wedge treads around a central column, each at its riser height.
    const s = g.spiral;
    const tt = Math.min(th, g.riserHeight * 0.8);
    const arc = (r, a0, a1) => Array.from({ length: 7 }, (_, k) => {
      const a = a0 + ((a1 - a0) * k) / 6;
      return [s.c[0] + Math.cos(a) * r, s.c[1] + Math.sin(a) * r];
    });
    for (let i = 0; i < s.treads; i++) {
      const a0 = s.a0 + s.step * i;
      const a1 = a0 + s.step * 1.04;
      const outer = arc(s.rout, a0, a1);
      const inner = arc(s.rin, a1, a0);
      const z = g.base + (i + 1) * g.riserHeight;
      b.prism([...outer, ...inner], [], z - tt, z, col);
    }
    b.cylinder(s.c, SPIRAL_CORE, g.base, g.base + g.risers * g.riserHeight + 900, materialColor(ctx, 'mat-steel'), { segments: 16 });
    if (el.railings !== false) {
      // A helical handrail round the outer edge, on a baluster per tread.
      const rail = materialColor(ctx, 'mat-steel');
      const rr = s.rout - 40;
      const at = (t) => {
        const a = s.a0 + s.step * t;
        return [s.c[0] + Math.cos(a) * rr, s.c[1] + Math.sin(a) * rr];
      };
      const zr = (t) => g.base + t * g.riserHeight + 900;
      const segs = s.treads * 3;
      for (let k = 0; k < segs; k++) {
        const t0 = 0.5 + ((s.treads - 0.5) * k) / segs;
        const t1 = 0.5 + ((s.treads - 0.5) * (k + 1)) / segs;
        const p0 = at(t0);
        const d = sub(at(t1), p0);
        const L = len(d);
        if (L < 1) continue;
        const dir = scale(d, 1 / L);
        const prof = [[0, zr(t0) - 40], [L, zr(t1) - 40], [L, zr(t1)], [0, zr(t0)]];
        b.extrudeProfile(prof, add(p0, scale(perp(dir), -20)), dir, 40, rail);
      }
      for (let i = 0; i < s.treads; i++) b.cylinder(at(i + 0.5), 12, g.base + (i + 1) * g.riserHeight, zr(i + 0.5), rail, { segments: 8, edges: false });
    }
    return b.build();
  }
  for (const f of g.flights) buildFlight(b, el, type, f, g, th, col, ctx);
  for (const l of g.landings) if (!landingParts(b, ctx, type, l, g, th)) b.prism(l.poly, [], l.z - (type.monolithic !== false ? th : 40), l.z, col);
  return b.build();
}

/**
 * A flight's treads and risers from the stair type's Archicad components
 * (stairparts.js), each run with its piece's polygon and placed at its top.
 */
/** A component run's triangles and edges (mm, in its piece's frame) placed at a point, turned and raised. */
function placePart(b, ctx, r, at, angle, z, fallback) {
  if (!r?.tris?.length) return;
  const fr = new Frame(at, angle, z);
  const P = (p) => {
    const q = fr.apply([p[0], p[1]]);
    return [q[0], q[1], z + p[2]];
  };
  const colors = new Map();
  const colorOf = (m) => {
    const key = typeof m === 'string' && m ? m : fallback;
    if (!colors.has(key)) colors.set(key, materialColor(ctx, key));
    return colors.get(key);
  };
  for (const t of r.tris) b.tri(P(t.a), P(t.b), P(t.c), t.rgb ? [...t.rgb.map((v) => Math.round(v * 255)), Math.round((t.alpha ?? 1) * 255)] : colorOf(t.mat));
  for (const [a, c] of r.edges) b.edge(P(a), P(c));
}

function flightParts(b, ctx, type, f, g, origin, nosing) {
  const { riserHeight: rh, tread: td, width: W } = g;
  const tread = type.treadPartId && ctx.doc.get(type.treadPartId);
  const riser = type.riserPartId && ctx.doc.get(type.riserPartId);
  const angle = Math.atan2(f.dir[1], f.dir[0]);
  const place = (r, at, z) => placePart(b, ctx, r, at, angle, z, type.materialId || 'mat-wood');
  const n = f.risers;
  const th = +type.thickness || 40;
  const rt = +type.riserThickness || 20;
  if (tread) {
    const r = runStairPart(tread, treadGlobals({ depth: td, width: W, nosing, thickness: th, riserHeight: rh, riserThickness: rt }));
    for (let i = 0; i < n - 1; i++) place(r, add(origin, scale(f.dir, i * td)), f.z0 + (i + 1) * rh);
  }
  if (riser) {
    const r = runStairPart(riser, riserGlobals({ width: W, height: rh, thickness: rt }));
    for (let i = 0; i < n; i++) place(r, add(origin, scale(f.dir, i * td)), f.z0 + (i + 1) * rh);
  }
  // The structure under the treads (a stringer, a beam, cantilevered brackets), run once for the flight.
  const structure = type.structurePartId && ctx.doc.get(type.structurePartId);
  if (structure && n >= 2) place(runStairPart(structure, structureGlobals({ steps: n - 1, depth: td, width: W, riserHeight: rh, thickness: th, nosing, riserThickness: rt })), origin, f.z0);
  return { treads: !!tread, structure: !!structure };
}

/**
 * A landing from the stair type's Archicad components: the tread component
 * over its whole outline and the landing structure under it, laid out with
 * the arriving flight's going along x. False when the type has neither.
 */
function landingParts(b, ctx, type, l, g, th) {
  const tread = type.treadPartId && ctx.doc.get(type.treadPartId);
  const structure = type.landingPartId && ctx.doc.get(type.landingPartId);
  if ((!tread && !structure) || l.poly.length !== 4) return false;
  const [p0, p1, , p3] = l.poly;
  const along = sub(p1, p0);
  const L = Math.round(len(along));
  const W = Math.round(len(sub(p3, p0)));
  const angle = Math.atan2(along[1], along[0]);
  const fallback = type.materialId || 'mat-wood';
  // Its outline runs from the arriving edge (p0..p3) along the going, across from the corner on the right.
  const origin = cross2(along, sub(p3, p0)) > 0 ? p0 : p3;
  const rh = g.riserHeight;
  if (tread) placePart(b, ctx, runStairPart(tread, treadGlobals({ depth: L, width: W, thickness: th, riserHeight: rh, riserThickness: +type.riserThickness || 20 })), origin, angle, l.z, fallback);
  if (structure) placePart(b, ctx, runStairPart(structure, structureGlobals({ steps: 1, depth: L, width: W, riserHeight: rh, thickness: th, polyFlag: landingPolyFlag(structure) })), origin, angle, l.z - rh, fallback);
  // A plain landing slab under a tread when nothing else carries it.
  if (!structure && type.monolithic !== false) b.prism(l.poly, [], l.z - th - Math.max(th, 150), l.z - th, materialColor(ctx, type.materialId || 'mat-concrete'));
  return true;
}

const cross2 = (a, c) => a[0] * c[1] - a[1] * c[0];

function buildFlight(b, el, type, f, g, th, col, ctx) {
  const { riserHeight: rh, tread: td, width: W } = g;
  const { dir, side } = f;
  const base = f.z0;
  const origin = add(f.start, scale(side, -W / 2));
  const n = f.risers;
  const sEnd = f.run;
  // Archicad treads, risers and structure, when the type has them: in place of plain treads and stringers.
  const own = n >= 2 ? flightParts(b, ctx, type, f, g, origin, 25) : {};
  const ownTreads = own.treads;
  if (n < 2) {
    b.prism(flightOutline({ ...f, run: Math.max(1, td * 0.2) }, W), [], base, base + rh, col);
    return;
  }
  if (type.monolithic !== false && !own.structure) {
    const prof = [[0, base]];
    for (let i = 0; i < n - 1; i++) {
      prof.push([i * td, base + (i + 1) * rh]);
      prof.push([(i + 1) * td, base + (i + 1) * rh]);
    }
    prof.push([sEnd, base + n * rh]);
    const ang = Math.atan2(rh, td);
    const zu = (s) => base + rh + Math.tan(ang) * s - th / Math.cos(ang);
    prof.push([sEnd, Math.max(base, zu(sEnd))]);
    const s0 = Math.max(0, Math.min(sEnd - 1, (th / Math.cos(ang) - rh) / Math.tan(ang)));
    prof.push([s0, base]);
    b.extrudeProfile(dedupe(prof), origin, dir, W, col);
  } else {
    const tt = th;
    for (let i = 0; i < n - 1 && !ownTreads; i++) {
      const z = base + (i + 1) * rh;
      const s0 = i * td - 25;
      const s1 = (i + 1) * td;
      const pts = [add(origin, scale(dir, s0)), add(origin, scale(dir, s1)), add(add(origin, scale(dir, s1)), scale(side, W)), add(add(origin, scale(dir, s0)), scale(side, W))];
      b.prism(pts, [], z - tt, z, col);
    }
    // Plain stringers, unless an Archicad structure carries the treads.
    for (const off of own.structure ? [] : [0, W - 40]) {
      const prof = [
        [0, base],
        [sEnd, base + n * rh - 200],
        [sEnd, base + n * rh],
        [0, base + 200 + rh],
      ];
      b.extrudeProfile(prof, add(origin, scale(side, off)), dir, 40, col);
    }
  }
  if (el.railings !== false) {
    const rail = materialColor(ctx, 'mat-steel');
    const h = 900;
    for (const off of [60, W - 60]) {
      const p0 = add(add(origin, scale(side, off)), scale(dir, td * 0.5));
      const p1 = add(add(origin, scale(side, off)), scale(dir, sEnd - td * 0.2));
      const z0 = base + rh * 1.5 + h;
      const z1 = base + n * rh - rh * 0.2 + h;
      const prof = [
        [0, z0 - 40],
        [len(sub(p1, p0)), z1 - 40],
        [len(sub(p1, p0)), z1],
        [0, z0],
      ];
      b.extrudeProfile(prof, add(p0, scale(side, -20)), dir, 40, rail);
      const posts = Math.max(2, Math.round(sEnd / 1200) + 1);
      for (let i = 0; i < posts; i++) {
        const s = td * 0.5 + ((sEnd - td * 0.7) * i) / (posts - 1);
        const step = Math.min(n - 1, Math.floor(s / td));
        const zb = base + (step + 1) * rh;
        const zt = z0 + ((z1 - z0) * (s - td * 0.5)) / Math.max(1, sEnd - td * 0.7);
        const c = add(add(origin, scale(side, off)), scale(dir, s));
        b.cylinder(c, 15, zb, zt, rail, { segments: 8, edges: false });
      }
    }
  }
}

/**
 * A railing made of the type's Archicad components (stairparts.js): posts
 * along its path at a spacing and at its corners, a toprail along each of
 * its segments at the railing's height, panels between the posts.
 */
function railingParts(ctx, el, type, z, zAt) {
  const post = type.postPartId && ctx.doc.get(type.postPartId);
  const rail = type.railPartId && ctx.doc.get(type.railPartId);
  const panel = type.panelPartId && ctx.doc.get(type.panelPartId);
  if (!post && !rail && !panel) return null;
  const b = new MeshBuilder();
  const H = +type.height || 1100;
  const sp = Math.max(300, +type.postSpacing || 1200);
  const mat = type.materialId || 'mat-steel';
  // Posts: at each corner and evenly between, each standing at the path's height there.
  const posts = [];
  for (let i = 0; i + 1 < el.path.length; i++) {
    const a = el.path[i];
    const c = el.path[i + 1];
    const L = len(sub(c, a));
    if (L < 1) continue;
    const n = Math.max(1, Math.ceil(L / sp));
    for (let k = i === 0 ? 0 : 1; k <= n; k++) posts.push({ at: add(a, scale(sub(c, a), k / n)), z: zAt(i) + ((zAt(i + 1) - zAt(i)) * k) / n, seg: i, k, n });
  }
  if (post) {
    const r = runStairPart(post, postGlobals({ height: H }));
    for (const p of posts) placePart(b, ctx, r, p.at, 0, p.z, mat);
  }
  if (panel)
    for (let j = 0; j + 1 < posts.length; j++) {
      const p = posts[j];
      const q = posts[j + 1];
      const L = len(sub(q.at, p.at));
      if (L < 1) continue;
      const d = sub(q.at, p.at);
      const r = runStairPart(panel, panelGlobals({ length: Math.round(L), z0: 100, z1: Math.max(200, H - 150), rise: Math.round(q.z - p.z) }));
      placePart(b, ctx, r, p.at, Math.atan2(d[1], d[0]), p.z, mat);
    }
  // A toprail along each segment of the path, as Archicad's railing segments have one each.
  if (rail)
    for (let i = 0; i + 1 < el.path.length; i++) {
      const o = el.path[i];
      const d = sub(el.path[i + 1], o);
      const L = len(d);
      if (L < 1) continue;
      placePart(b, ctx, runStairPart(rail, railGlobals([[0, 0, H], [Math.round(L), 0, Math.round(zAt(i + 1) - zAt(i)) + H]])), o, Math.atan2(d[1], d[0]), zAt(i), mat);
    }
  void z;
  return b.build();
}

function buildRailing(ctx, el) {
  if (!el.path || el.path.length < 2) return null;
  const type = ctx.doc.get(el.typeId) || {};
  const z = levelElevation(ctx.doc, el.levelId) + (+el.offset || 0);
  // Archicad posts, rails and panels, when the type has them.
  const own = railingParts(ctx, el, type, z, (i) => z + (+el.pathZ?.[i] || 0));
  if (own) return own;
  const H0 = +type.height || 1100;
  const r = +type.rail || 50;
  const bw = +type.baluster || 20;
  const sp = +type.spacing || 110;
  const col = materialColor(ctx, type.materialId || 'mat-steel');
  const glass = materialColor(ctx, 'mat-glass');
  const b = new MeshBuilder();
  // Heights along the path (pathZ, above the level): a railing on a stair climbs with it.
  const zAt = (i) => z + (+el.pathZ?.[i] || 0);
  for (let i = 0; i + 1 < el.path.length; i++) {
    const a = el.path[i];
    const c = el.path[i + 1];
    const L = len(sub(c, a));
    if (L < 1) continue;
    // System Edit Mode: each segment's own infill, height and top rail (el.segments[i]).
    const seg = el.segments?.[i] || {};
    if (seg.infill === 'none') continue;
    const H = +seg.height || H0;
    const glassSeg = seg.infill ? seg.infill === 'glass' : !!type.glass;
    const railOn = seg.rail !== false;
    const dir = norm(sub(c, a));
    const za = zAt(i);
    const zc = zAt(i + 1);
    if (Math.abs(zc - za) > 1) {
      // Sloped: the top rail follows the slope, balusters stand on it.
      if (railOn) b.beam3([a[0], a[1], za + H - r / 2], [c[0], c[1], zc + H - r / 2], r, r, col);
      const fr = new Frame(a, Math.atan2(dir[1], dir[0]), za);
      const count = Math.max(1, Math.floor(L / sp));
      for (let k = 0; k <= count; k++) {
        const s = Math.min(L - bw / 2, Math.max(bw / 2, (k * L) / count));
        const zb = ((zc - za) * s) / L;
        frameBox(b, fr, s - bw / 2, -bw / 2, zb, s + bw / 2, bw / 2, zb + H - r, col, { edges: false });
      }
      continue;
    }
    const fr = new Frame(a, Math.atan2(dir[1], dir[0]), za);
    if (railOn) frameBox(b, fr, 0, -r / 2, H - r, L, r / 2, H, col);
    if (seg.infill === 'open') {
      // Posts at the ends only.
      frameBox(b, fr, 0, -bw / 2, 0, bw * 2, bw / 2, H - r, col);
      frameBox(b, fr, L - bw * 2, -bw / 2, 0, L, bw / 2, H - r, col);
    } else if (glassSeg) {
      frameBox(b, fr, bw, -6, 80, L - bw, 6, H - r - 30, glass, { edges: false });
      frameBox(b, fr, 0, -bw / 2, 0, bw, bw / 2, H - r, col);
    } else {
      const count = Math.max(1, Math.floor(L / sp));
      for (let k = 0; k <= count; k++) {
        const s = Math.min(L - bw / 2, Math.max(bw / 2, (k * L) / count));
        frameBox(b, fr, s - bw / 2, -bw / 2, 0, s + bw / 2, bw / 2, H - r, col, { edges: false });
      }
    }
  }
  if (type.glass && el.segments?.at?.(-1)?.infill !== 'none') {
    const H = +el.segments?.[el.path.length - 2]?.height || H0;
    const last = el.path.at(-1);
    const prev = el.path.at(-2);
    const dir = norm(sub(last, prev));
    const fr = new Frame(last, Math.atan2(dir[1], dir[0]), zAt(el.path.length - 1));
    frameBox(b, fr, -bw, -bw / 2, 0, 0, bw / 2, H - r, col);
  }
  return b.build();
}

// Components ---------------------------------------------------------------------------------

function buildComponent(ctx, el) {
  const type = ctx.doc.get(el.typeId);
  if (!type) return null;
  const z = levelElevation(ctx.doc, el.levelId) + (+el.offset || 0) + (+type.elevation || 0);
  const frame = new Frame(el.at, ((+el.rotation || 0) * Math.PI) / 180, z);
  const b = new MeshBuilder();
  buildFamily(type, frame, b, (id) => ctx.material(id), el.gdlValues || {});
  return b.build();
}
