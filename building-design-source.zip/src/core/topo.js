/**
 * Topography: a ground surface through surveyed points [x, y, z]. The points
 * are triangulated (Delaunay, in plan); plans draw contour lines and 3D
 * views a solid of the given thickness under the surface.
 *
 *   topo { points: [[x, y, z]], boundary?: [[x, y, z]], ridges?: [[[x, y, z]]], thickness, contour, materialId }
 *
 * Archicad's Mesh: a polygon contour whose corners have their own heights
 * (`boundary`) and ridges (break lines) inside it, with or without points.
 * Contour and ridges are divided finely and triangulated with the points;
 * the surface stops at the contour. All helpers take the surface from
 * topoSurface().
 */

/** Delaunay triangulation of 2D points: array of [i, j, k] index triples. */
export function delaunay(pts) {
  const n = pts.length;
  if (n < 3) return [];
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (const p of pts) {
    x0 = Math.min(x0, p[0]);
    y0 = Math.min(y0, p[1]);
    x1 = Math.max(x1, p[0]);
    y1 = Math.max(y1, p[1]);
  }
  const d = Math.max(x1 - x0, y1 - y0) * 20 || 1;
  const cx = (x0 + x1) / 2;
  const cy = (y0 + y1) / 2;
  // A super triangle containing everything.
  const P = pts.map((p) => [p[0], p[1]]).concat([
    [cx - d, cy - d],
    [cx + d, cy - d],
    [cx, cy + d],
  ]);
  let tris = [[n, n + 1, n + 2]];
  const circum = (t) => {
    const [a, b, c] = t.map((i) => P[i]);
    const D = 2 * (a[0] * (b[1] - c[1]) + b[0] * (c[1] - a[1]) + c[0] * (a[1] - b[1]));
    if (Math.abs(D) < 1e-12) return { x: 0, y: 0, r2: Infinity };
    const a2 = a[0] * a[0] + a[1] * a[1];
    const b2 = b[0] * b[0] + b[1] * b[1];
    const c2 = c[0] * c[0] + c[1] * c[1];
    const x = (a2 * (b[1] - c[1]) + b2 * (c[1] - a[1]) + c2 * (a[1] - b[1])) / D;
    const y = (a2 * (c[0] - b[0]) + b2 * (a[0] - c[0]) + c2 * (b[0] - a[0])) / D;
    return { x, y, r2: (a[0] - x) ** 2 + (a[1] - y) ** 2 };
  };
  let circles = tris.map(circum);
  for (let i = 0; i < n; i++) {
    const p = P[i];
    const bad = [];
    const keep = [];
    const keepC = [];
    tris.forEach((t, k) => {
      const c = circles[k];
      if ((p[0] - c.x) ** 2 + (p[1] - c.y) ** 2 < c.r2 * (1 - 1e-12)) bad.push(t);
      else {
        keep.push(t);
        keepC.push(c);
      }
    });
    // The hole's boundary: edges of bad triangles not shared by two of them.
    const edges = new Map();
    for (const t of bad)
      for (let e = 0; e < 3; e++) {
        const a = t[e];
        const b = t[(e + 1) % 3];
        const key = a < b ? `${a},${b}` : `${b},${a}`;
        edges.set(key, edges.has(key) ? null : [a, b]);
      }
    for (const e of edges.values()) {
      if (!e) continue;
      const t = [e[0], e[1], i];
      keep.push(t);
      keepC.push(circum(t));
    }
    tris = keep;
    circles = keepC;
  }
  return tris.filter((t) => t[0] < n && t[1] < n && t[2] < n);
}

const SURFACES = new WeakMap();

/** Points along a polyline, at most `step` apart (heights interpolated), closed when asked. */
export function densify(line, step, closed = false) {
  const out = [];
  const n = line.length;
  for (let i = 0; i < (closed ? n : n - 1); i++) {
    const a = line[i];
    const b = line[(i + 1) % n];
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
    const k = Math.max(1, Math.ceil(L / step));
    for (let j = 0; j < k; j++) {
      const t = j / k;
      out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, (a[2] ?? 0) + ((b[2] ?? 0) - (a[2] ?? 0)) * t]);
    }
  }
  if (!closed && n) out.push([...line[n - 1]]);
  return out;
}

function inPoly(p, poly) {
  let r = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const c = poly[j];
    if (a[1] > p[1] !== c[1] > p[1] && p[0] < ((c[0] - a[0]) * (p[1] - a[1])) / (c[1] - a[1]) + a[0]) r = !r;
  }
  return r;
}

/**
 * The surface of a terrain: { P (points [x, y, z]), tris ([i, j, k]) }. Plain point meshes triangulate their
 * points; a mesh with a contour or ridges adds them, divided finely, and keeps only what lies inside the contour.
 */
export function topoSurface(topo) {
  const hit = SURFACES.get(topo);
  if (hit) return hit;
  const pts = (topo.points || []).filter((p) => p?.length >= 3);
  const bnd = (topo.boundary || []).filter((p) => p?.length >= 2);
  const ridges = (topo.ridges || []).filter((r) => r?.length >= 2);
  let out;
  if (bnd.length < 3 && !ridges.length) out = { P: pts, tris: delaunay(pts) };
  else {
    const all = [...pts];
    // Divide the contour and ridges so the triangulation follows them.
    const ext = (() => {
      const xs = [...bnd, ...pts, ...ridges.flat()].map((p) => p[0]);
      const ys = [...bnd, ...pts, ...ridges.flat()].map((p) => p[1]);
      return Math.max(Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys));
    })();
    const step = Math.max(100, (+topo.precision || ext / 40) || 500);
    if (bnd.length >= 3) all.push(...densify(bnd, step, true));
    for (const r of ridges) all.push(...densify(r, step / 2));
    // Points closer than 1 mm are one.
    const seen = new Map();
    const P = [];
    for (const p of all) {
      const k = `${Math.round(p[0])},${Math.round(p[1])}`;
      if (seen.has(k)) continue;
      seen.set(k, P.length);
      P.push([p[0], p[1], p[2] ?? 0]);
    }
    let tris = delaunay(P);
    if (bnd.length >= 3) tris = tris.filter(([i, j, k]) => inPoly([(P[i][0] + P[j][0] + P[k][0]) / 3, (P[i][1] + P[j][1] + P[k][1]) / 3], bnd));
    out = { P, tris };
  }
  if (topo && typeof topo === 'object') SURFACES.set(topo, out);
  return out;
}

/** The surface from an argument: a topoSurface, or (older callers) the triangles of the plain points. */
const surf = (topo, arg) => (Array.isArray(arg) ? { P: topo.points, tris: arg } : arg || topoSurface(topo));

/** Elevation of the surface at a plan point (null outside). */
export function topoHeightAt(topo, p, given) {
  const { P, tris } = surf(topo, given);
  for (const [i, j, k] of tris) {
    const a = P[i];
    const b = P[j];
    const c = P[k];
    const det = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1]);
    if (Math.abs(det) < 1e-9) continue;
    const l1 = ((b[1] - c[1]) * (p[0] - c[0]) + (c[0] - b[0]) * (p[1] - c[1])) / det;
    const l2 = ((c[1] - a[1]) * (p[0] - c[0]) + (a[0] - c[0]) * (p[1] - c[1])) / det;
    const l3 = 1 - l1 - l2;
    if (l1 >= -1e-9 && l2 >= -1e-9 && l3 >= -1e-9) return l1 * a[2] + l2 * b[2] + l3 * c[2];
  }
  return null;
}

/**
 * Contour segments at every multiple of `interval`:
 * [{ z, major, a: [x, y], b: [x, y] }]. Every fifth contour is major.
 */
export function contours(topo, interval, given) {
  const { P, tris } = surf(topo, given);
  const out = [];
  if (!(interval > 0)) return out;
  for (const [i, j, k] of tris) {
    const tri = [P[i], P[j], P[k]];
    const zs = tri.map((p) => p[2]);
    const lo = Math.ceil(Math.min(...zs) / interval);
    const hi = Math.floor(Math.max(...zs) / interval);
    for (let m = lo; m <= hi; m++) {
      const z = m * interval;
      const hits = [];
      for (let e = 0; e < 3; e++) {
        const a = tri[e];
        const b = tri[(e + 1) % 3];
        if ((a[2] - z) * (b[2] - z) < 0) {
          const t = (z - a[2]) / (b[2] - a[2]);
          hits.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
        }
      }
      if (hits.length === 2) out.push({ z, major: m % 5 === 0, a: hits[0], b: hits[1] });
    }
  }
  return out;
}

/** Outline of the surface (convex hull of the points, counterclockwise). */
export function topoBoundary(topo) {
  if ((topo.boundary || []).length >= 3) {
    const b = topo.boundary.map((p) => [p[0], p[1]]);
    let a = 0;
    for (let i = 0; i < b.length; i++) a += b[i][0] * b[(i + 1) % b.length][1] - b[(i + 1) % b.length][0] * b[i][1];
    return a >= 0 ? b : b.reverse();
  }
  const pts = topoSurface(topo).P.map((p) => [p[0], p[1]]).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  if (pts.length < 3) return pts;
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lower = [];
  for (const p of pts) {
    while (lower.length >= 2 && cross(lower.at(-2), lower.at(-1), p) <= 0) lower.pop();
    lower.push(p);
  }
  const upper = [];
  for (let i = pts.length - 1; i >= 0; i--) {
    const p = pts[i];
    while (upper.length >= 2 && cross(upper.at(-2), upper.at(-1), p) <= 0) upper.pop();
    upper.push(p);
  }
  return lower.slice(0, -1).concat(upper.slice(0, -1));
}

/** A rectangular site of points on a grid, gently sloped, to start from. */
export function sampleTopo(x0, y0, x1, y1, z0 = 0, rise = 0) {
  const pts = [];
  const nx = 5;
  const ny = 4;
  for (let i = 0; i <= nx; i++)
    for (let j = 0; j <= ny; j++) {
      const x = x0 + ((x1 - x0) * i) / nx;
      const y = y0 + ((y1 - y0) * j) / ny;
      pts.push([x, y, Math.round(z0 + (rise * j) / ny)]);
    }
  return pts;
}

/** Column orders survey point files come in. */
export const SURVEY_ORDERS = [
  { value: 'auto', label: 'Automatic (X Y Z, or ID X Y Z)' },
  { value: 'xyz', label: 'X Y Z' },
  { value: 'ixyz', label: 'ID X Y Z' },
  { value: 'yxz', label: 'Y X Z (Northing, Easting)' },
  { value: 'iyxz', label: 'ID Y X Z' },
];

const UNIT_MM = { m: 1000, mm: 1, cm: 10, ft: 304.8 };

/**
 * Survey points from text (CSV, TXT, XYZ: one point per line, numbers
 * separated by commas, semicolons, tabs or spaces; other lines are left
 * out). Returns points [[x, y, z]] in millimetres.
 */
export function parseSurveyPoints(text, { order = 'auto', unit = 'm' } = {}) {
  const k = UNIT_MM[unit] || 1000;
  const out = [];
  for (const raw of String(text).split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || /^[#;/]/.test(line)) continue;
    // A decimal comma only when fields are not separated by commas.
    const fields = (line.includes(';') || line.includes('\t') ? line.split(/[;\t]+/) : line.split(/[,\s]+/)).map((f) => f.trim()).filter(Boolean);
    const nums = fields.map((f) => Number(f.replace(/^(-?\d+),(\d+)$/, '$1.$2')));
    const numeric = nums.filter(Number.isFinite);
    let o = order;
    if (o === 'auto') o = numeric.length >= 4 ? 'ixyz' : 'xyz';
    let vals;
    if (o === 'xyz' || o === 'yxz') vals = numeric.slice(0, 3);
    else vals = Number.isFinite(nums[0]) ? numeric.slice(1, 4) : numeric.slice(0, 3);
    if (vals.length < 3) continue;
    let [x, y, z] = vals;
    if (o === 'yxz' || o === 'iyxz') [x, y] = [y, x];
    out.push([x * k, y * k, z * k]);
  }
  return out;
}

/** Points moved so their middle (in plan) is at the origin; heights kept. */
export function centrePoints(pts) {
  if (!pts.length) return pts;
  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  const cx = (Math.min(...xs) + Math.max(...xs)) / 2;
  const cy = (Math.min(...ys) + Math.max(...ys)) / 2;
  return pts.map((p) => [p[0] - cx, p[1] - cy, p[2]]);
}
