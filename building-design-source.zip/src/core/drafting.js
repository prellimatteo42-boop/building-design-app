/**
 * Precise drafting, as Archicad's: the construction grid (spacing, rotation
 * and origin, with snapping to its nodes), the user origin that coordinates
 * are read from, the Tracker's values while drawing (absolute X/Y from the
 * user origin, or relative to the last point as dX/dY or distance and
 * angle) and the point they give back, the parallel and bisector cursor
 * constraints, and the history of zooms of a view.
 *
 *   project.drafting = { grid: { spacing: [sx, sy], angle (deg), origin: [x, y], show, snap }, userOrigin: [x, y] }
 */

export const GRID_DEFAULTS = { spacing: [1000, 1000], angle: 0, rotated: false, origin: [0, 0], show: false, snap: false };

/**
 * The project's drafting settings with defaults. The grid is orthogonal unless `rotated` is on (Archicad's
 * Orthogonal / Rotated Grid); `angle` keeps the rotated grid's angle either way, and the returned grid's
 * `angle` is the one in use.
 */
export function draftingOf(project) {
  const d = project?.drafting || {};
  const g = { ...GRID_DEFAULTS, ...(d.grid || {}) };
  const sp = Array.isArray(g.spacing) ? g.spacing : [g.spacing, g.spacing];
  return {
    grid: { ...g, rotatedAngle: +g.angle || 0, angle: g.rotated ? +g.angle || 0 : 0, origin: g.rotated ? g.origin || [0, 0] : [0, 0], spacing: [Math.max(1, +sp[0] || 1000), Math.max(1, +(sp[1] ?? sp[0]) || 1000)] },
    userOrigin: d.userOrigin || [0, 0],
  };
}

/** A patch for project.drafting: the stored settings with some grid fields or the user origin changed. */
export function draftingPatch(project, { grid = null, userOrigin } = {}) {
  const d = project?.drafting || {};
  return { drafting: { ...d, ...(grid ? { grid: { ...GRID_DEFAULTS, ...(d.grid || {}), ...grid } } : {}), ...(userOrigin !== undefined ? { userOrigin } : {}) } };
}

const RAD = Math.PI / 180;

/** A point in grid coordinates (along the grid's axes from its origin) and back. */
export function toGrid(grid, p) {
  const a = (grid.angle || 0) * RAD;
  const dx = p[0] - grid.origin[0];
  const dy = p[1] - grid.origin[1];
  return [dx * Math.cos(a) + dy * Math.sin(a), -dx * Math.sin(a) + dy * Math.cos(a)];
}

export function fromGrid(grid, q) {
  const a = (grid.angle || 0) * RAD;
  return [grid.origin[0] + q[0] * Math.cos(a) - q[1] * Math.sin(a), grid.origin[1] + q[0] * Math.sin(a) + q[1] * Math.cos(a)];
}

/** The grid node nearest a point. */
export function snapToGrid(grid, p) {
  const q = toGrid(grid, p);
  return fromGrid(grid, [Math.round(q[0] / grid.spacing[0]) * grid.spacing[0], Math.round(q[1] / grid.spacing[1]) * grid.spacing[1]]);
}

/**
 * Grid lines across a box (model coordinates): { major: [[a, b]], minor: [[a, b]] }, every fifth line major;
 * thinned to every 5th (or 25th) line when lines would come closer than minGap model units.
 */
export function gridLines(grid, box, minGap = 0) {
  const corners = [
    [box.x0, box.y0],
    [box.x1, box.y0],
    [box.x1, box.y1],
    [box.x0, box.y1],
  ].map((p) => toGrid(grid, p));
  const lo = [Math.min(...corners.map((c) => c[0])), Math.min(...corners.map((c) => c[1]))];
  const hi = [Math.max(...corners.map((c) => c[0])), Math.max(...corners.map((c) => c[1]))];
  const out = { major: [], minor: [] };
  for (const axis of [0, 1]) {
    let s = grid.spacing[axis];
    let k = 1;
    while (s * k < minGap) k *= 5;
    const step = s * k;
    const other = 1 - axis;
    for (let i = Math.ceil(lo[axis] / step); i * step <= hi[axis]; i++) {
      const v = i * step;
      const a = [0, 0];
      const b = [0, 0];
      a[axis] = v;
      b[axis] = v;
      a[other] = lo[other];
      b[other] = hi[other];
      // Every fifth line of the drawn ones is major (counted on the grid, so it stays put while zooming).
      const major = Math.round(v / s) % (5 * k) === 0;
      (major ? out.major : out.minor).push([fromGrid(grid, a), fromGrid(grid, b)]);
    }
  }
  return out;
}

/**
 * Tracker values for the cursor: without a previous point, x and y from the user origin; with one, dx/dy
 * (mode 'xy') or r and angle in degrees counterclockwise from +X (mode 'polar').
 */
export function trackerValues(p, { from = null, origin = [0, 0], mode = 'polar' } = {}) {
  if (!from) return { kind: 'absolute', x: p[0] - origin[0], y: p[1] - origin[1] };
  const dx = p[0] - from[0];
  const dy = p[1] - from[1];
  if (mode === 'xy') return { kind: 'xy', dx, dy };
  let a = Math.atan2(dy, dx) / RAD;
  if (a < 0) a += 360;
  return { kind: 'polar', r: Math.hypot(dx, dy), angle: a };
}

/** The point Tracker values give (the inverse of trackerValues). */
export function trackerPoint(v, { from = null, origin = [0, 0] } = {}) {
  if (v.kind === 'absolute' || !from) return [origin[0] + (+v.x || 0), origin[1] + (+v.y || 0)];
  if (v.kind === 'xy') return [from[0] + (+v.dx || 0), from[1] + (+v.dy || 0)];
  const a = (+v.angle || 0) * RAD;
  return [from[0] + (+v.r || 0) * Math.cos(a), from[1] + (+v.r || 0) * Math.sin(a)];
}

/** The cursor constrained to the line through `from` along `dir` (parallel or bisector constraint). */
export function constrainToDirection(p, from, dir) {
  const l = Math.hypot(dir[0], dir[1]) || 1;
  const d = [dir[0] / l, dir[1] / l];
  const t = (p[0] - from[0]) * d[0] + (p[1] - from[1]) * d[1];
  return [from[0] + d[0] * t, from[1] + d[1] * t];
}

/** Direction of the bisector of the angle between two lines meeting (or that would meet) at a corner. */
export function bisectorDirection(l1, l2) {
  const u = (l) => {
    const d = [l.b[0] - l.a[0], l.b[1] - l.a[1]];
    const n = Math.hypot(d[0], d[1]) || 1;
    return [d[0] / n, d[1] / n];
  };
  const a = u(l1);
  let b = u(l2);
  // Bisect the angle between the lines (not between their arbitrary directions): pick b's sense nearest a.
  if (a[0] * b[0] + a[1] * b[1] < 0) b = [-b[0], -b[1]];
  const s = [a[0] + b[0], a[1] + b[1]];
  const n = Math.hypot(s[0], s[1]);
  return n < 1e-9 ? [-a[1], a[0]] : [s[0] / n, s[1] / n];
}

/**
 * Zoom history of a view (Archicad's Previous / Next Zoom). push() records a camera when the user settles on it;
 * back() and forward() move through the list.
 */
export class ZoomHistory {
  constructor(max = 50) {
    this.list = [];
    this.at = -1;
    this.max = max;
  }

  push(cam) {
    const cur = this.list[this.at];
    if (cur && Math.abs(cur.cx - cam.cx) < 1e-6 && Math.abs(cur.cy - cam.cy) < 1e-6 && Math.abs(cur.zoom - cam.zoom) < 1e-12) return;
    this.list = this.list.slice(0, this.at + 1);
    this.list.push({ cx: cam.cx, cy: cam.cy, zoom: cam.zoom, ...(cam.rot ? { rot: cam.rot } : {}) });
    if (this.list.length > this.max) this.list.shift();
    this.at = this.list.length - 1;
  }

  back() {
    if (this.at <= 0) return null;
    return { ...this.list[--this.at] };
  }

  forward() {
    if (this.at >= this.list.length - 1) return null;
    return { ...this.list[++this.at] };
  }

  get canBack() {
    return this.at > 0;
  }

  get canForward() {
    return this.at < this.list.length - 1;
  }
}

/** Zoom (screen px per model mm) at which a drawing at `scale` shows at its printed size (96 CSS px per inch). */
export function actualSizeZoom(scale) {
  return 96 / 25.4 / (+scale || 100);
}

// Reference lines on screen (Archicad's View > On-Screen View Options) ----------------------------------------

export const REF_LINE_KINDS = [
  { id: 'wall', label: 'Wall & Beam Reference Lines', kinds: ['wall', 'beam'] },
  { id: 'railing', label: 'Railing Reference Lines', kinds: ['railing'] },
  { id: 'mep', label: 'MEP Reference Lines', kinds: ['duct', 'pipe', 'cableTray', 'conduit'] },
  { id: 'roof', label: 'Roof Pivot Lines', kinds: ['roof'] },
  { id: 'stair', label: 'Stair Baselines', kinds: ['stair'] },
];

/**
 * The reference lines to draw in a plan view: [{ pts: [[x, y]], closed, arrow, label }], for the kinds switched on
 * (settings.refLines) on the view's level.
 */
export function referenceLines(doc, view, on) {
  const out = [];
  if (!on || !view?.levelId) return out;
  const want = new Set(REF_LINE_KINDS.filter((k) => on[k.id]).flatMap((k) => k.kinds));
  for (const el of doc.items.values()) {
    if (!want.has(el.kind) || el.levelId !== view.levelId) continue;
    if (el.kind === 'railing' && el.path?.length >= 2) out.push({ pts: el.path, arrow: true });
    else if (el.kind === 'roof' && el.boundary?.length >= 3) out.push({ pts: el.boundary, closed: true, pivot: true });
    else if (el.a && el.b) out.push({ pts: [el.a, el.b], arrow: true });
  }
  return out;
}

/** Foot of p on a line given by a point and a unit direction. */
const footOn = (p, o, d) => {
  const t = (p[0] - o[0]) * d[0] + (p[1] - o[1]) * d[1];
  return [o[0] + d[0] * t, o[1] + d[1] * t];
};

/**
 * The cursor under a constraint that needs no previous point. c: { kind:
 * 'offset' (at distance from a line, on the cursor's side) | 'multiOffset'
 * (the nearest multiple of the distance) | 'snapPoints' (n divisions of an
 * edge), a, b, distance, n }.
 */
export function constrainedPoint(c, p) {
  const L = Math.hypot(c.b[0] - c.a[0], c.b[1] - c.a[1]) || 1;
  const d = [(c.b[0] - c.a[0]) / L, (c.b[1] - c.a[1]) / L];
  if (c.kind === 'snapPoints') {
    const n = Math.max(1, Math.round(+c.n) || 1);
    const t = Math.max(0, Math.min(n, Math.round((((p[0] - c.a[0]) * d[0] + (p[1] - c.a[1]) * d[1]) / L) * n)));
    return [c.a[0] + d[0] * (L * t) / n, c.a[1] + d[1] * (L * t) / n];
  }
  const nrm = [-d[1], d[0]];
  const h = (p[0] - c.a[0]) * nrm[0] + (p[1] - c.a[1]) * nrm[1];
  const step = Math.max(1e-6, Math.abs(+c.distance) || 1);
  const off = c.kind === 'multiOffset' ? Math.round(h / step) * step : Math.sign(h || 1) * step;
  return footOn(p, [c.a[0] + nrm[0] * off, c.a[1] + nrm[1] * off], d);
}

/** Points dividing a chain of points along its whole length, into n parts: without the two ends when open. */
export function divisionsAlong(points, n) {
  const legs = points.slice(1).map((q, i) => Math.hypot(q[0] - points[i][0], q[1] - points[i][1]));
  const total = legs.reduce((s, l) => s + l, 0);
  const out = [];
  for (let k = 1; k < n; k++) {
    let t = (total * k) / n;
    for (let i = 0; i < legs.length; i++) {
      if (t <= legs[i] || i === legs.length - 1) {
        const u = legs[i] ? t / legs[i] : 0;
        out.push([points[i][0] + (points[i + 1][0] - points[i][0]) * u, points[i][1] + (points[i + 1][1] - points[i][1]) * u]);
        break;
      }
      t -= legs[i];
    }
  }
  return out;
}

/** Where a point lies on the extension of a line past its ends, within reach: { foot, end } or null. */
export function extensionPoint(p, a, b, tol, reach) {
  const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
  if (L < 1) return null;
  const d = [(b[0] - a[0]) / L, (b[1] - a[1]) / L];
  const t = (p[0] - a[0]) * d[0] + (p[1] - a[1]) * d[1];
  if (t >= 0 && t <= L) return null;
  const foot = [a[0] + d[0] * t, a[1] + d[1] * t];
  if (Math.hypot(p[0] - foot[0], p[1] - foot[1]) > tol) return null;
  const end = t < 0 ? a : b;
  if (Math.hypot(foot[0] - end[0], foot[1] - end[1]) > reach) return null;
  return { foot, end };
}
