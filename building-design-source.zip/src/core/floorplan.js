/**
 * From a floor plan drawing to a model: an image underlay maps its pixels
 * to model millimetres, can be calibrated from a known length, and a traced
 * plan (wall centre lines, doors, windows, rooms) becomes walls that join,
 * openings hosted in them and rooms, in one change.
 *
 *   image  { kind: 'image', viewId, at, w, h, rotation, src, px: [width, height] }
 *          pixel (0, 0) is the picture's top left; at is its bottom left.
 */
import { add, sub, scale, dot, dist, norm, perp, rotate, closestOnSegment, distToSegment } from './geom.js';
import { typeThickness } from './catalog.js';
import { levelElevation } from './model.js';

/** A point given in an image's pixels ([u, v] from the top left) in model millimetres. */
export function imagePointToModel(img, p) {
  const [pw, ph] = img.px || [img.w, img.h];
  const local = [(p[0] / pw) * img.w, (1 - p[1] / ph) * img.h];
  return add(img.at, rotate(local, ((+img.rotation || 0) * Math.PI) / 180));
}

/** A model point in an image's pixels. */
export function modelPointToImage(img, p) {
  const [pw, ph] = img.px || [img.w, img.h];
  const local = rotate(sub(p, img.at), (-(+img.rotation || 0) * Math.PI) / 180);
  return [(local[0] / img.w) * pw, (1 - local[1] / img.h) * ph];
}

/** Millimetres per pixel of an image underlay. */
export function imageScale(img) {
  return img.w / (img.px?.[0] || img.w);
}

/**
 * Patch that scales an image about the first of two of its pixel points so
 * that they lie `distance` millimetres apart.
 */
export function calibrateImagePatch(img, p1, p2, distance) {
  const a = imagePointToModel(img, p1);
  const b = imagePointToModel(img, p2);
  const d = dist(a, b);
  if (!(d > 1e-6) || !(+distance > 0)) return null;
  const k = +distance / d;
  return { w: img.w * k, h: img.h * k, at: add(a, scale(sub(img.at, a), k)), calibrated: true };
}

/** Least-squares meeting point of lines (point, unit direction), or null when they are parallel. */
function meet(lines) {
  let a = 0;
  let b = 0;
  let c = 0;
  let x = 0;
  let y = 0;
  for (const { p, d } of lines) {
    const n = [-d[1], d[0]];
    a += n[0] * n[0];
    b += n[0] * n[1];
    c += n[1] * n[1];
    const k = dot(n, p);
    x += n[0] * k;
    y += n[1] * k;
  }
  const det = a * c - b * b;
  if (Math.abs(det) < 1e-3 * Math.max(1, a * c)) return null;
  return [(c * x - b * y) / det, (a * y - b * x) / det];
}

/**
 * Clean traced wall centre lines: square up near-orthogonal walls, join
 * ends that nearly meet at their lines' meeting point, put ends that stop
 * near another wall onto it, and drop walls shorter than the tolerance.
 * walls: [{ a, b, ... }] in mm. Returns new objects in the same order (dropped ones left out).
 */
export function tidyWalls(walls, { tol = 150, squareDeg = 3, minLength = tol, keepLine = 25 } = {}) {
  const sq = Math.sin((squareDeg * Math.PI) / 180);
  let ws = walls.map((w) => ({ ...w, a: [...w.a], b: [...w.b] }));
  for (const w of ws) {
    const d = sub(w.b, w.a);
    const l = Math.hypot(d[0], d[1]) || 1;
    if (Math.abs(d[1]) / l < sq) w.a[1] = w.b[1] = (w.a[1] + w.b[1]) / 2;
    else if (Math.abs(d[0]) / l < sq) w.a[0] = w.b[0] = (w.a[0] + w.b[0]) / 2;
  }
  // Clusters of ends closer than the tolerance meet at one point.
  const ends = ws.flatMap((w, i) => [
    { i, k: 'a' },
    { i, k: 'b' },
  ]);
  const seen = new Set();
  for (const e of ends) {
    const key = `${e.i}${e.k}`;
    if (seen.has(key)) continue;
    const p = ws[e.i][e.k];
    // One end per wall: a short wall's two ends never fold into one point.
    const group = [];
    // Thick walls meet further from their centre lines' ends: allow for their half thicknesses.
    const reach = (f) => Math.max(tol, 0.75 * ((+ws[e.i].thickness || 0) + (+ws[f.i].thickness || 0)));
    for (const f of ends) if (!seen.has(`${f.i}${f.k}`) && dist(ws[f.i][f.k], p) <= reach(f) && !group.some((g) => g.i === f.i)) group.push(f);
    group.forEach((f) => seen.add(`${f.i}${f.k}`));
    if (group.length < 2) continue;
    const lines = group.map((f) => ({ p: ws[f.i].a, d: norm(sub(ws[f.i].b, ws[f.i].a)) }));
    const centroid = scale(group.reduce((s, f) => add(s, ws[f.i][f.k]), [0, 0]), 1 / group.length);
    let q = meet(lines);
    if (!q || dist(q, centroid) > Math.max(...group.map(reach)) * 2) q = centroid;
    for (const f of group) {
      // A wall whose line clearly misses the point (thicknesses flush on one face put the lines apart) runs up to it along itself: moving it there would slant it.
      const w = ws[f.i];
      const d = norm(sub(w.b, w.a));
      const on = add(w.a, scale(d, dot(sub(q, w.a), d)));
      w[f.k] = dist(on, q) <= keepLine ? [...q] : on;
    }
  }
  // A free end close to another wall's middle goes onto it (a T junction).
  for (const w of ws)
    for (const k of ['a', 'b']) {
      const p = w[k];
      if (ws.some((o) => o !== w && (dist(o.a, p) < 1 || dist(o.b, p) < 1))) continue;
      let best = null;
      for (const o of ws) {
        if (o === w) continue;
        const d = distToSegment(p, o.a, o.b);
        // An end at the face of a thick wall reaches its centre line.
        if (d <= Math.max(tol, (+o.thickness || 0) / 2 + 30) && d > 0.5 && (!best || d < best.d)) best = { d, o, q: closestOnSegment(p, o.a, o.b).point };
      }
      if (!best) continue;
      // Along the wall's own line where the two cross, so it stays straight; alongside a parallel wall it stays put.
      const du = norm(sub(w.b, w.a));
      const ou = norm(sub(best.o.b, best.o.a));
      const across = du[0] * ou[1] - du[1] * ou[0];
      if (Math.abs(across) > 0.2) {
        const r = sub(best.o.a, w.a);
        w[k] = add(w.a, scale(du, (r[0] * ou[1] - r[1] * ou[0]) / across));
      } else if (keepLine > 2) w[k] = best.q;
    }
  return ws.filter((w) => dist(w.a, w.b) > minLength);
}

/** The wall type nearest a thickness, among exterior or interior types when that is known. */
export function wallTypeFor(doc, thickness, exterior) {
  const all = doc.all('wallType').filter((t) => t.layers?.length && !t.curtain);
  const pool = exterior == null ? all : all.filter((t) => (t.function === 'exterior') === !!exterior);
  const list = pool.length ? pool : all;
  if (!(+thickness > 0)) return list[0] ?? null;
  return list.reduce((best, t) => (!best || Math.abs(typeThickness(t) - thickness) < Math.abs(typeThickness(best) - thickness) ? t : best), null);
}

/**
 * The wall type for a thickness (inside a transaction): the nearest one when
 * it is within 10 % (at least 15 mm; 5 mm when exact), else a new generic type of that thickness.
 */
export function wallTypeMaking(doc, thickness, exterior, exact = false) {
  const best = wallTypeFor(doc, thickness, exterior);
  const t = Math.round(+thickness || 0);
  // A drawing says how thick a wall is, not what it is made of: from exact drawings (CAD, PDF) a plain type within 5 mm, never a brick one because it happens to measure the same.
  if (exact && t > 0) {
    const plain = doc.all('wallType').filter((x) => /^Generic - \d+ mm$/.test(x.name) && Math.abs(typeThickness(x) - t) <= 5).sort((p, q) => Math.abs(typeThickness(p) - t) - Math.abs(typeThickness(q) - t))[0];
    if (plain) return plain;
  } else if (!(t > 0) || (best && Math.abs(typeThickness(best) - t) <= Math.max(15, t * 0.1))) return best;
  const name = `Generic - ${t} mm`;
  return doc.all('wallType').find((x) => x.name === name) || doc.add({ kind: 'wallType', name, function: exterior ? 'exterior' : 'interior', layers: [{ materialId: 'mat-default', thickness: t, function: 'structure' }] });
}

function openingTypeFor(doc, kind, width, family = null) {
  const all = doc.all(kind === 'door' ? 'doorType' : 'windowType');
  const fam = family ? all.filter((t) => t.family === family) : [];
  const types = fam.length ? fam : all;
  if (!(+width > 0)) return types[0] ?? null;
  return types.reduce((best, t) => (!best || Math.abs(+t.width - width) < Math.abs(+best.width - width) ? t : best), null);
}

function nextNumber(values, prefix = '') {
  let n = 0;
  for (const v of values) {
    const m = new RegExp(`^${prefix}(\\d+)$`).exec(String(v ?? ''));
    if (m) n = Math.max(n, +m[1]);
  }
  return `${prefix}${n + 1}`;
}

/**
 * Make a traced plan (inside a transaction). plan, all in mm:
 *   walls   [{ a, b, thickness?, exterior?, curtain? }]  centre lines
 *   doors   [{ at, width?, height? }]           near the wall they sit in
 *   windows [{ at, width?, height?, sill? }]
 *   rooms   [{ at, name, number? }]
 * opts: { levelId, height (when there is no level above), tol, minLength (shorter walls are left out; tol by default) }.
 * Returns { walls, doors, windows, rooms: ids, skipped: [reasons] }.
 */
export function buildFloorPlan(doc, plan, { levelId, height = 3000, tol, minLength } = {}) {
  const level = doc.get(levelId) || doc.levels()[0];
  const above = doc.levelAbove(level.id);
  const thick = (plan.walls || []).map((w) => +w.thickness).filter((t) => t > 0);
  const medianT = thick.length ? thick.sort((x, y) => x - y)[Math.floor(thick.length / 2)] : 200;
  const tolerance = tol ?? Math.max(50, Math.min(300, medianT * 0.9));
  const out = { walls: [], doors: [], windows: [], openings: [], rooms: [], skipped: [] };
  const clean = tidyWalls(
    (plan.walls || []).filter((w) => Array.isArray(w?.a) && Array.isArray(w?.b)).map((w) => ({ ...w, a: [+w.a[0], +w.a[1]], b: [+w.b[0], +w.b[1]] })),
    { tol: tolerance, minLength: minLength ?? tolerance, keepLine: plan.newTypes === 'exact' ? 2 : 25 },
  );
  if (clean.length < (plan.walls || []).length) out.skipped.push(`${(plan.walls || []).length - clean.length} wall(s) shorter than ${Math.round(minLength ?? tolerance)} mm left out`);
  const made = [];
  for (const w of clean) {
    const type = w.curtain ? doc.all('wallType').find((t) => t.curtain) : plan.newTypes ? wallTypeMaking(doc, +w.thickness, w.exterior, plan.newTypes === 'exact') : wallTypeFor(doc, +w.thickness, w.exterior);
    const el = doc.add({ kind: 'wall', typeId: type?.id, levelId: level.id, a: w.a, b: w.b, baseOffset: 0, topLevelId: above?.id ?? null, topOffset: 0, height: +w.height || height, locationLine: 'center', joinA: true, joinB: true, roomBounding: true });
    out.walls.push(el.id);
    made.push({ el, half: typeThickness(type) / 2 });
  }
  // Openings also go into walls already on the level.
  const hosts = [...made, ...doc.all('wall').filter((w) => w.levelId === level.id && !out.walls.includes(w.id) && !w.arc).map((el) => ({ el, half: typeThickness(doc.get(el.typeId)) / 2 }))];
  const place = (kind, o) => {
    if (!Array.isArray(o?.at)) return;
    const at = [+o.at[0], +o.at[1]];
    let best = null;
    for (const hst of hosts) {
      const d = distToSegment(at, hst.el.a, hst.el.b);
      if (d <= Math.max(600, hst.half + 300) && (!best || d < best.d)) best = { d, h: hst };
    }
    if (!best) return out.skipped.push(`${kind} at ${at.map(Math.round).join(', ')}: no wall near it`);
    const w = best.h.el;
    const L = dist(w.a, w.b);
    // An empty opening (a doorway with no door, a hole): no type, its own size.
    if (kind === 'opening') {
      const width = Math.min(+o.width || 900, L);
      const t = Math.min(L - width / 2, Math.max(width / 2, dot(sub(at, w.a), norm(sub(w.b, w.a)))));
      out.openings.push(doc.add({ kind: 'opening', hostId: w.id, t: Math.round(t), width: Math.round(width), height: Math.round(+o.height || 2100), sill: Math.round(+o.sill || 0) }).id);
      return;
    }
    const type = openingTypeFor(doc, kind, +o.width, o.family || (kind === 'window' && o.height ? 'casement' : null));
    // An exact drawing (CAD) may glaze a wall from one cross wall to the next: no pier needed beside it; an opening
    // drawn a frame's width wider than its wall (the frame lines run past the wall's ends) fills the wall.
    const pier = plan.newTypes === 'exact' ? 0 : 50;
    let width = +o.width > 0 ? +o.width : +type?.width || 900;
    if (!pier && width > L + 2 && width <= L + 120) width = L;
    if (width > (pier ? L - 100 : L + 2)) return out.skipped.push(`${kind} ${Math.round(width)} mm wide at ${at.map(Math.round).join(", ")} does not fit a ${Math.round(L)} mm wall`);
    const t = Math.min(L - width / 2 - pier, Math.max(width / 2 + pier, dot(sub(at, w.a), norm(sub(w.b, w.a)))));
    const el = { kind, typeId: type?.id, hostId: w.id, t };
    if (type && Math.abs(+type.width - width) > 10) el.width = width;
    if (+o.height > 0 && type && Math.abs(+type.height - +o.height) > 10) el.height = +o.height;
    // A door the drawing gives no height for, in a metric project, has the metric standard 2.10 m (the catalogue's
    // types are 7 ft, 2134 mm).
    else if (kind === 'door' && !(+o.height > 0) && doc.units?.system !== 'imperial' && type && Math.abs(+type.height - 2134) < 2) el.height = 2100;
    // A sill the drawing gives, nought included (a French window).
    if (kind === 'window' && o.sill != null && +o.sill >= 0 && Number.isFinite(+o.sill)) el.sill = +o.sill;
    // What the drawing shows of the frames.
    for (const key of ['frameWidth', 'frameDepth', 'reveal', 'transomAt']) if (o[key] != null) el[key] = +o[key];
    if (o.boxWindow) el.boxWindow = true;
    if (o.sillBoard === false) el.sillBoard = false;
    if (kind === 'window' && o.frameSide) el.flipFacing = dot(o.frameSide, perp(norm(sub(w.b, w.a)))) * (w.flipped ? -1 : 1) < 0;
    if (kind === 'door') {
      // The side a door opens to, and the jamb it hangs on, from the drawing.
      const dir = norm(sub(w.b, w.a));
      const sw = o.swing?.[0];
      const flipFacing = sw ? dot(sw.dir, perp(dir)) < 0 : false;
      const flipHand = sw && o.family !== 'double' ? dot(sub(sw.hinge, add(w.a, scale(dir, t))), dir) > 0 : false;
      Object.assign(el, { flipFacing, flipHand, mark: nextNumber(doc.all('door').map((d) => d.mark)) });
    }
    else el.mark = nextNumber(doc.all('window').map((d) => d.mark), 'W');
    out[kind === 'door' ? 'doors' : 'windows'].push(doc.add(el).id);
  };
  for (const d of plan.doors || []) place('door', d);
  for (const wi of plan.windows || []) place('window', wi);
  for (const op of plan.openings || []) place('opening', op);
  const storey = above ? levelElevation(doc, above.id) - level.elevation : height;
  for (const r of plan.rooms || []) {
    if (!Array.isArray(r?.at)) continue;
    const number = r.number ? String(r.number) : nextNumber(doc.all('room').map((x) => x.number));
    out.rooms.push(doc.add({ kind: 'room', levelId: level.id, at: [+r.at[0], +r.at[1]], name: String(r.name || 'Room'), number, upperOffset: +r.height || storey, ...(r.tagAt ? { tagAt: [+r.tagAt[0], +r.tagAt[1]] } : {}), ...(r.floorFinish ? { floorFinish: String(r.floorFinish) } : {}) }).id);
  }
  return out;
}
