/**
 * 3D Cutting Planes, as in Archicad: up to two planes that cut away part of
 * a 3D view (on top of its section box), horizontal at a height or
 * vertical through a point at an angle, each turned on or off and flipped
 * to keep the other side.
 *
 *   view3d.cutPlanes: [{ type: 'horizontal' | 'vertical', z, at: [x, y], angle (deg), flip, on }]
 */
export const MAX_CUT_PLANES = 2;

/** A plane as the renderer takes it: [nx, ny, nz, d], cutting away where n·p > d. */
export function cutPlaneOf(c) {
  let n;
  let d;
  if (c.type === 'vertical') {
    const a = ((+c.angle || 0) * Math.PI) / 180;
    n = [Math.cos(a), Math.sin(a), 0];
    const at = c.at || [0, 0];
    d = n[0] * at[0] + n[1] * at[1];
  } else if (c.type === 'custom') {
    // A free plane: facing a direction in plan and tilted up from it, through a point.
    const a = ((+c.angle || 0) * Math.PI) / 180;
    const t = ((+c.tilt || 0) * Math.PI) / 180;
    n = [Math.cos(a) * Math.cos(t), Math.sin(a) * Math.cos(t), Math.sin(t)];
    const at = c.at || [0, 0];
    d = n[0] * at[0] + n[1] * at[1] + n[2] * (+c.z || 0);
  } else {
    n = [0, 0, 1];
    d = +c.z || 0;
  }
  return c.flip ? [-n[0], -n[1], -n[2], -d] : [...n, d];
}

/** The renderer planes of a view's cutting planes that are on. */
export function viewCutPlanes(view) {
  return (view?.cutPlanes || []).filter((c) => c && c.on !== false).slice(0, MAX_CUT_PLANES).map(cutPlaneOf);
}

/** Whether a point is kept by a view's cutting planes. */
export function keptByCuts(view, p) {
  return viewCutPlanes(view).every(([x, y, z, d]) => x * p[0] + y * p[1] + z * p[2] <= d + 1e-6);
}
