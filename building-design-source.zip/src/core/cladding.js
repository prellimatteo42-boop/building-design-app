/**
 * Wall accessories, as Archicad's Wall Accessories: things built along one
 * face of a wall (or inside it), following the wall and its doors and windows.
 *
 *   wallCladding { wallId, side: 'exterior' | 'interior', accessory, ... }
 *
 * accessory:
 *   'cladding'  boards running horizontally or vertically, or a grid of panels, held off the face on battens:
 *               pattern 'horizontal' | 'vertical' | 'panels', board (a board's or panel's width), panelHeight,
 *               gap, thickness, cavity (face to the boards' back), materialId
 *   'moldings'  Moldings and Panelings: a base molding, a chair rail and a crown molding, with wainscot panels
 *               between the base and the chair rail: baseHeight, chairHeight, crownHeight, wainscot (bool),
 *               panelWidth, materialId
 *   'battered'  Battered Wall: a veneer thicker at the bottom than at the top, which may run past the wall's
 *               bottom and top: thickBottom, thickTop, extendBelow, extendAbove, materialId
 *   'framing'   Wall Framing: studs at a spacing inside the wall, bottom and double top plates, and at doors and
 *               windows king and jack studs, headers, sills and cripples: spacing, studWidth, studDepth, header
 * (Archicad's Canted Wall is the wall's own slant here: the Wall Accessories command sets it.)
 */
import earcut from 'earcut';
import { add, scale } from './geom.js';
import { wallAxis, verticalExtent } from './model.js';
import { arcPoint, arcTangent } from './arc.js';
import { MeshBuilder, hexToRgba } from './mesh.js';
import { wallOpenings } from './build3d.js';
import { W } from './plan.js';
import { PROFILES } from './sweeps.js';

export const CLADDING_PATTERNS = [
  { value: 'horizontal', label: 'Horizontal boards' },
  { value: 'vertical', label: 'Vertical boards' },
  { value: 'panels', label: 'Panels' },
];

export const WALL_ACCESSORIES = [
  { value: 'cladding', label: 'Cladding' },
  { value: 'moldings', label: 'Moldings and Panelings' },
  { value: 'battered', label: 'Battered Wall' },
  { value: 'framing', label: 'Wall Framing' },
];

/**
 * The side of a wall that faces out of the building: a ray from the middle of
 * its exterior face that crosses the level's other walls an odd number of times
 * starts inside, so the cladding goes on the other face.
 */
export function outerSide(doc, wall) {
  const ax = wallAxis(doc, wall);
  let mid = add(ax.a, scale(ax.dir, ax.length / 2));
  let d = ax.ext;
  if (ax.curve) {
    // A curved wall: from the middle of its arc, out along its exterior normal there.
    const tg = arcTangent(ax.curve, ax.length / 2);
    const left = [-tg[1], tg[0]];
    mid = arcPoint(ax.curve, ax.length / 2, 0);
    d = wall.flipped ? scale(left, -1) : left;
  }
  const o = add(mid, scale(d, ax.half + 1));
  let hits = 0;
  for (const w of doc.all('wall')) {
    if (w.id === wall.id || w.levelId !== wall.levelId) continue;
    const [a, b] = [w.a, w.b];
    const e = [b[0] - a[0], b[1] - a[1]];
    const den = d[0] * e[1] - d[1] * e[0];
    if (Math.abs(den) < 1e-9) continue;
    const q = [a[0] - o[0], a[1] - o[1]];
    const t = (q[0] * e[1] - q[1] * e[0]) / den;
    const u = (q[0] * d[1] - q[1] * d[0]) / den;
    if (t > 0 && u >= 0 && u < 1) hits++;
  }
  return hits % 2 ? 'interior' : 'exterior';
}

/** A rectangle [u0, u1, z0, z1] less another: the up to four rectangles left. */
function minus(r, o) {
  const [a0, a1, b0, b1] = r;
  const [c0, c1, d0, d1] = o;
  if (c1 <= a0 || c0 >= a1 || d1 <= b0 || d0 >= b1) return [r];
  const out = [];
  if (c0 > a0) out.push([a0, c0, b0, b1]);
  if (c1 < a1) out.push([c1, a1, b0, b1]);
  const m0 = Math.max(a0, c0);
  const m1 = Math.min(a1, c1);
  if (d0 > b0) out.push([m0, m1, b0, d0]);
  if (d1 < b1) out.push([m0, m1, d1, b1]);
  return out;
}

const cut = (rects, openings, gap = 0) => {
  let out = rects;
  for (const o of openings) out = out.flatMap((r) => minus(r, [o.u0 - gap, o.u1 + gap, o.z0 - gap, o.z1 + gap]));
  return out.filter((r) => r[1] - r[0] > 5 && r[3] - r[2] > 5);
};

/** Where an accessory sits: the wall's face from corner to corner, its height and its openings; or null. */
function faceOf(doc, el) {
  const wall = doc.get(el.wallId);
  if (!wall) return null;
  const ax = wallAxis(doc, wall);
  const { base, top } = verticalExtent(doc, wall);
  if (ax.length < 1 || top - base < 1) return null;
  const n = el.side === 'interior' ? scale(ax.ext, -1) : ax.ext;
  const kind = el.accessory || 'cladding';
  if (ax.curve) {
    // A curved wall: along its arc, offset to the face (exterior is its left unless flipped); pieces follow
    // the arc in short straight steps.
    const sgn = (el.side === 'interior' ? -1 : 1) * (wall.flipped ? -1 : 1);
    const face = (t, off) => arcPoint(ax.curve, t, sgn * (ax.half + off));
    const step = Math.max(50, Math.min(300, (ax.curve.r * Math.PI) / 45));
    const steps = (t0, t1) => {
      const k = Math.max(1, Math.ceil((t1 - t0) / step));
      return Array.from({ length: k + 1 }, (_, i) => t0 + ((t1 - t0) * i) / k);
    };
    // At its ends it runs on to the corners with joined walls like a straight one, along the arc's tangent there.
    const endAx = (u) => {
      const tg = arcTangent(ax.curve, u);
      return { a: arcPoint(ax.curve, u, 0), dir: tg, length: 0, half: ax.half, normal: scale([-tg[1], tg[0]], sgn) };
    };
    const A = endAx(0);
    const B = endAx(ax.length);
    const lo = kind === 'framing' ? 0 : -cornerReach(doc, wall, A, A.normal, el, 'a');
    const hi = ax.length + (kind === 'framing' ? 0 : cornerReach(doc, wall, B, B.normal, el, 'b'));
    return { wall, ax, n, base, top, lo, hi, face, steps, length: ax.length, half: ax.half, openings: wallOpenings(doc, wall, base, top) };
  }
  // Framing stays inside the wall; the rest runs along the face from corner to corner.
  const lo = kind === 'framing' ? 0 : -cornerReach(doc, wall, ax, n, el, 'a');
  const hi = ax.length + (kind === 'framing' ? 0 : cornerReach(doc, wall, ax, n, el, 'b'));
  const face = (t, off) => add(add(ax.a, scale(ax.dir, t)), scale(n, ax.half + off));
  return { wall, ax, n, base, top, lo, hi, face, steps: null, length: ax.length, half: ax.half, openings: wallOpenings(doc, wall, base, top) };
}

/**
 * The cladding's pieces: { pieces: [[t0, t1, z0, z1]] along the wall (from its
 * start) and up (absolute), face(t, off) a point off the face, n (outward), dir,
 * cavity, thickness }, or null.
 */
export function claddingGeometry(doc, el) {
  const f = faceOf(doc, el);
  if (!f) return null;
  const { base, top, lo, hi } = f;
  const gap = Math.max(0, +el.gap || 10);
  const pattern = el.pattern || 'horizontal';
  const size = Math.max(20, +el.board || (pattern === 'panels' ? 1200 : 150));
  const height = Math.max(20, +el.panelHeight || 600);
  const cells = [];
  if (pattern === 'horizontal') for (let z = base; z < top - 1; z += size) cells.push([lo, hi, z, Math.min(top, z + size - gap)]);
  else if (pattern === 'vertical') for (let t = lo; t < hi - 1; t += size) cells.push([t, Math.min(hi, t + size - gap), base, top]);
  else for (let z = base; z < top - 1; z += height) for (let t = lo; t < hi - 1; t += size) cells.push([t, Math.min(hi, t + size - gap), z, Math.min(top, z + height - gap)]);
  // Cut round the openings (with the gap round them too).
  const pieces = cut(cells, f.openings, gap);
  const cavity = Math.max(0, +(el.cavity ?? 30));
  const thickness = Math.max(1, +el.thickness || 20);
  return { pieces, face: f.face, steps: f.steps, n: f.n, dir: f.ax.dir, cavity, thickness, base, top, length: f.length, lo, hi };
}

/**
 * How far past its end ('a' backwards from the start, 'b' on from the end) the
 * cladding's face runs to the corner with a wall joined there: to that wall's
 * face on the same side, plus its cladding's depth at 'b' or its cavity at 'a'.
 */
function cornerReach(doc, wall, ax, n, el, end) {
  const p = end === 'a' ? wall.a : wall.b;
  const other = doc.all('wall').find((w) => w.id !== wall.id && w.levelId === wall.levelId && !w.arc && [w.a, w.b].some((q) => Math.hypot(q[0] - p[0], q[1] - p[1]) < 1));
  if (!other) return 0;
  const ox = wallAxis(doc, other);
  // Collinear: no corner.
  if (Math.abs(ox.dir[0] * ax.dir[1] - ox.dir[1] * ax.dir[0]) < 0.05) return 0;
  // The joined wall's face on the same side of the building as this cladding (both out, or both in).
  const out = (el.side || 'exterior') === outerSide(doc, wall);
  const side = (outerSide(doc, other) === 'exterior') === out ? 'exterior' : 'interior';
  const m = side === 'exterior' ? ox.ext : scale(ox.ext, -1);
  // Claddings meet: one laps the other's end, the other butts against its back.
  const isCladding = (c) => (c.accessory || 'cladding') === 'cladding';
  const own = isCladding(el) && doc.all('wallCladding').find((c) => c.wallId === other.id && c.id !== el.id && (c.side || 'exterior') === side && isCladding(c));
  const extra = own ? Math.max(0, +(own.cavity ?? 30)) + (end === 'b' ? Math.max(1, +own.thickness || 20) : 0) : 0;
  // The face line from the end point: f(s) = end + dir*s + n*half; solve m·(f(s) - other.a) = other.half + extra.
  const e = end === 'a' ? ax.a : add(ax.a, scale(ax.dir, ax.length));
  const f0 = add(e, scale(n, ax.half));
  const den = m[0] * ax.dir[0] + m[1] * ax.dir[1];
  if (Math.abs(den) < 1e-6) return 0;
  const s = (ox.half + extra - (m[0] * (f0[0] - ox.a[0]) + m[1] * (f0[1] - ox.a[1]))) / den;
  // Reach out (positive) past 'b', back (negative s) before 'a'; never more than a wall's depth plus cladding.
  const r = end === 'a' ? -s : s;
  return Math.abs(r) > 2 * ox.half + 500 ? 0 : r;
}

/** A box between t0..t1 along the face, z0..z1 up, out from the face o0..o1 (oTop: o1 at the top, for a batter). */
function box(b, P, [t0, t1, z0, z1], o0, o1, col, { oTop = o1, edges = true, back = true } = {}) {
  // Along a curved face in steps: the ends capped once, the long faces and edges per step.
  const ts = P.steps ? P.steps(t0, t1) : [t0, t1];
  for (let i = 0; i + 1 < ts.length; i++) {
    const [s0, s1] = [ts[i], ts[i + 1]];
    const v = [P(s0, o0, z0), P(s1, o0, z0), P(s1, o1, z0), P(s0, o1, z0), P(s0, o0, z1), P(s1, o0, z1), P(s1, oTop, z1), P(s0, oTop, z1)];
    const faces = [[3, 2, 6, 7], [7, 6, 5, 4], [0, 1, 2, 3]];
    if (back) faces.push([1, 0, 4, 5]);
    if (i === 0) faces.push([0, 3, 7, 4]);
    if (i === ts.length - 2) faces.push([2, 1, 5, 6]);
    for (const [a, c, d, e] of faces) b.quad(v[a], v[c], v[d], v[e], col);
    if (!edges) continue;
    for (const [a, c] of [[3, 2], [6, 7], [0, 1], [4, 5]]) b.edge(v[a], v[c]);
    if (i === 0) for (const [a, c] of [[7, 3], [0, 3], [4, 7]]) b.edge(v[a], v[c]);
    if (i === ts.length - 2) for (const [a, c] of [[2, 6], [1, 2], [5, 6]]) b.edge(v[a], v[c]);
  }
}

/** A profile [[out, up]] run along the face from t0 to t1 at height z. */
function profileRun(b, P, t0, t1, z, pts, col) {
  const n = pts.length;
  const ts = P.steps ? P.steps(t0, t1) : [t0, t1];
  for (let k = 0; k + 1 < ts.length; k++) {
    const [s0, s1] = [ts[k], ts[k + 1]];
    for (let i = 0; i < n; i++) {
      const [o0, u0] = pts[i];
      const [o1, u1] = pts[(i + 1) % n];
      b.quad(P(s0, o0, z + u0), P(s0, o1, z + u1), P(s1, o1, z + u1), P(s1, o0, z + u0), col);
    }
    for (const [o, u] of pts) if (o > 0.5) b.edge(P(s0, o, z + u), P(s1, o, z + u));
  }
  for (let i = 0; i < n; i++) {
    const [o0, u0] = pts[i];
    const [o1, u1] = pts[(i + 1) % n];
    if (o0 > 0.5 || o1 > 0.5) {
      b.edge(P(t0, o0, z + u0), P(t0, o1, z + u1));
      b.edge(P(t1, o0, z + u0), P(t1, o1, z + u1));
    }
  }
  const tri = earcut(pts.flat());
  for (let i = 0; i < tri.length; i += 3) {
    const [a, c, d] = [pts[tri[i]], pts[tri[i + 1]], pts[tri[i + 2]]];
    b.tri(P(t0, a[0], z + a[1]), P(t0, d[0], z + d[1]), P(t0, c[0], z + c[1]), col);
    b.tri(P(t1, a[0], z + a[1]), P(t1, c[0], z + c[1]), P(t1, d[0], z + d[1]), col);
  }
}

const pointOn = (face, steps) => {
  const P = (t, off, z) => {
    const p = face(t, off);
    return [p[0], p[1], z];
  };
  P.steps = steps;
  return P;
};

export function buildCladding(ctx, el) {
  const kind = el.accessory || 'cladding';
  if (kind === 'moldings') return buildMoldings(ctx, el);
  if (kind === 'battered') return buildBattered(ctx, el);
  if (kind === 'framing') return buildFraming(ctx, el);
  const g = claddingGeometry(ctx.doc, el);
  if (!g) return null;
  const col = hexToRgba(ctx.material(el.materialId || 'mat-wood')?.color || '#b08a5a', 1);
  const b = new MeshBuilder();
  const P = pointOn(g.face, g.steps);
  const o0 = g.cavity;
  const o1 = g.cavity + g.thickness;
  for (const r of g.pieces) box(b, P, r, o0, o1, col);
  // Battens behind across the boards: upright ones every 600 for horizontal boards and panels, level ones for
  // vertical boards.
  const bw = 40;
  if (g.cavity > 5 && (el.pattern || 'horizontal') === 'vertical') {
    for (let z = g.base + 300; z < g.top - bw; z += 600) for (const [a0, a1] of runs(g.pieces, z, z + bw, 0)) box(b, P, [a0, a1, z, z + bw], 0, o0, col, { edges: false, back: false });
  } else if (g.cavity > 5) {
    for (let t = g.lo + bw / 2; t < g.hi; t += 600) {
      const t0 = Math.max(g.lo, t - bw / 2);
      const t1 = Math.min(g.hi, t + bw / 2);
      for (const [a0, a1] of runs(g.pieces, t0, t1, 2)) box(b, P, [t0, t1, a0, a1], 0, o0, col, { edges: false, back: false });
    }
  }
  return b.build();
}

/** Where a batten behind the pieces runs: along the wall (k = 0, for heights a..c) or up it (k = 2, for a..c along). */
function runs(pieces, a, c, k) {
  const j = k === 0 ? 2 : 0;
  const spans = pieces.filter((r) => r[j] < c && r[j + 1] > a).map((r) => [r[k], r[k + 1]]).sort((x, y) => x[0] - y[0]);
  const out = [];
  for (const [p, q] of spans) {
    const last = out.at(-1);
    if (last && p <= last[1] + 50) last[1] = Math.max(last[1], q);
    else out.push([p, q]);
  }
  return out;
}

// Moldings and Panelings ------------------------------------------------------------------------------------

/** Moldings and wainscot: { runs: [{ role, t0, t1, z, h, depth, profile }], panels: [[t0, t1, z0, z1]], face } */
export function moldingsGeometry(doc, el) {
  const f = faceOf(doc, el);
  if (!f) return null;
  const baseH = Math.max(0, +(el.baseHeight ?? 120));
  const chairZ = Math.max(0, +(el.chairHeight ?? 900));
  const crownH = Math.max(0, +(el.crownHeight ?? 90));
  const chairH = 60;
  const out = { runs: [], panels: [], face: f.face, steps: f.steps, base: f.base, top: f.top };
  const along = (role, z, h, depth, profile) => {
    if (h <= 0) return;
    // A molding stops whole at an opening its height reaches into.
    const across = f.openings.filter((o) => o.z0 < z + h && o.z1 > z).map((o) => ({ ...o, z0: -Infinity, z1: Infinity }));
    for (const r of cut([[f.lo, f.hi, z, z + h]], across)) out.runs.push({ role, t0: r[0], t1: r[1], z, h, depth, profile });
  };
  along('base', f.base, baseH, 18, 'skirting');
  if (chairZ > 0) along('chair', f.base + chairZ - chairH / 2, chairH, 22, 'chamfer');
  along('crown', f.top - crownH, crownH, 60, 'cornice');
  // Wainscot panels between the base and the chair rail, cut round the openings.
  if (el.wainscot !== false && chairZ > 0) {
    const z0 = f.base + baseH + 40;
    const z1 = f.base + chairZ - chairH / 2 - 40;
    const w = Math.max(200, +el.panelWidth || 600);
    if (z1 - z0 > 100) {
      const cells = [];
      for (let t = f.lo + 40; t < f.hi - 100; t += w) cells.push([t, Math.min(f.hi - 40, t + w - 80), z0, z1]);
      out.panels = cut(cells, f.openings, 40).filter((r) => r[1] - r[0] > 100 && r[3] - r[2] > 100);
    }
  }
  return out;
}

function buildMoldings(ctx, el) {
  const g = moldingsGeometry(ctx.doc, el);
  if (!g) return null;
  const col = hexToRgba(ctx.material(el.materialId || 'mat-paint-white')?.color || '#f2efe8', 1);
  const b = new MeshBuilder();
  const P = pointOn(g.face, g.steps);
  for (const r of g.runs) profileRun(b, P, r.t0, r.t1, r.z, PROFILES[r.profile].pts.map(([o, u]) => [o * r.depth, u * r.h]), col);
  // Each panel: a flat board with a raised field inset in it.
  for (const [t0, t1, z0, z1] of g.panels) {
    box(b, P, [t0, t1, z0, z1], 0, 8, col, { back: false });
    if (t1 - t0 > 200 && z1 - z0 > 200) box(b, P, [t0 + 60, t1 - 60, z0 + 60, z1 - 60], 8, 16, col, { back: false });
  }
  return b.build();
}

// Battered Wall --------------------------------------------------------------------------------------------------

/** The veneer: { pieces, z0, z1, depth(z) out from the face, face }. */
export function batteredGeometry(doc, el) {
  const f = faceOf(doc, el);
  if (!f) return null;
  const z0 = f.base - (+el.extendBelow || 0);
  const z1 = f.top + (+el.extendAbove || 0);
  const tb = Math.max(1, +(el.thickBottom ?? 150));
  const tt = Math.max(1, +(el.thickTop ?? 60));
  const depth = (z) => tb + ((tt - tb) * (z - z0)) / Math.max(1, z1 - z0);
  return { pieces: cut([[f.lo, f.hi, z0, z1]], f.openings), z0, z1, depth, face: f.face, steps: f.steps };
}

function buildBattered(ctx, el) {
  const g = batteredGeometry(ctx.doc, el);
  if (!g) return null;
  const col = hexToRgba(ctx.material(el.materialId || 'mat-stone')?.color || '#a39a8c', 1);
  const b = new MeshBuilder();
  const P = pointOn(g.face, g.steps);
  for (const r of g.pieces) box(b, P, r, 0, g.depth(r[2]), col, { oTop: g.depth(r[3]) });
  return b.build();
}

// Wall Framing ---------------------------------------------------------------------------------------------------

/**
 * The framing members: [{ role, t0, t1, z0, z1 }] along the wall's axis (studs
 * upright, plates, headers and sills level), across the wall o0..o1 from its
 * face (the studs centred in it).
 */
export function framingGeometry(doc, el) {
  const f = faceOf(doc, el);
  if (!f) return null;
  const sw = Math.max(20, +el.studWidth || 45);
  const sd = Math.min(2 * f.half, Math.max(20, +el.studDepth || 140));
  const spacing = Math.max(150, +el.spacing || 400);
  const headerH = Math.max(sw, +el.header || 200);
  const { base, top, length } = f;
  const plate0 = base + sw;
  const plate1 = top - 2 * sw;
  const members = [
    { role: 'bottom plate', t0: 0, t1: length, z0: base, z1: plate0 },
    { role: 'top plate', t0: 0, t1: length, z0: plate1, z1: plate1 + sw },
    { role: 'top plate', t0: 0, t1: length, z0: plate1 + sw, z1: top },
  ];
  const stud = (t0, role = 'stud', z0 = plate0, z1 = plate1) => {
    if (z1 - z0 > 5) members.push({ role, t0, t1: t0 + sw, z0, z1 });
  };
  const ops = f.openings.map((o) => ({ ...o, a: Math.max(3 * sw, o.u0), c: Math.min(length - 3 * sw, o.u1) })).filter((o) => o.c > o.a);
  const busy = (t) => ops.some((o) => t + sw > o.a - 2 * sw - 1 && t < o.c + 2 * sw + 1);
  // End studs, doubled where another wall joins at a corner.
  const joined = (p) => doc.all('wall').some((w) => w.id !== f.wall.id && w.levelId === f.wall.levelId && [w.a, w.b].some((q) => Math.hypot(q[0] - p[0], q[1] - p[1]) < 1));
  stud(0);
  stud(length - sw);
  if (joined(f.wall.a)) stud(sw, 'corner stud');
  if (joined(f.wall.b)) stud(length - 2 * sw, 'corner stud');
  for (let t = spacing; t < length - 2 * sw; t += spacing) if (t - sw / 2 > 2 * sw && !busy(t - sw / 2)) stud(t - sw / 2);
  for (const o of ops) {
    const head = Math.min(plate1, o.z1);
    const hdrTop = Math.min(plate1, head + headerH);
    // King studs full height, jack studs up to the head carrying the header.
    stud(o.a - 2 * sw, 'king stud');
    stud(o.c + sw, 'king stud');
    stud(o.a - sw, 'jack stud', plate0, head);
    stud(o.c, 'jack stud', plate0, head);
    members.push({ role: 'header', t0: o.a - sw, t1: o.c + sw, z0: head, z1: hdrTop });
    // A sill under a window, cripples under it and over the header.
    const sill = o.z0 > plate0 + sw;
    if (sill) members.push({ role: 'sill', t0: o.a, t1: o.c, z0: o.z0 - sw, z1: o.z0 });
    for (let t = o.a + spacing / 2; t < o.c - sw; t += spacing) {
      stud(t, 'cripple', hdrTop, plate1);
      if (sill) stud(t, 'cripple', plate0, o.z0 - sw);
    }
  }
  const o0 = -f.half - sd / 2;
  return { members, o0, o1: o0 + sd, face: f.face, steps: f.steps, width: sw, depth: sd };
}

/** The lumber list, as Archicad's Wall Framing property script: pieces per role, lengths rounded up to 25 mm. */
export function framingList(g) {
  const out = new Map();
  for (const m of g.members) {
    const len = Math.max(m.t1 - m.t0, m.z1 - m.z0);
    const r = out.get(m.role) || { role: m.role, count: 0, length: 0, section: `${Math.round(g.width)} x ${Math.round(g.depth)}` };
    r.count++;
    r.length += Math.ceil(len / 25) * 25;
    out.set(m.role, r);
  }
  return [...out.values()];
}

function buildFraming(ctx, el) {
  const g = framingGeometry(ctx.doc, el);
  if (!g) return null;
  const col = hexToRgba(ctx.material(el.materialId || 'mat-wood')?.color || '#c8a46e', 1);
  const b = new MeshBuilder();
  const P = pointOn(g.face, g.steps);
  for (const m of g.members) box(b, P, [m.t0, m.t1, m.z0, m.z1], g.o0, g.o1, col);
  return b.build();
}

// Plan --------------------------------------------------------------------------------------------------------------

/** Plan: what the view cuts through (boards, veneer, moldings, studs), else nothing. */
export function planCladding(pc, el, b) {
  const wall = pc.doc.get(el.wallId);
  if (!wall || wall.levelId !== pc.view.levelId) return;
  const kind = el.accessory || 'cladding';
  const z = pc.cutZ;
  const rects = [];
  if (kind === 'battered') {
    const g = batteredGeometry(pc.doc, el);
    if (g) for (const [t0, t1, z0, z1] of g.pieces) if (z0 <= z && z1 > z) rects.push([g.face, t0, t1, 0, g.depth(z)]);
  } else if (kind === 'framing') {
    const g = framingGeometry(pc.doc, el);
    if (g) for (const m of g.members) if (m.z0 <= z && m.z1 > z) rects.push([g.face, m.t0, m.t1, g.o0, g.o1]);
  } else if (kind === 'moldings') {
    const g = moldingsGeometry(pc.doc, el);
    if (g) for (const r of g.runs) if (r.z <= z && r.z + r.h > z) rects.push([g.face, r.t0, r.t1, 0, r.depth]);
  } else {
    const g = claddingGeometry(pc.doc, el);
    if (g) for (const [t0, t1, z0, z1] of g.pieces) if (z0 <= z && z1 > z) rects.push([g.face, t0, t1, g.cavity, g.cavity + g.thickness]);
  }
  const steps = faceOf(pc.doc, el)?.steps;
  for (const [face, t0, t1, o0, o1] of rects) {
    const ts = steps ? steps(t0, t1) : [t0, t1];
    const poly = [...ts.map((t) => face(t, o0)), ...ts.slice().reverse().map((t) => face(t, o1))];
    b.fill(poly, [], [-1, -1, -1, 140]);
    b.poly(poly, true, W.thin);
    b.pick(poly);
  }
}
