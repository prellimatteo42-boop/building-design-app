/**
 * Solid Element Operations, as in Archicad: a target element's 3D body
 * loses what an operator element's body takes away (subtraction), keeps only
 * what they share (intersection) or takes the operator in (union). Upward
 * subtraction removes everything above the operator too. Stored on the
 * target: seo = [{ id: operatorId, op }]; plans are not affected, 3D views
 * and sections (which cut the 3D bodies) are.
 */
import { meshPolygons, subtract, union, intersect, polygonsMesh } from './csg.js';

export const SEO_OPS = [
  { value: 'subtract', label: 'Subtraction' },
  { value: 'subtractUp', label: 'Subtraction with Upward Extrusion' },
  { value: 'intersect', label: 'Intersection' },
  { value: 'union', label: 'Union' },
];

/** Beyond this many triangles a body is left as it is (the operation would be slow). */
const MAX_TRIS = 12000;

/** Polygons of an operator body raised to the sky above its middle height (upward extrusion). */
function extrudeUp(polys) {
  let z0 = Infinity;
  let z1 = -Infinity;
  for (const p of polys)
    for (const v of p.vs) {
      z0 = Math.min(z0, v.p[2]);
      z1 = Math.max(z1, v.p[2]);
    }
  const mid = (z0 + z1) / 2;
  return polys.map((p) => ({ ...p, vs: p.vs.map((v) => (v.p[2] > mid ? { ...v, p: [v.p[0], v.p[1], z1 + 1e6] } : v)), plane: p.plane }))
    .map((p) => ({ ...p, plane: planeOfPoly(p) }))
    .filter((p) => p.plane);
}

function planeOfPoly(p) {
  const [a, b, c] = p.vs.map((v) => v.p);
  const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const w = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
  const n = [u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]];
  const l = Math.hypot(...n);
  if (l < 1e-9) return null;
  const nn = n.map((x) => x / l);
  return { n: nn, w: nn[0] * a[0] + nn[1] * a[1] + nn[2] * a[2] };
}

/**
 * The target mesh after its operations. operatorMesh(id) gives an
 * operator's own mesh (or null). Returns the mesh unchanged when nothing
 * applies.
 */
export function applySEO(mesh, ops, operatorMesh) {
  if (!mesh?.pos?.length || !ops?.length) return mesh;
  let polys = meshPolygons(mesh);
  if (polys.length > MAX_TRIS) return mesh;
  let changed = false;
  for (const { id, op } of ops) {
    const om = operatorMesh(id);
    if (!om?.pos?.length) continue;
    let o = meshPolygons(om);
    if (o.length > MAX_TRIS) continue;
    if (op === 'subtractUp') o = extrudeUp(o);
    polys = op === 'intersect' ? intersect(polys, o) : op === 'union' ? union(polys, o) : subtract(polys, o);
    changed = true;
  }
  if (!changed) return mesh;
  const out = polygonsMesh(polys);
  // Sections fill layered walls by part (build3d.js).
  if (mesh.partMaterials) out.partMaterials = mesh.partMaterials;
  else delete out.parts;
  return out;
}
