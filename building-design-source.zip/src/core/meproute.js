/**
 * MEP routing, as Archicad's Duct / Pipe / Cable Carrier Route and its
 * Branch, Take-Off and Fitting tools:
 *
 *   - a route is a chain of runs; changing the elevation between two clicks
 *     puts a riser (a vertical run) at the corner, and a slope makes each run
 *     fall (or rise) along its length, the next one starting where it ended;
 *   - a branch (a take-off on ducts) starts on the middle of a run and goes
 *     to a clicked point; a fitting placed on a run splits it there, the
 *     part after it taking a new size (a transition);
 *   - the fittings (elbows, tees, crosses, transitions, branches) are made
 *     again after each change (core/mepfittings.js).
 */
import { fittingsFor } from './mepfittings.js';
import { routePrefs, routeFamily } from './projectprefs.js';

const r1 = (v) => Math.round(v * 10) / 10;

/**
 * The runs (not added) for the next leg of a route from `from` { p, z } to plan point p at elevation z (both z
 * above the level): a riser first when the elevation changed, then the run, falling by `slope` percent.
 * Returns { runs, end: { p, z } }.
 */
export function routeLeg(base, from, p, z, { slope = 0 } = {}) {
  const runs = [];
  if (Math.abs(z - from.z) > 0.5) runs.push({ ...base, a: from.p, b: from.p, offset: r1(from.z), endOffset: r1(z) });
  const L = Math.hypot(p[0] - from.p[0], p[1] - from.p[1]);
  const zEnd = z - (slope / 100) * L;
  if (L > 1) runs.push({ ...base, a: from.p, b: p, offset: r1(z), ...(slope ? { endOffset: r1(zEnd) } : {}) });
  return { runs, end: { p, z: L > 1 ? zEnd : z } };
}

/** The point of a run nearest a plan point: { t (0..1), p, z (above the level) } or null for a riser. */
export function onRun(run, q) {
  const d = [run.b[0] - run.a[0], run.b[1] - run.a[1]];
  const l2 = d[0] * d[0] + d[1] * d[1];
  if (l2 < 1) return null;
  const t = Math.max(0, Math.min(1, ((q[0] - run.a[0]) * d[0] + (q[1] - run.a[1]) * d[1]) / l2));
  const za = +run.offset || 0;
  const zb = run.endOffset != null ? +run.endOffset : za;
  return { t, p: [r1(run.a[0] + d[0] * t), r1(run.a[1] + d[1] * t)], z: r1(za + (zb - za) * t) };
}

/**
 * Split a run at t (inside a transaction): the run keeps its start, a new one (with `patch`, such as a new size)
 * goes from the split point to its end. Returns the new run's id.
 */
export function splitRun(doc, id, t, patch = {}) {
  const run = doc.get(id);
  const at = onRun(run, [run.a[0] + (run.b[0] - run.a[0]) * t, run.a[1] + (run.b[1] - run.a[1]) * t]);
  const zb = run.endOffset != null ? +run.endOffset : +run.offset || 0;
  const sloped = run.endOffset != null;
  doc.update(id, { b: at.p, ...(sloped ? { endOffset: at.z } : {}) });
  const { id: _id, ...rest } = run;
  void _id;
  return doc.add({ ...rest, a: at.p, b: run.b, offset: at.z, ...(sloped ? { endOffset: zb } : {}), ...patch }).id;
}

/** A branch (not added) off a run at plan point q to plan point to, at the main's elevation there, of `base`. */
export function branchRun(main, q, to, base = {}) {
  const at = onRun(main, q);
  if (!at || at.t <= 0.02 || at.t >= 0.98) return null;
  const { id: _id, a: _a, b: _b, endOffset: _e, ...rest } = main;
  void _id, _a, _b, _e;
  return { ...rest, ...base, a: at.p, b: to, offset: at.z };
}

/** Make the automatic fittings again (inside a transaction). Returns how many there are. */
export function refreshFittings(doc) {
  for (const f of doc.all('mepFitting')) if (f.auto) doc.remove(f.id);
  const r = routePrefs(doc.get('project'));
  const made = fittingsFor(doc, { bend: (family) => r[routeFamily(family)].bend });
  for (const f of made) doc.add(f);
  return made.length;
}
