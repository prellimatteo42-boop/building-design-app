/**
 * Gravity, as in Archicad: objects and columns placed on the top of the
 * slab (on their story), roof or mesh under their insertion point, through
 * their offset from the level.
 */
import { levelElevation } from './model.js';
import { pointInPolygon } from './geom.js';
import { roofGeometry } from './build3d.js';
import { roofHeightAt } from './roof.js';
import { topoHeightAt, topoSurface } from './topo.js';

export const GRAVITY = [
  { value: 'off', label: 'Gravity Off' },
  { value: 'slab', label: 'Gravity to Slab' },
  { value: 'roof', label: 'Gravity to Roof' },
  { value: 'mesh', label: 'Gravity to Mesh' },
];

const inside = (el, p) => pointInPolygon(p, el.boundary) && !(el.holes || []).some((h) => pointInPolygon(p, h));

/** Height of the surface under p for a gravity mode, or null when there is none. */
export function surfaceZ(doc, mode, p, levelId) {
  let best = null;
  const take = (z) => {
    if (Number.isFinite(z) && (best === null || z > best)) best = z;
  };
  if (mode === 'slab')
    for (const f of doc.all('floor')) if (f.levelId === levelId && f.boundary?.length >= 3 && inside(f, p)) take(levelElevation(doc, f.levelId) + (+f.offset || 0));
  if (mode === 'roof')
    for (const r of doc.all('roof')) {
      if (!r.boundary?.length) continue;
      const g = roofGeometry(doc, r);
      if (pointInPolygon(p, g.poly)) take(g.base + (g.planes.length ? roofHeightAt(g.planes, p) : 0) + g.th);
    }
  if (mode === 'mesh') for (const t of doc.all('topo')) if (topoSurface(t).P.length >= 3) take(topoHeightAt(t, p));
  return best;
}

/** The offset patch putting an object or column on the surface, or null. */
export function gravityPatch(doc, mode, item) {
  if (!mode || mode === 'off' || !item.at || !item.levelId) return null;
  const z = surfaceZ(doc, mode, item.at, item.levelId);
  if (z === null) return null;
  const dz = z - levelElevation(doc, item.levelId);
  if (item.kind === 'component') return { offset: dz };
  if (item.kind === 'column') return { baseOffset: dz };
  return null;
}
