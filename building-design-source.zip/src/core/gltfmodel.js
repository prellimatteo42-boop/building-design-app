/**
 * A model shaped in Blender (or any program writing glTF) as elements of this project: each object is read as what
 * its name, its custom properties or its shape say it is.
 *
 * - Its name or a `bd_kind` / `kind` property (Blender's custom properties travel as glTF extras): wall/muro/parete,
 *   floor/slab/solaio/pavimento/ceiling/soffitto, roof/tetto, column/pilastro, door/porta, window/finestra,
 *   furniture/arredo; an element exported by this app keeps its kind.
 * - Else its shape: an upright box thin in plan is a wall (holes through it become doors when they reach its foot,
 *   windows otherwise), a flat one a slab (its top face's outline, holes kept), an upright post a column, something
 *   that fits in a room a piece of furniture (a GDL object), anything else a morph that keeps the form as it is.
 * - Door and window objects go into the wall they sit in, at their size and height; holes they fill are not doubled.
 *
 * Coordinates: readGLTF's millimetres, Z up.
 */
import { minRect, signedArea, distToSegment } from './geom.js';
import { buildFloorPlan, wallTypeMaking } from './floorplan.js';
import { gdlFromMeshes } from './savegdl.js';
import { materialForGLTF } from './libtools.js';

const HINTS = [
  ['door', /\b(door|porta|portone|tür)\b/i],
  ['window', /\b(window|finestra|fenster|vetrata)\b/i],
  ['wall', /\b(wall|muro|muri|parete|tramezzo|wand)\b/i],
  ['column', /\b(column|pilastro|colonna|pillar|post)\b/i],
  ['roof', /\b(roof|tetto|copertura|falda)\b/i],
  ['slab', /\b(floor|slab|solaio|pavimento|ceiling|soffitto|platform|soletta|plate)\b/i],
  ['furniture', /\b(furniture|arredo|mobile|chair|sedia|table|tavolo|sofa|divano|bed|letto|lamp|lampada|desk|scrivania|cabinet|armadio|shelf)\b/i],
];
const KINDS = { wall: 'wall', floor: 'slab', slab: 'slab', roof: 'roof', column: 'column', door: 'door', window: 'window', component: 'furniture', furniture: 'furniture', morph: 'morph' };

/** What an object says it is (name, then custom properties), or null. */
export function objectHint(name = '', extras = {}) {
  const own = extras.bd_kind || extras.bdKind || extras.kind;
  if (own && KINDS[String(own).toLowerCase()]) return KINDS[String(own).toLowerCase()];
  const words = String(name).replace(/[._\-]+/g, ' ').replace(/\d+/g, ' ');
  for (const [kind, re] of HINTS) if (re.test(words)) return kind;
  return null;
}

/** The measures of an object's triangles: z range, plan rectangle, volume and how full of it the rectangle is. */
export function objectShape(pos) {
  let z0 = Infinity;
  let z1 = -Infinity;
  const pts = [];
  for (let i = 0; i < pos.length; i += 3) {
    z0 = Math.min(z0, pos[i + 2]);
    z1 = Math.max(z1, pos[i + 2]);
    pts.push([pos[i], pos[i + 1]]);
  }
  const rect = minRect(pts);
  let vol = 0;
  for (let t = 0; t < pos.length; t += 9) {
    const [ax, ay, az, bx, by, bz, cx, cy, cz] = pos.subarray ? pos.subarray(t, t + 9) : pos.slice(t, t + 9);
    vol += (ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) + az * (bx * cy - by * cx)) / 6;
  }
  vol = Math.abs(vol);
  const box = rect.L * rect.T * (z1 - z0);
  return { z0, z1, h: z1 - z0, rect, volume: vol, fill: box > 0 ? vol / box : 0 };
}

/** The kind an object's shape reads as. */
export function shapeKind(sh) {
  const { h, rect, fill } = sh;
  const { L, T } = rect;
  if (T <= 600 && h >= 1500 && L >= 2 * T && fill > 0.3) return 'wall';
  if (h <= 500 && L >= 1200 && T >= 600) return 'slab';
  if (T >= 120 && L <= 1000 && h >= 2000 && h >= 3 * L && fill > 0.6) return 'column';
  if (L <= 3500 && h <= 2600) return 'furniture';
  return 'morph';
}

/**
 * Holes through a wall seen from one face: the faces looking along the wall's normal, drawn on a grid along the wall
 * (s) and up it (z); empty patches that do not reach the edges are holes. Returns [{ s0, s1, z0, z1 }] (mm).
 */
export function wallHoles(pos, a, u, n, L, z0, z1, cell = 20) {
  const W = Math.max(1, Math.ceil(L / cell));
  const H = Math.max(1, Math.ceil((z1 - z0) / cell));
  if (W * H > 4e6) return [];
  const grid = new Uint8Array(W * H);
  for (let t = 0; t < pos.length; t += 9) {
    const P = [0, 3, 6].map((k) => [pos[t + k], pos[t + k + 1], pos[t + k + 2]]);
    const e1 = P[1].map((v, i) => v - P[0][i]);
    const e2 = P[2].map((v, i) => v - P[0][i]);
    const nx = e1[1] * e2[2] - e1[2] * e2[1];
    const ny = e1[2] * e2[0] - e1[0] * e2[2];
    const nz = e1[0] * e2[1] - e1[1] * e2[0];
    const l = Math.hypot(nx, ny, nz) || 1;
    // Faces looking either way across the wall (both faces cover the same patch where the wall is solid).
    if (Math.abs((nx * n[0] + ny * n[1]) / l) < 0.9) continue;
    const q = P.map((p) => [((p[0] - a[0]) * u[0] + (p[1] - a[1]) * u[1]) / cell, (p[2] - z0) / cell]);
    const [x0, x1] = [Math.max(0, Math.floor(Math.min(...q.map((p) => p[0])))), Math.min(W - 1, Math.ceil(Math.max(...q.map((p) => p[0]))))];
    const [y0, y1] = [Math.max(0, Math.floor(Math.min(...q.map((p) => p[1])))), Math.min(H - 1, Math.ceil(Math.max(...q.map((p) => p[1]))))];
    const d = (q[1][0] - q[0][0]) * (q[2][1] - q[0][1]) - (q[2][0] - q[0][0]) * (q[1][1] - q[0][1]);
    if (Math.abs(d) < 1e-9) continue;
    for (let y = y0; y <= y1; y++)
      for (let x = x0; x <= x1; x++) {
        const px = x + 0.5;
        const py = y + 0.5;
        const w1 = ((q[1][0] - px) * (q[2][1] - py) - (q[2][0] - px) * (q[1][1] - py)) / d;
        const w2 = ((q[2][0] - px) * (q[0][1] - py) - (q[0][0] - px) * (q[2][1] - py)) / d;
        if (w1 >= -1e-6 && w2 >= -1e-6 && 1 - w1 - w2 >= -1e-6) grid[y * W + x] = 1;
      }
  }
  const seen = new Uint8Array(W * H);
  const holes = [];
  for (let s = 0; s < W * H; s++) {
    if (grid[s] || seen[s]) continue;
    const stack = [s];
    seen[s] = 1;
    let edge = false;
    let [xa, xb, ya, yb] = [Infinity, -1, Infinity, -1];
    let count = 0;
    while (stack.length) {
      const c = stack.pop();
      const x = c % W;
      const y = (c / W) | 0;
      count++;
      xa = Math.min(xa, x);
      xb = Math.max(xb, x);
      ya = Math.min(ya, y);
      yb = Math.max(yb, y);
      // A hole reaching the foot of the wall is a doorway, not an open edge: only the sides and the top are open.
      if (x === 0 || x === W - 1 || y === H - 1) edge = true;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx;
        const ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const k = ny * W + nx;
        if (!grid[k] && !seen[k]) {
          seen[k] = 1;
          stack.push(k);
        }
      }
    }
    // Small specks are gaps between faces, not holes.
    if (edge || count < 40 || xb - xa < 10 || yb - ya < 10) continue;
    holes.push({ s0: xa * cell, s1: (xb + 1) * cell, z0: z0 + ya * cell, z1: z0 + (yb + 1) * cell });
  }
  return holes;
}

/** The outline of the faces looking up at the top of a flat object: [outer, ...holes]. */
export function topOutline(pos, zTop, tol = 5) {
  const count = new Map();
  const ends = new Map();
  const key = (p) => `${Math.round(p[0])},${Math.round(p[1])}`;
  for (let t = 0; t < pos.length; t += 9) {
    const P = [0, 3, 6].map((k) => [pos[t + k], pos[t + k + 1], pos[t + k + 2]]);
    if (P.some((p) => Math.abs(p[2] - zTop) > tol)) continue;
    const ar = (P[1][0] - P[0][0]) * (P[2][1] - P[0][1]) - (P[2][0] - P[0][0]) * (P[1][1] - P[0][1]);
    if (Math.abs(ar) < 1) continue;
    const Q = ar > 0 ? P : [P[0], P[2], P[1]];
    for (let i = 0; i < 3; i++) {
      const [ka, kb] = [key(Q[i]), key(Q[(i + 1) % 3])];
      if (ka === kb) continue;
      const rev = `${kb}|${ka}`;
      if (count.has(rev)) count.delete(rev);
      else {
        count.set(`${ka}|${kb}`, 1);
        ends.set(ka, Q[i]);
        ends.set(kb, Q[(i + 1) % 3]);
      }
    }
  }
  // Chain the edges used once into loops.
  const next = new Map();
  for (const k of count.keys()) {
    const [ka, kb] = k.split('|');
    next.set(ka, kb);
  }
  const loops = [];
  const used = new Set();
  for (const start of next.keys()) {
    if (used.has(start)) continue;
    const loop = [];
    let k = start;
    while (k && !used.has(k)) {
      used.add(k);
      loop.push(ends.get(k).slice(0, 2).map(Math.round));
      k = next.get(k);
    }
    if (loop.length >= 3) loops.push(dropCollinear(loop));
  }
  loops.sort((x, y) => Math.abs(signedArea(y)) - Math.abs(signedArea(x)));
  return loops.filter((l) => l.length >= 3);
}

function dropCollinear(loop) {
  const out = [];
  for (let i = 0; i < loop.length; i++) {
    const a = loop[(i - 1 + loop.length) % loop.length];
    const b = loop[i];
    const c = loop[(i + 1) % loop.length];
    const cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
    if (Math.abs(cross) > 1e-3 * Math.hypot(b[0] - a[0], b[1] - a[1]) * Math.hypot(c[0] - b[0], c[1] - b[1])) out.push(b);
  }
  return out;
}

/** The circle through points (least squares): { c, r } or null. */
export function fitCircle(pts) {
  // x² + y² + D x + E y + F = 0, about the points' mean for precision.
  const mx = pts.reduce((s, p) => s + p[0], 0) / pts.length;
  const my = pts.reduce((s, p) => s + p[1], 0) / pts.length;
  const A = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  const B = [0, 0, 0];
  for (const [px, py] of pts) {
    const [x, y] = [px - mx, py - my];
    const row = [x, y, 1];
    const rhs = -(x * x + y * y);
    for (let i = 0; i < 3; i++) {
      B[i] += row[i] * rhs;
      for (let j = 0; j < 3; j++) A[i][j] += row[i] * row[j];
    }
  }
  const det = (m) => m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
  const d = det(A);
  if (Math.abs(d) < 1e-9) return null;
  const sol = [0, 1, 2].map((k) => det(A.map((r, i) => r.map((v, j) => (j === k ? B[i] : v)))) / d);
  const c = [-sol[0] / 2, -sol[1] / 2];
  const r2 = c[0] * c[0] + c[1] * c[1] - sol[2];
  return r2 > 0 ? { c: [c[0] + mx, c[1] + my], r: Math.sqrt(r2) } : null;
}

/**
 * A curved wall in plan points: its centre line from a to b counterclockwise (the app's positive sweep), thickness and
 * sweep, when every point lies on one of two concentric arcs; else null.
 */
export function arcWall(pts) {
  // One circle through both faces sits between them, off centre: split the points into the inner and the outer face
  // and fit each, a few times over.
  let fit = fitCircle(pts);
  for (let k = 0; fit && k < 6; k++) {
    const rs = pts.map((p) => Math.hypot(p[0] - fit.c[0], p[1] - fit.c[1]));
    const mid = (Math.min(...rs) + Math.max(...rs)) / 2;
    const inner = pts.filter((_, i) => rs[i] < mid);
    const outer = pts.filter((_, i) => rs[i] >= mid);
    const fi = inner.length >= 3 ? fitCircle(inner) : null;
    const fo = outer.length >= 3 ? fitCircle(outer) : null;
    if (!fi || !fo) break;
    fit = { c: [(fi.c[0] + fo.c[0]) / 2, (fi.c[1] + fo.c[1]) / 2], r: (fi.r + fo.r) / 2 };
  }
  if (!fit || fit.r > 1e6) return null;
  const rs = pts.map((p) => Math.hypot(p[0] - fit.c[0], p[1] - fit.c[1]));
  const rin = Math.min(...rs);
  const rout = Math.max(...rs);
  const T = rout - rin;
  if (!(T > 10 && T <= 800 && rin > T)) return null;
  if (!rs.every((r) => Math.min(Math.abs(r - rin), Math.abs(r - rout)) < 0.05 * T + 5)) return null;
  const ang = pts.map((p) => Math.atan2(p[1] - fit.c[1], p[0] - fit.c[0])).sort((x, y) => x - y);
  let gap = ang[0] + 2 * Math.PI - ang.at(-1);
  let start = ang[0];
  for (let i = 1; i < ang.length; i++)
    if (ang[i] - ang[i - 1] > gap) [gap, start] = [ang[i] - ang[i - 1], ang[i]];
  const sweep = 2 * Math.PI - gap;
  if (sweep < 0.05 || sweep > 2 * Math.PI - 0.05) return null;
  const rm = (rin + rout) / 2;
  const at = (t) => [fit.c[0] + rm * Math.cos(t), fit.c[1] + rm * Math.sin(t)];
  return { a: at(start).map(Math.round), b: at(start + sweep).map(Math.round), sweep, thickness: Math.round(T), c: fit.c, r: rm };
}

function concat(meshes) {
  const n = meshes.reduce((s, m) => s + m.pos.length, 0);
  const pos = new Float32Array(n);
  let o = 0;
  for (const m of meshes) {
    pos.set(m.pos, o);
    o += m.pos.length;
  }
  return pos;
}

/**
 * Elements from glTF meshes (readGLTF), added to `doc` (inside a transaction) on `levelId`. Returns counts and what
 * each object became: { walls, slabs, columns, doors, windows, furniture, morphs, objects: [{ name, as }], skipped }.
 */
export function modelFromGLTF(doc, meshes, { levelId } = {}) {
  const level = doc.get(levelId) || doc.levels()[0];
  const base = +level.elevation || 0;
  // One object per glTF node.
  const objects = new Map();
  for (const m of meshes) {
    const k = m.nodeIndex ?? m.object ?? m.name;
    if (!objects.has(k)) objects.set(k, { name: m.object || m.name, extras: m.extras || {}, meshes: [] });
    objects.get(k).meshes.push(m);
  }
  const out = { walls: 0, slabs: 0, columns: 0, doors: 0, windows: 0, openings: 0, furniture: 0, morphs: 0, objects: [], skipped: [] };
  const materialIds = new Map();
  const materialOf = (m) => {
    const k = `${m.name}|${m.color}`;
    if (!materialIds.has(k)) {
      const r = materialForGLTF(doc, m);
      materialIds.set(k, r.id || doc.add(r.add).id);
    }
    return materialIds.get(k);
  };
  const plan = { walls: [], doors: [], windows: [], newTypes: 'exact' };
  const wallInfo = [];
  const pending = [];
  for (const obj of objects.values()) {
    const pos = concat(obj.meshes);
    if (pos.length < 9) continue;
    const sh = objectShape(pos);
    const as = objectHint(obj.name, obj.extras) || shapeKind(sh);
    obj.shape = sh;
    obj.pos = pos;
    obj.as = as;
    out.objects.push({ name: obj.name, as });
    // A wall bent in plan (it fills little of its rectangle): a curved wall of the app.
    const curved = as === 'wall' && sh.fill < 0.5 ? arcWall(Array.from({ length: pos.length / 3 }, (_, i) => [pos[i * 3], pos[i * 3 + 1]])) : null;
    if (curved) {
      const type = wallTypeMaking(doc, curved.thickness, false, true);
      doc.add({ kind: 'wall', typeId: type.id, levelId: level.id, a: curved.a, b: curved.b, arc: curved.sweep, paintId: materialOf(obj.meshes[0].material), baseOffset: Math.round(sh.z0 - base), topLevelId: null, topOffset: 0, height: Math.round(sh.h), locationLine: 'center', joinA: true, joinB: true, roomBounding: true, name: obj.name });
      out.curvedWalls = (out.curvedWalls || 0) + 1;
      obj.as = 'curved wall';
      out.objects.at(-1).as = 'curved wall';
    } else if (as === 'wall' && sh.rect.T <= 1000) {
      const { c, u, L, T } = sh.rect;
      const a = [c[0] - (u[0] * L) / 2, c[1] - (u[1] * L) / 2];
      const b = [c[0] + (u[0] * L) / 2, c[1] + (u[1] * L) / 2];
      const n = [-u[1], u[0]];
      const holes = wallHoles(pos, a, u, n, L, sh.z0, sh.z1);
      plan.walls.push({ a: a.map(Math.round), b: b.map(Math.round), thickness: Math.max(10, Math.round(T)), height: Math.round(sh.h) });
      wallInfo.push({ a, u, n, L, T, holes, z0: sh.z0, h: sh.h, materialId: materialOf(obj.meshes[0].material) });
    } else pending.push(obj);
  }
  // Door and window objects: at their centre, their size along their own long side.
  const fills = [];
  for (const obj of pending) {
    if (obj.as !== 'door' && obj.as !== 'window') continue;
    const { rect, z0, z1 } = obj.shape;
    fills.push({ kind: obj.as, at: rect.c, width: Math.round(rect.L), height: Math.round(z1 - z0), z0 });
  }
  // Holes no object fills become doors (reaching the wall's foot) or windows.
  for (const w of wallInfo)
    for (const hole of w.holes) {
      const mid = [w.a[0] + w.u[0] * ((hole.s0 + hole.s1) / 2), w.a[1] + w.u[1] * ((hole.s0 + hole.s1) / 2)];
      if (fills.some((f) => distToSegment(f.at, w.a, [w.a[0] + w.u[0] * w.L, w.a[1] + w.u[1] * w.L]) < w.T + 100 && Math.abs((f.at[0] - w.a[0]) * w.u[0] + (f.at[1] - w.a[1]) * w.u[1] - (hole.s0 + hole.s1) / 2) < (hole.s1 - hole.s0) / 2)) continue;
      const door = hole.z0 - w.z0 < 60;
      fills.push({ kind: door ? 'door' : 'window', at: mid, width: Math.round(hole.s1 - hole.s0), height: Math.round(hole.z1 - hole.z0), z0: hole.z0, fromHole: true });
    }
  for (const f of fills) {
    const o = { at: f.at.map(Math.round), width: f.width, height: f.height };
    if (f.kind === 'window') plan.windows.push({ ...o, sill: Math.max(0, Math.round(f.z0 - base)) });
    else plan.doors.push(o);
  }
  const built = buildFloorPlan(doc, plan, { levelId: level.id, minLength: 100 });
  out.skipped.push(...built.skipped);
  // Each wall at its own foot and height, and in its own material.
  // (The plan's walls may have been joined or trimmed: each takes the Blender wall nearest its middle.)
  built.walls.forEach((id) => {
    const el = doc.get(id);
    const mid = [(el.a[0] + el.b[0]) / 2, (el.a[1] + el.b[1]) / 2];
    let w = null;
    let best = Infinity;
    for (const x of wallInfo) {
      const d = distToSegment(mid, x.a, [x.a[0] + x.u[0] * x.L, x.a[1] + x.u[1] * x.L]);
      if (d < best) [best, w] = [d, x];
    }
    if (!w) return;
    doc.update(id, { baseOffset: Math.round(w.z0 - base), topLevelId: null, height: Math.round(w.h), paintId: w.materialId });
  });
  out.walls = built.walls.length + (out.curvedWalls || 0);
  out.doors = built.doors.length;
  out.windows = built.windows.length;
  for (const obj of pending) {
    const { rect, z0, z1 } = obj.shape;
    if (obj.as === 'door' || obj.as === 'window' || obj.as === 'curved wall') continue;
    if (obj.as === 'slab' || (obj.as === 'roof' && obj.shape.h <= 600)) {
      const loops = topOutline(obj.pos, z1);
      if (!loops.length || Math.abs(signedArea(loops[0])) < 1e5) {
        out.skipped.push(`${obj.name}: no flat top to make a slab of`);
        continue;
      }
      const th = Math.max(10, Math.round(z1 - z0));
      let type = doc.all('floorType').find((t) => !t.foundation && Math.abs((t.layers || []).reduce((s, l) => s + (+l.thickness || 0), 0) - th) <= 1);
      if (!type) type = doc.add({ kind: 'floorType', name: `Generic - ${th} mm`, layers: [{ materialId: materialOf(obj.meshes[0].material), thickness: th, function: 'structure' }] });
      const outer = signedArea(loops[0]) < 0 ? [...loops[0]].reverse() : loops[0];
      doc.add({ kind: 'floor', typeId: type.id, levelId: level.id, boundary: outer, holes: loops.slice(1), offset: Math.round(z1 - base), paintId: materialOf(obj.meshes[0].material), name: obj.name });
      out.slabs++;
    } else if (obj.as === 'column') {
      const round = obj.shape.fill < 0.85 && rect.L - rect.T < 0.1 * rect.L;
      const [w, d] = [Math.round(rect.L), Math.round(rect.T)];
      const tname = round ? `Round ${w} mm` : `${w} x ${d} mm`;
      let type = doc.all('columnType').find((t) => t.name === tname);
      if (!type) {
        const { id: _id, ...rest } = doc.all('columnType')[0] || {};
        type = doc.add({ ...rest, kind: 'columnType', name: tname, width: w, depth: round ? w : d, shape: round ? 'round' : 'rect' });
      }
      doc.add({ kind: 'column', typeId: type.id, levelId: level.id, at: rect.c.map(Math.round), rotation: Math.atan2(rect.u[1], rect.u[0]), baseOffset: Math.round(z0 - base), topLevelId: null, height: Math.round(z1 - z0), paintId: materialOf(obj.meshes[0].material), name: obj.name });
      out.columns++;
    } else if (obj.as === 'furniture') {
      const g = gdlFromMeshes(obj.meshes.map((m) => ({ mesh: m, materialId: materialOf(m.material) })));
      if (!g) continue;
      const type = doc.add({ kind: 'componentType', family: 'gdl', familyName: 'GDL Object (glTF)', category: 'furniture', name: obj.name, width: g.width, depth: g.depth, height: g.height, gdl: { params: [], script3d: g.script3d, script2d: g.script2d } });
      doc.add({ kind: 'component', typeId: type.id, levelId: level.id, at: g.origin.slice(0, 2).map(Math.round), rotation: 0, offset: Math.round(g.origin[2] - base) });
      out.furniture++;
    } else {
      // A free form (a curved wall, a vault, a sloping roof): a morph that keeps it.
      const tris = Array.from(obj.pos, Math.round);
      doc.add({ kind: 'morph', levelId: level.id, tris, materialId: materialOf(obj.meshes[0].material), name: obj.name });
      out.morphs++;
    }
  }
  return out;
}
