/**
 * Complex profiles, as in Archicad's Profile Manager: cross-sections made
 * of polygons (with holes), each in a building material.
 *   - wall: x across the wall (positive towards its exterior side), y up
 *     from its base; vertices above `stretch` move up with the wall's
 *     height, so a cornice stays a cornice on taller walls;
 *   - beam: x across, y up from the beam's bottom; its top is the beam's top;
 *   - column: x, y in plan around the column's point, extruded up.
 * profile { kind: 'profile', name, use, shapes: [{ poly, holes, materialId }], stretch }
 */
import { MeshBuilder, Frame, hexToRgba } from './mesh.js';
import { add, sub, scale, norm, perp, len, triangulate, signedArea } from './geom.js';
import { meshPolygons, subtract, polygonsMesh } from './csg.js';

const rect = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
const circle = (r, n = 32) => Array.from({ length: n }, (_, i) => [r * Math.cos((2 * Math.PI * i) / n), r * Math.sin((2 * Math.PI * i) / n)]);

/** I or channel section, bottom at y = 0, centred on x = 0 (I) or web at x = 0 (channel). */
function iSection(h, bw, tw, tf) {
  const x = bw / 2;
  const w = tw / 2;
  return [[-x, 0], [x, 0], [x, tf], [w, tf], [w, h - tf], [x, h - tf], [x, h], [-x, h], [-x, h - tf], [-w, h - tf], [-w, tf], [-x, tf]];
}

export const PROFILE_PRESETS = [
  {
    id: 'pf-cornice',
    name: 'Wall with Cornice',
    use: 'wall',
    stretch: 1500,
    shapes: [
      { poly: [[-150, 0], [150, 0], [150, 2650], [300, 2750], [380, 2750], [380, 3000], [-150, 3000]], materialId: 'mat-masonry-brick' },
    ],
  },
  { id: 'pf-battered', name: 'Battered Wall', use: 'wall', stretch: 0, shapes: [{ poly: [[-300, 0], [300, 0], [100, 3000], [-100, 3000]], materialId: 'mat-concrete' }] },
  {
    id: 'pf-plinth',
    name: 'Wall with Plinth',
    use: 'wall',
    stretch: 800,
    shapes: [
      { poly: rect(-100, 0, 160, 600), materialId: 'mat-stone' },
      { poly: rect(-100, 600, 100, 3000), materialId: 'mat-masonry-brick' },
    ],
  },
  { id: 'pf-ipe300', name: 'IPE 300', use: 'beam', shapes: [{ poly: iSection(300, 150, 7.1, 10.7), materialId: 'mat-steel' }] },
  { id: 'pf-heb200', name: 'HEB 200', use: 'beam', shapes: [{ poly: iSection(200, 200, 9, 15), materialId: 'mat-steel' }] },
  { id: 'pf-upn200', name: 'UPN 200', use: 'beam', shapes: [{ poly: [[0, 0], [75, 0], [75, 11.5], [8.5, 11.5], [8.5, 188.5], [75, 188.5], [75, 200], [0, 200]], materialId: 'mat-steel' }] },
  { id: 'pf-rhs', name: 'Hollow Section 200 x 100', use: 'beam', shapes: [{ poly: rect(-50, 0, 50, 200), holes: [rect(-42, 8, 42, 192)], materialId: 'mat-steel' }] },
  {
    id: 'pf-cross',
    name: 'Cruciform Column',
    use: 'column',
    shapes: [{ poly: [[-100, -300], [100, -300], [100, -100], [300, -100], [300, 100], [100, 100], [100, 300], [-100, 300], [-100, 100], [-300, 100], [-300, -100], [-100, -100]], materialId: 'mat-concrete' }],
  },
  { id: 'pf-chs273', name: 'Steel Tube 273', use: 'column', shapes: [{ poly: circle(136.5), holes: [circle(126.5)], materialId: 'mat-steel' }] },
];

export function defaultProfiles() {
  return PROFILE_PRESETS.map((p) => ({ ...JSON.parse(JSON.stringify(p)), kind: 'profile' }));
}

/** Profiles for an element kind, for its Profile property. */
export function profilesFor(doc, use) {
  return doc.all('profile').filter((p) => p.use === use);
}

/** The profile an element uses, when it is a valid one for it. */
export function profileOf(doc, el) {
  const p = el.profileId ? doc.get(el.profileId) : null;
  return p?.kind === 'profile' && p.use === el.kind && p.shapes?.some((s) => s.poly?.length >= 3) ? p : null;
}

/** Extent of the profile's polygons: { x0, x1, y0, y1 }. */
export function profileBox(profile) {
  const pts = profile.shapes.flatMap((s) => s.poly);
  return { x0: Math.min(...pts.map((p) => p[0])), x1: Math.max(...pts.map((p) => p[0])), y0: Math.min(...pts.map((p) => p[1])), y1: Math.max(...pts.map((p) => p[1])) };
}

/** Shapes of a wall profile for a wall of height H: what lies above the stretch line moves up. */
export function stretchedShapes(profile, H) {
  if (profile.use !== 'wall') return profile.shapes;
  const nominal = profileBox(profile).y1;
  const d = H - nominal;
  const s = +profile.stretch || 0;
  const move = (p) => (p[1] > s ? [p[0], p[1] + d] : p);
  return profile.shapes.map((sh) => ({ ...sh, poly: sh.poly.map(move), holes: (sh.holes || []).map((h) => h.map(move)) }));
}

/**
 * Extrude shapes (x, y) along a run: world(u, x, y) gives the 3D point at
 * distance u. When the frame (u, x, y) is left-handed (a flipped wall) every
 * face is turned round so the body stays outward-facing.
 */
function extrude(b, shapes, L, world, colorOf) {
  const o = world(0, 0, 0);
  const d = (q) => [q[0] - o[0], q[1] - o[1], q[2] - o[2]];
  const [eu, ex, ey] = [d(world(1, 0, 0)), d(world(0, 1, 0)), d(world(0, 0, 1))];
  const right = (eu[1] * ex[2] - eu[2] * ex[1]) * ey[0] + (eu[2] * ex[0] - eu[0] * ex[2]) * ey[1] + (eu[0] * ex[1] - eu[1] * ex[0]) * ey[2] > 0;
  const tri = (a, c, e, col) => (right ? b.tri(a, c, e, col) : b.tri(a, e, c, col));
  const quad = (a, c, e, f, col) => (right ? b.quad(a, c, e, f, col) : b.quad(f, e, c, a, col));
  for (const sh of shapes) {
    const outer = signedArea(sh.poly) >= 0 ? sh.poly : sh.poly.slice().reverse();
    const holes = (sh.holes || []).map((h) => (signedArea(h) >= 0 ? h.slice().reverse() : h));
    const col = colorOf(sh);
    const { points, tris } = triangulate(outer, holes);
    for (let t = 0; t + 2 < tris.length; t += 3) {
      const [p, q, r] = [points[tris[t]], points[tris[t + 1]], points[tris[t + 2]]];
      const ccw = (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]) > 0;
      const [a, c] = ccw ? [q, r] : [r, q];
      // The end at u = 0 faces back, the one at u = L faces on.
      tri(world(0, p[0], p[1]), world(0, c[0], c[1]), world(0, a[0], a[1]), col);
      tri(world(L, p[0], p[1]), world(L, a[0], a[1]), world(L, c[0], c[1]), col);
    }
    for (const loop of [outer, ...holes])
      for (let i = 0; i < loop.length; i++) {
        const p = loop[i];
        const q = loop[(i + 1) % loop.length];
        // Outward: the loop runs counterclockwise around the solid seen down the run (holes the other way).
        quad(world(0, p[0], p[1]), world(0, q[0], q[1]), world(L, q[0], q[1]), world(L, p[0], p[1]), col);
        b.edge(world(0, p[0], p[1]), world(L, p[0], p[1]));
        b.edge(world(0, p[0], p[1]), world(0, q[0], q[1]));
        b.edge(world(L, p[0], p[1]), world(L, q[0], q[1]));
      }
  }
}

const colorFor = (doc) => (sh) => hexToRgba(doc.get(sh.materialId)?.color || '#bdbdbd', doc.get(sh.materialId)?.opacity ?? 1);

/**
 * A wall built from its profile along its reference line, between base
 * and top; openings (base-relative rectangles { u0, u1, z0, z1 }) are cut
 * through it.
 */
export function buildProfiledWall(doc, w, profile, base, top, openings = []) {
  const L = len(sub(w.b, w.a));
  if (L < 1) return null;
  const dir = norm(sub(w.b, w.a));
  const ext = scale(perp(dir), w.flipped ? -1 : 1);
  const shapes = stretchedShapes(profile, top - base);
  const world = (u, x, y) => {
    const p = add(add(w.a, scale(dir, u)), scale(ext, x));
    return [p[0], p[1], base + y];
  };
  const b = new MeshBuilder();
  extrude(b, shapes, L, world, colorFor(doc));
  let mesh = b.build();
  if (openings.length) {
    const box = profileBox(profile);
    const cut = new MeshBuilder();
    for (const o of openings) {
      const pts = [world(o.u0, box.x0 - 50, 0), world(o.u1, box.x0 - 50, 0), world(o.u1, box.x1 + 50, 0), world(o.u0, box.x1 + 50, 0)].map((p) => [p[0], p[1]]);
      cut.prism(pts, [], o.z0, o.z1, [0, 0, 0, 255]);
    }
    const out = polygonsMesh(subtract(meshPolygons(mesh), meshPolygons(cut.build())));
    delete out.parts;
    mesh = out;
  }
  return mesh;
}

/** A beam built from its profile along a-b, its top at zTop. */
export function buildProfiledBeam(doc, el, profile, zTop) {
  const L = len(sub(el.b, el.a));
  if (L < 1) return null;
  const dir = norm(sub(el.b, el.a));
  const n = perp(dir);
  const { y1 } = profileBox(profile);
  const world = (u, x, y) => {
    const p = add(add(el.a, scale(dir, u)), scale(n, x));
    return [p[0], p[1], zTop - y1 + y];
  };
  const b = new MeshBuilder();
  extrude(b, profile.shapes, L, world, colorFor(doc));
  return b.build();
}

/** Plan polygons of a column profile, placed at the column (with its rotation). */
export function columnProfileShapes(el, profile) {
  const fr = new Frame(el.at, ((+el.rotation || 0) * Math.PI) / 180, 0);
  return profile.shapes.map((s) => ({ ...s, poly: s.poly.map((p) => fr.apply(p)), holes: (s.holes || []).map((h) => h.map((p) => fr.apply(p))) }));
}

export function buildProfiledColumn(doc, el, profile, base, top) {
  const b = new MeshBuilder();
  const col = colorFor(doc);
  for (const s of columnProfileShapes(el, profile)) b.prism(s.poly, s.holes || [], base, top, col(s));
  return b.build();
}

const PATTERN_MATERIAL = { concrete: 'mat-concrete', insulation: 'mat-insulation', brick: 'mat-masonry-brick', wood: 'mat-wood', earth: 'mat-earth', solid: 'mat-concrete' };

/**
 * Capture Profile of Selection (Archicad's): fills drawn in a view become a complex profile. Each fill is a
 * shape (its holes kept) in the material its pattern suggests; walls and beams measure x from the middle and y
 * from the bottom of the drawing, columns from its centre. Returns the profile (not added).
 */
export function captureProfile(regions, { use = 'wall', name = 'Captured Profile', materialOf = null } = {}) {
  const fills = regions.filter((r) => r?.boundary?.length >= 3);
  if (!fills.length) return null;
  const pts = fills.flatMap((r) => r.boundary);
  const x0 = Math.min(...pts.map((p) => p[0]));
  const x1 = Math.max(...pts.map((p) => p[0]));
  const y0 = Math.min(...pts.map((p) => p[1]));
  const y1 = Math.max(...pts.map((p) => p[1]));
  const ox = (x0 + x1) / 2;
  const oy = use === 'column' ? (y0 + y1) / 2 : y0;
  const m = (p) => [Math.round((p[0] - ox) * 10) / 10, Math.round((p[1] - oy) * 10) / 10];
  const ccw = (poly) => (signedArea(poly) < 0 ? poly.slice().reverse() : poly);
  const shapes = fills.map((r) => ({
    poly: ccw(r.boundary.map(m)),
    holes: (r.holes || []).filter((hh) => hh.length >= 3).map((hh) => hh.map(m)),
    materialId: materialOf?.(r) || PATTERN_MATERIAL[r.pattern] || 'mat-concrete',
  }));
  return { kind: 'profile', name, use, shapes, stretch: use === 'wall' ? Math.round((y1 - y0) / 2) : 0 };
}
