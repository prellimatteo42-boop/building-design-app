/**
 * Object library, as in Archicad's Object Settings: the built-in component
 * types (families.js) and the ones made in the project, browsed by category
 * and family. A built-in type that a project does not have yet is loaded
 * into it when it is first placed.
 */
import { CATEGORIES, libraryComponentTypes } from './catalog.js';
import { uniqueName } from './ops.js';
import { buildFamily } from './families.js';
import { MeshBuilder, Frame } from './mesh.js';

/** Built-in and project component types, the project's version winning: [{ type, builtIn, loaded }]. */
export function libraryItems(doc) {
  const system = doc.units?.system === 'imperial' ? 'imperial' : 'metric';
  const out = new Map();
  for (const t of libraryComponentTypes(system)) out.set(t.id, { type: t, builtIn: true, loaded: doc.has(t.id) });
  for (const t of doc.all('componentType')) out.set(t.id, { type: t, builtIn: out.has(t.id), loaded: true });
  return [...out.values()];
}

function matches(item, words) {
  const t = item.type;
  const label = CATEGORIES.find((c) => c.id === t.category)?.label || '';
  const hay = `${t.name} ${t.familyName || ''} ${t.family || ''} ${label}`.toLowerCase();
  return words.every((w) => hay.includes(w));
}

/**
 * The library as a tree: [{ id, label, families: [{ name, items }] }], in
 * category order, filtered by the words of a search.
 */
export function libraryTree(doc, query = '') {
  const words = String(query).toLowerCase().split(/\s+/).filter(Boolean);
  const items = libraryItems(doc).filter((i) => matches(i, words));
  const cats = [];
  for (const c of CATEGORIES) {
    const own = items.filter((i) => (i.type.category || 'furniture') === c.id);
    if (!own.length) continue;
    const fams = new Map();
    for (const i of own) {
      const key = i.type.familyName || 'Custom';
      if (!fams.has(key)) fams.set(key, []);
      fams.get(key).push(i);
    }
    cats.push({ id: c.id, label: c.label, families: [...fams].sort((a, b) => a[0].localeCompare(b[0])).map(([name, list]) => ({ name, items: list.sort((a, b) => a.type.name.localeCompare(b.type.name, undefined, { numeric: true })) })) });
  }
  return cats;
}

/**
 * The project type to place for a library item (inside a transaction):
 * loads a built-in type the project lacks, and with dimensions other than
 * the type's makes a new type of the same family with them.
 */
export function ensureLibraryType(doc, typeId, dims = {}) {
  let type = doc.get(typeId);
  if (!type) {
    const lib = libraryItems(doc).find((i) => i.type.id === typeId);
    if (!lib) return null;
    type = doc.add({ ...lib.type });
  }
  const want = { width: +dims.width || type.width, depth: +dims.depth || type.depth, height: +dims.height || type.height };
  if (want.width === type.width && want.depth === type.depth && want.height === type.height) return type;
  const same = doc.all('componentType').find((t) => t.family === type.family && t.category === type.category && t.width === want.width && t.depth === want.depth && t.height === want.height && t.familyName === type.familyName);
  if (same) return same;
  const { id: _id, ...rest } = type;
  const names = doc.all('componentType').map((t) => t.name);
  return doc.add({ ...rest, ...want, name: uniqueName(names, `${Math.round(want.width)} x ${Math.round(want.depth)} x ${Math.round(want.height)}`) });
}

/**
 * Preview geometry of a component type, in the type's own frame.
 * view 'plan': the plan symbol's loops; view '3d': triangles projected to an
 * axonometric from the front left, back faces dropped, farthest first,
 * each with a shaded rgba colour, or a picture (src) and its texture
 * coordinates (uv): { polys: [{ pts, color } | { pts, src, uv }], bounds }.
 */
export function libraryPreview(type, materialOf, view = '3d') {
  const b = view === '3d' ? new MeshBuilder() : null;
  const plan = buildFamily(type, new Frame([0, 0], 0, 0), b, materialOf);
  if (view !== '3d') {
    const pts = plan.loops.flatMap((l) => l.pts);
    return { loops: plan.loops, outline: plan.outline, fillColor: plan.fillColor, noFill: plan.noFill, bounds: boundsOf(pts.length ? pts : plan.outline) };
  }
  const cam = norm3([-0.55, -0.8, 0.62]);
  const right = norm3([-cam[1], cam[0], 0]);
  const up = norm3(cross([cam, right]));
  const light = norm3([-0.3, -0.6, 0.9]);
  const polys = [];
  for (let i = 0; i + 8 < b.pos.length; i += 9) {
    const n = [b.nrm[i] / 127, b.nrm[i + 1] / 127, b.nrm[i + 2] / 127];
    if (dot(n, cam) < -1e-3) continue;
    const pts = [];
    let depth = 0;
    for (let k = 0; k < 3; k++) {
      const p = [b.pos[i + k * 3], b.pos[i + k * 3 + 1], b.pos[i + k * 3 + 2]];
      pts.push([dot(p, right), dot(p, up)]);
      depth += dot(p, cam);
    }
    const c = (i / 9) * 12;
    const shade = 0.55 + 0.45 * Math.max(0, dot(n, light));
    polys.push({ pts, depth, color: [b.col[c] * shade, b.col[c + 1] * shade, b.col[c + 2] * shade, b.col[c + 3] / 255] });
  }
  // Triangles showing pictures: drawn with their picture (both faces, as a cut-out is seen from both).
  for (const [src, g] of b.tex || []) {
    for (let i = 0; i + 8 < g.pos.length; i += 9) {
      const pts = [];
      let depth = 0;
      for (let k = 0; k < 3; k++) {
        const p = [g.pos[i + k * 3], g.pos[i + k * 3 + 1], g.pos[i + k * 3 + 2]];
        pts.push([dot(p, right), dot(p, up)]);
        depth += dot(p, cam);
      }
      const j = (i / 9) * 6;
      polys.push({ pts, depth, src, uv: [[g.uv[j], g.uv[j + 1]], [g.uv[j + 2], g.uv[j + 3]], [g.uv[j + 4], g.uv[j + 5]]] });
    }
  }
  polys.sort((p, q) => p.depth - q.depth);
  return { polys, bounds: boundsOf(polys.flatMap((p) => p.pts)) };
}

function boundsOf(pts) {
  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  return xs.length ? { x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) } : { x0: 0, y0: 0, x1: 1, y1: 1 };
}

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + (a[2] || 0) * (b[2] || 0);
const norm3 = (v) => {
  const l = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / l, v[1] / l, v[2] / l];
};
const cross = ([a, b]) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
