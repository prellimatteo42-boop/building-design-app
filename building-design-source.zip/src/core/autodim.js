/**
 * Automatic exterior dimensioning, as in Archicad: for each side of the
 * building's bounding rectangle, up to three associative dimension chains
 * outside the facade, from the wall out: the openings of the facade walls
 * (with the corners), the walls that reach the facade (their faces), and the
 * overall length. Dimensions reference the walls and openings, so they
 * follow later edits.
 */
import { add, scale, dot, sub, norm, cross, len } from './geom.js';
import { wallAxis, openingSize } from './model.js';

const TOL = 60; // mm: how far a wall face may sit from the facade line

const SIDES = [
  { d: [1, 0], m: [0, 1] }, // north: measured along x
  { d: [1, 0], m: [0, -1] }, // south
  { d: [0, 1], m: [1, 0] }, // east: measured along y
  { d: [0, 1], m: [-1, 0] }, // west
];

/**
 * Dimension elements (not yet added) for walls on one level, drawn in view
 * viewId at a scale (paper offsets 8, 13 and 18 mm).
 */
export function exteriorDimensions(doc, walls, viewId, viewScale = 100) {
  const items = walls
    .filter((w) => w.kind === 'wall')
    .map((w) => {
      const ax = wallAxis(doc, w);
      const faces = [1, -1].map((side) => ({ side, a: add(ax.a, scale(ax.n, side * ax.half)), b: add(ax.b, scale(ax.n, side * ax.half)) }));
      return { w, ax, faces };
    })
    .filter((it) => it.ax.length > 1 && !it.ax.curve);
  if (!items.length) return [];
  const out = [];
  const gap = [8, 13, 18].map((mm) => mm * viewScale);
  for (const { d, m } of SIDES) {
    let F = -Infinity;
    let lo = Infinity;
    for (const it of items)
      for (const f of it.faces)
        for (const p of [f.a, f.b]) {
          F = Math.max(F, dot(p, m));
          lo = Math.min(lo, dot(p, d));
        }
    const lineAt = (off, s) => add(scale(m, F + off), scale(d, s));
    // Walls running out to the facade: their faces measured along d.
    const walls2 = [];
    for (const it of items) {
      if (Math.abs(dot(it.ax.dir, d)) > 0.05) continue;
      const reach = Math.max(dot(it.ax.a, m), dot(it.ax.b, m)) + it.ax.half;
      if (reach < F - 2 * it.ax.half - TOL) continue;
      for (const f of it.faces) walls2.push({ s: dot(f.a, d), id: it.w.id, ref: f.side > 0 ? 'left' : 'right' });
    }
    const uniq = (refs) => {
      const sorted = refs.sort((x, y) => x.s - y.s);
      return sorted.filter((r, i) => i === 0 || r.s - sorted[i - 1].s > 1);
    };
    const corners = uniq(walls2);
    if (corners.length < 2) continue;
    // Openings in the facade walls (walls along d whose outer face is on the facade).
    const opens = [];
    for (const it of items) {
      if (Math.abs(dot(it.ax.dir, m)) > 0.05) continue;
      const outer = Math.max(...it.faces.map((f) => dot(f.a, m)));
      if (outer < F - TOL) continue;
      for (const o of doc.all('door', 'window', 'opening')) {
        if (o.hostId !== it.w.id) continue;
        const { width } = openingSize(doc, o);
        const c = add(it.ax.a, scale(it.ax.dir, o.t));
        const s0 = dot(c, d) - (width / 2) * Math.sign(dot(it.ax.dir, d) || 1);
        const s1 = dot(c, d) + (width / 2) * Math.sign(dot(it.ax.dir, d) || 1);
        opens.push({ s: s0, id: o.id, ref: 'left' }, { s: s1, id: o.id, ref: 'right' });
      }
    }
    const chain = (refs, off) => ({
      kind: 'dimension',
      viewId,
      refs: refs.map((r) => ({ at: lineAt(off, r.s), ...(r.id ? { id: r.id, ref: r.ref } : {}) })),
      dir: d,
      line: lineAt(off, lo),
      auto: true,
    });
    const ends = [corners[0], corners.at(-1)];
    if (opens.length) out.push(chain(uniq([...ends, ...opens]), gap[0]));
    out.push(chain(corners, gap[1]));
    if (corners.length > 2) out.push(chain(ends, gap[2]));
  }
  return out;
}

/**
 * Interior dimensioning, as in Archicad: a chain along the segment a-b
 * through the faces of every wall it crosses (walls running along the
 * segment are skipped), drawn on the segment. Returns the dimension, or
 * null when it crosses fewer than two faces.
 */
export function interiorDimension(doc, walls, a, b, viewId) {
  const d = norm(sub(b, a));
  const L = len(sub(b, a));
  if (!(L > 1)) return null;
  const refs = [];
  for (const w of walls) {
    if (w.kind !== 'wall') continue;
    const ax = wallAxis(doc, w);
    if (ax.length < 1 || ax.curve || Math.abs(cross(ax.dir, d)) < 0.2) continue;
    for (const side of [1, -1]) {
      const p = add(ax.a, scale(ax.n, side * ax.half));
      // Where the face line meets the segment, if within both.
      const den = cross(d, ax.dir);
      const t = cross(sub(p, a), ax.dir) / den;
      const u = cross(sub(p, a), d) / den;
      if (t < 0 || t > L || u < -1 || u > ax.length + 1) continue;
      refs.push({ s: t, id: w.id, ref: side > 0 ? 'left' : 'right' });
    }
  }
  refs.sort((x, y) => x.s - y.s);
  const uniq = refs.filter((r, i) => i === 0 || r.s - refs[i - 1].s > 1);
  if (uniq.length < 2) return null;
  return { kind: 'dimension', viewId, dir: d, line: a, refs: uniq.map((r) => ({ at: add(a, scale(d, r.s)), id: r.id, ref: r.ref })) };
}
