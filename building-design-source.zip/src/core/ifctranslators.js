/**
 * IFC translators (Archicad's IFC Translators, reimplemented): named export
 * setups kept in the project, each with
 *   schema       'IFC4' (Reference View, tessellated geometry) or 'IFC2X3'
 *                (Coordination View 2.0, faceted B-rep geometry)
 *   unit         'mm' | 'm'
 *   filter       which elements go out: 'all' | 'loadBearing' (structural walls,
 *                columns, beams, slabs, footings) | 'architecture' (no MEP) | 'mep'
 *   spaces, properties, classifications   whether rooms, property sets and
 *                classification references are written
 *   entityMap    { kind: 'IfcEntity' } overriding the entity per element kind
 * and the IFC project tree (IFC Project Manager): project.ifcProject
 * { projectName, projectDescription, phase, siteName, siteDescription,
 *   buildingName, buildingDescription }, element.ifcAttrs { Name, Description,
 *   ObjectType }.
 */

export const IFC_SCHEMAS = [
  { value: 'IFC4', label: 'IFC4 (Reference View)' },
  { value: 'IFC2X3', label: 'IFC2x3 (Coordination View 2.0)' },
];
export const IFC_FILTERS = [
  { value: 'all', label: 'All elements' },
  { value: 'architecture', label: 'Architecture (no building services)' },
  { value: 'loadBearing', label: 'Load-bearing structure only' },
  { value: 'mep', label: 'Building services only' },
];

const MEP = new Set(['duct', 'pipe', 'cableTray', 'conduit', 'mepFitting', 'mepAccessory', 'mepFlex', 'airTerminal', 'wire']);
const STRUCTURE_KINDS = new Set(['column', 'beam', 'floor', 'footing', 'wallFooting', 'slabFoundation', 'brace', 'truss']);

export const TRANSLATOR_PRESETS = [
  { id: 'tr-general', name: 'General Translator', schema: 'IFC4', unit: 'mm', filter: 'all', spaces: true, properties: true, classifications: true },
  { id: 'tr-coordination', name: 'Coordination View 2.0 (IFC2x3)', schema: 'IFC2X3', unit: 'mm', filter: 'all', spaces: true, properties: true, classifications: true },
  { id: 'tr-structural', name: 'Structural Analysis', schema: 'IFC4', unit: 'm', filter: 'loadBearing', spaces: false, properties: true, classifications: true },
  { id: 'tr-mep', name: 'Building Services', schema: 'IFC4', unit: 'mm', filter: 'mep', spaces: false, properties: true, classifications: false },
];

/** The project's translators: its own, else the presets. */
export function ifcTranslators(doc) {
  const own = doc.get('project')?.ifcTranslators;
  return Array.isArray(own) && own.length ? own : TRANSLATOR_PRESETS;
}

/** A translator by id (or the first), with every option filled in. */
export function translatorFor(doc, idOrOptions = null) {
  const list = ifcTranslators(doc);
  const base = typeof idOrOptions === 'object' && idOrOptions ? idOrOptions : list.find((t) => t.id === idOrOptions) || list.find((t) => t.id === doc.get('project')?.ifcTranslatorId) || list[0];
  return { schema: 'IFC4', unit: 'mm', filter: 'all', spaces: true, properties: true, classifications: true, entityMap: {}, ...base };
}

/** Whether a translator writes an element. */
export function translatorIncludes(doc, t, el) {
  const f = t.filter || 'all';
  if (f === 'all') return true;
  const mep = MEP.has(el.kind) || (el.kind === 'component' && ['mechanical', 'electrical', 'plumbingEquipment', 'lighting', 'airTerminals', 'electricalFixtures', 'sprinklers'].includes(doc.get(el.typeId)?.category));
  if (f === 'mep') return mep;
  if (f === 'architecture') return !mep;
  if (f === 'loadBearing') return STRUCTURE_KINDS.has(el.kind) || (el.kind === 'wall' && (el.structural || doc.get(el.typeId)?.function === 'exterior' || doc.get(el.typeId)?.structural));
  return true;
}

// IFC2x3 ---------------------------------------------------------------------------------------------

/** IFC4 entities that do not exist in IFC2x3, and what they become there. */
const IFC2X3_NAME = {
  IFCFURNITURE: 'IFCFURNISHINGELEMENT',
  IFCSANITARYTERMINAL: 'IFCFLOWTERMINAL',
  IFCELECTRICAPPLIANCE: 'IFCFLOWTERMINAL',
  IFCLIGHTFIXTURE: 'IFCFLOWTERMINAL',
  IFCAIRTERMINAL: 'IFCFLOWTERMINAL',
  IFCFIRESUPPRESSIONTERMINAL: 'IFCFLOWTERMINAL',
  IFCOUTLET: 'IFCFLOWTERMINAL',
  IFCDUCTSEGMENT: 'IFCFLOWSEGMENT',
  IFCPIPESEGMENT: 'IFCFLOWSEGMENT',
  IFCCABLECARRIERSEGMENT: 'IFCFLOWSEGMENT',
  IFCUNITARYEQUIPMENT: 'IFCENERGYCONVERSIONDEVICE',
  IFCELECTRICDISTRIBUTIONBOARD: 'IFCFLOWCONTROLLER',
  IFCGEOGRAPHICELEMENT: 'IFCBUILDINGELEMENTPROXY',
};
/** IFC2x3 entities with one enumeration after Tag (predefined type, shape type or composition). */
const IFC2X3_ENUM = { IFCSLAB: 'p', IFCCOVERING: 'p', IFCROOF: 's', IFCSTAIR: 's', IFCRAMP: 's', IFCRAILING: 'p', IFCFOOTING: 'p', IFCBUILDINGELEMENTPROXY: 'c' };
/** IFC2x3 entities with exactly the eight common attributes. */
const IFC2X3_PLAIN = new Set(['IFCWALL', 'IFCWALLSTANDARDCASE', 'IFCCOLUMN', 'IFCBEAM', 'IFCCURTAINWALL', 'IFCFURNISHINGELEMENT', 'IFCFLOWTERMINAL', 'IFCFLOWSEGMENT', 'IFCENERGYCONVERSIONDEVICE', 'IFCFLOWCONTROLLER', 'IFCPLATE', 'IFCMEMBER']);

/**
 * One product line for the schema: entity (IFC4 name, upper case) and its predefined type, the common attributes
 * as STEP text (g GlobalId, n Name, d Description, o ObjectType, p placement, r representation, tag) and, for doors
 * and windows, the overall height and width (already formatted).
 */
export function productLine(schema, entity, predefined, { g, n, d = '$', o = '$', p, r, tag, height = null, width = null }) {
  const common = `'${g}',$,${n},${d},${o},${p},${r},${tag}`;
  if (schema !== 'IFC2X3') {
    if (entity === 'IFCDOOR' || entity === 'IFCWINDOW') return `${entity}(${common},${height},${width},.${predefined || entity.slice(3)}.,.NOTDEFINED.,$)`;
    return `${entity}(${common},.${predefined || 'NOTDEFINED'}.)`;
  }
  const E = IFC2X3_NAME[entity] || entity;
  if (E === 'IFCDOOR' || E === 'IFCWINDOW') return `${E}(${common},${height},${width})`;
  if (IFC2X3_ENUM[E] === 'c') return `${E}(${common},$)`;
  if (IFC2X3_ENUM[E]) {
    const v = E === 'IFCSTAIR' ? (predefined && predefined !== 'NOTDEFINED' ? predefined : 'STRAIGHT_RUN_STAIR') : E === 'IFCRAMP' ? 'STRAIGHT_RUN_RAMP' : predefined || 'NOTDEFINED';
    return `${E}(${common},.${v}.)`;
  }
  if (IFC2X3_PLAIN.has(E)) return `${E}(${common})`;
  return `IFCBUILDINGELEMENTPROXY(${common},$)`;
}
