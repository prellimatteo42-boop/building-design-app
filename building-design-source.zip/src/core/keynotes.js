/**
 * The keynote catalogue, as Archicad's Keynote Manager: folders and
 * keynotes in a tree, each with a key, a title and a description. Elements
 * and types carry a key (`keynote`), which keynote tags show; the catalogue
 * gives its title and description for legends and schedules.
 *
 *   project.keynotes = [{ key, title, description, parent: key | null, folder: bool }]
 *
 * Plain-text keynote files (one entry per line: key, text and parent key,
 * separated by tabs, as most BIM tools write them) read and write here.
 */

export function keynotes(doc) {
  return doc.get('project')?.keynotes || [];
}

/** Entries in tree order with their depth: [{ item, depth }]. */
export function keynoteTree(list) {
  const out = [];
  const seen = new Set();
  const walk = (parent, depth) => {
    for (const k of list.filter((x) => (x.parent || null) === parent).sort((a, b) => String(a.key).localeCompare(String(b.key), undefined, { numeric: true }))) {
      if (seen.has(k)) continue;
      seen.add(k);
      out.push({ item: k, depth });
      walk(k.key, depth + 1);
    }
  };
  walk(null, 0);
  for (const k of list) if (!seen.has(k)) out.push({ item: k, depth: 0 });
  return out;
}

/** The keynote entry (not a folder) with a key, or null. */
export function keynoteByKey(doc, key) {
  if (!key) return null;
  return keynotes(doc).find((k) => !k.folder && k.key === key) || null;
}

/** The keynote key of an element: its own, else its type's. */
export function keynoteKeyOf(doc, el) {
  return el?.keynote || doc.get(el?.typeId)?.keynote || '';
}

/**
 * Add, change or remove entries; returns the new list or throws. ops: [{ op: 'add' | 'modify' | 'delete', ...entry }]
 * with `new_key` to rename (children follow). Keys are unique among keynotes and among folders.
 */
export function editKeynotes(list, ops) {
  let out = list.map((k) => ({ ...k }));
  const same = (a, b) => !!a.folder === !!b.folder && a.key === b.key;
  for (const o of ops) {
    const folder = !!o.folder;
    if (o.op === 'add') {
      const key = String(o.key ?? '').trim();
      const title = String(o.title ?? '').trim();
      if (!key && !(folder && title)) throw new Error(folder ? 'A folder needs a key or a title' : 'A keynote needs a key');
      const k = key || title;
      if (out.some((x) => same(x, { key: k, folder }))) throw new Error(`${folder ? 'A folder' : 'A keynote'} with key ${k} exists`);
      if (o.parent && !out.some((x) => x.folder && x.key === o.parent)) throw new Error(`No folder ${o.parent}`);
      out.push({ key: k, title, description: String(o.description ?? ''), parent: o.parent || null, folder });
      continue;
    }
    const cur = out.find((x) => same(x, { key: o.key, folder }));
    if (!cur) throw new Error(`No ${folder ? 'folder' : 'keynote'} ${o.key}`);
    if (o.op === 'delete') {
      if (folder && out.some((x) => x.parent === cur.key)) throw new Error(`Folder ${cur.key} is not empty`);
      out = out.filter((x) => x !== cur);
      continue;
    }
    if (o.new_key && o.new_key !== cur.key) {
      if (out.some((x) => same(x, { key: o.new_key, folder }))) throw new Error(`Key ${o.new_key} is taken`);
      if (folder) for (const x of out) if (x.parent === cur.key) x.parent = o.new_key;
      cur.key = o.new_key;
    }
    if (o.title !== undefined) cur.title = String(o.title);
    if (o.description !== undefined) cur.description = String(o.description);
    if (o.parent !== undefined) {
      if (o.parent && !out.some((x) => x.folder && x.key === o.parent)) throw new Error(`No folder ${o.parent}`);
      if (folder && o.parent === cur.key) throw new Error('A folder cannot hold itself');
      cur.parent = o.parent || null;
    }
  }
  return out;
}

/**
 * Entries from a keynote text file. An entry whose key is some other
 * entry's parent is a folder; the text is its title.
 */
export function parseKeynoteFile(text) {
  const rows = [];
  for (const line of String(text).split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const [key, title = '', parent = ''] = line.split('\t').map((x) => x.trim());
    if (key) rows.push({ key, title, description: '', parent: parent || null });
  }
  const parents = new Set(rows.map((r) => r.parent).filter(Boolean));
  return rows.map((r) => ({ ...r, folder: parents.has(r.key) }));
}

/** The catalogue as a keynote text file. */
export function keynoteFileText(list) {
  return keynoteTree(list)
    .map(({ item }) => [item.key, item.title + (item.description ? ` - ${item.description}` : ''), item.parent || ''].join('\t').replace(/\t$/, ''))
    .join('\n');
}
