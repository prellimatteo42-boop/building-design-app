/**
 * Convert drafting into model elements, as in Archicad's Convert Selection
 * and Magic Wand on lines: lines become walls (as centre lines, or pairs
 * of parallel face lines as one wall of that thickness), and closed chains
 * of lines become slabs, zones or fills. Useful after importing a DXF.
 */
import { dist, sub, dot, norm, add, scale, signedArea, pointInPolygon } from './geom.js';
import { splinePoints } from './spline.js';
import { polylinePoints } from './polyline.js';
import { buildFloorPlan } from './floorplan.js';

/** Magic Wand Settings: how finely arcs and splines are cut into straight pieces (degrees of arc per piece). */
export const WAND = { arcStep: 10, splineSteps: 8 };

/** Segments of line-like elements: detail and model lines, arcs and splines (as short pieces). */
export function segmentsOf(els) {
  const out = [];
  for (const e of els) {
    if (!e) continue;
    if (e.a && e.b && ['detailLine', 'modelLine', 'roomSeparator', 'areaBoundary'].includes(e.kind)) out.push({ a: e.a, b: e.b, id: e.id });
    else if (e.kind === 'detailArc') {
      const a0 = e.a0 ?? 0;
      const a1 = e.a1 ?? Math.PI * 2;
      const n = Math.max(4, Math.ceil(((a1 - a0) * 180) / Math.PI / Math.max(1, WAND.arcStep)));
      for (let k = 0; k < n; k++) {
        const t0 = a0 + ((a1 - a0) * k) / n;
        const t1 = a0 + ((a1 - a0) * (k + 1)) / n;
        out.push({ a: [e.c[0] + Math.cos(t0) * e.r, e.c[1] + Math.sin(t0) * e.r], b: [e.c[0] + Math.cos(t1) * e.r, e.c[1] + Math.sin(t1) * e.r], id: e.id });
      }
    } else if (e.kind === 'polyline' && e.path?.length >= 2) {
      const c = polylinePoints(e, WAND.arcStep);
      for (let k = 0; k + 1 < c.length; k++) out.push({ a: c[k], b: c[k + 1], id: e.id });
    } else if (e.kind === 'spline' && e.path?.length >= 2) {
      const c = splinePoints(e.path, !!e.closed, WAND.splineSteps);
      for (let k = 0; k + 1 < c.length; k++) out.push({ a: c[k], b: c[k + 1], id: e.id });
    }
  }
  return out;
}

/**
 * Closed loops made by chaining segments end to end (ends closer than tol
 * meet). Returns { loops: [[p, ...]], open: segments left over }.
 */
export function chainLoops(segs, tol = 20) {
  const left = segs.map((s) => ({ ...s }));
  const loops = [];
  const open = [];
  while (left.length) {
    const first = left.shift();
    const chain = [first.a, first.b];
    const taken = [first];
    let grew = true;
    while (grew && dist(chain[0], chain.at(-1)) > tol) {
      grew = false;
      for (let i = 0; i < left.length; i++) {
        const s = left[i];
        const end = chain.at(-1);
        if (dist(s.a, end) <= tol) chain.push(s.b);
        else if (dist(s.b, end) <= tol) chain.push(s.a);
        else continue;
        taken.push(s);
        left.splice(i, 1);
        grew = true;
        break;
      }
    }
    if (chain.length >= 4 && dist(chain[0], chain.at(-1)) <= tol) {
      chain.pop();
      // Drop points on straight runs.
      const pts = chain.filter((p, i) => {
        const a = chain[(i - 1 + chain.length) % chain.length];
        const b = chain[(i + 1) % chain.length];
        const u = sub(p, a);
        const v = sub(b, p);
        return Math.abs(u[0] * v[1] - u[1] * v[0]) > 1e-6 * (Math.hypot(...u) * Math.hypot(...v) + 1);
      });
      if (pts.length >= 3) loops.push(signedArea(pts) < 0 ? pts.reverse() : pts);
    } else open.push(...taken.map(({ a, b, ...rest }) => ({ ...rest, a, b })));
  }
  return { loops, open };
}

/**
 * Pairs of parallel face lines as walls: two lines that run the same way,
 * between min and max apart and overlapping, make a wall along their middle
 * with that thickness. Returns { walls: [{ a, b, thickness }], rest: unpaired segments }.
 */
export function wallPairs(segs, { min = 50, max = 600 } = {}) {
  const used = new Set();
  const walls = [];
  const items = segs.map((s, i) => ({ ...s, i, len: dist(s.a, s.b), d: norm(sub(s.b, s.a)) })).sort((x, y) => y.len - x.len);
  for (const s of items) {
    if (used.has(s.i) || s.len < min) continue;
    let best = null;
    for (const o of items) {
      if (o === s || used.has(o.i)) continue;
      if (Math.abs(Math.abs(dot(s.d, o.d)) - 1) > 1e-3) continue;
      const n = [-s.d[1], s.d[0]];
      const gap = Math.abs(dot(sub(o.a, s.a), n));
      if (gap < min || gap > max) continue;
      // Overlap along s.
      const ta = dot(sub(o.a, s.a), s.d);
      const tb = dot(sub(o.b, s.a), s.d);
      const lo = Math.max(0, Math.min(ta, tb));
      const hi = Math.min(s.len, Math.max(ta, tb));
      if (hi - lo < Math.min(s.len, o.len) * 0.5) continue;
      if (!best || gap < best.gap) best = { o, gap, lo, hi, n, side: Math.sign(dot(sub(o.a, s.a), n)) };
    }
    if (!best) continue;
    used.add(s.i);
    used.add(best.o.i);
    const off = scale(best.n, (best.side * best.gap) / 2);
    walls.push({ a: add(add(s.a, scale(s.d, best.lo)), off), b: add(add(s.a, scale(s.d, best.hi)), off), thickness: Math.round(best.gap) });
  }
  return { walls, rest: items.filter((s) => !used.has(s.i)).map(({ a, b, id }) => ({ a, b, id })) };
}

/**
 * Make model elements from line segments (inside a transaction).
 * to: 'walls' (centre lines), 'wallPairs' (face lines), 'slabs', 'zones', 'fills'.
 * Returns { ids, skipped }.
 */
export function convertLines(doc, segs, to, { levelId, viewId, floorTypeId, tol = 20 } = {}) {
  const ids = [];
  if (to === 'walls' || to === 'wallPairs') {
    let walls;
    let rest = segs;
    if (to === 'wallPairs') ({ walls, rest } = wallPairs(segs));
    else walls = segs.map((s) => ({ a: s.a, b: s.b }));
    const out = buildFloorPlan(doc, { walls: walls.map((w) => ({ a: w.a, b: w.b, thickness: w.thickness })) }, { levelId, tol: to === 'wallPairs' ? undefined : Math.max(tol, 50) });
    return { ids: out.walls, skipped: [...out.skipped, ...(to === 'wallPairs' && rest.length ? [`${rest.length} line(s) without a parallel partner left as they are`] : [])] };
  }
  const { loops, open } = chainLoops(segs, tol);
  const skipped = open.length ? [`${open.length} line(s) do not close a shape`] : [];
  for (const loop of loops) {
    if (to === 'slabs') ids.push(doc.add({ kind: 'floor', typeId: floorTypeId || doc.all('floorType')[0]?.id, levelId, boundary: loop, offset: 0 }).id);
    else if (to === 'fills') ids.push(doc.add({ kind: 'region', viewId, boundary: loop, holes: [], pattern: 'diag', outline: true }).id);
    else if (to === 'zones') {
      for (let i = 0; i < loop.length; i++) ids.push(doc.add({ kind: 'roomSeparator', levelId, a: loop[i], b: loop[(i + 1) % loop.length] }).id);
      const at = interiorPoint(loop);
      const n = doc.all('room').reduce((m, r) => Math.max(m, parseInt(r.number, 10) || 0), 0) + 1;
      ids.push(doc.add({ kind: 'room', levelId, at, name: 'Room', number: String(n) }).id);
    }
  }
  return { ids, skipped };
}

/** A point inside a loop: its centroid, or else the middle of a diagonal that lies inside. */
function interiorPoint(loop) {
  const c = scale(loop.reduce((s, p) => add(s, p), [0, 0]), 1 / loop.length);
  if (pointInPolygon(c, loop)) return c;
  for (let i = 0; i < loop.length; i++)
    for (let j = i + 2; j < loop.length; j++) {
      const m = scale(add(loop[i], loop[j]), 0.5);
      if (pointInPolygon(m, loop)) return m;
    }
  return c;
}

/**
 * Walls from the cut fills of a drawing (the filled outlines a CAD program
 * draws for cut walls): opposite parallel edges of those shapes, min to max
 * apart with the fill between them, become walls of that thickness. An edge
 * can face several shorter ones (a long face against the pieces of the other
 * face between junctions); each stretch of it goes with its nearest partner.
 * Pieces on one axis are joined where the fill runs on between them.
 * polys: [[x, y], ...] closed outlines.
 */
export function wallsFromPolygons(polys, { min = 80, max = 600 } = {}) {
  const shapes = polys.filter((p) => p.length >= 3).map((poly) => {
    const xs = poly.map((q) => q[0]);
    const ys = poly.map((q) => q[1]);
    return { poly, x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) };
  });
  const solid = (p) => shapes.some((s) => p[0] >= s.x0 - 1 && p[0] <= s.x1 + 1 && p[1] >= s.y0 - 1 && p[1] <= s.y1 + 1 && pointInPolygon(p, s.poly));
  return wallsFromFaces(shapes.map((s) => s.poly), solid, { min, max });
}

/**
 * Walls from the outlines of solid shapes (loops of points) and a test
 * for whether a point is solid: the pairing behind wallsFromPolygons, for
 * shapes known some other way (a picture's dark cells, with their holes).
 */
export function wallsFromFaces(loops, solid, { min = 80, max = 600, angleTol = 2.5 } = {}) {
  // Faces count as parallel within angleTol degrees.
  const cosTol = Math.cos((angleTol * Math.PI) / 180);
  const edges = [];
  for (const poly of loops)
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i];
      const b = poly[(i + 1) % poly.length];
      const len = dist(a, b);
      if (len > 1) edges.push({ a, b, len, d: norm(sub(b, a)), cover: [] });
    }
  // Candidate pairs: parallel, min..max apart, overlapping, with fill between them.
  const cands = [];
  for (let i = 0; i < edges.length; i++) {
    const s = edges[i];
    if (s.len < 20) continue;
    const n = [-s.d[1], s.d[0]];
    for (let j = i + 1; j < edges.length; j++) {
      const o = edges[j];
      if (o.len < 20 || Math.abs(dot(s.d, o.d)) < cosTol) continue;
      const off = dot(sub(o.a, s.a), n);
      const gap = Math.abs(off);
      if (gap < min || gap > max) continue;
      const ta = dot(sub(o.a, s.a), s.d);
      const tb = dot(sub(o.b, s.a), s.d);
      const lo = Math.max(0, Math.min(ta, tb));
      const hi = Math.min(s.len, Math.max(ta, tb));
      if (hi - lo < 20) continue;
      // The fill runs between them all along: not two shapes facing each other across a space.
      const at = (f) => add(add(s.a, scale(s.d, lo + (hi - lo) * f)), scale(n, off / 2));
      if (!solid(at(0.5)) || (hi - lo > 2 * gap && (!solid(at(0.15)) || !solid(at(0.85))))) continue;
      cands.push({ s, o, lo, hi, gap, n, off });
    }
  }
  // Nearest partners first; a stretch already taken on either edge is not used again.
  cands.sort((x, y) => x.gap - y.gap);
  const pieces = [];
  const freeOf = (cover, lo, hi) => {
    let parts = [[lo, hi]];
    for (const [c0, c1] of cover) parts = parts.flatMap(([p0, p1]) => (c1 <= p0 || c0 >= p1 ? [[p0, p1]] : [[p0, c0], [c1, p1]].filter(([u, v]) => v - u > 20)));
    return parts;
  };
  for (const c of cands) {
    const toO = (t) => dot(sub(add(c.s.a, scale(c.s.d, t)), c.o.a), c.o.d);
    for (const [lo, hi] of freeOf(c.s.cover, c.lo, c.hi)) {
      const oLo = Math.min(toO(lo), toO(hi));
      const oHi = Math.max(toO(lo), toO(hi));
      for (const [p0, p1] of freeOf(c.o.cover, oLo, oHi)) {
        // Back onto s: the stretch free on both edges.
        const t0 = dot(sub(add(c.o.a, scale(c.o.d, p0)), c.s.a), c.s.d);
        const t1 = dot(sub(add(c.o.a, scale(c.o.d, p1)), c.s.a), c.s.d);
        const u0 = Math.max(lo, Math.min(t0, t1));
        const u1 = Math.min(hi, Math.max(t0, t1));
        if (u1 - u0 < 20) continue;
        // A short wall's two ends face each other across its length: that strip, shorter than it is
        // thick, lies inside the wall already found there and would be over twice as thick. No wall of its own.
        const shift0 = scale(c.n, c.off / 2);
        const mid = (f) => add(add(c.s.a, scale(c.s.d, u0 + (u1 - u0) * f)), shift0);
        if (u1 - u0 < c.gap && [0.25, 0.5, 0.75].every((f) => insidePiece(mid(f), pieces, c.gap * 0.5))) continue;
        c.s.cover.push([u0, u1]);
        c.o.cover.push([Math.min(toO(u0), toO(u1)), Math.max(toO(u0), toO(u1))]);
        const shift = scale(c.n, c.off / 2);
        pieces.push({ a: add(add(c.s.a, scale(c.s.d, u0)), shift), b: add(add(c.s.a, scale(c.s.d, u1)), shift), thickness: Math.round(c.gap) });
      }
    }
  }
  return joinCollinear(pieces, solid);
}

/** Whether p lies within the footprint of a wall piece thinner than maxT. */
function insidePiece(p, pieces, maxT = Infinity) {
  for (const w of pieces) {
    if (w.thickness >= maxT) continue;
    const L = dist(w.a, w.b);
    if (L < 1) continue;
    const d = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
    const t = dot(sub(p, w.a), d);
    if (t < 0 || t > L) continue;
    if (Math.abs(dot(sub(p, w.a), [-d[1], d[0]])) < w.thickness / 2 - 1) return true;
  }
  return false;
}

/** Join wall pieces on one axis with the same thickness where solid(point) holds all across the gap between them. */
export function joinCollinear(pieces, solid) {
  const groups = [];
  for (const w of pieces) {
    let d = norm(sub(w.b, w.a));
    // One sense per line: its larger component positive (a near-vertical line's tiny x must not decide).
    if (Math.abs(d[0]) >= Math.abs(d[1]) ? d[0] < 0 : d[1] < 0) d = [-d[0], -d[1]];
    const n = [-d[1], d[0]];
    const off = dot(w.a, n);
    let g = groups.find((x) => Math.abs(dot(x.d, d)) > 0.9999 && Math.abs(x.off - off) < 3 && Math.abs(x.t - w.thickness) < 3);
    if (!g) groups.push((g = { d, n, off, t: w.thickness, list: [] }));
    const ts = [dot(w.a, d), dot(w.b, d)].sort((p, q) => p - q);
    g.list.push(ts);
  }
  const out = [];
  for (const g of groups) {
    const at = (t) => add(scale(g.d, t), scale(g.n, g.off));
    g.list.sort((p, q) => p[0] - q[0]);
    let cur = null;
    for (const [t0, t1] of g.list) {
      if (cur && (t0 <= cur[1] + 1 || [0.25, 0.5, 0.75].every((f) => solid(at(cur[1] + (t0 - cur[1]) * f))))) cur[1] = Math.max(cur[1], t1);
      else {
        if (cur) out.push({ a: at(cur[0]), b: at(cur[1]), thickness: g.t });
        cur = [t0, t1];
      }
    }
    if (cur) out.push({ a: at(cur[0]), b: at(cur[1]), thickness: g.t });
  }
  return out;
}

/** The fill colours of a drawing's filled shapes, most used first: [{ color, count }], white left out. */
export function fillColors(paths) {
  const m = new Map();
  for (const p of paths) if (p.fill && p.closed && p.pts.length >= 3 && !/^#f[ef]f[ef]f[ef]$/i.test(p.fillColor)) m.set(p.fillColor, (m.get(p.fillColor) || 0) + 1);
  return [...m].map(([color, count]) => ({ color, count })).sort((a, b) => b.count - a.count);
}
