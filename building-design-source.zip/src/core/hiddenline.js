/**
 * Hidden-line projection of the model for elevations and sections, as
 * vector lines: the feature edges of the element meshes, projected onto the
 * view plane, keeping only the parts no surface hides. Visibility comes from
 * a depth buffer of all triangles rasterised on the CPU at a few
 * millimetres per pixel, so the result is plain data (testable, usable for
 * independent drawings and vector exports).
 *
 * View coordinates are those of elevation.js: u across the view (mm from
 * the frame origin along `right`), z the height, depth along `look`.
 */
import { viewFrame, sectionCuts } from './elevation.js';
import { explodeGraphics } from './explode.js';
import { categoryOf } from './catalog.js';

/** Clip a triangle (array of [u, z, d]) to d >= lo and d <= hi. */
function clipDepth(tri, lo, hi) {
  let poly = tri;
  for (const [sign, lim] of [
    [1, lo],
    [-1, hi],
  ]) {
    const out = [];
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i];
      const b = poly[(i + 1) % poly.length];
      const da = sign * (a[2] - lim);
      const db = sign * (b[2] - lim);
      if (da >= 0) out.push(a);
      if ((da >= 0) !== (db >= 0)) {
        const s = da / (da - db);
        out.push([a[0] + (b[0] - a[0]) * s, a[1] + (b[1] - a[1]) * s, a[2] + (b[2] - a[2]) * s]);
      }
    }
    poly = out;
    if (poly.length < 3) return [];
  }
  return poly;
}

/**
 * Visible projected edges: [{ a: [u, z], b: [u, z], outline }] (outline: against empty space). meshes: [mesh] with
 * pos (triangles) and edges (segments). frame: viewFrame(view). opts.res is
 * the depth-buffer cell in mm (made coarser for very large views).
 */
export function hiddenLineEdges(meshes, frame, { res = 20, maxCells = 4e6 } = {}) {
  const L = frame.look || [0, 1];
  const R = frame.right || [1, 0];
  const O = frame.origin || [0, 0];
  const ro = R[0] * O[0] + R[1] * O[1];
  const lo0 = L[0] * O[0] + L[1] * O[1];
  const near = frame.near ?? 0;
  const far = frame.far ?? 30000;
  // frame.project: any linear projection to [u, v, depth] (3D documents); else the elevation frame's.
  const proj = frame.project || ((x, y, z) => [R[0] * x + R[1] * y - ro, z, L[0] * x + L[1] * y - lo0]);
  const inU = (u) => frame.u0 == null || (u >= frame.u0 - 1 && u <= frame.u1 + 1);
  // Triangles in view space, clipped to the view depth.
  const tris = [];
  let u0 = Infinity;
  let u1 = -Infinity;
  let z0 = Infinity;
  let z1 = -Infinity;
  for (const m of meshes) {
    const P = m?.pos;
    if (!P) continue;
    for (let t = 0; t < P.length; t += 9) {
      const poly = clipDepth([proj(P[t], P[t + 1], P[t + 2]), proj(P[t + 3], P[t + 4], P[t + 5]), proj(P[t + 6], P[t + 7], P[t + 8])], near, far);
      if (!poly.length) continue;
      for (let i = 1; i + 1 < poly.length; i++) tris.push([poly[0], poly[i], poly[i + 1]]);
      for (const p of poly) {
        u0 = Math.min(u0, p[0]);
        u1 = Math.max(u1, p[0]);
        z0 = Math.min(z0, p[1]);
        z1 = Math.max(z1, p[1]);
      }
    }
  }
  if (!tris.length) return [];
  if (frame.u0 != null) (u0 = Math.max(u0, frame.u0)), (u1 = Math.min(u1, frame.u1));
  if (frame.z0 != null) (z0 = Math.max(z0, frame.z0)), (z1 = Math.min(z1, frame.z1));
  let cell = res;
  while (((u1 - u0) / cell + 3) * ((z1 - z0) / cell + 3) > maxCells) cell *= 1.25;
  const W = Math.ceil((u1 - u0) / cell) + 3;
  const H = Math.ceil((z1 - z0) / cell) + 3;
  const zb = new Float32Array(W * H).fill(Infinity);
  const px = (u) => (u - u0) / cell + 1;
  const pz = (z) => (z - z0) / cell + 1;
  // Depth buffer: nearest depth at each cell centre.
  for (const [a, b, c] of tris) {
    const ax = px(a[0]);
    const ay = pz(a[1]);
    const bx = px(b[0]);
    const by = pz(b[1]);
    const cx = px(c[0]);
    const cy = pz(c[1]);
    const area = (bx - ax) * (cy - ay) - (cx - ax) * (by - ay);
    if (Math.abs(area) < 1e-9) continue;
    const xa = Math.max(0, Math.floor(Math.min(ax, bx, cx)));
    const xb = Math.min(W - 1, Math.ceil(Math.max(ax, bx, cx)));
    const ya = Math.max(0, Math.floor(Math.min(ay, by, cy)));
    const yb = Math.min(H - 1, Math.ceil(Math.max(ay, by, cy)));
    for (let y = ya; y <= yb; y++) {
      const sy = y + 0.5;
      for (let x = xa; x <= xb; x++) {
        const sx = x + 0.5;
        const w0 = ((bx - sx) * (cy - sy) - (cx - sx) * (by - sy)) / area;
        const w1 = ((cx - sx) * (ay - sy) - (ax - sx) * (cy - sy)) / area;
        const w2 = 1 - w0 - w1;
        if (w0 < -1e-6 || w1 < -1e-6 || w2 < -1e-6) continue;
        const d = w0 * a[2] + w1 * b[2] + w2 * c[2];
        const i = y * W + x;
        if (d < zb[i]) zb[i] = d;
      }
    }
  }
  // A point is hidden when a surface lies clearly in front of it; the edge's own
  // surfaces (and those meeting it) are within the tolerance.
  const tol = Math.max(cell * 2.5, 40);
  // 0 visible, 1 visible on the outline (empty space next to it), 2 hidden.
  const look = (u, z, d) => {
    const x = Math.floor(px(u));
    const y = Math.floor(pz(z));
    // The farthest of the cell and its neighbours: an edge on an outline is not hidden by the cell next to it.
    let m = -Infinity;
    for (let j = -2; j <= 2; j++)
      for (let i = -2; i <= 2; i++) {
        const xx = x + i;
        const yy = y + j;
        if (xx < 0 || yy < 0 || xx >= W || yy >= H) {
          m = Infinity;
          continue;
        }
        const v = zb[yy * W + xx];
        if (v > m) m = v;
      }
    return m < d - tol ? 2 : m === Infinity ? 1 : 0;
  };
  const out = [];
  const seen = new Set();
  const key = (p) => `${Math.round(p[0])},${Math.round(p[1])}`;
  for (const m of meshes) {
    const E = m?.edges;
    if (!E) continue;
    for (let e = 0; e < E.length; e += 6) {
      let a = proj(E[e], E[e + 1], E[e + 2]);
      let b = proj(E[e + 3], E[e + 4], E[e + 5]);
      // Clip to the view depth.
      if ((a[2] < near && b[2] < near) || (a[2] > far && b[2] > far)) continue;
      for (const lim of [near, far]) {
        if ((a[2] - lim) * (b[2] - lim) < 0) {
          const s = (lim - a[2]) / (b[2] - a[2]);
          const p = [a[0] + (b[0] - a[0]) * s, a[1] + (b[1] - a[1]) * s, lim];
          if (lim === near ? a[2] < near : a[2] > far) a = p;
          else b = p;
        }
      }
      const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (len < 1) continue;
      const n = Math.max(1, Math.ceil(len / (cell * 0.5)));
      let start = null;
      let last = null;
      let samples = 0;
      let outline = 0;
      const flush = () => {
        const run = start && last ? Math.hypot(last[0] - start[0], last[1] - start[1]) : 0;
        // A hidden edge running up to the outline shows its last cell or two there: not a line.
        const stub = run < cell * 3 && outline === samples && run < len - 1;
        if (run >= 1 && !stub) {
          const k = [key(start), key(last)].sort().join('|');
          if (!seen.has(k)) (seen.add(k), out.push({ a: [start[0], start[1]], b: [last[0], last[1]], outline: outline * 2 > samples }));
        }
        start = null;
        last = null;
        samples = 0;
        outline = 0;
      };
      for (let i = 0; i <= n; i++) {
        const s = i / n;
        const p = [a[0] + (b[0] - a[0]) * s, a[1] + (b[1] - a[1]) * s, a[2] + (b[2] - a[2]) * s];
        const v = inU(p[0]) && (frame.z0 == null || (p[1] >= frame.z0 - 1 && p[1] <= frame.z1 + 1)) ? look(p[0], p[1], p[2]) : 2;
        if (v < 2) {
          if (!start) start = p;
          last = p;
          samples++;
          if (v === 1) outline++;
        } else flush();
      }
      flush();
    }
  }
  return out;
}

/** Elements drawn in an elevation or section view (not hidden in it), with their meshes. */
export function viewMeshes(doc, view, meshOf, kinds) {
  const hiddenCats = new Set(view.hiddenCats || []);
  const hiddenIds = new Set(view.hiddenIds || []);
  const out = [];
  for (const kind of kinds)
    for (const el of doc.all(kind)) {
      if (hiddenIds.has(el.id)) continue;
      const cat = categoryOf(el, doc);
      if (cat && hiddenCats.has(cat)) continue;
      const m = meshOf(el);
      if (m?.pos) out.push(m);
    }
  return out;
}

/**
 * The drawing of an elevation or section as 2D parts for a drafting view
 * ({ lines, fills, texts }, as explodeGraphics gives): the cut fills and
 * lines of a section, then the visible projected edges.
 */
export function independentDrawing(doc, view, meshOf, kinds, { res = 20 } = {}) {
  const frame = viewFrame(view);
  const cuts = sectionCuts(doc, frame, meshOf, view.detail, view.structureDisplay || 'entire');
  const parts = explodeGraphics(
    cuts.map((c) => c.g),
    +view.scale || 100,
  );
  // Section: what lies beyond the cut is drawn from just behind it.
  const f = frame.cut ? { ...frame, near: 1 } : frame;
  for (const l of hiddenLineEdges(viewMeshes(doc, view, meshOf, kinds), f, { res })) parts.lines.push({ a: l.a, b: l.b, style: l.outline ? 'medium' : 'thin' });
  return parts;
}

