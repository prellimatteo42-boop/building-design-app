/**
 * Physical Model Quality, as Archicad's check: geometric problems of the
 * physical model that make drawings, quantities or the analytical model
 * wrong. Each problem: { check, message, ids, at? }.
 *
 *   duplicate   two elements of one kind in the same place
 *   tiny        walls, columns, beams or slabs too small to be meant
 *   gap         wall ends that nearly meet another wall but are not joined
 *   short       walls that stop under the slab above them, or a beam under the slab it should carry
 *   unsupported walls and columns of upper levels with nothing under them
 *
 * opts: { gap (mm, the largest gap still reported, default 100), minSize (mm, default 50), shortBy (mm, default 300) }
 */
import { verticalExtent, levelElevation, wallAxis } from './model.js';
import { typeThickness } from './catalog.js';
import { pointInPolygon, area as polyArea } from './geom.js';

export const QUALITY_CHECKS = [
  { id: 'duplicate', label: 'Elements in the same place' },
  { id: 'tiny', label: 'Elements too small' },
  { id: 'gap', label: 'Walls that nearly meet but are not joined' },
  { id: 'short', label: 'Walls and beams that stop short of the slab above' },
  { id: 'unsupported', label: 'Walls and columns with nothing under them' },
];

const key = (v) => JSON.stringify(v, (k, x) => (typeof x === 'number' ? Math.round(x) : x));

function distToSegment(p, a, b) {
  const d = [b[0] - a[0], b[1] - a[1]];
  const l2 = d[0] * d[0] + d[1] * d[1] || 1;
  const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * d[0] + (p[1] - a[1]) * d[1]) / l2));
  return Math.hypot(a[0] + d[0] * t - p[0], a[1] + d[1] * t - p[1]);
}

export function physicalQuality(doc, scene, opts = {}) {
  const o = { gap: 100, minSize: 50, shortBy: 300, ...opts };
  const out = [];
  const add = (check, message, ids, at) => out.push({ check, message, ids, ...(at ? { at } : {}) });
  const walls = doc.all('wall').filter((w) => w.a && w.b);
  const floors = doc.all('floor').filter((f) => f.boundary?.length >= 3);
  const columns = doc.all('column').filter((c) => c.at);
  const beams = doc.all('beam').filter((b) => b.a && b.b);

  // Duplicates: same kind, level and geometry.
  const geo = (el) => {
    if (el.kind === 'wall' || el.kind === 'beam') return [el.levelId, [el.a, el.b].sort((x, y) => x[0] - y[0] || x[1] - y[1]), el.baseOffset ?? el.offset ?? 0];
    if (el.kind === 'column') return [el.levelId, el.at, el.baseOffset ?? 0];
    if (el.kind === 'floor' || el.kind === 'roof') return [el.levelId, el.offset ?? el.baseOffset ?? 0, [...el.boundary].sort((x, y) => x[0] - y[0] || x[1] - y[1])];
    if (el.kind === 'component') return [el.levelId, el.at, el.typeId];
    return null;
  };
  const seen = new Map();
  for (const el of [...walls, ...beams, ...columns, ...floors, ...doc.all('roof').filter((r) => r.boundary?.length), ...doc.all('component').filter((c) => c.at)]) {
    const g = geo(el);
    if (!g) continue;
    const k = `${el.kind}|${key(g)}`;
    if (seen.has(k)) add('duplicate', `Two ${el.kind}s in the same place`, [seen.get(k), el.id], el.at || el.a || el.boundary[0]);
    else seen.set(k, el.id);
  }

  // Too small.
  for (const w of walls) {
    const l = Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]);
    if (l < o.minSize) add('tiny', `A wall only ${Math.round(l)} mm long`, [w.id], w.a);
    else if ((typeThickness(doc.get(w.typeId)) || 1) < 10) add('tiny', 'A wall less than 10 mm thick', [w.id], w.a);
    const { base, top } = verticalExtent(doc, w);
    if (top - base < o.minSize) add('tiny', `A wall only ${Math.round(top - base)} mm high`, [w.id], w.a);
  }
  for (const b of beams) if (Math.hypot(b.b[0] - b.a[0], b.b[1] - b.a[1]) < o.minSize) add('tiny', 'A beam too short to be meant', [b.id], b.a);
  for (const c of columns) {
    const t = doc.get(c.typeId) || {};
    if ((+t.width || 450) < o.minSize / 2) add('tiny', 'A column too thin to be meant', [c.id], c.at);
  }
  for (const f of floors) if (Math.abs(polyArea(f.boundary)) < 0.01e6) add('tiny', 'A slab smaller than 0.01 m²', [f.id], f.boundary[0]);

  // Wall ends that nearly meet another wall on the same level without being joined.
  for (const w of walls) {
    for (const p of [w.a, w.b]) {
      let best = null;
      for (const v of walls) {
        if (v.id === w.id || v.levelId !== w.levelId) continue;
        // Joined: ends coincide, or the end lies on the other wall's axis.
        const dEnd = Math.min(Math.hypot(p[0] - v.a[0], p[1] - v.a[1]), Math.hypot(p[0] - v.b[0], p[1] - v.b[1]));
        const ax = wallAxis(doc, v);
        const dAxis = distToSegment(p, ax.a, ax.b);
        const half = ax.half;
        if (dEnd <= 2 || dAxis <= 2) {
          best = null;
          break;
        }
        // A gap: the end is near the other wall's end, or near its face without reaching its axis.
        const gap = Math.min(dEnd, Math.max(0, dAxis - half));
        if (gap > 0.5 && gap <= o.gap && (!best || gap < best.gap)) best = { v, gap };
      }
      if (best) add('gap', `A wall end ${Math.round(best.gap)} mm from another wall, not joined`, [w.id, best.v.id], p);
    }
  }

  // Walls and beams that stop short of the slab over them.
  for (const w of walls) {
    const { top } = verticalExtent(doc, w);
    const mid = [(w.a[0] + w.b[0]) / 2, (w.a[1] + w.b[1]) / 2];
    for (const f of floors) {
      const t = typeThickness(doc.get(f.typeId)) || 200;
      const fTop = levelElevation(doc, f.levelId) + (+f.offset || 0);
      const under = fTop - t - top;
      if (under > 1 && under <= o.shortBy && pointInPolygon(mid, f.boundary)) {
        add('short', `A wall stops ${Math.round(under)} mm under the slab above`, [w.id, f.id], mid);
        break;
      }
    }
  }
  for (const b of beams) {
    const bt = levelElevation(doc, b.levelId) + (+b.offset || 0);
    const mid = [(b.a[0] + b.b[0]) / 2, (b.a[1] + b.b[1]) / 2];
    for (const f of floors) {
      const t = typeThickness(doc.get(f.typeId)) || 200;
      const fBottom = levelElevation(doc, f.levelId) + (+f.offset || 0) - t;
      const under = fBottom - bt;
      if (under > 1 && under <= o.shortBy && pointInPolygon(mid, f.boundary)) {
        add('short', `A beam stops ${Math.round(under)} mm under the slab it should carry`, [b.id, f.id], mid);
        break;
      }
    }
  }

  // Unsupported: walls and columns above the lowest level with no wall, column, beam or slab under their base.
  const lowest = Math.min(...doc.levels().map((l) => l.elevation ?? 0));
  const supported = (pts, base, selfId) => {
    for (const p of pts) {
      let ok = false;
      for (const f of floors) {
        const fTop = levelElevation(doc, f.levelId) + (+f.offset || 0);
        if (Math.abs(fTop - base) <= 50 && pointInPolygon(p, f.boundary)) ok = true;
      }
      for (const v of walls) {
        if (ok || v.id === selfId) break;
        const { top } = verticalExtent(doc, v);
        const ax = wallAxis(doc, v);
        if (Math.abs(top - base) <= 50 && distToSegment(p, ax.a, ax.b) <= ax.half + 1) ok = true;
      }
      for (const c of columns) {
        if (ok || c.id === selfId) break;
        const { top } = verticalExtent(doc, c);
        const t = doc.get(c.typeId) || {};
        if (Math.abs(top - base) <= 50 && Math.hypot(p[0] - c.at[0], p[1] - c.at[1]) <= Math.max(+t.width || 450, +t.depth || 0) / 2 + 1) ok = true;
      }
      for (const b of beams) {
        if (ok) break;
        const bt = levelElevation(doc, b.levelId) + (+b.offset || 0);
        if (Math.abs(bt - base) <= 50 && distToSegment(p, b.a, b.b) <= (+doc.get(b.typeId)?.width || 300) / 2 + 1) ok = true;
      }
      if (!ok) return false;
    }
    return true;
  };
  for (const w of walls) {
    const { base } = verticalExtent(doc, w);
    if (base <= lowest + 1) continue;
    const pts = [w.a, [(w.a[0] + w.b[0]) / 2, (w.a[1] + w.b[1]) / 2], w.b];
    if (!supported(pts, base, w.id)) add('unsupported', 'A wall with nothing under part of its base', [w.id], pts[1]);
  }
  for (const c of columns) {
    const { base } = verticalExtent(doc, c);
    if (base <= lowest + 1) continue;
    if (!supported([c.at], base, c.id)) add('unsupported', 'A column with nothing under it', [c.id], c.at);
  }
  return out;
}
