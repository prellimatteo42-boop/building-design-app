/**
 * Find & Replace Library Parts and their parameters (Options > Library Parts,
 * Library Part Parameters): placed objects, doors and windows move to another
 * type, keeping every parameter the new type also has; or the instances whose
 * parameter has a value are found and set to another.
 */
export const PLACED_KINDS = ['component', 'door', 'window'];

const sameValue = (a, b) => (typeof a === 'number' || typeof b === 'number' ? Math.abs(+a - +b) < 1e-6 : String(a) === String(b));

/** Types with placed instances: [{ type, count }], by name. */
export function typesInUse(doc) {
  const n = new Map();
  for (const k of PLACED_KINDS) for (const el of doc.all(k)) n.set(el.typeId, (n.get(el.typeId) || 0) + 1);
  return [...n].map(([id, count]) => ({ type: doc.get(id), count })).filter((x) => x.type).sort((a, b) => a.type.name.localeCompare(b.type.name));
}

/** The GDL parameters of a type: [{ name, label, value, kind }]. */
export const typeParams = (type) => type?.gdl?.params || [];

/** Move instances to another type (inside a transaction). Returns { moved, kept, dropped } (parameter values). */
export function replaceParts(doc, ids, toTypeId, { transfer = true } = {}) {
  const to = doc.get(toTypeId);
  const names = new Set(typeParams(to).map((p) => p.name));
  let moved = 0;
  let kept = 0;
  let dropped = 0;
  for (const id of ids) {
    const el = doc.get(id);
    if (!el || el.typeId === toTypeId) continue;
    const values = {};
    for (const [k, v] of Object.entries(el.gdlValues || {})) {
      if (transfer && names.has(k)) {
        values[k] = v;
        kept++;
      } else dropped++;
    }
    doc.update(id, { typeId: toTypeId, gdlValues: Object.keys(values).length ? values : undefined });
    moved++;
  }
  return { moved, kept, dropped };
}

/** The value of a parameter on an instance. */
export function paramValueOf(doc, el, name) {
  const p = typeParams(doc.get(el.typeId)).find((x) => x.name === name);
  return p ? (el.gdlValues?.[name] ?? p.value) : undefined;
}

/** Instances of a type whose parameter equals `value` (any value when it is empty). */
export function findByParam(doc, typeId, name, value = '') {
  const out = [];
  for (const k of PLACED_KINDS)
    for (const el of doc.all(k)) {
      if (el.typeId !== typeId) continue;
      const v = paramValueOf(doc, el, name);
      if (v !== undefined && (value === '' || sameValue(v, value))) out.push(el.id);
    }
  return out;
}

/** Set a parameter on instances (inside a transaction), in the parameter's own kind of value. */
export function setParam(doc, ids, name, value) {
  for (const id of ids) {
    const el = doc.get(id);
    const p = typeParams(doc.get(el.typeId)).find((x) => x.name === name);
    if (!p) continue;
    const v = p.kind === 'boolean' ? value === true || value === 'true' || value === '1' : p.kind === 'string' || p.kind === 'material' ? String(value) : +value;
    doc.update(id, { gdlValues: { ...(el.gdlValues || {}), [name]: v } });
  }
}
