/**
 * Splines, as in Archicad's Spline tool: a smooth curve through the points
 * clicked (a centripetal Catmull-Rom curve, which neither loops nor
 * overshoots between close points), open or closed.
 *
 *   spline { kind: 'spline', viewId, path: [[x, y], ...], closed, style }
 */
import { dist } from './geom.js';

/** Points along the curve through `pts`, `segs` per span. */
export function splinePoints(pts, closed = false, segs = 16) {
  const n = pts.length;
  if (n < 3) return closed && n === 2 ? [...pts, pts[0]] : pts.map((p) => [...p]);
  const at = (i) => (closed ? pts[((i % n) + n) % n] : pts[Math.max(0, Math.min(n - 1, i))]);
  const out = [];
  const spans = closed ? n : n - 1;
  for (let i = 0; i < spans; i++) {
    const p0 = at(i - 1);
    const p1 = at(i);
    const p2 = at(i + 1);
    const p3 = at(i + 2);
    // Centripetal parameterisation (alpha 0.5).
    const t01 = Math.max(1e-6, Math.sqrt(dist(p0, p1)));
    const t12 = Math.max(1e-6, Math.sqrt(dist(p1, p2)));
    const t23 = Math.max(1e-6, Math.sqrt(dist(p2, p3)));
    const m1 = [0, 1].map((k) => (p2[k] - p1[k] + t12 * ((p1[k] - p0[k]) / t01 - (p2[k] - p0[k]) / (t01 + t12))));
    const m2 = [0, 1].map((k) => (p2[k] - p1[k] + t12 * ((p3[k] - p2[k]) / t23 - (p3[k] - p1[k]) / (t12 + t23))));
    for (let s = 0; s < segs; s++) {
      const t = s / segs;
      const t2 = t * t;
      const t3 = t2 * t;
      const h00 = 2 * t3 - 3 * t2 + 1;
      const h10 = t3 - 2 * t2 + t;
      const h01 = -2 * t3 + 3 * t2;
      const h11 = t3 - t2;
      out.push([0, 1].map((k) => h00 * p1[k] + h10 * m1[k] + h01 * p2[k] + h11 * m2[k]));
    }
  }
  out.push([...(closed ? pts[0] : pts[n - 1])]);
  return out;
}

/** Length of a spline. */
export function splineLength(pts, closed = false) {
  const c = splinePoints(pts, closed);
  let s = 0;
  for (let i = 0; i + 1 < c.length; i++) s += dist(c[i], c[i + 1]);
  return s;
}
