/**
 * Railings placed on other elements, as in Archicad's railing tool:
 *   - on a stair: one along each side of every flight, climbing with it
 *     (pathZ), and along the outer edges of its landings;
 *   - on slab edges: one per edge that no wall runs along.
 * They are ordinary railings afterwards (path, pathZ, offset).
 */
import { stairFlights } from './stairs.js';
import { levelElevation, wallAxis } from './model.js';
import { add, sub, scale, dot, len, norm, signedArea } from './geom.js';

const INSET = 50; // mm in from the edge

/** Railings (not yet added) on the sides of a stair. */
export function railingsOnStair(doc, stair, typeId, { sides = 'both' } = {}) {
  const fl = stairFlights(doc, stair);
  if (fl.shape === 'spiral' || !fl.flights?.length) return [];
  const z0 = levelElevation(doc, stair.levelId);
  const { riserHeight: rh, tread: td, width: W } = fl;
  const out = [];
  const which = sides === 'both' ? [1, -1] : sides === 'left' ? [1] : [-1];
  for (const f of fl.flights) {
    for (const s of which) {
      const off = scale(f.side, s * (W / 2 - INSET));
      const a = add(f.start, off);
      const b = add(add(f.start, scale(f.dir, f.run)), off);
      // On the nosings: from the first tread to the last.
      out.push({ kind: 'railing', typeId, levelId: stair.levelId, offset: 0, path: [a, b], pathZ: [f.z0 - z0 + rh, f.z0 - z0 + f.risers * rh], stairId: stair.id });
    }
  }
  for (const l of fl.landings) {
    // A landing's edges, less the ones the flights arrive and leave by.
    const poly = l.poly;
    for (let i = 0; i < poly.length; i++) {
      const p = poly[i];
      const q = poly[(i + 1) % poly.length];
      const m = scale(add(p, q), 0.5);
      const touchesFlight = fl.flights.some((f) => {
        const ends = [f.start, add(f.start, scale(f.dir, f.run + td))];
        return ends.some((e) => len(sub(e, m)) < W * 0.3);
      });
      if (touchesFlight) continue;
      out.push({ kind: 'railing', typeId, levelId: stair.levelId, offset: l.z - z0, path: [p, q], stairId: stair.id });
    }
  }
  return out;
}

/** Railings (not yet added) on the edges of a slab that no wall runs along. */
export function railingsOnSlabEdges(doc, slab, typeId) {
  const b = slab.boundary;
  if (!b || b.length < 3) return [];
  const ccw = signedArea(b) >= 0;
  const walls = doc.all('wall').map((w) => ({ w, ax: wallAxis(doc, w) }));
  const out = [];
  for (let i = 0; i < b.length; i++) {
    const p = b[i];
    const q = b[(i + 1) % b.length];
    const d = norm(sub(q, p));
    if (len(sub(q, p)) < 100) continue;
    const m = scale(add(p, q), 0.5);
    // A wall along the edge: the edge's middle lies within its thickness (plus a margin), parallel to it.
    const walled = walls.some(({ ax }) => {
      if (ax.curve || Math.abs(dot(ax.dir, d)) < 0.98) return false;
      const u = dot(sub(m, ax.a), ax.dir);
      const v = Math.abs(dot(sub(m, ax.a), ax.n));
      return u > 0 && u < ax.length && v <= ax.half + 60;
    });
    if (walled) continue;
    // Inward normal: left of a counterclockwise boundary.
    const n = ccw ? [-d[1], d[0]] : [d[1], -d[0]];
    out.push({ kind: 'railing', typeId, levelId: slab.levelId, offset: +slab.offset || 0, path: [add(p, scale(n, INSET)), add(q, scale(n, INSET))] });
  }
  return out;
}
