/**
 * Property values through spreadsheets, as Archicad's Export Property Values
 * and Import Property Values into Elements: a table with one row per element
 * (its ID, IFC GlobalId, kind, type and the editable values: Name, Mark or
 * Number, Comments and every custom property available to it, by
 * "Group: Name") goes out to Excel; edited, it comes back and the values are
 * set on the elements, found by ID or GlobalId.
 */
import { KIND_LABEL, categoryOf } from './catalog.js';
import { projectParams, paramsForElement, coerceParamValue, storedValue } from './params.js';
import { ifcGuidFor } from './issues.js';
import { isView } from './doc.js';

const FIXED = ['Element ID', 'GlobalId', 'Kind', 'Type'];
const BUILTIN = { Name: 'name', Mark: 'mark', Number: 'number', Comments: 'comments' };
const colOf = (p) => `${p.group || 'Identity Data'}: ${p.name}`;

/** Elements that can carry property values (optionally only some kinds). */
function propertyElements(doc, kinds = null) {
  const out = [];
  for (const el of doc.items.values()) {
    if (isView(el) || el.kind.endsWith('Type') || el.viewId) continue;
    if (kinds && !kinds.includes(el.kind)) continue;
    if (!categoryOf(el, doc) && el.kind !== 'room') continue;
    out.push(el);
  }
  return out;
}

/** The table: rows of cells, the first the header. Values in stored units (lengths mm, areas m², volumes m³). */
export function propertyTable(doc, { kinds = null } = {}) {
  const els = propertyElements(doc, kinds);
  const params = projectParams(doc).filter((p) => p.type !== 'expression' && els.some((el) => paramsForElement(doc, el).includes(p)));
  const header = [...FIXED, ...Object.keys(BUILTIN), ...params.map(colOf)];
  const rows = [header];
  for (const el of els) {
    const mine = new Set(paramsForElement(doc, el).map((p) => p.id));
    const val = (p) => {
      if (!mine.has(p.id)) return '';
      const v = storedValue(el, p);
      if (v === null || v === undefined) return '';
      if (Array.isArray(v)) return v.join('; ');
      if (typeof v === 'boolean') return v ? 'Yes' : 'No';
      return p.type === 'area' ? +v / 1e6 : p.type === 'volume' ? +v / 1e9 : v;
    };
    rows.push([el.id, el.ifcGuid || ifcGuidFor(el.id), KIND_LABEL[el.kind] || el.kind, doc.get(el.typeId)?.name || '', ...Object.values(BUILTIN).map((k) => el[k] ?? ''), ...params.map(val)]);
  }
  return rows;
}

/**
 * Set the values of a table on the elements (inside a transaction). Rows are arrays with the header first; an
 * empty cell leaves a value as it is. Returns { updated, unknownRows, unknownColumns, errors: [{ row, column, message }] }.
 */
export function applyPropertyTable(doc, rows) {
  const out = { updated: 0, unknownRows: 0, unknownColumns: [], errors: [] };
  if (!rows?.length) return out;
  const header = rows[0].map((h) => String(h ?? '').trim());
  const idCol = header.findIndex((h) => /^(element )?id$/i.test(h));
  const guidCol = header.findIndex((h) => /^globalid$/i.test(h));
  const byGuid = new Map();
  for (const el of doc.items.values()) byGuid.set(el.ifcGuid || ifcGuidFor(el.id), el);
  const params = projectParams(doc);
  // Columns from a schedule carry their unit, "Height (m)": values come back to stored units.
  const UNIT = { m: 1000, ft: 304.8, 'm²': 1, 'ft²': 0.09290304, 'm³': 1, 'ft³': 0.0283168466 };
  const scaleOf = header.map((h) => UNIT[/\(([^)]+)\)$/.exec(h)?.[1]] ?? 1);
  const cols = header.map((h0, i) => {
    const h = h0.replace(/\s*\((m|ft|m²|ft²|m³|ft³)\)$/, '');
    if (i === idCol || i === guidCol || FIXED.includes(h) || !h) return null;
    if (BUILTIN[h]) return { builtin: BUILTIN[h] };
    const m = /^(.*?):\s*(.+)$/.exec(h);
    const p = m ? params.find((x) => (x.group || 'Identity Data').toLowerCase() === m[1].trim().toLowerCase() && x.name.toLowerCase() === m[2].trim().toLowerCase()) : params.filter((x) => x.name.toLowerCase() === h.toLowerCase()).length === 1 ? params.find((x) => x.name.toLowerCase() === h.toLowerCase()) : null;
    if (!p) out.unknownColumns.push(h);
    return p ? { param: p } : null;
  });
  for (let r = 1; r < rows.length; r++) {
    const row = rows[r];
    if (!row?.some((c) => c !== '' && c !== null && c !== undefined)) continue;
    // A schedule row of several elements lists their ids with ";": the value goes to each.
    const ids = idCol >= 0 ? String(row[idCol] ?? '').split(';').map((x) => x.trim()).filter(Boolean) : [];
    const targets = ids.length > 1 ? ids.map((x) => doc.get(x)).filter(Boolean) : [(idCol >= 0 && doc.get(String(row[idCol]))) || (guidCol >= 0 && byGuid.get(String(row[guidCol]))) || null];
    if (!targets[0]) {
      out.unknownRows++;
      continue;
    }
    for (const el of targets) applyRow(el, row, r);
  }
  return out;

  function applyRow(el, row, r) {
    const patch = {};
    let params2 = null;
    cols.forEach((c, i) => {
      const raw = row[i];
      if (!c || raw === '' || raw === null || raw === undefined) return;
      if (c.builtin) {
        if (String(el[c.builtin] ?? '') !== String(raw)) patch[c.builtin] = String(raw);
        return;
      }
      const p = c.param;
      if (!paramsForElement(doc, el).includes(p)) return out.errors.push({ row: r + 1, column: header[i], message: 'not available for this element' });
      const scaled = typeof raw === 'number' && scaleOf[i] !== 1 && ['length', 'area', 'volume'].includes(p.type) ? raw * scaleOf[i] : raw;
      let v = coerceParamValue(p, scaled);
      if (v instanceof Error) return out.errors.push({ row: r + 1, column: header[i], message: v.message });
      if (p.type === 'area') v *= 1e6;
      if (p.type === 'volume') v *= 1e9;
      if (JSON.stringify(storedValue(el, p)) === JSON.stringify(v)) return;
      params2 = { ...(params2 || el.params || {}), [p.id]: v };
    });
    if (params2) patch.params = params2;
    if (Object.keys(patch).length) {
      doc.update(el.id, patch);
      out.updated++;
    }
  }
}

/** CSV text to rows (quotes, commas or semicolons). */
export function parseCSV(text) {
  const sep = (text.split('\n')[0].match(/;/g) || []).length > (text.split('\n')[0].match(/,/g) || []).length ? ';' : ',';
  const rows = [];
  let row = [];
  let cell = '';
  let q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      if (ch === '"' && text[i + 1] === '"') (cell += '"'), i++;
      else if (ch === '"') q = false;
      else cell += ch;
    } else if (ch === '"') q = true;
    else if (ch === sep) row.push(cell), (cell = '');
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
    } else cell += ch;
  }
  if (cell || row.length) row.push(cell), rows.push(row);
  return rows.map((r) => r.map((c) => (c !== '' && /^-?\d+(\.\d+)?$/.test(c.trim()) ? +c : c)));
}
