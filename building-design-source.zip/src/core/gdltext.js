/**
 * Text editing for GDL scripts, as Archicad's GDL editor: comment and
 * uncomment the selected lines (GDL comments start with !), go to a line,
 * find the next occurrence (of a word or of the selection) and replace it.
 * Pure functions on (text, selection) so the editor and tests share them.
 */

/** Start and end offsets of the whole lines a selection touches. */
function lineSpan(text, start, end) {
  const a = text.lastIndexOf('\n', Math.max(0, start - 1)) + 1;
  let b = text.indexOf('\n', end > start && text[end - 1] === '\n' ? end - 1 : end);
  if (b < 0) b = text.length;
  return [a, b];
}

/** Comment the selected lines: { text, start, end } with the new selection over them. */
export function commentLines(text, start, end) {
  const [a, b] = lineSpan(text, start, end);
  const block = text.slice(a, b).split('\n').map((l) => (l.trim() ? `!${l}` : l)).join('\n');
  return { text: text.slice(0, a) + block + text.slice(b), start: a, end: a + block.length };
}

export function uncommentLines(text, start, end) {
  const [a, b] = lineSpan(text, start, end);
  const block = text.slice(a, b).split('\n').map((l) => l.replace(/^(\s*)!/, '$1')).join('\n');
  return { text: text.slice(0, a) + block + text.slice(b), start: a, end: a + block.length };
}

/** Offsets of line n (1-based): [start, end], clamped to the text. */
export function lineRange(text, n) {
  const lines = text.split('\n');
  const k = Math.max(1, Math.min(lines.length, Math.round(n) || 1));
  let off = 0;
  for (let i = 0; i < k - 1; i++) off += lines[i].length + 1;
  return [off, off + lines[k - 1].length];
}

/** The next occurrence of query after `from` (case-insensitive, wrapping): [start, end] or null. */
export function findNext(text, query, from = 0) {
  if (!query) return null;
  const t = text.toLowerCase();
  const q = query.toLowerCase();
  let i = t.indexOf(q, from);
  if (i < 0) i = t.indexOf(q);
  return i < 0 ? null : [i, i + q.length];
}

/** Replace the occurrence at the selection (if it matches) or the next one: { text, start, end } or null. */
export function replaceNext(text, query, replacement, start, end) {
  const here = text.slice(start, end).toLowerCase() === String(query).toLowerCase() ? [start, end] : findNext(text, query, end);
  if (!here) return null;
  const out = text.slice(0, here[0]) + replacement + text.slice(here[1]);
  return { text: out, start: here[0], end: here[0] + replacement.length };
}

/** A GUID for a library part, in Archicad's upper-case form. */
export function partGuid(seed = Math.random) {
  const hex = (n) => Array.from({ length: n }, () => Math.floor(seed() * 16).toString(16)).join('').toUpperCase();
  return `${hex(8)}-${hex(4)}-4${hex(3)}-${'89AB'[Math.floor(seed() * 4)]}${hex(3)}-${hex(12)}`;
}
