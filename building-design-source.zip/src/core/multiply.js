/**
 * Multiply (Archicad's Edit > Move > Multiply): copies of the selection
 * along one vector or a matrix of two, with an elevation step between
 * copies, by Increment (the vector is the distance between copies) or
 * Distribute (the vector is the whole span, the copies spread over it) or
 * Spread (copies at a set spacing, as many as fit along the vector), and
 * Mirror (each copy the mirror image of the one before, across an axis that
 * moves on by the selection's distance from it: a mirrored row).
 */
import { copyElements, translation, mirrorAcross } from './ops.js';
import { scale, add, sub, len } from './geom.js';
import { HEIGHT_FIELDS } from './editextras.js';

/** Raise copies by z (their height fields). */
function raise(doc, copies, z) {
  if (!z) return;
  for (const id of copies) {
    const el = doc.get(id);
    if (!el?.levelId || el.hostId) continue;
    const patch = {};
    for (const f of HEIGHT_FIELDS[el.kind] || []) patch[f] = Math.round((+el[f] || 0) + z);
    if (Object.keys(patch).length) doc.update(id, patch);
  }
}

/** Number of items and step for Spread: as many as fit at the spacing (including the original). */
export function spreadStep(d, spacing) {
  const l = len(d);
  if (!(spacing > 0) || l < 1e-9) return { n: 1, step: [0, 0] };
  return { n: Math.floor(l / spacing + 1e-6) + 1, step: scale(d, spacing / l) };
}

/** Plan centre of the elements (middle of their points' box). */
export function selectionCentre(doc, ids) {
  const pts = [];
  for (const id of ids) {
    const el = doc.get(id);
    if (!el) continue;
    if (el.at) pts.push(el.at);
    if (el.a) pts.push(el.a);
    if (el.b) pts.push(el.b);
    for (const k of ['boundary', 'points', 'path']) if (Array.isArray(el[k])) pts.push(...el[k].filter((p) => Array.isArray(p)));
  }
  if (!pts.length) return null;
  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  return [(Math.min(...xs) + Math.max(...xs)) / 2, (Math.min(...ys) + Math.max(...ys)) / 2];
}

/**
 * Mirror multiply: n items (including the original) across the axis a-b and
 * on in the same direction, alternately mirrored and repeated. Returns the new ids.
 */
export function multiplyMirror(doc, ids, a, b, { n = 2, dz = 0 } = {}) {
  const c = selectionCentre(doc, ids);
  const d = sub(b, a);
  const l = len(d);
  if (!c || l < 1e-9) return [];
  let nrm = [-d[1] / l, d[0] / l];
  let dist = (c[0] - a[0]) * nrm[0] + (c[1] - a[1]) * nrm[1];
  // The normal points from the selection across the axis.
  if (dist > 0) {
    nrm = [-nrm[0], -nrm[1]];
    dist = -dist;
  }
  const D = Math.abs(dist);
  const out = [];
  for (let k = 1; k < n; k++) {
    // Odd copies: mirrored across the axis moved on by (k - 1) D; even ones: moved on by 2 k D.
    const shift = scale(nrm, (k - 1) * D);
    const xf = k % 2 ? mirrorAcross(add(a, shift), add(b, shift)) : translation(scale(nrm, 2 * k * D));
    const copies = copyElements(doc, ids, xf);
    raise(doc, copies, dz * k);
    out.push(...copies);
  }
  return out;
}

/**
 * Make the copies (inside a transaction): opts { d1, n1, d2, n2, dz, method: 'increment' | 'distribute' | 'spread', spacing }.
 * With Spread the counts come from the spacing.
 * n1 and n2 count the items along each vector including the original. Returns the new ids.
 */
export function multiply(doc, ids, { d1, n1 = 2, d2 = null, n2 = 1, dz = 0, method = 'increment', spacing = 0 }) {
  let s1;
  let s2 = [0, 0];
  if (method === 'spread') {
    ({ n: n1, step: s1 } = spreadStep(d1, spacing));
    if (d2) ({ n: n2, step: s2 } = spreadStep(d2, spacing));
  } else {
    const step = (d, n) => (method === 'distribute' && n > 1 ? scale(d, 1 / (n - 1)) : d);
    s1 = step(d1, n1);
    if (d2) s2 = step(d2, n2);
  }
  const rows = d2 ? n2 : 1;
  const total = n1 * rows;
  const out = [];
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < n1; i++) {
      if (!i && !j) continue;
      const k = j * n1 + i;
      const copies = copyElements(doc, ids, translation(add(scale(s1, i), scale(s2, j))));
      raise(doc, copies, (method === 'distribute' && total > 1 ? dz / (total - 1) : dz) * k);
      out.push(...copies);
    }
  return out;
}
