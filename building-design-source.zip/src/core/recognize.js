/**
 * Model recognition from CAD drawings: each layer is given a role from its
 * name (in Italian, English, Ukrainian, Russian, French, German or Spanish,
 * as CAD programs and offices name them), and the geometry on it becomes
 * elements: walls from the cut fills or face lines on wall layers, columns
 * from column shapes, doors and windows from the clusters on their layers
 * hosted in the nearest wall, rooms from closed zone outlines named by the
 * zone stamps inside them.
 */
import { railingsOnStair } from './autorail.js';
import { isElementExport, exportedOpenings, exportedZoneNames, wallBlockTest, exportedStairs, exportedColumns, exportedLifts, exportedRailings } from './acdwg.js';
import { stairFromLines } from './stairread.js';
import { wallsFromPolygons, wallPairs, chainLoops } from './convert.js';
import { buildFloorPlan, wallTypeMaking } from './floorplan.js';
import { pointInPolygon, signedArea, dist, sub, dot, norm, add, scale } from './geom.js';
import { FloorGrid } from './flood.js';
import { mtextPlain } from './cadflatten.js';

export const ROLES = [
  { value: 'drafting', label: 'Drafting' },
  { value: 'wall', label: 'Walls' },
  { value: 'column', label: 'Columns' },
  { value: 'door', label: 'Doors' },
  { value: 'window', label: 'Windows' },
  { value: 'zone', label: 'Zones (outlines)' },
  { value: 'stamp', label: 'Zone names' },
  { value: 'ignore', label: 'Leave out' },
];

const RULES = [
  ['stamp', /(паспорт|stamp|timbro|cartigl|tag|label|etichett|beschrift|etiqueta)/i],
  ['zone', /(zon[aeі]|room|stanz|vano|locale|ambient|зон|приміщ|помещ|pièce|raum|habitaci|espacio)/i],
  ['window', /(window|finestr|окн|вікн|fen[eê]tre|fenster|ventana|vetrat|glazing|serrament|infiss)/i],
  ['door', /(door|port[ae]|двер|tür|tuer|puerta)/i],
  ['column', /(column|colonn|pilastr|колон|poteau|stütze|stuetze|säule|saeule|pilar)/i],
  ['wall', /(wall|muri|muro|muratur|paret|tramezz|sezion|taglio|стін|стен|mur\b|murs|cloison|wand|wände|waende|tabique|muros)/i],
  ['ignore', /(dim|quot|cot[ae]|розмір|размер|cote|maß|mass|acot|hatch|retin|штрих|axis|asse|griglia|grid|ось|defpoints|viewport|border|squadr|frame|cornice)/i],
];

/** The role of a layer from its name. */
export function layerRole(name) {
  const n = String(name || '');
  for (const [role, re] of RULES) if (re.test(n)) return role;
  return 'drafting';
}

/** Groups of segments that touch each other (ends within tol). */
export function clusters(segs, tol = 30) {
  const parent = segs.map((_, i) => i);
  const find = (i) => (parent[i] === i ? i : (parent[i] = find(parent[i])));
  const cell = new Map();
  const key = (p) => `${Math.floor(p[0] / tol)},${Math.floor(p[1] / tol)}`;
  segs.forEach((s, i) => {
    for (const p of [s.a, s.b]) {
      const [cx, cy] = key(p).split(',').map(Number);
      for (let dx = -1; dx <= 1; dx++)
        for (let dy = -1; dy <= 1; dy++) {
          const list = cell.get(`${cx + dx},${cy + dy}`);
          if (list) for (const j of list) parent[find(j)] = find(i);
        }
      const k = key(p);
      if (!cell.has(k)) cell.set(k, []);
      cell.get(k).push(i);
    }
  });
  const groups = new Map();
  segs.forEach((s, i) => {
    const r = find(i);
    if (!groups.has(r)) groups.set(r, []);
    groups.get(r).push(s);
  });
  return [...groups.values()];
}

/**
 * Join wall pieces that line up on one axis with the same thickness: across
 * a short break (where a cut fill was split at a junction) they simply
 * join, and across a gap holding door or window symbols they join with
 * that opening in the gap, as wide as the gap.
 * walls: [{ a, b, thickness }]; marks: { door: [segments], window: [segments] }.
 * Returns { walls, openings: [{ kind, at, width }] }.
 */
export function bridgeOpenings(walls, marks, { maxGap = 12000, joinGap = 0, classify = null, loose = false, canJoin = null } = {}) {
  const groups = [];
  for (const w of walls) {
    let d = norm(sub(w.b, w.a));
    // One sense per line: its larger component positive (a near-vertical line's tiny x must not decide).
    if (Math.abs(d[0]) >= Math.abs(d[1]) ? d[0] < 0 : d[1] < 0) d = [-d[0], -d[1]];
    const n = [-d[1], d[0]];
    // Old walls vary a little in thickness along a front: a few per cent still counts as the same wall.
    const tol = loose ? Math.max(40, 0.3 * w.thickness) : Math.max(25, 0.08 * w.thickness);
    // Off the group's line measured square to it (a piece's own normal, a little turned, would put a far piece off).
    const mid = [(w.a[0] + w.b[0]) / 2, (w.a[1] + w.b[1]) / 2];
    // The nearest such group, in thickness and in offset (the first found may hold only a part of the wall).
    let g = null;
    let best = Infinity;
    for (const x of groups) {
      if (Math.abs(dot(x.d, d)) <= 0.9995) continue;
      const dOff = Math.abs(dot(mid, x.n) - x.off);
      const dT = Math.abs(x.t - w.thickness);
      if (dOff < tol && dT < tol && dOff + dT < best) (best = dOff + dT), (g = x);
    }
    const dd = g ? g.d : d;
    const ts = [dot(w.a, dd), dot(w.b, dd)].sort((p, q) => p - q);
    const piece = { t0: ts[0], t1: ts[1] };
    if (g) g.pieces.push(piece);
    else groups.push({ d, n, off: dot(mid, n), t: w.thickness, pieces: [piece] });
  }
  const marked = Object.entries(marks).flatMap(([kind, segs]) => segs.map((s) => ({ kind, s, m: [(s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2] })));
  // A gap other walls run alongside, touching the gap's band on one side for 60 % of its length or more (together),
  // is a recess in front of a wall (a niche between piers), not an opening: its two pieces are not joined across it.
  const flanked = (g, t0, t1) => {
    if (t1 - t0 < 500) return false;
    const spans = { 1: [], [-1]: [] };
    for (const w of walls) {
      const L = Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]);
      if (L < 1) continue;
      const d = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
      if (Math.abs(dot(d, g.d)) < 0.999) continue;
      const off = dot([(w.a[0] + w.b[0]) / 2, (w.a[1] + w.b[1]) / 2], g.n) - g.off;
      if (Math.abs(Math.abs(off) - (g.t + w.thickness) / 2) > Math.max(30, 0.1 * w.thickness)) continue;
      const u0 = Math.max(t0, Math.min(dot(w.a, g.d), dot(w.b, g.d)));
      const u1 = Math.min(t1, Math.max(dot(w.a, g.d), dot(w.b, g.d)));
      if (u1 > u0) spans[Math.sign(off)].push([u0, u1]);
    }
    for (const list of Object.values(spans)) {
      list.sort((x, y) => x[0] - y[0]);
      let covered = 0;
      let end = -Infinity;
      for (const [u0, u1] of list) {
        if (u1 <= end) continue;
        covered += u1 - Math.max(u0, end);
        end = u1;
      }
      if (covered >= 0.6 * (t1 - t0)) return true;
    }
    return false;
  };
  const out = { walls: [], openings: [] };
  for (const g of groups) {
    const at = (t) => [g.d[0] * t + g.n[0] * g.off, g.d[1] * t + g.n[1] * g.off];
    g.pieces.sort((p, q) => p.t0 - q.t0);
    let cur = null;
    const flush = () => cur && cur.t1 - cur.t0 > 1 && out.walls.push({ a: at(cur.t0), b: at(cur.t1), thickness: g.t });
    for (const p of g.pieces) {
      if (!cur) { cur = { ...p }; continue; }
      const gap = p.t0 - cur.t1;
      if (gap > Math.max(60, g.t * 1.2) && flanked(g, cur.t1, p.t0)) {
        flush();
        cur = { ...p };
        continue;
      }
      // In a thick wall a doorway is shorter than the wall is deep: what a classifier calls an opening comes before the short-break rule.
      const early = classify && gap >= 500 && gap <= Math.max(60, g.t * 1.2) ? classify({ at: at((cur.t1 + p.t0) / 2), width: gap, d: g.d, n: g.n, thickness: g.t, sides: [cur.t1 - cur.t0, p.t1 - p.t0] }) : null;
      if (early) {
        out.openings.push(typeof early === 'object' ? { ...early, d: g.d } : { kind: early, at: at((cur.t1 + p.t0) / 2), width: gap, d: g.d });
        cur.t1 = Math.max(cur.t1, p.t1);
        continue;
      }
      if (gap <= Math.max(60, g.t * 1.2) || (gap <= joinGap && (!canJoin || canJoin(at(cur.t1), at(p.t0), g.t, cur.t1 - cur.t0, p.t1 - p.t0)))) { cur.t1 = Math.max(cur.t1, p.t1); continue; }
      if (gap <= maxGap) {
        // Symbols in the gap: midpoints between the pieces and within the wall's band.
        const inGap = marked.filter((x) => { const t = dot(x.m, g.d); return t > cur.t1 + 5 && t < p.t0 - 5 && Math.abs(dot(x.m, g.n) - g.off) <= g.t / 2 + 40; });
        // A classifier (for drawings without layers) decides from the gap itself.
        const judged = classify ? classify({ at: at((cur.t1 + p.t0) / 2), width: gap, d: g.d, n: g.n, thickness: g.t, sides: [cur.t1 - cur.t0, p.t1 - p.t0] }) : undefined;
        if (judged) {
          // The classifier may place the opening in part of the gap: { kind, at, width }.
          out.openings.push(typeof judged === 'object' ? { ...judged, d: g.d } : { kind: judged, at: at((cur.t1 + p.t0) / 2), width: gap, d: g.d });
          cur.t1 = Math.max(cur.t1, p.t1);
          continue;
        }
        if (judged === undefined && inGap.length >= 2) {
          // Symbols apart along the gap are separate openings (two windows with a pier the fill left out).
          const spans = inGap.map((x) => [Math.min(dot(x.s.a, g.d), dot(x.s.b, g.d)), Math.max(dot(x.s.a, g.d), dot(x.s.b, g.d)), x.kind]).sort((u, v) => u[0] - v[0]);
          const runs = [];
          for (const sp of spans) {
            const r = runs.at(-1);
            if (r && sp[0] <= r.t1 + 150) { r.t1 = Math.max(r.t1, sp[1]); r.kinds.push(sp[2]); }
            else runs.push({ t0: sp[0], t1: sp[1], kinds: [sp[2]] });
          }
          const big = runs.filter((r) => r.t1 - r.t0 >= 300);
          // A wide gap is an opening only when its symbols fill much of it.
          const covered = runs.reduce((sum, r) => sum + Math.min(p.t0, r.t1) - Math.max(cur.t1, r.t0), 0);
          if (gap > 4000 && covered < 0.5 * gap) {
            flush();
            cur = { ...p };
            continue;
          }
          const kindOf = (ks) => (ks.filter((k) => k === 'door').length * 2 >= ks.length ? 'door' : 'window');
          if (big.length > 1)
            for (const r of big) {
              const t0 = Math.max(cur.t1, r.t0);
              const t1 = Math.min(p.t0, r.t1);
              out.openings.push({ kind: kindOf(r.kinds), at: at((t0 + t1) / 2), width: t1 - t0 });
            }
          else out.openings.push({ kind: kindOf(inGap.map((x) => x.kind)), at: at((cur.t1 + p.t0) / 2), width: gap });
          cur.t1 = Math.max(cur.t1, p.t1);
          continue;
        }
      }
      flush();
      cur = { ...p };
    }
    flush();
  }
  return out;
}

/** Whether a point lies in a wall's band (its thickness plus pad, along its length). */
function inWall(p, w, pad = 50) {
  const L = dist(w.a, w.b) || 1;
  const d = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
  const t = dot(sub(p, w.a), d);
  return t > -pad && t < L + pad && Math.abs(dot(sub(p, w.a), [-d[1], d[0]])) <= w.thickness / 2 + pad;
}

/**
 * Glazing drawn on window layers away from any wall (a glazed front, a
 * curtain wall): its parallel frame lines are paired, side by side bands
 * merged into one as deep as the whole frame, and pieces on one axis joined
 * across mullions. Returns walls [{ a, b, thickness, curtain: true }].
 */
export function glazingFromLines(segs, walls, { min = 40, max = 400, minLength = 400 } = {}) {
  const free = segs.filter((s) => dist(s.a, s.b) >= 150 && !walls.some((w) => inWall([(s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2], w)));
  const pairs = wallPairsAll(free, { min, max });
  // Bands side by side on one direction and stretch become one.
  const bands = [];
  for (const p of pairs) {
    let d = norm(sub(p.b, p.a));
    // One sense per line: its larger component positive (a near-vertical line's tiny x must not decide).
    if (Math.abs(d[0]) >= Math.abs(d[1]) ? d[0] < 0 : d[1] < 0) d = [-d[0], -d[1]];
    const n = [-d[1], d[0]];
    const off = dot(p.a, n);
    const ts = [dot(p.a, d), dot(p.b, d)].sort((x, y) => x - y);
    const b = { d, n, lo: off - p.thickness / 2, hi: off + p.thickness / 2, t0: ts[0], t1: ts[1] };
    const m = bands.find((x) => Math.abs(dot(x.d, d)) > 0.9999 && b.lo <= x.hi + 40 && b.hi >= x.lo - 40 && Math.min(b.t1, x.t1) - Math.max(b.t0, x.t0) > 0.5 * Math.min(b.t1 - b.t0, x.t1 - x.t0));
    if (m) Object.assign(m, { lo: Math.min(m.lo, b.lo), hi: Math.max(m.hi, b.hi), t0: Math.min(m.t0, b.t0), t1: Math.max(m.t1, b.t1) });
    else bands.push(b);
  }
  const pieces = bands.map((b) => {
    const off = (b.lo + b.hi) / 2;
    const at = (t) => [b.d[0] * t + b.n[0] * off, b.d[1] * t + b.n[1] * off];
    return { a: at(b.t0), b: at(b.t1), thickness: Math.round(b.hi - b.lo) };
  });
  return bridgeOpenings(pieces, {}, { maxGap: 0, joinGap: 250 }).walls.filter((w) => dist(w.a, w.b) >= minLength).map((w) => ({ ...w, curtain: true }));
}

/** Every stretch of each line with its nearest parallel partner min..max away: [{ a, b, thickness }]. */
function wallPairsAll(segs, { min, max }) {
  const items = segs.map((s) => ({ a: s.a, b: s.b, len: dist(s.a, s.b), d: norm(sub(s.b, s.a)), cover: [] }));
  const cands = [];
  for (let i = 0; i < items.length; i++)
    for (let j = i + 1; j < items.length; j++) {
      const s = items[i];
      const o = items[j];
      if (Math.abs(Math.abs(dot(s.d, o.d)) - 1) > 2e-3) continue;
      const n = [-s.d[1], s.d[0]];
      const off = dot(sub(o.a, s.a), n);
      if (Math.abs(off) < min || Math.abs(off) > max) continue;
      const ta = dot(sub(o.a, s.a), s.d);
      const tb = dot(sub(o.b, s.a), s.d);
      const lo = Math.max(0, Math.min(ta, tb));
      const hi = Math.min(s.len, Math.max(ta, tb));
      if (hi - lo > 50) cands.push({ s, n, off, lo, hi, gap: Math.abs(off) });
    }
  cands.sort((x, y) => x.gap - y.gap);
  const out = [];
  for (const c of cands) {
    if (c.s.cover.some(([u, v]) => u <= c.lo + 1 && v >= c.hi - 1)) continue;
    c.s.cover.push([c.lo, c.hi]);
    const shift = [c.n[0] * c.off / 2, c.n[1] * c.off / 2];
    out.push({ a: [c.s.a[0] + c.s.d[0] * c.lo + shift[0], c.s.a[1] + c.s.d[1] * c.lo + shift[1]], b: [c.s.a[0] + c.s.d[0] * c.hi + shift[0], c.s.a[1] + c.s.d[1] * c.hi + shift[1]], thickness: c.gap });
  }
  return out;
}

/**
 * Doors and windows drawn inside a wall's thickness where the wall runs on
 * through them (no gap in its outline): the runs of their symbols along the
 * wall, 300 mm to 6 m long, away from the openings already found.
 */
export function openingsInWalls(walls, marks, found = []) {
  const out = [];
  for (const w of walls) {
    const L = dist(w.a, w.b);
    if (L < 300) continue;
    const d = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
    const n = [-d[1], d[0]];
    const band = w.thickness / 2 + 40;
    const spans = [];
    for (const [kind, segs] of Object.entries(marks))
      for (const sg of segs) {
        const ta = dot(sub(sg.a, w.a), d);
        const tb = dot(sub(sg.b, w.a), d);
        if (Math.max(ta, tb) < 0 || Math.min(ta, tb) > L) continue;
        if (Math.abs(dot(sub(sg.a, w.a), n)) > band || Math.abs(dot(sub(sg.b, w.a), n)) > band) continue;
        spans.push([Math.max(0, Math.min(ta, tb)), Math.min(L, Math.max(ta, tb)), kind]);
      }
    spans.sort((p, q) => p[0] - q[0]);
    const runs = [];
    for (const sp of spans) {
      const r = runs.at(-1);
      if (r && sp[0] <= r.t1 + 60) { r.t1 = Math.max(r.t1, sp[1]); r.kinds.push(sp[2]); }
      else runs.push({ t0: sp[0], t1: sp[1], kinds: [sp[2]] });
    }
    for (const r of runs) {
      const width = r.t1 - r.t0;
      if (width < 300 || width > 6000 || r.kinds.length < 2) continue;
      const at = [w.a[0] + d[0] * (r.t0 + r.t1) / 2, w.a[1] + d[1] * (r.t0 + r.t1) / 2];
      if ([...found, ...out].some((o) => dist(o.at, at) < Math.max(300, (o.width + width) / 4))) continue;
      out.push({ kind: r.kinds.filter((k) => k === 'door').length * 2 >= r.kinds.length ? 'door' : 'window', at, width });
    }
  }
  return out;
}

const bboxOf = (pts) => {
  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  return { x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) };
};

/**
 * Recognise a model from a flattened CAD drawing (cadflatten.js) whose
 * coordinates are already in millimetres. roles: Map layer -> role.
 * Returns { plan (for buildFloorPlan), columns: [{ at, w, d, round }], counts }.
 */
export function recognizeCAD(flat, roles, { extraTexts = [] } = {}) {
  const role = (l) => roles.get(l) || 'drafting';
  const by = (r, k) => flat[k].filter((x) => role(x.layer) === r);
  // Walls: the cut fills of wall layers and the closed outlines drawn there
  // (walls without poché), else pairs of their face lines.
  // A drawing Archicad wrote element by element has its walls in wall blocks: a frame or title block on a wall layer is not one.
  const exported = isElementExport(flat);
  const ofWall = exported ? wallBlockTest(flat) : () => true;
  const wallLines = by('wall', 'lines').filter(ofWall);
  const outlines = chainLoops(wallLines, 5);
  const wallPolys = [...by('wall', 'fills').filter(ofWall).map((f) => f.poly), ...outlines.loops].filter((p) => Math.abs(signedArea(p)) > 1000);
  let walls = wallPolys.length ? wallsFromPolygons(wallPolys, { min: 60, max: 1500 }) : [];
  // Face lines no wall was found along (left open, or in an outline that did not make a clean shape) pair up on their own.
  const loose = wallLines.filter((s) => !walls.some((w) => inWall([(s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2], w, 20)));
  // Each stretch of a face goes with its nearest partner; slivers shorter than their thickness are reveals and steps.
  if (loose.length) walls = [...walls, ...wallPairsAll(loose, { min: 60, max: 900 }).filter((w) => dist(w.a, w.b) >= Math.min(w.thickness, 200))];
  // Curved walls: pairs of concentric arcs on wall layers (their faces). The straight pieces found in the band between
  // them (from a fill cut into short sides) give way to the curved wall.
  const curvedWalls = curvedWallsFromArcs(by('wall', 'arcs').filter(ofWall));
  if (curvedWalls.length) walls = walls.filter((w) => !curvedWalls.some((c) => inArcBand([(w.a[0] + w.b[0]) / 2, (w.a[1] + w.b[1]) / 2], c, 30)));
  const arcChord = (a) => ({ a: [a.c[0] + a.r * Math.cos(a.a0), a.c[1] + a.r * Math.sin(a.a0)], b: [a.c[0] + a.r * Math.cos(a.a1), a.c[1] + a.r * Math.sin(a.a1)] });
  const marks = { door: [...by('door', 'lines'), ...by('door', 'arcs').map(arcChord)], window: [...by('window', 'lines'), ...by('window', 'arcs').map(arcChord)] };
  // A drawing Archicad wrote element by element: its door, window and opening blocks say what fills each gap.
  const ac = exported ? exportedOpenings(flat) : null;
  if (ac?.length) {
    marks.door = ac.filter((e) => e.kind !== 'window').flatMap((e) => e.segs);
    marks.window = ac.filter((e) => e.kind === 'window').flatMap((e) => e.segs);
  }
  // Doors and windows sit in the gaps between wall pieces on one axis. A drawing with no door symbols at all (a planning
  // permit's plan shows doorways as plain gaps) has its empty gaps a door wide made doors.
  const allMarks = [...marks.door, ...marks.window];
  const plainGaps = !marks.door.length
    ? (o) => {
        if (o.width < 600 || o.width > 1300) return undefined;
        const t0 = dot(o.at, o.d) - o.width / 2;
        const t1 = dot(o.at, o.d) + o.width / 2;
        const off = dot(o.at, o.n);
        const marked = allMarks.some((s) => {
          const m = [(s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2];
          const t = dot(m, o.d);
          return t > t0 - 5 && t < t1 + 5 && Math.abs(dot(m, o.n) - off) <= o.thickness / 2 + 40;
        });
        return marked ? undefined : 'door';
      }
    : null;
  const bridged = bridgeOpenings(walls, marks, plainGaps ? { classify: plainGaps } : {});
  // Plain doorways beside a corner too: from a wall's free end to the face of the wall it points at.
  if (plainGaps) {
    const corner = cornerDoors(bridged.walls, (gap) => (plainGaps(gap) === 'door' ? 'door' : null), { min: 600, max: 1300 });
    bridged.walls = corner.walls;
    bridged.openings.push(...corner.openings);
  }
  // Each gap takes the kind of the element block that fills it (and a door its swing from the leaf's arc); a gap no
  // block fills is where two wall blocks meet, and the wall runs on. A block no gap was found for goes in by itself.
  if (ac?.length) {
    const used = new Map();
    for (const o of bridged.openings) {
      const dir = o.d || [1, 0];
      const nrm = [-dir[1], dir[0]];
      const hit = ac
        .filter((x) => ![...used.values()].includes(x))
        .map((x) => ({ x, along: Math.abs(dot(sub(x.at, o.at), dir)), across: Math.abs(dot(sub(x.at, o.at), nrm)) }))
        .filter((c) => c.along <= o.width / 2 + 100 && c.across <= 700)
        .sort((p, q) => p.along + p.across - (q.along + q.across))[0];
      if (hit) used.set(o, hit.x);
    }
    // How far each kind of block draws past its hole (frames and casings): learnt where the gap is the hole exactly
    // (no wider than the block), and taken off where the gap is wider (beside a cross wall) or there is none.
    const over = new Map();
    for (const [o, x] of used) {
      const ext = x.ext[1] - x.ext[0];
      if (o.width <= ext + 10 && o.width >= ext - 300) (over.get(x.base) || over.set(x.base, []).get(x.base)).push(ext - o.width);
    }
    const median = (v) => [...v].sort((a, b) => a - b)[Math.floor(v.length / 2)];
    const hole = (x) => (x.ext[1] - x.ext[0]) - (over.has(x.base) ? median(over.get(x.base)) : 0);
    const kept = [];
    for (const [o, x] of used) {
      const dir = o.d || x.d;
      // Along the wall where the block is, across where the gap's wall is.
      const at = add(o.at, scale(dir, dot(sub(x.at, o.at), dir)));
      kept.push({ ...o, at, width: o.width <= (x.ext[1] - x.ext[0]) + 10 ? o.width : hole(x), kind: x.kind, swing: x.swing });
    }
    const placed = new Set(used.values());
    for (const x of ac) {
      if (placed.has(x)) continue;
      let width = hole(x);
      // No wall found where it sits: its own wall block is the wall.
      if (x.hostWall && !bridged.walls.some((w) => inWall(x.at, w, 50) && dist(w.a, w.b) >= 0.8 * width)) {
        bridged.walls.push(x.hostWall);
        width = Math.min(width, dist(x.hostWall.a, x.hostWall.b));
      }
      kept.push({ kind: x.kind, at: x.at, width, swing: x.swing, d: x.d });
    }
    bridged.openings = kept;
  }
  // Glazing away from the walls becomes curtain walls.
  const glazing = ac?.length ? [] : glazingFromLines(marks.window, bridged.walls);
  const plan = { walls: [...bridged.walls, ...glazing], curvedWalls, doors: [], windows: [], openings: [], rooms: [], newTypes: 'exact' };
  const inside = ac?.length ? [] : openingsInWalls(bridged.walls, marks, bridged.openings);
  for (const o of [...bridged.openings, ...inside]) {
    if (o.kind === 'opening') plan.openings.push({ at: o.at, width: Math.round(o.width) });
    else (o.kind === 'door' ? plan.doors : plan.windows).push({ at: o.at, width: Math.round(o.width), ...(o.kind === 'door' && o.swing?.length ? { swing: o.swing } : {}) });
  }
  // Sizes written beside openings in centimetres (Italian permit drawings: "140 230", "90 210"): the nearest label
  // with a number matching the drawn width gives the height; one 2 m high or more stands on the floor (a French window).
  const sizes = flat.texts
    .map((t) => ({ t, m: /^\s*(\d{2,3})\s+(\d{2,3})\s*$/.exec(mtextPlain(String(t.text || '')).replace(/\\P/g, ' ')) }))
    .filter((x) => x.m)
    .map((x) => ({ at: x.t.at, a: +x.m[1] * 10, b: +x.m[2] * 10 }));
  // Width first as a rule, but some write the height first: the number that matches the drawn width is the width.
  const fitW = (v, o) => Math.abs(v - o.width) <= Math.max(150, 0.15 * o.width);
  if (sizes.length)
    for (const o of [...plan.doors, ...plan.windows]) {
      const near = sizes.filter((x) => (fitW(x.a, o) || fitW(x.b, o)) && dist(x.at, o.at) <= 2500).sort((x, y) => dist(x.at, o.at) - dist(y.at, o.at))[0];
      if (!near) continue;
      near.h = fitW(near.a, o) ? near.b : near.a;
      o.height = near.h;
      if (plan.windows.includes(o)) o.sill = near.h >= 2000 ? 0 : Math.max(0, 2200 - near.h);
    }
  // Without gaps (walls drawn over their openings), each cluster of symbols, as wide as its long side.
  if (!bridged.openings.length && !inside.length)
    for (const [r, list] of [['door', plan.doors], ['window', plan.windows]])
      for (const g of clusters(marks[r], 40)) {
        const b = bboxOf(g.flatMap((x) => [x.a, x.b]));
        const w = Math.max(b.x1 - b.x0, b.y1 - b.y0);
        if (w < 400 || w > 6000) continue;
        list.push({ at: [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2], width: r === 'door' ? Math.min(w, 2400) : w });
      }
  // Columns: filled or closed shapes on column layers.
  const columns = [];
  // Column blocks of an element-by-element export, then outlines (before fills: a round column's hatch may be coarser
  // than its outline) and fills on column layers.
  const colBlocks = exported ? exportedColumns(flat) : [];
  for (const c of colBlocks) if (c.w >= 100 && c.d >= 100 && c.w <= 2500 && c.d <= 2500) columns.push({ at: c.at, w: c.w, d: c.d, round: c.round, rotation: c.round ? 0 : c.rotation });
  const colShapes = [...chainLoops(by('column', 'lines'), 5).loops, ...by('column', 'fills').map((f) => f.poly)];
  for (const poly of colShapes) {
    const b = bboxOf(poly);
    const w = b.x1 - b.x0;
    const d = b.y1 - b.y0;
    if (w < 100 || d < 100 || w > 2500 || d > 2500) continue;
    const area = Math.abs(signedArea(poly));
    const at = [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2];
    // A column drawn both filled and outlined counts once.
    if (columns.some((c) => dist(c.at, at) < 50)) continue;
    columns.push({ at, w, d, round: poly.length > 12 && Math.abs(area - (Math.PI * w * d) / 4) < 0.1 * area });
  }
  // Rooms: closed zone outlines, named by the stamp texts inside.
  const zoneLoops = [...chainLoops(by('zone', 'lines'), 5).loops, ...by('zone', 'fills').map((f) => f.poly)].filter((p) => Math.abs(signedArea(p)) > 1e6);
  const stamps = [...by('stamp', 'texts'), ...by('zone', 'texts')];
  const seen = [];
  for (const loop of zoneLoops) {
    const b = bboxOf(loop);
    // The same outline drawn twice (fill and line) counts once.
    if (seen.some((s) => Math.abs(s.x0 - b.x0) < 50 && Math.abs(s.y1 - b.y1) < 50 && Math.abs(s.x1 - b.x1) < 50)) continue;
    seen.push(b);
    const inside = stamps.filter((t) => pointInPolygon(t.at, loop)).sort((p, q) => q.at[1] - p.at[1]);
    // A zone number is a short code (12, 2A, B.3); an area (21,1 m²) is neither; a name has a word in it.
    const isArea = (x) => /\d\s*(м²|m²|m2|мкв|mq)/i.test(x);
    const isCode = (x) => /^[\p{L}\d]{1,4}([.\-/][\p{L}\d]{1,4})*$/u.test(x.trim());
    const nameText = inside.find((t) => !isArea(t.text) && !isCode(t.text) && /\p{L}{3,}/u.test(t.text));
    const numText = inside.find((t) => !isArea(t.text) && isCode(t.text));
    // The room is found from the point of its stamp, which sits in the free floor.
    let at = nameText?.at || [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2];
    if (!pointInPolygon(at, loop)) at = loop.reduce((s, p) => [s[0] + p[0] / loop.length, s[1] + p[1] / loop.length], [0, 0]);
    plan.rooms.push({ at, name: nameText ? nameText.text.split('\n')[0].trim() : 'Room', number: numText?.text.trim(), outline: loop });
  }
  // No zone outlines but stamps that give an area ("camera 15.48 mq"): each stamp is a zone found from the walls round it.
  if (!plan.rooms.length) {
    const AREA = /(\d+(?:[.,]\d+)?)\s*(м²|m²|m2|мкв|mq)/i;
    for (const t of flat.texts) {
      const text = String(t.text || '').trim();
      const m = AREA.exec(text);
      if (!m) continue;
      const name = text.replace(AREA, '').replace(/\bH\.?\s*\d+[.,]\d+/i, '').split('\n')[0].trim();
      if (!/\p{L}{2,}/u.test(name)) continue;
      plan.rooms.push({ at: t.mid || t.at, name, stampArea: +m[1].replace(',', '.') });
    }
    if (plan.rooms.length) floodStampZones(plan, [...wallLines, ...marks.window, ...marks.door], flat.lines.filter((l) => !['ignore', 'stamp', 'zone'].includes(role(l.layer))));
  }
  // Stairs from the stair blocks of an element-by-element export (their drawing is then the stair's own, not drafting).
  plan.stairs = [];
  const consumed = new Set();
  if (exported)
    for (const b of exportedStairs(flat)) {
      const st = stairFromLines(b.lines, b.arcs);
      if (!st) continue;
      // The same stair written twice counts once.
      if (plan.stairs.some((o) => dist(o.a, st.a) < 50)) { consumed.add(b.ins); continue; }
      plan.stairs.push(st);
      consumed.add(b.ins);
    }
  // Railings and lifts of an element-by-element export (their drawing is then the element's own).
  plan.railings = [];
  plan.lifts = [];
  if (exported) {
    for (const r of exportedRailings(flat)) {
      for (const path of r.paths) plan.railings.push({ path });
      consumed.add(r.ins);
    }
    for (const l of exportedLifts(flat)) {
      if (l.w < 600 || l.d < 600 || l.w > 4000 || l.d > 4000) continue;
      plan.lifts.push(l);
      consumed.add(l.ins);
    }
    for (const c of colBlocks) consumed.add(c.ins);
  }
  // Names Archicad wrote into its zone blocks ("Camera 1_A.1_4"), for zones whose stamps give a number only.
  const zoneNames = exportedZoneNames(flat);
  for (const r of plan.rooms) if (r.name === 'Room' && r.number && zoneNames.has(r.number)) r.name = zoneNames.get(r.number);
  // Names from the drawing's room schedule, for zones whose stamps give a number only.
  nameRoomsFromLegend(plan.rooms, [...flat.texts, ...extraTexts].map((t) => ({ ...t, size: t.height || 200 })));
  return { plan, columns, consumed, counts: { curvedWalls: curvedWalls.length, stairs: plan.stairs.length, railings: plan.railings.length, lifts: plan.lifts.length, curtainWalls: glazing.length, walls: plan.walls.length, doors: plan.doors.length, windows: plan.windows.length, openings: plan.openings.length, rooms: plan.rooms.length, columns: columns.length } };
}

/** Make a recognised model (inside a transaction). Returns the new ids by kind. */
/**
 * Zones from their stamps by flooding the floor (as for PDF plans): the barriers are the walls made (their openings
 * included), the drawing's own wall and window lines, and the gaps along walls closed as a zone's outline crosses a
 * doorway. A zone is kept when it measures as its stamp says (within 4 %), first with every gap closed, then with
 * only the doorways; one flood that reaches two stamps is an open plan and is left to its stamps.
 */
function floodStampZones(plan, lines, extra = []) {
  const pts = [...plan.walls.flatMap((w) => [w.a, w.b]), ...lines.flatMap((l) => [l.a, l.b])];
  if (!pts.length) return;
  const box = { x0: Math.min(...pts.map((p) => p[0])) - 500, y0: Math.min(...pts.map((p) => p[1])) - 500, x1: Math.max(...pts.map((p) => p[0])) + 500, y1: Math.max(...pts.map((p) => p[1])) + 500 };
  const span = Math.max(box.x1 - box.x0, box.y1 - box.y0);
  const grid = new FloorGrid(box, Math.max(10, span / 3000));
  const band = (a, b, half) => {
    const L = dist(a, b) || 1;
    const n = [(-(b[1] - a[1]) / L) * half, ((b[0] - a[0]) / L) * half];
    return [[a[0] + n[0], a[1] + n[1]], [b[0] + n[0], b[1] + n[1]], [b[0] - n[0], b[1] - n[1]], [a[0] - n[0], a[1] - n[1]]];
  };
  grid.paint(plan.walls.map((w) => band(w.a, w.b, w.thickness / 2)));
  grid.paint(lines.map((l) => band(l.a, l.b, grid.cell * 0.75)));
  const open = grid.clone();
  grid.paint(closingWalls(plan.walls).map((w) => band(w.a, w.b, Math.max(w.thickness / 2, grid.cell))));
  // Doorways however they are drawn (with rebates, beside a corner, between pieces that do not line up): from each wall's
  // end to the nearest other wall a door's width away, the floor is closed as a zone's outline crosses a doorway.
  const near = (p, w) => {
    const d = sub(w.b, w.a);
    const L2 = dot(d, d) || 1;
    const t = Math.max(0, Math.min(1, dot(sub(p, w.a), d) / L2));
    return [w.a[0] + d[0] * t, w.a[1] + d[1] * t];
  };
  const doorways = [];
  for (const w of plan.walls)
    for (const p of [w.a, w.b]) {
      let best = null;
      for (const o of plan.walls) {
        if (o === w) continue;
        const q = near(p, o);
        const d = dist(p, q) - o.thickness / 2;
        if (d < 450 || d > 1300) continue;
        if (!best || d < best.d) best = { d, q };
      }
      if (best) doorways.push(band(p, best.q, Math.max(grid.cell, 30)));
    }
  const doors = grid.clone();
  doors.paint(doorways);
  // Then between wall ends that face each other a door apart (the jambs of a doorway), and straight on from each end
  // along its wall to the first wall a door's width away.
  const jambs = [];
  const ends = plan.walls.flatMap((w) => [{ p: w.a, w, o: w.b }, { p: w.b, w, o: w.a }]);
  for (let i = 0; i < ends.length; i++)
    for (let j = i + 1; j < ends.length; j++) {
      if (ends[i].w === ends[j].w) continue;
      const d = dist(ends[i].p, ends[j].p);
      if (d >= 450 && d <= 1300) jambs.push(band(ends[i].p, ends[j].p, Math.max(grid.cell, 30)));
    }
  for (const e of ends) {
    const L = dist(e.p, e.o) || 1;
    const u = [(e.p[0] - e.o[0]) / L, (e.p[1] - e.o[1]) / L];
    let hit = null;
    for (let t = 100; t <= 1300 && !hit; t += 25) {
      const q = [e.p[0] + u[0] * t, e.p[1] + u[1] * t];
      if (plan.walls.some((o) => o !== e.w && dist(q, near(q, o)) <= o.thickness / 2)) hit = q;
    }
    if (hit && dist(e.p, hit) >= 450) jambs.push(band(e.p, hit, Math.max(grid.cell, 30)));
  }
  const jambed = doors.clone();
  jambed.paint(jambs);
  // Last, every line of the drawing as a boundary (glazing drawn as thin lines on a layer of its own).
  const drawn = jambed.clone();
  drawn.paint((extra || []).map((l) => band(l.a, l.b, grid.cell * 0.75)));
  const area = (cells) => (cells.length * grid.cell ** 2) / 1e6;
  const fits = (cells, r) => Math.abs(area(cells) - r.stampArea) <= 0.04 * r.stampArea + 0.1;
  const cellOf = (p) => Math.floor((p[1] - grid.y0) / grid.cell) * grid.w + Math.floor((p[0] - grid.x0) / grid.cell);
  const stamps = plan.rooms.map((r) => cellOf(r.at));
  for (const [i, r] of plan.rooms.entries()) {
    for (const g of [grid, doors, jambed, drawn, open]) {
      const cells = g.flood(r.at, (r.stampArea * 3e6) / g.cell ** 2);
      if (!cells) continue;
      const set = new Set(cells);
      if (stamps.some((c, j) => j !== i && set.has(c))) continue;
      if (fits(cells, r)) {
        // Kept aside: the walls may close the room more exactly (see placeCAD).
        r.floodOutline = g.outline(cells);
        break;
      }
    }
  }
}

/** Whether a point lies in the band of a curved wall (between its faces, within its angles), with a margin (mm). */
export function inArcBand(p, c, margin = 0) {
  const r = Math.hypot(p[0] - c.c[0], p[1] - c.c[1]);
  if (Math.abs(r - c.r) > c.thickness / 2 + margin) return false;
  let t = Math.atan2(p[1] - c.c[1], p[0] - c.c[0]) - c.a0;
  while (t < 0) t += 2 * Math.PI;
  while (t > 2 * Math.PI) t -= 2 * Math.PI;
  return t <= c.sweep + margin / c.r;
}

/**
 * Curved walls from the arcs of wall faces: two arcs about the same centre (within 20 mm), 60 to 1500 mm apart, over
 * the angles they share (10 degrees at least), make a wall on the arc halfway between them: [{ c, r, a0, sweep,
 * thickness, a, b }] (a to b counterclockwise, sweep in radians).
 */
export function curvedWallsFromArcs(arcs) {
  const norm2 = (a) => { while (a < 0) a += 2 * Math.PI; while (a >= 2 * Math.PI) a -= 2 * Math.PI; return a; };
  const list = arcs.filter((a) => a.r > 200).map((a) => ({ ...a, s: norm2(a.a0), e: norm2(a.a0) + norm2(a.a1 - a.a0 || 2 * Math.PI) }));
  const out = [];
  const used = new Set();
  // Inner and outer faces closest in radius pair first.
  const pairs = [];
  for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
    const p = list[i];
    const q = list[j];
    if (Math.hypot(p.c[0] - q.c[0], p.c[1] - q.c[1]) > 20) continue;
    const t = Math.abs(p.r - q.r);
    if (t < 60 || t > 1500) continue;
    pairs.push([t, i, j]);
  }
  pairs.sort((x, y) => x[0] - y[0]);
  for (const [t, i, j] of pairs) {
    if (used.has(i) || used.has(j)) continue;
    const p = list[i];
    const q = list[j];
    // The angles both arcs cover (q shifted by whole turns to overlap p).
    let best = null;
    for (const k of [-1, 0, 1]) {
      const s = Math.max(p.s, q.s + 2 * Math.PI * k);
      const e = Math.min(p.e, q.e + 2 * Math.PI * k);
      if (e - s > (best ? best.e - best.s : 0)) best = { s, e };
    }
    if (!best || best.e - best.s < (10 * Math.PI) / 180) continue;
    used.add(i).add(j);
    const c = [(p.c[0] + q.c[0]) / 2, (p.c[1] + q.c[1]) / 2];
    const r = (p.r + q.r) / 2;
    const a = [c[0] + r * Math.cos(best.s), c[1] + r * Math.sin(best.s)];
    const b = [c[0] + r * Math.cos(best.e), c[1] + r * Math.sin(best.e)];
    out.push({ c, r, a0: norm2(best.s), sweep: best.e - best.s, thickness: t, a, b });
  }
  return out;
}

export function buildRecognized(doc, rec, { levelId }) {
  // CAD geometry is exact: short piers between openings are real walls.
  const out = buildFloorPlan(doc, { ...rec.plan, walls: withoutOverlaps(rec.plan.walls) }, { levelId, minLength: 40 });
  // Zones keep their drawn outlines exactly (manual zones, as the drawing's were).
  rec.plan.rooms.forEach((r, i) => r.outline && out.rooms[i] && doc.update(out.rooms[i], { boundary: r.outline.map((p) => [p[0], p[1]]) }));
  // The area the drawing writes for each zone, kept to check the zone against.
  rec.plan.rooms.forEach((r, i) => r.stampArea > 0 && out.rooms[i] && doc.update(out.rooms[i], { stampArea: r.stampArea }));
  // Curved walls as drawn (a to b counterclockwise round the centre), of a type their thickness.
  const above = doc.levelAbove(levelId);
  for (const c of rec.plan.curvedWalls || []) {
    const type = wallTypeMaking(doc, Math.round(c.thickness), false, true);
    out.walls.push(doc.add({ kind: 'wall', typeId: type?.id, levelId, a: c.a.map(Math.round), b: c.b.map(Math.round), arc: c.sweep, baseOffset: 0, topLevelId: above?.id ?? null, topOffset: 0, height: 3000, locationLine: 'center', joinA: true, joinB: true, roomBounding: true }).id);
  }
  const colType = doc.all('columnType').find((t) => !t.structural) || doc.all('columnType')[0];
  const cols = [];
  for (const c of rec.columns) {
    // A column type of this size, made when missing.
    const shape = c.round ? 'round' : 'rect';
    const name = c.round ? `Round ${Math.round(c.w)} mm` : `${Math.round(c.w)} x ${Math.round(c.d)} mm`;
    let t = doc.all('columnType').find((x) => x.name === name);
    if (!t && colType) {
      const { id: _id, ...rest } = colType;
      t = doc.add({ ...rest, name, width: Math.round(c.w), depth: Math.round(c.d), shape });
    }
    cols.push(doc.add({ kind: 'column', typeId: t?.id, levelId, at: c.at, rotation: Math.round(c.rotation || 0), topLevelId: doc.levelAbove(levelId)?.id ?? null, height: 3000 }).id);
  }
  // Lifts: a lift car the size of the block, turned as it is drawn.
  const lifts = [];
  for (const l of rec.plan.lifts || []) {
    const name = `Lift ${Math.round(l.w)} x ${Math.round(l.d)} mm`;
    const t = doc.all('componentType').find((x) => x.family === 'elevator' && x.name === name) || doc.add({ kind: 'componentType', family: 'elevator', category: 'equipment', familyName: 'Elevator', name, width: Math.round(l.w), depth: Math.round(l.d), height: 2200 });
    lifts.push(doc.add({ kind: 'component', typeId: t.id, levelId, at: l.at.map(Math.round), rotation: Math.round(l.rotation || 0), offset: 0 }).id);
  }
  // Stairs read from the drawing (their height from the step rule: a plan does not give it).
  const stairs = [];
  for (const st of rec.plan.stairs || []) {
    const el = { kind: 'stair', typeId: doc.all('stairType')[0]?.id, levelId, topLevelId: null, baseOffset: 0, topOffset: 0, height: Math.round(st.risers * st.riser), a: st.a.map(Math.round), b: [Math.round(st.a[0] + st.dir[0] * 1000), Math.round(st.a[1] + st.dir[1] * 1000)], width: Math.round(st.width), tread: Math.round(st.tread), risers: st.risers, railings: false, shape: st.shape };
    if (st.shape !== 'straight') Object.assign(el, { splitRisers: st.splitRisers, turn: st.turn });
    if (st.shape === 'u') el.gap = Math.round(st.gap);
    if (st.shape === 'l') el.landingDepth = Math.round(st.landingDepth);
    stairs.push(doc.add(el).id);
  }
  // Railings along the paths read from the drawing, of the project's first railing type. Where a path runs along a
  // stair's flights and landings, the stair's own railings on that side take its place, climbing with the flights.
  const railings = [];
  const railType = doc.all('railingType')[0];
  const segDist = (p, a, b) => {
    const d = [b[0] - a[0], b[1] - a[1]];
    const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * d[0] + (p[1] - a[1]) * d[1]) / (d[0] * d[0] + d[1] * d[1] || 1)));
    return Math.hypot(p[0] - a[0] - d[0] * t, p[1] - a[1] - d[1] * t);
  };
  const toPath = (path, p) => Math.min(...path.slice(1).map((q, i) => segDist(p, path[i], q)));
  for (const r of rec.plan.railings || []) {
    const path = r.path.map((p) => p.map(Math.round));
    let onStair = [];
    for (const id of stairs) {
      const cand = railingsOnStair(doc, doc.get(id), railType?.id);
      // A stair railing the drawn path runs along: its middle and both ends near the path.
      onStair.push(...cand.filter((c) => [c.path[0], c.path.at(-1), [(c.path[0][0] + c.path.at(-1)[0]) / 2, (c.path[0][1] + c.path.at(-1)[1]) / 2]].every((p) => toPath(path, p) < 250)));
    }
    // The drawn path is the stair's when most of its length is covered by those railings.
    const length = path.slice(1).reduce((s, q, i) => s + Math.hypot(q[0] - path[i][0], q[1] - path[i][1]), 0);
    const covered = onStair.reduce((s, c) => s + Math.hypot(c.path.at(-1)[0] - c.path[0][0], c.path.at(-1)[1] - c.path[0][1]), 0);
    if (onStair.length && covered > 0.5 * length) for (const c of onStair) railings.push(doc.add(c).id);
    else railings.push(doc.add({ kind: 'railing', typeId: railType?.id, levelId, offset: 0, path }).id);
  }
  return { ...out, columns: cols, stairs, railings, lifts };
}

/**
 * How many zones made from stamps measure as their stamps say (within 2 %):
 * a check that the scale and the walls are right. ids: the rooms made, in
 * the order of `rooms` (which carry stampArea in m²).
 */
export function stampCheck(doc, scene, ids, rooms) {
  let total = 0;
  let match = 0;
  ids.forEach((id, i) => {
    const want = rooms[i]?.stampArea;
    if (!(want > 0)) return;
    total++;
    const got = scene.rooms.room(doc.get(id))?.area / 1e6;
    if (got > 0 && Math.abs(got - want) <= 0.02 * want + 0.05) match++;
  });
  return { total, match };
}

/**
 * Walls that close the plan for finding rooms: pieces of one wall joined
 * across gaps up to 3 m, and free wall ends carried on along their line up
 * to reach (a doorway beside a corner) when they meet another wall there.
 */
export function closingWalls(walls, { reach = 1300 } = {}) {
  // Blurred or scaled drawings vary the thickness along one wall: closing rooms allows for it.
  const kept = withoutEmbeddedStubs(walls);
  // Where both ends of the gap stand on walls that run on past them either side, the gap is a
  // passage between those walls (a corridor crossing the wall's line), not a doorway in it.
  const passing = (p, t) => {
    let lo = 0;
    let hi = 0;
    for (const o of kept) {
      const L = dist(o.a, o.b);
      // Junctions are often drawn with a small gap: within the joining wall's thickness counts.
      if (L < 1 || distToSeg(p, o.a, o.b) > o.thickness / 2 + t + 20) continue;
      const u = [(o.b[0] - o.a[0]) / L, (o.b[1] - o.a[1]) / L];
      const s0 = dot(sub(o.a, p), u);
      lo = Math.min(lo, s0, s0 + L);
      hi = Math.max(hi, s0, s0 + L);
    }
    return lo < -t && hi > t;
  };
  // Blots shorter than they are thick (a door frame's corner, where thin lines cross) are not joined to one
  // another across a gap: a wall is, to a short jamb beside its doorway.
  // A wall's end may stop a little short of the wall it meets (a junction drawn apart, a line crossed there):
  // look for it a little way on into the gap.
  const passingInto = (p, q, t) => {
    const L = dist(p, q) || 1;
    const u = [(q[0] - p[0]) / L, (q[1] - p[1]) / L];
    // Only across a gap wider than a doorway: a corridor's width (a door beside a wall's end is not one).
    return (L > 2000 ? [0, 150, 300, 450] : [0]).some((k) => k < L / 2 && passing([p[0] + u[0] * k, p[1] + u[1] * k], t));
  };
  const canJoin = (a, b, t, la, lb) => Math.max(la, lb) >= Math.max(t, 300) && !(passingInto(a, b, t) && passingInto(b, a, t));
  const joined = bridgeOpenings(kept, {}, { joinGap: 3000, loose: true, canJoin }).walls;
  const out = [...joined];
  // An end is closed where it meets another wall along that wall's run (a T); one wall's end beside another's
  // (a stub leaving its side at its end, an L) leaves it free, and carried on it stops at the first wall ahead.
  const touches = (p, self) =>
    joined.some((w) => {
      if (w === self || distToSeg(p, w.a, w.b) > w.thickness / 2 + 20) return false;
      const L = dist(w.a, w.b) || 1;
      const t = dot(sub(p, w.a), sub(w.b, w.a)) / L;
      return t > w.thickness / 2 + 20 && t < L - w.thickness / 2 - 20;
    });
  for (const w of joined) {
    const L = dist(w.a, w.b);
    // A short piece's line (a junction's corner, a jamb) is not worth carrying on across a room.
    if (L < Math.max(400, 1.5 * w.thickness)) continue;
    const u = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
    for (const [p, s] of [[w.a, -1], [w.b, 1]]) {
      if (touches(p, w)) continue;
      // The nearest other wall straight ahead within reach.
      let best = null;
      for (const o of joined) {
        if (o === w) continue;
        const t = rayToWall(p, [u[0] * s, u[1] * s], o);
        if (t != null && t > 0 && t <= reach && (!best || t < best)) best = t;
      }
      if (best) out.push({ a: p, b: [p[0] + u[0] * s * best, p[1] + u[1] * s * best], thickness: w.thickness });
    }
  }
  return out;
}

/**
 * Doors beside a corner: a doorway between a wall's free end and the face
 * of the wall it points at (a gap no two pieces of one wall bound, so
 * bridging along a wall's line misses it). From each free end, straight on
 * to the nearest wall's face; a gap 450 to 1400 mm that classify (as given
 * to bridgeOpenings) calls a door becomes one, and the wall is carried
 * across it to host it. Returns { walls, openings } (walls with the carried
 * ends; openings found here only).
 */
export function cornerDoors(walls, classify, { min = 450, max = 1400 } = {}) {
  const out = walls.map((w) => ({ ...w }));
  const openings = [];
  const touches = (p, self) => out.some((w) => w !== self && distToSeg(p, w.a, w.b) <= w.thickness / 2 + 20);
  for (const w of out) {
    const L = dist(w.a, w.b);
    if (L < Math.max(300, w.thickness)) continue;
    const u = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
    for (const end of ['a', 'b']) {
      const p = w[end];
      if (touches(p, w)) continue;
      const s = end === 'b' ? 1 : -1;
      const d = [u[0] * s, u[1] * s];
      // The nearest face straight ahead: the middle line less half the thickness, square on.
      let best = null;
      for (const o of out) {
        if (o === w) continue;
        const t = rayToWall(p, d, o);
        if (t == null || t <= 0) continue;
        const Lo = dist(o.a, o.b) || 1;
        const cos = Math.abs(dot(d, [-(o.b[1] - o.a[1]) / Lo, (o.b[0] - o.a[0]) / Lo]));
        const face = t - o.thickness / 2 / Math.max(cos, 0.2);
        if (!best || face < best) best = face;
      }
      if (!best || best < min || best > max + 400) continue;
      // The leaf may be narrower than the gap (a nib the drawing leaves beside it): against either side.
      let found = null;
      for (const f of [1, 0.9, 0.8, 0.7]) {
        const R = best * f;
        if (R < min || R > max) continue;
        for (const c of f === 1 ? [best / 2] : [R / 2, best - R / 2]) {
          const at = [p[0] + d[0] * c, p[1] + d[1] * c];
          if (classify({ at, width: R, d, n: [-d[1], d[0]], thickness: w.thickness }) === 'door') {
            found = { kind: 'door', at, width: R, d };
            break;
          }
        }
        if (found) break;
      }
      if (!found) continue;
      openings.push(found);
      w[end] = [p[0] + d[0] * best, p[1] + d[1] * best];
    }
  }
  return { walls: out, openings };
}

/**
 * Walls without those lying along another (parallel, inside its band but for
 * a quarter of their own thickness, mostly within its length): a wall drawn in
 * outline whose faces paired up more than one way (a slanted partition's two
 * lines and its hatch) gives several such, which would stack in the model.
 * The thicker, then longer, wall is kept.
 */
export function withoutOverlaps(walls) {
  const kept = [];
  const order = walls.map((w) => ({ w, L: dist(w.a, w.b) })).sort((p, q) => q.w.thickness - p.w.thickness || q.L - p.L);
  for (const { w, L } of order) {
    if (L < 1) continue;
    const u = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
    const lies = kept.some(({ w: o, L: Lo, u: uo }) => {
      if (Math.abs(u[0] * uo[1] - u[1] * uo[0]) > 0.05) return false;
      const m = [(w.a[0] + w.b[0]) / 2, (w.a[1] + w.b[1]) / 2];
      // Within the other's band, but for a quarter of its own thickness at most.
      if (Math.abs(dot(sub(m, o.a), [-uo[1], uo[0]])) + w.thickness / 2 > o.thickness / 2 + 0.25 * w.thickness) return false;
      const t0 = dot(sub(w.a, o.a), uo);
      const t1 = dot(sub(w.b, o.a), uo);
      const overlap = Math.min(Lo, Math.max(t0, t1)) - Math.max(0, Math.min(t0, t1));
      return overlap >= 0.8 * L;
    });
    if (!lies) kept.push({ w, L, u });
  }
  // In the order given.
  const set = new Set(kept.map((k) => k.w));
  return walls.filter((w) => set.has(w));
}

/**
 * Walls without the stubs (no longer than one and a half times their
 * thickness) that lie inside a longer wall's band: pieces of that wall's
 * drawing (a jamb's return, a junction) with no line of their own, which
 * would otherwise be taken as jambs across a room or carried on through it.
 */
export function withoutEmbeddedStubs(walls) {
  const stub = (w) => dist(w.a, w.b) < 1.5 * w.thickness;
  const long = walls.filter((w) => !stub(w));
  return walls.filter((w) => {
    if (!stub(w)) return true;
    const m = [(w.a[0] + w.b[0]) / 2, (w.a[1] + w.b[1]) / 2];
    return !long.some((o) => distToSeg(m, o.a, o.b) <= o.thickness / 2);
  });
}

function distToSeg(p, a, b) {
  const L2 = (b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 || 1;
  const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * (b[0] - a[0]) + (p[1] - a[1]) * (b[1] - a[1])) / L2));
  return Math.hypot(p[0] - a[0] - t * (b[0] - a[0]), p[1] - a[1] - t * (b[1] - a[1]));
}

/** Distance along a ray from p (unit dir d) to the far face of wall o's band, or null. */
export function rayToWall(p, d, o) {
  const L = dist(o.a, o.b) || 1;
  const ou = [(o.b[0] - o.a[0]) / L, (o.b[1] - o.a[1]) / L];
  const on = [-ou[1], ou[0]];
  const den = dot(d, on);
  if (Math.abs(den) < 0.2) return null;
  const off = dot(sub(p, o.a), on);
  // Reach the wall's middle line: its fill closes the rest.
  const t = -off / den;
  const hit = [p[0] + d[0] * t, p[1] + d[1] * t];
  const along = dot(sub(hit, o.a), ou);
  return along >= -o.thickness && along <= L + o.thickness ? t : null;
}

/**
 * The walls of the building itself: walls joined end to side (within reach)
 * form groups, and groups much smaller than the largest (a legend table's
 * shaded cells, a title block's frame) are left out. Returns { walls, box }
 * with the kept walls' extent.
 */
export function mainBuilding(walls, { reach = 1000, share = 0.1 } = {}) {
  const n = walls.length;
  const parent = walls.map((_, i) => i);
  const find = (i) => (parent[i] === i ? i : (parent[i] = find(parent[i])));
  const near = (p, w) => distToSeg(p, w.a, w.b) <= w.thickness / 2 + reach;
  for (let i = 0; i < n; i++)
    for (let j = i + 1; j < n; j++) {
      const a = walls[i];
      const b = walls[j];
      if (near(a.a, b) || near(a.b, b) || near(b.a, a) || near(b.b, a)) parent[find(i)] = find(j);
    }
  const size = new Map();
  walls.forEach((w, i) => size.set(find(i), (size.get(find(i)) || 0) + dist(w.a, w.b)));
  const top = Math.max(0, ...size.values());
  const kept = walls.filter((_, i) => size.get(find(i)) >= share * top);
  const xs = kept.flatMap((w) => [w.a[0], w.b[0]]);
  const ys = kept.flatMap((w) => [w.a[1], w.b[1]]);
  return { walls: kept, box: kept.length ? { x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) } : null };
}

/** Move a recognised plan by d (mm), in place: walls, openings, rooms with their outlines, columns. */
export function shiftRecognized(rec, d) {
  const m = (p) => [p[0] + d[0], p[1] + d[1]];
  for (const w of rec.plan.walls) Object.assign(w, { a: m(w.a), b: m(w.b) });
  for (const o of [...rec.plan.doors, ...rec.plan.windows]) o.at = m(o.at);
  for (const r of rec.plan.rooms) Object.assign(r, { at: m(r.at), ...(r.outline ? { outline: r.outline.map(m) } : {}) });
  for (const c of rec.columns || []) c.at = m(c.at);
  for (const r of rec.plan.rooms) if (r.tagAt) r.tagAt = m(r.tagAt);
  for (const o of rec.plan.doors) if (o.swing) o.swing = o.swing.map((s) => ({ ...s, hinge: m(s.hinge) }));
  for (const t of rec.labels || []) t.at = m(t.at);
  for (const x of rec.dimensions || []) Object.assign(x, { a: m(x.a), b: m(x.b) });
  return rec;
}

/** The middle of a recognised plan's walls (mm). */
export function recognizedMiddle(rec) {
  const pts = rec.plan.walls.flatMap((w) => [w.a, w.b]);
  if (!pts.length) return [0, 0];
  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  return [(Math.min(...xs) + Math.max(...xs)) / 2, (Math.min(...ys) + Math.max(...ys)) / 2];
}

const AREA_RE = /^\s*\d{1,5}([.,]\d{1,3})?\s*(m²|m2|м²|м2|mq|мкв)?\s*$/i;
const CODE_RE = /^[\p{L}\d]{1,4}([.\-/][\p{L}\d]{1,4})*$/u;

/** A zone code: digits (12, 2A, 1.1), letters split by a point (A.B), or one letter (B). */
export function isZoneCode(x) {
  const t = String(x).trim();
  return CODE_RE.test(t) && (/\d/.test(t) || /[.\-/]/.test(t) || t.length === 1);
}

/**
 * Room names from a drawing's room schedule (a legend table: number, name,
 * area per row; two tables side by side read as well): Map code -> name.
 * texts: [{ at, text, size }], at the text's start.
 */
export function legendNames(texts) {
  const out = new Map();
  const items = texts.filter((t) => t.text && t.text.trim()).map((t) => ({ ...t, text: t.text.trim() })).sort((a, b) => b.at[1] - a.at[1]);
  // Rows: texts at about one height.
  const rows = [];
  for (const t of items) {
    const tol = (t.size || 1) * 0.6;
    const row = rows.find((r) => Math.abs(r.y - t.at[1]) <= tol);
    if (row) row.cells.push(t);
    else rows.push({ y: t.at[1], cells: [t] });
  }
  for (const r of rows) {
    const cells = r.cells.sort((a, b) => a.at[0] - b.at[0]);
    for (let i = 0; i + 1 < cells.length; i++) {
      const code = cells[i].text;
      const name = cells[i + 1].text;
      // A code: digits (12, 2A, 1.1), or letters split by a point (A.B), or one letter (B).
      if (!isZoneCode(code)) continue;
      // A name: a word of three letters or more, not an area or a numbered code (Холл is a name, 2A is not).
      if (AREA_RE.test(name) || (CODE_RE.test(name) && /\d/.test(name)) || !/\p{L}{3,}/u.test(name)) continue;
      // A name next to its code, with the row's area after it when there is one.
      const after = cells[i + 2];
      const gap = cells[i + 1].at[0] - cells[i].at[0];
      if (gap > (cells[i].size || 1) * 40) continue;
      if (after && !AREA_RE.test(after.text) && !(CODE_RE.test(after.text) && isZoneCode(after.text))) continue;
      if (!out.has(code)) out.set(code, name);
    }
  }
  return out;
}

/** Name the rooms that have a number but no name from a drawing's legend (in place). */
export function nameRoomsFromLegend(rooms, texts) {
  const names = legendNames(texts);
  let named = 0;
  for (const r of rooms) {
    if (r.number && (!r.name || r.name === 'Room') && names.has(String(r.number))) {
      r.name = names.get(String(r.number));
      named++;
    }
  }
  return named;
}

/**
 * What a drawing writes, added to a view (inside a transaction): its dimensions, tied to the walls they measure, with
 * the written figure where it differs from the model, and its other texts. Returns { dimensions, texts }.
 */
export function addRecognizedAnnotations(doc, rec, viewId, interiorDimension) {
  const walls = doc.all('wall');
  // Texts and tags read at the drawing's own scale.
  if (rec.scale > 0) doc.update(viewId, { scale: rec.scale });
  // Windows drawn dashed lie above the sheet's cut: the plan is cut under the lowest sill.
  const sills = (rec.plan.windows || []).filter((o) => o.aboveCut && o.sill > 0).map((o) => o.sill);
  if (sills.length && Math.min(...sills) <= 1200) doc.update(viewId, { cutHeight: Math.min(1100, Math.min(...sills) - 50) });
  let dimensions = 0;
  for (const x of rec.dimensions || []) {
    const L = dist(x.a, x.b) || 1;
    const u = [(x.b[0] - x.a[0]) / L, (x.b[1] - x.a[1]) / L];
    const over = 120;
    const tied = interiorDimension?.(doc, walls, [x.a[0] - u[0] * over, x.a[1] - u[1] * over], [x.b[0] + u[0] * over, x.b[1] + u[1] * over], viewId);
    const dim = tied && tied.refs.length === 2 ? tied : { kind: 'dimension', viewId, dir: u, line: x.a, refs: [{ at: x.a }, { at: x.b }] };
    const measured = dist(dim.refs[0].at, dim.refs[1].at);
    doc.add({ ...dim, ...(Math.abs(measured - x.value) > 5 ? { override: x.text } : {}) });
    dimensions++;
  }
  let texts = 0;
  for (const t of rec.labels || []) {
    const rotation = (t.angle * 180) / Math.PI;
    doc.add({ kind: 'text', viewId, at: t.at, text: t.text, size: Math.round(t.size * 10) / 10, rotation, align: 'left', leaders: [] });
    texts++;
  }
  return { dimensions, texts };
}
