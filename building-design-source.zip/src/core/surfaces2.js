/**
 * Surface attributes of a material: a texture picture laid on the faces of
 * that colour, by box mapping at the material's texture size.
 *
 *   material.surface = { image: data URL, w, h (mm), angle (degrees), shininess, reflection }
 */
const near = (a, b) => Math.abs(a - b) <= 1;

/** The texture coordinates of a point on a face with a normal, by the axis it faces. */
export function boxUV(p, n, surface) {
  const w = +surface.w || 1000;
  const h = +surface.h || 1000;
  const ax = Math.abs(n[0]);
  const ay = Math.abs(n[1]);
  const az = Math.abs(n[2]);
  let [u, v] = az >= ax && az >= ay ? [p[0], p[1]] : ax >= ay ? [p[1], p[2]] : [p[0], p[2]];
  const a = ((+surface.angle || 0) * Math.PI) / 180;
  if (a) [u, v] = [u * Math.cos(a) - v * Math.sin(a), u * Math.sin(a) + v * Math.cos(a)];
  return [u / w, v / h];
}

const hexRGB = (c) => [parseInt(c.slice(1, 3), 16), parseInt(c.slice(3, 5), 16), parseInt(c.slice(5, 7), 16)];

/** The textured materials of a project: [{ rgb, surface }]. */
export function texturedMaterials(doc) {
  return doc.all('material').filter((m) => m.surface?.image && /^#[0-9a-f]{6}/i.test(m.color || '')).map((m) => ({ rgb: hexRGB(m.color), surface: m.surface }));
}

/** A mesh with the triangles of textured materials moved to textured groups; the same mesh when none match. */
export function applySurfaceTextures(mesh, materials) {
  if (!mesh?.pos?.length || !materials.length) return mesh;
  const nv = mesh.pos.length / 3;
  const per = mesh.col.length / nv;
  const groups = new Map();
  const keep = [];
  for (let t = 0; t < nv; t += 3) {
    const c = [mesh.col[t * per], mesh.col[t * per + 1], mesh.col[t * per + 2]];
    const m = materials.find((x) => near(x.rgb[0], c[0]) && near(x.rgb[1], c[1]) && near(x.rgb[2], c[2]));
    if (m) groups.set(m, [...(groups.get(m) || []), t]);
    else keep.push(t);
  }
  if (!groups.size) return mesh;
  const pos = new Float32Array(keep.length * 9);
  const nrm = new Int8Array(keep.length * 9);
  const col = new Uint8Array(keep.length * 3 * per);
  keep.forEach((t, i) => {
    pos.set(mesh.pos.subarray(t * 3, (t + 3) * 3), i * 9);
    nrm.set(mesh.nrm.subarray(t * 3, (t + 3) * 3), i * 9);
    col.set(mesh.col.subarray(t * per, (t + 3) * per), i * 3 * per);
  });
  const tex = [...(mesh.tex || [])];
  for (const [m, list] of groups) {
    const gp = new Float32Array(list.length * 9);
    const gn = new Int8Array(list.length * 9);
    const uv = new Float32Array(list.length * 6);
    list.forEach((t, i) => {
      for (let v = 0; v < 3; v++) {
        const at = (t + v) * 3;
        const p = [mesh.pos[at], mesh.pos[at + 1], mesh.pos[at + 2]];
        const n = [mesh.nrm[at], mesh.nrm[at + 1], mesh.nrm[at + 2]];
        gp.set(p, (i * 3 + v) * 3);
        gn.set(n, (i * 3 + v) * 3);
        uv.set(boxUV(p, n, m.surface), (i * 3 + v) * 2);
      }
    });
    tex.push({ src: m.surface.image, pos: gp, nrm: gn, uv, col: new Uint8Array(list.length * 12).fill(255) });
  }
  return { ...mesh, pos, nrm, col, tex };
}
