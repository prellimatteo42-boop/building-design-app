/**
 * Building materials, as in Archicad: besides how a material looks, it
 * carries an intersection priority and physical properties.
 *
 *   - priority (0-999): how layers of this material meet where walls join
 *     (layerjoins.js). A layer's own priority wins over its material's, and
 *     the material's over the layer function's.
 *   - conductivity λ in W/(m·K), density ρ in kg/m³, heat capacity c in
 *     J/(kg·K); or a fixed thermal resistance R in m²·K/W for layers that
 *     are not a solid material (air spaces, stud cavities).
 *
 * From these a layered type has a thermal transmittance U (EN ISO 6946, plane
 * layers without thermal bridges) and a mass per area.
 */

/** Defaults of the catalog materials: [priority, λ, ρ, c] or { r } for a fixed resistance. */
const DATA = {
  'mat-concrete': [850, 2.3, 2400, 1000],
  'mat-masonry-brick': [700, 0.77, 1800, 1000],
  'mat-cmu': [800, 0.9, 1400, 1000],
  'mat-gypsum': [200, 0.25, 900, 1000],
  'mat-stud': [750, { r: 0.17 }, 50, 450],
  'mat-wood-frame': [750, 0.13, 500, 1600],
  'mat-insulation': [400, 0.035, 30, 1030],
  'mat-sheathing': [600, 0.13, 500, 1600],
  'mat-air': [400, { r: 0.18 }, 1.2, 1000],
  'mat-membrane': [100, 0.17, 980, 1800],
  'mat-plaster': [200, 1.0, 1800, 1000],
  'mat-siding': [200, 0.13, 500, 1600],
  'mat-wood': [750, 0.18, 700, 1600],
  'mat-wood-light': [750, 0.15, 600, 1600],
  'mat-steel': [900, 50, 7800, 450],
  'mat-aluminum': [900, 160, 2800, 880],
  'mat-glass': [500, 1.0, 2500, 750],
  'mat-roofing': [200, 0.23, 1100, 1000],
  'mat-roof-metal': [200, 50, 7800, 450],
  'mat-tile': [200, 1.3, 2300, 840],
  'mat-carpet': [150, 0.06, 200, 1300],
  'mat-timber-floor': [200, 0.18, 700, 1600],
  'mat-acoustic': [200, 0.06, 300, 1000],
  'mat-paint-white': [100, 0.2, 1200, 1000],
  'mat-door': [500, 0.13, 500, 1600],
  'mat-fabric': [100, 0.06, 200, 1300],
  'mat-fabric-warm': [100, 0.06, 200, 1300],
  'mat-porcelain': [200, 1.3, 2300, 840],
  'mat-stone': [600, 2.8, 2600, 1000],
  'mat-earth': [950, 1.5, 1500, 1800],
};

/** Physical fields of a catalog material, to merge into it. */
export function materialDefaults(id) {
  const d = DATA[id];
  if (!d) return {};
  const [priority, k, density, heatCapacity] = d;
  return typeof k === 'object' ? { priority, resistance: k.r, density, heatCapacity } : { priority, conductivity: k, density, heatCapacity };
}

const num = (v) => (v !== undefined && v !== null && v !== '' && Number.isFinite(+v) ? +v : null);

/** A material's intersection priority, or null when it has none. */
export function materialPriority(m) {
  const p = num(m?.priority);
  return p === null ? null : Math.max(0, Math.min(999, p));
}

/** Inside and outside surface resistances (m²·K/W) per type kind, EN ISO 6946. */
export const SURFACE_RESISTANCE = { wallType: [0.13, 0.04], roofType: [0.1, 0.04], floorType: [0.17, 0.04], ceilingType: [0.1, 0.1] };

/** Thermal resistance of one layer in m²·K/W, or null when its material lacks the data. */
export function layerResistance(doc, layer) {
  const m = doc.get(layer.materialId);
  const r = num(m?.resistance);
  if (r !== null) return r;
  const k = num(m?.conductivity);
  const d = (+layer.thickness || 0) / 1000;
  return k && k > 0 ? d / k : null;
}

/**
 * Thermal data of a layered type: { r, u, mass, missing } with r the total
 * resistance surface to surface (m²·K/W), u the transmittance (W/(m²·K)), mass
 * in kg/m², and the names of materials without data (u and r are then null).
 */
export function thermalProperties(doc, type) {
  const layers = type?.layers;
  if (!layers?.length) return null;
  const [rsi, rse] = SURFACE_RESISTANCE[type.kind] ?? SURFACE_RESISTANCE.wallType;
  let r = rsi + rse;
  let mass = 0;
  const missing = [];
  for (const l of layers) {
    const lr = layerResistance(doc, l);
    const m = doc.get(l.materialId);
    if (lr === null) {
      const name = m?.name ?? 'a layer without material';
      if (!missing.includes(name)) missing.push(name);
    } else r += lr;
    mass += (num(m?.density) ?? 0) * ((+l.thickness || 0) / 1000);
  }
  if (missing.length) return { r: null, u: null, mass, missing };
  return { r, u: 1 / r, mass, missing };
}

/** "0.27 W/(m²·K)", or '' when it cannot be computed. */
export function uValueLabel(doc, type) {
  const t = thermalProperties(doc, type);
  return t?.u ? `${t.u.toFixed(2)} W/(m²·K)` : '';
}
