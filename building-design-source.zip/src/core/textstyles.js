/**
 * Text styles: named looks for text notes (height on paper, bold,
 * alignment), so notes that share a style change together, as with
 * Archicad's favourite text settings.
 *
 *   textStyle { kind: 'textStyle', name, size (mm on paper), bold, align }
 *   text      styleId, optional: without one, its own size, bold and align
 */
export function defaultTextStyles() {
  return [
    { id: 'ts-notes', kind: 'textStyle', name: 'Notes', size: 2.5, bold: false, align: 'left' },
    { id: 'ts-labels', kind: 'textStyle', name: 'Labels', size: 1.8, bold: false, align: 'left' },
    { id: 'ts-rooms', kind: 'textStyle', name: 'Room Names', size: 3.5, bold: true, align: 'center' },
    { id: 'ts-titles', kind: 'textStyle', name: 'Titles', size: 5, bold: true, align: 'left' },
  ];
}

/** How a text note looks: its style's settings, else its own. */
export function textLook(doc, el) {
  const st = el?.styleId ? doc.get(el.styleId) : null;
  if (st?.kind === 'textStyle') return { size: +st.size || 2.5, bold: !!st.bold, align: st.align || 'left' };
  return { size: +el.size || 2.5, bold: !!el.bold, align: el.align || 'left' };
}
