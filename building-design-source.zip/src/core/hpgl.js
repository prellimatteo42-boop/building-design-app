/**
 * Plot (Archicad's Plot and Plot Setup, reimplemented for any HP-GL/2 plotter):
 * a drawing in paper millimetres written as an HP-GL/2 plot file (.plt) for a
 * roll plotter. Lines go to pens by their width, fills are filled polygons
 * (light grey on pen 8 unless dark), text is labels.
 *
 *   setup { roll (paper roll width, mm), rotate: 'auto' | 'never' | 'always', margin (mm), copies,
 *           pens: [{ pen, upTo (mm) }] }  pen n draws lines up to its width
 */

export const ROLLS = [
  { value: 610, label: '610 mm (24")' },
  { value: 841, label: '841 mm (A0 short side)' },
  { value: 914, label: '914 mm (36")' },
  { value: 1067, label: '1067 mm (42")' },
  { value: 1118, label: '1118 mm (44")' },
];

export const PLOT_DEFAULTS = {
  roll: 914,
  rotate: 'auto',
  margin: 5,
  copies: 1,
  pens: [
    { pen: 1, upTo: 0.13 },
    { pen: 2, upTo: 0.18 },
    { pen: 3, upTo: 0.25 },
    { pen: 4, upTo: 0.35 },
    { pen: 5, upTo: 0.5 },
    { pen: 6, upTo: 0.7 },
    { pen: 7, upTo: 99 },
  ],
};

const PU_PER_MM = 40; // HP-GL plotter units: 0.025 mm

/** The pen for a line width (mm) and the width the pen is set to. */
export function penFor(setup, w) {
  const pens = (setup.pens || PLOT_DEFAULTS.pens).slice().sort((a, b) => a.upTo - b.upTo);
  return (pens.find((p) => w <= p.upTo + 1e-9) || pens.at(-1)).pen;
}

/** Whether the sheet is turned a quarter to fit the roll: its width along the roll's length. */
export function plotRotated(setup, w, h) {
  if (setup.rotate === 'always') return true;
  if (setup.rotate === 'never') return false;
  const roll = (+setup.roll || 914) - 2 * (+setup.margin || 0);
  // Across the roll goes the sheet's height; turned when only its height fits along the roll and its width does not across.
  return h > roll && w <= roll;
}

/**
 * The plot file. drawing { w, h (paper mm), lines: [{ a, b, w, dash }], fills: [{ poly, holes, rgb, a }],
 * texts: [{ text, at, size, rot }] } in paper millimetres. Returns { text, rotated, length (mm of roll) }.
 */
export function writeHPGL(drawing, setup = {}) {
  const s = { ...PLOT_DEFAULTS, ...setup };
  const rot = plotRotated(s, drawing.w, drawing.h);
  const m = +s.margin || 0;
  // Plotter x runs along the roll (its length), y across it.
  const T = rot ? (p) => [p[1] + m, drawing.w - p[0] + m] : (p) => [p[0] + m, p[1] + m];
  const pu = (p) => {
    const q = T(p);
    return `${Math.round(q[0] * PU_PER_MM)},${Math.round(q[1] * PU_PER_MM)}`;
  };
  const length = (rot ? drawing.h : drawing.w) + 2 * m;
  const width = (rot ? drawing.w : drawing.h) + 2 * m;
  const out = ['\x1bE\x1b%-1B', 'BP1,"Building Design";', 'IN;', `PS${Math.round(length * PU_PER_MM)},${Math.round(width * PU_PER_MM)};`, 'RO0;', 'IP;', 'SC;', 'TR0;', 'WU0;'];
  // Pen widths.
  for (const p of s.pens) out.push(`PW${Math.min(p.upTo, 2).toFixed(2)},${p.pen};`);
  out.push('NP8;', 'PC8,200,200,200;');
  // Fills first, then lines grouped by pen, text last.
  for (const f of drawing.fills || []) {
    if (!f.poly?.length || (f.a ?? 1) < 0.05) continue;
    const dark = f.rgb && 0.299 * f.rgb[0] + 0.587 * f.rgb[1] + 0.114 * f.rgb[2] < 0.35;
    out.push(`SP${dark ? 7 : 8};`, `PU${pu(f.poly[0])};`, 'PM0;', `PD${f.poly.slice(1).map(pu).join(',')},${pu(f.poly[0])};`);
    for (const hole of f.holes || []) if (hole.length > 2) out.push('PM1;', `PU${pu(hole[0])};`, `PD${hole.slice(1).map(pu).join(',')},${pu(hole[0])};`);
    out.push('PM2;', 'FP;');
  }
  const byPen = new Map();
  for (const l of drawing.lines || []) {
    const pen = penFor(s, l.w || 0.18);
    if (!byPen.has(pen)) byPen.set(pen, []);
    byPen.get(pen).push(l);
  }
  for (const [pen, ls] of [...byPen].sort((a, b) => a[0] - b[0])) {
    out.push(`SP${pen};`);
    let dashed = null;
    for (const l of ls) {
      const d = l.dash ? 'LT2,4,1;' : 'LT;';
      if (d !== dashed) out.push(d), (dashed = d);
      out.push(`PU${pu(l.a)};PD${pu(l.b)};`);
    }
  }
  if (drawing.texts?.length) {
    out.push('SP7;', 'DT\x03;');
    for (const t of drawing.texts) {
      const hcm = Math.max(0.05, (+t.size || 2.5) / 10);
      const a = (((t.rot || 0) + (rot ? 90 : 0)) * Math.PI) / 180;
      out.push(`SI${(hcm * 0.7).toFixed(3)},${hcm.toFixed(3)};`, `DI${Math.cos(a).toFixed(4)},${Math.sin(a).toFixed(4)};`, `PU${pu(t.at)};`, `LB${String(t.text).replace(/[\x00-\x1f\x03]/g, ' ')}\x03`);
    }
  }
  out.push('SP0;', 'PG;', `\x1b%0A\x1bE`);
  // Copies: the page again.
  const one = out.join('\n');
  const copies = Math.max(1, Math.min(50, Math.round(+s.copies || 1)));
  return { text: Array(copies).fill(one).join('\n'), rotated: rot, length, width };
}
