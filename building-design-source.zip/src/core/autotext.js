/**
 * Autotext of labels, as in Archicad: a label's text is a template whose
 * {Field} tokens take the values of the labelled element (the fields of its
 * schedule category, by label or id) or of the project, formatted in the
 * project's units. Example: "{Name}\n{Area}" on a room.
 */
import { SCHEDULE_CATEGORIES, formatCell } from './schedule.js';
import { levelOf } from './model.js';
import { paramFieldsFor } from './params.js';
import { classOf, classLabel } from './classify.js';

const PROJECT_FIELDS = [
  { id: 'projectName', label: 'Project Name', get: (doc) => doc.project?.name ?? '' },
  { id: 'projectNumber', label: 'Project Number', get: (doc) => doc.project?.number ?? '' },
  { id: 'client', label: 'Client', get: (doc) => doc.project?.client ?? '' },
  { id: 'date', label: 'Date', get: () => new Date().toISOString().slice(0, 10) },
];

/** Default template of an autotext label, by the kind of element it labels. */
export const AUTOTEXT_DEFAULTS = {
  room: '{Name}\n{Area}',
  door: '{Mark}\n{Width} x {Height}',
  window: '{Mark}\n{Width} x {Height}',
  wall: '{Type}\n{Width}',
  floor: '{Type}\n{Area}',
  component: '{Type}',
};

function categoryOfKind(kind) {
  return Object.values(SCHEDULE_CATEGORIES).find((c) => c.kinds?.includes(kind)) || null;
}

/** The fields an element's autotext can use: [{ id, label, type }]; with doc, its project parameters too. */
export function autotextFields(el, doc = null) {
  const cat = el ? categoryOfKind(el.kind) : null;
  const own = (cat?.fields || []).filter((f) => f.id !== 'count');
  const names = new Set(own.map((f) => f.label.toLowerCase()));
  const extra = [
    { id: 'level', label: 'Level', type: 'text', get: (e, c) => levelOf(c.doc, e)?.name ?? '' },
    { id: 'mark', label: 'Mark', type: 'text', get: (e, c) => e.mark ?? c.doc.get(e.typeId)?.mark ?? '' },
    { id: 'type', label: 'Type', type: 'text', get: (e, c) => c.doc.get(e.typeId)?.name ?? '' },
    { id: 'classification', label: 'Classification', type: 'text', get: (e, c) => classLabel(classOf(c.doc, e, c.doc.all('classSystem')[0])) },
  ].filter((f) => !names.has(f.label.toLowerCase()));
  const params = doc && el ? paramFieldsFor(doc, el) : [];
  return [...own, ...extra, ...params, ...PROJECT_FIELDS.map((f) => ({ ...f, type: 'text', project: true }))];
}

/**
 * The text of a template for an element. ctx: { doc, scene } where scene
 * gives rooms and areas (a plan context's will do). Unknown fields show
 * as "?" so a mistyped token is visible.
 */
export function resolveAutotext(ctx, el, template) {
  const fields = autotextFields(el, ctx.doc);
  return String(template ?? '').replace(/\{([^{}]+)\}/g, (_, key) => {
    const k = key.trim().toLowerCase();
    const f = fields.find((x) => x.label.toLowerCase() === k || x.id.toLowerCase() === k);
    if (!f) return '?';
    let v;
    try {
      v = f.project ? f.get(ctx.doc) : f.get(el, ctx);
    } catch {
      v = '';
    }
    return formatCell(f, v, ctx.doc.units);
  });
}
