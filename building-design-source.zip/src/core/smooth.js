/**
 * Smooth shading for curved objects: a mesh's corners that belong to the same surface share one normal, averaged over the
 * faces that meet there and turn less than a crease angle, so pillows and lamps look round and boxes keep their edges.
 */
const CREASE = Math.cos((38 * Math.PI) / 180);

/** The same mesh with its normals smoothed (mesh.pos: 9 numbers a triangle; mesh.nrm: 9 bytes), or the mesh itself when nothing changes. */
export function smoothNormals(mesh) {
  const n = (mesh?.pos?.length || 0) / 9;
  if (!n || n > 400000) return mesh;
  const P = mesh.pos;
  // Corners at the same place, to a tenth of a millimetre.
  const at = new Map();
  const faces = new Float32Array(n * 3);
  for (let t = 0; t < n; t++) {
    const a = 9 * t;
    const [ux, uy, uz] = [P[a + 3] - P[a], P[a + 4] - P[a + 1], P[a + 5] - P[a + 2]];
    const [vx, vy, vz] = [P[a + 6] - P[a], P[a + 7] - P[a + 1], P[a + 8] - P[a + 2]];
    // Length left in: larger faces count for more.
    faces[3 * t] = uy * vz - uz * vy;
    faces[3 * t + 1] = uz * vx - ux * vz;
    faces[3 * t + 2] = ux * vy - uy * vx;
    for (let c = 0; c < 3; c++) {
      const q = a + 3 * c;
      const key = `${Math.round(P[q] * 10)},${Math.round(P[q + 1] * 10)},${Math.round(P[q + 2] * 10)}`;
      let list = at.get(key);
      if (!list) at.set(key, (list = []));
      list.push(t);
    }
  }
  const nrm = new Int8Array(mesh.nrm);
  const len = (t) => Math.hypot(faces[3 * t], faces[3 * t + 1], faces[3 * t + 2]) || 1;
  let changed = false;
  for (let t = 0; t < n; t++) {
    const lt = len(t);
    for (let c = 0; c < 3; c++) {
      const q = 9 * t + 3 * c;
      const key = `${Math.round(P[q] * 10)},${Math.round(P[q + 1] * 10)},${Math.round(P[q + 2] * 10)}`;
      let [x, y, z] = [0, 0, 0];
      for (const o of at.get(key)) {
        const cos = (faces[3 * t] * faces[3 * o] + faces[3 * t + 1] * faces[3 * o + 1] + faces[3 * t + 2] * faces[3 * o + 2]) / (lt * len(o));
        if (cos < CREASE) continue;
        x += faces[3 * o];
        y += faces[3 * o + 1];
        z += faces[3 * o + 2];
      }
      const m = Math.hypot(x, y, z);
      if (!m) continue;
      const [nx, ny, nz] = [Math.round((x / m) * 127), Math.round((y / m) * 127), Math.round((z / m) * 127)];
      // The face's own winding decides which side is out; the stored normal may have been turned to face out.
      const flip = nrm[q] * (faces[3 * t] / lt) + nrm[q + 1] * (faces[3 * t + 1] / lt) + nrm[q + 2] * (faces[3 * t + 2] / lt) < 0 ? -1 : 1;
      const v = [nx * flip, ny * flip, nz * flip];
      if (v[0] !== nrm[q] || v[1] !== nrm[q + 1] || v[2] !== nrm[q + 2]) changed = true;
      nrm.set(v, q);
    }
  }
  return changed ? { ...mesh, nrm } : mesh;
}
