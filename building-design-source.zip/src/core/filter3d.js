/**
 * Filter Elements in 3D, as in Archicad: a 3D view shows only the stories
 * from one to another (by the story elements stand on, doors and windows
 * by their wall's), so a building can be looked at floor by floor.
 *
 *   view3d.storyFilter: { from: levelId | null, to: levelId | null }
 */
import { levelOf } from './model.js';

/** Whether an element is left out of a 3D view by its story filter. */
export function hiddenByStoryFilter(doc, view, el) {
  const f = view?.kind === 'view3d' ? view.storyFilter : null;
  if (!f || (!f.from && !f.to)) return false;
  const lv = levelOf(doc, el.hostId ? doc.get(el.hostId) || el : el);
  if (!lv) return false;
  const lo = f.from ? doc.get(f.from)?.elevation ?? -Infinity : -Infinity;
  const hi = f.to ? doc.get(f.to)?.elevation ?? Infinity : Infinity;
  return lv.elevation < Math.min(lo, hi) - 1e-6 || lv.elevation > Math.max(lo, hi) + 1e-6;
}
