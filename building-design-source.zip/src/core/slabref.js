/**
 * Slab reference plane, as in Archicad: a slab's height is read and set at its top, at the top or bottom of its
 * core, or at its bottom. Changing the reference plane (Modify Slab Reference Plane) does not move the slab:
 * only the plane its elevation is measured at changes. Internally a slab's `offset` stays its top.
 *
 *   floor.refPlane = 'top' | 'coreTop' | 'coreBottom' | 'bottom'
 */
import { typeThickness } from './catalog.js';

export const SLAB_REF_PLANES = [
  { value: 'top', label: 'Top' },
  { value: 'coreTop', label: 'Core Top' },
  { value: 'coreBottom', label: 'Core Bottom' },
  { value: 'bottom', label: 'Bottom' },
];

/** Depth (mm) of a reference plane below the slab's top, for its type (layers listed from the top). */
export function refPlaneDepth(type, plane = 'top') {
  const layers = type?.layers || [];
  const total = typeThickness(type) || layers.reduce((t, l) => t + (+l.thickness || 0), 0) || 300;
  if (plane === 'bottom') return total;
  if (plane === 'top' || !layers.length) return plane === 'coreBottom' ? total : 0;
  let core = layers.findIndex((l) => l.function === 'structure');
  if (core < 0) core = layers.reduce((b, l, i) => ((+l.thickness || 0) > (+layers[b].thickness || 0) ? i : b), 0);
  let end = core;
  while (end + 1 < layers.length && layers[end + 1].function === 'structure') end++;
  const above = layers.slice(0, core).reduce((t, l) => t + (+l.thickness || 0), 0);
  if (plane === 'coreTop') return above;
  return above + layers.slice(core, end + 1).reduce((t, l) => t + (+l.thickness || 0), 0);
}

/** Elevation of the slab's reference plane above its level (mm). */
export const refOffset = (slab, type) => (+slab.offset || 0) - refPlaneDepth(type, slab.refPlane);

/** The slab's offset (its top) for a reference plane elevation. */
export const offsetForRef = (slab, type, v) => +v + refPlaneDepth(type, slab.refPlane);
