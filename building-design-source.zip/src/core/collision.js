/**
 * Collision Detection, as in Archicad: pairs of elements, one from each of
 * two groups, whose 3D bodies overlap by more than a volume tolerance. The
 * overlap is the CSG intersection of the bodies (csg.js), after a bounding
 * box test. Elements and the walls hosting them are not checked against
 * each other, and an element never against itself.
 */
import { meshPolygons, intersect } from './csg.js';

function polysVolume(polys) {
  let v = 0;
  for (const p of polys)
    for (let i = 1; i + 1 < p.vs.length; i++) {
      const [a, b, c] = [p.vs[0].p, p.vs[i].p, p.vs[i + 1].p];
      v += (a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0]) + a[2] * (b[0] * c[1] - b[1] * c[0])) / 6;
    }
  return v;
}

const overlaps = (a, b, pad = 0) => a.min.every((v, k) => v - pad <= b.max[k]) && b.min.every((v, k) => v - pad <= a.max[k]);

/**
 * Collisions between elements of groups A and B (arrays of elements):
 * [{ a, b, volume (mm³), center [x, y, z] }], largest first. meshOf(el)
 * gives an element's 3D body. tolerance in mm³.
 */
export function detectCollisions(groupA, groupB, meshOf, { tolerance = 1e6 } = {}) {
  const bodies = new Map();
  const body = (el) => {
    if (!bodies.has(el.id)) {
      const m = meshOf(el);
      bodies.set(el.id, m?.bounds && m.pos?.length ? { m, polys: null } : null);
    }
    return bodies.get(el.id);
  };
  const seen = new Set();
  const out = [];
  for (const a of groupA)
    for (const b of groupB) {
      if (a.id === b.id || a.hostId === b.id || b.hostId === a.id) continue;
      const key = a.id < b.id ? `${a.id}|${b.id}` : `${b.id}|${a.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const A = body(a);
      const B = body(b);
      if (!A || !B || !overlaps(A.m.bounds, B.m.bounds)) continue;
      A.polys ??= meshPolygons(A.m);
      B.polys ??= meshPolygons(B.m);
      const common = intersect(A.polys, B.polys);
      const volume = polysVolume(common);
      if (volume <= tolerance) continue;
      const min = [Infinity, Infinity, Infinity];
      const max = [-Infinity, -Infinity, -Infinity];
      for (const p of common)
        for (const v of p.vs)
          for (let k = 0; k < 3; k++) {
            min[k] = Math.min(min[k], v.p[k]);
            max[k] = Math.max(max[k], v.p[k]);
          }
      out.push({ a, b, volume, center: min.map((v, k) => (v + max[k]) / 2), min, max });
    }
  return out.sort((x, y) => y.volume - x.volume);
}
