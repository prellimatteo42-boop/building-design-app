/**
 * Expressions of expression-based properties, as in Archicad's Properties
 * Manager: arithmetic, comparison and logic over the values of an element's
 * fields, written {Field Name}, with functions such as IF, ROUND and CONCAT.
 * Lengths are in metres, areas in square metres and volumes in cubic metres,
 * whatever the project units. Parsed and evaluated here, never with eval.
 *
 *   {Area} * 1.1
 *   IF({Height} > 2.7, "High", "Standard")
 *   CONCAT({Number}, " - ", UPPER({Name}))
 */

const FUNCS = {
  IF: (c, a, b) => (truthy(c) ? a : b),
  AND: (...xs) => xs.every(truthy),
  OR: (...xs) => xs.some(truthy),
  NOT: (x) => !truthy(x),
  ROUND: (x, n = 0) => {
    const k = 10 ** num(n);
    return Math.round(num(x) * k) / k;
  },
  ROUNDUP: (x, n = 0) => Math.ceil(num(x) * 10 ** num(n)) / 10 ** num(n),
  ROUNDDOWN: (x, n = 0) => Math.floor(num(x) * 10 ** num(n)) / 10 ** num(n),
  ABS: (x) => Math.abs(num(x)),
  SQRT: (x) => Math.sqrt(num(x)),
  MIN: (...xs) => Math.min(...xs.map(num)),
  MAX: (...xs) => Math.max(...xs.map(num)),
  SUM: (...xs) => xs.reduce((s, x) => s + num(x), 0),
  AVERAGE: (...xs) => (xs.length ? xs.reduce((s, x) => s + num(x), 0) / xs.length : 0),
  PI: () => Math.PI,
  SIN: (x) => Math.sin((num(x) * Math.PI) / 180),
  COS: (x) => Math.cos((num(x) * Math.PI) / 180),
  TAN: (x) => Math.tan((num(x) * Math.PI) / 180),
  CONCAT: (...xs) => xs.map(str).join(''),
  UPPER: (x) => str(x).toUpperCase(),
  LOWER: (x) => str(x).toLowerCase(),
  LEFT: (x, n = 1) => str(x).slice(0, num(n)),
  RIGHT: (x, n = 1) => (num(n) > 0 ? str(x).slice(-num(n)) : ''),
  LEN: (x) => str(x).length,
  STR: (x, n) => (n == null ? str(x) : num(x).toFixed(num(n))),
  NUM: (x) => num(x),
  CONTAINS: (x, y) => str(x).toLowerCase().includes(str(y).toLowerCase()),
};

export const EXPRESSION_FUNCTIONS = Object.keys(FUNCS);

function truthy(v) {
  return typeof v === 'string' ? v !== '' && v.toLowerCase() !== 'no' && v.toLowerCase() !== 'false' : !!v;
}

function num(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'boolean') return v ? 1 : 0;
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : 0;
}

function str(v) {
  if (typeof v === 'number') return String(Math.round(v * 1e6) / 1e6);
  if (typeof v === 'boolean') return v ? 'Yes' : 'No';
  return v == null ? '' : String(v);
}

export class ExpressionError extends Error {}

function tokenize(src) {
  const out = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (/\s/.test(c)) {
      i++;
    } else if (c === '{') {
      const j = src.indexOf('}', i);
      if (j < 0) throw new ExpressionError('A { has no closing }');
      out.push({ t: 'field', v: src.slice(i + 1, j).trim() });
      i = j + 1;
    } else if (c === '"' || c === "'") {
      const j = src.indexOf(c, i + 1);
      if (j < 0) throw new ExpressionError('A text has no closing quote');
      out.push({ t: 'str', v: src.slice(i + 1, j) });
      i = j + 1;
    } else if (/[0-9.]/.test(c)) {
      const m = /^\d*\.?\d+(?:[eE][-+]?\d+)?|^\d+\./.exec(src.slice(i));
      if (!m) throw new ExpressionError(`Unexpected "${c}"`);
      out.push({ t: 'num', v: parseFloat(m[0]) });
      i += m[0].length;
    } else if (/[A-Za-z_]/.test(c)) {
      const m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(src.slice(i));
      const w = m[0].toUpperCase();
      if (w === 'TRUE' || w === 'FALSE') out.push({ t: 'bool', v: w === 'TRUE' });
      else if (w === 'AND' || w === 'OR' || w === 'NOT' || w === 'MOD') out.push(src[i + m[0].length]?.trim() === '(' && w !== 'MOD' ? { t: 'name', v: w } : { t: 'op', v: w });
      else out.push({ t: 'name', v: w });
      i += m[0].length;
    } else {
      const two = src.slice(i, i + 2);
      if (['<=', '>=', '<>', '!=', '==', '&&', '||'].includes(two)) {
        out.push({ t: 'op', v: { '!=': '<>', '==': '=', '&&': 'AND', '||': 'OR' }[two] || two });
        i += 2;
      } else if ('+-*/^%()=<>,&'.includes(c)) {
        out.push({ t: c === '(' || c === ')' || c === ',' ? c : 'op', v: c === '%' ? 'MOD' : c });
        i++;
      } else throw new ExpressionError(`Unexpected "${c}"`);
    }
  }
  return out;
}

const BIN = { OR: 1, AND: 2, '=': 3, '<>': 3, '<': 4, '>': 4, '<=': 4, '>=': 4, '&': 5, '+': 6, '-': 6, '*': 7, '/': 7, MOD: 7, '^': 9 };

/** Parse an expression into a tree; throws ExpressionError with a readable message. */
export function parseExpression(src) {
  const toks = tokenize(String(src ?? ''));
  let i = 0;
  const peek = () => toks[i];
  const expect = (t) => {
    if (toks[i]?.t !== t) throw new ExpressionError(`Expected "${t}"`);
    i++;
  };
  const primary = () => {
    const k = toks[i++];
    if (!k) throw new ExpressionError('The expression ends too early');
    if (k.t === 'num' || k.t === 'str' || k.t === 'bool') return { k: 'lit', v: k.v };
    if (k.t === 'field') return { k: 'field', name: k.v };
    if (k.t === '(') {
      const e = expr(0);
      expect(')');
      return e;
    }
    if (k.t === 'op' && (k.v === '-' || k.v === '+')) return { k: 'neg', sign: k.v, e: expr(9) };
    if (k.t === 'op' && k.v === 'NOT') return { k: 'call', fn: 'NOT', args: [expr(3)] };
    if (k.t === 'name') {
      if (!FUNCS[k.v]) throw new ExpressionError(`Unknown function ${k.v}`);
      const args = [];
      expect('(');
      if (peek()?.t !== ')') {
        args.push(expr(0));
        while (peek()?.t === ',') {
          i++;
          args.push(expr(0));
        }
      }
      expect(')');
      return { k: 'call', fn: k.v, args };
    }
    throw new ExpressionError(`Unexpected "${k.v ?? k.t}"`);
  };
  const expr = (min) => {
    let left = primary();
    for (;;) {
      const k = peek();
      const p = k?.t === 'op' ? BIN[k.v] : undefined;
      if (p === undefined || p < min) break;
      i++;
      left = { k: 'bin', op: k.v, a: left, b: expr(k.v === '^' ? p : p + 1) };
    }
    return left;
  };
  if (!toks.length) throw new ExpressionError('The expression is empty');
  const tree = expr(0);
  if (i < toks.length) throw new ExpressionError(`Unexpected "${toks[i].v ?? toks[i].t}"`);
  return tree;
}

/** Field names an expression reads. */
export function expressionFields(tree, out = new Set()) {
  if (!tree) return out;
  if (tree.k === 'field') out.add(tree.name);
  for (const c of [tree.a, tree.b, tree.e, ...(tree.args || [])]) if (c) expressionFields(c, out);
  return out;
}

/**
 * Evaluate a parsed expression. field(name) gives a field's value or
 * undefined when there is no such field (an error names it).
 */
export function evaluate(tree, field) {
  const ev = (n) => {
    switch (n.k) {
      case 'lit':
        return n.v;
      case 'field': {
        const v = field(n.name);
        if (v === undefined) throw new ExpressionError(`No field {${n.name}}`);
        return v;
      }
      case 'neg':
        return n.sign === '-' ? -num(ev(n.e)) : num(ev(n.e));
      case 'call':
        // IF only evaluates the branch it takes.
        if (n.fn === 'IF') return truthy(ev(n.args[0])) ? (n.args[1] ? ev(n.args[1]) : true) : n.args[2] ? ev(n.args[2]) : false;
        return FUNCS[n.fn](...n.args.map(ev));
      case 'bin': {
        const a = ev(n.a);
        if (n.op === 'AND') return truthy(a) && truthy(ev(n.b));
        if (n.op === 'OR') return truthy(a) || truthy(ev(n.b));
        const b = ev(n.b);
        const numeric = typeof a !== 'string' && typeof b !== 'string';
        switch (n.op) {
          case '+':
            return numeric ? num(a) + num(b) : str(a) + str(b);
          case '&':
            return str(a) + str(b);
          case '-':
            return num(a) - num(b);
          case '*':
            return num(a) * num(b);
          case '/':
            if (num(b) === 0) throw new ExpressionError('Division by zero');
            return num(a) / num(b);
          case 'MOD':
            return num(a) % num(b);
          case '^':
            return num(a) ** num(b);
          case '=':
            return numeric ? Math.abs(num(a) - num(b)) < 1e-9 : str(a).toLowerCase() === str(b).toLowerCase();
          case '<>':
            return numeric ? Math.abs(num(a) - num(b)) >= 1e-9 : str(a).toLowerCase() !== str(b).toLowerCase();
          case '<':
            return numeric ? num(a) < num(b) : str(a) < str(b);
          case '>':
            return numeric ? num(a) > num(b) : str(a) > str(b);
          case '<=':
            return numeric ? num(a) <= num(b) : str(a) <= str(b);
          case '>=':
            return numeric ? num(a) >= num(b) : str(a) >= str(b);
        }
      }
    }
    throw new ExpressionError('Bad expression');
  };
  return ev(tree);
}
