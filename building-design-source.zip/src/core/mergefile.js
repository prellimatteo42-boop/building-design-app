/**
 * Merge from File (Archicad's Merge, reimplemented): another project's
 * stories, views and attributes brought into this one, as chosen:
 *   levels      the source levels whose elements come (by id); their
 *               elements land on this project's level at the same height
 *               (a new level is made where none matches);
 *   views       the source's floor plans of those levels bring their
 *               annotations onto the matching plans here; other views
 *               (sections, details, drafting views, schedules) are added;
 *   attributes  every type, material, layer, fill, text style, profile,
 *               classification system and property the project lacks
 *               (by id, then by name), not only the ones the merged
 *               elements use;
 *   offset      [dx, dy, dz] moving the merged model.
 */
import { newId } from './doc.js';
import { MODEL_KINDS } from './scene.js';
import { transformPatch, translation } from './ops.js';

const MODEL = new Set(MODEL_KINDS);
const VIEW_KINDS = new Set(['plan', 'ceilingPlan', 'areaPlan', 'section', 'elevation', 'drafting', 'legend', 'schedule', 'view3d']);
const ATTRIBUTE_KINDS = ['material', 'layer', 'fillType', 'textStyle', 'profile', 'classSystem', 'propertyGroup', 'projectParam', 'zoneCategory', 'lineStyle', 'phase'];

/** What a project file offers for merging: { levels: [{ id, name, elevation, count }], views: [{ id, name, kind }] }. */
export function mergeOptions(src) {
  const count = new Map();
  for (const el of src.items.values()) if (MODEL.has(el.kind) && el.levelId) count.set(el.levelId, (count.get(el.levelId) || 0) + 1);
  return {
    levels: src.levels().map((l) => ({ id: l.id, name: l.name, elevation: l.elevation, count: count.get(l.id) || 0 })),
    views: [...src.items.values()].filter((v) => VIEW_KINDS.has(v.kind) && !['plan', 'ceilingPlan'].includes(v.kind)).map((v) => ({ id: v.id, name: v.name, kind: v.kind })),
  };
}

/**
 * Merge (inside a transaction). opts { levels: [srcLevelId] (default all), views: true | [srcViewId], attributes: true,
 * offset: [dx, dy, dz] }. Returns { elements, annotations, views, levels (made), attributes }.
 */
export function mergeFromProject(doc, src, opts = {}) {
  const out = { elements: 0, annotations: 0, views: 0, levels: 0, attributes: 0 };
  const chosen = new Set(opts.levels || src.levels().map((l) => l.id));
  const [dx, dy, dz] = opts.offset || [0, 0, 0];
  const xf = dx || dy ? translation([dx, dy]) : null;
  const idMap = new Map();
  // Attributes: everything missing, or only what the merged elements use.
  const bring = (id) => {
    const it = id && src.get(id);
    if (!it || doc.has(id) || idMap.has(id)) return;
    const same = it.name && doc.all(it.kind).find((x) => x.name === it.name);
    if (same) {
      idMap.set(id, same.id);
      return;
    }
    doc.add({ ...structuredClone(it) });
    out.attributes++;
    for (const l of it.layers || []) bring(l.materialId);
    for (const k of ['materialId', 'panelMaterialId', 'frameMaterialId', 'profileId']) if (it[k]) bring(it[k]);
  };
  if (opts.attributes !== false) {
    for (const k of ATTRIBUTE_KINDS) for (const it of src.all(k)) bring(it.id);
    for (const it of src.items.values()) if (it.kind.endsWith('Type')) bring(it.id);
  }
  // Levels by height.
  const levelMap = new Map();
  for (const lv of src.levels()) {
    if (!chosen.has(lv.id)) continue;
    const z = lv.elevation + dz;
    let mine = doc.levels().find((l) => Math.abs(l.elevation - z) < 1);
    if (!mine) {
      mine = doc.add({ kind: 'level', name: lv.name, elevation: z });
      doc.add({ kind: 'plan', name: mine.name, levelId: mine.id, scale: 100, detail: 'medium' });
      out.levels++;
    }
    levelMap.set(lv.id, mine.id);
  }
  // Model elements of the chosen levels, hosts first.
  const els = [...src.items.values()].filter((x) => MODEL.has(x.kind) && x.levelId && levelMap.has(x.levelId) && !x.viewId);
  for (const x of els) idMap.set(x.id, newId());
  els.sort((a, b) => (a.hostId ? 1 : 0) - (b.hostId ? 1 : 0));
  for (const x of els) {
    bring(x.typeId);
    bring(x.materialId);
    const { id, ...rest } = structuredClone(x);
    const patch = { ...rest, ...(xf && !x.hostId ? transformPatch(x, { point: (p) => [p[0] + dx, p[1] + dy], angle: 0 }) : {}), id: idMap.get(id) };
    for (const k of ['typeId', 'materialId']) if (patch[k] && idMap.has(patch[k])) patch[k] = idMap.get(patch[k]);
    for (const k of ['levelId', 'topLevelId']) if (patch[k]) patch[k] = levelMap.get(patch[k]) ?? null;
    if (patch.hostId) patch.hostId = idMap.get(patch.hostId) ?? null;
    if (x.hostId && !patch.hostId) continue;
    delete patch.groupId;
    doc.add(patch);
    out.elements++;
  }
  // Views: annotations of the chosen levels' plans onto the matching plans; other views added with their annotations.
  if (opts.views) {
    const wanted = opts.views === true ? null : new Set(opts.views);
    const viewMap = new Map();
    for (const v of src.all('plan', 'ceilingPlan')) {
      if (!levelMap.has(v.levelId)) continue;
      const mine = doc.all(v.kind).find((x) => x.levelId === levelMap.get(v.levelId));
      if (mine) viewMap.set(v.id, mine.id);
    }
    for (const v of src.items.values()) {
      if (!VIEW_KINDS.has(v.kind) || v.kind === 'plan' || v.kind === 'ceilingPlan') continue;
      if (wanted && !wanted.has(v.id)) continue;
      const { id, ...rest } = structuredClone(v);
      const nid = newId();
      if (rest.levelId) rest.levelId = levelMap.get(rest.levelId) ?? doc.levels()[0]?.id;
      doc.add({ ...rest, id: nid });
      viewMap.set(id, nid);
      out.views++;
    }
    for (const a of src.items.values()) {
      if (!a.viewId || !viewMap.has(a.viewId) || MODEL.has(a.kind) || VIEW_KINDS.has(a.kind)) continue;
      const { id: _i, ...rest } = structuredClone(a);
      void _i;
      const patch = { ...rest, viewId: viewMap.get(a.viewId), ...(xf ? transformPatch(a, { point: (p) => [p[0] + dx, p[1] + dy], angle: 0 }) : {}) };
      if (patch.levelId) patch.levelId = levelMap.get(patch.levelId) ?? patch.levelId;
      if (patch.hostId) patch.hostId = idMap.get(patch.hostId) ?? null;
      doc.add(patch);
      out.annotations++;
    }
  }
  return out;
}
