/** Starting points for GDL objects: a table, a bookshelf and a floor lamp. */
export const GDL_TEMPLATES = [
  {
    name: 'GDL Table',
    category: 'furniture',
    width: 1400,
    depth: 800,
    height: 750,
    gdl: {
      params: [
        { name: 'top', label: 'Top Thickness', kind: 'length', value: 40 },
        { name: 'leg', label: 'Leg Size', kind: 'length', value: 60 },
        { name: 'topMat', label: 'Top Material', kind: 'material', value: 'mat-wood' },
        { name: 'legMat', label: 'Leg Material', kind: 'material', value: 'mat-steel' },
      ],
      script3d: `! The top, then a leg at each corner.
MATERIAL topMat
ADDZ ZZYZX - top
BLOCK A, B, top
DEL 1
MATERIAL legMat
FOR i = 0 TO 1
  FOR j = 0 TO 1
    ADD i * (A - leg), j * (B - leg), 0
    BLOCK leg, leg, ZZYZX - top
    DEL 1
  NEXT j
NEXT i`,
      script2d: `RECT2 0, 0, A, B
FOR i = 0 TO 1
  FOR j = 0 TO 1
    RECT2 i * (A - leg), j * (B - leg), i * (A - leg) + leg, j * (B - leg) + leg
  NEXT j
NEXT i`,
    },
  },
  {
    name: 'GDL Bookshelf',
    category: 'furniture',
    width: 900,
    depth: 350,
    height: 1800,
    gdl: {
      params: [
        { name: 'shelves', label: 'Shelves', kind: 'integer', value: 5 },
        { name: 'board', label: 'Board Thickness', kind: 'length', value: 20 },
        { name: 'back', label: 'Back Panel', kind: 'boolean', value: true },
        { name: 'mat', label: 'Material', kind: 'material', value: 'mat-wood-light' },
      ],
      script3d: `MATERIAL mat
! Sides.
BLOCK board, B, ZZYZX
ADDX A - board
BLOCK board, B, ZZYZX
DEL 1
! Shelves, evenly from the bottom to the top.
n = MAX(2, shelves)
FOR i = 0 TO n - 1
  ADD board, 0, i * (ZZYZX - board) / (n - 1)
  BLOCK A - 2 * board, B, board
  DEL 1
NEXT i
IF back THEN
  ADDY B - 0.006
  BLOCK A, 0.006, ZZYZX
  DEL 1
ENDIF`,
      script2d: `PROJECT2 3, 270, 2`,
    },
  },
  {
    name: 'GDL Floor Lamp',
    category: 'lighting',
    width: 400,
    depth: 400,
    height: 1700,
    gdl: {
      params: [
        { name: 'shade', label: 'Shade Height', kind: 'length', value: 300 },
        { name: 'shadeMat', label: 'Shade Material', kind: 'material', value: 'mat-fabric-warm' },
      ],
      script3d: `ADD A / 2, B / 2, 0
MATERIAL "mat-steel"
CYLIND 0.02, A / 2 * 0.7
CYLIND ZZYZX - shade, 0.012
ADDZ ZZYZX - shade
MATERIAL shadeMat
CONE shade, A / 2, A / 2 * 0.6, 90, 90
DEL 2`,
      script2d: `CIRCLE2 A / 2, B / 2, A / 2
CIRCLE2 A / 2, B / 2, A / 2 * 0.6`,
    },
  },
];
