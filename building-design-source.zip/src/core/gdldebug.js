/**
 * GDL debugger (Library Developer > Open Debugger): a library part's script
 * run with a trace of every command it executes (name, arguments, macro
 * depth, script and line), the macros it calls, and its variables where it
 * stopped: at the end, at an error, or at a breakpoint line of the script.
 */
import { runGDL } from './gdl.js';
import { gdlVars } from './gdlobject.js';

class Break extends Error {}

const SYSTEM_VAR = /^(GLOB_|SYMB_|AC_|WALL_|WIDO_|PI$)/;

export const SCRIPTS = { '3d': 'script3d', '2d': 'script2d', params: 'paramScript' };

/** The steps of a run for stepping through it: the top-level commands, each with the variables as they stand then. */
export function debugSteps(events) {
  const vars = {};
  const out = [];
  for (const e of events) {
    if (e.kind !== 'cmd' || e.depth !== 0) continue;
    Object.assign(vars, e.changed || {});
    out.push({ name: e.name, args: e.args, at: e.at, changed: Object.keys(e.changed || {}), vars: { ...vars } });
  }
  return out;
}

/** The next step at or after `from` on one of the breakpoints ("script:line"), or -1. */
export function nextBreak(steps, breaks, from) {
  for (let i = from; i < steps.length; i++) if (steps[i].at && breaks.has(`${steps[i].at.script}:${steps[i].at.line}`)) return i;
  return -1;
}

const short = (v) => {
  if (typeof v === 'number') return Math.round(v * 1e6) / 1e6;
  if (Array.isArray(v)) return v.length > 12 ? `[${v.length} values]` : v.map(short);
  if (v && typeof v === 'object') return '{…}';
  return v;
};

/**
 * Run a type's script under the debugger. opts: mode '3d' | '2d' | 'params', breakAt { script: 'master'|'main',
 * line } (1-based, in that script), maxEvents. Returns { events, vars, error, stoppedAt, unknown, steps }.
 */
export function debugRun(type, own = {}, { mode = '3d', breakAt = null, maxEvents = 5000, stepVars = false } = {}) {
  const g = type?.gdl || {};
  const master = g.master || '';
  const main = g[SCRIPTS[mode]] || '';
  const offset = master ? master.split('\n').length : 0;
  const where = (line) => (line == null ? null : line <= offset ? { script: 'master', line } : { script: 'main', line: line - offset });
  const events = [];
  let stopped = null;
  let top = null;
  // Stepping: at each top-level command, the variables that changed since the one before.
  const seen = new Map();
  const changedVars = (runner) => {
    const out = {};
    for (const [k, v] of Object.entries(runner.vars || {})) {
      if (SYSTEM_VAR.test(k)) continue;
      const s = short(v);
      const j = JSON.stringify(s);
      if (seen.get(k) !== j) {
        seen.set(k, j);
        out[k] = s;
      }
    }
    return out;
  };
  const trace = (kind, name, depth, runner, args, line) => {
    if (kind === 'cmd' && depth === 0) top = runner;
    if (events.length < maxEvents) events.push({ kind, name, depth, ...(kind === 'cmd' ? { args: (args || []).map(short), at: depth === 0 ? where(line) : null } : {}), ...(stepVars && kind === 'cmd' && depth === 0 ? { changed: changedVars(runner) } : {}) });
    if (breakAt && kind === 'cmd' && depth === 0) {
      const w = where(line);
      if (w && w.script === (breakAt.script || 'main') && w.line >= breakAt.line) {
        stopped = w;
        throw new Break();
      }
    }
  };
  const macros = (n) => g.macros?.[String(n).toLowerCase()] || null;
  const src = master ? `${master}\n${main}` : main;
  let r = null;
  let error = null;
  try {
    r = runGDL(src, { vars: gdlVars(type, own), mode, lenient: !!g.lenient, macros, trace, maxSteps: 3e6 });
  } catch (err) {
    if (!(err instanceof Break)) error = { message: err.message, at: where(err.line) };
  }
  const runner = r || top;
  const vars = {};
  if (runner?.vars) for (const [k, v] of Object.entries(runner.vars)) if (!SYSTEM_VAR.test(k)) vars[k] = short(v);
  return { events, vars, error, stoppedAt: stopped, unknown: runner?.unknown ? Object.fromEntries(runner.unknown) : {}, truncated: events.length >= maxEvents };
}
