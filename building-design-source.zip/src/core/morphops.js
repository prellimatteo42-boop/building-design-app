/**
 * Morph operations, as Archicad's Design > Modify Morph: Check Solidity
 * (whether a body is closed: every edge shared by two faces running it in
 * opposite directions), Cover with Faces (open edge loops closed with new
 * faces) and Smooth & Merge Faces (faces meeting under an angle merge: their
 * edges are not drawn). They work on a morph's triangles (a frozen body, as
 * Convert to Morph makes); a prism morph is always closed.
 */
import earcut from 'earcut';

const keyOf = (p) => `${Math.round(p[0] * 10)},${Math.round(p[1] * 10)},${Math.round(p[2] * 10)}`;
const corner = (tris, t, k) => [tris[t + 3 * k], tris[t + 3 * k + 1], tris[t + 3 * k + 2]];

/** Each edge (by its two corners' keys, sorted) with the directed uses of the triangles on it. */
function edgeUses(tris) {
  const edges = new Map();
  for (let t = 0; t + 8 < tris.length; t += 9)
    for (let e = 0; e < 3; e++) {
      const a = corner(tris, t, e);
      const b = corner(tris, t, (e + 1) % 3);
      const ka = keyOf(a);
      const kb = keyOf(b);
      if (ka === kb) continue;
      const k = ka < kb ? `${ka}|${kb}` : `${kb}|${ka}`;
      if (!edges.has(k)) edges.set(k, { a, b, uses: [] });
      edges.get(k).uses.push({ from: ka, to: kb, a, b });
    }
  return edges;
}

/**
 * Whether a body is solid: { solid, triangles, open (edges on one face),
 * nonManifold (edges on more than two), flipped (edges both faces run the
 * same way: a face turned inside out) }.
 */
export function checkSolidity(tris) {
  let open = 0;
  let nonManifold = 0;
  let flipped = 0;
  for (const e of edgeUses(tris).values()) {
    if (e.uses.length === 1) open++;
    else if (e.uses.length > 2) nonManifold++;
    else if (e.uses[0].from === e.uses[1].from) flipped++;
  }
  return { solid: !open && !nonManifold && !flipped, triangles: Math.floor(tris.length / 9), open, nonManifold, flipped };
}

/**
 * Cover with Faces: each loop of open edges closed by faces over it (the
 * loop triangulated in its best-fitting plane), facing out like the faces
 * around it. Returns the new triangle array (and how many holes it closed).
 */
export function coverWithFaces(tris) {
  // Open edges, kept in the direction their face runs them; a cover runs them backwards.
  const next = new Map();
  const pts = new Map();
  for (const e of edgeUses(tris).values()) {
    if (e.uses.length !== 1) continue;
    const u = e.uses[0];
    next.set(u.to, u.from);
    pts.set(u.from, u.a);
    pts.set(u.to, u.b);
  }
  const out = tris.slice();
  let holes = 0;
  const seen = new Set();
  for (const start of next.keys()) {
    if (seen.has(start)) continue;
    const loop = [];
    let k = start;
    while (k !== undefined && !seen.has(k)) {
      seen.add(k);
      loop.push(pts.get(k));
      k = next.get(k);
    }
    if (k !== start || loop.length < 3) continue;
    // The loop's plane: Newell's normal; its points in 2D on that plane.
    const n = [0, 0, 0];
    for (let i = 0; i < loop.length; i++) {
      const p = loop[i];
      const q = loop[(i + 1) % loop.length];
      n[0] += (p[1] - q[1]) * (p[2] + q[2]);
      n[1] += (p[2] - q[2]) * (p[0] + q[0]);
      n[2] += (p[0] - q[0]) * (p[1] + q[1]);
    }
    const l = Math.hypot(...n);
    if (l < 1e-9) continue;
    const N = n.map((v) => v / l);
    const U = Math.abs(N[0]) < 0.9 ? norm(cross(N, [1, 0, 0])) : norm(cross(N, [0, 1, 0]));
    const V = cross(N, U);
    const flat = loop.flatMap((p) => [dot(p, U), dot(p, V)]);
    const ids = earcut(flat);
    for (let i = 0; i < ids.length; i += 3) {
      // Earcut gives the loop's own winding (counterclockwise about N): the cover's outward face.
      for (const j of [ids[i], ids[i + 1], ids[i + 2]]) out.push(...loop[j]);
    }
    holes++;
  }
  return { tris: out, holes };
}

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a) => {
  const l = Math.hypot(...a) || 1;
  return a.map((v) => v / l);
};

/**
 * Curve & Merge Edges on a prism morph: its straight footprint edges become one
 * smooth curve through its corners (a closed centripetal Catmull-Rom spline,
 * each edge cut into `segments` pieces), the corner heights following it, and
 * the pieces of each curved edge merge into one (no edges drawn between them).
 * Returns the patch { boundary, heights, curved }, or null when it has no footprint.
 */
export function curveMorphEdges(el, segments = 8) {
  // Curving again (Modify Segmentation) starts from the corners it was curved through.
  const pts = el.curveCorners || el.boundary;
  segments = Math.max(1, Math.min(64, Math.round(+segments || 8)));
  if (!Array.isArray(pts) || pts.length < 3) return null;
  const n = pts.length;
  const hs = el.curveCorners ? el.curveHeights : el.heights;
  const h = (i) => {
    const v = hs?.[(i + n) % n];
    return Number.isFinite(+v) && v !== null && v !== '' ? +v : +el.height || 3000;
  };
  const P = (i) => [...pts[(i + n) % n], h(i)];
  const dist = (a, b) => Math.max(1e-6, Math.sqrt(Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2])));
  const boundary = [];
  const heights = [];
  for (let i = 0; i < n; i++) {
    const [p0, p1, p2, p3] = [P(i - 1), P(i), P(i + 1), P(i + 2)];
    // Centripetal parameterisation (alpha 1/2): no cusps or loops on uneven edges.
    const t0 = 0;
    const t1 = t0 + dist(p0, p1);
    const t2 = t1 + dist(p1, p2);
    const t3 = t2 + dist(p2, p3);
    const lerp = (a, b, ta, tb, t) => a.map((v, k) => ((tb - t) / (tb - ta)) * v + ((t - ta) / (tb - ta)) * b[k]);
    for (let s = 0; s < segments; s++) {
      const t = t1 + ((t2 - t1) * s) / segments;
      const A1 = lerp(p0, p1, t0, t1, t);
      const A2 = lerp(p1, p2, t1, t2, t);
      const A3 = lerp(p2, p3, t2, t3, t);
      const B1 = lerp(A1, A2, t0, t2, t);
      const B2 = lerp(A2, A3, t1, t3, t);
      const C = lerp(B1, B2, t1, t2, t);
      boundary.push([C[0], C[1]]);
      heights.push(C[2]);
    }
  }
  return { boundary, heights, curved: true, segments, curveCorners: pts.map((p) => [p[0], p[1]]), curveHeights: pts.map((_, i) => h(i)) };
}

/**
 * Merge Elements: bodies of faces joined into one; faces two bodies share
 * (the same three corners, facing opposite ways) are inside the result and go.
 * Returns { tris, cols, removed }.
 */
export function mergeBodies(parts) {
  const tris = [];
  const cols = [];
  for (const p of parts) {
    tris.push(...p.tris);
    cols.push(...p.cols);
  }
  const key = (t) =>
    [0, 1, 2]
      .map((k) => keyOf(corner(tris, t, k)))
      .sort()
      .join('|');
  const byKey = new Map();
  for (let t = 0; t + 8 < tris.length; t += 9) {
    const k = key(t);
    if (!byKey.has(k)) byKey.set(k, []);
    byKey.get(k).push(t);
  }
  const drop = new Set();
  for (const list of byKey.values()) if (list.length >= 2 && list.length % 2 === 0) list.forEach((t) => drop.add(t));
  const outT = [];
  const outC = [];
  for (let t = 0; t + 8 < tris.length; t += 9) {
    if (drop.has(t)) continue;
    for (let k = 0; k < 9; k++) outT.push(tris[t + k]);
    outC.push(cols[t / 9]);
  }
  return { tris: outT, cols: outC, removed: drop.size };
}

const vsub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const vdot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const vcross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const vlerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

/** Where triangle T crosses the plane (n, d): its two crossing points, or null. */
function crossing(T, n, d, eps) {
  const s = T.map((p) => vdot(n, p) - d);
  if (s.every((v) => v > eps) || s.every((v) => v < -eps)) return null;
  if (s.every((v) => Math.abs(v) <= eps)) return null; // coplanar: no edge of intersection
  const pts = [];
  for (let i = 0; i < 3; i++) {
    const a = T[i];
    const b = T[(i + 1) % 3];
    const sa = s[i];
    const sb = s[(i + 1) % 3];
    if (Math.abs(sa) <= eps) pts.push(a);
    else if ((sa < -eps && sb > eps) || (sa > eps && sb < -eps)) pts.push(vlerp(a, b, sa / (sa - sb)));
  }
  return pts.length >= 2 ? [pts[0], pts[pts.length - 1]] : null;
}

/** The segment where two triangles cut each other, or null. */
function triTri(A, B) {
  const nA = vcross(vsub(A[1], A[0]), vsub(A[2], A[0]));
  const nB = vcross(vsub(B[1], B[0]), vsub(B[2], B[0]));
  const lA = Math.hypot(...nA);
  const lB = Math.hypot(...nB);
  if (lA < 1e-9 || lB < 1e-9) return null;
  const eps = 1e-6 * Math.max(1, Math.sqrt(Math.max(lA, lB)));
  const sB = crossing(B, nA.map((v) => v / lA), vdot(nA, A[0]) / lA, eps);
  if (!sB) return null;
  const sA = crossing(A, nB.map((v) => v / lB), vdot(nB, B[0]) / lB, eps);
  if (!sA) return null;
  const dir = vcross(nA, nB);
  if (Math.hypot(...dir) < 1e-9) return null;
  const t = (p) => vdot(dir, p);
  const [a0, a1] = t(sA[0]) <= t(sA[1]) ? sA : [sA[1], sA[0]];
  const [b0, b1] = t(sB[0]) <= t(sB[1]) ? sB : [sB[1], sB[0]];
  const lo = t(a0) >= t(b0) ? a0 : b0;
  const hi = t(a1) <= t(b1) ? a1 : b1;
  if (t(hi) - t(lo) <= 1e-9 * Math.hypot(...dir) || Math.hypot(...vsub(hi, lo)) < 0.5) return null;
  return [lo, hi];
}

/** A convex polygon (3D, in one plane) split by the plane (n, d): [below, above]. */
function splitConvex(poly, n, d) {
  const s = poly.map((p) => vdot(n, p) - d);
  if (s.every((v) => v >= -1e-6) || s.every((v) => v <= 1e-6)) return [poly];
  const a = [];
  const b = [];
  for (let i = 0; i < poly.length; i++) {
    const p = poly[i];
    const q = poly[(i + 1) % poly.length];
    const sp = s[i];
    const sq = s[(i + 1) % poly.length];
    if (sp <= 0) a.push(p);
    if (sp >= 0) b.push(p);
    if ((sp < 0 && sq > 0) || (sp > 0 && sq < 0)) {
      const x = vlerp(p, q, sp / (sp - sq));
      a.push(x);
      b.push(x);
    }
  }
  return [a, b].filter((x) => x.length >= 3);
}

/**
 * Intersect Morph Faces, as Archicad's: where faces of the bodies cut through
 * each other (between bodies, and within one), each face is split along the
 * line of the cut and the line becomes an edge. bodies: [{ tris, cols }].
 * Returns per body { tris, cols, lines (flat segment corners) } and the number
 * of cuts found.
 */
export function intersectFaces(bodies) {
  const all = [];
  bodies.forEach((bd, bi) => {
    for (let t = 0; t + 8 < bd.tris.length; t += 9) {
      const T = [0, 1, 2].map((k) => corner(bd.tris, t, k));
      const lo = [0, 1, 2].map((k) => Math.min(T[0][k], T[1][k], T[2][k]));
      const hi = [0, 1, 2].map((k) => Math.max(T[0][k], T[1][k], T[2][k]));
      all.push({ bi, t, T, lo, hi, cuts: [] });
    }
  });
  if (all.length > 20000) throw new Error('Too many faces to intersect');
  const sharesCorner = (a, b) => a.T.some((p) => b.T.some((q) => keyOf(p) === keyOf(q)));
  let found = 0;
  // Sweep along x so only faces whose boxes overlap are compared.
  const order = all.slice().sort((a, b) => a.lo[0] - b.lo[0]);
  for (let i = 0; i < order.length; i++) {
    const A = order[i];
    for (let j = i + 1; j < order.length && order[j].lo[0] <= A.hi[0]; j++) {
      const B = order[j];
      if (B.lo[1] > A.hi[1] || B.hi[1] < A.lo[1] || B.lo[2] > A.hi[2] || B.hi[2] < A.lo[2]) continue;
      if (A.bi === B.bi && sharesCorner(A, B)) continue;
      const seg = triTri(A.T, B.T);
      if (!seg) continue;
      A.cuts.push(seg);
      B.cuts.push(seg);
      found++;
    }
  }
  const out = bodies.map(() => ({ tris: [], cols: [], lines: [] }));
  for (const f of all) {
    const o = out[f.bi];
    const col = bodies[f.bi].cols?.[f.t / 9] || [190, 190, 190, 255];
    let pieces = [f.T];
    const n = vcross(vsub(f.T[1], f.T[0]), vsub(f.T[2], f.T[0]));
    for (const [p, q] of f.cuts) {
      // The plane through the cut line square to the face.
      const m = vcross(n, vsub(q, p));
      const ml = Math.hypot(...m);
      if (ml < 1e-9) continue;
      const mu = m.map((v) => v / ml);
      pieces = pieces.flatMap((pc) => splitConvex(pc, mu, vdot(mu, p)));
      o.lines.push(...p, ...q);
    }
    for (const pc of pieces)
      for (let k = 1; k + 1 < pc.length; k++) {
        o.tris.push(...pc[0], ...pc[k], ...pc[k + 1]);
        o.cols.push(col);
      }
  }
  // Each cut line was recorded on both faces: keep one per body.
  for (const o of out) {
    const seen = new Set();
    const lines = [];
    for (let i = 0; i + 5 < o.lines.length; i += 6) {
      const a = keyOf(o.lines.slice(i, i + 3));
      const b = keyOf(o.lines.slice(i + 3, i + 6));
      const k = a < b ? `${a}|${b}` : `${b}|${a}`;
      if (seen.has(k)) continue;
      seen.add(k);
      lines.push(...o.lines.slice(i, i + 6));
    }
    o.lines = lines;
  }
  return { bodies: out, cuts: found };
}
