/**
 * Work Environment customisation, as in Archicad's Options > Work
 * Environment: which Toolbox tools show and which commands are added to it,
 * which menus show and a menu of one's own, the Standard toolbar's buttons
 * and toolbars of one's own, the Info Box panels of each tool, the fields
 * of each Tool Settings dialog, and named profiles of all of these.
 *
 *   settings.acCustom = {
 *     toolbox: { hidden: ['Design/Wall', ...], extra: [cmd] },
 *     menus: { hidden: ['Teamwork', ...], custom: { label, cmds: [cmd] } | null },
 *     toolbars: { standard: true, hidden: [label], user: [{ name, cmds: [cmd] }] },
 *     infobox: { [toolCmd]: [hidden panel] },
 *     toolSettings: { [typeKind]: [hidden field key] },
 *   }
 *   settings.acProfiles = { [name]: acCustom }
 */

export const EMPTY_CUSTOM = () => ({ toolbox: { hidden: [], extra: [] }, menus: { hidden: [], custom: null }, toolbars: { standard: true, hidden: [], user: [] }, infobox: {}, toolSettings: {} });

/** A customisation with every part present (old or partial ones filled with the defaults). */
export function normCustom(c) {
  const e = EMPTY_CUSTOM();
  c = c || {};
  return {
    toolbox: { ...e.toolbox, ...(c.toolbox || {}) },
    menus: { ...e.menus, ...(c.menus || {}) },
    toolbars: { ...e.toolbars, ...(c.toolbars || {}) },
    infobox: { ...(c.infobox || {}) },
    toolSettings: { ...(c.toolSettings || {}) },
  };
}

export const toolKey = (section, label) => `${section}/${label}`;

/** Toolbox sections with the hidden tools left out and a "User" section of added commands. */
export function customToolbox(toolbox, c, labelOf = (cmd) => cmd) {
  const { hidden, extra } = normCustom(c).toolbox;
  const out = toolbox.map((s) => ({ ...s, tools: s.tools.filter((t) => !hidden.includes(toolKey(s.title, t.label))) })).filter((s) => s.tools.length);
  if (extra.length) out.push({ title: 'User', tools: extra.map((cmd) => ({ label: labelOf(cmd), cmd })) });
  return out;
}

/** The menu bar with hidden menus left out and the custom menu before the last one (Help). */
export function customMenubar(menubar, c, labelOf = (cmd) => cmd) {
  const { hidden, custom } = normCustom(c).menus;
  const out = menubar.filter((m) => !hidden.includes(m.label));
  if (custom?.label && custom.cmds?.length) {
    const menu = { label: custom.label, items: custom.cmds.map((cmd) => (cmd ? { label: labelOf(cmd), cmd } : null)), custom: true };
    const help = out.findIndex((m) => m.label === 'Help');
    out.splice(help >= 0 ? help : out.length, 0, menu);
  }
  return out;
}

/** The Standard toolbar's items without the hidden ones (and without separators left doubled). */
export function customStandard(items, c) {
  const { hidden } = normCustom(c).toolbars;
  const out = [];
  for (const it of items) {
    if (it && hidden.includes(it.label)) continue;
    if (!it && (!out.length || !out.at(-1))) continue;
    out.push(it);
  }
  while (out.length && !out.at(-1)) out.pop();
  return out;
}

/** Info Box panels of a tool, without the hidden ones ('Main' always stays). */
export function customPanels(panels, c, cmd) {
  const hidden = normCustom(c).infobox[cmd] || [];
  return (panels || []).filter((p) => p === 'Main' || !hidden.includes(p));
}

/** Whether a Tool Settings field shows. */
export function fieldShown(c, kind, key) {
  return !(normCustom(c).toolSettings[kind] || []).includes(key);
}

/** Toggle a value in a list (returns a new list). */
export const toggled = (list, v, on) => (on ? [...new Set([...(list || []), v])] : (list || []).filter((x) => x !== v));

/** A work environment profile file (JSON) and back. */
export function profileFile(name, c) {
  return JSON.stringify({ format: 'building-design-work-environment', version: 1, name, custom: normCustom(c) }, null, 1);
}
export function readProfileFile(text) {
  const j = JSON.parse(text);
  if (j?.format !== 'building-design-work-environment' || !j.custom) throw new Error('Not a work environment profile.');
  return { name: String(j.name || 'Profile'), custom: normCustom(j.custom) };
}
