/**
 * 3D input on Archicad's editing plane: the plane may be horizontal (at a
 * height), or any plane picked from a surface (a wall face, a roof pitch);
 * with Align to Surface it follows the surface under the cursor. After the
 * first click, the input projection constrains the next points:
 *
 *   free         on the editing plane;
 *   horizontal   on the horizontal plane through the last point;
 *   vertical     on the vertical plane through the last point that faces the camera;
 *   perpEdit     along the editing plane's normal through the last point;
 *   perpResult   along the normal of the plane the input points so far lie in.
 *
 * Points are model millimetres [x, y, z]; planes { o, n } with n of length 1.
 */

export const PROJECTIONS = [
  { value: 'free', label: 'On Editing Plane' },
  { value: 'horizontal', label: 'Horizontal' },
  { value: 'vertical', label: 'Vertical' },
  { value: 'perpEdit', label: 'Perpendicular to Editing Plane' },
  { value: 'perpResult', label: 'Perpendicular to Result Plane' },
];

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const add = (a, b, k = 1) => [a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const unit = (v) => {
  const l = Math.hypot(v[0], v[1], v[2]);
  return l > 1e-12 ? v.map((c) => c / l) : null;
};

export const horizontalPlane = (z) => ({ o: [0, 0, z], n: [0, 0, 1] });

/** Is a plane horizontal (its normal straight up or down)? */
export const isHorizontal = (pl) => Math.abs(Math.abs(pl.n[2]) - 1) < 1e-6;

/** The plane of a surface hit { p, n }. */
export function planeFromSurface(hit) {
  const n = unit(hit.n);
  return n ? { o: hit.p.slice(), n } : null;
}

/** Where a ray o + t·d (t > 0) meets a plane, or null. */
export function rayPlane(o, d, pl) {
  const den = dot(d, pl.n);
  if (Math.abs(den) < 1e-12) return null;
  const t = dot(sub(pl.o, o), pl.n) / den;
  return t > 0 ? add(o, d, t) : null;
}

/** The point of the line p + s·u nearest to the ray o + t·d. */
export function lineNearRay(p, u, o, d) {
  const w = sub(p, o);
  const a = dot(u, u);
  const b = dot(u, d);
  const c = dot(d, d);
  const den = a * c - b * b;
  if (Math.abs(den) < 1e-12) return p.slice();
  const s = (b * dot(d, w) - c * dot(u, w)) / den;
  return add(p, u, s);
}

/** The normal of the plane through input points (the last three not in a line), or null. */
export function resultNormal(points) {
  for (let i = points.length - 1; i >= 2; i--) {
    const n = unit(cross(sub(points[i - 1], points[i - 2]), sub(points[i], points[i - 2])));
    if (n) return n;
  }
  return null;
}

/**
 * The 3D input point for a ray: on the editing plane, or constrained by the projection relative to the last point.
 * opts: { mode, anchor (last point), points (all so far), view (camera direction) }.
 */
export function inputPoint(o, d, plane, { mode = 'free', anchor = null, points = [], view = d } = {}) {
  if (!anchor || mode === 'free') return rayPlane(o, d, plane);
  if (mode === 'horizontal') return rayPlane(o, d, horizontalPlane(anchor[2]));
  if (mode === 'vertical') {
    const n = unit([view[0], view[1], 0]) || [1, 0, 0];
    return rayPlane(o, d, { o: anchor, n });
  }
  const n = mode === 'perpResult' ? resultNormal(points) || plane.n : plane.n;
  return lineNearRay(anchor, n, o, d);
}

/** The base offset patch an element placed at height z gets on its level (only kinds that sit at a height). */
export function offsetPatch(kind, z, levelZ) {
  const off = Math.round(z - levelZ);
  if (kind === 'component' || kind === 'lamp' || kind === 'mepEquipment') return { offset: off };
  if (kind === 'column') return { baseOffset: off };
  if (kind === 'floor' || kind === 'mass' || kind === 'morph') return { offset: off };
  return null;
}
