/**
 * Escape check after the Italian fire code (Codice di prevenzione incendi, D.M. 3 agosto 2015, chapter S.4): for each
 * zone the longest walk to an exit (lunghezza d'esodo, table S.4-25) and the longest stretch with one way out only
 * (corridoio cieco, table S.4-18), the occupants each exit takes and the width they need (tables S.4-27, S.4-28).
 *
 * Walls are painted solid on a grid, doors and openings opened in them, and walking distances measured from each exit
 * over the free floor (16 directions, within 3 % of the straight line). A point's dead-end stretch is the part of its
 * paths to two independent exits that they share: (dA + dB - dAB) / 2 for the best pair of exits (on a corridor that
 * splits it is the way to the split; with one exit, the whole way). Furniture is not an obstacle; outside is safe.
 *
 * Exits on the lowest level are the doors and openings that lead outside; above, those that lead onto an external
 * stair, or any marked as an exit.
 */

/** Rvita profiles: max escape length Les (m), max dead end Lcc (m), max occupants of a dead end, horizontal unit width (mm/person). */
export const RVITA = {
  A1: { les: 70, lcc: 45, crowd: 100, unit: 3.4 },
  A2: { les: 60, lcc: 30, crowd: 100, unit: 3.8 },
  A3: { les: 45, lcc: 15, crowd: 100, unit: 4.6 },
  A4: { les: 30, lcc: 10, crowd: 50, unit: 12.3 },
  B1: { les: 60, lcc: 25, crowd: 50, unit: 3.6 },
  B2: { les: 50, lcc: 20, crowd: 50, unit: 4.1 },
  B3: { les: 40, lcc: 15, crowd: 50, unit: 6.2 },
  Cii1: { les: 40, lcc: 20, crowd: 50, unit: 3.6 },
  Cii2: { les: 30, lcc: 15, crowd: 50, unit: 4.1 },
  Cii3: { les: 20, lcc: 10, crowd: 50, unit: 6.2 },
  Ciii1: { les: 40, lcc: 20, crowd: 50, unit: 3.6 },
  Ciii2: { les: 30, lcc: 15, crowd: 50, unit: 4.1 },
  Ciii3: { les: 20, lcc: 10, crowd: 50, unit: 6.2 },
  D1: { les: 30, lcc: 20, crowd: 50, unit: 4.1 },
  D2: { les: 20, lcc: 15, crowd: 50, unit: 6.2 },
  E1: { les: 60, lcc: 25, crowd: 50, unit: 3.6 },
  E2: { les: 50, lcc: 20, crowd: 50, unit: 4.1 },
  E3: { les: 40, lcc: 15, crowd: 50, unit: 6.2 },
};

/** Minimum width of a horizontal escape route for the occupants it serves (table S.4-28), mm. */
export function minRouteWidth(occupants) {
  if (occupants > 1000) return 1200;
  if (occupants > 300) return 1000;
  return 900;
}

/** Minimum width of a doorway out of a space with so many occupants (table S.4-28), mm. */
export function minDoorWidth(occupants) {
  if (occupants <= 10) return 700;
  if (occupants <= 50) return 800;
  return minRouteWidth(occupants);
}

/**
 * Occupants of a zone from what it is: its own `occupants`, its beds, else the density of its use (table S.4-12:
 * eating 0.7 per m², lounges and waiting 0.4, offices 0.1 per m²; corridors, baths, stores and plant rooms none).
 */
export function zoneOccupants(name, area, { occupants = null, beds = null } = {}) {
  if (Number.isFinite(+occupants) && occupants !== null && occupants !== '') return Math.max(0, Math.round(+occupants));
  if (Number.isFinite(+beds) && beds !== null && beds !== '') return Math.max(0, Math.round(+beds));
  const n = String(name || '').toLowerCase();
  const m2 = area / 1e6;
  if (/camer|bedroom|stanza/.test(n)) return 2;
  if (/pranzo|ristor|mensa|refettor|dining|restaurant|bar\b|colazion/.test(n)) return Math.ceil(m2 * 0.7);
  if (/comune|soggiorno|sala|attesa|lounge|living|aula|riunion/.test(n)) return Math.ceil(m2 * 0.4);
  if (/uffic|reception|office|portineria/.test(n)) return Math.ceil(m2 * 0.1);
  if (/cucin|kitchen/.test(n)) return Math.ceil(m2 * 0.1);
  return 0;
}

const SQ2 = Math.SQRT2;
const SQ5 = Math.sqrt(5);
// 16 directions: the 8 neighbours and the knight's moves (which must not cut a corner).
const STEPS = [
  [1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1],
  [1, 1, SQ2], [1, -1, SQ2], [-1, 1, SQ2], [-1, -1, SQ2],
  [2, 1, SQ5], [2, -1, SQ5], [-2, 1, SQ5], [-2, -1, SQ5], [1, 2, SQ5], [-1, 2, SQ5], [1, -2, SQ5], [-1, -2, SQ5],
];

/** Cells whose centre lies in a polygon: indices. */
function cellsIn(g, poly) {
  const out = [];
  if (!poly || poly.length < 3) return out;
  let ymin = Infinity;
  let ymax = -Infinity;
  for (const p of poly) (ymin = Math.min(ymin, p[1])), (ymax = Math.max(ymax, p[1]));
  const r0 = Math.max(0, Math.floor((ymin - g.y0) / g.cell));
  const r1 = Math.min(g.h - 1, Math.ceil((ymax - g.y0) / g.cell));
  for (let r = r0; r <= r1; r++) {
    const y = g.y0 + (r + 0.5) * g.cell;
    const xs = [];
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[j];
      const b = poly[i];
      if ((a[1] > y) !== (b[1] > y)) xs.push(a[0] + ((y - a[1]) * (b[0] - a[0])) / (b[1] - a[1]));
    }
    xs.sort((p, q) => p - q);
    for (let k = 0; k + 1 < xs.length; k += 2) {
      const c0 = Math.max(0, Math.ceil((xs[k] - g.x0) / g.cell - 0.5));
      const c1 = Math.min(g.w - 1, Math.floor((xs[k + 1] - g.x0) / g.cell - 0.5));
      for (let c = c0; c <= c1; c++) out.push(r * g.w + c);
    }
  }
  return out;
}

/** Walking distances (cells) from source cells over free cells, not through outside ones. */
function distances(g, sources, blocked) {
  const N = g.w * g.h;
  // Doubles: a float32 store rounds up past the double it is compared with, and the same cell is queued over and over.
  const d = new Float64Array(N).fill(Infinity);
  // A binary heap of [dist, index].
  const heap = [];
  const push = (v, i) => {
    heap.push([v, i]);
    let k = heap.length - 1;
    while (k > 0) {
      const p = (k - 1) >> 1;
      if (heap[p][0] <= heap[k][0]) break;
      [heap[p], heap[k]] = [heap[k], heap[p]];
      k = p;
    }
  };
  const pop = () => {
    const top = heap[0];
    const last = heap.pop();
    if (heap.length) {
      heap[0] = last;
      let k = 0;
      for (;;) {
        const l = 2 * k + 1;
        const r = l + 1;
        let m = k;
        if (l < heap.length && heap[l][0] < heap[m][0]) m = l;
        if (r < heap.length && heap[r][0] < heap[m][0]) m = r;
        if (m === k) break;
        [heap[m], heap[k]] = [heap[k], heap[m]];
        k = m;
      }
    }
    return top;
  };
  for (const s of sources) if (!blocked[s]) (d[s] = 0), push(0, s);
  const free = (x, y) => x >= 0 && y >= 0 && x < g.w && y < g.h && !blocked[y * g.w + x];
  while (heap.length) {
    const [v, i] = pop();
    if (v > d[i]) continue;
    const x = i % g.w;
    const y = (i / g.w) | 0;
    for (const [dx, dy, c] of STEPS) {
      const nx = x + dx;
      const ny = y + dy;
      if (!free(nx, ny)) continue;
      // Diagonal and knight steps only where the cells they pass are free too.
      if (Math.abs(dx) + Math.abs(dy) > 1) {
        const sx = Math.sign(dx);
        const sy = Math.sign(dy);
        if (!free(x + sx, y) || !free(x, y + sy)) continue;
        if (Math.abs(dx) === 2 && !free(x + sx, y + sy)) continue;
        if (Math.abs(dy) === 2 && !free(x + sx, y + sy)) continue;
      }
      const j = ny * g.w + nx;
      const nv = v + c;
      if (nv < d[j]) (d[j] = nv), push(nv, j);
    }
  }
  return d;
}

/** Douglas-Peucker on a polyline (mm). */
function simplify(pts, tol) {
  if (pts.length < 3) return pts;
  const keep = new Uint8Array(pts.length);
  keep[0] = keep[pts.length - 1] = 1;
  const stack = [[0, pts.length - 1]];
  while (stack.length) {
    const [i, j] = stack.pop();
    const [ax, ay] = pts[i];
    const [bx, by] = pts[j];
    const L = Math.hypot(bx - ax, by - ay) || 1;
    let best = -1;
    let at = -1;
    for (let k = i + 1; k < j; k++) {
      const e = Math.abs((bx - ax) * (ay - pts[k][1]) - (ax - pts[k][0]) * (by - ay)) / L;
      if (e > best) (best = e), (at = k);
    }
    if (best > tol) {
      keep[at] = 1;
      stack.push([i, at], [at, j]);
    }
  }
  return pts.filter((_, k) => keep[k]);
}

/**
 * The check: barriers (wall and column outlines), openings ([{ id, poly, width }] door and opening gaps, opened in the
 * walls), exits (ids of openings that are exits; null = every opening that touches outside), rooms ([{ id, name, poly,
 * occupants }]), profile (an RVITA key), cell (mm). Lengths in the result in metres.
 */
/**
 * The floor of a level on a grid: walls painted solid (with every cell their edges cross), the outside found with the
 * doors shut, then the doorways opened. { g, solid, outside, blocked, gap } (gap: opening id -> its cells), or null.
 */
export function floorGrid({ barriers = [], openings = [], rooms = [], cell = 150, margin = 3000 }) {
  const pts = [...barriers.flat(), ...rooms.flatMap((r) => r.poly)];
  if (!pts.length) return null;
  const box = { x0: Math.min(...pts.map((p) => p[0])) - margin, y0: Math.min(...pts.map((p) => p[1])) - margin, x1: Math.max(...pts.map((p) => p[0])) + margin, y1: Math.max(...pts.map((p) => p[1])) + margin };
  const g = { cell, x0: box.x0, y0: box.y0, w: Math.ceil((box.x1 - box.x0) / cell), h: Math.ceil((box.y1 - box.y0) / cell) };
  const N = g.w * g.h;
  const solid = new Uint8Array(N);
  // A doorway: the cells its outline covers and those its edges cross (as the walls' edges were painted).
  const edgeCells = (poly) => {
    const out = [];
    for (let k = 0; k < poly.length; k++) {
      const p = poly[k];
      const q = poly[(k + 1) % poly.length];
      const n = Math.max(1, Math.ceil((Math.hypot(q[0] - p[0], q[1] - p[1]) / cell) * 3));
      for (let j = 0; j <= n; j++) {
        const x = Math.floor((p[0] + ((q[0] - p[0]) * j) / n - g.x0) / cell);
        const y = Math.floor((p[1] + ((q[1] - p[1]) * j) / n - g.y0) / cell);
        if (x >= 0 && y >= 0 && x < g.w && y < g.h) out.push(y * g.w + x);
      }
    }
    return out;
  };
  const gap = new Map();
  for (const o of openings) gap.set(o.id, [...new Set([...cellsIn(g, o.poly), ...edgeCells(o.poly)])]);
  // Walls solid: the cells their outline covers, and every cell their edges cross (a partition thinner than a cell
  // must not leave gaps to walk through).
  for (const b of barriers) {
    for (const i of cellsIn(g, b)) solid[i] = 1;
    for (const i of edgeCells(b)) solid[i] = 1;
  }
  // Outside: free cells reached from the grid's edge with the doors shut (else it would come in through them).
  const outside = new Uint8Array(N);
  const stack = [];
  const seed = (i) => !solid[i] && !outside[i] && ((outside[i] = 1), stack.push(i));
  for (let x = 0; x < g.w; x++) seed(x), seed((g.h - 1) * g.w + x);
  for (let y = 0; y < g.h; y++) seed(y * g.w), seed(y * g.w + g.w - 1);
  while (stack.length) {
    const i = stack.pop();
    const x = i % g.w;
    if (x > 0) seed(i - 1);
    if (x < g.w - 1) seed(i + 1);
    if (i >= g.w) seed(i - g.w);
    if (i < N - g.w) seed(i + g.w);
  }
  // Then the doors open.
  for (const cells of gap.values()) for (const i of cells) solid[i] = 0;
  const blocked = new Uint8Array(N);
  for (let i = 0; i < N; i++) blocked[i] = solid[i] || outside[i] ? 1 : 0;
  return { g, solid, outside, blocked, gap };
}

/**
 * How far one walks to the nearest of some points (extinguishers, hose reels) from anywhere in each zone, over the
 * free floor with every door open: [{ id, name, max (m), farthest }]. A point on a wall is taken from the free cell
 * nearest to it.
 */
export function reachAnalysis({ barriers = [], openings = [], rooms = [], sources = [], cell = 150, margin = 3000 }) {
  const fg = floorGrid({ barriers, openings, rooms, cell, margin });
  if (!fg) return [];
  const { g, blocked } = fg;
  const cellOf = (p) => {
    const cx = Math.floor((p[0] - g.x0) / cell);
    const cy = Math.floor((p[1] - g.y0) / cell);
    let best = -1;
    let bd = Infinity;
    for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
      const x = cx + dx;
      const y = cy + dy;
      if (x < 0 || y < 0 || x >= g.w || y >= g.h || blocked[y * g.w + x]) continue;
      const d = dx * dx + dy * dy;
      if (d < bd) (bd = d), (best = y * g.w + x);
    }
    return best;
  };
  const src = sources.map(cellOf).filter((i) => i >= 0);
  const d = src.length ? distances(g, src, blocked) : null;
  const center = (i) => [g.x0 + ((i % g.w) + 0.5) * cell, g.y0 + (((i / g.w) | 0) + 0.5) * cell];
  return rooms.map((r) => {
    const cells = cellsIn(g, r.poly).filter((i) => !blocked[i]);
    let max = cells.length ? 0 : NaN;
    let far = -1;
    for (const i of cells) {
      const v = d ? d[i] : Infinity;
      if (v > max) (max = v), (far = i);
    }
    return { id: r.id, name: r.name, max: Number.isFinite(max) ? (max * cell) / 1000 : max, farthest: far >= 0 ? center(far) : null };
  });
}

export function egressAnalysis({ barriers = [], openings = [], exits = null, maybeExits = [], rooms = [], profile = 'A2', cell = 150, margin = 3000 }) {
  const lim = RVITA[profile] || RVITA.A2;
  const fg = floorGrid({ barriers, openings, rooms, cell, margin });
  if (!fg) return { profile, limits: lim, rooms: [], exits: [], ok: true };
  const { g, outside, blocked, gap } = fg;
  const N = g.w * g.h;
  const touchesOutside = (cells) => cells.some((i) => outside[i - 1] || outside[i + 1] || outside[i - g.w] || outside[i + g.w] || outside[i]);
  // Exits: those given, those that may be (onto an external stair) when they lead outside, else all that lead outside.
  const exitList = openings.filter((o) => (exits ? exits.includes(o.id) || (maybeExits.includes(o.id) && touchesOutside(gap.get(o.id) || [])) : touchesOutside(gap.get(o.id) || [])));
  const fields = exitList.map((o) => distances(g, (gap.get(o.id) || []).filter((i) => !outside[i]), blocked));
  // Exit to exit, for the dead-end stretch.
  const between = exitList.map((_, a) => exitList.map((o, b) => (a === b ? 0 : Math.min(...(gap.get(o.id) || []).map((i) => fields[a][i]).filter(Number.isFinite), Infinity))));
  const toM = (v) => (v * cell) / 1000;
  const center = (i) => [g.x0 + ((i % g.w) + 0.5) * cell, g.y0 + (((i / g.w) | 0) + 0.5) * cell];
  const independent = 5000 / cell;
  const deadEnd = (i) => {
    let best = Infinity;
    let reach = 0;
    for (let a = 0; a < fields.length; a++) {
      if (!Number.isFinite(fields[a][i])) continue;
      reach++;
      for (let b = a + 1; b < fields.length; b++) {
        if (!Number.isFinite(fields[b][i]) || !(between[a][b] >= independent)) continue;
        best = Math.min(best, Math.max(0, (fields[a][i] + fields[b][i] - between[a][b]) / 2));
      }
    }
    if (!reach) return Infinity;
    // One exit (or none far enough from the others): the whole way out is a dead end.
    if (!Number.isFinite(best)) best = Math.min(...fields.map((f) => f[i]));
    return best;
  };
  const occByExit = new Map(exitList.map((o) => [o.id, 0]));
  const roomsOut = [];
  for (const r of rooms) {
    const cells = cellsIn(g, r.poly).filter((i) => !blocked[i]);
    if (!cells.length) continue;
    let les = -1;
    let far = -1;
    let lcc = 0;
    for (const i of cells) {
      let d = Infinity;
      for (const f of fields) if (f[i] < d) d = f[i];
      if (d > les) (les = d), (far = i);
      const l = deadEnd(i);
      if (l > lcc) lcc = l;
    }
    // The exit its farthest point goes to, and the way there (down the distances).
    let k = -1;
    let best = Infinity;
    fields.forEach((f, j) => f[far] < best && ((best = f[far]), (k = j)));
    const path = [];
    if (k >= 0 && Number.isFinite(best)) {
      let i = far;
      for (let guard = 0; guard < g.w * g.h && fields[k][i] > 0; guard++) {
        path.push(center(i));
        const x = i % g.w;
        const y = (i / g.w) | 0;
        let next = -1;
        let nv = fields[k][i];
        for (const [dx, dy] of STEPS) {
          const nx = x + dx;
          const ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= g.w || ny >= g.h) continue;
          const j = ny * g.w + nx;
          if (fields[k][j] < nv) (nv = fields[k][j]), (next = j);
        }
        if (next < 0) break;
        i = next;
      }
      path.push(center(i));
    }
    const occ = Math.max(0, +r.occupants || 0);
    if (k >= 0) occByExit.set(exitList[k].id, occByExit.get(exitList[k].id) + occ);
    const lesM = Number.isFinite(les) ? toM(les) : Infinity;
    const lccM = Number.isFinite(lcc) ? toM(lcc) : Infinity;
    roomsOut.push({ id: r.id, name: r.name, occupants: occ, les: lesM, lcc: lccM, exitId: k >= 0 ? exitList[k].id : null, farthest: center(far), path: simplify(path, cell * 1.5), ok: lesM <= lim.les && lccM <= lim.lcc });
  }
  const exitsOut = exitList.map((o) => {
    const n = occByExit.get(o.id) || 0;
    // The width the occupants need (unit width), and never under the doorway minimum.
    const required = n ? Math.max(minDoorWidth(n), Math.ceil(n * lim.unit)) : 0;
    return { id: o.id, occupants: n, width: Math.round(+o.width || 0), required, ok: (+o.width || 0) >= required };
  });
  return { profile, limits: lim, rooms: roomsOut, exits: exitsOut, ok: roomsOut.every((r) => r.ok) && exitsOut.every((e) => e.ok) };
}
