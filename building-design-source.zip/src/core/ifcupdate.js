/**
 * Update with IFC Model (Archicad's): bring a new version of an IFC file
 * into a project made from an earlier one, matching elements by their IFC
 * GlobalId. The file is read into a scratch project with the same import as
 * Open IFC as Model (io/ifcmodel.js); then each element whose GlobalId is
 * already in the project takes the new geometry and IFC data (its own
 * classifications, custom properties and graphics stay), elements new in
 * the file are added, and elements of the project that came from IFC but
 * are no longer in it are listed (and removed if asked).
 */
import { createProject } from './template.js';
import { ifcToModel } from '../io/ifcmodel.js';

// Fields an IFC import sets that an update replaces; the rest of an element stays the project's own.
const GEOMETRY = ['a', 'b', 'arc', 'boundary', 'holes', 'at', 't', 'width', 'height', 'depth', 'sill', 'baseOffset', 'topOffset', 'offset', 'endOffset', 'rotation', 'slopes', 'overhangs', 'diameter', 'locationLine', 'flipped', 'flipFacing', 'flipHand', 'upperOffset', 'points', 'parts', 'mesh'];
const IFC_DATA = ['ifcProps', 'ifcName'];

/**
 * Compare and (with apply) update. Returns { updated: [id], added: [id], gone: [id], unchanged: n } where ids are of
 * the project (added: the new elements' ids after apply, or the file's GlobalIds before).
 * Run inside a transaction when apply is true.
 */
export function updateFromIFC(doc, text, { apply = false, removeGone = false, name = 'IFC model' } = {}) {
  const scratch = createProject({ system: doc.units?.system || 'metric' });
  scratch.transact('read', () => ifcToModel(scratch, text, { name }));
  const byGuid = new Map();
  for (const el of doc.items.values()) if (el.ifcGuid) byGuid.set(el.ifcGuid, el);
  const fresh = [...scratch.items.values()].filter((el) => el.ifcGuid);
  const freshGuids = new Set(fresh.map((el) => el.ifcGuid));
  // Levels by elevation; types by id (the same template), else copied; hosts by GlobalId.
  const levelMap = new Map();
  for (const lv of scratch.levels()) {
    const mine = doc.levels().find((l) => Math.abs(l.elevation - lv.elevation) < 20) || null;
    levelMap.set(lv.id, mine?.id ?? null);
  }
  const typeMap = new Map();
  const mapRef = (key, v, newLevels) => {
    if (!v) return v;
    if (key === 'levelId' || key === 'topLevelId') return levelMap.get(v) ?? newLevels.get(v) ?? v;
    if (key === 'hostId') {
      const host = scratch.get(v);
      return (host?.ifcGuid && (byGuid.get(host.ifcGuid)?.id ?? typeMap.get(`host:${host.ifcGuid}`))) || v;
    }
    if (key === 'typeId') {
      if (doc.has(v)) return v;
      if (typeMap.has(v)) return typeMap.get(v);
      const t = scratch.get(v);
      if (!t) return v;
      const { id: _old, ...rest } = t;
      void _old;
      const nt = apply ? doc.add(rest) : { id: v };
      typeMap.set(v, nt.id);
      return nt.id;
    }
    return v;
  };
  const out = { updated: [], added: [], gone: [], unchanged: 0 };
  const newLevels = new Map();
  if (apply)
    for (const lv of scratch.levels())
      if (!levelMap.get(lv.id)) {
        const { id: _i, ...rest } = lv;
        void _i;
        const nl = doc.add(rest);
        newLevels.set(lv.id, nl.id);
        doc.add({ kind: 'plan', name: nl.name, levelId: nl.id, scale: 100, detail: 'medium' });
      }
  // Hosts first, so their hosted elements find them.
  const order = [...fresh].sort((x, y) => (x.hostId ? 1 : 0) - (y.hostId ? 1 : 0));
  for (const el of order) {
    const mine = byGuid.get(el.ifcGuid);
    const patch = {};
    for (const k of [...GEOMETRY, ...IFC_DATA, 'levelId', 'topLevelId', 'hostId', 'typeId']) {
      if (!(k in el)) continue;
      const v = ['levelId', 'topLevelId', 'hostId', 'typeId'].includes(k) ? mapRef(k, el[k], newLevels) : el[k];
      if (!mine || JSON.stringify(mine[k]) !== JSON.stringify(v)) patch[k] = v;
    }
    if (mine) {
      if (!Object.keys(patch).length) {
        out.unchanged++;
        continue;
      }
      if (apply) doc.update(mine.id, patch);
      out.updated.push(mine.id);
    } else if (el.kind !== 'level' && el.kind !== 'plan') {
      if (apply) {
        const { id: _i, ...rest } = el;
        void _i;
        const added = doc.add({ ...rest, ...patch });
        typeMap.set(`host:${el.ifcGuid}`, added.id);
        out.added.push(added.id);
      } else out.added.push(el.ifcGuid);
    }
  }
  for (const [g, el] of byGuid) if (!freshGuids.has(g) && el.kind !== 'level') out.gone.push(el.id);
  if (apply && removeGone) for (const id of out.gone) doc.remove(id);
  return out;
}
