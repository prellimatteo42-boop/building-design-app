/**
 * IDS (buildingSMART Information Delivery Specification, version 1.0):
 * read an .ids file and check the model against it, as Archicad's Import IDS
 * File does. Each specification says which elements it applies to
 * (applicability) and what they must have (requirements), both made of
 * facets: entity, attribute, property, classification, material, partOf.
 *
 * The model is checked as it exports to IFC (io/ifc.js): the entity and
 * predefined type, the attributes (Name = the type's name, Tag = the mark,
 * GlobalId, Description), the property sets (those brought from an IFC file
 * and the custom properties, one set per group, plus Pset_*Common
 * IsExternal and LoadBearing), the classifications of every system, the
 * materials of the type's layers, and the storey the element is in.
 */
import { ifcEntityOf } from '../io/ifc.js';
import { typeLabel } from './catalog.js';
import { classOf } from './classify.js';
import { paramsForElement, paramValueOf } from './params.js';
import { ifcGuidFor } from './issues.js';
import { levelOf } from './model.js';
import { MODEL_KINDS } from './scene.js';

// A small XML reader --------------------------------------------------------------------------

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
const unescape = (s) => s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => (e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1)) : ENT[e] ?? m));

/** XML text to a tree of { name (without prefix), attrs, children, text }. */
export function parseXML(text) {
  const root = { name: '#root', attrs: {}, children: [], text: '' };
  const stack = [root];
  const re = /<!--[\s\S]*?-->|<!\[CDATA\[([\s\S]*?)\]\]>|<\?[\s\S]*?\?>|<!DOCTYPE[^>]*>|<(\/?)([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|([^<]+)/g;
  let m;
  while ((m = re.exec(text))) {
    const top = stack[stack.length - 1];
    if (m[1] !== undefined) top.text += m[1];
    else if (m[3]) {
      const name = m[3].replace(/^.*:/, '');
      if (m[2]) {
        if (stack.length > 1) stack.pop();
        continue;
      }
      const attrs = {};
      for (const a of m[4].matchAll(/([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) attrs[a[1].replace(/^.*:/, '')] = unescape(a[2] ?? a[3]);
      const node = { name, attrs, children: [], text: '' };
      top.children.push(node);
      if (!m[5]) stack.push(node);
    } else if (m[6] !== undefined) top.text += unescape(m[6]);
  }
  return root;
}

const kids = (n, name) => (n?.children || []).filter((c) => c.name === name);
const kid = (n, name) => kids(n, name)[0] || null;

// Values ----------------------------------------------------------------------------------------

/**
 * A value condition from an IDS value element: { simple } or { enumeration, pattern, bounds, length } (a
 * restriction), or null for "any value".
 */
function readValue(node) {
  if (!node) return null;
  const sv = kid(node, 'simpleValue');
  if (sv) return { simple: sv.text.trim() };
  const r = kid(node, 'restriction');
  if (!r) return null;
  const out = { base: r.attrs.base || '' };
  const vals = (n) => kids(r, n).map((x) => x.attrs.value);
  if (kids(r, 'enumeration').length) out.enumeration = vals('enumeration');
  if (kids(r, 'pattern').length) out.pattern = vals('pattern');
  for (const k of ['minInclusive', 'maxInclusive', 'minExclusive', 'maxExclusive', 'length', 'minLength', 'maxLength']) if (kid(r, k)) out[k] = +kid(r, k).attrs.value;
  return out;
}

/** XSD regular expression to a JavaScript one (anchored, XSD's \i and \c classes approximated). */
const xsdRegex = (p) => new RegExp(`^(?:${p.replace(/\\i/g, '[A-Za-z_:]').replace(/\\c/g, '[\\w.:-]')})$`, 'u');

const numeric = (v) => (typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' && Number.isFinite(+v) ? +v : null);

/** Does a value meet a condition? Numbers compare with IDS's relative tolerance of 1e-6. */
export function valueMatches(cond, v) {
  if (!cond) return v !== null && v !== undefined && v !== '';
  if (v === null || v === undefined) return false;
  const vs = Array.isArray(v) ? v : [v];
  const one = (x) => {
    const s = typeof x === 'boolean' ? (x ? 'TRUE' : 'FALSE') : String(x);
    const n = numeric(x);
    const eq = (t) => {
      const tn = numeric(t);
      if (n !== null && tn !== null) return Math.abs(n - tn) <= 1e-6 * Math.max(1, Math.abs(tn));
      if (typeof x === 'boolean') return String(t).toUpperCase() === s;
      return s === String(t);
    };
    if (cond.simple !== undefined) return eq(cond.simple);
    if (cond.enumeration && !cond.enumeration.some(eq)) return false;
    if (cond.pattern && !cond.pattern.every((p) => xsdRegex(p).test(s))) return false;
    if (cond.minInclusive !== undefined && !(n !== null && n >= cond.minInclusive - 1e-9)) return false;
    if (cond.maxInclusive !== undefined && !(n !== null && n <= cond.maxInclusive + 1e-9)) return false;
    if (cond.minExclusive !== undefined && !(n !== null && n > cond.minExclusive)) return false;
    if (cond.maxExclusive !== undefined && !(n !== null && n < cond.maxExclusive)) return false;
    if (cond.length !== undefined && s.length !== cond.length) return false;
    if (cond.minLength !== undefined && s.length < cond.minLength) return false;
    if (cond.maxLength !== undefined && s.length > cond.maxLength) return false;
    return true;
  };
  return vs.some(one);
}

const describe = (c) => (!c ? 'any value' : c.simple !== undefined ? `"${c.simple}"` : c.enumeration ? `one of ${c.enumeration.join(', ')}` : c.pattern ? `matching ${c.pattern.join(' and ')}` : 'a value in range');

// Reading the file ------------------------------------------------------------------------------

function readFacets(node) {
  const out = [];
  for (const c of node?.children || []) {
    const card = c.attrs.cardinality || (c.attrs.minOccurs === '0' && c.attrs.maxOccurs === '0' ? 'prohibited' : c.attrs.minOccurs === '0' ? 'optional' : 'required');
    if (c.name === 'entity') out.push({ facet: 'entity', name: readValue(kid(c, 'name')), predefinedType: readValue(kid(c, 'predefinedType')) });
    else if (c.name === 'attribute') out.push({ facet: 'attribute', name: readValue(kid(c, 'name')), value: readValue(kid(c, 'value')), cardinality: card });
    else if (c.name === 'property') out.push({ facet: 'property', propertySet: readValue(kid(c, 'propertySet')), baseName: readValue(kid(c, 'baseName')), value: readValue(kid(c, 'value')), dataType: c.attrs.dataType || null, cardinality: card });
    else if (c.name === 'classification') out.push({ facet: 'classification', value: readValue(kid(c, 'value')), system: readValue(kid(c, 'system')), cardinality: card });
    else if (c.name === 'material') out.push({ facet: 'material', value: readValue(kid(c, 'value')), cardinality: card });
    else if (c.name === 'partOf') out.push({ facet: 'partOf', relation: c.attrs.relation || null, entity: kid(c, 'entity') ? { name: readValue(kid(kid(c, 'entity'), 'name')), predefinedType: readValue(kid(kid(c, 'entity'), 'predefinedType')) } : null, cardinality: card });
  }
  return out;
}

/** An .ids file: { title, specifications: [{ name, ifcVersion, description, use: 'required'|'optional'|'prohibited', applicability, requirements }] }. */
export function parseIDS(text) {
  const doc = parseXML(text);
  const ids = kid(doc, 'ids');
  if (!ids) throw new Error('Not an IDS file (no ids element)');
  const info = kid(ids, 'info');
  const specs = kids(kid(ids, 'specifications'), 'specification').map((s) => {
    const app = kid(s, 'applicability');
    const min = app?.attrs.minOccurs ?? s.attrs.minOccurs ?? '0';
    const max = app?.attrs.maxOccurs ?? s.attrs.maxOccurs ?? 'unbounded';
    const use = max === '0' ? 'prohibited' : +min >= 1 ? 'required' : 'optional';
    return { name: s.attrs.name || 'Specification', ifcVersion: s.attrs.ifcVersion || '', description: s.attrs.description || '', instructions: s.attrs.instructions || '', use, applicability: readFacets(app), requirements: readFacets(kid(s, 'requirements')) };
  });
  return { title: kid(info, 'title')?.text.trim() || 'IDS', specifications: specs };
}

// The model as IFC ------------------------------------------------------------------------------

/** What an element looks like in the exported IFC, for checking. */
export function ifcFacts(doc, el) {
  const ent = ifcEntityOf(doc, el);
  if (!ent) return null;
  const type = doc.get(el.typeId);
  const psets = {};
  const put = (set, name, v) => ((psets[set] ||= {})[name] = v);
  for (const [k, v] of Object.entries(el.ifcProps || {})) {
    const dot = k.indexOf('.');
    put(dot > 0 ? k.slice(0, dot) : 'Pset', dot > 0 ? k.slice(dot + 1) : k, v);
  }
  for (const p of paramsForElement(doc, el)) {
    const r = paramValueOf({ doc }, el, p);
    if (!r.error && r.value !== null && r.value !== undefined && r.value !== '' && !(Array.isArray(r.value) && !r.value.length)) {
      const t = p.type === 'expression' ? p.result : p.type;
      put(p.group || 'Identity Data', p.name, t === 'area' ? r.value / 1e6 : t === 'volume' ? r.value / 1e9 : Array.isArray(r.value) ? r.value.join('; ') : r.value);
    }
  }
  // Common property sets the app knows the answer to.
  const common = { IFCWALL: 'Pset_WallCommon', IFCSLAB: 'Pset_SlabCommon', IFCCOLUMN: 'Pset_ColumnCommon', IFCBEAM: 'Pset_BeamCommon', IFCDOOR: 'Pset_DoorCommon', IFCWINDOW: 'Pset_WindowCommon', IFCROOF: 'Pset_RoofCommon' }[ent.entity];
  if (common) {
    if (type?.function) put(common, 'IsExternal', type.function === 'exterior');
    if (el.structural !== undefined || ['IFCCOLUMN', 'IFCBEAM'].includes(ent.entity)) put(common, 'LoadBearing', el.structural ?? true);
    if (type?.name) put(common, 'Reference', type.name);
    if (el.fireRating) put(common, 'FireRating', String(el.fireRating));
  }
  const classifications = [];
  for (const sys of doc.all('classSystem')) {
    const item = classOf(doc, el, sys);
    if (item) classifications.push({ system: sys.name, value: item.code, name: item.name });
  }
  const materials = [];
  for (const l of type?.layers || []) {
    const m = doc.get(l.materialId);
    if (m && !materials.includes(m.name)) materials.push(m.name);
  }
  const single = doc.get(type?.materialId || el.materialId);
  if (single && !materials.includes(single.name)) materials.push(single.name);
  const lv = levelOf(doc, el);
  return {
    id: el.id,
    entity: ent.entity,
    predefinedType: ent.predefinedType,
    attributes: { Name: el.kind === 'room' ? el.number || el.name : type ? typeLabel(type) : el.kind, Tag: el.mark || el.id, GlobalId: el.ifcGuid || ifcGuidFor(el.id), Description: el.comments || undefined, LongName: el.kind === 'room' ? el.name : undefined, ObjectType: type?.name },
    psets,
    classifications,
    materials,
    container: lv ? { entity: 'IFCBUILDINGSTOREY', name: lv.name } : null,
  };
}

// Checking --------------------------------------------------------------------------------------

/** Does the element have what a facet describes? { ok, why } */
function facetHolds(f, x) {
  switch (f.facet) {
    case 'entity': {
      const ok = valueMatches(f.name && f.name.simple !== undefined ? { simple: f.name.simple.toUpperCase() } : f.name, x.entity) && (!f.predefinedType || valueMatches(f.predefinedType, x.predefinedType));
      return { ok, why: `is ${x.entity}${x.predefinedType ? `.${x.predefinedType}` : ''}` };
    }
    case 'attribute': {
      const names = Object.keys(x.attributes).filter((n) => valueMatches(f.name, n) && x.attributes[n] !== undefined && x.attributes[n] !== '');
      if (!names.length) return { ok: false, found: false, why: `has no attribute ${describe(f.name)}` };
      const ok = names.every((n) => valueMatches(f.value, x.attributes[n]));
      return { ok, found: true, why: ok ? '' : `attribute ${names[0]} is "${x.attributes[names[0]]}", not ${describe(f.value)}` };
    }
    case 'property': {
      const hits = [];
      for (const [set, props] of Object.entries(x.psets)) {
        if (!valueMatches(f.propertySet, set)) continue;
        for (const [n, v] of Object.entries(props)) if (valueMatches(f.baseName, n)) hits.push([set, n, v]);
      }
      if (!hits.length) return { ok: false, found: false, why: `has no property ${describe(f.propertySet)}.${describe(f.baseName)}` };
      const bad = hits.find(([, , v]) => !valueMatches(f.value, v));
      return { ok: !bad, found: true, why: bad ? `${bad[0]}.${bad[1]} is "${bad[2]}", not ${describe(f.value)}` : '' };
    }
    case 'classification': {
      const hits = x.classifications.filter((c) => (!f.system || valueMatches(f.system, c.system)) && (!f.value || valueMatches(f.value, c.value)));
      return { ok: hits.length > 0, found: x.classifications.length > 0, why: hits.length ? '' : x.classifications.length ? `is classified ${x.classifications.map((c) => `${c.system} ${c.value}`).join(', ')}` : 'has no classification' };
    }
    case 'material': {
      const hits = x.materials.filter((m) => !f.value || valueMatches(f.value, m));
      return { ok: hits.length > 0, found: x.materials.length > 0, why: hits.length ? '' : x.materials.length ? `has materials ${x.materials.join(', ')}` : 'has no material' };
    }
    case 'partOf': {
      const c = x.container;
      const relOk = !f.relation || f.relation.toUpperCase() === 'IFCRELCONTAINEDINSPATIALSTRUCTURE';
      const entOk = c && (!f.entity || valueMatches(f.entity.name?.simple !== undefined ? { simple: f.entity.name.simple.toUpperCase() } : f.entity.name, c.entity));
      return { ok: !!(relOk && entOk), found: !!c, why: relOk && entOk ? '' : `is ${c ? `in ${c.entity} ${c.name}` : 'in no storey'}${relOk ? '' : ` (only spatial containment is known, not ${f.relation})`}` };
    }
    default:
      return { ok: false, why: `unknown facet ${f.facet}` };
  }
}

/** A requirement with its cardinality: required must hold, prohibited must not be there, optional must hold if there. */
function requirementHolds(f, x) {
  const r = facetHolds(f, x);
  const card = f.cardinality || 'required';
  if (f.facet === 'entity') return r;
  if (card === 'prohibited') return { ok: !r.ok, why: r.ok ? `should not have this ${f.facet}${f.facet === 'property' ? ` ${describe(f.baseName)}` : ''}` : '' };
  if (card === 'optional') return r.found === false ? { ok: true, why: '' } : r;
  return r;
}

/**
 * Check a model against an IDS: { title, specifications: [{ name, use, ok, applicable, passed, failed: [{ id, reasons }] }],
 * ok }. Elements: every model element that exports to IFC, and rooms (IfcSpace).
 */
export function checkIDS(doc, ids) {
  const facts = [];
  for (const el of doc.items.values()) {
    if (!(MODEL_KINDS.includes(el.kind) || el.kind === 'room') || el.viewId) continue;
    const x = ifcFacts(doc, el);
    if (x) facts.push(x);
  }
  const specifications = ids.specifications.map((s) => {
    const applicable = facts.filter((x) => s.applicability.every((f) => facetHolds(f, x).ok));
    const failed = [];
    let passed = 0;
    if (s.use !== 'prohibited')
      for (const x of applicable) {
        const reasons = s.requirements.map((f) => requirementHolds(f, x)).filter((r) => !r.ok).map((r) => r.why);
        if (reasons.length) failed.push({ id: x.id, entity: x.entity, name: x.attributes.Name, reasons });
        else passed++;
      }
    let ok = !failed.length;
    let note = '';
    if (s.use === 'required' && !applicable.length) (ok = false), (note = 'No element it applies to, and the specification requires at least one.');
    if (s.use === 'prohibited' && applicable.length) (ok = false), (note = `${applicable.length} elements it applies to, and the specification prohibits them.`);
    return { name: s.name, description: s.description, use: s.use, ok, applicable: applicable.length, passed, failed, note, prohibited: s.use === 'prohibited' ? applicable.map((x) => x.id) : [] };
  });
  return { title: ids.title, specifications, ok: specifications.every((s) => s.ok) };
}
