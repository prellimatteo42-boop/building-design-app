/**
 * External references (Archicad's Attach Xref, Xref Manager and Place External
 * Drawing, reimplemented): a DWG/DXF attached to a 2D view, or a PDF or picture
 * placed on a layout, stays linked to its file (io/filelinks.js) and can be
 * brought up to date when the file changes.
 *
 *   xref   { kind: 'xref', name, viewId, settings (the import's), lastModified, size, linked }
 *   image  { ..., extLink: id, lastModified }   an external drawing on a layout
 */

/** The state of a link from what reading its file gave: 'current' | 'changed' | 'missing' | 'permission' | 'copy'. */
export function linkState(item, read) {
  if (!item.linked) return 'copy';
  if (!read || read.state === 'missing') return 'missing';
  if (read.state === 'permission') return 'permission';
  const f = read.file;
  return f && (f.lastModified > (+item.lastModified || 0) + 1 || (item.size != null && f.size !== item.size)) ? 'changed' : 'current';
}

export const LINK_LABEL = {
  current: 'Up to date',
  changed: 'Changed on disk',
  missing: 'File not found',
  permission: 'Needs permission',
  copy: 'Embedded copy (no live link)',
};

/**
 * Where an external drawing goes on a layout: { at, w, h } in paper mm. A PDF page keeps its paper size (1:1, at
 * most the layout's width less margins); a picture takes half the layout's width. Centred.
 */
export function externalPlacement(sheet, { pageMm = null, px = null }) {
  const W = sheet.w;
  const H = sheet.h;
  let w;
  let h;
  if (pageMm) [w, h] = pageMm;
  else {
    w = W / 2;
    h = (w * (px?.[1] || 1)) / (px?.[0] || 1);
  }
  const k = Math.min(1, (W - 20) / w, (H - 20) / h);
  w *= k;
  h *= k;
  return { at: [(W - w) / 2, (H - h) / 2], w, h };
}

/** The elements a DWG import of a file brought into a view. */
export function xrefElements(doc, x) {
  const out = [];
  for (const el of doc.items.values()) if (el.cadSource === x.name && (el.viewId === x.viewId || (!el.viewId && el.levelId === doc.get(x.viewId)?.levelId))) out.push(el);
  return out;
}
