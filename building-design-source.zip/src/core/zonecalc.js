/**
 * Zone area calculation, as in Archicad's zone calculation rules: besides
 * the net area (inside the walls), a gross area to the wall centre lines,
 * and a reduced area where the room is low under a sloping roof: parts
 * lower than each height threshold count only by that rule's percentage.
 *
 *   project.areaRules: [{ below: mm, percent }]   e.g. lower than 1500 mm counts 0 %
 */
import { pointInPolygon, offsetPolygon, area as polyArea, distToSegment } from './geom.js';
import { levelElevation } from './model.js';
import { roofGeometry } from './build3d.js';
import { roofHeightAt } from './roof.js';
import { typeThickness } from './catalog.js';
import { polygonBoolean } from './polybool.js';
import { openingSize, wallLength } from './model.js';
import { columnOutline } from './plan.js';

export const DEFAULT_AREA_RULES = [{ below: 1500, percent: 0 }];

export function areaRules(doc) {
  const r = doc.project?.areaRules;
  return Array.isArray(r) ? r.filter((x) => +x.below > 0) : DEFAULT_AREA_RULES;
}

/** The share of a point's area that counts for a clear height h. */
export function heightFactor(rules, h) {
  const sorted = rules.slice().sort((a, b) => a.below - b.below);
  const r = sorted.find((x) => h < +x.below);
  return r ? Math.max(0, Math.min(100, +r.percent || 0)) / 100 : 1;
}

/** Gross area: the room grown to the centre lines of the walls around it. */
export function grossArea(doc, region, room) {
  if (!region) return 0;
  const walls = doc.all('wall').filter((w) => w.levelId === room.levelId && !w.arc);
  const halves = [];
  for (const w of walls) {
    const t = typeThickness(doc.get(w.typeId)) / 2;
    if (region.outer.some((p, i) => distToSegment(p, w.a, w.b) <= t + 5 || distToSegment(region.outer[(i + 1) % region.outer.length], w.a, w.b) <= t + 5)) halves.push(t);
  }
  const d = halves.length ? halves.reduce((s, x) => s + x, 0) / halves.length : 0;
  const outer = d > 0 ? offsetPolygon(region.outer, d) : region.outer;
  return polyArea(outer) - (region.holes || []).reduce((s, hh) => s + polyArea(hh), 0);
}

/**
 * Reduced area of a room: its net region sampled on a grid, each sample
 * counting by the height factor of the clear height above it (the room's
 * height, or a roof over it when that is lower).
 */
export function reducedArea(doc, region, room, rules = areaRules(doc)) {
  if (!region) return 0;
  const floor = levelElevation(doc, room.levelId);
  const roofs = doc
    .all('roof')
    .filter((r) => r.boundary?.length >= 3)
    .map((r) => roofGeometry(doc, r))
    .filter((g) => g.base >= floor - 1);
  const full = +room.upperOffset || 2700;
  const xs = region.outer.map((p) => p[0]);
  const ys = region.outer.map((p) => p[1]);
  const x0 = Math.min(...xs);
  const x1 = Math.max(...xs);
  const y0 = Math.min(...ys);
  const y1 = Math.max(...ys);
  const step = Math.max(50, Math.sqrt(((x1 - x0) * (y1 - y0)) / 20000));
  let counted = 0;
  let inside = 0;
  for (let x = x0 + step / 2; x < x1; x += step)
    for (let y = y0 + step / 2; y < y1; y += step) {
      const p = [x, y];
      if (!pointInPolygon(p, region.outer) || (region.holes || []).some((hh) => pointInPolygon(p, hh))) continue;
      inside++;
      let h = full;
      for (const g of roofs) if (pointInPolygon(p, g.poly)) h = Math.min(h, g.base + (g.planes.length ? roofHeightAt(g.planes, p) : 0) - floor);
      counted += heightFactor(rules, h);
    }
  return inside ? (region.area * counted) / inside : region.area;
}

// Zone deductions (Project Preferences > Zones) --------------------------------------------------------

/**
 * project.zoneRules: how much of a free-standing column counts as taken off the zone (percent, and only columns
 * of at least columnMinArea m²), how much of a fill marked Subtract from Zones, and whether door and window
 * niches reaching the floor add to the zone when they are at least nicheMinDepth (mm) deep.
 */
export const ZONE_DEFAULTS = { columnPercent: 100, columnMinArea: 0, fillPercent: 100, addNiches: false, nicheMinDepth: 130 };

export const zoneRules = (project) => ({ ...ZONE_DEFAULTS, ...(project?.zoneRules || {}) });

/** The area (mm²) of a shape inside the region. */
function overlapArea(region, shape) {
  const out = polygonBoolean({ boundary: region.outer, holes: region.holes || [] }, shape, 'intersect');
  return out.reduce((s, x) => s + polyArea(x.boundary) - (x.holes || []).reduce((t, hh) => t + polyArea(hh), 0), 0);
}

/** The part of a column touching the region that stands clear of the walls (mm²); 0 when it does not touch. */
function attachedColumnArea(doc, region, room, c) {
  const outline = columnOutline(doc, c);
  if (!outline?.length || !outline.some((p) => region.outer.some((q, i) => distToSegment(p, q, region.outer[(i + 1) % region.outer.length]) <= 5))) return 0;
  const walls = doc.all('wall').filter((w) => w.levelId === room.levelId && !w.arc).map((w) => [w, typeThickness(doc.get(w.typeId)) / 2]);
  const xs = outline.map((p) => p[0]);
  const ys = outline.map((p) => p[1]);
  const STEP = 10;
  let cells = 0;
  for (let x = Math.min(...xs) + STEP / 2; x < Math.max(...xs); x += STEP)
    for (let y = Math.min(...ys) + STEP / 2; y < Math.max(...ys); y += STEP) if (pointInPolygon([x, y], outline) && !walls.some(([w, t]) => distToSegment([x, y], w.a, w.b) <= t)) cells++;
  return cells * STEP * STEP;
}

/** Door and window niches of the walls round a region that add to it (mm²). */
function nicheArea(doc, region, room, minDepth) {
  let total = 0;
  for (const kind of ['door', 'window'])
    for (const o of doc.all(kind)) {
      const w = doc.get(o.hostId);
      if (!w || w.levelId !== room.levelId || w.arc) continue;
      const size = openingSize(doc, o);
      if (size.sill > 1) continue;
      const depth = typeThickness(doc.get(w.typeId)) / 2;
      if (depth < minDepth) continue;
      const L = wallLength(w) || 1;
      const u = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
      const c = [w.a[0] + u[0] * o.t, w.a[1] + u[1] * o.t];
      // The niche belongs to the room on whose boundary the face of the wall lies.
      const faces = [1, -1].map((k) => [c[0] - u[1] * k * depth, c[1] + u[0] * k * depth]);
      const near = faces.filter((f) => region.outer.some((p, i) => distToSegment(f, p, region.outer[(i + 1) % region.outer.length]) <= 30));
      if (near.length) total += size.width * depth;
    }
  return total;
}

/**
 * Calculated area of a zone: the reduced area with the Zones preferences applied. Free-standing columns are
 * already out of the net region, so those that should not count go back in.
 */
export function calculatedArea(doc, region, room) {
  if (!region) return 0;
  const r = zoneRules(doc.get('project'));
  let total = reducedArea(doc, region, room);
  const columns = doc.all('column').filter((c) => c.levelId === room.levelId);
  const backIn = (a) => (a < +r.columnMinArea * 1e6 ? a : a * (1 - Math.max(0, Math.min(100, +r.columnPercent)) / 100));
  const free = new Set();
  for (const hole of region.holes || []) {
    const c = columns.find((x) => pointInPolygon(x.at, hole));
    if (!c) continue;
    free.add(c.id);
    total += backIn(polyArea(hole));
  }
  // A column against a wall notches the zone's outline: what stands outside the walls goes back in the same way.
  if (+r.columnPercent < 100 || +r.columnMinArea > 0)
    for (const c of columns) if (!free.has(c.id)) total += backIn(attachedColumnArea(doc, region, room, c));
  for (const f of doc.all('region')) {
    if (!f.deductFromZones || doc.get(f.viewId)?.levelId !== room.levelId) continue;
    total -= overlapArea(region, { boundary: f.boundary, holes: f.holes || [] }) * (Math.max(0, Math.min(100, +r.fillPercent)) / 100);
  }
  if (r.addNiches) total += nicheArea(doc, region, room, +r.nicheMinDepth || 0);
  return Math.max(0, total);
}
