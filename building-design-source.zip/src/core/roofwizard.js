/**
 * Roof Wizard, as Archicad's: a whole roof over a building in one go, by
 * type (hip, gable, shed, mansard, gambrel) with its slope and overhang, on
 * the outline round the selected walls' outer faces (or a selected slab's).
 */
import { wallAxis, verticalExtent, levelElevation } from './model.js';
import { offsetPolygon, signedArea } from './geom.js';

export const ROOF_TYPES = [
  { value: 'hip', label: 'Hip' },
  { value: 'gable', label: 'Gable' },
  { value: 'shed', label: 'Shed (one plane)' },
  { value: 'mansard', label: 'Mansard' },
  { value: 'gambrel', label: 'Gambrel' },
];

const near = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]) < 5;

/** The selected walls chained end to end into a closed loop of their axes (counterclockwise), or null. */
export function wallLoop(doc, walls) {
  if (walls.length < 3) return null;
  const segs = walls.map((w) => {
    const ax = wallAxis(doc, w);
    return { w, a: ax.a, b: ax.b, half: ax.half };
  });
  const loop = [segs[0].a, segs[0].b];
  const used = new Set([0]);
  while (used.size < segs.length) {
    const end = loop.at(-1);
    const i = segs.findIndex((s, k) => !used.has(k) && (near(s.a, end) || near(s.b, end)));
    if (i < 0) return null;
    used.add(i);
    loop.push(near(segs[i].a, end) ? segs[i].b : segs[i].a);
  }
  if (!near(loop[0], loop.at(-1))) return null;
  loop.pop();
  const ccw = signedArea(loop) > 0 ? loop : loop.slice().reverse();
  // Out to the walls' outer faces.
  return offsetPolygon(ccw, Math.max(...segs.map((s) => s.half)));
}

/**
 * The roof for an outline: { boundary, slopes, overhangs, levels } by type.
 * Gable and gambrel slope the two long sides (those along the outline's
 * longest edge), shed slopes its longest edge only; mansard and gambrel break
 * at upperHeight to the upper slope.
 */
export function wizardRoof(boundary, { type = 'hip', slope = 30, overhang = 500, upperHeight = 1800, upperSlope = 20, lowerSlope = 65 } = {}) {
  const n = boundary.length;
  const dirs = boundary.map((p, i) => {
    const q = boundary[(i + 1) % n];
    const l = Math.hypot(q[0] - p[0], q[1] - p[1]) || 1;
    return { d: [(q[0] - p[0]) / l, (q[1] - p[1]) / l], l };
  });
  const longest = dirs.reduce((a, b) => (b.l > a.l ? b : a));
  const along = (i) => Math.abs(dirs[i].d[0] * longest.d[0] + dirs[i].d[1] * longest.d[1]) > 0.98;
  const lowSlope = type === 'mansard' || type === 'gambrel' ? lowerSlope : slope;
  let slopes;
  if (type === 'gable' || type === 'gambrel') slopes = dirs.map((_, i) => (along(i) ? lowSlope : null));
  else if (type === 'shed') slopes = dirs.map((d) => (d === longest ? slope : null));
  else slopes = dirs.map(() => lowSlope);
  const levels = type === 'mansard' || type === 'gambrel' ? [{ height: upperHeight, slope: upperSlope }] : [];
  return { boundary: boundary.map((p) => [Math.round(p[0] * 10) / 10, Math.round(p[1] * 10) / 10]), slopes, overhangs: dirs.map(() => overhang), levels };
}

/** Where the roof sits: on the level of the walls, at their top. */
export function roofBase(doc, walls) {
  const w = walls[0];
  const top = Math.max(...walls.map((x) => verticalExtent(doc, x).top));
  return { levelId: w.levelId, baseOffset: top - levelElevation(doc, w.levelId) };
}
