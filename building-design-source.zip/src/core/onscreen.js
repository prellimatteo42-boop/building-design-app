/**
 * On-screen aids (Archicad's View > On-Screen View Options): the handles of
 * lines and fills, the tangent handles of splines, and a stair's calculated
 * walking line, worked out for the overlay of a floor plan.
 */
import { add, sub, scale, dist } from './geom.js';
import { stairFlights } from './stairs.js';
import { polylineSegments } from './polyline.js';

/** Points of drawn figures in a view: line ends, arc centres and ends, polyline and spline points. */
export function figureHandlePoints(doc, viewId) {
  const out = [];
  for (const l of doc.all('detailLine')) if (l.viewId === viewId && l.a && l.b) out.push(l.a, l.b);
  for (const a of doc.all('detailArc')) {
    if (a.viewId !== viewId || !a.c) continue;
    out.push(a.c);
    const full = Math.abs((a.a1 ?? Math.PI * 2) - (a.a0 ?? 0)) >= Math.PI * 2 - 1e-6;
    if (!full) for (const t of [a.a0, a.a1]) out.push(add(a.c, scale([Math.cos(t), Math.sin(t)], a.r)));
  }
  for (const p of doc.all('polyline')) if (p.viewId === viewId) out.push(...polylineSegments(p).flatMap((s, i) => (i ? [s.b] : [s.a, s.b])));
  for (const s of doc.all('spline')) if (s.viewId === viewId) out.push(...(s.path || []));
  return out;
}

/** The corners of the fills (regions) in a view. */
export function fillHandlePoints(doc, viewId) {
  const out = [];
  for (const r of doc.all('region')) if (r.viewId === viewId) out.push(...(r.boundary || []), ...(r.holes || []).flat());
  return out;
}

/** Tangent handles of a spline: [{ at, a, b }], the two ends of the handle through each point. */
export function splineTangentHandles(el) {
  const pts = el.path || [];
  const n = pts.length;
  if (n < 2) return [];
  return pts.map((p, i) => {
    const prev = i > 0 ? pts[i - 1] : el.closed ? pts[n - 1] : p;
    const next = i < n - 1 ? pts[i + 1] : el.closed ? pts[0] : p;
    // The curve runs through the points with a tangent of half the chord; as a handle, a third of that each way.
    const t = scale(sub(next, prev), 1 / 6);
    return { at: p, a: sub(p, t), b: add(p, t) };
  });
}

/**
 * A stair's calculated walking line: { path, nodes, length, risers, going,
 * rise, step } with a node at each tread's nosing and step = 2R + T.
 */
export function walkingLine(doc, el) {
  const lay = stairFlights(doc, el);
  const path = [];
  const nodes = [];
  if (lay.spiral) {
    const { c, rwalk, a0, step, treads } = lay.spiral;
    const P = (k) => add(c, scale([Math.cos(a0 + step * k), Math.sin(a0 + step * k)], rwalk));
    for (let k = 0; k < treads; k++) nodes.push(P(k));
    path.push(...nodes);
  } else {
    lay.flights.forEach((f, i) => {
      const end = add(f.start, scale(f.dir, f.run));
      for (let k = 0; k < f.risers; k++) nodes.push(add(f.start, scale(f.dir, (f.run / Math.max(1, f.risers - 1)) * k)));
      if (i > 0) {
        // Across the landing: on along the last flight until in line with this one, then to its start.
        const last = path.at(-1);
        const prev = lay.flights[i - 1];
        const t = (f.start[0] - last[0]) * prev.dir[0] + (f.start[1] - last[1]) * prev.dir[1];
        if (t > 1) path.push(add(last, scale(prev.dir, t)));
      }
      path.push(f.start, end);
    });
  }
  const length = path.slice(1).reduce((s, p, k) => s + dist(path[k], p), 0);
  return { path, nodes, length, risers: lay.risers, going: lay.tread, rise: lay.riserHeight, step: 2 * lay.riserHeight + lay.tread };
}

/** The nearest of the lines straight left, right, down and up from p, within range: [{ to, d }]. */
export function distanceHits(lines, p, range) {
  const out = [];
  for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    let best = null;
    for (const l of lines) {
      const ex = l.b[0] - l.a[0];
      const ey = l.b[1] - l.a[1];
      const den = dx * ey - dy * ex;
      if (Math.abs(den) < 1e-9) continue;
      const wx = l.a[0] - p[0];
      const wy = l.a[1] - p[1];
      const t = (wx * ey - wy * ex) / den;
      const u = (wx * dy - wy * dx) / den;
      if (t > 0.5 && t <= range && u >= -1e-6 && u <= 1 + 1e-6 && (best === null || t < best)) best = t;
    }
    if (best !== null) out.push({ to: [p[0] + dx * best, p[1] + dy * best], d: best });
  }
  return out;
}
