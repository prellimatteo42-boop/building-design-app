/**
 * Fly-through, as in Archicad: a camera path through the model, made of
 * cameras recorded from the 3D view or of a path drawn in plan walked at
 * eye height, played back smoothly and recorded as a video.
 *
 *   view3d.flyCameras: [camera], camera = our orbit camera { target, dist, yaw, pitch, persp, fov }
 */
import { splinePoints } from './spline.js';

/** Where a camera stands. */
export function cameraEye(cam) {
  const { target: t, dist, yaw, pitch } = cam;
  return [t[0] + dist * Math.cos(pitch) * Math.cos(yaw), t[1] + dist * Math.cos(pitch) * Math.sin(yaw), t[2] + dist * Math.sin(pitch)];
}

/** An orbit camera standing at eye and looking at target. */
export function cameraLooking(eye, target, base = {}) {
  const v = [eye[0] - target[0], eye[1] - target[1], eye[2] - target[2]];
  const dist = Math.max(1, Math.hypot(...v));
  return { ...base, target: [...target], dist, yaw: Math.atan2(v[1], v[0]), pitch: Math.asin(Math.max(-1, Math.min(1, v[2] / dist))), persp: true, fov: base.fov || 60 };
}

const cr = (p0, p1, p2, p3, t) => {
  const t2 = t * t;
  const t3 = t2 * t;
  return p1.map((_, k) => 0.5 * (2 * p1[k] + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3));
};

/** The camera at u in [0, 1] along a list of cameras (smooth through each). */
export function cameraAt(cams, u) {
  if (!cams.length) return null;
  if (cams.length === 1) return { ...cams[0] };
  const n = cams.length - 1;
  const x = Math.max(0, Math.min(1, u)) * n;
  const i = Math.min(n - 1, Math.floor(x));
  const t = x - i;
  const at = (j) => cams[Math.max(0, Math.min(n, j))];
  const eyes = [i - 1, i, i + 1, i + 2].map((j) => cameraEye(at(j)));
  const tgts = [i - 1, i, i + 1, i + 2].map((j) => at(j).target);
  return cameraLooking(cr(...eyes, t), cr(...tgts, t), { fov: cams[i].fov });
}

/**
 * Cameras walking a plan path (points in mm) at eye height z, a camera
 * every `step` mm, each looking `ahead` mm further along the path.
 */
export function pathCameras(path, z, { closed = false, step = 1500, ahead = 2000 } = {}) {
  const pts = splinePoints(path, closed, 12);
  const along = [0];
  for (let i = 1; i < pts.length; i++) along.push(along[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const total = along.at(-1);
  if (!(total > 0)) return [];
  const pointAt = (s) => {
    s = Math.max(0, Math.min(total, s));
    let i = along.findIndex((a) => a >= s);
    if (i <= 0) return pts[0];
    const t = (s - along[i - 1]) / (along[i] - along[i - 1] || 1);
    return [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t];
  };
  const out = [];
  const n = Math.max(1, Math.round(total / step));
  for (let k = 0; k <= n; k++) {
    const s = (total * k) / n;
    const e = pointAt(s);
    // At the end, keep looking the way the path goes.
    const f = s + ahead <= total ? pointAt(s + ahead) : (() => {
      const a = pointAt(total - 1);
      const b = pointAt(total);
      const d = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
      return [e[0] + ((b[0] - a[0]) / d) * ahead, e[1] + ((b[1] - a[1]) / d) * ahead];
    })();
    out.push(cameraLooking([e[0], e[1], z], [f[0], f[1], z], { fov: 60 }));
  }
  return out;
}
