/**
 * Clean-up after drawings come in from DWG or PDF, as Archicad's Merge
 * Walls / Beams / Columns and Linework Consolidation:
 *
 *   - walls (and beams) on one line that touch or overlap end to end, with
 *     the same type, level, heights and location line, become one; doors
 *     and windows move onto the merged wall at the same place;
 *   - columns stacked on consecutive levels with the same type and place
 *     become one column through the levels;
 *   - detail lines: zero-length ones go, duplicates go, and pieces of one
 *     straight line that touch or overlap (with the same style, in the same
 *     view) become one line.
 */
import { levelElevation, verticalExtent } from './model.js';

const near = (p, q, tol) => Math.abs(p[0] - q[0]) <= tol && Math.abs(p[1] - q[1]) <= tol;

/** Two segments on one line (within tol across, and parallel within ~0.1°)? */
function collinear(a, b, tol) {
  const d = [a.b[0] - a.a[0], a.b[1] - a.a[1]];
  const L = Math.hypot(d[0], d[1]);
  if (L < 1e-6) return false;
  const u = [d[0] / L, d[1] / L];
  const off = (p) => Math.abs((p[0] - a.a[0]) * u[1] - (p[1] - a.a[1]) * u[0]);
  const e = [b.b[0] - b.a[0], b.b[1] - b.a[1]];
  const Le = Math.hypot(e[0], e[1]);
  if (Le < 1e-6) return false;
  return off(b.a) <= tol && off(b.b) <= tol && Math.abs((d[0] * e[1] - d[1] * e[0]) / (L * Le)) < 2e-3;
}

/** Parameters along a's line: t of a point. */
const along = (a, p) => {
  const d = [a.b[0] - a.a[0], a.b[1] - a.a[1]];
  const L = Math.hypot(d[0], d[1]);
  return ((p[0] - a.a[0]) * d[0] + (p[1] - a.a[1]) * d[1]) / L;
};

const settingsKey = (el, keys) => JSON.stringify(keys.map((k) => el[k] ?? null));

/**
 * Groups of segment elements to merge: runs of collinear pieces whose spans touch or overlap (gap ≤ tol), with equal
 * settings. Returns [{ keep, others, a, b }] where a-b is the merged span along keep's direction.
 */
export function mergeRuns(els, keys, tol = 2) {
  const groups = [];
  const used = new Set();
  for (const el of els) {
    if (used.has(el.id) || el.arc) continue;
    const key = settingsKey(el, keys);
    const run = [el];
    used.add(el.id);
    // Grow the run while some other piece touches its span.
    let grew = true;
    let lo = 0;
    let hi = along(el, el.b);
    while (grew) {
      grew = false;
      for (const o of els) {
        if (used.has(o.id) || o.arc || settingsKey(o, keys) !== key || !collinear(el, o, tol)) continue;
        const t0 = Math.min(along(el, o.a), along(el, o.b));
        const t1 = Math.max(along(el, o.a), along(el, o.b));
        if (t0 > hi + tol || t1 < lo - tol) continue;
        lo = Math.min(lo, t0);
        hi = Math.max(hi, t1);
        run.push(o);
        used.add(o.id);
        grew = true;
      }
    }
    if (run.length < 2) continue;
    const d = [el.b[0] - el.a[0], el.b[1] - el.a[1]];
    const L = Math.hypot(d[0], d[1]);
    const at = (t) => [el.a[0] + (d[0] / L) * t, el.a[1] + (d[1] / L) * t];
    groups.push({ keep: el, others: run.slice(1), a: at(lo), b: at(hi), lo });
  }
  return groups;
}

const WALL_KEYS = ['typeId', 'levelId', 'baseOffset', 'topLevelId', 'topOffset', 'height', 'locationLine', 'flipped', 'structural', 'phaseId', 'demolishedId', 'optionId', 'layerId'];
const BEAM_KEYS = ['typeId', 'levelId', 'offset', 'endOffset', 'profileId', 'layerId'];

/** Merge collinear walls (inside a transaction). ids: only these (default all). Returns the number of walls removed. */
export function mergeWalls(doc, ids = null) {
  const walls = doc.all('wall').filter((w) => w.a && w.b && (!ids || ids.includes(w.id)));
  let removed = 0;
  for (const g of mergeRuns(walls, WALL_KEYS)) {
    const old = new Map([g.keep, ...g.others].map((w) => [w.id, w]));
    doc.update(g.keep.id, { a: g.a, b: g.b });
    // Hosted openings keep their place: t is measured from the merged wall's start.
    for (const w of old.values())
      for (const k of ['door', 'window', 'opening'])
        for (const h of doc.all(k)) {
          if (h.hostId !== w.id || h.t == null) continue;
          const p = (() => {
            const d = [w.b[0] - w.a[0], w.b[1] - w.a[1]];
            const L = Math.hypot(d[0], d[1]) || 1;
            return [w.a[0] + (d[0] / L) * h.t, w.a[1] + (d[1] / L) * h.t];
          })();
          doc.update(h.id, { hostId: g.keep.id, t: Math.round(along({ a: g.a, b: g.b }, p) * 10) / 10 });
        }
    for (const o of g.others) {
      doc.remove(o.id);
      removed++;
    }
  }
  return removed;
}

/** Merge collinear beams. Returns the number removed. */
export function mergeBeams(doc, ids = null) {
  const beams = doc.all('beam').filter((b) => b.a && b.b && (!ids || ids.includes(b.id)) && (b.endOffset == null || b.endOffset === b.offset));
  let removed = 0;
  for (const g of mergeRuns(beams, BEAM_KEYS)) {
    doc.update(g.keep.id, { a: g.a, b: g.b });
    for (const o of g.others) (doc.remove(o.id), removed++);
  }
  return removed;
}

/** Merge columns stacked in the same place with the same type, the upper standing on the lower's top. */
export function mergeColumns(doc, ids = null) {
  const cols = doc.all('column').filter((c) => c.at && (!ids || ids.includes(c.id)));
  let removed = 0;
  const gone = new Set();
  const sorted = [...cols].sort((a, b) => verticalExtent(doc, a).base - verticalExtent(doc, b).base);
  for (const c of sorted) {
    if (gone.has(c.id)) continue;
    let cur = doc.get(c.id);
    for (;;) {
      const top = verticalExtent(doc, cur).top;
      const up = sorted.find((o) => !gone.has(o.id) && o.id !== cur.id && o.typeId === cur.typeId && near(o.at, cur.at, 2) && (+o.rotation || 0) === (+cur.rotation || 0) && Math.abs(verticalExtent(doc, o).base - top) <= 2);
      if (!up) break;
      const ue = verticalExtent(doc, doc.get(up.id));
      const patch = up.topLevelId ? { topLevelId: up.topLevelId, topOffset: up.topOffset ?? 0 } : { topLevelId: null, height: ue.top - (levelElevation(doc, cur.levelId) + (+cur.baseOffset || 0)) };
      doc.update(cur.id, patch);
      doc.remove(up.id);
      gone.add(up.id);
      removed++;
      cur = doc.get(cur.id);
    }
  }
  return removed;
}

/**
 * Linework Consolidation (inside a transaction): in each view, detail lines of no length or repeated go, and
 * collinear pieces with the same style that touch or overlap become one. Returns { removed, merged }.
 */
export function consolidateLines(doc, { viewId = null, ids = null, tol = 1 } = {}) {
  const lines = doc.all('detailLine').filter((l) => l.a && l.b && (!viewId || l.viewId === viewId) && (!ids || ids.includes(l.id)));
  let removed = 0;
  // Zero length and exact duplicates.
  const seen = new Set();
  const live = [];
  for (const l of lines) {
    const k = [l.viewId, l.style || '', ...[l.a, l.b].map((p) => `${Math.round(p[0] / tol)},${Math.round(p[1] / tol)}`).sort()].join('|');
    if (Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1]) <= tol || seen.has(k)) {
      doc.remove(l.id);
      removed++;
      continue;
    }
    seen.add(k);
    live.push(l);
  }
  let merged = 0;
  for (const g of mergeRuns(live, ['viewId', 'style', 'layerId'], tol)) {
    doc.update(g.keep.id, { a: g.a, b: g.b });
    for (const o of g.others) (doc.remove(o.id), merged++);
  }
  return { removed, merged };
}
