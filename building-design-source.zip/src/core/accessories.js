/**
 * Slab and roof accessories, as Archicad's Accessories add-on (Slab
 * Accessories, Roof Accessories), and room accessories, as Archicad's Interior
 * Wizard (Create / Update Room Accessories). Each is an element built from its
 * host, so it follows it when the host changes.
 *
 *   slabAccessory { slabId, accessory: 'floor' | 'footing', ... }
 *     floor    Floor Construction: joists under the slab across its shorter direction at a spacing, with a rim
 *              joist round its edge: joistSpacing, joistWidth, joistDepth, materialId
 *     footing  Footing: a stem wall under the slab's edge (flush with it) on a concrete footing, with a sill plate
 *              between the stem wall and the slab: stemWidth, stemHeight, footingWidth, footingDepth, sill (bool)
 *   roofAccessory { roofId, accessory: 'surfacer' | 'woodCeiling', ... }
 *     surfacer     Roof Surfacer: the roof sheathed tile by tile ('tiles', courses lapping down the slope, with
 *                  caps on the ridges and hips) or with metal sheets ('metal', standing seams up the slope):
 *                  sheathing, tileWidth, course, materialId
 *     woodCeiling  Wood Ceiling: boards under the roof running up the slope: boardWidth, boardThickness, materialId
 *   roomAccessory { roomId, skirtingHeight, skirtingDepth, cornice (bool), corniceHeight, materialId }
 *     a skirting round the room, broken at its doors, and a cornice under the ceiling
 */
import earcut from 'earcut';
import { offsetPolygon, clipHalfPlane, signedArea, convexHull, cleanPolygon } from './geom.js';
import { levelElevation, wallAxis, verticalExtent } from './model.js';
import { typeThickness } from './catalog.js';
import { MeshBuilder, hexToRgba } from './mesh.js';
import { roofGeometry, wallOpenings } from './build3d.js';
import { planeHeight, roofHeightAt, verticalThickness } from './roof.js';
import { PROFILES } from './sweeps.js';

export const SLAB_ACCESSORIES = [
  { value: 'floor', label: 'Floor Construction' },
  { value: 'footing', label: 'Footing' },
];
export const ROOF_ACCESSORIES = [
  { value: 'surfacer', label: 'Roof Surfacer' },
  { value: 'woodCeiling', label: 'Wood Ceiling' },
];
export const SHEATHING = [
  { value: 'tiles', label: 'Tiles' },
  { value: 'metal', label: 'Metal sheets' },
];

const colorOf = (ctx, id, fallback) => hexToRgba(ctx.material(id)?.color || fallback, 1);
const ccw = (p) => (signedArea(p) >= 0 ? p : p.slice().reverse());

/** Even-odd intervals where the line p + d*s crosses the loops: [[s0, s1]]. */
function lineSpans(loops, p, d) {
  const hits = [];
  for (const loop of loops)
    for (let i = 0; i < loop.length; i++) {
      const a = loop[i];
      const b = loop[(i + 1) % loop.length];
      const e = [b[0] - a[0], b[1] - a[1]];
      const den = d[0] * e[1] - d[1] * e[0];
      if (Math.abs(den) < 1e-12) continue;
      const q = [a[0] - p[0], a[1] - p[1]];
      const u = (q[0] * d[1] - q[1] * d[0]) / den;
      // Half-open on the edge so a line through a corner counts it once.
      if (u < 0 || u >= 1) continue;
      hits.push((q[0] * e[1] - q[1] * e[0]) / den);
    }
  hits.sort((x, y) => x - y);
  const out = [];
  for (let i = 0; i + 1 < hits.length; i += 2) if (hits[i + 1] - hits[i] > 1) out.push([hits[i], hits[i + 1]]);
  return out;
}

/** The slab's outline, holes, top and bottom: { outer, holes, top, bottom } or null. */
function slabOf(doc, el) {
  const slab = doc.get(el.slabId);
  if (!slab?.boundary || slab.boundary.length < 3) return null;
  const th = Math.max(1, typeThickness(doc.get(slab.typeId)) || 300);
  const top = levelElevation(doc, slab.levelId) + (+slab.offset || 0);
  return { slab, outer: ccw(slab.boundary), holes: slab.holes || [], top, bottom: top - th };
}

/**
 * Floor Construction: { joists: [{ a, b }] centre lines in plan, rim: outline
 * ring, z0, z1, width } with the joists spanning the slab's shorter direction.
 */
export function floorGeometry(doc, el) {
  const s = slabOf(doc, el);
  if (!s) return null;
  const w = Math.max(20, +el.joistWidth || 50);
  const depth = Math.max(50, +el.joistDepth || 220);
  const spacing = Math.max(150, +el.joistSpacing || 400);
  // The long axis of the outline's smallest box: joists run across it.
  const hull = convexHull(s.outer);
  let best = null;
  for (let i = 0; i < hull.length; i++) {
    const a = hull[i];
    const b = hull[(i + 1) % hull.length];
    const l = Math.hypot(b[0] - a[0], b[1] - a[1]);
    if (l < 1e-6) continue;
    const u = [(b[0] - a[0]) / l, (b[1] - a[1]) / l];
    const v = [-u[1], u[0]];
    const us = hull.map((p) => p[0] * u[0] + p[1] * u[1]);
    const vs = hull.map((p) => p[0] * v[0] + p[1] * v[1]);
    const L = Math.max(...us) - Math.min(...us);
    const T = Math.max(...vs) - Math.min(...vs);
    const box = { u: L >= T ? u : v, along: L >= T ? [Math.min(...us), Math.max(...us)] : [Math.min(...vs), Math.max(...vs)], areaBox: L * T };
    if (!best || box.areaBox < best.areaBox - 1e-6) best = box;
  }
  if (!best) return null;
  const inner = offsetPolygon(s.outer, -w);
  const u = best.u;
  const v = [-u[1], u[0]];
  const joists = [];
  for (let k = best.along[0] + w + spacing; k < best.along[1] - w; k += spacing) {
    const p = [u[0] * k, u[1] * k];
    for (const [s0, s1] of lineSpans([inner, ...s.holes], p, v)) joists.push({ a: [p[0] + v[0] * s0, p[1] + v[1] * s0], b: [p[0] + v[0] * s1, p[1] + v[1] * s1] });
  }
  return { joists, outer: s.outer, inner, holes: s.holes, z0: s.bottom - depth, z1: s.bottom, width: w, depth };
}

/** Footing: rings under the slab's edge { stem, sill, footing: { outer, inner, z0, z1 } }. */
export function footingGeometry(doc, el) {
  const s = slabOf(doc, el);
  if (!s) return null;
  const sw = Math.max(50, +el.stemWidth || 200);
  const sh = Math.max(50, +el.stemHeight || 600);
  const fw = Math.max(sw, +el.footingWidth || 600);
  const fd = Math.max(50, +el.footingDepth || 300);
  const sill = el.sill !== false;
  const sillH = sill ? 45 : 0;
  const stemTop = s.bottom - sillH;
  const stemBottom = stemTop - sh;
  const spread = (fw - sw) / 2;
  const ring = (o, i, z0, z1) => ({ outer: o === 0 ? s.outer : offsetPolygon(s.outer, o), inner: offsetPolygon(s.outer, -i), z0, z1 });
  return {
    stem: ring(0, sw, stemBottom, stemTop),
    sill: sill ? ring(0, Math.min(sw, 140), stemTop, s.bottom) : null,
    footing: ring(spread, sw + spread, stemBottom - fd, stemBottom),
  };
}

function buildSlabAccessory(ctx, el) {
  const b = new MeshBuilder();
  if ((el.accessory || 'floor') === 'footing') {
    const g = footingGeometry(ctx.doc, el);
    if (!g) return null;
    const concrete = colorOf(ctx, el.materialId || 'mat-concrete', '#b5b2ac');
    for (const r of [g.stem, g.footing]) b.prism(r.outer, [r.inner], r.z0, r.z1, concrete);
    if (g.sill) b.prism(g.sill.outer, [g.sill.inner], g.sill.z0, g.sill.z1, colorOf(ctx, 'mat-wood', '#c8a46e'));
    return b.build();
  }
  const g = floorGeometry(ctx.doc, el);
  if (!g) return null;
  const col = colorOf(ctx, el.materialId || 'mat-wood', '#c8a46e');
  b.prism(g.outer, [g.inner], g.z0, g.z1, col);
  for (const { a, b: c } of g.joists) {
    const d = [c[0] - a[0], c[1] - a[1]];
    const l = Math.hypot(d[0], d[1]) || 1;
    const n = [(-d[1] / l) * (g.width / 2), (d[0] / l) * (g.width / 2)];
    b.prism([[a[0] + n[0], a[1] + n[1]], [c[0] + n[0], c[1] + n[1]], [c[0] - n[0], c[1] - n[1]], [a[0] - n[0], a[1] - n[1]]], [], g.z0, g.z1, col);
  }
  return b.build();
}

// Roof accessories --------------------------------------------------------------------------------------------

/** A plan polygon clipped to a convex quad [p0..p3] (counterclockwise). */
function clipToQuad(poly, quad) {
  let out = poly;
  for (let i = 0; i < 4 && out.length >= 3; i++) {
    const a = quad[i];
    const b = quad[(i + 1) % 4];
    // Keep the left of a -> b: outward normal is to the right.
    const n = [b[1] - a[1], -(b[0] - a[0])];
    const l = Math.hypot(n[0], n[1]) || 1;
    out = clipHalfPlane(out, [n[0] / l, n[1] / l], (n[0] * a[0] + n[1] * a[1]) / l);
  }
  out = out.length >= 3 ? cleanPolygon(out, 0.5) : [];
  return out.length >= 3 && Math.abs(signedArea(out)) > 100 ? out : null;
}

/**
 * The pieces of a roof accessory, per roof face: [{ poly (plan), lift(p)
 * height of its top over the roof surface, under (true: hangs under the roof) }]
 * with height(p) the roof's top surface and underside, and caps along ridges.
 */
export function roofAccessoryGeometry(doc, el) {
  const roof = doc.get(el.roofId);
  if (!roof?.boundary || roof.boundary.length < 3) return null;
  const { poly, planes, faces, ridges, th, base } = roofGeometry(doc, roof);
  if (!planes.length) return null;
  const kind = el.accessory || 'surfacer';
  const metal = kind === 'surfacer' && el.sheathing === 'metal';
  const pieces = [];
  for (const f of faces) {
    const pl = f.plane;
    if (!pl) continue;
    const vt = verticalThickness(th, pl);
    const m = pl.m;
    const e = [m[1], -m[0]];
    const cos = Math.cos((pl.slope * Math.PI) / 180);
    const us = f.poly.map((q) => (q[0] - pl.p[0]) * e[0] + (q[1] - pl.p[1]) * e[1]);
    const vs = f.poly.map((q) => (q[0] - pl.p[0]) * m[0] + (q[1] - pl.p[1]) * m[1]);
    const [u0, u1, v0, v1] = [Math.min(...us), Math.max(...us), Math.min(...vs), Math.max(...vs)];
    const at = (u, v) => [pl.p[0] + e[0] * u + m[0] * v, pl.p[1] + e[1] * u + m[1] * v];
    const rect = (a, c, p, q) => [at(a, p), at(c, p), at(c, q), at(a, q)];
    const top = (q) => base + planeHeight(pl, q) + vt;
    const under = (q) => base + planeHeight(pl, q);
    const add = (quad, piece) => {
      const ccwQuad = signedArea(quad) >= 0 ? quad : quad.slice().reverse();
      const c = clipToQuad(f.poly, ccwQuad);
      if (c) pieces.push({ ...piece, poly: c });
    };
    if (kind === 'woodCeiling') {
      const w = Math.max(40, +el.boardWidth || 120);
      const t = Math.max(5, +el.boardThickness || 15);
      for (let u = u0; u < u1; u += w) add(rect(u, Math.min(u1, u + w - 4), v0, v1), { z: (q) => under(q) - t, h: () => t, edge: true });
    } else if (metal) {
      const w = Math.max(200, +el.tileWidth || 600);
      add(rect(u0, u1, v0, v1), { z: (q) => top(q), h: () => 3, edge: false });
      for (let u = u0 + w; u < u1; u += w) add(rect(u - 12, u + 12, v0, v1), { z: (q) => top(q) + 3, h: () => 35, edge: true });
    } else {
      // Tiles in courses up the slope (course measured along the slope), each lapping over the one below.
      const w = Math.max(100, +el.tileWidth || 300);
      const course = Math.max(100, +el.course || 340) * cos;
      const lap = 80 * cos;
      let row = 0;
      const tt = 15;
      // The tile's lower edge rides up on the course below it (whose top there is lift * lap / (course + lap) + tt
      // over the roof): lift it enough to clear that.
      const lift = (tt * (course + lap)) / course + 3;
      const vOf = (pt) => (pt[0] - pl.p[0]) * m[0] + (pt[1] - pl.p[1]) * m[1];
      for (let v = v0; v < v1; v += course, row++) {
        const shift = row % 2 ? w / 2 : 0;
        const p = v;
        const q = v + course + lap;
        // Only the tile's lower edge and the sides of what shows are drawn: the rest lies under the next course.
        const shows = (a, c) => Math.min(vOf(a), vOf(c)) < p + course - 1;
        for (let u = u0 - shift; u < u1; u += w) add(rect(u + 2, u + w - 2, p, Math.min(v1, q)), { z: (pt) => top(pt) + (lift * (q - vOf(pt))) / (q - p), h: () => tt, edge: shows });
      }
    }
  }
  // Caps along ridges and hips (not valleys): where the roof falls away on both sides.
  const caps = [];
  if (kind === 'surfacer') {
    const hAt = (q) => base + roofHeightAt(planes, q);
    for (const [a, c] of ridges) {
      const mid = [(a[0] + c[0]) / 2, (a[1] + c[1]) / 2];
      const d = [c[0] - a[0], c[1] - a[1]];
      const l = Math.hypot(d[0], d[1]) || 1;
      const n = [(-d[1] / l) * 150, (d[0] / l) * 150];
      const h0 = hAt(mid);
      if (hAt([mid[0] + n[0], mid[1] + n[1]]) < h0 - 1 && hAt([mid[0] - n[0], mid[1] - n[1]]) < h0 - 1) caps.push({ a, b: c, z: (q) => hAt(q) + verticalThickness(th, planes[0]) });
    }
  }
  return { pieces, caps, kind, metal, outline: poly };
}

/** A plan polygon raised as a slab over a surface: its bottom at z(p), its top h(p) above. */
function draped(b, poly, z, h, col, edges) {
  const tri = earcut(poly.flat());
  const T = (p) => [p[0], p[1], z(p) + h(p)];
  const B = (p) => [p[0], p[1], z(p)];
  for (let i = 0; i < tri.length; i += 3) {
    const [p, q, r] = [poly[tri[i]], poly[tri[i + 1]], poly[tri[i + 2]]];
    b.tri(T(p), T(q), T(r), col);
    b.tri(B(p), B(r), B(q), col);
  }
  for (let i = 0; i < poly.length; i++) {
    const p = poly[i];
    const q = poly[(i + 1) % poly.length];
    b.quad(B(p), B(q), T(q), T(p), col);
    if (edges === true || (typeof edges === 'function' && edges(p, q))) b.edge(T(p), T(q));
  }
}

function buildRoofAccessory(ctx, el) {
  const g = roofAccessoryGeometry(ctx.doc, el);
  if (!g) return null;
  const b = new MeshBuilder();
  const fallback = g.kind === 'woodCeiling' ? 'mat-wood' : g.metal ? 'mat-roof-metal' : 'mat-roof-tile';
  const col = colorOf(ctx, el.materialId || fallback, g.kind === 'woodCeiling' ? '#c8a46e' : g.metal ? '#8d949a' : '#a5533a');
  for (const p of g.pieces) draped(b, p.poly, p.z, p.h, col, p.edge);
  // Ridge and hip caps: a ridge roll over the line (a triangular prism standing on the tiles).
  for (const c of g.caps) {
    const d = [c.b[0] - c.a[0], c.b[1] - c.a[1]];
    const l = Math.hypot(d[0], d[1]) || 1;
    const n = [(-d[1] / l) * 130, (d[0] / l) * 130];
    const P = (p, s, up) => [p[0] + n[0] * s, p[1] + n[1] * s, c.z([p[0] + n[0] * s, p[1] + n[1] * s]) + up];
    const A = [P(c.a, -1, 15), P(c.a, 0, 110), P(c.a, 1, 15)];
    const B = [P(c.b, -1, 15), P(c.b, 0, 110), P(c.b, 1, 15)];
    b.quad(A[0], B[0], B[1], A[1], col);
    b.quad(A[1], B[1], B[2], A[2], col);
    b.tri(A[0], A[1], A[2], col);
    b.tri(B[0], B[2], B[1], col);
    b.edge(A[1], B[1]);
  }
  return b.build();
}

// Room accessories --------------------------------------------------------------------------------------------

/**
 * Where a room's skirting runs: [{ a, b, inA, inB }] stretches of its outline
 * (counterclockwise) between its doors, with the mitred inner corners where a
 * stretch reaches a corner (else square ends), and its floor and ceiling heights.
 */
export function roomAccessoryGeometry(ctx, el) {
  const doc = ctx.doc;
  const room = doc.get(el.roomId);
  if (!room || !ctx.rooms) return null;
  const r = ctx.rooms.room(room);
  if (!r?.outer || r.outer.length < 3) return null;
  const outer = ccw(r.outer);
  const depth = Math.max(5, +el.skirtingDepth || 15);
  const inner = offsetPolygon(outer, -depth);
  if (inner.length !== outer.length) return null;
  const floor = levelElevation(doc, room.levelId) + (+room.offset || 0);
  const above = doc.levelAbove?.(room.levelId);
  const ceiling = +room.height > 0 ? floor + +room.height : above ? levelElevation(doc, above.id) - 300 : floor + 2700;
  // Door openings (from the floor) on this level, as plan segments on both faces of their walls.
  const doors = [];
  for (const w of doc.all('wall')) {
    if (w.levelId !== room.levelId || w.arc) continue;
    const ax = wallAxis(doc, w);
    const { base, top } = verticalExtent(doc, w);
    for (const o of wallOpenings(doc, w, base, top)) {
      if (o.z0 > base + 50) continue;
      for (const s of [1, -1]) {
        const off = [ax.ext[0] * ax.half * s, ax.ext[1] * ax.half * s];
        doors.push([[ax.a[0] + ax.dir[0] * o.u0 + off[0], ax.a[1] + ax.dir[1] * o.u0 + off[1]], [ax.a[0] + ax.dir[0] * o.u1 + off[0], ax.a[1] + ax.dir[1] * o.u1 + off[1]]]);
      }
    }
  }
  const runs = [];
  const n = outer.length;
  for (let i = 0; i < n; i++) {
    const a = outer[i];
    const c = outer[(i + 1) % n];
    const d = [c[0] - a[0], c[1] - a[1]];
    const l = Math.hypot(d[0], d[1]);
    if (l < 1) continue;
    const u = [d[0] / l, d[1] / l];
    const along = (p) => (p[0] - a[0]) * u[0] + (p[1] - a[1]) * u[1];
    const off = (p) => Math.abs((p[0] - a[0]) * u[1] - (p[1] - a[1]) * u[0]);
    // Doors whose face lies on this edge cut it.
    let spans = [[0, l]];
    for (const [p, q] of doors) {
      if (off(p) > 5 || off(q) > 5) continue;
      const s0 = Math.min(along(p), along(q));
      const s1 = Math.max(along(p), along(q));
      spans = spans.flatMap(([x, y]) => (s1 <= x || s0 >= y ? [[x, y]] : [[x, s0], [s1, y]].filter(([m0, m1]) => m1 - m0 > 1)));
    }
    const nIn = [-u[1] * depth, u[0] * depth];
    for (const [s0, s1] of spans) {
      const A = [a[0] + u[0] * s0, a[1] + u[1] * s0];
      const B = [a[0] + u[0] * s1, a[1] + u[1] * s1];
      runs.push({ a: A, b: B, inA: s0 < 0.5 ? inner[i] : [A[0] + nIn[0], A[1] + nIn[1]], inB: s1 > l - 0.5 ? inner[(i + 1) % n] : [B[0] + nIn[0], B[1] + nIn[1]] });
    }
  }
  return { runs, floor, ceiling, depth, outer };
}

function buildRoomAccessory(ctx, el) {
  const g = roomAccessoryGeometry(ctx, el);
  if (!g) return null;
  const b = new MeshBuilder();
  const col = colorOf(ctx, el.materialId || 'mat-paint-white', '#f2efe8');
  const sh = Math.max(10, +el.skirtingHeight || 100);
  // A run's profile: [[out from the wall (0..1 of the depth), up]] scaled between its outer and inner lines.
  const run = (r, z, h, pts) => {
    const at = (end, o, up) => {
      const [p, q] = end ? [r.b, r.inB] : [r.a, r.inA];
      return [p[0] + (q[0] - p[0]) * o, p[1] + (q[1] - p[1]) * o, z + up * h];
    };
    for (let i = 0; i < pts.length; i++) {
      const [o0, u0] = pts[i];
      const [o1, u1] = pts[(i + 1) % pts.length];
      b.quad(at(0, o0, u0), at(1, o0, u0), at(1, o1, u1), at(0, o1, u1), col);
      if (o0 > 0.01 && o1 > 0.01) b.edge(at(0, o0, u0), at(1, o0, u0));
    }
    const tri = earcut(pts.flat());
    for (let i = 0; i < tri.length; i += 3) {
      const [x, y, w] = [pts[tri[i]], pts[tri[i + 1]], pts[tri[i + 2]]];
      b.tri(at(0, ...x), at(0, ...y), at(0, ...w), col);
      b.tri(at(1, ...x), at(1, ...w), at(1, ...y), col);
    }
  };
  for (const r of g.runs) run(r, g.floor, sh, PROFILES.skirting.pts);
  if (el.cornice) {
    const ch = Math.max(20, +el.corniceHeight || 80);
    // The cornice runs round the whole room (doors do not reach the ceiling), at the full outline.
    const whole = g.outer.map((a, i) => ({ a, b: g.outer[(i + 1) % g.outer.length] }));
    const inner = offsetPolygon(g.outer, -g.depth * 3);
    whole.forEach((r, i) => run({ ...r, inA: inner[i], inB: inner[(i + 1) % inner.length] }, g.ceiling - ch, ch, PROFILES.cornice.pts));
  }
  return b.build();
}

export function buildAccessory(ctx, el) {
  if (el.kind === 'slabAccessory') return buildSlabAccessory(ctx, el);
  if (el.kind === 'roofAccessory') return buildRoofAccessory(ctx, el);
  if (el.kind === 'roomAccessory') return buildRoomAccessory(ctx, el);
  return null;
}
