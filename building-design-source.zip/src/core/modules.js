/**
 * Modules (Archicad's hotlinks), on top of linked projects (core/links.js):
 *
 *   - Save Selection as Module: a project file holding the selected model
 *     elements (with what they host) and the project's setup (levels,
 *     types, materials, views), to link into other projects;
 *   - Break Hotlink (Embed Elements): a link's elements copied into this
 *     project as its own, placed where the link shows them, on the levels at
 *     the same heights (new ones are made where none matches), with the
 *     types and materials this project lacks; the link goes;
 *   - Save Hotlink as File: the link's snapshot as a project file.
 */
import { Doc, newId } from './doc.js';
import { MODEL_KINDS } from './scene.js';
import { linkFrame, linkPoint } from './links.js';
import { transformPatch } from './ops.js';

const MODEL = new Set(MODEL_KINDS);

/** A Doc for a module: the selected model elements (and their hosted ones), with the setup of the project. */
export function moduleDoc(doc, ids) {
  const keep = new Set(ids.filter((id) => MODEL.has(doc.get(id)?.kind)));
  // Hosted elements (doors, windows, openings, accessories) go with their host.
  let grew = true;
  while (grew) {
    grew = false;
    for (const el of doc.items.values()) if (el.hostId && keep.has(el.hostId) && !keep.has(el.id) && MODEL.has(el.kind)) (keep.add(el.id), (grew = true));
  }
  const items = [];
  for (const el of doc.items.values()) {
    if (MODEL.has(el.kind)) {
      if (keep.has(el.id)) items.push(el);
      continue;
    }
    // Annotations drawn in views belong to this project's drawings, not to the module.
    if (el.viewId) continue;
    items.push(el);
  }
  return Doc.fromJSON({ ...doc.toJSON(), items: structuredClone(items) });
}

/**
 * Embed a link (inside a transaction): its model elements become this project's. linked is the link's Doc.
 * Returns { added: [id], levels: [id] (made) }.
 */
export function embedLink(doc, el, linked) {
  const f = linkFrame(el);
  const xf = { point: (p) => linkPoint(f, p), angle: f.r };
  const out = { added: [], levels: [] };
  // Levels by height.
  const levelMap = new Map();
  for (const lv of linked.levels()) {
    const z = lv.elevation + f.z;
    let mine = doc.levels().find((l) => Math.abs(l.elevation - z) < 1);
    if (!mine) {
      mine = doc.add({ kind: 'level', name: lv.name, elevation: z });
      doc.add({ kind: 'plan', name: mine.name, levelId: mine.id, scale: 100, detail: 'medium' });
      out.levels.push(mine.id);
    }
    levelMap.set(lv.id, mine.id);
  }
  // Types and materials this project lacks.
  const bring = (id) => {
    const it = id && linked.get(id);
    if (!it || doc.has(id)) return;
    doc.add({ ...structuredClone(it) });
    for (const l of it.layers || []) bring(l.materialId);
    for (const k of ['materialId', 'panelMaterialId', 'frameMaterialId']) if (it[k]) bring(it[k]);
  };
  // Nested modules stay modules: their links come along, placed where the outer link puts them.
  for (const x of linked.all('link')) {
    const at = linkPoint(f, x.at || [0, 0]);
    out.added.push(doc.add({ ...structuredClone(x), id: newId(), at, rotation: (+x.rotation || 0) + (f.r * 180) / Math.PI, z: (+x.z || 0) + f.z, levelId: undefined }).id);
  }
  const els = [...linked.items.values()].filter((x) => MODEL.has(x.kind) && x.kind !== 'link');
  const idMap = new Map(els.map((x) => [x.id, newId()]));
  // Hosts first.
  els.sort((a, b) => (a.hostId ? 1 : 0) - (b.hostId ? 1 : 0));
  for (const x of els) {
    bring(x.typeId);
    bring(x.materialId);
    const { id, ...rest } = structuredClone(x);
    const moved = x.hostId ? {} : transformPatch(x, xf);
    const patch = { ...rest, ...moved, id: idMap.get(id) };
    for (const k of ['levelId', 'topLevelId']) if (patch[k]) patch[k] = levelMap.get(patch[k]) ?? null;
    if (patch.hostId) patch.hostId = idMap.get(patch.hostId) ?? null;
    if (x.hostId && !patch.hostId) continue;
    // Elements hosted by things that did not come along (groups) drop the reference.
    if (patch.groupId) delete patch.groupId;
    out.added.push(doc.add(patch).id);
  }
  doc.remove(el.id);
  return out;
}
