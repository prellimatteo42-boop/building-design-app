import earcut from 'earcut';

/**
 * Text as a solid, for GDL's TEXT in 3D: the string is drawn in the style's font onto a small canvas, and the inked pixels
 * become rectangles (runs along each row, merged down the rows), their outline the sides. The text's size is the height of
 * its capitals, as Archicad measures a style's size.
 */
const PX = 96;
const cache = new Map();
let source = defaultRaster;

/** Replaces how text is drawn into pixels (tests, or a host with no canvas): fn(text, font, face) → raster or null. */
export function setTextRaster(fn) {
  source = fn || defaultRaster;
  cache.clear();
}

/** { width, height, cap, base, advance, ink: Uint8Array (1 per inked pixel) } in pixels, or null without a canvas. */
function defaultRaster(text, font, face) {
  if (typeof OffscreenCanvas === 'undefined') return null;
  const css = `${face & 2 ? 'italic ' : ''}${face & 1 ? 'bold ' : ''}${PX}px "${String(font || 'Arial').replace(/"/g, '')}", Arial, sans-serif`;
  let c = new OffscreenCanvas(8, 8);
  let g = c.getContext('2d');
  if (!g) return null;
  g.font = css;
  const advance = g.measureText(text).width;
  const cap = g.measureText('H').actualBoundingBoxAscent || PX * 0.72;
  const width = Math.max(1, Math.ceil(advance + PX * 0.3));
  const height = Math.ceil(PX * 1.4);
  const base = Math.ceil(PX * 1.05);
  c = new OffscreenCanvas(width, height);
  g = c.getContext('2d');
  g.font = css;
  g.fillStyle = '#000';
  g.fillText(text, Math.round(PX * 0.1), base);
  const data = g.getImageData(0, 0, width, height).data;
  const ink = new Uint8Array(width * height);
  for (let i = 0; i < ink.length; i++) ink[i] = data[4 * i + 3] > 110 ? 1 : 0;
  return { width, height, cap, base, advance, left: Math.round(PX * 0.1), ink };
}

function raster(text, font, face) {
  const key = `${font}|${face}|${text}`;
  if (!cache.has(key)) {
    if (cache.size > 300) cache.clear();
    cache.set(key, source(text, font, face));
  }
  return cache.get(key);
}

/** The width of a text in the style, in the style's own units (its size is the capitals' height), or null without a canvas. */
export function textAdvance(text, style) {
  const r = raster(String(text), style.font, style.face || 0);
  return r ? (r.advance / r.cap) * style.size : null;
}

/**
 * The solid of a text: { quads: [[p0, p1, p2, p3], ...] sides and { tris } faces, all facing out, edges: [[a, b], ...] } in
 * the text's local units (x along the line, y up, z from 0 to depth), placed at the style's anchor (1 top left ... 5 centre
 * ... 9 bottom right), or null. The letters' outlines follow the inked pixels' border, simplified to straight runs, so curves
 * come out smooth and the faces are polygons with their holes.
 */
export function textSolid(text, style, depth) {
  const s = String(text);
  if (!s.trim()) return null;
  const r = raster(s, style.font, style.face || 0);
  if (!r) return null;
  const k = style.size / r.cap;
  const anchor = Math.min(9, Math.max(1, Math.round(style.anchor || 1)));
  const col = (anchor - 1) % 3;
  const row = Math.floor((anchor - 1) / 3);
  const dx = -r.left * k - (col === 1 ? (r.advance * k) / 2 : col === 2 ? r.advance * k : 0);
  const dy = row === 0 ? -style.size : row === 1 ? -style.size / 2 : 0;
  // Grid corners (u, v) with v up: pixel (i, j) spans u i..i+1, v -j-1..-j; the baseline is v = -base.
  const place = ([u, v]) => [u * k + dx, (v + r.base) * k + dy];
  const loops = inkLoops(r).map((l) => simplify(soften(l), 0.4)).filter((l) => l.length >= 3);
  const outers = loops.filter((l) => area(l) > 0);
  const holes = loops.filter((l) => area(l) < 0);
  const groups = outers.map((o) => ({ outer: o, holes: [] }));
  for (const h of holes) {
    const inside = groups.filter((g) => inPolygon(h[0], g.outer)).sort((a, b) => area(a.outer) - area(b.outer));
    if (inside[0]) inside[0].holes.push(h);
  }
  const z0 = 0;
  const z1 = depth;
  const thick = depth > 1e-9;
  const tris = [];
  for (const g of groups) {
    const all = [g.outer, ...g.holes].flat().map(place);
    const starts = [];
    let at = g.outer.length;
    for (const h of g.holes) (starts.push(at), (at += h.length));
    const ids = earcut(all.flat(), starts, 2);
    for (let i = 0; i < ids.length; i += 3) {
      const [a, b, c] = [all[ids[i]], all[ids[i + 1]], all[ids[i + 2]]];
      const ccw = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]) > 0;
      const [p, q] = ccw ? [b, c] : [c, b];
      tris.push([[a[0], a[1], z1], [p[0], p[1], z1], [q[0], q[1], z1]]);
      if (thick) tris.push([[a[0], a[1], z0], [q[0], q[1], z0], [p[0], p[1], z0]]);
    }
  }
  const quads = [];
  const edges = [];
  // Sides: the ink is on the left of each outline, so a side from a to b faces right of it, out of the letter.
  for (const l of loops) {
    const pts = l.map(place);
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      if (thick) quads.push([[a[0], a[1], z0], [b[0], b[1], z0], [b[0], b[1], z1], [a[0], a[1], z1]]);
      edges.push([[a[0], a[1], z1], [b[0], b[1], z1]]);
      if (thick) edges.push([[a[0], a[1], z0], [b[0], b[1], z0]]);
    }
  }
  return { tris, quads, edges };
}

/** The border of the inked pixels as closed loops of grid corners, each with the ink on its left (outlines CCW, holes CW). */
function inkLoops({ width: W, height: H, ink }) {
  const at = (i, j) => (i >= 0 && j >= 0 && i < W && j < H ? ink[j * W + i] : 0);
  const from = new Map();
  const add = (a, b) => {
    const key = `${a[0]},${a[1]}`;
    if (!from.has(key)) from.set(key, []);
    from.get(key).push({ a, b, used: false });
  };
  for (let j = 0; j < H; j++)
    for (let i = 0; i < W; i++) {
      if (!at(i, j)) continue;
      const [lo, hi] = [-j - 1, -j];
      if (!at(i, j + 1)) add([i, lo], [i + 1, lo]);
      if (!at(i + 1, j)) add([i + 1, lo], [i + 1, hi]);
      if (!at(i, j - 1)) add([i + 1, hi], [i, hi]);
      if (!at(i - 1, j)) add([i, hi], [i, lo]);
    }
  const loops = [];
  for (const list of from.values())
    for (const e0 of list) {
      if (e0.used) continue;
      const loop = [];
      let e = e0;
      while (e && !e.used) {
        e.used = true;
        loop.push(e.a);
        const next = (from.get(`${e.b[0]},${e.b[1]}`) || []).filter((x) => !x.used);
        // Where two pixels touch only at a corner, turn left: each keeps its own outline.
        const d = [e.b[0] - e.a[0], e.b[1] - e.a[1]];
        e = next.find((x) => d[0] * (x.b[1] - x.a[1]) - d[1] * (x.b[0] - x.a[0]) > 0) || next[0];
      }
      if (loop.length >= 4) loops.push(loop);
    }
  return loops;
}

/**
 * A pixel outline without its steps: the middles of its unit sides, each then drawn a quarter of the way toward both
 * neighbours, twice. A corner between two runs of at least two pixels is a true corner of the letter and stays as it is.
 */
function soften(loop0) {
  // The turns of the outline, with the length of the run leaving each.
  const turns = loop0.filter((p, i) => {
    const a = loop0[(i + loop0.length - 1) % loop0.length];
    const b = loop0[(i + 1) % loop0.length];
    return (p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0]) !== 0;
  });
  const n = turns.length;
  const len = (i) => Math.abs(turns[(i + 1) % n][0] - turns[i][0]) + Math.abs(turns[(i + 1) % n][1] - turns[i][1]);
  const pts = [];
  const pinned = [];
  for (let i = 0; i < n; i++) {
    const a = turns[i];
    const b = turns[(i + 1) % n];
    if (len(i) >= 2 && len((i + n - 1) % n) >= 2) (pts.push(a), pinned.push(true));
    const steps = len(i);
    for (let t = 0; t < steps; t++) (pts.push([a[0] + ((b[0] - a[0]) * (t + 0.5)) / steps, a[1] + ((b[1] - a[1]) * (t + 0.5)) / steps]), pinned.push(false));
  }
  let cur = pts;
  for (let pass = 0; pass < 2; pass++)
    cur = cur.map((p, i) => {
      if (pinned[i]) return p;
      const a = cur[(i + cur.length - 1) % cur.length];
      const b = cur[(i + 1) % cur.length];
      return [(a[0] + 2 * p[0] + b[0]) / 4, (a[1] + 2 * p[1] + b[1]) / 4];
    });
  return cur;
}

/** A closed loop with the points that stray less than tol from a straight run between their neighbours left out. */
function simplify(loop, tol) {
  const n = loop.length;
  if (n < 5) return loop;
  // Split at the point farthest from the first, then Douglas-Peucker on both halves.
  let far = 0;
  let best = -1;
  for (let i = 1; i < n; i++) {
    const d = (loop[i][0] - loop[0][0]) ** 2 + (loop[i][1] - loop[0][1]) ** 2;
    if (d > best) (best = d), (far = i);
  }
  const keep = new Uint8Array(n);
  keep[0] = keep[far] = 1;
  const stack = [[0, far], [far, n]];
  while (stack.length) {
    const [s, e] = stack.pop();
    const a = loop[s];
    const b = loop[e % n];
    const [dx, dy] = [b[0] - a[0], b[1] - a[1]];
    const len = Math.hypot(dx, dy) || 1;
    let worst = -1;
    let at = -1;
    for (let i = s + 1; i < e; i++) {
      const d = Math.abs((loop[i][0] - a[0]) * dy - (loop[i][1] - a[1]) * dx) / len;
      if (d > worst) (worst = d), (at = i);
    }
    if (worst > tol) {
      keep[at] = 1;
      stack.push([s, at], [at, e]);
    }
  }
  const out = loop.filter((_, i) => keep[i]);
  // The start may sit in the middle of a straight run: leave out points on a line with their neighbours.
  return out.filter((p, i) => {
    const a = out[(i + out.length - 1) % out.length];
    const b = out[(i + 1) % out.length];
    return Math.abs((p[0] - a[0]) * (b[1] - a[1]) - (p[1] - a[1]) * (b[0] - a[0])) > 1e-9;
  });
}

function area(l) {
  let a = 0;
  for (let i = 0; i < l.length; i++) {
    const p = l[i];
    const q = l[(i + 1) % l.length];
    a += p[0] * q[1] - q[0] * p[1];
  }
  return a / 2;
}

function inPolygon([x, y], l) {
  let inside = false;
  for (let i = 0, j = l.length - 1; i < l.length; j = i++) {
    const [xi, yi] = l[i];
    const [xj, yj] = l[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
