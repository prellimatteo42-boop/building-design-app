/**
 * Clone folders, as in Archicad's View Map: a folder that holds a floor plan
 * of every story, all with the folder's settings (scale, detail, layer
 * combination, pen set, partial structure display, view template). Stories
 * added later get their plan in the folder too; changing the folder changes
 * its plans; deleting it deletes them.
 *
 * viewClone { kind: 'viewClone', name, source: 'stories', settings }
 * Its plans carry cloneId.
 */
import { planView } from './template.js';

export const CLONE_SETTINGS = ['scale', 'detail', 'layerComboId', 'penSet', 'structureDisplay', 'templateId'];

const cloneName = (level, clone) => `${level.name} - ${clone.name}`;

function settingsPatch(clone) {
  const out = {};
  for (const k of CLONE_SETTINGS) if (clone.settings?.[k] !== undefined && clone.settings[k] !== '') out[k] = clone.settings[k];
  return out;
}

/**
 * Keep clone folders' plans in step with the stories, inside the open
 * transaction (a doc solver). drivers: ids edited, or null for all.
 * Returns the ids it changed.
 */
export function applyViewClones(doc, drivers = null) {
  const changed = new Set();
  // Only stories, folders and deletions matter.
  if (drivers) {
    let relevant = false;
    for (const id of drivers) {
      const it = doc.get(id);
      if (!it || it.kind === 'level' || it.kind === 'viewClone') relevant = true;
    }
    if (!relevant) return changed;
  }
  const clones = doc.all('viewClone');
  for (const v of doc.filter((x) => x.cloneId && !doc.has(x.cloneId))) {
    doc.remove(v.id);
    changed.add(v.id);
  }
  for (const clone of clones) {
    const reapply = !drivers || drivers.has(clone.id);
    const mine = new Map(doc.filter((v) => v.kind === 'plan' && v.cloneId === clone.id).map((v) => [v.levelId, v]));
    for (const level of doc.levels()) {
      const v = mine.get(level.id);
      if (!v) {
        const view = { ...planView(doc, level), ...settingsPatch(clone), name: cloneName(level, clone), cloneId: clone.id };
        doc.add(view);
        changed.add(view.id);
        continue;
      }
      const patch = reapply ? settingsPatch(clone) : {};
      if (v.name !== cloneName(level, clone)) patch.name = cloneName(level, clone);
      if (Object.keys(patch).some((k) => v[k] !== patch[k])) {
        doc.update(v.id, patch);
        changed.add(v.id);
      }
    }
    for (const [levelId, v] of mine)
      if (!doc.has(levelId)) {
        doc.remove(v.id);
        changed.add(v.id);
      }
  }
  return changed;
}
