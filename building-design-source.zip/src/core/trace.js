/**
 * Trace & Reference, as in Archicad: another drawing (the story below or
 * above, or any plan, ceiling plan, drafting view or detail) shown faded
 * under the active plan, moved and rotated as needed, to draw against and
 * snap to. A trace is a way of looking, not part of the model.
 *
 *   trace { refId: view id | 'below' | 'above' | 'source', offset: [dx, dy], rotation (degrees), on, onTop }
 */
import { PlanBuilder } from './plan.js';
import { rotate, add } from './geom.js';
import { isFlatView } from './doc.js';

/** The view a trace shows for an active view, or null. */
export function traceReference(doc, view, trace) {
  if (!trace?.on || !view) return null;
  let ref = null;
  if (trace.refId === 'below' || trace.refId === 'above') {
    const levels = doc.levels();
    const i = levels.findIndex((l) => l.id === view.levelId);
    const lv = i < 0 ? null : levels[trace.refId === 'below' ? i - 1 : i + 1];
    ref = lv ? doc.all('plan').find((p) => p.levelId === lv.id) : null;
  } else if (trace.refId === 'source') {
    // Reference - Source View: the view a detail, worksheet or independent drawing comes from.
    ref = doc.get(view.calloutOf) || doc.get(view.sourceViewId) || null;
  } else ref = doc.get(trace.refId);
  return ref && ref.id !== view.id && isFlatView(ref) && ref.kind !== 'sheet' ? ref : null;
}

/** The function placing reference points: rotated about the origin, then moved. */
export function traceTransform(trace) {
  const a = ((+trace?.rotation || 0) * Math.PI) / 180;
  const o = trace?.offset || [0, 0];
  return (p) => add(rotate(p, a), o);
}

/** A plan builder with its geometry placed by T (text keeps its size). */
export function transformBuilder(g, T, rotation = 0) {
  const b = new PlanBuilder();
  for (const l of g.lines) b.lines.push({ ...l, a: T(l.a), b: T(l.b) });
  for (const f of g.fills) b.fills.push({ ...f, poly: f.poly.map(T), holes: (f.holes || []).map((hh) => hh.map(T)) });
  for (const t of g.texts) b.texts.push({ ...t, at: T(t.at), rot: (t.rot || 0) + (rotation * Math.PI) / 180 });
  return b;
}

/**
 * The offset and rotation of a trace turned by `deg` degrees about a point c
 * of the drawing it lies in: the rest of the placement carries on from there.
 */
export function turnTrace(trace, c, deg) {
  const a = (deg * Math.PI) / 180;
  const o = trace?.offset || [0, 0];
  const moved = rotate([o[0] - c[0], o[1] - c[1]], a);
  return { rotation: (+trace?.rotation || 0) + deg, offset: [c[0] + moved[0], c[1] + moved[1]] };
}

/** The views a trace shows: one, or every other story's plan for Entire Model Display. */
export function traceReferences(doc, view, trace) {
  if (trace?.on && trace.refId === 'entire') return doc.all('plan').filter((p) => p.id !== view?.id);
  const one = traceReference(doc, view, trace);
  return one ? [one] : [];
}
