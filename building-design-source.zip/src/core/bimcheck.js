/**
 * Model data checks (Library Developer, experimental in Archicad): what a
 * model lacks as BIM data, and what its IFC file says once written, with no
 * IDS needed.
 */
import { classifiable, classOf } from './classify.js';
import { materialOf } from './plan.js';

/** Elements short of BIM data, by problem: [{ id, title, ids }]. */
export function missingBimData(doc) {
  const system = doc.all('classSystem')[0];
  const groups = {
    classification: { title: 'No classification', ids: [] },
    id: { title: 'No element ID', ids: [] },
    name: { title: 'Zone without a real name', ids: [] },
    material: { title: 'Only the default material', ids: [] },
    level: { title: 'No valid story', ids: [] },
  };
  for (const el of doc.items.values()) {
    if (!el.kind || !classifiable(doc, el) || el.viewId) continue;
    if (system && !classOf(doc, el, system)) groups.classification.ids.push(el.id);
    if (['door', 'window'].includes(el.kind) && !el.mark) groups.id.ids.push(el.id);
    if (el.kind === 'room') {
      if (!String(el.name || '').trim() || /^room$/i.test(el.name)) groups.name.ids.push(el.id);
    } else if (el.typeId) {
      const layers = doc.get(el.typeId)?.layers;
      const defaults = layers?.length ? layers.every((l) => !l.materialId || l.materialId === 'mat-default') : materialOf(doc, el)?.id === 'mat-default';
      if (defaults) groups.material.ids.push(el.id);
    }
    if (el.levelId && !doc.has(el.levelId)) groups.level.ids.push(el.id);
  }
  return Object.entries(groups).filter(([, g]) => g.ids.length).map(([id, g]) => ({ id, ...g }));
}

/** Top-level arguments of a STEP record's text inside its brackets. */
function stepArgs(s) {
  const out = [];
  let depth = 0;
  let cur = '';
  let q = false;
  for (const c of s) {
    if (c === "'") q = !q;
    if (!q && c === '(') depth++;
    if (!q && c === ')') depth--;
    if (!q && c === ',' && depth === 0) {
      out.push(cur);
      cur = '';
    } else cur += c;
  }
  out.push(cur);
  return out.map((x) => x.trim());
}

const SPATIAL = new Set(['IFCPROJECT', 'IFCSITE', 'IFCBUILDING', 'IFCBUILDINGSTOREY', 'IFCSPACE']);

/** Whether a record is a physical product (rooted, with placement and shape attributes). */
const isProduct = (name, args) => !SPATIAL.has(name) && args.length >= 8 && /^'/.test(args[0]) && /^(#\d+|\$)$/.test(args[5] ?? '') && /^(#\d+|\$)$/.test(args[6] ?? '') && !/^IFC(REL|PROPERTY|ELEMENTQUANTITY|.*TYPE$)/.test(name);

/**
 * What an IFC file holds and what is wrong with it: { schema, counts: { name: n }, products,
 * issues: [{ level, title, count }] }.
 */
export function checkIfcText(text) {
  const recs = new Map();
  for (const line of text.split('\n')) {
    const m = /^#(\d+)\s*=\s*([A-Z0-9_]+)\((.*)\);\s*$/.exec(line);
    if (m) recs.set(m[1], { name: m[2], args: stepArgs(m[3]) });
  }
  const counts = {};
  const guids = new Map();
  const products = [];
  const spaces = [];
  for (const [id, r] of recs) {
    counts[r.name] = (counts[r.name] || 0) + 1;
    if (/^'[^']{22}'$/.test(r.args[0] || '')) guids.set(r.args[0], (guids.get(r.args[0]) || 0) + 1);
    if (r.name === 'IFCSPACE') spaces.push(r);
    if (isProduct(r.name, r.args)) products.push({ id, ...r });
  }
  const contained = new Set();
  const withProps = new Set();
  const refs = (s) => [...String(s).matchAll(/#(\d+)/g)].map((m) => m[1]);
  for (const r of recs.values()) {
    if (r.name === 'IFCRELCONTAINEDINSPATIALSTRUCTURE') refs(r.args[4]).forEach((x) => contained.add(x));
    if (r.name === 'IFCRELFILLSELEMENT') refs(r.args[5]).forEach((x) => contained.add(x));
    if (r.name === 'IFCRELVOIDSELEMENT') refs(r.args[5]).forEach((x) => contained.add(x));
    if (r.name === 'IFCRELAGGREGATES') refs(r.args[5]).forEach((x) => contained.add(x));
    if (r.name === 'IFCRELDEFINESBYPROPERTIES') refs(r.args[4]).forEach((x) => withProps.add(x));
  }
  const issues = [];
  const add = (level, title, count) => count && issues.push({ level, title, count });
  const need = (name, label) => add('error', `No ${label} in the file`, counts[name] ? 0 : 1);
  need('IFCPROJECT', 'project');
  need('IFCSITE', 'site');
  need('IFCBUILDING', 'building');
  need('IFCBUILDINGSTOREY', 'story');
  add('error', 'GlobalIds used more than once', [...guids.values()].filter((n) => n > 1).length);
  const real = products.filter((p) => p.name !== 'IFCOPENINGELEMENT');
  add('error', 'Products not placed on a story', real.filter((p) => !contained.has(p.id)).length);
  add('warning', 'Products without a name', real.filter((p) => p.args[2] === '$' || p.args[2] === "''").length);
  add('warning', 'Products without geometry', real.filter((p) => p.args[6] === '$').length);
  add('warning', 'Exported as generic proxies', counts.IFCBUILDINGELEMENTPROXY || 0);
  add('info', 'Products without property sets', real.filter((p) => !withProps.has(p.id)).length);
  add('warning', 'Spaces without a name', spaces.filter((s) => s.args[2] === '$' || s.args[2] === "''").length);
  add('info', 'Spaces without a long name', spaces.filter((s) => (s.args[7] ?? '$') === '$').length);
  const schema = /FILE_SCHEMA\s*\(\s*\(\s*'([^']+)'/.exec(text)?.[1] || '?';
  return { schema, counts, products: real.length, issues };
}
