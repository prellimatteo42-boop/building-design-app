/**
 * Fitting the camera of a rebuilt room to the photo it came from. The photo's edges (Sobel, the strongest share of
 * them) give a distance map: how far each pixel is from an edge. The room's own lines (where walls meet the floor, the
 * ceiling and each other) are projected with a camera; the camera is good when they fall on the photo's edges. A
 * search over the camera's position, heading, tilt and field of view makes the mean (capped) distance smallest.
 */

/** Two-pass chamfer distance from the pixels set in `on` (capped). */
function chamfer(on, w, h, cap) {
  const dist = new Float32Array(w * h).fill(cap);
  for (let i = 0; i < w * h; i++) if (on[i]) dist[i] = 0;
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      let d = dist[i];
      if (x > 0) d = Math.min(d, dist[i - 1] + 1);
      if (y > 0) {
        d = Math.min(d, dist[i - w] + 1);
        if (x > 0) d = Math.min(d, dist[i - w - 1] + 1.4142);
        if (x < w - 1) d = Math.min(d, dist[i - w + 1] + 1.4142);
      }
      dist[i] = d;
    }
  for (let y = h - 1; y >= 0; y--)
    for (let x = w - 1; x >= 0; x--) {
      const i = y * w + x;
      let d = dist[i];
      if (x < w - 1) d = Math.min(d, dist[i + 1] + 1);
      if (y < h - 1) {
        d = Math.min(d, dist[i + w] + 1);
        if (x < w - 1) d = Math.min(d, dist[i + w + 1] + 1.4142);
        if (x > 0) d = Math.min(d, dist[i + w - 1] + 1.4142);
      }
      dist[i] = Math.min(cap, d);
    }
  return dist;
}

/**
 * Edges of a picture (RGBA, w × h): each pixel's distance to the nearest edge (dist), to the nearest edge running
 * level-ish (distH: horizontal lines of the picture) and to the nearest one running upright (distV). Capped.
 */
export function edgeMap(rgba, w, h, { share = 0.1, cap = 40 } = {}) {
  const g = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) g[i] = 0.299 * rgba[4 * i] + 0.587 * rgba[4 * i + 1] + 0.114 * rgba[4 * i + 2];
  const mag = new Float32Array(w * h);
  const gxs = new Float32Array(w * h);
  const gys = new Float32Array(w * h);
  for (let y = 1; y < h - 1; y++)
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const gx = g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1] - g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1];
      const gy = g[i + w - 1] + 2 * g[i + w] + g[i + w + 1] - g[i - w - 1] - 2 * g[i - w] - g[i - w + 1];
      mag[i] = Math.hypot(gx, gy);
      gxs[i] = gx;
      gys[i] = gy;
    }
  // The threshold that keeps the strongest share of the pixels.
  const sorted = Float32Array.from(mag).sort();
  const t = Math.max(1, sorted[Math.floor(sorted.length * (1 - share))]);
  const all = new Uint8Array(w * h);
  const level = new Uint8Array(w * h);
  const upright = new Uint8Array(w * h);
  for (let i = 0; i < w * h; i++) {
    if (mag[i] < t) continue;
    all[i] = 1;
    // A level line has its gradient up or down; an upright one, left or right.
    if (Math.abs(gys[i]) > 1.7 * Math.abs(gxs[i])) level[i] = 1;
    else if (Math.abs(gxs[i]) > 1.7 * Math.abs(gys[i])) upright[i] = 1;
  }
  return { w, h, cap, dist: chamfer(all, w, h, cap), distH: chamfer(level, w, h, cap), distV: chamfer(upright, w, h, cap) };
}

/** A pinhole camera { eye, heading, tilt (radians), fov (vertical degrees) } projecting into a w × h picture. */
export function projector(cam, w, h) {
  const [ch, sh, ct, st] = [Math.cos(cam.heading), Math.sin(cam.heading), Math.cos(cam.tilt), Math.sin(cam.tilt)];
  const f = [ct * ch, ct * sh, st];
  const r = [sh, -ch, 0];
  const u = [-st * ch, -st * sh, ct];
  const k = h / 2 / Math.tan(((cam.fov || 55) * Math.PI) / 360);
  return (p) => {
    const d = [p[0] - cam.eye[0], p[1] - cam.eye[1], p[2] - cam.eye[2]];
    const z = d[0] * f[0] + d[1] * f[1] + d[2] * f[2];
    if (z < 100) return null;
    return [w / 2 + (k * (d[0] * r[0] + d[1] * r[1] + d[2] * r[2])) / z, h / 2 - (k * (d[0] * u[0] + d[1] * u[1] + d[2] * u[2])) / z];
  };
}

/** The camera as eye and target (and back): heading and tilt of the line of sight. */
export const fromEyeTarget = (eye, target, fov) => {
  const d = [target[0] - eye[0], target[1] - eye[1], target[2] - eye[2]];
  return { eye: [...eye], heading: Math.atan2(d[1], d[0]), tilt: Math.atan2(d[2], Math.hypot(d[0], d[1])), fov };
};
export const toEyeTarget = (cam, reach = 3000) => ({
  eye: cam.eye.map((v) => Math.round(v)),
  target: [cam.eye[0] + reach * Math.cos(cam.tilt) * Math.cos(cam.heading), cam.eye[1] + reach * Math.cos(cam.tilt) * Math.sin(cam.heading), cam.eye[2] + reach * Math.sin(cam.tilt)].map((v) => Math.round(v)),
  fov: Math.round(cam.fov * 10) / 10,
});

/**
 * How well the lines fall on the photo's edges. Points along each line (lines are [[x, y, z], [x, y, z]] in mm) are
 * looked up in the distance map of edges running the same way: level lines in the level edges, upright ones in the
 * upright edges, slanting ones in all. mean: their mean distance (pixels, capped); near: the share within `tol`
 * pixels; seen: the share that lands in the picture. cost: what the search makes smallest.
 */
export function lineScore(lines, cam, map, { step = 6, tol = 3 } = {}) {
  const P = projector(cam, map.w, map.h);
  let sum = 0;
  let n = 0;
  let near = 0;
  let all = 0;
  for (const [a, b] of lines) {
    const pa = P(a);
    const pb = P(b);
    const len = pa && pb ? Math.hypot(pb[0] - pa[0], pb[1] - pa[1]) : 0;
    const dx = pa && pb ? Math.abs(pb[0] - pa[0]) : 0;
    const dy = pa && pb ? Math.abs(pb[1] - pa[1]) : 0;
    const d = dx > 2.5 * dy ? map.distH : dy > 2.5 * dx ? map.distV : map.dist;
    const k = Math.max(8, Math.min(200, Math.round(len / step)));
    for (let i = 0; i <= k; i++) {
      const t = i / k;
      const q = P([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]);
      all++;
      if (!q) continue;
      const x = Math.round(q[0]);
      const y = Math.round(q[1]);
      if (x < 0 || y < 0 || x >= map.w || y >= map.h) continue;
      const v = d[y * map.w + x];
      sum += v;
      if (v <= tol) near++;
      n++;
    }
  }
  const seen = all ? n / all : 0;
  const mean = n ? sum / n : map.cap;
  // Most weight on points that land on a matching edge; lines left outside the picture count as missing it.
  const cost = 1 - (all ? near / all : 0) + (0.3 * Math.min(mean, map.cap)) / map.cap;
  return { mean, near: n ? near / n : 0, seen, cost };
}

/** The camera that brings the lines onto the photo's edges, from a first guess: a shrinking coordinate search. */
function localFit(lines, cam0, map, { rounds = 6 } = {}) {
  const deg = Math.PI / 180;
  const keys = [
    ['eye', 0, 300],
    ['eye', 1, 300],
    ['eye', 2, 150],
    ['heading', null, 3 * deg],
    ['tilt', null, 3 * deg],
    ['fov', null, 4],
  ];
  const get = (c, [k, i]) => (i == null ? c[k] : c[k][i]);
  const set = (c, [k, i], v) => {
    const d = { ...c, eye: [...c.eye] };
    if (i == null) d[k] = v;
    else d[k][i] = v;
    if (d.fov < 20) d.fov = 20;
    if (d.fov > 100) d.fov = 100;
    return d;
  };
  let cam = { ...cam0, eye: [...cam0.eye] };
  let best = lineScore(lines, cam, map).cost;
  let evals = 1;
  for (let r = 0; r < rounds; r++) {
    const scale = 1 / 2 ** r;
    let moved = true;
    let guard = 0;
    while (moved && guard++ < 12) {
      moved = false;
      for (const key of keys) {
        for (const s of [1, -1]) {
          const c = set(cam, key, get(cam, key) + s * key[2] * scale);
          const v = lineScore(lines, c, map).cost;
          evals++;
          if (v < best - 1e-6) {
            best = v;
            cam = c;
            moved = true;
          }
        }
      }
    }
  }
  return { cam, cost: best, evals };
}

/**
 * The camera that brings the lines onto the photo's edges: a shrinking coordinate search from the first guess and
 * from starts scattered round it (the photo has many edges near the right ones, so one search can stop on the wrong
 * ones), keeping the best.
 */
export function fitCamera(lines, cam0, map, { starts = 30, seed = 7, spread = { eye: 900, height: 400, heading: 10, tilt: 6, fov: 14 } } = {}) {
  let r = seed;
  const rnd = () => ((r = (r * 16807) % 2147483647) / 2147483647) * 2 - 1;
  const deg = Math.PI / 180;
  const before = lineScore(lines, cam0, map);
  // Quick searches from every start, then the best few searched finely.
  const tries = [cam0];
  for (let i = 1; i < starts; i++)
    tries.push({ eye: [cam0.eye[0] + rnd() * spread.eye, cam0.eye[1] + rnd() * spread.eye, cam0.eye[2] + rnd() * spread.height], heading: cam0.heading + rnd() * spread.heading * deg, tilt: cam0.tilt + rnd() * spread.tilt * deg, fov: Math.max(25, Math.min(90, cam0.fov + rnd() * spread.fov)) });
  let evals = 0;
  const coarse = tries.map((c) => {
    const f = localFit(lines, c, map, { rounds: 3 });
    evals += f.evals;
    return f;
  });
  coarse.sort((a, b) => a.cost - b.cost);
  let best = null;
  for (const c of coarse.slice(0, 4)) {
    const f = localFit(lines, c.cam, map, { rounds: 7 });
    evals += f.evals;
    if (!best || f.cost < best.cost) best = f;
  }
  return { cam: best.cam, before, after: lineScore(lines, best.cam, map), evals };
}
