/**
 * Save GDL, and Save Selection as Object / Door / Window / Stair Tread /
 * Riser / Railing Post / Railing Panel / Label / Drawing Title, as in
 * Archicad: the selected elements' 3D bodies written as a GDL library part
 * (faces as PLANE, edges as LIN_, each element with its material), with
 * its box (A, B, ZZYZX) and a 2D script that projects the 3D from above.
 * 2D selections (lines, arcs, fills, texts) become a 2D-only part for
 * labels and drawing titles.
 *
 * GDL lengths are metres, from the box's corner; the app places its own
 * GDL objects by the centre of the box.
 */
const R = (v) => Math.round(v * 10000) / 10000;
const MAX_TRIS = 60000;

/**
 * GDL of 3D meshes: items [{ mesh, materialId }]. Returns { width, depth, height (mm), origin: [cx, cy, z0] (model
 * mm, where the part's insertion point goes), script3d, script2d, triangles } or null when there is nothing.
 */
export function gdlFromMeshes(items, { opening = false } = {}) {
  let x0 = Infinity;
  let y0 = Infinity;
  let z0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  let z1 = -Infinity;
  let tris = 0;
  for (const { mesh } of items) {
    const P = mesh?.pos;
    if (!P) continue;
    for (let i = 0; i < P.length; i += 3) {
      x0 = Math.min(x0, P[i]);
      x1 = Math.max(x1, P[i]);
      y0 = Math.min(y0, P[i + 1]);
      y1 = Math.max(y1, P[i + 1]);
      z0 = Math.min(z0, P[i + 2]);
      z1 = Math.max(z1, P[i + 2]);
    }
    tris += P.length / 9;
  }
  if (!Number.isFinite(x0)) return null;
  if (tris > MAX_TRIS) throw new Error(`The selection has ${tris} triangles; at most ${MAX_TRIS} can be saved as GDL.`);
  // Doors and windows (GDL's opening axes): x along the wall from the middle, y up, z into the wall.
  const xm = (x0 + x1) / 2;
  const q = opening ? (x, y, z) => `${R((x - xm) / 1000)}, ${R((z - z0) / 1000)}, ${R((y - y0) / 1000)}` : (x, y, z) => `${R((x - x0) / 1000)}, ${R((y - y0) / 1000)}, ${R((z - z0) / 1000)}`;
  const lines = [opening ? '! Saved from Building Design as an opening: x along the wall, y up, z into the wall.' : '! Saved from Building Design: faces as PLANE, edges as LIN_.'];
  for (const { mesh, materialId } of items) {
    const P = mesh?.pos;
    if (!P) continue;
    if (materialId) lines.push(`MATERIAL "${materialId}"`);
    for (let t = 0; t < P.length; t += 9) lines.push(`PLANE 3, ${q(P[t], P[t + 1], P[t + 2])}, ${q(P[t + 3], P[t + 4], P[t + 5])}, ${q(P[t + 6], P[t + 7], P[t + 8])}`);
    const E = mesh.edges;
    if (E) for (let e = 0; e < E.length; e += 6) lines.push(`LIN_ ${q(E[e], E[e + 1], E[e + 2])}, ${q(E[e + 3], E[e + 4], E[e + 5])}`);
  }
  return {
    width: Math.max(1, Math.round(x1 - x0)),
    depth: Math.max(1, Math.round(y1 - y0)),
    height: Math.max(1, Math.round(z1 - z0)),
    origin: [(x0 + x1) / 2, (y0 + y1) / 2, z0],
    corner: [x0, y0, z0],
    script3d: lines.join('\n'),
    // An opening's plan: its box across the wall; other parts: the 3D seen from above.
    script2d: opening ? `RECT2 -A / 2, 0, A / 2, ${R((y1 - y0) / 1000)}` : 'PROJECT2 3, 270, 2',
    triangles: tris,
  };
}

/**
 * A 2D-only part from plan graphics: { lines: [{ a, b }], polys: [{ pts, closed }], texts: [{ at, text, size }] } in
 * model mm. Returns { width, depth, origin, script2d } (origin: the bottom-left corner).
 */
export function gdl2DFrom({ lines = [], polys = [], texts = [] }) {
  const pts = [...lines.flatMap((l) => [l.a, l.b]), ...polys.flatMap((p) => p.pts), ...texts.map((t) => t.at)];
  if (!pts.length) return null;
  const x0 = Math.min(...pts.map((p) => p[0]));
  const y0 = Math.min(...pts.map((p) => p[1]));
  const x1 = Math.max(...pts.map((p) => p[0]));
  const y1 = Math.max(...pts.map((p) => p[1]));
  const q = (p) => `${R((p[0] - x0) / 1000)}, ${R((p[1] - y0) / 1000)}`;
  const out = ['! Saved from Building Design.'];
  for (const l of lines) out.push(`LINE2 ${q(l.a)}, ${q(l.b)}`);
  for (const p of polys) {
    if (p.pts.length < 2) continue;
    if (p.closed && p.pts.length >= 3) out.push(`POLY2 ${p.pts.length}, 1, ${p.pts.map(q).join(', ')}`);
    else for (let i = 0; i + 1 < p.pts.length; i++) out.push(`LINE2 ${q(p.pts[i])}, ${q(p.pts[i + 1])}`);
  }
  for (const t of texts) out.push(`TEXT2 ${q(t.at)}, "${String(t.text).replace(/"/g, "'")}"`);
  return { width: Math.max(1, Math.round(x1 - x0)), depth: Math.max(1, Math.round(y1 - y0)), origin: [x0, y0], script2d: out.join('\n') };
}

/** What each Save Selection as ... target makes: the component type's kind, category and family name. */
export const SAVE_TARGETS = {
  object: { kind: 'componentType', category: 'genericModels', familyName: 'GDL Object' },
  door: { kind: 'doorType', familyName: 'GDL Door' },
  window: { kind: 'windowType', familyName: 'GDL Window' },
  stairTread: { kind: 'componentType', category: 'stairs', familyName: 'GDL Stair Tread', part: 'tread' },
  stairRiser: { kind: 'componentType', category: 'stairs', familyName: 'GDL Stair Riser', part: 'riser' },
  railingPost: { kind: 'componentType', category: 'railings', familyName: 'GDL Railing Post', part: 'post' },
  railingPanel: { kind: 'componentType', category: 'railings', familyName: 'GDL Railing Panel', part: 'panel' },
  label: { kind: 'componentType', category: 'genericAnnotations', familyName: 'GDL Label', twoD: true },
  drawingTitle: { kind: 'componentType', category: 'genericAnnotations', familyName: 'GDL Drawing Title', twoD: true },
  mepPart: { kind: 'componentType', category: 'mechanical', familyName: 'GDL MEP Part' },
};

/** The library part (a type, not added) for a target from saved GDL. */
export function partType(target, name, g) {
  const t = SAVE_TARGETS[target] || SAVE_TARGETS.object;
  const gdl = { params: [], script3d: g.script3d || '', script2d: g.script2d || '' };
  const out = { kind: t.kind, family: 'gdl', familyName: t.familyName, name, width: g.width, depth: g.depth || 1, height: g.height || 1, gdl };
  if (t.category) out.category = t.category;
  if (t.part) out.stairPart = t.part;
  if (target === 'window') out.sill = 900;
  return out;
}

/** GDL as a text file: a header, the parameters and the scripts, readable by people and by this app's GDL editor. */
export function gdlText(name, g) {
  return [`! ${name}`, `! A = ${g.width} mm, B = ${g.depth} mm, ZZYZX = ${g.height || 0} mm`, '', '!--- 3D script', g.script3d || '', '', '!--- 2D script', g.script2d || ''].join('\n');
}
