/**
 * Text boxes: a text with a box width (el.boxWidth, paper mm) wraps its
 * words to that width, as Archicad's text blocks do; Textbox Handles drag
 * the width on the plan. Sizes here are model mm (paper mm × view scale).
 */

const CHAR = 0.6;
const LINE = 1.3;

/** Words of each paragraph wrapped to at most `n` characters a line (long words stay whole). */
export function wrapText(text, n) {
  const out = [];
  for (const para of String(text ?? '').split('\n')) {
    if (!(n > 0)) {
      out.push(para);
      continue;
    }
    let line = '';
    for (const w of para.split(/\s+/).filter(Boolean)) {
      if (line && line.length + 1 + w.length > n) (out.push(line), (line = w));
      else line = line ? `${line} ${w}` : w;
    }
    out.push(line);
  }
  return out;
}

/**
 * The lines and box of a text: { lines, w, h, x0 } for its size in model mm, alignment and box width (paper mm)
 * at a view scale. x0 is where the box starts from the insertion point along the text's direction.
 */
export function textBox(el, size, align = 'left', scale = 1) {
  const boxW = +el.boxWidth > 0 ? el.boxWidth * scale : 0;
  const lines = boxW ? wrapText(el.text, Math.max(1, Math.floor(boxW / (size * CHAR)))) : String(el.text ?? '').split('\n');
  const w = boxW || size * CHAR * Math.max(1, ...lines.map((l) => l.length));
  const h = size * LINE * lines.length;
  const x0 = align === 'center' ? -w / 2 : align === 'right' ? -w : 0;
  return { lines, w, h, x0 };
}

/** The box width (paper mm) for a handle dragged to distance `d` (model mm) from the box's fixed side. */
export const boxWidthFor = (d, scale = 1) => Math.max(5, Math.round((Math.abs(d) / scale) * 10) / 10);
