/**
 * The user's own library: objects that the Archicad libraries do not have, kept in this browser between projects.
 * The assistant and the user add to it; it is searched like any other library and can be written as an Archicad
 * library (.lcf or single .gsm files) to load in Archicad.
 *
 *   entry { name, words, category, width, depth, height, gdl, thumb (data URL), added (ISO date) }
 */
import { matchesQuery } from './furniture.js';
import { runGdlType } from './gdlobject.js';
import { writeObjectPart } from '../io/gsm.js';

const DB = 'bd-userlib';
const STORE = 'objects';

function open() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') return reject(new Error('No IndexedDB'));
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: 'name' });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/** Keeps entries in memory, and in IndexedDB where there is one (not in tests). */
export class UserLibrary {
  constructor() {
    this.items = new Map();
    this.loading = null;
  }

  ready() {
    this.loading ||= open()
      .then((db) => new Promise((resolve) => {
        const req = db.transaction(STORE).objectStore(STORE).getAll();
        req.onsuccess = () => {
          for (const e of req.result) this.items.set(e.name.toLowerCase(), e);
          resolve();
        };
        req.onerror = () => resolve();
      }))
      .catch(() => {});
    return this.loading;
  }

  all() {
    return [...this.items.values()].sort((a, b) => a.name.localeCompare(b.name));
  }

  get(name) {
    return this.items.get(String(name).toLowerCase()) || null;
  }

  search(query) {
    return this.all().filter((e) => matchesQuery(`${e.name} ${e.words || ''} ${e.category || ''}`, query));
  }

  async add(entry) {
    await this.ready();
    this.items.set(entry.name.toLowerCase(), entry);
    await this.write((s) => s.put(entry));
    return entry;
  }

  async remove(name) {
    await this.ready();
    const e = this.get(name);
    if (!e) return false;
    this.items.delete(e.name.toLowerCase());
    await this.write((s) => s.delete(e.name));
    return true;
  }

  write(fn) {
    return open()
      .then((db) => new Promise((resolve) => {
        const tx = db.transaction(STORE, 'readwrite');
        fn(tx.objectStore(STORE));
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      }))
      .catch(() => {});
  }
}

/** A library entry from a GDL object type of a project. */
export function entryFromType(type, { name, words = '', thumb = null } = {}) {
  return { name: name || type.name, words, category: type.category || 'furniture', width: type.width, depth: type.depth, height: type.height, gdl: structuredClone(type.gdl), thumb, added: new Date().toISOString() };
}

/** The fields of a project object type for an entry of the library. */
export function typeFromEntry(e) {
  return { kind: 'componentType', family: 'gdl', familyName: 'My Library', name: e.name, category: e.category, width: e.width, depth: e.depth, height: e.height, gdl: structuredClone(e.gdl) };
}

/** The triangles of a type as seen from the front, a little to the left and above: [{ pts: [[x, y]...], depth, normal, color }]. */
export function thumbnailFaces(type) {
  const { tris } = runGdlType(type);
  const view = (p) => [p[0] * 0.8 + p[1] * 0.6, p[2] * 0.82 - (p[1] * 0.8 - p[0] * 0.6) * 0.5 * -1, -p[0] * 0.5 + p[1] * 0.66 - p[2] * 0.55];
  const faces = [];
  for (const t of tris) {
    const [a, b, c] = [view(t.a), view(t.b), view(t.c)];
    const n = [(t.b[1] - t.a[1]) * (t.c[2] - t.a[2]) - (t.b[2] - t.a[2]) * (t.c[1] - t.a[1]), (t.b[2] - t.a[2]) * (t.c[0] - t.a[0]) - (t.b[0] - t.a[0]) * (t.c[2] - t.a[2]), (t.b[0] - t.a[0]) * (t.c[1] - t.a[1]) - (t.b[1] - t.a[1]) * (t.c[0] - t.a[0])];
    const len = Math.hypot(...n) || 1;
    faces.push({ pts: [a, b, c], depth: (a[2] + b[2] + c[2]) / 3, normal: n.map((v) => v / len), color: t.src ? [0.55, 0.55, 0.55] : t.rgb || [0.7, 0.68, 0.65], alpha: t.alpha ?? 1 });
  }
  return faces.sort((p, q) => q.depth - p.depth);
}

/** A small picture of a type, drawn without the 3D view: a data URL. In the browser only. */
export function thumbnail(type, size = 240) {
  const faces = thumbnailFaces(type);
  const cv = document.createElement('canvas');
  cv.width = cv.height = size;
  const g = cv.getContext('2d');
  g.fillStyle = '#fff';
  g.fillRect(0, 0, size, size);
  if (!faces.length) return cv.toDataURL('image/jpeg', 0.85);
  const xs = faces.flatMap((f) => f.pts.map((p) => p[0]));
  const ys = faces.flatMap((f) => f.pts.map((p) => p[1]));
  const [x0, x1, y0, y1] = [Math.min(...xs), Math.max(...xs), Math.min(...ys), Math.max(...ys)];
  const k = (size - 20) / Math.max(x1 - x0, y1 - y0, 1);
  const px = (p) => [size / 2 + (p[0] - (x0 + x1) / 2) * k, size / 2 - (p[1] - (y0 + y1) / 2) * k];
  for (const f of faces) {
    const lit = 0.62 + 0.38 * Math.abs(f.normal[0] * -0.4 + f.normal[1] * -0.5 + f.normal[2] * 0.77);
    const c = f.color.map((v) => Math.round(Math.min(1, v * lit) * 255));
    g.fillStyle = `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${f.alpha})`;
    g.strokeStyle = g.fillStyle;
    g.beginPath();
    f.pts.map(px).forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y)));
    g.closePath();
    g.fill();
    g.stroke();
  }
  return cv.toDataURL('image/jpeg', 0.85);
}

const safeName = (s) => String(s).replace(/[\\/:*?"<>|]+/g, '_');

/** The entries as files of an Archicad library: [{ path, data }]. ancestry: the ANCS section of an object of the user's own library, which says what kind of part these are. */
export function archicadFiles(entries, ancestry) {
  const used = new Set();
  return entries.map((e) => {
    let base = safeName(e.name);
    while (used.has(base.toLowerCase())) base += '_';
    used.add(base.toLowerCase());
    return { path: `${base}.gsm`, data: writeObjectPart({ ...e, name: base, ancestry }) };
  });
}
