/**
 * Curtain wall schemes, frame classes and panel classes (Archicad's Curtain
 * Wall Scheme, Frame and Panel settings, reimplemented from the user guide):
 *
 *   type.curtain.uScheme / vScheme  { pattern: [sizes], fit }
 *     a repeating module pattern of different widths along the wall (u) or
 *     up it (v). fit:
 *       'repeat'  whole patterns from the start, the remainder last
 *       'center'  whole patterns, the remainder split between both ends
 *       'stretch' the pattern repeated round(total / pattern) times, scaled
 *                 to fit exactly
 *       'fixed'   the pattern once as given, the rest one panel
 *   type.curtain.frames  { boundary, mullion, transom }  each
 *     { kind: 'rect' | 'capped' | 'tee' | 'butt', width, depth }
 *   type.curtain.frameClasses  [{ id, name, kind, width, depth }]  extra classes,
 *     assigned per segment with wall.frameClass['v:i:j' | 'h:j:i'] = id
 *   type.curtain.panelClasses  [{ id, name, kind, thickness, materialId }]  extra
 *     classes, assigned per cell with wall.panels['i:j'] = id (the built-in kinds
 *     glass, solid, door, empty still work there)
 */

export const FIT_MODES = [
  { value: 'repeat', label: 'Repeat, remainder at the end' },
  { value: 'center', label: 'Repeat, remainder at both ends' },
  { value: 'stretch', label: 'Stretch modules to fit' },
  { value: 'fixed', label: 'Pattern once, rest in one panel' },
];

export const FRAME_KINDS = [
  { value: 'rect', label: 'Rectangular' },
  { value: 'capped', label: 'Capped (pressure cap outside)' },
  { value: 'tee', label: 'T profile (fin inside)' },
  { value: 'butt', label: 'Butt-glazed (silicone joint)' },
];

export const PANEL_KINDS = [
  { value: 'glass', label: 'Glass' },
  { value: 'solid', label: 'Solid' },
  { value: 'spandrel', label: 'Spandrel (opaque glass)' },
  { value: 'louvre', label: 'Louvre' },
  { value: 'door', label: 'Door' },
  { value: 'empty', label: 'Empty' },
];

const MIN_PANEL = 1;

/** Parse a pattern given as text ("900, 1500 900") or a list into positive sizes. */
export function parsePattern(v) {
  const list = Array.isArray(v) ? v : String(v ?? '').split(/[\s,;]+/);
  return list.map((x) => +x).filter((x) => Number.isFinite(x) && x > 0);
}

/** Grid line positions from 0 to total (both included) for a module pattern. */
export function schemeLines(total, scheme) {
  const pattern = parsePattern(scheme?.pattern);
  if (!(total > 0)) return [0, Math.max(0, total || 0)];
  if (!pattern.length) return [0, total];
  const fit = scheme.fit || 'repeat';
  const sum = pattern.reduce((s, x) => s + x, 0);
  const out = [0];
  const push = (u) => {
    if (u > out.at(-1) + MIN_PANEL && u < total - MIN_PANEL) out.push(u);
  };
  if (fit === 'stretch') {
    const reps = Math.max(1, Math.round(total / sum));
    const k = total / (reps * sum);
    let u = 0;
    for (let r = 0; r < reps; r++)
      for (const x of pattern) {
        u += x * k;
        push(u);
      }
  } else if (fit === 'fixed') {
    let u = 0;
    for (const x of pattern) {
      u += x;
      if (u >= total) break;
      push(u);
    }
  } else {
    // Whole modules (not only whole patterns) that fit, then the remainder.
    const sizes = [];
    let used = 0;
    for (let i = 0; used + pattern[i % pattern.length] <= total + 1e-6; i++) {
      sizes.push(pattern[i % pattern.length]);
      used += pattern[(i) % pattern.length];
      if (sizes.length > 10000) break;
    }
    const rest = total - used;
    let u = fit === 'center' && rest > MIN_PANEL ? rest / 2 : 0;
    if (u) push(u);
    for (const x of sizes) {
      u += x;
      push(u);
    }
  }
  out.push(total);
  return out;
}

const DEFAULT_FRAME = (c) => ({ kind: 'rect', width: +c.mullionWidth || 50, depth: +c.mullionDepth || 150 });

/** The three frame roles of a curtain type, filled from the old single mullion size. */
export function frameRoles(c = {}) {
  const base = DEFAULT_FRAME(c);
  const f = c.frames || {};
  const role = (r, extra = {}) => ({ ...base, ...extra, ...(f[r] || {}), id: r, name: r[0].toUpperCase() + r.slice(1) });
  return { boundary: role('boundary'), mullion: role('mullion'), transom: role('transom') };
}

/** Every frame class: the three roles then the type's own classes. */
export function frameClasses(c = {}) {
  const roles = frameRoles(c);
  const base = DEFAULT_FRAME(c);
  return [roles.boundary, roles.mullion, roles.transom, ...(c.frameClasses || []).map((x) => ({ ...base, ...x }))];
}

/**
 * The frame class of one segment: 'v:i:j' (vertical line i, cell row j) or
 * 'h:j:i' (horizontal line j, cell column i). Boundary on the outer lines,
 * mullion or transom inside, unless the wall assigns a class to the segment.
 */
export function frameFor(c, w, key, nu, nv) {
  const classes = frameClasses(c);
  const own = w?.frameClass?.[key];
  if (own) {
    const hit = classes.find((x) => x.id === own);
    if (hit) return hit;
  }
  const [dir, line] = key.split(':');
  const roles = frameRoles(c);
  if (dir === 'v') return +line === 0 || +line === nu ? roles.boundary : roles.mullion;
  return +line === 0 || +line === nv ? roles.boundary : roles.transom;
}

/** Built-in panel classes plus the type's own. */
export function panelClasses(c = {}) {
  const t = +c.panelThickness || 12;
  const builtIn = PANEL_KINDS.map((k) => ({ id: k.value, name: k.label, kind: k.value, thickness: k.value === 'solid' ? 30 : t, materialId: k.value === 'solid' ? c.panelMaterialId || null : null }));
  return [...builtIn, ...(c.panelClasses || []).map((x) => ({ thickness: t, ...x, kind: x.kind || 'glass' }))];
}

/** The panel class of cell i:j (glass unless the wall says otherwise). */
export function panelFor(c, w, i, j) {
  const v = w?.panels?.[`${i}:${j}`] || c.mainPanel || 'glass';
  const all = panelClasses(c);
  return all.find((x) => x.id === v) || all[0];
}

/**
 * Boxes of one frame segment's profile in its own section: [across0, y0, across1, y1]
 * with across centred on the grid line and y out of the exterior face (from -depth/2).
 */
export function frameSection(f) {
  const w = Math.max(1, +f.width || 50);
  const d = Math.max(1, +f.depth || 150);
  switch (f.kind) {
    case 'capped': {
      // Core inside, a wider and thinner cap on the outside with a small gap.
      const capD = Math.min(40, d * 0.3);
      return [
        [-w / 2, -d / 2, w / 2, d / 2 - capD - 5],
        [-w * 0.6, d / 2 - capD, w * 0.6, d / 2],
      ];
    }
    case 'tee': {
      // A flange along the glass and a fin into the room.
      const fl = Math.min(d, Math.max(20, w * 0.6));
      return [
        [-w / 2, d / 2 - fl, w / 2, d / 2],
        [-w / 6, -d / 2, w / 6, d / 2 - fl],
      ];
    }
    case 'butt':
      return [[-Math.min(w, 25) / 2, -Math.min(d, 30) / 2, Math.min(w, 25) / 2, Math.min(d, 30) / 2]];
    default:
      return [[-w / 2, -d / 2, w / 2, d / 2]];
  }
}
