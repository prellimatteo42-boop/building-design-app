/**
 * A CAD drawing (DWG or DXF, as read by io/dwgread.js) flattened into
 * plain geometry: blocks expanded through their insertions (translation,
 * scale, rotation, arrays, nested), polylines with arcs, circles and arcs,
 * ellipses and splines in short pieces, texts, dimension graphics, and
 * solid fills, each on its layer, in drawing units.
 *
 *   { lines: [{ a, b, layer }], arcs: [{ c, r, a0, a1, layer }], texts: [{ at, text, height, rotation, layer }],
 *     fills: [{ poly, layer }] }
 */

/** Millimetres per drawing unit by INSUNITS (0 unitless: assume millimetres). */
export const INSUNITS_MM = { 0: 1, 1: 25.4, 2: 304.8, 3: 1609344, 4: 1, 5: 10, 6: 1000, 7: 1e6, 8: 0.0000254, 9: 0.0254, 10: 914.4, 14: 100, 15: 10000 };

const P = (p) => [+p?.x || 0, +p?.y || 0];

/** Affine 2D transforms [a, b, c, d, e, f]: x' = a x + c y + e, y' = b x + d y + f. */
const ID = [1, 0, 0, 1, 0, 0];
const mul = (m, n) => [m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1], m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3], m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]];
const ap = (m, [x, y]) => [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]];
const det = (m) => m[0] * m[3] - m[1] * m[2];
const scaleOf = (m) => Math.sqrt(Math.abs(det(m))) || 1;
const angleOf = (m) => Math.atan2(m[1], m[0]);

/** Points along a polyline segment with a bulge (an arc), end excluded. */
function bulgePoints(p, q, bulge) {
  if (!bulge || Math.abs(bulge) < 1e-9) return [p];
  const theta = 4 * Math.atan(bulge);
  const chord = Math.hypot(q[0] - p[0], q[1] - p[1]);
  if (chord < 1e-9) return [p];
  const r = chord / (2 * Math.sin(theta / 2));
  const m = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2];
  const d = [(q[0] - p[0]) / chord, (q[1] - p[1]) / chord];
  const h = r * Math.cos(theta / 2);
  const c = [m[0] - d[1] * h, m[1] + d[0] * h];
  const a0 = Math.atan2(p[1] - c[1], p[0] - c[0]);
  const n = Math.max(2, Math.ceil(Math.abs(theta) / (Math.PI / 18)));
  const out = [];
  for (let k = 0; k < n; k++) {
    const a = a0 + (theta * k) / n;
    out.push([c[0] + Math.abs(r) * Math.cos(a), c[1] + Math.abs(r) * Math.sin(a)]);
  }
  out[0] = p;
  return out;
}

/** Points on an arc from a0 to a1 (radians, counterclockwise). */
function arcPts(c, r, a0, a1) {
  let sweep = a1 - a0;
  while (sweep <= 0) sweep += Math.PI * 2;
  const n = Math.max(4, Math.ceil(sweep / (Math.PI / 18)));
  const out = [];
  for (let k = 0; k <= n; k++) {
    const a = a0 + (sweep * k) / n;
    out.push([c[0] + r * Math.cos(a), c[1] + r * Math.sin(a)]);
  }
  return out;
}

/** Plain text of an MTEXT string: formatting codes removed, paragraphs kept. */
export function mtextPlain(s) {
  return String(s || '')
    .replace(/\\P/g, '\n')
    .replace(/\\[ACFHQTWfhqtwpX][^;\\]*;/g, '')
    .replace(/\\[LlOoKk]/g, '')
    .replace(/\\S([^;]*)[#^/]([^;]*);/g, '$1/$2')
    .replace(/[{}]/g, '')
    .replace(/%%[cC]/g, 'Ø')
    .replace(/%%[dD]/g, '°')
    .replace(/%%[pP]/g, '±')
    .replace(/\\~/g, ' ')
    .trim();
}

/**
 * Flatten a CAD drawing. opts: { layers: Set of layer names to keep (all when
 * absent), maxDepth, maxItems }.
 */
export function flattenCAD(cad, { layers = null, maxDepth = 8, maxItems = 400000 } = {}) {
  const out = { lines: [], arcs: [], texts: [], fills: [] };
  const keep = (layer) => !layers || layers.has(layer);
  let count = 0;
  const seg = (m, a, b, layer) => {
    if (count++ > maxItems) return;
    out.lines.push({ a: ap(m, a), b: ap(m, b), layer });
  };
  const poly = (m, pts, closed, layer) => {
    for (let i = 0; i + 1 < pts.length; i++) seg(m, pts[i], pts[i + 1], layer);
    if (closed && pts.length > 2) seg(m, pts.at(-1), pts[0], layer);
  };
  const conformal = (m) => Math.abs(Math.abs(m[0] * m[0] + m[1] * m[1]) - Math.abs(m[2] * m[2] + m[3] * m[3])) < 1e-6 * (m[0] * m[0] + m[1] * m[1] + 1) && Math.abs(m[0] * m[2] + m[1] * m[3]) < 1e-6;
  const arc = (m, c, r, a0, a1, layer) => {
    // Kept as an arc when the transform keeps circles round, else in pieces.
    if (conformal(m)) {
      // A mirroring transform runs the arc the other way round.
      const flip = det(m) < 0;
      const rot = angleOf(m);
      const s = flip ? -a1 : a0;
      const e = flip ? -a0 : a1;
      out.arcs.push({ c: ap(m, c), r: r * scaleOf(m), a0: s + rot, a1: e + rot, layer });
      count++;
    } else poly(m, arcPts(c, r, a0, a1), false, layer);
  };
  const text = (m, at, str, height, rotation, layer) => {
    if (!str) return;
    out.texts.push({ at: ap(m, at), text: str, height: (+height || 0) * scaleOf(m), rotation: (+rotation || 0) + angleOf(m), layer });
  };
  const walk = (ents, m, depth, inherit) => {
    for (const e of ents || []) {
      if (count > maxItems) return;
      if (e.isVisible === false) continue;
      // Entities on layer 0 inside a block take the insert's layer.
      const layer = e.layer === '0' && inherit ? inherit : e.layer;
      switch (e.type) {
        case 'LINE':
          if (keep(layer)) seg(m, P(e.startPoint), P(e.endPoint), layer);
          break;
        case 'LWPOLYLINE':
        case 'POLYLINE2D':
        case 'POLYLINE3D': {
          if (!keep(layer)) break;
          const vs = (e.vertices || []).map((v) => ({ p: P(v.point || v), bulge: +v.bulge || 0 }));
          const closed = !!(e.flag & 1) || !!(e.flag & 512);
          const pts = [];
          for (let i = 0; i < vs.length; i++) {
            const next = vs[(i + 1) % vs.length];
            if (i === vs.length - 1 && !closed) pts.push(vs[i].p);
            else pts.push(...bulgePoints(vs[i].p, next.p, vs[i].bulge));
          }
          poly(m, pts, closed, layer);
          break;
        }
        case 'CIRCLE':
          if (keep(layer)) arc(m, P(e.center), +e.radius, 0, Math.PI * 2, layer);
          break;
        case 'ARC':
          if (keep(layer)) arc(m, P(e.center), +e.radius, +e.startAngle, +e.endAngle, layer);
          break;
        case 'ELLIPSE': {
          if (!keep(layer)) break;
          const c = P(e.center);
          const maj = P(e.majorAxisEndPoint);
          const R = Math.hypot(...maj);
          const rot = Math.atan2(maj[1], maj[0]);
          const r2 = R * (+e.axisRatio || 1);
          let a0 = +e.startAngle || 0;
          let a1 = e.endAngle == null ? Math.PI * 2 : +e.endAngle;
          if (a1 <= a0) a1 += Math.PI * 2;
          const n = Math.max(8, Math.ceil((a1 - a0) / (Math.PI / 24)));
          const pts = [];
          for (let k = 0; k <= n; k++) {
            const t = a0 + ((a1 - a0) * k) / n;
            const x = R * Math.cos(t);
            const y = r2 * Math.sin(t);
            pts.push([c[0] + x * Math.cos(rot) - y * Math.sin(rot), c[1] + x * Math.sin(rot) + y * Math.cos(rot)]);
          }
          poly(m, pts, false, layer);
          break;
        }
        case 'SPLINE': {
          if (!keep(layer)) break;
          const pts = (e.fitPoints?.length ? e.fitPoints : e.controlPoints || []).map(P);
          poly(m, pts, !!(e.flag & 1), layer);
          break;
        }
        case 'SOLID':
        case '3DFACE': {
          if (!keep(layer)) break;
          const pts = [e.corner1, e.corner2, e.corner4 || e.corner3, e.corner3].filter(Boolean).map(P);
          if (pts.length >= 3) out.fills.push({ poly: pts.map((p) => ap(m, p)), layer });
          break;
        }
        case 'HATCH': {
          if (!keep(layer) || !e.solidFill) break;
          for (const bp of e.boundaryPaths || []) {
            let pts = [];
            if (bp.vertices) pts = bp.vertices.map(P);
            else for (const ed of bp.edges || []) {
              if (ed.start && ed.end) pts.push(P(ed.start), P(ed.end));
              else if (ed.center && ed.radius) pts.push(...arcPts(P(ed.center), +ed.radius, +ed.startAngle, +ed.endAngle));
            }
            if (pts.length >= 3) out.fills.push({ poly: pts.map((p) => ap(m, p)), layer });
          }
          break;
        }
        case 'TEXT':
        case 'ATTRIB':
        case 'ATTDEF': {
          if (!keep(layer)) break;
          const t = e.text && typeof e.text === 'object' ? e.text : e;
          if (e.type === 'ATTDEF') break;
          text(m, P(t.startPoint || t.insertionPoint), String(t.text ?? '').trim(), t.textHeight, t.rotation, layer);
          break;
        }
        case 'MTEXT':
          if (keep(layer)) text(m, P(e.insertionPoint), mtextPlain(e.text), e.textHeight, e.rotation, layer);
          break;
        case 'DIMENSION': {
          const b = e.name && cad.blocks?.[e.name];
          if (b && depth < maxDepth) walk(b.entities, mul(m, [1, 0, 0, 1, -(b.basePoint?.x || 0), -(b.basePoint?.y || 0)]), depth + 1, layer);
          break;
        }
        case 'INSERT': {
          const b = cad.blocks?.[e.name];
          if (b && depth < maxDepth) {
            const cols = Math.max(1, +e.columnCount || 1);
            const rows = Math.max(1, +e.rowCount || 1);
            const rot = +e.rotation || 0;
            const cs = Math.cos(rot);
            const sn = Math.sin(rot);
            for (let ci = 0; ci < cols; ci++)
              for (let ri = 0; ri < rows; ri++) {
                const ox = ci * (+e.columnSpacing || 0);
                const oy = ri * (+e.rowSpacing || 0);
                const ip = P(e.insertionPoint);
                const T = [cs, sn, -sn, cs, ip[0] + ox * cs - oy * sn, ip[1] + ox * sn + oy * cs];
                const S = [+e.xScale || 1, 0, 0, +e.yScale || 1, 0, 0];
                const B = [1, 0, 0, 1, -(b.basePoint?.x || 0), -(b.basePoint?.y || 0)];
                walk(b.entities, mul(m, mul(T, mul(S, B))), depth + 1, layer);
              }
          }
          for (const at of e.attribs || []) if (keep(at.layer || layer) && at.text) {
            const t = typeof at.text === 'object' ? at.text : at;
            text(m, P(t.startPoint), String(t.text ?? '').trim(), t.textHeight, t.rotation, at.layer || layer);
          }
          break;
        }
        default:
          break;
      }
    }
  };
  walk(cad.entities, ID, 0, null);
  return out;
}

/** Counts of drawn items per layer, from a flattened drawing: Map name -> n. */
export function layerCounts(flat) {
  const m = new Map();
  for (const k of ['lines', 'arcs', 'texts', 'fills']) for (const it of flat[k]) m.set(it.layer, (m.get(it.layer) || 0) + 1);
  return m;
}
