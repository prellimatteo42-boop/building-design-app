/**
 * Crop Zone, as Archicad's Design > Modify Zone > Crop Zone: a zone's volume
 * cut off under the roofs (and slabs) over it, so an attic room measures its
 * true volume. The zone keeps the ids of what crops it (cropBy); Undo All
 * Crops clears them.
 */
import { levelElevation } from './model.js';
import { pointInPolygon, signedArea } from './geom.js';
import { roofGeometry } from './build3d.js';
import { roofHeightAt, planeHeight } from './roof.js';
import { polygonBoolean } from './polybool.js';
import earcut from 'earcut';
import { typeThickness } from './catalog.js';

/** The height over the zone's floor at plan point p under one cropping element, or Infinity. */
function ceilingOver(doc, el, floor, cache) {
  if (el.kind === 'roof') {
    if (!cache.has(el.id)) cache.set(el.id, roofGeometry(doc, el));
    const g = cache.get(el.id);
    return (p) => (g.planes.length && pointInPolygon(p, g.poly) ? g.base + roofHeightAt(g.planes, p) - floor : Infinity);
  }
  if (el.kind === 'floor' || el.kind === 'ceiling') {
    const th = Math.max(1, typeThickness(doc.get(el.typeId)) || (el.kind === 'floor' ? 300 : 20));
    const top = levelElevation(doc, el.levelId) + (+el.offset || 0);
    const bottom = el.kind === 'floor' ? top - th : top;
    return (p) => (bottom > floor + 1 && pointInPolygon(p, el.boundary) ? bottom - floor : Infinity);
  }
  return () => Infinity;
}

/**
 * The zone's volume: { volume (mm³), height (its set height), netHeight (mean
 * under what crops it), cropped } for its region (rooms.js) or null.
 */
export function roomVolume(doc, room, region) {
  const H = +room.upperOffset || 0;
  if (!region?.outer || !(H > 0)) return null;
  const area = region.area ?? Math.abs(signedArea(region.outer));
  const crops = (room.cropBy || []).map((id) => doc.get(id)).filter(Boolean);
  if (!crops.length) return { volume: area * H, height: H, netHeight: H, cropped: false };
  const floor = levelElevation(doc, room.levelId) + (+room.offset || 0);
  try {
    const exact = exactVolume(doc, crops, floor, H, region);
    if (exact) return { volume: exact, height: H, netHeight: exact / area, cropped: true };
  } catch {
    // Fall back to sampling below.
  }
  const cache = new Map();
  const over = crops.map((c) => ceilingOver(doc, c, floor, cache));
  // Sample the zone on a grid fine enough for about 4000 cells.
  const xs = region.outer.map((p) => p[0]);
  const ys = region.outer.map((p) => p[1]);
  const cell = Math.max(25, Math.sqrt(area / 4000));
  let sum = 0;
  let n = 0;
  for (let x = Math.min(...xs) + cell / 2; x < Math.max(...xs); x += cell)
    for (let y = Math.min(...ys) + cell / 2; y < Math.max(...ys); y += cell) {
      const p = [x, y];
      if (!pointInPolygon(p, region.outer) || (region.holes || []).some((h) => pointInPolygon(p, h))) continue;
      let h = H;
      for (const f of over) h = Math.min(h, f(p));
      sum += Math.max(0, h);
      n++;
    }
  const netHeight = n ? sum / n : H;
  return { volume: area * netHeight, height: H, netHeight, cropped: true };
}

/**
 * The cropped volume, exactly: the zone cut into pieces over each of which the
 * height is one linear function (a roof plane, a slab's underside, the zone's
 * own height), each piece then split where the next surface over it is lower
 * and where the height falls to zero; a linear height integrates to the
 * piece's area times its value at the centroid (summed over triangles).
 */
function exactVolume(doc, crops, floor, H, region) {
  // Height functions: [c, gx, gy] with h(p) = c + gx x + gy y.
  const at = (f, p) => f[0] + f[1] * p[0] + f[2] * p[1];
  const surfaces = [];
  for (const el of crops) {
    if (el.kind === 'roof') {
      const g = roofGeometry(doc, el);
      for (const face of g.faces) {
        const pl = face.plane;
        if (!pl) continue;
        // planeHeight(pl, p) = h + k (p - p0) . m
        const c = g.base + (pl.h || 0) - pl.k * (pl.p[0] * pl.m[0] + pl.p[1] * pl.m[1]) - floor;
        surfaces.push({ poly: face.poly, f: [c, pl.k * pl.m[0], pl.k * pl.m[1]] });
      }
    } else if (el.kind === 'floor' || el.kind === 'ceiling') {
      const th = Math.max(1, typeThickness(doc.get(el.typeId)) || (el.kind === 'floor' ? 300 : 20));
      const top = levelElevation(doc, el.levelId) + (+el.offset || 0);
      const bottom = el.kind === 'floor' ? top - th : top;
      if (bottom > floor + 1) surfaces.push({ poly: el.boundary, f: [bottom - floor, 0, 0] });
    }
  }
  const xs = region.outer.map((p) => p[0]);
  const ys = region.outer.map((p) => p[1]);
  const R = 10 * (Math.max(...xs) - Math.min(...xs) + Math.max(...ys) - Math.min(...ys) + 1000);
  const cx = (Math.max(...xs) + Math.min(...xs)) / 2;
  const cy = (Math.max(...ys) + Math.min(...ys)) / 2;
  // The half-plane where f1 - f0 <= 0, as a big polygon.
  const halfPlane = (d) => {
    const n = Math.hypot(d[1], d[2]);
    if (n < 1e-12) return d[0] <= 0 ? 'all' : 'none';
    const u = [d[1] / n, d[2] / n];
    // Point on the line d = 0 nearest the zone's centre.
    const s = -(d[0] + d[1] * cx + d[2] * cy) / n;
    const o = [cx + u[0] * s, cy + u[1] * s];
    const v = [-u[1], u[0]];
    return { boundary: [
      [o[0] + v[0] * R, o[1] + v[1] * R], [o[0] - v[0] * R, o[1] - v[1] * R],
      [o[0] - v[0] * R - u[0] * R, o[1] - v[1] * R - u[1] * R], [o[0] + v[0] * R - u[0] * R, o[1] + v[1] * R - u[1] * R],
    ].reverse(), holes: [] };
  };
  const split = (shape, d) => {
    // [where d <= 0, where d > 0]
    const hp = halfPlane(d);
    if (hp === 'all') return [[shape], []];
    if (hp === 'none') return [[], [shape]];
    return [polygonBoolean(shape, hp, 'intersect'), polygonBoolean(shape, hp, 'subtract')];
  };
  let pieces = [{ shape: { boundary: region.outer, holes: region.holes || [] }, f: [H, 0, 0] }];
  for (const sfc of surfaces) {
    const next = [];
    for (const pc of pieces) {
      const inside = polygonBoolean(pc.shape, { boundary: sfc.poly, holes: [] }, 'intersect');
      const outside = polygonBoolean(pc.shape, { boundary: sfc.poly, holes: [] }, 'subtract');
      for (const o of outside) next.push({ shape: o, f: pc.f });
      for (const i of inside) {
        // Where the surface is lower than the piece's height, it takes over.
        const [lower, higher] = split(i, [sfc.f[0] - pc.f[0], sfc.f[1] - pc.f[1], sfc.f[2] - pc.f[2]]);
        for (const l of lower) next.push({ shape: l, f: sfc.f });
        for (const h of higher) next.push({ shape: h, f: pc.f });
      }
    }
    pieces = next;
  }
  let volume = 0;
  for (const pc of pieces) {
    // Only where the height is above the floor.
    const [up] = split(pc.shape, pc.f.map((v) => -v));
    for (const sh of up) {
      const loops = [sh.boundary, ...(sh.holes || [])];
      const flat = loops.flat();
      const holeIdx = [];
      let n = sh.boundary.length;
      for (const hl of sh.holes || []) {
        holeIdx.push(n);
        n += hl.length;
      }
      const tri = earcut(flat.flat(), holeIdx);
      for (let i = 0; i < tri.length; i += 3) {
        const [a, b, c] = [flat[tri[i]], flat[tri[i + 1]], flat[tri[i + 2]]];
        const area = Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) / 2;
        volume += area * Math.max(0, at(pc.f, [(a[0] + b[0] + c[0]) / 3, (a[1] + b[1] + c[1]) / 3]));
      }
    }
  }
  return volume;
}

/** The roofs over a zone that crop it: those whose underside comes down into the zone's height somewhere over it. */
export function croppersOver(doc, room, region) {
  if (!region?.outer) return [];
  const floor = levelElevation(doc, room.levelId) + (+room.offset || 0);
  const top = floor + (+room.upperOffset || 3000);
  const pts = region.outer;
  const out = [];
  const cache = new Map();
  for (const el of doc.all('roof')) {
    const f = ceilingOver(doc, el, floor, cache);
    if (pts.some((p) => f(p) < top - floor) || f(pts.reduce((s, p) => [s[0] + p[0] / pts.length, s[1] + p[1] / pts.length], [0, 0])) < top - floor) out.push(el.id);
  }
  return out;
}
