/**
 * GDL's CUTPLANE ... CUTEND: what a script makes in between is cut by a plane, the part on one side removed, and
 * the bodies closed again where the plane cut them. A cut is { n, d } in placed coordinates (removed where n · p > d)
 * with the segments its plane cut, from which CUTEND makes the closing polygons.
 */
import earcut from 'earcut';
import { makePolygon, subtract, insidePolygons } from './csg.js';

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];

/**
 * The plane of a CUTPLANE's arguments (status already taken off), in the script's local coordinates: three points
 * on it and a point on the side removed. No arguments: the x-y plane; one: through the x axis at that angle (degrees)
 * to the x-y plane; two: through (x, 0, 0) and (0, y, 0), upright; three: through (x, 0, 0), (0, y, 0) and
 * (0, 0, z) (a zero is the origin: 1, 1, 0 is the x-y plane). A fourth is the side: 0 removes what is above
 * (towards +z for the x-y plane, away from the origin for planes off it), 1 what is below.
 */
export function cutPlaneLocal(args) {
  const [x, y, z, side] = args.map((v) => +v || 0);
  let pts;
  let up;
  if (!args.length || (args.length === 1 && !x)) {
    pts = [[0, 0, 0], [1, 0, 0], [0, 1, 0]];
    up = [0, 0, 1];
  } else if (args.length === 1) {
    const a = (x * Math.PI) / 180;
    // The x-y plane turned about the x axis by the angle: "above" turns with it.
    pts = [[0, 0, 0], [1, 0, 0], [0, Math.cos(a), Math.sin(a)]];
    up = [0, -Math.sin(a), Math.cos(a)];
  } else {
    const px = [x, 0, 0];
    const py = [0, y, 0];
    const third = args.length >= 3 ? [0, 0, z] : [x, 0, 1];
    pts = [px, py, third];
    up = args.length >= 3 ? cross(sub(py, px), sub(third, px)) : cross(sub(py, px), [0, 0, 1]);
    if (dot(up, up) < 1e-24) return null;
  }
  if (args.length >= 4 && Math.round(side) === 1) up = up.map((v) => -v);
  const o = pts[0];
  return { pts, away: [o[0] + up[0], o[1] + up[1], o[2] + up[2]] };
}

/** The cut placed: P turns local points into placed ones. Null for a degenerate plane. */
export function placeCut(local, P, status = 0) {
  if (!local) return null;
  const [a, b, c] = local.pts.map(P);
  let n = cross(sub(b, a), sub(c, a));
  const l = Math.hypot(...n);
  if (l < 1e-18) return null;
  n = n.map((v) => v / l);
  if (dot(n, sub(P(local.away), a)) < 0) n = n.map((v) => -v);
  return { n, d: dot(n, a), segs: [], looks: [], status };
}

/**
 * A triangle t ({ a, b, c, uv? }) cut by the planes: the triangles of what is left (copies of t), and for each
 * plane the segment it cut (with t's look) for the closing polygon.
 */
export function cutTriangle(t, cuts) {
  let poly = [t.a, t.b, t.c];
  let uvs = t.uv ? t.uv.slice() : null;
  for (const c of cuts) {
    if (!c.n) continue;
    const s = poly.map((p) => dot(c.n, p) - c.d);
    const eps = 1e-9 * (1 + Math.abs(c.d));
    if (s.every((v) => v <= eps)) continue;
    if (s.every((v) => v >= -eps)) return [];
    const out = [];
    const ouv = uvs ? [] : null;
    const hits = [];
    for (let i = 0; i < poly.length; i++) {
      const j = (i + 1) % poly.length;
      const [p, q] = [poly[i], poly[j]];
      const [sp, sq] = [s[i], s[j]];
      if (sp <= eps) {
        out.push(p);
        if (ouv) ouv.push(uvs[i]);
      }
      if ((sp < -eps && sq > eps) || (sp > eps && sq < -eps)) {
        const k = sp / (sp - sq);
        const x = [p[0] + (q[0] - p[0]) * k, p[1] + (q[1] - p[1]) * k, p[2] + (q[2] - p[2]) * k];
        out.push(x);
        hits.push(x);
        if (ouv) ouv.push([uvs[i][0] + (uvs[j][0] - uvs[i][0]) * k, uvs[i][1] + (uvs[j][1] - uvs[i][1]) * k]);
      } else if (Math.abs(sp) <= eps && hits.length < 2) hits.push(p);
    }
    if (hits.length >= 2) {
      c.segs.push([hits[0], hits[hits.length - 1]]);
      c.looks.push(t);
    }
    if (out.length < 3) return [];
    poly = out;
    uvs = ouv;
  }
  if (poly.length === 3 && poly[0] === t.a && poly[1] === t.b && poly[2] === t.c) return [t];
  const res = [];
  for (let i = 1; i + 1 < poly.length; i++) res.push({ ...t, a: poly[0], b: poly[i], c: poly[i + 1], ...(uvs ? { uv: [uvs[0], uvs[i], uvs[i + 1]] } : {}) });
  return res;
}

/** An edge [p, q] cut by the planes: what is left of it, or null. */
export function cutEdge(e, cuts) {
  let [p, q] = e;
  for (const c of cuts) {
    if (!c.n) continue;
    const sp = dot(c.n, p) - c.d;
    const sq = dot(c.n, q) - c.d;
    const eps = 1e-9 * (1 + Math.abs(c.d));
    if (sp > eps && sq > eps) return null;
    if (sp <= eps && sq <= eps) continue;
    const k = sp / (sp - sq);
    const x = [p[0] + (q[0] - p[0]) * k, p[1] + (q[1] - p[1]) * k, p[2] + (q[2] - p[2]) * k];
    if (sp > eps) p = x;
    else q = x;
  }
  return [p, q];
}

/**
 * The polygons that close the bodies a plane cut: its segments joined into loops (ends that meet), loops inside
 * others as their holes, triangulated in the plane. → { tris: [{ a, b, c, look }], edges: [[p, q]] }.
 */
export function capCut(c) {
  const out = { tris: [], edges: [] };
  if (c.segs.length < 3) return out;
  // Ends matched by position, to a tolerance relative to the size of the cut.
  let span = 0;
  for (const [p, q] of c.segs) span = Math.max(span, Math.abs(p[0]) + Math.abs(p[1]) + Math.abs(p[2]), Math.abs(q[0]) + Math.abs(q[1]) + Math.abs(q[2]));
  const tol = Math.max(1e-9, span * 1e-7);
  const key = (p) => `${Math.round(p[0] / tol)},${Math.round(p[1] / tol)},${Math.round(p[2] / tol)}`;
  const at = new Map();
  c.segs.forEach((s, i) => {
    for (const end of [0, 1]) {
      const k = key(s[end]);
      if (!at.has(k)) at.set(k, []);
      at.get(k).push([i, end]);
    }
  });
  const used = new Uint8Array(c.segs.length);
  const loops = [];
  for (let i = 0; i < c.segs.length; i++) {
    if (used[i]) continue;
    used[i] = 1;
    const loop = [c.segs[i][0], c.segs[i][1]];
    const look = c.looks[i];
    const startKey = key(loop[0]);
    let closed = false;
    for (let guard = 0; guard < c.segs.length; guard++) {
      const k = key(loop[loop.length - 1]);
      if (k === startKey && loop.length > 2) {
        loop.pop();
        closed = true;
        break;
      }
      const next = (at.get(k) || []).find(([j]) => !used[j]);
      if (!next) break;
      used[next[0]] = 1;
      loop.push(c.segs[next[0]][1 - next[1]]);
    }
    if (closed && loop.length >= 3) loops.push({ pts: loop, look });
  }
  if (!loops.length) return out;
  // The plane's own axes.
  const n = c.n;
  const u0 = Math.abs(n[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0];
  let u = cross(n, u0);
  const lu = Math.hypot(...u);
  u = u.map((v) => v / lu);
  const v = cross(n, u);
  const flat = (p) => [dot(p, u), dot(p, v)];
  for (const L of loops) L.f = L.pts.map(flat);
  const inside = (p, f) => {
    let w = false;
    for (let i = 0, j = f.length - 1; i < f.length; j = i++) {
      if (f[i][1] > p[1] !== f[j][1] > p[1] && p[0] < ((f[j][0] - f[i][0]) * (p[1] - f[i][1])) / (f[j][1] - f[i][1]) + f[i][0]) w = !w;
    }
    return w;
  };
  // Loops inside an odd number of others are holes, of the smallest one around them.
  for (const L of loops) {
    L.depth = loops.filter((M) => M !== L && inside(L.f[0], M.f)).length;
  }
  for (const L of loops.filter((x) => x.depth % 2 === 0)) {
    const holes = loops.filter((H) => H.depth === L.depth + 1 && inside(H.f[0], L.f));
    const all = [L, ...holes];
    const coords = [];
    const starts = [];
    const pts = [];
    for (const H of all) {
      if (H !== L) starts.push(pts.length);
      for (let i = 0; i < H.f.length; i++) {
        coords.push(H.f[i][0], H.f[i][1]);
        pts.push(H.pts[i]);
      }
    }
    const ids = earcut(coords, starts.length ? starts : null, 2);
    for (let i = 0; i < ids.length; i += 3) out.tris.push({ a: pts[ids[i]], b: pts[ids[i + 1]], c: pts[ids[i + 2]], look: L.look });
  }
  for (const L of loops) for (let i = 0; i < L.pts.length; i++) out.edges.push([L.pts[i], L.pts[(i + 1) % L.pts.length]]);
  return out;
}

/**
 * A cutting body of CUTPOLY, CUTPOLYA and CUTFORM: the polygon (local x-y points) swept along dir (local) from t0 to
 * t1 (local lengths along dir; Infinity for as far as needed), or towards an apex, placed by P. → closed solid as
 * triangles [[p, q, r], ...] in placed coordinates, faces outwards; `far` is how far "infinite" reaches.
 */
export function cutBody(poly, { dir = [0, 0, 1], t0 = -Infinity, t1 = Infinity, apex = null }, P, far) {
  if (poly.length < 3) return null;
  // Anticlockwise, so that sides and caps face out together.
  let area = 0;
  for (let i = 0; i < poly.length; i++) {
    const [p, q] = [poly[i], poly[(i + 1) % poly.length]];
    area += p[0] * q[1] - q[0] * p[1];
  }
  if (Math.abs(area) < 1e-18) return null;
  const pts = (area > 0 ? poly : poly.slice().reverse()).map((q) => [q[0], q[1], 0]);
  let lower;
  let upper;
  if (apex) {
    // A pyramid from the apex through the polygon, on beyond it.
    const k = Number.isFinite(t1) ? 1 : null;
    lower = pts.map(() => P(apex));
    upper = pts.map((q) => {
      const a = P(apex);
      const b = P(q);
      const d = sub(b, a);
      const len = Math.hypot(...d) || 1;
      const s = k ?? (far / len + 1);
      return [a[0] + d[0] * s, a[1] + d[1] * s, a[2] + d[2] * s];
    });
  } else {
    const dl = Math.hypot(...dir) || 1;
    const u = dir.map((v) => v / dl);
    const at = (q, t) => {
      if (Number.isFinite(t)) return P([q[0] + u[0] * t, q[1] + u[1] * t, q[2] + u[2] * t]);
      // As far as needed in placed coordinates.
      const a = P(q);
      const b = P([q[0] + u[0], q[1] + u[1], q[2] + u[2]]);
      const d = sub(b, a);
      const l = Math.hypot(...d) || 1;
      const s = (Math.sign(t) * far) / l;
      return [a[0] + d[0] * s, a[1] + d[1] * s, a[2] + d[2] * s];
    };
    lower = pts.map((q) => at(q, t0));
    upper = pts.map((q) => at(q, t1));
  }
  const tris = [];
  const flat = pts.flatMap((q) => [q[0], q[1]]);
  const ids = earcut(flat);
  for (let i = 0; i < ids.length; i += 3) {
    let [a, b, c] = [ids[i], ids[i + 1], ids[i + 2]];
    const ccw = (pts[b][0] - pts[a][0]) * (pts[c][1] - pts[a][1]) - (pts[c][0] - pts[a][0]) * (pts[b][1] - pts[a][1]);
    if (ccw < 0) [b, c] = [c, b];
    if (!apex) tris.push([lower[a], lower[c], lower[b]]);
    tris.push([upper[a], upper[b], upper[c]]);
  }
  for (let i = 0; i < pts.length; i++) {
    const j = (i + 1) % pts.length;
    if (apex) tris.push([lower[i], upper[j], upper[i]]);
    else {
      tris.push([lower[i], lower[j], upper[j]]);
      tris.push([lower[i], upper[j], upper[i]]);
    }
  }
  // Outwards: a positive volume.
  let vol = 0;
  for (const [a, b, c] of tris) vol += dot(a, cross(b, c));
  if (Math.abs(vol) < 1e-30) return null;
  const out = vol > 0 ? tris : tris.map(([a, b, c]) => [a, c, b]);
  // Convex when every turn of the polygon goes the same way.
  out.convex = pts.every((p, i) => {
    const q = pts[(i + 1) % pts.length];
    const r = pts[(i + 2) % pts.length];
    return (q[0] - p[0]) * (r[1] - q[1]) - (q[1] - p[1]) * (r[0] - q[0]) >= -1e-12;
  });
  return out;
}

/** A convex body's faces as planes { n, d } (outwards), one per distinct plane. */
function bodyPlanes(body) {
  const planes = [];
  for (const [a, b, c] of body) {
    let n = cross(sub(b, a), sub(c, a));
    const l = Math.hypot(...n);
    if (l < 1e-18) continue;
    n = n.map((v) => v / l);
    const d = dot(n, a);
    if (!planes.some((q) => dot(q.n, n) > 1 - 1e-9 && Math.abs(q.d - d) < 1e-9 * (1 + Math.abs(d)))) planes.push({ n, d });
  }
  return planes;
}

/** Split a polygon (points, uvs) by a plane: the part in front (n · p > d) and the part behind. */
function splitPoly(poly, uvs, pl) {
  const s = poly.map((p) => dot(pl.n, p) - pl.d);
  const eps = 1e-10 * (1 + Math.abs(pl.d));
  // Lying on the face: on the body's surface, so with what is inside it.
  if (s.every((v) => Math.abs(v) <= eps)) return [{ pts: [], uvs: null }, { pts: poly, uvs }];
  const f = { pts: [], uvs: uvs ? [] : null };
  const b = { pts: [], uvs: uvs ? [] : null };
  for (let i = 0; i < poly.length; i++) {
    const j = (i + 1) % poly.length;
    if (s[i] >= -eps) {
      f.pts.push(poly[i]);
      if (uvs) f.uvs.push(uvs[i]);
    }
    if (s[i] <= eps) {
      b.pts.push(poly[i]);
      if (uvs) b.uvs.push(uvs[i]);
    }
    if ((s[i] < -eps && s[j] > eps) || (s[i] > eps && s[j] < -eps)) {
      const k = s[i] / (s[i] - s[j]);
      const x = [0, 1, 2].map((m) => poly[i][m] + (poly[j][m] - poly[i][m]) * k);
      f.pts.push(x);
      b.pts.push(x);
      if (uvs) {
        const u = [uvs[i][0] + (uvs[j][0] - uvs[i][0]) * k, uvs[i][1] + (uvs[j][1] - uvs[i][1]) * k];
        f.uvs.push(u);
        b.uvs.push(u);
      }
    }
  }
  return [f, b];
}


/**
 * Triangles (GDL's { a, b, c, uv?, look }) less a cutting body: what was inside it removed and the bodies closed
 * along its faces, in capLook. Worked in millimetres, the tolerance the solid operations use.
 */
export function subtractBody(tris, body, capLook) {
  const S = 1000;
  // Only triangles that reach the body's box go through the solid operation; the rest stay as they are.
  const lo = [Infinity, Infinity, Infinity];
  const hi = [-Infinity, -Infinity, -Infinity];
  for (const f of body)
    for (const p of f)
      for (let k = 0; k < 3; k++) {
        if (p[k] < lo[k]) lo[k] = p[k];
        if (p[k] > hi[k]) hi[k] = p[k];
      }
  const eps = 1e-6;
  const near = (t) => [0, 1, 2].every((k) => Math.max(t.a[k], t.b[k], t.c[k]) >= lo[k] - eps && Math.min(t.a[k], t.b[k], t.c[k]) <= hi[k] + eps);
  const keep = [];
  const work = [];
  for (const t of tris) (near(t) ? work : keep).push(t);
  if (!work.length) return tris;
  if (body.convex) return keep.concat(subtractConvex(work, body, capLook));
  tris = work;
  const A = [];
  tris.forEach((t, i) => {
    const uv = t.uv || [[0, 0], [0, 0], [0, 0]];
    const poly = makePolygon([t.a, t.b, t.c].map((p, k) => ({ p: [p[0] * S, p[1] * S, p[2] * S], c: [uv[k][0], uv[k][1], 0, 0] })), i);
    if (poly) A.push(poly);
  });
  const B = body.map((f) => makePolygon(f.map((p) => ({ p: [p[0] * S, p[1] * S, p[2] * S], c: [0, 0, 0, 0] })), -1)).filter(Boolean);
  if (!A.length || !B.length) return keep.concat(tris);
  const out = keep;
  const [blo, bhi] = boxOf(tris);
  for (const poly of subtract(A, B)) {
    const own = poly.part >= 0;
    if (!own && !clipToBox(poly.vs.map((v) => v.p.map((x) => x / S)), blo, bhi)) continue;
    const src = own ? tris[poly.part] : capLook || tris[0];
    const { a: _a, b: _b, c: _c, uv, ...look } = src;
    if (!own) delete look.tex;
    for (let i = 1; i + 1 < poly.vs.length; i++) {
      const vs = [poly.vs[0], poly.vs[i], poly.vs[i + 1]];
      const t = { ...look, a: vs[0].p.map((v) => v / S), b: vs[1].p.map((v) => v / S), c: vs[2].p.map((v) => v / S) };
      if (own && uv) t.uv = vs.map((v) => [v.c[0], v.c[1]]);
      out.push(t);
    }
  }
  return out;
}

/** Whether p is inside a closed body (triangles), by the parity of crossings along a ray. */
function insideBody(p, body) {
  const d = [0.5773, 0.5774, 0.5775];
  let n = 0;
  for (const [a, b, c] of body) {
    const e1 = sub(b, a);
    const e2 = sub(c, a);
    const h = cross(d, e2);
    const det = dot(e1, h);
    if (Math.abs(det) < 1e-18) continue;
    const s = sub(p, a);
    const u = dot(s, h) / det;
    if (u < 0 || u > 1) continue;
    const q = cross(s, e1);
    const v = dot(d, q) / det;
    if (v < 0 || u + v > 1) continue;
    if (dot(e2, q) / det > 0) n++;
  }
  return n % 2 === 1;
}

/** An edge less a cutting body: its pieces outside it. */
export function edgeOutsideBody([p, q], body) {
  const ts = [0, 1];
  const d = sub(q, p);
  for (const [a, b, c] of body) {
    const n = cross(sub(b, a), sub(c, a));
    const den = dot(n, d);
    if (Math.abs(den) < 1e-18) continue;
    const t = dot(n, sub(a, p)) / den;
    if (t > 1e-9 && t < 1 - 1e-9) ts.push(t);
  }
  ts.sort((x, y) => x - y);
  const at = (t) => [p[0] + d[0] * t, p[1] + d[1] * t, p[2] + d[2] * t];
  const out = [];
  for (let i = 0; i + 1 < ts.length; i++) {
    if (ts[i + 1] - ts[i] < 1e-9) continue;
    if (!insideBody(at((ts[i] + ts[i + 1]) / 2), body)) out.push([at(ts[i]), at(ts[i + 1])]);
  }
  return out;
}


/** A polygon (placed points) clipped to a box: what of it lies inside, or null. */
function clipToBox(pts, lo, hi) {
  let poly = pts;
  for (let k = 0; k < 3; k++)
    for (const [sign, lim] of [[1, hi[k]], [-1, lo[k]]]) {
      const n = [0, 0, 0];
      n[k] = sign;
      const [, b] = splitPoly(poly, null, { n, d: sign * lim });
      poly = b.pts;
      if (poly.length < 3) return null;
    }
  return poly;
}

/** The box of triangles, a little larger. */
function boxOf(tris) {
  const lo = [Infinity, Infinity, Infinity];
  const hi = [-Infinity, -Infinity, -Infinity];
  for (const t of tris)
    for (const p of [t.a, t.b, t.c])
      for (let k = 0; k < 3; k++) {
        if (p[k] < lo[k]) lo[k] = p[k];
        if (p[k] > hi[k]) hi[k] = p[k];
      }
  const e = 1e-6 + 1e-6 * Math.max(...[0, 1, 2].map((k) => hi[k] - lo[k]));
  return [lo.map((v) => v - e), hi.map((v) => v + e)];
}

/** Triangles less a convex body: each cut by its planes, what is outside kept; the faces closing them from the body. */
function subtractConvex(tris, body, capLook) {
  const planes = bodyPlanes(body);
  const out = [];
  const S = 1000;
  let cut = false;
  for (const t of tris) {
    let rest = { pts: [t.a, t.b, t.c], uvs: t.uv ? t.uv.slice() : null };
    const pieces = [];
    let inside = true;
    for (const pl of planes) {
      const [f, b] = splitPoly(rest.pts, rest.uvs, pl);
      if (b.pts.length < 3) {
        // Wholly in front of this face: outside the body.
        inside = false;
        pieces.push(rest);
        break;
      }
      if (f.pts.length >= 3) pieces.push(f);
      rest = b;
    }
    if (!inside && pieces.length === 1 && pieces[0].pts.length === 3 && pieces[0].pts[0] === t.a && pieces[0].pts[1] === t.b && pieces[0].pts[2] === t.c) {
      out.push(t);
      continue;
    }
    cut = true;
    for (const pc of pieces)
      for (let i = 1; i + 1 < pc.pts.length; i++) {
        const x = { ...t, a: pc.pts[0], b: pc.pts[i], c: pc.pts[i + 1] };
        if (pc.uvs) x.uv = [pc.uvs[0], pc.uvs[i], pc.uvs[i + 1]];
        out.push(x);
      }
  }
  if (!cut) return out;
  // The new faces: the body's own, where they are inside the solids that were cut.
  const A = [];
  for (const t of tris) {
    const poly = makePolygon([t.a, t.b, t.c].map((p) => ({ p: [p[0] * S, p[1] * S, p[2] * S], c: [0, 0, 0, 0] })), 0);
    if (poly) A.push(poly);
  }
  const B = body.map((f) => makePolygon(f.map((p) => ({ p: [p[0] * S, p[1] * S, p[2] * S], c: [0, 0, 0, 0] })), -1)).filter(Boolean);
  const { a: _a, b: _b, c: _c, uv: _uv, tex: _tex, ...look } = capLook || tris[0];
  // Within what was cut: where it is not a closed solid, its "inside" is not to be trusted beyond it.
  const [lo, hi] = boxOf(tris);
  for (const poly of insidePolygons(A, B)) {
    const pts = clipToBox(poly.vs.map((v) => v.p.map((x) => x / S)), lo, hi);
    if (pts) for (let i = 1; i + 1 < pts.length; i++) out.push({ ...look, a: pts[0], b: pts[i], c: pts[i + 1] });
  }
  return out;
}
