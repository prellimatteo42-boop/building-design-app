/**
 * Energy evaluation: the design heat loss of each room (Archicad's zones)
 * through its envelope and by ventilation, a steady-state estimate in the
 * spirit of EN 12831:
 *   - exterior walls (type function 'exterior') along the room's boundary,
 *     with their U from the building materials (materials.js), less the
 *     doors and windows in that stretch, which count with their own U;
 *   - the roof over a room with no slab between them, the floor of the
 *     lowest story (with a ground reduction factor);
 *   - ventilation 0.34 · n · V (W/K, n air changes an hour, V in m³);
 *   - load = (H_T + H_V) · (θi − θe).
 * Structures without thermal data count with fallback U values, and the
 * room says so. Curved walls are not counted yet.
 */
import { thermalProperties } from './materials.js';
import { openingSize, levelElevation } from './model.js';
import { axisParam } from './walls.js';
import { dot, sub, len, norm, pointInPolygon } from './geom.js';
import { roofGeometry } from './build3d.js';

export const ENERGY_DEFAULTS = { inside: 20, outside: -5, ach: 0.5, groundFactor: 0.5 };
const FALLBACK = { wall: 1.0, roof: 0.8, floor: 0.8, window: 1.4, door: 1.8 };

const uOf = (doc, type, kind, notes) => {
  const u = thermalProperties(doc, type)?.u;
  if (u) return u;
  notes.add(`${type?.name || kind}: no thermal data, U ${FALLBACK[kind]} assumed`);
  return FALLBACK[kind];
};

/** Length along segment p-q that lies on the face from a to b (both on one line within tol). */
function overlapOnFace(p, q, a, b, tol = 3) {
  const d = sub(b, a);
  const L = len(d);
  if (L < 1) return null;
  const u = norm(d);
  const off = (x) => Math.abs(u[0] * (x[1] - a[1]) - u[1] * (x[0] - a[0]));
  if (off(p) > tol || off(q) > tol) return null;
  const s0 = dot(sub(p, a), u);
  const s1 = dot(sub(q, a), u);
  const lo = Math.max(0, Math.min(s0, s1));
  const hi = Math.min(L, Math.max(s0, s1));
  return hi - lo > 1 ? { lo, hi } : null;
}

/**
 * Heat loss of every enclosed room: [{ room, area (m²), volume (m³),
 * walls, windows, roof, floor (m² each), HT, HV (W/K), load (W), perArea
 * (W/m²), notes }], and the building totals.
 */
export function energyReport(doc, scene, opts = {}) {
  const o = { ...ENERGY_DEFAULTS, ...doc.get('project')?.energy, ...opts };
  // U-values set by hand in the Energy Model Review, by element id.
  const own = o.uOverrides || {};
  const uFor = (id, u) => (Number.isFinite(+own[id]) && own[id] !== null && own[id] !== '' ? +own[id] : u);
  const dT = o.inside - o.outside;
  const levels = doc.levels();
  const rows = [];
  for (const room of doc.all('room')) {
    const region = scene.rooms.room(room);
    if (!region) continue;
    const notes = new Set();
    const z0 = levelElevation(doc, room.levelId);
    const above = doc.levelAbove(room.levelId);
    const height = +room.upperOffset || (above ? above.elevation - z0 : 2700);
    const area = region.area / 1e6;
    const volume = area * (height / 1000);
    let HT = 0;
    let walls = 0;
    let windows = 0;
    // Exterior walls along the room's boundary.
    const solved = scene.walls.level(room.levelId);
    const outer = region.outer;
    // Envelope parts with their facing (compass azimuth of the outward normal), for solar gains.
    const faces = [];
    let signed = 0;
    for (let i = 0; i < outer.length; i++) signed += outer[i][0] * outer[(i + 1) % outer.length][1] - outer[(i + 1) % outer.length][0] * outer[i][1];
    const north = ((+doc.get('project')?.trueNorth || 0) * Math.PI) / 180;
    const facing = (p, q) => {
      const d = norm(sub(q, p));
      const n = signed > 0 ? [d[1], -d[0]] : [-d[1], d[0]];
      // Model +Y is true north turned counterclockwise by the north angle.
      const x = n[0] * Math.cos(north) + n[1] * Math.sin(north);
      const y = -n[0] * Math.sin(north) + n[1] * Math.cos(north);
      return ((Math.atan2(x, y) * 180) / Math.PI + 360) % 360;
    };
    for (const g of solved.walls.values()) {
      const type = doc.get(g.wall.typeId);
      if (type?.function !== 'exterior' || g.axis.curve) continue;
      for (let i = 0; i < outer.length; i++) {
        const p = outer[i];
        const q = outer[(i + 1) % outer.length];
        const hit = overlapOnFace(p, q, g.L0, g.L1) || overlapOnFace(p, q, g.R0, g.R1);
        if (!hit) continue;
        const gross = ((hit.hi - hit.lo) * height) / 1e6;
        let open = 0;
        // Doors and windows of the wall in that stretch.
        const u0 = Math.min(axisParam(g.axis, p), axisParam(g.axis, q));
        const u1 = Math.max(axisParam(g.axis, p), axisParam(g.axis, q));
        for (const h of doc.all('door', 'window')) {
          if (h.hostId !== g.wall.id || h.t < u0 || h.t > u1) continue;
          const { width, height: oh } = openingSize(doc, h);
          const a = (width * oh) / 1e6;
          const ht = doc.get(h.typeId);
          const ut = uFor(h.id, +ht?.uValue || FALLBACK[h.kind]);
          HT += ut * a;
          open += a;
          windows += a;
          faces.push({ kind: h.kind, id: h.id, name: ht?.name || h.kind, area: a, u: ut, azimuth: facing(p, q), g: h.kind === 'window' ? +(ht?.gValue ?? ht?.g ?? 0.6) : 0 });
        }
        const net = Math.max(0, gross - open);
        const uw = uFor(g.wall.id, own[g.wall.id] != null ? 0 : uOf(doc, type, 'wall', notes));
        HT += uw * net;
        walls += net;
        faces.push({ kind: 'wall', id: g.wall.id, name: type?.name || 'Wall', area: net, u: uw, azimuth: facing(p, q) });
      }
    }
    // Roof over the top story, floor of the lowest one.
    let roof = 0;
    let floor = 0;
    const c = room.at;
    // The roof over the room, when no slab lies between them.
    const r = doc.all('roof').find((x) => x.boundary?.length && roofGeometry(doc, x).base >= z0 && pointInPolygon(c, roofGeometry(doc, x).poly));
    if (r) {
      const zr = roofGeometry(doc, r).base;
      const slab = doc.all('floor').some((f) => {
        const zf = levelElevation(doc, f.levelId) + (+f.offset || 0);
        return zf > z0 + 1 && zf <= zr + 1 && f.boundary?.length && pointInPolygon(c, f.boundary);
      });
      if (!slab) {
        roof = area;
        const ur = uFor(r.id, own[r.id] != null ? 0 : uOf(doc, doc.get(r.typeId), 'roof', notes));
        HT += ur * area;
        faces.push({ kind: 'roof', id: r.id, name: doc.get(r.typeId)?.name || 'Roof', area, u: ur, azimuth: null });
      }
    }
    if (levels[0]?.id === room.levelId) {
      const f = doc.all('floor').find((x) => x.levelId === room.levelId && x.boundary?.length && pointInPolygon(c, x.boundary));
      if (f) {
        floor = area;
        const uf = uFor(f.id, own[f.id] != null ? 0 : uOf(doc, doc.get(f.typeId), 'floor', notes));
        HT += uf * area * o.groundFactor;
        faces.push({ kind: 'floor', id: f.id, name: doc.get(f.typeId)?.name || 'Floor', area, u: uf, azimuth: null, factor: o.groundFactor });
      }
    }
    const HV = 0.34 * o.ach * volume;
    const load = (HT + HV) * dT;
    rows.push({ room, area, volume, walls, windows, roof, floor, HT, HV, load, perArea: area ? load / area : 0, notes: [...notes], faces });
  }
  const sum = (k) => rows.reduce((s, r) => s + r[k], 0);
  const totals = { area: sum('area'), volume: sum('volume'), HT: sum('HT'), HV: sum('HV'), load: sum('load') };
  totals.perArea = totals.area ? totals.load / totals.area : 0;
  return { rows, totals, settings: o };
}
