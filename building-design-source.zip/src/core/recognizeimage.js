/**
 * Model recognition from a picture of a floor plan (a scan, a photo of a
 * printed plan, an exported image): walls are the plan's thick dark
 * strokes, found from how far each dark run reaches across and along; their
 * outlines go through the same pairing as cut fills from a PDF, doors and
 * windows are read in the gaps from the pixels (a swing arc beside the gap,
 * glass lines along it), and rooms are the floor flooded between the walls.
 * Pixel coordinates (y down) become model millimetres through toModel.
 */
import { wallsFromFaces } from './convert.js';
import { bridgeOpenings, closingWalls, cornerDoors, mainBuilding, withoutEmbeddedStubs } from './recognize.js';
import { simplify } from './flood.js';
import { dist, sub, signedArea } from './geom.js';

/** Otsu's threshold of a grey picture (0 black .. 255 white). */
export function otsu(gray) {
  const hist = new Float64Array(256);
  for (let i = 0; i < gray.length; i++) hist[gray[i]]++;
  const total = gray.length;
  let sum = 0;
  for (let t = 0; t < 256; t++) sum += t * hist[t];
  let sumB = 0;
  let wB = 0;
  let best = 0;
  let level = 128;
  for (let t = 0; t < 256; t++) {
    wB += hist[t];
    if (!wB) continue;
    const wF = total - wB;
    if (!wF) break;
    sumB += t * hist[t];
    const mB = sumB / wB;
    const mF = (sum - sumB) / wF;
    const between = wB * wF * (mB - mF) ** 2;
    if (between > best) (best = between), (level = t);
  }
  return level;
}

/**
 * The cells of the picture that are walls: dark, and as thick as a wall
 * (tMin..tMax pixels) at least one way. Thin lines (furniture, dimensions,
 * text) are left out. Returns a Uint8Array mask (1 = wall).
 */
export function wallMask({ gray, w, h }, { tMin, tMax, level = otsu(gray) }) {
  const dark = new Uint8Array(w * h);
  for (let i = 0; i < w * h; i++) dark[i] = gray[i] <= level ? 1 : 0;
  // Grey fills (columns, a wall drawn in a lighter or hatched poche): solid and a shade off
  // the paper, the commonest light grey.
  const hist = new Uint32Array(256);
  for (let i = 0; i < w * h; i++) hist[gray[i]]++;
  let paper = 255;
  for (let t = 255; t > level; t--) if (hist[t] > hist[paper]) paper = t;
  const greyLevel = Math.max(level, paper - 12);
  const grey = new Uint8Array(w * h);
  for (let y = 1; y < h - 1; y++)
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      grey[i] = !dark[i] && gray[i] <= greyLevel && gray[i - 1] <= greyLevel && gray[i + 1] <= greyLevel && gray[i - w] <= greyLevel && gray[i + w] <= greyLevel ? 1 : 0;
    }
  const thick = (on, top = tMax) => {
    const hRun = new Uint16Array(w * h);
    const vRun = new Uint16Array(w * h);
    for (let y = 0; y < h; y++) {
      let x = 0;
      while (x < w) {
        if (!on[y * w + x]) {
          x++;
          continue;
        }
        let e = x;
        while (e < w && on[y * w + e]) e++;
        const n = Math.min(65535, e - x);
        for (let k = x; k < e; k++) hRun[y * w + k] = n;
        x = e;
      }
    }
    for (let x = 0; x < w; x++) {
      let y = 0;
      while (y < h) {
        if (!on[y * w + x]) {
          y++;
          continue;
        }
        let e = y;
        while (e < h && on[e * w + x]) e++;
        const n = Math.min(65535, e - y);
        for (let k = y; k < e; k++) vRun[k * w + x] = n;
        y = e;
      }
    }
    const test = (i) => {
      const a = Math.min(hRun[i], vRun[i]);
      return a >= tMin && a <= top;
    };
    test.across = (i) => Math.min(hRun[i], vRun[i]);
    return test;
  };
  const darkWall = thick(dark);
  // A grey block a little wider than a wall is a shaft or a column, still not floor.
  const greyWall = thick(grey, 1.4 * tMax);
  const mask = new Uint8Array(w * h);
  // A wall: thick across, at least that long along (corners and columns are thick both ways).
  for (let i = 0; i < w * h; i++) if ((dark[i] && darkWall(i)) || (grey[i] && greyWall(i))) mask[i] = 1;
  // ... and at least as long along as it is thick across: where two thin lines cross (a dimension line and its
  // tick), one is as long across as the other is, but only for the other's width.
  {
    const across = (i) => (dark[i] ? darkWall.across(i) : greyWall.across(i));
    const runH = new Uint16Array(w * h);
    const runV = new Uint16Array(w * h);
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; ) {
        if (!mask[y * w + x]) {
          x++;
          continue;
        }
        let e = x;
        while (e < w && mask[y * w + e]) e++;
        for (let k = x; k < e; k++) runH[y * w + k] = Math.min(65535, e - x);
        x = e;
      }
    for (let x = 0; x < w; x++)
      for (let y = 0; y < h; ) {
        if (!mask[y * w + x]) {
          y++;
          continue;
        }
        let e = y;
        while (e < h && mask[e * w + x]) e++;
        for (let k = y; k < e; k++) runV[k * w + x] = Math.min(65535, e - y);
        y = e;
      }
    for (let i = 0; i < w * h; i++) if (mask[i] && Math.max(runH[i], runV[i]) < 0.8 * across(i)) mask[i] = 0;
  }
  // A thin line drawn across a wall makes its run long both ways there: fill such dark cells
  // that have wall within two cells on both sides, so the wall has no hole along the line.
  const on = (x, y) => x >= 0 && y >= 0 && x < w && y < h && mask[y * w + x] === 1;
  const fill = [];
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      if (mask[i] || !dark[i]) continue;
      if (((on(x - 1, y) || on(x - 2, y)) && (on(x + 1, y) || on(x + 2, y))) || ((on(x, y - 1) || on(x, y - 2)) && (on(x, y + 1) || on(x, y + 2)))) fill.push(i);
    }
  for (const i of fill) mask[i] = 1;
  // Clean single stray cells.
  for (let y = 1; y < h - 1; y++)
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      if (mask[i] && mask[i - 1] + mask[i + 1] + mask[i - w] + mask[i + w] <= 1) mask[i] = 0;
    }
  return { mask, dark };
}

/** Every boundary loop (pixel corners) of a mask, simplified to tol pixels. */
export function maskLoops(mask, w, h, tol = 1) {
  const at = (x, y) => (x >= 0 && y >= 0 && x < w && y < h ? mask[y * w + x] : 0);
  // Boundary edges between a set cell and an unset one, the set cell on their right (y down).
  const sx = [];
  const sy = [];
  const ex = [];
  const ey = [];
  const add = (a, b, c, d) => (sx.push(a), sy.push(b), ex.push(c), ey.push(d));
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      if (!mask[y * w + x]) continue;
      if (!at(x, y - 1)) add(x, y, x + 1, y);
      if (!at(x + 1, y)) add(x + 1, y, x + 1, y + 1);
      if (!at(x, y + 1)) add(x + 1, y + 1, x, y + 1);
      if (!at(x - 1, y)) add(x, y + 1, x, y);
    }
  const key = (x, y) => y * (w + 1) + x;
  const starts = new Map();
  for (let i = 0; i < sx.length; i++) {
    const k = key(sx[i], sy[i]);
    const list = starts.get(k);
    if (list) list.push(i);
    else starts.set(k, [i]);
  }
  const used = new Uint8Array(sx.length);
  const loops = [];
  for (let i0 = 0; i0 < sx.length; i0++) {
    if (used[i0]) continue;
    const loop = [];
    let i = i0;
    while (i >= 0 && !used[i]) {
      used[i] = 1;
      loop.push([sx[i], sy[i]]);
      const outs = starts.get(key(ex[i], ey[i])) || [];
      i = outs.find((j) => !used[j]) ?? -1;
    }
    if (loop.length >= 4) loops.push(simplify(loop, tol));
  }
  return loops.filter((l) => l.length >= 3 && Math.abs(signedArea(l)) >= 4);
}

/**
 * Dimension lines in a picture: thin straight lines (maxThick pixels at most)
 * along the rows or columns, at least minLen pixels long, crossed in two
 * places at least by a tick (a short slash through the line: ink
 * diagonally on both sides of it). A wall's face drawn as a thin line has its
 * hatch meeting it from one side only. Returns [{ horizontal, at (top row
 * or left column of the line), thick, from, to, ticks: [{ at, d }] }] in
 * pixels, d the slash's lean.
 */
export function dimensionLines({ gray, w, h }, { ink, minLen, maxThick = 3, walls = null }) {
  const out = [];
  for (const horizontal of [true, false]) {
    const W = horizontal ? w : h;
    const H = horizontal ? h : w;
    const on = horizontal ? (u, v) => u >= 0 && v >= 0 && u < W && v < H && gray[v * w + u] < ink : (u, v) => u >= 0 && v >= 0 && u < W && v < H && gray[u * w + v] < ink;
    // Thickness of the ink band across the line from its top (or left) row v at u, or 0 when v is not its top.
    const band = (u, v) => {
      if (!on(u, v) || on(u, v - 1)) return 0;
      let t = 1;
      while (t <= maxThick && on(u, v + t)) t++;
      return t;
    };
    for (let v = 1; v < H - 1; v++) {
      let u = 0;
      while (u < W) {
        const t0 = band(u, v);
        if (!t0 || t0 > maxThick) {
          u++;
          continue;
        }
        // Along the line: thin ink, through crossings (ink above or below, at most 12 pixels) and gaps of 2.
        const from = u;
        let end = u;
        let cross = 0;
        let gap = 0;
        const thick = [];
        for (let x = u; x < W; x++) {
          const t = band(x, v);
          if (t && t <= maxThick) {
            end = x;
            cross = 0;
            gap = 0;
            thick.push(t);
          } else if (on(x, v)) {
            if (++cross > 12) break;
          } else if (++gap > 2) break;
        }
        u = end + 1;
        if (end - from + 1 < minLen) continue;
        thick.sort((p, q) => p - q);
        const t = thick[thick.length >> 1];
        // Ticks: a slash through the line, ink 2 and 3 pixels off it diagonally on both sides.
        const ticks = [];
        for (let x = from; x <= end; x++) {
          const slash = [2, 3].every((k) => on(x + k, v - k) && on(x - k, v + t - 1 + k));
          const back = [2, 3].every((k) => on(x - k, v - k) && on(x + k, v + t - 1 + k));
          if ((slash || back) && !(ticks.length && x - ticks.at(-1).at <= 4)) ticks.push({ at: x, d: slash ? 1 : -1 });
        }
        if (ticks.length < 2) continue;
        // Not a wall's face: walls (a mask) beside it along a third of its length at most.
        if (walls) {
          // (along, across): a row and column for a horizontal line, a column and row for a vertical one.
          const wall = (a, c) => a >= 0 && c >= 0 && a < W && c < H && walls[horizontal ? c * w + a : a * w + c];
          let by = 0;
          for (let x = from; x <= end; x++) if ([-3, -2, -1, t, t + 1, t + 2].some((d) => wall(x, v + d))) by++;
          if (by > (end - from + 1) / 3) continue;
        }
        out.push({ horizontal, at: v, thick: t, from, to: end, ticks });
      }
    }
  }
  return out;
}

/**
 * The picture without its dimension lines (dimensionLines): their thin
 * stretches and ticks painted the paper's grey, so they make no walls, glass
 * or swings. The ink of anything they cross is kept.
 */
export function withoutDimensions(img, { ink, minLen, maxThick = 3, paper = 255, walls = null }) {
  const { w, h } = img;
  const gray = img.gray.slice();
  const lines = dimensionLines(img, { ink, minLen, maxThick, walls });
  const at = (L, u, v) => (L.horizontal ? v * w + u : u * w + v);
  const inkAt = (x, y) => x >= 0 && y >= 0 && x < w && y < h && img.gray[y * w + x] < ink;
  // A thin pixel: ink with paper on two sides at least (not inside a filled shape).
  const thin = (i) => {
    const x = i % w;
    const y = (i / w) | 0;
    return [inkAt(x - 1, y), inkAt(x + 1, y), inkAt(x, y - 1), inkAt(x, y + 1)].filter((b) => !b).length >= 2;
  };
  // Walls (a mask) keep their ink, and a pixel beside them too.
  const nearWall = (i) => {
    if (!walls) return false;
    const x = i % w;
    const y = (i / w) | 0;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (x + dx >= 0 && y + dy >= 0 && x + dx < w && y + dy < h && walls[(y + dy) * w + x + dx]) return true;
    return false;
  };
  for (const L of lines) {
    const W = L.horizontal ? w : h;
    for (let u = L.from; u <= L.to; u++) {
      // Lines crossing it keep their ink (ink on both sides); text resting on it does not.
      if (inkAt(...(L.horizontal ? [u, L.at - 1] : [L.at - 1, u])) && inkAt(...(L.horizontal ? [u, L.at + L.thick] : [L.at + L.thick, u]))) continue;
      for (let k = 0; k < L.thick; k++) if (!nearWall(at(L, u, L.at + k))) gray[at(L, u, L.at + k)] = paper;
    }
    // The tick's slash (up to the side the line runs, d), off walls.
    for (const { at: x, d } of L.ticks)
      for (let k = -6; k <= 6 + L.thick; k++)
        for (const e of [-1, 0, 1]) {
          const u = x - d * (k - (L.thick >> 1)) + e;
          const v = L.at + k;
          if (u < 0 || u >= W || v < 0 || v >= (L.horizontal ? h : w)) continue;
          const i = at(L, u, v);
          if (img.gray[i] < ink && thin(i) && !nearWall(i)) gray[i] = paper;
        }
  }
  return { img: { ...img, gray }, lines };
}

/**
 * Recognise a plan from a grey picture. opts:
 *   mmPerPx   the picture's scale
 *   toModel   pixel [x, y] -> model [x, y] in mm (default: y flipped about the top)
 * Returns { plan, counts } in model millimetres.
 */
export function recognizeImage(img, { mmPerPx, toModel = null, level, stamps = null } = {}) {
  const { w, h } = img;
  const s = mmPerPx;
  const M = toModel || ((p) => [p[0] * s, -p[1] * s]);
  const tMin = Math.max(3, Math.round(60 / s));
  const tMax = Math.max(tMin + 1, Math.round(900 / s));
  // Dimension lines out first: their ticks and crossings would read as walls, the line as glass or a jamb.
  const level0 = level ?? otsu(img.gray);
  const paper0 = paperLevel(img.gray);
  // Only real walls guard ink from being cleared: blots the dimension lines make with their text are left out.
  const walls0 = bigParts(wallMask(img, { tMin, tMax, level }).mask, w, h, 4 * tMin * tMin);
  img = withoutDimensions(img, { ink: (level0 + paper0) / 2, minLen: Math.max(20, Math.round(600 / s)), maxThick: Math.max(2, Math.round(0.6 * tMin)), paper: paper0, walls: walls0 }).img;
  const { mask, dark } = wallMask(img, { tMin, tMax, level });
  const loops = maskLoops(mask, w, h, 1).map((l) => l.map(M));
  const solidPx = (p) => mask[Math.floor(p[1]) * w + Math.floor(p[0])] === 1;
  // Back from model to pixels for the solid test.
  const P = invert(M);
  const solid = (p) => {
    const q = P(p);
    return q[0] >= 0 && q[1] >= 0 && q[0] < w && q[1] < h && solidPx(q);
  };
  const pieces = wallsFromFaces(loops, solid, { min: Math.max(50, 2 * s), max: 900 });
  // Thin lines come out grey once a picture is scaled: halfway to white still counts as ink.
  const inkLevel = ((level ?? otsu(img.gray)) + 255) / 2;
  const darkAt = (p) => {
    const q = P(p);
    const x = Math.round(q[0]);
    const y = Math.round(q[1]);
    if (x < 1 || y < 1 || x >= w - 1 || y >= h - 1) return false;
    // A pixel or its neighbour: lines are one or two pixels wide.
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (dark[(y + dy) * w + x + dx] || img.gray[(y + dy) * w + x + dx] < inkLevel) return true;
    return false;
  };
  // Faint ink (a grey dashed swing, a thin line scaled down): anything clearly darker than the paper.
  const paper = paperLevel(img.gray);
  const faintLevel = Math.max(inkLevel, paper - Math.max(12, (paper - (level ?? otsu(img.gray))) * 0.12));
  const faintAt = (p) => {
    const q = P(p);
    const x = Math.round(q[0]);
    const y = Math.round(q[1]);
    if (x < 1 || y < 1 || x >= w - 1 || y >= h - 1) return false;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (img.gray[(y + dy) * w + x + dx] < faintLevel) return true;
    return false;
  };
  // A doorway leaves the wall's faces open: lines running on across the gap near both faces are a wall
  // drawn in outline (white between its lines, a shaft's boxes), not an opening.
  const openGap = (o) => {
    let faces = 0;
    for (const sgn of [-1, 1]) {
      let best = 0;
      for (const f of [0.3, 0.4, 0.5, 0.6, 0.7]) {
        let ink = 0;
        for (let i = 1; i < 12; i++) {
          const t = (i / 12 - 0.5) * o.width * 0.8;
          if (darkAt([o.at[0] + o.d[0] * t + o.n[0] * sgn * f * o.thickness, o.at[1] + o.d[1] * t + o.n[1] * sgn * f * o.thickness])) ink++;
        }
        best = Math.max(best, ink);
      }
      if (best >= 9) faces++;
    }
    return faces < 2;
  };
  // A window has a real wall on one side at least: between blots where thin lines cross (a dimension line's
  // ticks) the dimension line itself would read as glass. A door is told by its swing.
  const side = (gap) => (gap.sides ? Math.max(...gap.sides) : Infinity);
  const swingIn = (gap) => swingAt(gap, darkAt) || swingAt(gap, faintAt, true);
  // A leaf narrower than the gap (a frame or nib the walls left beside it): against either side.
  const doorIn = (gap) => {
    if (gap.width < 500 || gap.width > 2600 + 400) return null;
    if (gap.width <= 2600 && swingIn(gap)) return 'door';
    for (const f of [0.85]) {
      const R = gap.width * f;
      if (R < 500 || R > 1300) continue;
      for (const c of [-1, 1]) {
        const at = [gap.at[0] + (gap.d[0] * c * (gap.width - R)) / 2, gap.at[1] + (gap.d[1] * c * (gap.width - R)) / 2];
        if (swingIn({ ...gap, at, width: R })) return { kind: 'door', at, width: R };
      }
    }
    return null;
  };
  const classify = (gap) => doorIn(gap) || (gap.width >= 300 && side(gap) >= Math.max(2 * gap.thickness, 250) && glassAt(gap, darkAt) ? 'window' : null);
  // Stubs inside another wall's band are not jambs to bridge from, but they are still drawn wall.
  const jambs = withoutEmbeddedStubs(pieces);
  // Loose: a hatched wall's ragged faces pair up a few pixels thicker or thinner along one wall.
  const bridged = bridgeOpenings(jambs, { window: [] }, { classify, maxGap: 6000, loose: true });
  // Doors between a wall's end and a wall across (beside a corner).
  // Beside a corner only a drawn door counts: a swing from end to end, its open leaf and clear floor under it.
  // Debugging aid: the pieces and what bridging made of them, when a caller asks for them.
  if (globalThis.__imgDebug) Object.assign(globalThis.__imgDebug, { pieces, bridged: bridged.walls.map((w) => ({ ...w })), openings: bridged.openings.slice() });
  const corner = cornerDoors(bridged.walls, (gap) => (openGap(gap) && swingAt(gap, faintAt, true, [1]) ? 'door' : null));
  bridged.walls = corner.walls;
  bridged.openings.push(...corner.openings);
  // The building itself, without a legend's or title block's thick strokes.
  const plan = { walls: mainBuilding([...bridged.walls, ...pieces.filter((p) => !jambs.includes(p))]).walls, doors: [], windows: [], rooms: [], newTypes: true };
  for (const o of bridged.openings) (o.kind === 'door' ? plan.doors : plan.windows).push({ at: o.at, width: Math.round(o.width) });
  // Rooms: the free floor between the walls, with doorways closed along the walls' lines.
  const closed = mask.slice();
  for (const wl of closingWalls(plan.walls)) paintRect(closed, w, h, wallCorners(wl).map(P));
  // Rooms the walls leave open to the outside, where the facade is glazing drawn as lines: the outside is
  // what a flood from around the building reaches with every drawn line as a barrier, and the lines it stops
  // at are solid. (From a box about the walls: a sheet's frame would otherwise hold everything inside.)
  if (plan.walls.length) {
    const px = plan.walls.flatMap((wl) => [P(wl.a), P(wl.b)]);
    const pad = Math.round(1000 / s);
    const x0 = Math.max(0, Math.floor(Math.min(...px.map((p) => p[0]))) - pad);
    const x1 = Math.min(w - 1, Math.ceil(Math.max(...px.map((p) => p[0]))) + pad);
    const y0 = Math.max(0, Math.floor(Math.min(...px.map((p) => p[1]))) - pad);
    const y1 = Math.min(h - 1, Math.ceil(Math.max(...px.map((p) => p[1]))) + pad);
    const barrier = (i) => closed[i] || img.gray[i] < inkLevel;
    const out = new Uint8Array(w * h);
    const stack = [];
    const push = (x, y) => {
      if (x < x0 || x > x1 || y < y0 || y > y1) return;
      const i = y * w + x;
      if (out[i] || barrier(i)) return;
      out[i] = 1;
      stack.push(i);
    };
    for (let x = x0; x <= x1; x++) push(x, y0), push(x, y1);
    for (let y = y0; y <= y1; y++) push(x0, y), push(x1, y);
    while (stack.length) {
      const i = stack.pop();
      const x = i % w;
      const y = (i / w) | 0;
      push(x - 1, y), push(x + 1, y), push(x, y - 1), push(x, y + 1);
    }
    // The lines the outside stops at, a few pixels in.
    for (let step = 0; step < 3; step++) {
      const add = [];
      for (let y = Math.max(1, y0); y < Math.min(h - 1, y1); y++)
        for (let x = Math.max(1, x0); x < Math.min(w - 1, x1); x++) {
          const i = y * w + x;
          if (!out[i] && !closed[i] && img.gray[i] < inkLevel && (out[i - 1] || out[i + 1] || out[i - w] || out[i + w])) add.push(i);
        }
      for (const i of add) out[i] = 1;
    }
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; x++) if (out[y * w + x] || x < x0 || x > x1 || y < y0 || y > y1) closed[y * w + x] = 1;
  }
  // Room stamps read off the picture (by Claude or a person): a space holding two or more is split where a wall
  // running on would close it, choosing the cuts that give each stamp its written area.
  const stampPx = (stamps || []).filter((st) => Array.isArray(st?.at)).map((st) => ({ ...st, px: P(st.at).map(Math.floor) }));
  const cuts = stampPx.length > 1 ? stampCuts(closed, w, h, stampPx, plan.walls.map((wl) => ({ ...wl, a: P(wl.a), b: P(wl.b), thickness: wl.thickness / s })), { maxLen: 8000 / s, minCells: 1.5e6 / (s * s), mm2: s * s }) : [];
  for (const c of cuts) paintRect(closed, w, h, c);
  // Doorways the wall lines left open still narrow the floor: rooms joined through one are split there.
  for (const r of freeRegions(closed, w, h, { minCells: 1.5e6 / (s * s), maxCells: 5e8 / (s * s), neck: 500 / s, core: 1e6 / (s * s) })) {
    const outline = r.outline.map(M);
    plan.rooms.push({ at: M(r.inside), name: 'Room', outline, area: Math.abs(signedArea(outline)) / 1e6 });
  }
  // Each room takes the name and number of the stamp inside it.
  for (const st of stampPx) {
    const room = plan.rooms.find((r) => pointIn(st.at, r.outline));
    if (!room || room.stamped) continue;
    room.stamped = true;
    if (st.name) room.name = st.name;
    if (st.number) room.number = st.number;
    if (st.area > 0) room.stampArea = st.area;
  }
  return { plan, mask, closed, cuts: cuts.length, counts: { walls: plan.walls.length, doors: plan.doors.length, windows: plan.windows.length, rooms: plan.rooms.length } };
}

/** A mask with only its parts (4-connected) of minArea cells or more. */
export function bigParts(mask, w, h, minArea) {
  const out = new Uint8Array(w * h);
  const seen = new Uint8Array(w * h);
  const stack = [];
  for (let i0 = 0; i0 < w * h; i0++) {
    if (!mask[i0] || seen[i0]) continue;
    const cells = [];
    stack.push(i0);
    seen[i0] = 1;
    while (stack.length) {
      const i = stack.pop();
      cells.push(i);
      const x = i % w;
      for (const j of [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, i - w, i + w]) if (j >= 0 && j < w * h && mask[j] && !seen[j]) (seen[j] = 1), stack.push(j);
    }
    if (cells.length >= minArea) for (const i of cells) out[i] = 1;
  }
  return out;
}

/** The paper's grey: the commonest level in the brightest half of the picture. */
function paperLevel(gray) {
  const hist = new Uint32Array(256);
  for (let i = 0; i < gray.length; i += 7) hist[gray[i]]++;
  let best = 255;
  for (let v = 128; v < 256; v++) if (hist[v] > hist[best]) best = v;
  return best;
}

/** The inverse of an affine map given as a function (from three points). */
function invert(M) {
  const o = M([0, 0]);
  const ex = sub(M([1, 0]), o);
  const ey = sub(M([0, 1]), o);
  const det = ex[0] * ey[1] - ex[1] * ey[0];
  return (p) => {
    const d = sub(p, o);
    return [(d[0] * ey[1] - d[1] * ey[0]) / det, (ex[0] * d[1] - ex[1] * d[0]) / det];
  };
}

/**
 * A door's swing: a quarter circle about a corner of the gap, as wide as
 * the gap, mostly dark; or a double door's two, each half as wide, one
 * about each jamb on the same side.
 */
function swingAt(o, darkAt, clear = false, radii = [1, 0.95, 1.05, 0.9, 1.1]) {
  const half = o.thickness / 2;
  const arc = (R, sa, sn) => {
    // Hinge at a corner of the gap on one face; the arc swings away from the wall on that side.
    const h = [o.at[0] + o.d[0] * sa * (o.width / 2) + o.n[0] * sn * half, o.at[1] + o.d[1] * sa * (o.width / 2) + o.n[1] * sn * half];
    let hits = 0;
    let first = -1;
    let last = -1;
    const N = 24;
    for (let i = 1; i < N; i++) {
      const a = (i / N) * (Math.PI / 2);
      // From along the gap (towards the other jamb) round to straight out from the wall.
      const u = [-sa * o.d[0] * Math.cos(a) + sn * o.n[0] * Math.sin(a), -sa * o.d[1] * Math.cos(a) + sn * o.n[1] * Math.sin(a)];
      if (darkAt([h[0] + u[0] * R, h[1] + u[1] * R])) {
        hits++;
        if (first < 0) first = i;
        last = i;
      }
    }
    if (!clear) return hits >= 0.6 * (N - 1);
    // A dashed swing marks a third of the arc at least, from end to end, and the open leaf is drawn
    // straight out from the hinge.
    if (hits < 0.33 * (N - 1) || first > 0.25 * N || last < 0.75 * N) return false;
    let leaf = 0;
    for (let i = 2; i <= 9; i++) if (darkAt([h[0] + sn * o.n[0] * R * (i / 10), h[1] + sn * o.n[1] * R * (i / 10)])) leaf++;
    if (leaf < 6) return false;
    // Read faintly, the swing must also sweep clear floor (not a dense patch of fittings that marks any circle).
    let inside = 0;
    for (let i = 1; i < N; i++) {
      const a = (i / N) * (Math.PI / 2);
      const u = [-sa * o.d[0] * Math.cos(a) + sn * o.n[0] * Math.sin(a), -sa * o.d[1] * Math.cos(a) + sn * o.n[1] * Math.sin(a)];
      for (const f of [0.45, 0.7]) if (darkAt([h[0] + u[0] * R * f, h[1] + u[1] * R * f])) inside++;
    }
    return inside <= 0.3 * 2 * (N - 1);
  };
  for (const sn of [-1, 1]) {
    // The leaf a little wider or narrower than the gap the walls leave (a frame drawn at the jambs or not).
    for (const f of radii) if (o.width >= 350 && o.width <= 1300 && (arc(o.width * f, -1, sn) || arc(o.width * f, 1, sn))) return true;
    if (o.width >= 1000 && o.width <= 2600 && arc(o.width / 2, -1, sn) && arc(o.width / 2, 1, sn)) return true;
  }
  return false;
}

/** A window's glass: lines along the gap inside the wall's thickness, dark along most of it. */
function glassAt(o, darkAt) {
  let lines = 0;
  const N = Math.max(8, Math.round(o.width / 50));
  for (const f of [-0.35, -0.15, 0, 0.15, 0.35]) {
    let hits = 0;
    for (let i = 1; i < N; i++) {
      const t = (i / N - 0.5) * o.width;
      if (darkAt([o.at[0] + o.d[0] * t + o.n[0] * f * o.thickness, o.at[1] + o.d[1] * t + o.n[1] * f * o.thickness])) hits++;
    }
    if (hits >= 0.75 * (N - 1)) lines++;
  }
  return lines >= 1;
}

function pointIn(p, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const b = poly[j];
    if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < ((b[0] - a[0]) * (p[1] - a[1])) / (b[1] - a[1]) + a[0]) inside = !inside;
  }
  return inside;
}

/**
 * A flood over the free cells (0 in the mask) from a pixel, marking the cells it reaches with `gen` in `seen`
 * (an Int32Array reused across floods): { count, min (lowest index, the space's key), capped }.
 */
function floodFrom(mask, w, h, [x, y], cap, seen, gen, stack) {
  const i0 = y * w + x;
  if (x < 0 || y < 0 || x >= w || y >= h || mask[i0]) return { count: 0, min: -1, capped: false };
  let count = 1;
  let min = i0;
  let top = 0;
  seen[i0] = gen;
  stack[top++] = i0;
  while (top) {
    const i = stack[--top];
    const cx = i % w;
    for (let k = 0; k < 4; k++) {
      const j = k === 0 ? (cx > 0 ? i - 1 : -1) : k === 1 ? (cx < w - 1 ? i + 1 : -1) : k === 2 ? i - w : i + w;
      if (j < 0 || j >= w * h || mask[j] || seen[j] === gen) continue;
      seen[j] = gen;
      if (j < min) min = j;
      if (++count > cap) return { count, min, capped: true };
      stack[top++] = j;
    }
  }
  return { count, min, capped: false };
}

/**
 * Cuts (pixel quadrilaterals) that split spaces holding several stamps: from each wall end at the space, the wall run
 * on along its axis, or square to it from the end, to the first solid it meets (within maxLen). Cuts are added one
 * at a time, each the one that best gives the stamps their areas (or, without areas, separates most stamps), and
 * kept only when every stamp then sits in a space of its own close to its written area (when it has one).
 */
export function stampCuts(closed, w, h, stamps, walls, { maxLen, minCells, mm2 }) {
  // A space that fills most of the picture is the outside leaking in, not a room.
  const cap = 0.6 * w * h;
  const seen = new Int32Array(w * h);
  const stack = new Int32Array(w * h);
  let gen = 0;
  const groups = new Map();
  for (const st of stamps) {
    const g0 = ++gen;
    const f = floodFrom(closed, w, h, st.px, cap, seen, g0, stack);
    if (!f.count || f.capped) continue;
    if (!groups.has(f.min)) {
      // The space's own cells, kept for the "touches this space" test.
      const cells = new Uint8Array(w * h);
      for (let i = 0; i < w * h; i++) if (seen[i] === g0) cells[i] = 1;
      groups.set(f.min, { cells, size: f.count, stamps: [] });
    }
    groups.get(f.min).stamps.push(st);
  }
  const out = [];
  for (const g of groups.values()) {
    if (g.stamps.length < 2) continue;
    const near = (p) => {
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        const x = Math.round(p[0]) + dx;
        const y = Math.round(p[1]) + dy;
        if (x >= 0 && y >= 0 && x < w && y < h && g.cells[y * w + x]) return true;
      }
      return false;
    };
    const cands = [];
    for (const wl of walls) {
      const L = Math.hypot(wl.b[0] - wl.a[0], wl.b[1] - wl.a[1]);
      if (L < 1) continue;
      const d = [(wl.b[0] - wl.a[0]) / L, (wl.b[1] - wl.a[1]) / L];
      const t = Math.max(2, wl.thickness);
      for (const [end, out0] of [[wl.a, [-d[0], -d[1]]], [wl.b, d]]) {
        for (const dir of [out0, [-d[1], d[0]], [d[1], -d[0]]]) {
          const start = [end[0] + dir[0] * (t / 2 + 1), end[1] + dir[1] * (t / 2 + 1)];
          if (!near(start)) continue;
          let k = 0;
          for (; k < maxLen; k++) {
            const x = Math.round(start[0] + dir[0] * k);
            const y = Math.round(start[1] + dir[1] * k);
            if (x < 0 || y < 0 || x >= w || y >= h) { k = maxLen; break; }
            if (closed[y * w + x]) break;
          }
          if (k >= maxLen || k < 2) continue;
          const e = [start[0] + dir[0] * (k + 1), start[1] + dir[1] * (k + 1)];
          const n = [-dir[1] * (t / 2), dir[0] * (t / 2)];
          const from = [end[0] - dir[0] * 0.5, end[1] - dir[1] * 0.5];
          cands.push([[from[0] + n[0], from[1] + n[1]], [e[0] + n[0], e[1] + n[1]], [e[0] - n[0], e[1] - n[1]], [from[0] - n[0], from[1] - n[1]]]);
        }
      }
    }
    const areaOf = (m, st) => {
      const f = floodFrom(m, w, h, st.px, g.size + 10, seen, ++gen, stack);
      return f;
    };
    const score = (set) => {
      const m = closed.slice();
      for (const c of set) paintRect(m, w, h, c);
      const keys = new Map();
      let err = 0;
      for (const st of g.stamps) {
        const f = areaOf(m, st);
        if (f.count < minCells) return null;
        keys.set(f.min, (keys.get(f.min) || 0) + 1);
        if (st.area > 0) err += Math.abs((f.count * mm2) / 1e6 - st.area) / st.area;
      }
      let apart = 0;
      for (const n of keys.values()) if (n === 1) apart++;
      return { err, apart, separate: apart === g.stamps.length, m };
    };
    // A beam search: the six best sets of cuts at each step, each grown by one cut that sets a stamp more apart.
    const start = score([]);
    if (!start) continue;
    let beam = [{ set: [], sc: start }];
    let best = start.separate ? beam[0] : null;
    for (let round = 0; round < g.stamps.length + 1 && beam.length; round++) {
      const next = [];
      const seenSets = new Set();
      for (const st of beam) {
        if (st.sc.separate) continue;
        for (let k = 0; k < cands.length; k++) {
          if (st.set.includes(k)) continue;
          const set = [...st.set, k].sort((a, b) => a - b);
          const key = set.join(',');
          if (seenSets.has(key)) continue;
          seenSets.add(key);
          const sc = score(set.map((x) => cands[x]));
          if (!sc || sc.apart <= st.sc.apart) continue;
          next.push({ set, sc });
          if (sc.separate && (!best || sc.err < best.sc.err)) best = { set, sc };
        }
      }
      next.sort((a, b) => b.sc.apart - a.sc.apart || a.sc.err - b.sc.err);
      beam = next.slice(0, 6);
    }
    const chosen = best ? best.set.map((x) => cands[x]) : [];
    best = best?.sc;
    if (!best?.separate) continue;
    // With written areas: on average within 10 % of them, and none off by more than 30 % (a picture measures its
    // rooms a few per cent small, and a stair or shaft drawn inside a room is left out of its floor).
    const errs = g.stamps.filter((st) => st.area > 0).map((st) => Math.abs((areaOf(best.m, st).count * mm2) / 1e6 - st.area) / st.area);
    const fits = !errs.length || (errs.reduce((a, b) => a + b, 0) / errs.length <= 0.1 && errs.every((e) => e <= 0.3));
    if (globalThis.__imgDebug) (globalThis.__imgDebug.stampGroups ||= []).push({ stamps: g.stamps.map((st) => st.area), cands: cands.length, chosen: chosen.length, err: best.err, fits, areas: g.stamps.map((st) => +((areaOf(best.m, st).count * mm2) / 1e6).toFixed(2)) });
    if (fits) out.push(...chosen);
  }
  return out;
}

function wallCorners(wl) {
  const L = dist(wl.a, wl.b) || 1;
  const n = [(-(wl.b[1] - wl.a[1]) / L) * (wl.thickness / 2), ((wl.b[0] - wl.a[0]) / L) * (wl.thickness / 2)];
  return [[wl.a[0] + n[0], wl.a[1] + n[1]], [wl.b[0] + n[0], wl.b[1] + n[1]], [wl.b[0] - n[0], wl.b[1] - n[1]], [wl.a[0] - n[0], wl.a[1] - n[1]]];
}

/** Set the cells of a mask whose centres lie in a convex polygon (pixels). */
function paintRect(mask, w, h, poly) {
  const ys = poly.map((p) => p[1]);
  const y0 = Math.max(0, Math.floor(Math.min(...ys)));
  const y1 = Math.min(h - 1, Math.ceil(Math.max(...ys)));
  for (let y = y0; y <= y1; y++) {
    const yc = y + 0.5;
    const xs = [];
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[j];
      const b = poly[i];
      if ((a[1] > yc) !== (b[1] > yc)) xs.push(a[0] + ((yc - a[1]) * (b[0] - a[0])) / (b[1] - a[1]));
    }
    if (xs.length < 2) continue;
    const x0 = Math.max(0, Math.ceil(Math.min(...xs) - 0.5));
    const x1 = Math.min(w - 1, Math.floor(Math.max(...xs) - 0.5));
    for (let x = x0; x <= x1; x++) mask[y * w + x] = 1;
  }
}

/**
 * The enclosed free regions of a mask (not reaching the picture's edge),
 * minCells..maxCells big: [{ inside: a cell well inside, outline: pixel loop }].
 * With neck (cells), a region is split where it narrows below twice that
 * (a doorway) between parts whose cores are at least `core` cells.
 */
function freeRegions(mask, w, h, { minCells, maxCells, neck = 0, core = 0 }) {
  const label = new Int32Array(w * h).fill(-1);
  const out = [];
  let n = 0;
  const stack = [];
  for (let i0 = 0; i0 < w * h; i0++) {
    if (mask[i0] || label[i0] >= 0) continue;
    const cells = [];
    let edge = false;
    stack.push(i0);
    label[i0] = n;
    while (stack.length) {
      const i = stack.pop();
      cells.push(i);
      const x = i % w;
      const y = (i / w) | 0;
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) edge = true;
      for (const j of [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1])
        if (j >= 0 && !mask[j] && label[j] < 0) {
          label[j] = n;
          stack.push(j);
        }
    }
    n++;
    if (edge || cells.length < minCells || cells.length > maxCells) continue;
    for (const part of neck > 0 ? splitAtNecks(cells, w, h, neck, core) : [cells]) if (part.length >= minCells) {
        const r = regionOf(part, w, h);
        if (r) out.push(r);
      }
  }
  return out;
}

/**
 * A region's cells split at its necks: the cells further than r from its
 * edge (chamfer distance) form cores; cores of at least minCore cells each
 * take the cells geodesically nearest to them. One part when there is at
 * most one such core.
 */
function splitAtNecks(cells, w, h, r, minCore) {
  const inR = new Uint8Array(w * h);
  for (const i of cells) inR[i] = 1;
  // Chamfer distance (3-4) to the nearest cell outside the region, two passes over its box.
  let x0 = w;
  let x1 = 0;
  let y0 = h;
  let y1 = 0;
  for (const i of cells) {
    const x = i % w;
    const y = (i / w) | 0;
    if (x < x0) x0 = x;
    if (x > x1) x1 = x;
    if (y < y0) y0 = y;
    if (y > y1) y1 = y;
  }
  const D = new Float32Array(w * h);
  for (const i of cells) D[i] = 1e9;
  const at = (x, y) => (x < 0 || y < 0 || x >= w || y >= h ? 0 : D[y * w + x]);
  for (let y = y0; y <= y1; y++)
    for (let x = x0; x <= x1; x++) {
      const i = y * w + x;
      if (!inR[i]) continue;
      D[i] = Math.min(D[i], at(x - 1, y) + 3, at(x, y - 1) + 3, at(x - 1, y - 1) + 4, at(x + 1, y - 1) + 4);
    }
  for (let y = y1; y >= y0; y--)
    for (let x = x1; x >= x0; x--) {
      const i = y * w + x;
      if (!inR[i]) continue;
      D[i] = Math.min(D[i], at(x + 1, y) + 3, at(x, y + 1) + 3, at(x + 1, y + 1) + 4, at(x - 1, y + 1) + 4);
    }
  const R = 3 * r;
  // Cores: the deep cells, by 4-connected component.
  const label = new Int32Array(w * h).fill(-1);
  const cores = [];
  for (const i0 of cells) {
    if (D[i0] < R || label[i0] >= 0) continue;
    const list = [i0];
    label[i0] = cores.length;
    for (let k = 0; k < list.length; k++) {
      const i = list[k];
      for (const j of [i - 1, i + 1, i - w, i + w]) if (inR[j] && D[j] >= R && label[j] < 0) (label[j] = cores.length), list.push(j);
    }
    cores.push(list);
  }
  const big = cores.map((c, k) => (c.length >= minCore ? k : -1)).filter((k) => k >= 0);
  if (big.length < 2) return [cells];
  // Grow the big cores back through the region, breadth first: each cell goes to the core that reaches it first.
  const owner = new Int32Array(w * h).fill(-1);
  let front = [];
  big.forEach((k, m) => {
    for (const i of cores[k]) (owner[i] = m), front.push(i);
  });
  while (front.length) {
    const next = [];
    for (const i of front) for (const j of [i - 1, i + 1, i - w, i + w]) if (inR[j] && owner[j] < 0) (owner[j] = owner[i]), next.push(j);
    front = next;
  }
  const parts = big.map(() => []);
  for (const i of cells) if (owner[i] >= 0) parts[owner[i]].push(i);
  return parts;
}

/** A region's cells as { inside, outline }, or null when it has no outline. */
function regionOf(cells, w, h) {
  const region = new Uint8Array(w * h);
  let cx = 0;
  let cy = 0;
  for (const i of cells) {
    region[i] = 1;
    cx += i % w;
    cy += (i / w) | 0;
  }
  cx /= cells.length;
  cy /= cells.length;
  // The cell nearest the middle that has free cells all round it.
  let best = cells[0];
  let bd = Infinity;
  for (const i of cells) {
    const x = i % w;
    const y = (i / w) | 0;
    const d = (x - cx) ** 2 + (y - cy) ** 2;
    if (d < bd && region[i - 1] && region[i + 1] && region[i - w] && region[i + w]) (bd = d), (best = i);
  }
  const loops = maskLoops(region, w, h, 1.5);
  const outline = loops.reduce((a, b) => (Math.abs(signedArea(b)) > Math.abs(signedArea(a || [])) ? b : a), null);
  return outline ? { inside: [(best % w) + 0.5, ((best / w) | 0) + 0.5], outline } : null;
}

/**
 * A picture's likely scale (mm per pixel) when nothing gives it: the plan's
 * wall thickness in pixels against an ordinary wall (250 mm), then refined
 * so the doors found come out at an ordinary width (850 mm). null when no
 * walls stand out.
 */
export function guessScale(img) {
  const { gray, w, h } = img;
  const level = otsu(gray);
  // Thickness of thick dark runs: the median of the shorter run through dark cells.
  const counts = new Map();
  for (let y = 2; y < h - 2; y += 2) {
    let x = 0;
    while (x < w) {
      if (gray[y * w + x] > level) {
        x++;
        continue;
      }
      let e = x;
      while (e < w && gray[y * w + e] <= level) e++;
      const n = e - x;
      if (n >= 3 && n <= 80) counts.set(n, (counts.get(n) || 0) + n);
      x = e;
    }
  }
  if (!counts.size) return null;
  // The thickness that covers most dark cells, among runs thicker than a line.
  const [t] = [...counts].filter(([n]) => n >= 4).sort((a, b) => b[1] - a[1])[0] || [0];
  if (!t) return null;
  let s = 250 / t;
  const rec = recognizeImage(img, { mmPerPx: s, level });
  const doors = rec.plan.doors.map((d) => d.width).sort((a, b) => a - b);
  if (doors.length) s *= 850 / doors[Math.floor(doors.length / 2)];
  return s;
}
