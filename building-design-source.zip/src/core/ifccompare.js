/**
 * Detect IFC Model Changes (Archicad's IFC Model Comparison, reimplemented):
 * two versions of an IFC file compared element by element through their
 * GlobalIds. Each element is new, deleted, modified (its entity, name,
 * geometry or property values changed) or unchanged; geometry is compared by
 * a fingerprint of its triangles (bounding box, centroid, area to 1 mm).
 */
import { ifcProducts } from '../io/ifcread.js';
import { propertySets } from '../io/ifcmodel.js';

/** A comparable value of an IFC property (typed values unwrapped). */
function plain(v) {
  if (v && typeof v === 'object') {
    if ('enum' in v) return v.enum;
    if (Array.isArray(v.args)) return plain(v.args[0]);
  }
  return typeof v === 'number' ? Math.round(v * 1e6) / 1e6 : v;
}

/** Geometry fingerprint of a product's triangles (millimetres). */
export function geometryKey(tris) {
  if (!tris?.length) return 'none';
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  const c = [0, 0, 0];
  let area = 0;
  for (let i = 0; i + 8 < tris.length; i += 9) {
    const a = [tris[i], tris[i + 1], tris[i + 2]];
    const b = [tris[i + 3], tris[i + 4], tris[i + 5]];
    const d = [tris[i + 6], tris[i + 7], tris[i + 8]];
    for (const p of [a, b, d])
      for (let k = 0; k < 3; k++) {
        min[k] = Math.min(min[k], p[k]);
        max[k] = Math.max(max[k], p[k]);
      }
    const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
    const v = [d[0] - a[0], d[1] - a[1], d[2] - a[2]];
    const A = Math.hypot(u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]) / 2;
    area += A;
    for (let k = 0; k < 3; k++) c[k] += ((a[k] + b[k] + d[k]) / 3) * A;
  }
  const r = (x) => Math.round(x);
  return [...min.map(r), ...max.map(r), ...(area ? c.map((x) => r(x / area)) : [0, 0, 0]), r(area / 100)].join(',');
}

/** The elements of an IFC file by GlobalId: Map(guid → { guid, type, name, geometry, props }). */
export function ifcElements(text) {
  const { E, products } = ifcProducts(text);
  const psets = propertySets(E);
  const out = new Map();
  for (const p of products) {
    const e = E.get(p.id);
    const guid = typeof e?.args?.[0] === 'string' ? e.args[0] : null;
    if (!guid) continue;
    const props = {};
    for (const [k, v] of Object.entries(psets.get(p.id) || {})) props[k] = plain(v);
    out.set(guid, { guid, type: p.type, name: typeof e.args[2] === 'string' ? e.args[2] : p.name || '', geometry: geometryKey(p.tris), props });
  }
  return out;
}

/**
 * Compare two versions of an IFC file: { added, deleted, modified: [{ ..., changes: [text] }], unchanged (count) }.
 */
export function compareIFC(oldText, newText) {
  const A = ifcElements(oldText);
  const B = ifcElements(newText);
  const added = [];
  const deleted = [];
  const modified = [];
  let unchanged = 0;
  for (const [g, b] of B) {
    const a = A.get(g);
    if (!a) {
      added.push(b);
      continue;
    }
    const changes = [];
    if (a.type !== b.type) changes.push(`entity ${a.type} → ${b.type}`);
    if (a.name !== b.name) changes.push(`name "${a.name}" → "${b.name}"`);
    if (a.geometry !== b.geometry) changes.push('geometry');
    for (const k of new Set([...Object.keys(a.props), ...Object.keys(b.props)])) if (JSON.stringify(a.props[k]) !== JSON.stringify(b.props[k])) changes.push(`${k}: ${a.props[k] ?? '—'} → ${b.props[k] ?? '—'}`);
    if (changes.length) modified.push({ ...b, changes });
    else unchanged++;
  }
  for (const [g, a] of A) if (!B.has(g)) deleted.push(a);
  return { added, deleted, modified, unchanged };
}
