/**
 * Stair and railing components from Archicad's library (Tread, Riser, Post,
 * Rail, Panel, ...): Archicad's Stair and Railing tools run them once per
 * piece with the global variables that describe it (GDL reference, Stair
 * Parameters):
 *   STAIR_TREAD_GEOMETRY [n][3]  the tread polygon, x y (m) and the central
 *                                angle of the edge from the node (0 straight),
 *                                closed by repeating its first node
 *   STAIR_TREAD_FLAGS [n][1]     each edge's role: 0 leading, 1 trailing,
 *                                2 left, 3 right, -1 the closing node
 *   TREAD_THICKNESS              downwards from the tread's top at z = 0
 *   STAIR_RISER_GEOMETRY [n][3]  the riser's line (its thickness on its right)
 *   RISER_HEIGHT, RISER_THICKNESS, RISER_SLANT_ANGLE (degrees, 90 upright),
 *   RISER_CUT [2][2]             its ends
 *   RAILINGPOST_TYPE (1 post, 2 inner post, 3 baluster), RAILINGPOST_TOP_COORD
 *   [3] and RAILINGPOST_CUTS [2][3] (its base and top), RAILINGPOST_SEGMENT_CUTS
 *   RAIL_TYPE (1 toprail, 2 handrail, 3 rail), RAIL_POLYLINE_GEOMETRY [n][5]
 *   (x y z, central angle, the tube's rotation), RAIL_SEGMENT_FLAGS [n],
 *   RAIL_CUTS [2][4] (its ends, 0 square), RAIL_COMPONENTS [3]
 *   RAILINGPANEL_GEOMETRY [n][5] (x y z, angle, cutting angle; bottom, end
 *   side, top, start side), RAILINGPANEL_FLAGS [n][3], RAILINGPANEL_SIDE_OFFSETS
 * Here each stair piece is laid out in a frame along its flight (x up the
 * going, y across to the left), its top at the frame's height; a post at its
 * base point, a panel along its segment, a rail from the railing's start.
 */
import { runGdlType } from './gdlobject.js';

/** A JavaScript array as GDL keeps one: counted from 1 (a 2D one by rows). */
export function gdlArray(a) {
  return Array.isArray(a[0]) ? [[], ...a.map((r) => [0, ...r])] : [0, ...a];
}

const EDGE = { TREAD_LEADINGEDGE: 0, TREAD_TRAILINGEDGE: 1, TREAD_LEFTSIDEEDGE: 2, TREAD_RIGHTSIDEEDGE: 3, TREAD_BREAKLINESIDEEDGE: 4, TREAD_CLOSINGVERTEX: -1 };

/**
 * The globals for a rectangular tread, going `depth` up x from its leading
 * edge at x = -nosing, `width` across y from its right edge (mm).
 */
export function treadGlobals({ depth, width, nosing = 0, thickness, riserHeight = 0, riserThickness = 0 }) {
  const m = (v) => v / 1000;
  const x0 = m(-nosing);
  const x1 = m(depth);
  const W = m(width);
  return {
    ...EDGE,
    STAIR_TREAD_GEOMETRY: gdlArray([[x0, W, 0], [x0, 0, 0], [x1, 0, 0], [x1, W, 0], [x0, W, 0]]),
    STAIR_TREAD_FLAGS: gdlArray([[0], [3], [1], [2], [-1]]),
    TREAD_THICKNESS: m(thickness),
    TREAD_NOSING_METHOD: 1,
    TREAD_NOSING_BY_SLANTING: 0,
    TREAD_LOWER_RISER_SLANT_ANGLE: 90,
    RISER_SLANT_ANGLE: 90,
    RISER_HEIGHT: m(riserHeight),
    RISER_THICKNESS: m(riserThickness),
  };
}

/** The globals for an upright riser along the leading edge at x = 0, `height` down from its top. */
export function riserGlobals({ width, height, thickness }) {
  const m = (v) => v / 1000;
  const W = m(width);
  // Its line runs from the left edge to the right one, so its thickness (on its right) faces down the flight.
  return {
    ...EDGE,
    STAIR_RISER_GEOMETRY: gdlArray([[0, W, 0], [0, 0, 0]]),
    RISER_CUT: gdlArray([[0, W], [0, 0]]),
    RISER_HEIGHT: m(height),
    RISER_THICKNESS: m(thickness),
    RISER_SLANT_ANGLE: 90,
  };
}

/**
 * The globals for a flight's structure (stringer, beam, cantilevered
 * brackets...): STAIR_STRUCTURE_GEOMETRY [n][14] and STAIR_STRUCTURE_FLAGS
 * [n][4] hold each tread as two halves, the left one then the right one of
 * the centreline, each from its leading edge round counterclockwise and
 * closed by repeating its first node (edge roles 0 leading, 1 trailing,
 * 2 left, 3 right, 4 centreline, -1 the closing node); the columns: x y z
 * (the tread's top), the edge's angle, the riser's slant at leading and
 * trailing edges, riser heights below and above, tread thickness, the gap
 * under it, a cantilever's height, nosing, riser thickness, riser gap and a
 * cantilever's depth. STAIR2D_POLYLINES_GEOM [n][3] / _FLAGS [n][1] give the
 * flight's left and right boundaries and its centreline (0, 1, 2).
 * `steps` treads going `depth` up x, `width` across y from the right edge.
 */
export function structureGlobals({ steps, depth, width, riserHeight, thickness, nosing = 0, riserThickness = 0, pathOffset = 50, polyFlag = 0 }) {
  const m = (v) => v / 1000;
  const W = m(width);
  const D = m(depth);
  const rh = m(riserHeight);
  const geom = [];
  const flags = [];
  const node = (x, y, z, edge, side, step) => {
    geom.push([x, y, z, 0, edge === 0 || edge === 1 ? 90 : 0, rh, rh, m(thickness), 0, 0, m(nosing), m(riserThickness), 0, 0]);
    flags.push([polyFlag, side, edge, step]);
  };
  for (let i = 0; i < steps; i++) {
    const [s0, s1, z] = [i * D, (i + 1) * D, (i + 1) * rh];
    for (const [x, y, e] of [[s0, W, 0], [s0, W / 2, 4], [s1, W / 2, 1], [s1, W, 2], [s0, W, -1]]) node(x, y, z, e, 0, i + 1);
    for (const [x, y, e] of [[s0, W / 2, 0], [s0, 0, 3], [s1, 0, 1], [s1, W / 2, 4], [s0, W / 2, -1]]) node(x, y, z, e, 1, i + 1);
  }
  const run = steps * D;
  return {
    STAIR_STRUCTURE_GEOMETRY: gdlArray(geom),
    STAIR_STRUCTURE_FLAGS: gdlArray(flags),
    // Starting at the floor and ending at the top, both cut square.
    STAIR_STRUCTURE_CONN_FLAGS: gdlArray([[0, 0, 1], [0, 4, 1]]),
    STAIR_STRUCTURE_CONN_OFFSETS: gdlArray([[0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0]]),
    STAIR_STRINGER_PATH_OFFSET: m(pathOffset),
    STAIR2D_POLYLINES_GEOM: gdlArray([[0, W, 0], [run, W, 0], [0, 0, 0], [run, 0, 0], [0, W / 2, 0], [run, W / 2, 0]]),
    STAIR2D_POLYLINES_FLAGS: gdlArray([[0], [0], [1], [1], [2], [2]]),
    TREAD_THICKNESS: m(thickness),
    RISER_HEIGHT: rh,
    RISER_THICKNESS: m(riserThickness),
    RISER_SLANT_ANGLE: 90,
  };
}

/** The globals for a post (or a baluster, type 3) `height` tall from its base at the origin. */
export function postGlobals({ height, type = 1 }) {
  const H = height / 1000;
  return {
    RAILINGPOST_TYPE: type,
    RAILINGPOST_TOP_COORD: gdlArray([0, 0, H]),
    RAILINGPOST_CUTS: gdlArray([[0, 0, 0], [0, 0, H]]),
    RAILINGPOST_SEGMENT_CUTS: gdlArray([[0, 0, 0, 0], [0, 0, 0, 0]]),
    RAILING_REFLINE_DISTANCE: gdlArray([0, 0]),
  };
}

/** The globals for a rail along points [x, y, z] (mm, from its own origin): a toprail by default. */
export function railGlobals(points, type = 1) {
  const m = (v) => v / 1000;
  const rows = points.map((p) => [m(p[0]), m(p[1]), m(p[2]), 0, 0]);
  const end = (p) => [m(p[0]), m(p[1]), m(p[2]), 0];
  return {
    RAIL_TYPE: type,
    RAIL_POLYLINE_GEOMETRY: gdlArray(rows),
    RAIL_SEGMENT_FLAGS: gdlArray(points.map((_, i) => Math.min(i + 1, points.length - 1))),
    RAIL_CUTS: gdlArray([end(points[0]), end(points.at(-1))]),
    RAIL_DISCONNECTED_CUTS: gdlArray([[0, 0, 0, 0], [0, 0, 0, 0]]),
    RAIL_COMPONENTS: gdlArray([0, 0, 0]),
    RAIL_SLANT_ANGLE: 0,
    RAIL_CONNECTING_POSTS_NUM: 0,
    RAIL_CONNECTING_POSTS: gdlArray([[0, 0]]),
    RAILING_REFLINE_DISTANCE: gdlArray([0, 0]),
  };
}

/** The globals for a panel `length` along x, from z0 to z1 at its start, its far end `rise` higher (mm). */
export function panelGlobals({ length, z0, z1, rise = 0 }) {
  const m = (v) => v / 1000;
  const L = m(length);
  const geom = gdlArray([[0, 0, m(z0), 0, 0], [L, 0, m(z0 + rise), 0, 0], [L, 0, m(z1 + rise), 0, 0], [0, 0, m(z1), 0, 0]]);
  return {
    RAILINGPANEL_TYPE: 1,
    RAILINGPANEL_GEOMETRY: geom,
    RAILINGPANEL_UNCUT_GEOMETRY: geom,
    RAILINGPANEL_FLAGS: gdlArray([[1, 1, 0], [1, 2, 0], [1, 3, 0], [1, 4, 0]]),
    RAILINGPANEL_SIDE_OFFSETS: gdlArray([0, 0, 0, 0]),
    RAILINGPANEL_SLANT_ANGLE: 0,
    RAILINGPANEL_SKEW_ANGLE: 0,
    RAILING_REFLINE_DISTANCE: gdlArray([0, 0]),
  };
}

// Runs per component type and size: a flight's treads are all alike.
const runs = new WeakMap();

/** A stair component's triangles (mm, in the piece's frame) for its globals. */
export function runStairPart(type, globals) {
  let byKey = runs.get(type);
  if (!byKey) runs.set(type, (byKey = new Map()));
  const key = JSON.stringify(globals);
  if (!byKey.has(key)) byKey.set(key, runGdlType(type, {}, globals));
  return byKey.get(key);
}

/** The first flag of a landing's polygons: Archicad's cantilevered and metal landings carry only polygons marked as treads (-1). */
export const landingPolyFlag = (type) => (/cantilever|metal\s*(pan|plate)/i.test(type?.name || '') ? -1 : 0);

/** Whether a stair structure component is one of Archicad's landing ones (Landing Beam, Cantilevered Landing Block...). */
export function isLandingPart(type) {
  return /\blanding\b/i.test(type?.name || '');
}

/** Which of Archicad's stair or railing components a type is (tread, riser, post, rail, panel...), by its library folder. */
export function stairPartKind(type) {
  const src = type?.gdl?.source || '';
  const m = src.match(/\/(?:Stair|Railing)\/(Tread|Riser|Stringer|Beam|Cantilevered|Post|Rail End|Rail|Panel)\//i);
  if (m) return m[1].toLowerCase();
  const b = /Built-In (Tread|Riser|Post|Rail End|Rail|Panel)\b/i.exec(type?.name || '');
  return b ? b[1].toLowerCase() : null;
}
