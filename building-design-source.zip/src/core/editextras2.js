/**
 * More Edit menu commands, as in Archicad:
 *
 *   Adjust Elements to Slabs    walls and columns trimmed or extended to the slabs above or below them:
 *                               the top to the underside of the slab above, the bottom to the top of the slab below
 *                               (or the bottom of the slab below, the top of the slab above);
 *   Edit Elements by Stories    delete the elements of chosen kinds on chosen stories (copying is Paste Aligned);
 *   Select Duplicates           the second and later copies of elements in the same place.
 */
import { levelElevation, verticalExtent } from './model.js';
import { pointInPolygon } from './geom.js';
import { typeThickness } from './catalog.js';
import { physicalQuality } from './modelquality.js';

export const ADJUST_TO = [
  { value: 'topToBottom', label: 'Top to the underside of the slab above' },
  { value: 'topToTop', label: 'Top to the top of the slab above' },
  { value: 'bottomToTop', label: 'Bottom to the top of the slab below' },
  { value: 'bottomToBottom', label: 'Bottom to the underside of the slab below' },
];

/** The slabs over a plan point: [{ id, top, bottom }] (absolute mm). */
function slabsAt(doc, p) {
  const out = [];
  for (const f of doc.all('floor')) {
    if (!f.boundary || f.boundary.length < 3 || !pointInPolygon(p, f.boundary)) continue;
    const top = levelElevation(doc, f.levelId) + (+f.offset || 0);
    out.push({ id: f.id, top, bottom: top - (typeThickness(doc.get(f.typeId)) || 200) });
  }
  return out;
}

/** Plan points of an element to test slabs at: a column's centre, a wall's middle and ends. */
const probes = (el) => (el.kind === 'column' ? [el.at] : [[(el.a[0] + el.b[0]) / 2, (el.a[1] + el.b[1]) / 2]]);

/** Adjust walls and columns to the slabs above or below (inside a transaction). Returns how many changed. */
export function adjustToSlabs(doc, ids, mode = 'topToBottom') {
  let n = 0;
  for (const id of ids) {
    const el = doc.get(id);
    if (!el || (el.kind !== 'wall' && el.kind !== 'column') || !(el.kind === 'column' ? el.at : el.a && el.b)) continue;
    const { base, top } = verticalExtent(doc, el);
    const lv = levelElevation(doc, el.levelId);
    const slabs = probes(el).flatMap((p) => slabsAt(doc, p));
    if (!slabs.length) continue;
    const up = mode.startsWith('top');
    const face = (s) => (mode === 'topToBottom' || mode === 'bottomToBottom' ? s.bottom : s.top);
    // The nearest slab on that side: above the element's base for its top, below its top for its bottom.
    const cands = slabs.filter((s) => (up ? face(s) > base + 1 : face(s) < top - 1)).sort((a, b) => (up ? face(a) - face(b) : face(b) - face(a)));
    const s = cands[0];
    if (!s) continue;
    const z = face(s);
    if (up) doc.update(id, { topLevelId: null, topOffset: 0, height: Math.round(z - base), attachTopId: null });
    else {
      const patch = { baseOffset: Math.round(z - lv) };
      if (!el.topLevelId) patch.height = Math.round(top - z);
      doc.update(id, patch);
    }
    n++;
  }
  return n;
}

/** Delete the elements of `kinds` on `levelIds` (inside a transaction). Returns how many. */
export function deleteOnStories(doc, levelIds, kinds) {
  const lv = new Set(levelIds);
  const ks = new Set(kinds);
  let n = 0;
  for (const el of doc.filter((x) => ks.has(x.kind) && lv.has(x.levelId))) {
    if (!doc.has(el.id)) continue;
    doc.remove(el.id);
    n++;
  }
  return n;
}

/** Ids of the later copies of duplicated elements (the first of each stays unselected). */
export function duplicateIds(doc, scene) {
  const out = new Set();
  for (const f of physicalQuality(doc, scene)) if (f.check === 'duplicate') f.ids.slice(1).forEach((id) => out.add(id));
  return [...out];
}
