/**
 * Electrical calculation from the project's electrical settings: the load of
 * each story (devices, lighting and equipment), its design current, and the
 * smallest copper cable that carries it within the allowed voltage drop.
 *
 *   ampacities: IEC 60364-5-52, table B.52.4, PVC, method B1, 2 or 3 loaded conductors
 *   drop: ΔU = k · L · I · ρ / S · cosφ, k = 2 single phase, √3 three phase, ρ = 0.0225 Ω·mm²/m at 70 °C
 */
import { settingsOf, ELECTRICAL_DEFAULTS } from './mepparts.js';
import { categoryOf } from './catalog.js';

export const CABLES = [
  [1.5, 17.5, 15.5],
  [2.5, 24, 21],
  [4, 32, 28],
  [6, 41, 36],
  [10, 57, 50],
  [16, 76, 68],
  [25, 101, 89],
  [35, 125, 110],
  [50, 151, 134],
  [70, 192, 171],
  [95, 232, 207],
];

const RHO = 0.0225;
const DEFAULT_W = { lighting: 15, electricalFixtures: 200, electricalEquipment: 0 };

/** The electrical load of a component in W: its own value, or a default for its category. */
export function powerOf(doc, c) {
  if (c.electricalLoad != null && c.electricalLoad !== '') return +c.electricalLoad || 0;
  const own = doc.get(c.typeId)?.electricalLoad;
  if (own != null) return +own || 0;
  return DEFAULT_W[categoryOf(c, doc)] ?? 0;
}

export const designCurrent = (w, s) => (+s.phases === 3 ? w / (Math.sqrt(3) * s.threePhaseVoltage * s.powerFactor) : w / (s.voltage * s.powerFactor));

/** Voltage drop in % for a current over a one-way length (m) of a section (mm²). */
export function voltageDrop(i, lengthM, section, s) {
  const three = +s.phases === 3;
  const volts = (three ? Math.sqrt(3) : 2) * lengthM * i * (RHO / section) * s.powerFactor;
  return (volts / (three ? s.threePhaseVoltage : s.voltage)) * 100;
}

/** The smallest section carrying the current within the drop: { section, drop } or null when none does. */
export function cableFor(i, lengthM, s) {
  const col = +s.phases === 3 ? 2 : 1;
  for (const c of CABLES) {
    const drop = voltageDrop(i, lengthM, c[0], s);
    if (c[col] >= i && drop <= +s.maxDrop) return { section: c[0], drop };
  }
  return null;
}

/**
 * One row per story with electrical components: { level, count, watts, current, panel, lengthM, cable }.
 * The length is the longest run on the story from its panel (an Electrical Equipment object) along the axes;
 * with no panel on the story there is no length and the cable is sized on the current alone.
 */
export function electricalLoads(doc) {
  const s = settingsOf(doc.get('project'), 'electrical', ELECTRICAL_DEFAULTS);
  const rows = [];
  for (const level of doc.levels()) {
    const comps = doc.all('component').filter((c) => c.levelId === level.id && DEFAULT_W[categoryOf(c, doc)] != null);
    if (!comps.length) continue;
    const panels = comps.filter((c) => categoryOf(c, doc) === 'electricalEquipment');
    const devices = comps.filter((c) => !panels.includes(c));
    const watts = comps.reduce((t, c) => t + powerOf(doc, c), 0);
    const current = designCurrent(watts, s);
    let lengthM = 0;
    if (panels.length) for (const d of devices) lengthM = Math.max(lengthM, Math.min(...panels.map((p) => Math.abs(p.at[0] - d.at[0]) + Math.abs(p.at[1] - d.at[1]))) / 1000);
    rows.push({ level: level.name, count: comps.length, watts, current, panel: panels.length > 0, lengthM, cable: cableFor(current, lengthM, s) });
  }
  return rows;
}
