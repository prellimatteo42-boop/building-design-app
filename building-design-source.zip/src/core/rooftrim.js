/**
 * Trim Elements to Roof/Shell and Crop to Single-plane Roof for any element
 * with a 3D body (beams, slabs, objects, morphs, shells, and walls or columns
 * trimmed to a shell). Walls and columns under a roof follow it analytically
 * (build3d.js attachedTop, which can also extend them); everything else loses
 * the part of its body beyond the trimming surface:
 *   - attachTopMode 'above' (default): what is above the trimmer's underside
 *   - attachTopMode 'below': what is below the trimmer's top
 *   - attachTopMode 'plane': what is above the plane of a single-plane roof,
 *     extended without end (Crop to Single-plane Roof)
 * The cut solid is built from the trimmer's mesh: its downward (or upward)
 * faces, a cap far beyond the element and side faces along the open edges.
 */
import { meshPolygons, subtract, polygonsMesh } from './csg.js';
import { roofGeometry } from './build3d.js';
import { planeHeight } from './roof.js';
import { triangulate, ensureCCW } from './geom.js';

/** Beyond this many triangles a body is left as it is (the operation would be slow). */
const MAX_TRIS = 12000;
export const TRIM_MODES = [
  { value: 'above', label: 'Parts above the roof/shell' },
  { value: 'below', label: 'Parts below the roof/shell' },
];
const TRIMMER_KINDS = new Set(['roof', 'shell']);
/** Elements that can be trimmed to a roof or shell. */
export const TRIMMABLE_KINDS = new Set(['wall', 'column', 'beam', 'floor', 'ceiling', 'component', 'morph', 'shell', 'mass', 'roof', 'stair', 'railing', 'ramp', 'brace', 'footing', 'truss', 'duct', 'pipe', 'cableTray']);

export const isTrimmer = (el) => !!el && TRIMMER_KINDS.has(el.kind);

/** Walls and columns under a roof are trimmed by their own geometry (not by a solid). */
export function trimsAnalytically(el, trimmer) {
  return (el.kind === 'wall' || el.kind === 'column') && trimmer?.kind === 'roof' && el.attachTopMode !== 'below';
}

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const crossV = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const key = (p) => `${Math.round(p[0] * 10)},${Math.round(p[1] * 10)}`;

/** Triangles of a mesh as point triples. */
function triangles(mesh) {
  const P = mesh.pos;
  const out = [];
  for (let i = 0; i + 8 < P.length; i += 9) out.push([[P[i], P[i + 1], P[i + 2]], [P[i + 3], P[i + 4], P[i + 5]], [P[i + 6], P[i + 7], P[i + 8]]]);
  return out;
}

/**
 * A closed mesh between a surface (triangles all facing down for an upward
 * solid, up for a downward one) and the height zFar, with side faces along
 * the surface's open edges.
 */
export function extrudedSolid(surface, zFar, color = [0, 0, 0, 255]) {
  const pos = [];
  const col = [];
  const tri = (a, b, c) => {
    pos.push(...a, ...b, ...c);
    col.push(...color, ...color, ...color);
  };
  const edges = new Map();
  for (const [a, b, c] of surface) {
    tri(a, b, c);
    tri([a[0], a[1], zFar], [c[0], c[1], zFar], [b[0], b[1], zFar]);
    const cx = (a[0] + b[0] + c[0]) / 3;
    const cy = (a[1] + b[1] + c[1]) / 3;
    for (const [p, q] of [[a, b], [b, c], [c, a]]) {
      const kp = key(p);
      const kq = key(q);
      if (kp === kq) continue;
      const k = kp < kq ? `${kp}|${kq}` : `${kq}|${kp}`;
      const e = edges.get(k);
      if (e) e.n++;
      else edges.set(k, { p, q, cx, cy, n: 1 });
    }
  }
  for (const { p, q, cx, cy, n } of edges.values()) {
    if (n !== 1) continue;
    const P2 = [p[0], p[1], zFar];
    const Q2 = [q[0], q[1], zFar];
    // Outward: away from the triangle the edge belongs to.
    const nrm = crossV(sub(q, p), sub(Q2, p));
    const out = [(p[0] + q[0]) / 2 - cx, (p[1] + q[1]) / 2 - cy];
    if (nrm[0] * out[0] + nrm[1] * out[1] >= 0) {
      tri(p, q, Q2);
      tri(p, Q2, P2);
    } else {
      tri(q, p, P2);
      tri(q, P2, Q2);
    }
  }
  return { pos, col };
}

/** Faces of a trimmer mesh facing down (dir -1) or up (dir 1), oriented that way. */
export function facingSurface(mesh, dir = -1) {
  const out = [];
  for (const t of triangles(mesh)) {
    const n = crossV(sub(t[1], t[0]), sub(t[2], t[0]));
    const l = Math.hypot(...n);
    if (l < 1e-6) continue;
    if ((n[2] / l) * dir > 0.05) out.push(t);
  }
  return out;
}

function bounds(mesh) {
  if (mesh.bounds) return mesh.bounds;
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  const P = mesh.pos;
  for (let i = 0; i < P.length; i += 3)
    for (let k = 0; k < 3; k++) {
      min[k] = Math.min(min[k], P[i + k]);
      max[k] = Math.max(max[k], P[i + k]);
    }
  return { min, max };
}

/** The (downward-facing) underside of a single-plane roof's plane over a box, extended without end. */
export function planeSurface(doc, roof, box, margin = 1000) {
  const g = roofGeometry(doc, roof);
  const pl = g.planes[0];
  const z = (x, y) => g.base + (pl ? planeHeight(pl, [x, y]) : 0);
  const x0 = box.min[0] - margin;
  const x1 = box.max[0] + margin;
  const y0 = box.min[1] - margin;
  const y1 = box.max[1] + margin;
  const A = [x0, y0, z(x0, y0)];
  const B = [x1, y0, z(x1, y0)];
  const C = [x1, y1, z(x1, y1)];
  const D = [x0, y1, z(x0, y1)];
  // Clockwise seen from above: facing down.
  return [[A, C, B], [A, D, C]];
}

/**
 * The element's mesh without its part beyond the trimmer. trimmerMesh is the
 * trimmer's own mesh (not needed in plane mode). Unchanged when nothing applies.
 */
export function trimMesh(doc, mesh, trimmer, trimmerMesh, mode = 'above') {
  if (!mesh?.pos?.length || !trimmer) return mesh;
  const polys = meshPolygons(mesh);
  if (polys.length > MAX_TRIS) return mesh;
  const box = bounds(mesh);
  let surface;
  let zFar;
  if (mode === 'plane') {
    if (trimmer.kind !== 'roof') return mesh;
    surface = planeSurface(doc, trimmer, box);
    zFar = Math.max(box.max[2], ...surface.flat().map((p) => p[2])) + 1000;
  } else {
    if (!trimmerMesh?.pos?.length) return mesh;
    const dir = mode === 'below' ? 1 : -1;
    surface = facingSurface(trimmerMesh, dir);
    if (!surface.length || surface.length > MAX_TRIS / 2) return mesh;
    const zs = surface.flat().map((p) => p[2]);
    zFar = dir < 0 ? Math.max(box.max[2], ...zs) + 1000 : Math.min(box.min[2], ...zs) - 1000;
  }
  const cutter = meshPolygons(extrudedSolid(surface, zFar));
  const kept = subtract(polys, cutter);
  const out = polygonsMesh(kept);
  if (!out.pos?.length) return out;
  if (mesh.partMaterials) out.partMaterials = mesh.partMaterials;
  return out;
}

/** Plan centre of an element (for choosing the trimmer above it). */
function planCentre(el) {
  if (el.at) return el.at;
  if (el.a && el.b) return [(el.a[0] + el.b[0]) / 2, (el.a[1] + el.b[1]) / 2];
  const pts = el.boundary || el.points || el.path;
  if (pts?.length) return [pts.reduce((s, p) => s + p[0], 0) / pts.length, pts.reduce((s, p) => s + p[1], 0) / pts.length];
  return null;
}

function inside(p, poly) {
  let r = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const c = poly[j];
    if (a[1] > p[1] !== c[1] > p[1] && p[0] < ((c[0] - a[0]) * (p[1] - a[1])) / (c[1] - a[1]) + a[0]) r = !r;
  }
  return r;
}

/**
 * The trimmer for an element: one of the given (selected) roofs and shells
 * over it, else the lowest roof whose outline holds it on a level above its own.
 */
export function trimmerFor(doc, el, candidates = []) {
  const m = planCentre(el);
  const elev = (x) => doc.get(x.levelId)?.elevation ?? 0;
  const over = (r) => !m || !r.boundary?.length || inside(m, r.boundary);
  if (candidates.length) return candidates.find(over) || candidates[0];
  if (!m) return null;
  const base = elev(el) + (+el.baseOffset || 0);
  return doc
    .all('roof')
    .filter((r) => elev(r) + (+r.baseOffset || 0) >= base && over(r))
    .sort((a, b) => elev(a) - elev(b))[0] || null;
}

/**
 * Cut Additional Element with Opening: the vertical opening outlines (plan
 * polygons) cut through the body, top to bottom. Unchanged when nothing applies.
 */
export function cutOpenings(mesh, outlines) {
  if (!mesh?.pos?.length || !outlines?.length) return mesh;
  let polys = meshPolygons(mesh);
  if (polys.length > MAX_TRIS) return mesh;
  const box = bounds(mesh);
  const z0 = box.min[2] - 1000;
  const z1 = box.max[2] + 1000;
  let changed = false;
  for (const outline of outlines) {
    if (!outline || outline.length < 3) continue;
    const { points, tris } = triangulate(ensureCCW(outline), []);
    const surface = [];
    // Facing down at the bottom.
    for (let i = 0; i + 2 < tris.length; i += 3) {
      const t = [tris[i], tris[i + 1], tris[i + 2]].map((k) => [points[k][0], points[k][1], z0]);
      const up = (t[1][0] - t[0][0]) * (t[2][1] - t[0][1]) - (t[1][1] - t[0][1]) * (t[2][0] - t[0][0]) > 0;
      surface.push(up ? [t[0], t[2], t[1]] : t);
    }
    if (!surface.length) continue;
    polys = subtract(polys, meshPolygons(extrudedSolid(surface, z1)));
    changed = true;
  }
  if (!changed) return mesh;
  const out = polygonsMesh(polys);
  if (mesh.partMaterials && out.pos?.length) out.partMaterials = mesh.partMaterials;
  return out;
}

const HOLE_KINDS = new Set(['floor', 'ceiling', 'roof']);

/**
 * Add elements to the openings of a host slab, roof or ceiling (its holes):
 * other slabs, roofs and ceilings take the holes as their own holes, every
 * other body keeps them as openingCuts (cut in 3D). Returns how many changed.
 */
export function cutWithOpenings(doc, hostId, ids) {
  const host = doc.get(hostId);
  const holes = host?.holes?.filter((h) => h?.length >= 3) || [];
  if (!holes.length) return 0;
  let n = 0;
  for (const id of ids) {
    const el = doc.get(id);
    if (!el || el.id === hostId) continue;
    if (HOLE_KINDS.has(el.kind)) doc.update(id, { holes: [...(el.holes || []), ...holes.map((h) => h.map((p) => [...p]))] });
    else if (TRIMMABLE_KINDS.has(el.kind)) doc.update(id, { openingCuts: [...(el.openingCuts || []), ...holes.map((h) => h.map((p) => [...p]))] });
    else continue;
    n++;
  }
  return n;
}
