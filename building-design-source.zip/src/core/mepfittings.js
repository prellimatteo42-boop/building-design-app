/**
 * MEP fittings, as Archicad's routing makes them: where runs of one kind
 * meet, an elbow (two runs at an angle), a tee (three), a cross (four) or a
 * transition (two in line with different sizes). Fittings are elements of
 * their own, counted in schedules; the runs stop where a fitting begins.
 *
 *   mepFitting { levelId, at: [x, y], z, family: 'duct' | 'pipe' | 'cableTray' | 'conduit', fittingType,
 *                system, size: { round, w, h }, ends: [{ id, end: 0 | 1, trim, dir: [x, y, z], size }], angle, auto }
 *
 * Elbows bend on a radius of one width (Archicad's default bend ratio);
 * transitions are 1.5 times the change in size long, at least 100 mm.
 */
import { MEP_KINDS, mepSize, systemOf } from './mep.js';
import { runEnds } from './mepnet.js';

const same = (p, q) => Math.abs(p[0] - q[0]) <= 2 && Math.abs(p[1] - q[1]) <= 2 && Math.abs(p[2] - q[2]) <= 6;
const unit = (v) => {
  const l = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / l, v[1] / l, v[2] / l];
};

/** The fittings the runs of a model call for: [fitting] (not yet in the model). */
export function fittingsFor(doc, { bend = 1 } = {}) {
  const runs = MEP_KINDS.flatMap((k) => doc.all(k)).filter((r) => r.a && r.b);
  // Joints: run ends grouped where they coincide, per kind.
  const joints = [];
  for (const r of runs) {
    const ends = runEnds(doc, r);
    ends.forEach((p, end) => {
      const other = ends[1 - end];
      const dir = unit([other[0] - p[0], other[1] - p[1], other[2] - p[2]]);
      let j = joints.find((x) => x.kind === r.kind && same(x.p, p));
      if (!j) joints.push((j = { kind: r.kind, p, levelId: r.levelId, ends: [] }));
      j.ends.push({ run: r, end, dir, size: mepSize(doc, r), length: Math.hypot(other[0] - p[0], other[1] - p[1], other[2] - p[2]) });
    });
  }
  // A joint on the middle of another run of its kind is a branch off it (Archicad: Branch / Take-Off).
  const mainUnder = (j) => {
    for (const m of runs) {
      if (m.kind !== j.kind || j.ends.some((e) => e.run.id === m.id)) continue;
      const [a, b] = runEnds(doc, m);
      const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
      const l2 = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];
      if (l2 < 1) continue;
      const t = ((j.p[0] - a[0]) * d[0] + (j.p[1] - a[1]) * d[1] + (j.p[2] - a[2]) * d[2]) / l2;
      if (t <= 0.01 || t >= 0.99) continue;
      const q = [a[0] + d[0] * t, a[1] + d[1] * t, a[2] + d[2] * t];
      if (Math.hypot(q[0] - j.p[0], q[1] - j.p[1], q[2] - j.p[2]) <= mepSize(doc, m).w / 2 + 1) return m;
    }
    return null;
  };
  const out = [];
  for (const j of joints) {
    const n = j.ends.length;
    const main = mainUnder(j);
    if (main) {
      const ms = mepSize(doc, main);
      out.push({
        kind: 'mepFitting',
        levelId: j.levelId,
        at: [j.p[0], j.p[1]],
        z: j.p[2],
        family: j.kind,
        fittingType: 'branch',
        system: j.ends[0].run.system ?? systemOf(j.ends[0].run).value,
        size: j.ends[0].size,
        mainId: main.id,
        angle: null,
        ends: j.ends.map((e) => ({ id: e.run.id, end: e.end, trim: Math.round(Math.min(ms.w / 2 + 50, 0.45 * e.length) * 10) / 10, dir: e.dir.map((v) => Math.round(v * 1e6) / 1e6), size: e.size })),
        auto: true,
      });
      continue;
    }
    if (n < 2) continue;
    const big = j.ends.reduce((a, b) => (b.size.w * b.size.h > a.size.w * a.size.h ? b : a));
    const w = big.size.w;
    let fittingType;
    let angle = null;
    const trims = new Map();
    if (n === 2) {
      const [e1, e2] = j.ends;
      const cos = e1.dir[0] * e2.dir[0] + e1.dir[1] * e2.dir[1] + e1.dir[2] * e2.dir[2];
      const inLine = cos < -0.999;
      if (inLine) {
        if (Math.abs(e1.size.w - e2.size.w) < 1 && Math.abs(e1.size.h - e2.size.h) < 1) continue; // a plain joint
        fittingType = 'transition';
        const L = Math.max(100, 1.5 * Math.max(Math.abs(e1.size.w - e2.size.w), Math.abs(e1.size.h - e2.size.h)));
        trims.set(e1, L / 2).set(e2, L / 2);
      } else {
        fittingType = 'elbow';
        // Interior angle between the runs; the bend is tangent to both.
        const alpha = Math.acos(Math.max(-1, Math.min(1, cos)));
        angle = 180 - (alpha * 180) / Math.PI;
        const R = (typeof bend === 'function' ? bend(j.kind) : bend) * w;
        const t = Math.min(R / Math.tan(alpha / 2), 0.45 * Math.min(e1.length, e2.length));
        trims.set(e1, t).set(e2, t);
      }
    } else {
      fittingType = n === 3 ? 'tee' : n === 4 ? 'cross' : 'tee';
      for (const e of j.ends) trims.set(e, Math.min(w / 2 + 50, 0.45 * e.length));
    }
    out.push({
      kind: 'mepFitting',
      levelId: j.levelId,
      at: [j.p[0], j.p[1]],
      z: j.p[2],
      family: j.kind,
      fittingType,
      system: big.run.system ?? systemOf(big.run).value,
      size: big.size,
      angle,
      ends: j.ends.map((e) => ({ id: e.run.id, end: e.end, trim: Math.round(trims.get(e) * 10) / 10, dir: e.dir.map((v) => Math.round(v * 1e6) / 1e6), size: e.size })),
      auto: true,
    });
  }
  return out;
}

export const FITTING_LABEL = { elbow: 'Elbow', tee: 'Tee', cross: 'Cross', transition: 'Transition', branch: 'Branch', wye: 'Wye', cap: 'End Cap', riser: 'Vertical Bend' };

/**
 * Fittings chosen by hand from the library (Archicad's Duct/Pipe/Cable Carrier Fitting tools): each part with the
 * directions of its ends in its own frame (x along the incoming run, z up) and the families it exists for.
 */
export const FITTING_LIBRARY = [
  { value: 'elbow90', label: 'Elbow 90°', type: 'elbow', dirs: [[-1, 0, 0], [0, 1, 0]] },
  { value: 'elbow45', label: 'Elbow 45°', type: 'elbow', dirs: [[-1, 0, 0], [Math.SQRT1_2, Math.SQRT1_2, 0]] },
  { value: 'tee', label: 'Tee', type: 'tee', dirs: [[-1, 0, 0], [1, 0, 0], [0, 1, 0]] },
  { value: 'cross', label: 'Cross', type: 'cross', dirs: [[-1, 0, 0], [1, 0, 0], [0, 1, 0], [0, -1, 0]] },
  { value: 'wye', label: 'Wye (45° branch)', type: 'wye', dirs: [[-1, 0, 0], [1, 0, 0], [Math.SQRT1_2, Math.SQRT1_2, 0]] },
  { value: 'reducer', label: 'Reducer', type: 'transition', dirs: [[-1, 0, 0], [1, 0, 0]] },
  { value: 'cap', label: 'End cap', type: 'cap', dirs: [[-1, 0, 0]] },
  { value: 'riserUp', label: 'Vertical bend up', type: 'riser', dirs: [[-1, 0, 0], [0, 0, 1]], families: ['cableTray', 'duct', 'pipe'] },
  { value: 'riserDown', label: 'Vertical bend down', type: 'riser', dirs: [[-1, 0, 0], [0, 0, -1]], families: ['cableTray', 'duct', 'pipe'] },
];

/**
 * A fitting placed by hand (not added): part from FITTING_LIBRARY at a plan point and height, turned by `rotation`
 * (degrees, counterclockwise) or along `along` (the direction the incoming run runs in, 3D), with its size (and
 * the reducer's second size). attach: { id, end } of a run the first end belongs to (it is trimmed back there).
 */
export function placedFitting({ family, part, at, z, rotation = 0, along = null, size, size2 = null, system, levelId, attach = null }) {
  const def = FITTING_LIBRARY.find((x) => x.value === part);
  if (!def) return null;
  let ex;
  // x runs on in the direction the run comes in, so the first end looks back along it.
  if (along) ex = unit([along[0], along[1], 0]);
  else ex = [Math.cos((rotation * Math.PI) / 180), Math.sin((rotation * Math.PI) / 180), 0];
  const ey = [-ex[1], ex[0], 0];
  const turn = (d) => [ex[0] * d[0] + ey[0] * d[1], ex[1] * d[0] + ey[1] * d[1], d[2]].map((v) => Math.round(v * 1e6) / 1e6 + 0);
  const w = Math.max(size.w, size.h || 0);
  const leg = def.type === 'elbow' || def.type === 'riser' ? Math.max(100, w) : def.type === 'cap' ? Math.max(40, w * 0.15) : Math.max(100, w * 0.75);
  const ends = def.dirs.map((d, i) => {
    const sz = def.type === 'transition' && i === 1 && size2 ? size2 : size;
    const trim = def.type === 'transition' ? Math.max(100, 1.5 * Math.abs((size2?.w ?? size.w) - size.w)) / 2 : leg;
    return { id: i === 0 && attach ? attach.id : null, end: i === 0 && attach ? attach.end : null, trim: Math.round(trim * 10) / 10, dir: turn(d), size: sz };
  });
  const elbowAngle = def.type === 'elbow' || def.type === 'riser' ? Math.round((Math.acos(Math.max(-1, Math.min(1, -(ends[0].dir[0] * ends[1].dir[0] + ends[0].dir[1] * ends[1].dir[1] + ends[0].dir[2] * ends[1].dir[2])))) * 180) / Math.PI) : null;
  return {
    kind: 'mepFitting',
    levelId,
    at: [at[0], at[1]],
    z,
    family,
    fittingType: def.type === 'riser' ? 'elbow' : def.type,
    part,
    system,
    size,
    angle: elbowAngle,
    ends,
    auto: false,
  };
}

/**
 * A fitting as short straight pieces along its centre line, each with a size: [{ a, b, size }] (3D, mm).
 * Elbows follow their bend, transitions step from one size to the other, tees and crosses are stubs to each run.
 */
export function fittingSegments(f) {
  const p = [f.at[0], f.at[1], f.z];
  const at = (d, t) => [p[0] + d[0] * t, p[1] + d[1] * t, p[2] + d[2] * t];
  const out = [];
  if (f.fittingType === 'elbow' && f.ends.length === 2) {
    const [e1, e2] = f.ends;
    const cos = e1.dir[0] * e2.dir[0] + e1.dir[1] * e2.dir[1] + e1.dir[2] * e2.dir[2];
    const alpha = Math.acos(Math.max(-1, Math.min(1, cos)));
    const t = Math.min(e1.trim, e2.trim);
    const TA = at(e1.dir, t);
    const TB = at(e2.dir, t);
    const bis = unit([e1.dir[0] + e2.dir[0], e1.dir[1] + e2.dir[1], e1.dir[2] + e2.dir[2]]);
    const R = t * Math.tan(alpha / 2);
    const C = at(bis, R / Math.sin(alpha / 2));
    const va = [TA[0] - C[0], TA[1] - C[1], TA[2] - C[2]];
    const vb = [TB[0] - C[0], TB[1] - C[1], TB[2] - C[2]];
    const theta = Math.PI - alpha;
    const steps = Math.max(2, Math.ceil(theta / (Math.PI / 16)));
    const pts = [];
    for (let k = 0; k <= steps; k++) {
      const s = k / steps;
      const w1 = Math.sin((1 - s) * theta) / Math.sin(theta);
      const w2 = Math.sin(s * theta) / Math.sin(theta);
      pts.push([C[0] + va[0] * w1 + vb[0] * w2, C[1] + va[1] * w1 + vb[1] * w2, C[2] + va[2] * w1 + vb[2] * w2]);
    }
    // The shorter run's trim may be less than the other's: fill the gap with a straight piece.
    if (e1.trim > t + 0.5) out.push({ a: at(e1.dir, e1.trim), b: TA, size: e1.size });
    for (let k = 0; k < pts.length - 1; k++) out.push({ a: pts[k], b: pts[k + 1], size: f.size });
    if (e2.trim > t + 0.5) out.push({ a: TB, b: at(e2.dir, e2.trim), size: e2.size });
    return out;
  }
  if (f.fittingType === 'transition' && f.ends.length === 2) {
    const [e1, e2] = f.ends;
    const A = at(e1.dir, e1.trim);
    const B = at(e2.dir, e2.trim);
    const steps = 6;
    for (let k = 0; k < steps; k++) {
      const s0 = k / steps;
      const s1 = (k + 1) / steps;
      const sm = (s0 + s1) / 2;
      out.push({
        a: [A[0] + (B[0] - A[0]) * s0, A[1] + (B[1] - A[1]) * s0, A[2] + (B[2] - A[2]) * s0],
        b: [A[0] + (B[0] - A[0]) * s1, A[1] + (B[1] - A[1]) * s1, A[2] + (B[2] - A[2]) * s1],
        size: { round: e1.size.round, w: e1.size.w + (e2.size.w - e1.size.w) * sm, h: e1.size.h + (e2.size.h - e1.size.h) * sm },
      });
    }
    return out;
  }
  if (f.fittingType === 'cap' && f.ends.length === 1) {
    const e = f.ends[0];
    return [{ a: p, b: at(e.dir, e.trim), size: e.size, cap: true }];
  }
  for (const e of f.ends) out.push({ a: p, b: at(e.dir, e.trim), size: e.size });
  return out;
}
