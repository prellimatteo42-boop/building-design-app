/**
 * Import BIM Content / export it (Archicad's classification and property XML,
 * reimplemented from its documented structure): classification systems with
 * their item trees and property definition groups with their properties.
 *
 * <BuildingInformation>
 *   <Classification><System><Name/><EditionVersion/><Description/>
 *     <Items><Item><ID/><Name/><Description/><Children><Item>…</Item></Children></Item></Items>
 *   </System></Classification>
 *   <PropertyDefinitionGroups><PropertyDefinitionGroup><Name/><Description/>
 *     <PropertyDefinitions><PropertyDefinition><Name/><Description/>
 *       <ValueDescriptor type="SingleValueDescriptor|EnumerationValueDescriptor"><ValueType>String|Integer|Real|
 *         Length|Area|Volume|Angle|Boolean</ValueType><Values><EnumerationValue><Value>…</Value></EnumerationValue></Values>
 *         </ValueDescriptor>
 *       <Classifications><ClassificationID><ItemID/><SystemName/></ClassificationID></Classifications>
 *     </PropertyDefinition></PropertyDefinitions>
 *   </PropertyDefinitionGroup></PropertyDefinitionGroups>
 * </BuildingInformation>
 */

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
const decode = (s) => s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => (e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1)) : ENT[e] ?? m));
const encode = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** A small XML reader: { tag, attrs, children, text } (enough for these files). */
export function parseXML(text) {
  const root = { tag: '#root', attrs: {}, children: [], text: '' };
  const stack = [root];
  const re = /<!--[\s\S]*?-->|<!\[CDATA\[([\s\S]*?)\]\]>|<\?[\s\S]*?\?>|<!DOCTYPE[^>]*>|<\/([^\s>]+)\s*>|<([^\s/>]+)((?:\s+[^\s=]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|([^<]+)/g;
  let m;
  while ((m = re.exec(text))) {
    const top = stack.at(-1);
    if (m[1] != null) top.text += m[1];
    else if (m[2]) {
      if (stack.length > 1 && stack.at(-1).tag === m[2]) stack.pop();
    } else if (m[3]) {
      const attrs = {};
      for (const a of m[4].matchAll(/([^\s=]+)\s*=\s*("([^"]*)"|'([^']*)')/g)) attrs[a[1]] = decode(a[3] ?? a[4] ?? '');
      const node = { tag: m[3], attrs, children: [], text: '' };
      top.children.push(node);
      if (!m[5]) stack.push(node);
    } else if (m[6]) top.text += decode(m[6]);
  }
  return root;
}

const kids = (n, tag) => (n?.children || []).filter((c) => c.tag === tag);
const kid = (n, tag) => kids(n, tag)[0] || null;
const txt = (n, tag) => (kid(n, tag)?.text || '').trim();

const TYPE_IN = { string: 'text', integer: 'number', real: 'number', number: 'number', length: 'length', area: 'area', volume: 'volume', angle: 'angle', boolean: 'bool' };
const TYPE_OUT = { text: 'String', number: 'Real', length: 'Length', area: 'Area', volume: 'Volume', angle: 'Angle', bool: 'Boolean', choice: 'String', multi: 'String', list: 'String' };

/** The content of a BIM content XML: { systems: [{ name, edition, items }], groups: [{ name, description, props }] }. */
export function parseBIMContent(text) {
  const root = parseXML(text);
  const bi = kid(root, 'BuildingInformation') || root;
  const systems = [];
  for (const cls of kids(bi, 'Classification'))
    for (const sys of kids(cls, 'System')) {
      const items = [];
      const walk = (list, parent) => {
        for (const it of kids(list, 'Item')) {
          const code = txt(it, 'ID');
          if (!code) continue;
          items.push({ code, name: txt(it, 'Name') || code, description: txt(it, 'Description'), parent });
          walk(kid(it, 'Children'), code);
        }
      };
      walk(kid(sys, 'Items'), null);
      systems.push({ name: txt(sys, 'Name') || 'Classification', edition: txt(sys, 'EditionVersion'), description: txt(sys, 'Description'), items });
    }
  const groups = [];
  for (const gs of kids(bi, 'PropertyDefinitionGroups'))
    for (const g of kids(gs, 'PropertyDefinitionGroup')) {
      const props = [];
      for (const pd of kids(kid(g, 'PropertyDefinitions'), 'PropertyDefinition')) {
        const vd = kid(pd, 'ValueDescriptor');
        const vt = txt(vd, 'ValueType').toLowerCase();
        const options = kids(kid(vd, 'Values'), 'EnumerationValue').map((e) => txt(e, 'Value') || (e.text || '').trim()).filter(Boolean);
        const multiple = /multiple/i.test(vd?.attrs?.type || '') || txt(vd, 'MultipleChoice') === 'true';
        const type = options.length ? (multiple ? 'multi' : 'choice') : TYPE_IN[vt] || 'text';
        const classes = kids(kid(pd, 'Classifications'), 'ClassificationID').map((c) => ({ system: txt(c, 'SystemName'), code: txt(c, 'ItemID') })).filter((c) => c.code);
        props.push({ name: txt(pd, 'Name'), description: txt(pd, 'Description'), type, options, classes });
      }
      groups.push({ name: txt(g, 'Name') || 'Properties', description: txt(g, 'Description'), props: props.filter((p) => p.name) });
    }
  return { systems, groups };
}

/**
 * Bring BIM content into a document (inside a transaction): systems replace their items when one of that name
 * exists (keeping its IFC mappings by code) or are added; groups and properties are added or updated by name.
 * Returns { systems, items, groups, properties } counts.
 */
export function applyBIMContent(doc, content) {
  const n = { systems: 0, items: 0, groups: 0, properties: 0 };
  for (const s of content.systems) {
    const old = doc.all('classSystem').find((x) => x.name === s.name);
    const prev = new Map((old?.items || []).map((i) => [i.code, i]));
    const items = s.items.map((i) => ({ ...(prev.get(i.code) || { ifc: null, kinds: [], cats: [] }), code: i.code, name: i.name, parent: i.parent, description: i.description || undefined }));
    if (old) doc.update(old.id, { items, edition: s.edition || old.edition });
    else doc.add({ kind: 'classSystem', name: s.name, edition: s.edition || '', items });
    n.systems++;
    n.items += items.length;
  }
  const sysId = (name) => doc.all('classSystem').find((x) => x.name === name)?.id || doc.all('classSystem')[0]?.id;
  for (const g of content.groups) {
    if (!doc.all('propertyGroup').some((x) => x.name === g.name)) doc.add({ kind: 'propertyGroup', name: g.name, description: g.description || '' });
    n.groups++;
    for (const p of g.props) {
      const fields = { name: p.name, type: p.type, group: g.name, description: p.description || '', options: p.options?.length ? p.options : undefined, classes: p.classes.map((c) => ({ system: sysId(c.system), code: c.code })) };
      const old = doc.all('projectParam').find((x) => x.name === p.name && (x.group || '') === g.name);
      if (old) doc.update(old.id, fields);
      else doc.add({ kind: 'projectParam', categories: [], ...fields });
      n.properties++;
    }
  }
  return n;
}

/** The project's classification systems and own property groups as BIM content XML. */
export function writeBIMContent(doc) {
  const out = ['<?xml version="1.0" encoding="UTF-8"?>', '<BuildingInformation>', '  <Classification>'];
  for (const s of doc.all('classSystem')) {
    out.push('    <System>', `      <Name>${encode(s.name)}</Name>`, `      <EditionVersion>${encode(s.edition || '')}</EditionVersion>`, '      <Items>');
    const write = (parent, depth) => {
      for (const it of s.items.filter((i) => (i.parent || null) === parent)) {
        const pad = '  '.repeat(depth);
        out.push(`${pad}<Item>`, `${pad}  <ID>${encode(it.code)}</ID>`, `${pad}  <Name>${encode(it.name)}</Name>`);
        if (it.description) out.push(`${pad}  <Description>${encode(it.description)}</Description>`);
        const sub = s.items.some((i) => i.parent === it.code);
        if (sub) {
          out.push(`${pad}  <Children>`);
          write(it.code, depth + 2);
          out.push(`${pad}  </Children>`);
        }
        out.push(`${pad}</Item>`);
      }
    };
    write(null, 4);
    out.push('      </Items>', '    </System>');
  }
  out.push('  </Classification>', '  <PropertyDefinitionGroups>');
  const groups = new Map();
  for (const p of doc.all('projectParam')) {
    if (p.type === 'expression') continue;
    const g = p.group || 'Identity Data';
    if (!groups.has(g)) groups.set(g, []);
    groups.get(g).push(p);
  }
  for (const [g, props] of groups) {
    out.push('    <PropertyDefinitionGroup>', `      <Name>${encode(g)}</Name>`, '      <PropertyDefinitions>');
    for (const p of props) {
      const enumd = p.type === 'choice' || p.type === 'multi';
      out.push('        <PropertyDefinition>', `          <Name>${encode(p.name)}</Name>`, `          <Description>${encode(p.description || '')}</Description>`);
      out.push(`          <ValueDescriptor type="${enumd ? 'EnumerationValueDescriptor' : 'SingleValueDescriptor'}">`, `            <ValueType>${TYPE_OUT[p.type] || 'String'}</ValueType>`);
      if (p.type === 'multi') out.push('            <MultipleChoice>true</MultipleChoice>');
      if (enumd) out.push('            <Values>', ...(p.options || []).map((o) => `              <EnumerationValue><Value>${encode(o)}</Value></EnumerationValue>`), '            </Values>');
      out.push('          </ValueDescriptor>');
      if (p.classes?.length) {
        out.push('          <Classifications>');
        for (const c of p.classes) out.push('            <ClassificationID>', `              <ItemID>${encode(c.code)}</ItemID>`, `              <SystemName>${encode(doc.get(c.system)?.name || '')}</SystemName>`, '            </ClassificationID>');
        out.push('          </Classifications>');
      }
      out.push('        </PropertyDefinition>');
    }
    out.push('      </PropertyDefinitions>', '    </PropertyDefinitionGroup>');
  }
  out.push('  </PropertyDefinitionGroups>', '</BuildingInformation>', '');
  return out.join('\n');
}
