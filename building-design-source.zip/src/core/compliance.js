/**
 * Checking a design against the requirements a building code sets for
 * dwellings. The Italian rules of the DM 5 July 1975 (requisiti
 * igienico-sanitari) and the DM 236/1989 door widths come built in:
 *
 *   - rooms people live in at least 2.70 m high, service rooms (bathrooms,
 *     corridors, storerooms) at least 2.40 m;
 *   - a single bedroom at least 9 m², a double one 14 m², the living room 14 m²;
 *   - windows in rooms people live in at least 1/8 of their floor;
 *   - a bathroom without a window needs mechanical ventilation;
 *   - a one-room dwelling at least 28 m² (one person) or 38 m² (two);
 *   - doors at least 0.80 m wide at the entrance and 0.75 m inside.
 *
 * Each room's use is read from its name, in Italian, English, Ukrainian,
 * Russian, French, German and Spanish.
 */
import { openingSize, levelElevation } from './model.js';
import { pointInPolygon, dist } from './geom.js';

export const RULESETS = {
  'it-dm1975': {
    name: 'Italy: DM 5/7/1975 and DM 236/1989',
    minHeight: 2700,
    minHeightService: 2400,
    bedroomSingle: 9,
    bedroomDouble: 14,
    living: 14,
    daylight: 1 / 8,
    studioOne: 28,
    studioTwo: 38,
    entranceDoor: 800,
    innerDoor: 750,
  },
};

const USES = [
  ['bath', /(bagn|wc|toilet|bath|servizi|ванн|санвуз|с\/у|туалет|salle d.eau|salle de bain|\bbad\b|baño|aseo|douche|doccia)/i],
  ['bedroomDouble', /(matrimonial|doppia|double|master|мастер|двоспал|parentale|matrimonio)/i],
  ['bedroom', /(camer|letto|bedroom|спальн|chambre|schlafzimmer|dormitorio|habitaci)/i],
  ['living', /(soggiorn|salott|living|lounge|вітальн|гостин|зал\b|séjour|salon|wohnzimmer|salón|sala\b|estar)/i],
  ['kitchen', /(cucin|kitchen|кухн|cuisine|küche|kueche|cocina)/i],
  ['study', /(studio|study|office|кабінет|кабинет|bureau|arbeitszimmer|despacho)/i],
  ['service', /(corridoi|disimpegn|ingress|hall|entrance|corridor|коридор|хол|передпок|прихож|rispostigl|ripostigl|storage|комор|кладов|lavanderi|laundry|пральн|dressing|guardarob|garage|cantina|couloir|entrée|flur|diele|pasillo|recibidor|scala|stair)/i],
];

/** The use of a room from its name: bedroomDouble, bedroom, living, kitchen, study, bath, service, or other. */
export function roomUse(name) {
  for (const [use, re] of USES) if (re.test(String(name || ''))) return use;
  return 'other';
}

const HABITABLE = new Set(['bedroom', 'bedroomDouble', 'living', 'kitchen', 'study']);

/**
 * Check a document. scene gives each room's region (scene.rooms.room).
 * Returns findings: [{ rule, severity ('error', 'warning'), message, ids, value, limit }].
 */
export function checkCompliance(doc, scene, { ruleset = 'it-dm1975' } = {}) {
  const R = RULESETS[ruleset] || RULESETS['it-dm1975'];
  const out = [];
  const m2 = (a) => `${(a / 1e6).toFixed(2)} m²`;
  const label = (r) => `${r.name || 'Room'}${r.number ? ` ${r.number}` : ''}`;
  const rooms = doc.all('room').map((r) => ({ el: r, region: scene.rooms.room(r), use: roomUse(r.name) })).filter((x) => x.region);
  // Each window and door at the middle of its opening, with the wall's thickness.
  const openings = doc.all('window', 'door').map((o) => {
    const host = doc.get(o.hostId);
    if (!host?.a || !host?.b) return null;
    const L = dist(host.a, host.b) || 1;
    const t = Math.max(0, Math.min(L, +o.t || 0));
    const at = [host.a[0] + ((host.b[0] - host.a[0]) * t) / L, host.a[1] + ((host.b[1] - host.a[1]) * t) / L];
    const size = openingSize(doc, o);
    const type = doc.get(host.typeId);
    const thick = (type?.layers || []).reduce((s, l) => s + (+l.thickness || 0), 0) || 300;
    return { el: o, at, size, reach: thick / 2 + 150, exterior: type?.function === 'exterior' };
  }).filter(Boolean);
  // An opening serves a room when its middle lies on the room's outline, within the wall.
  const onEdge = (p, poly, reach) => {
    if (pointInPolygon(p, poly)) return true;
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i];
      const b = poly[(i + 1) % poly.length];
      const L2 = (b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 || 1;
      const s = Math.max(0, Math.min(1, ((p[0] - a[0]) * (b[0] - a[0]) + (p[1] - a[1]) * (b[1] - a[1])) / L2));
      if (Math.hypot(p[0] - a[0] - s * (b[0] - a[0]), p[1] - a[1] - s * (b[1] - a[1])) <= reach) return true;
    }
    return false;
  };
  for (const { el, region, use } of rooms) {
    const area = region.area;
    const name = label(el);
    // Height: the room's own, else its level's to the next.
    const lv = doc.get(el.levelId);
    const above = lv && doc.levelAbove(lv.id);
    const height = +el.upperOffset || (above ? levelElevation(doc, above.id) - levelElevation(doc, lv.id) : 0);
    const needH = HABITABLE.has(use) ? R.minHeight : use === 'bath' || use === 'service' ? R.minHeightService : 0;
    if (needH && height && height < needH - 1) out.push({ rule: 'height', severity: 'error', ids: [el.id], value: height, limit: needH, message: `${name} is ${(height / 1000).toFixed(2)} m high: a ${HABITABLE.has(use) ? 'room people live in' : 'service room'} needs ${(needH / 1000).toFixed(2)} m (DM 5/7/1975, art. 1).` });
    if (use === 'bedroomDouble' && area < R.bedroomDouble * 1e6 - 1e3) out.push({ rule: 'bedroom', severity: 'error', ids: [el.id], value: area, limit: R.bedroomDouble * 1e6, message: `${name} is ${m2(area)}: a double bedroom needs ${R.bedroomDouble} m² (DM 5/7/1975, art. 2).` });
    if (use === 'bedroom' && area < R.bedroomSingle * 1e6 - 1e3) out.push({ rule: 'bedroom', severity: 'error', ids: [el.id], value: area, limit: R.bedroomSingle * 1e6, message: `${name} is ${m2(area)}: a bedroom needs at least ${R.bedroomSingle} m² (${R.bedroomDouble} m² for two) (DM 5/7/1975, art. 2).` });
    if (use === 'bedroom' && area >= R.bedroomSingle * 1e6 && area < R.bedroomDouble * 1e6 - 1e3) out.push({ rule: 'bedroom', severity: 'warning', ids: [el.id], value: area, limit: R.bedroomDouble * 1e6, message: `${name} is ${m2(area)}: enough for one person; two need ${R.bedroomDouble} m².` });
    if (use === 'living' && area < R.living * 1e6 - 1e3) out.push({ rule: 'living', severity: 'error', ids: [el.id], value: area, limit: R.living * 1e6, message: `${name} is ${m2(area)}: the living room needs ${R.living} m² (DM 5/7/1975, art. 2).` });
    const serving = openings.filter((o) => onEdge(o.at, region.outer, o.reach));
    const windows = serving.filter((o) => o.el.kind === 'window');
    const glazed = windows.reduce((s, o) => s + o.size.width * o.size.height, 0);
    if (HABITABLE.has(use) && glazed < R.daylight * area - 1e3) out.push({ rule: 'daylight', severity: 'error', ids: [el.id, ...windows.map((o) => o.el.id)], value: glazed, limit: R.daylight * area, message: `${name} has ${m2(glazed)} of windows for ${m2(area)} of floor: it needs 1/${Math.round(1 / R.daylight)}, ${m2(R.daylight * area)} (DM 5/7/1975, art. 5).` });
    if (use === 'bath' && !windows.length) out.push({ rule: 'ventilation', severity: 'warning', ids: [el.id], message: `${name} has no window: it needs mechanical ventilation (DM 5/7/1975, art. 7).` });
  }
  // A dwelling of one room people live in.
  const living = rooms.filter((r) => HABITABLE.has(r.use));
  if (living.length === 1) {
    const total = rooms.reduce((s, r) => s + r.region.area, 0);
    if (total < R.studioOne * 1e6 - 1e3) out.push({ rule: 'dwelling', severity: 'error', ids: rooms.map((r) => r.el.id), value: total, limit: R.studioOne * 1e6, message: `A one-room dwelling of ${m2(total)}: it needs ${R.studioOne} m² for one person, ${R.studioTwo} m² for two, bathroom included (DM 5/7/1975, art. 3).` });
  }
  // Door widths: the entrance (a door in an exterior wall) and the doors inside.
  for (const o of openings.filter((x) => x.el.kind === 'door')) {
    const need = o.exterior ? R.entranceDoor : R.innerDoor;
    if (o.size.width < need - 1) out.push({ rule: 'door', severity: 'warning', ids: [o.el.id], value: o.size.width, limit: need, message: `Door ${o.el.mark || ''} is ${Math.round(o.size.width)} mm wide: ${o.exterior ? 'an entrance' : 'a door inside'} needs ${need} mm (DM 236/1989, 8.1.1).`.replace('Door  is', 'A door is') });
  }
  return out;
}
