/**
 * Sheets: paper layout in millimetres with an original title block and
 * viewports showing views at their scale. Plan views are placed as
 * vectors (their plan graphics transformed to paper space); 3D views,
 * elevations and sections are placed as rendered images.
 */
import { PlanBuilder, W, INK, BG } from './plan.js';
import { SHEET_SIZES } from './props.js';
import { bboxUnion } from './geom.js';
import { scaleLabel } from './units.js';
import { revisionsOnSheet } from './revisions.js';
import { sheetText } from './masters.js';

export function sheetSize(sheet) {
  return SHEET_SIZES.find((s) => s.id === sheet.size) || SHEET_SIZES[2];
}

/** The scales of the views placed on a sheet, for the {Scales} autotext. */
function sheetScales(doc, sheet) {
  const scales = new Set();
  const ref = doc.get(sheet.autotextRef);
  for (const vp of doc.all('viewport')) {
    if (vp.viewId !== sheet.id || (ref && vp.id !== ref.id)) continue;
    const v = doc.get(vp.placedId);
    if (v && v.kind !== 'view3d' && +v.scale) scales.add(+v.scale);
  }
  return [...scales].sort((a, b) => a - b).map((s) => scaleLabel(s, doc.units)).join(', ') || 'As shown';
}

/** {Drawing Name} and {Drawing Scale}: the autotext reference drawing, or the layout's first drawing. */
function drawingAutotext(doc, sheet) {
  const vp = doc.get(sheet.autotextRef) || doc.all('viewport').find((v) => v.viewId === sheet.id);
  const view = vp && doc.get(vp.placedId);
  return { 'drawing name': view?.name || '', 'drawing scale': view && +view.scale ? scaleLabel(+view.scale, doc.units) : '' };
}

/** Paper with its surroundings greyed and a border at the margin. */
function paper(b, w, H, m) {
  b.fill(
    [
      [-5000, -5000],
      [w + 5000, -5000],
      [w + 5000, H + 5000],
      [-5000, H + 5000],
    ],
    [
      [
        [0, 0],
        [0, H],
        [w, H],
        [w, 0],
      ],
    ],
    INK(22),
  );
  b.poly(
    [
      [0, 0],
      [w, 0],
      [w, H],
      [0, H],
    ],
    true,
    W.thin,
  );
  b.poly(
    [
      [m, m],
      [w - m, m],
      [w - m, H - m],
      [m, H - m],
    ],
    true,
    W.heavy,
  );
}

/** Revisions clouded on a sheet, newest at the bottom, just above the sheet name in a title strip. */
function revisionsBlock(b, doc, sheet, x0, strip, w, m) {
  const revs = revisionsOnSheet(doc, sheet).slice(-8);
  if (revs.length) {
    const rh = 6;
    const top = m + 62 + (revs.length + 1) * rh + 6;
    const cx = [x0 + 3, x0 + 14, x0 + strip - 26];
    b.line([x0, top], [w - m, top], W.medium);
    b.text([x0 + 3, top - 3], 'REVISIONS', { size: 1.8, align: 'left', color: INK(150) });
    revs.forEach((r, i) => {
      const yy = top - rh * (i + 1) - 3;
      b.line([x0, yy - rh / 2], [w - m, yy - rh / 2], W.thin, 0, INK(90));
      b.text([cx[0], yy], String(r.number ?? r.seq), { size: 2.2, align: 'left', bold: true });
      b.text([cx[1], yy], clip(r.description || '', Math.floor((strip - 42) / 1.4)), { size: 2.2, align: 'left' });
      b.text([cx[2], yy], r.date || '', { size: 2, align: 'left' });
    });
  }
}

/** Sheet name and number at the bottom of a title strip. */
function sheetNameBlock(b, sheet, x0, strip, w, m) {
  const nb = m + 34;
  b.line([x0, nb], [w - m, nb], W.medium);
  b.text([x0 + 3, nb + 20], 'SHEET NAME', { size: 1.8, align: 'left', color: INK(150) });
  b.text([x0 + 3, nb + 12], sheet.name || '', { size: 3.6, align: 'left', bold: true });
  b.line([x0, nb + 28], [w - m, nb + 28], W.thin);
  b.text([x0 + 3, m + 30], 'SHEET', { size: 1.8, align: 'left', color: INK(150) });
  b.text([x0 + strip / 2, m + 15], sheet.number || '', { size: 10, bold: true });
}

/** Title block of a master layout: a strip on the right, a bar at the bottom, or none. */
function masterTitleBlock(doc, sheet, master) {
  const { w, h: H } = sheetSize(sheet);
  const b = new PlanBuilder();
  const m = Number.isFinite(+master.margin) ? +master.margin : 10;
  paper(b, w, H, m);
  const extra = { scales: sheetScales(doc, sheet), ...drawingAutotext(doc, sheet) };
  const T = (t) => sheetText(doc, sheet, t, extra);
  const rows = master.rows || [];
  if (master.strip === 'bottom') {
    const bar = 34;
    const y1 = m + bar;
    b.line([m, y1], [w - m, y1], W.medium);
    const numW = 60;
    const cells = rows.length || 1;
    const cw = (w - 2 * m - numW) / cells;
    rows.forEach((r, i) => {
      const x = m + i * cw;
      if (i) b.line([x, m], [x, y1], W.thin);
      b.text([x + 3, y1 - 4], r.label || '', { size: 1.8, align: 'left', baseline: 'middle', color: INK(150) });
      b.text([x + 3, m + bar * 0.4], clip(T(r.text), Math.floor(cw / ((+r.size || 2.6) * 0.62))), { size: +r.size || 2.6, align: 'left', baseline: 'middle', bold: (+r.size || 0) > 3.2 });
    });
    const xn = w - m - numW;
    b.line([xn, m], [xn, y1], W.medium);
    b.text([xn + 3, y1 - 4], 'SHEET', { size: 1.8, align: 'left', color: INK(150) });
    b.text([xn + 3, y1 - 10], clip(sheet.name || '', 26), { size: 2.2, align: 'left', bold: true });
    b.text([xn + numW / 2, m + 9], sheet.number || '', { size: 8, bold: true });
    return { builder: b, area: { x0: m + 5, y0: y1 + 5, x1: w - m - 5, y1: H - m - 5 } };
  }
  if (master.strip === 'none') return { builder: b, area: { x0: m + 5, y0: m + 5, x1: w - m - 5, y1: H - m - 5 } };
  const strip = Math.min(130, w * 0.18);
  const x0 = w - m - strip;
  b.line([x0, m], [x0, H - m], W.medium);
  let y = H - m;
  for (const r of rows) {
    const size = +r.size || 2.6;
    const rh = Math.max(12, size * 3 + 6);
    y -= rh;
    b.line([x0, y], [w - m, y], W.thin);
    b.text([x0 + 3, y + rh - 3.2], r.label || '', { size: 1.8, align: 'left', baseline: 'middle', color: INK(150) });
    b.text([x0 + 3, y + rh * 0.42], clip(T(r.text), Math.floor((strip - 6) / (size * 0.62))), { size, align: 'left', baseline: 'middle', bold: size > 3.5 });
  }
  revisionsBlock(b, doc, sheet, x0, strip, w, m);
  sheetNameBlock(b, sheet, x0, strip, w, m);
  return { builder: b, area: { x0: m + 5, y0: m + 5, x1: x0 - 5, y1: H - m - 5 } };
}

/** Title block and border graphics in paper millimetres. */
export function titleBlock(doc, sheet, { master: showMaster = true } = {}) {
  // Master Items on Layout off: the paper alone.
  if (!showMaster) {
    const { w, h: H } = sheetSize(sheet);
    const b = new PlanBuilder();
    const m = 10;
    paper(b, w, H, m);
    return { builder: b, area: { x0: m + 5, y0: m + 5, x1: w - m - 5, y1: H - m - 5 } };
  }
  // A master layout opened as a window: its title block on a sample layout.
  if (sheet.kind === 'masterLayout') return masterTitleBlock(doc, { id: sheet.id, kind: 'sheet', name: 'Layout Name', number: 'A000', size: sheet.size, masterId: sheet.id }, sheet);
  const master = sheet.masterId ? doc.get(sheet.masterId) : null;
  if (master?.kind === 'masterLayout') return masterTitleBlock(doc, sheet, master);
  const { w, h: H } = sheetSize(sheet);
  const b = new PlanBuilder();
  const m = 10;
  const strip = Math.min(130, w * 0.18);
  paper(b, w, H, m);
  const x0 = w - m - strip;
  b.line([x0, m], [x0, H - m], W.medium);
  const p = doc.project;
  const rows = [
    { label: 'PROJECT', value: p.name, size: 4.2, h: 26 },
    { label: 'PROJECT NUMBER', value: p.number, size: 3, h: 14 },
    { label: 'CLIENT', value: p.client, size: 3, h: 14 },
    { label: 'ADDRESS', value: p.address, size: 2.6, h: 14 },
    { label: 'DRAWN BY', value: sheet.drawnBy || p.author, size: 2.6, h: 12 },
    { label: 'CHECKED BY', value: sheet.checkedBy, size: 2.6, h: 12 },
    { label: 'DATE', value: sheet.issueDate || new Date().toISOString().slice(0, 10), size: 2.6, h: 12 },
    { label: 'STATUS', value: p.status, size: 2.6, h: 12 },
  ];
  let y = H - m;
  for (const r of rows) {
    y -= r.h;
    b.line([x0, y], [w - m, y], W.thin);
    b.text([x0 + 3, y + r.h - 3.2], r.label, { size: 1.8, align: 'left', baseline: 'middle', color: INK(150) });
    b.text([x0 + 3, y + r.h * 0.42], r.value || '', { size: r.size, align: 'left', baseline: 'middle', bold: r.size > 3.5 });
  }
  revisionsBlock(b, doc, sheet, x0, strip, w, m);
  sheetNameBlock(b, sheet, x0, strip, w, m);
  return { builder: b, area: { x0: m + 5, y0: m + 5, x1: x0 - 5, y1: H - m - 5 } };
}

function clip(s, n) {
  return s.length > n ? `${s.slice(0, Math.max(1, n - 1))}…` : s;
}

/**
 * Paper-space graphics for a plan viewport: every element of the placed
 * view transformed by p' = at + (p - center) / scale.
 */
export function planViewportGraphics(scene, view, viewport, pc) {
  const els = scene.planCandidates(view);
  const parts = [];
  let bounds = null;
  for (const el of els) {
    if (el.kind === 'section' || el.kind === 'elevation') continue;
    const g = scene.planOf(view, el, pc);
    if (!g) continue;
    parts.push({ el, g });
    bounds = bboxUnion(bounds, scene.planBounds(view, el.id));
  }
  const s = +view.scale || 100;
  const center = viewport.center || (bounds ? [(bounds.x0 + bounds.x1) / 2, (bounds.y0 + bounds.y1) / 2] : [0, 0]);
  const at = viewport.at;
  const T = (p) => [at[0] + (p[0] - center[0]) / s, at[1] + (p[1] - center[1]) / s];
  // One transformed builder per element keeps the draw order of plans.
  const natural = bounds ? [(bounds.x1 - bounds.x0) / s, (bounds.y1 - bounds.y0) / s] : [100, 80];
  // A drawing cropped to its frame (Archicad: Crop Drawing to Frame) shows only what lies inside it.
  const size = viewport.cropped && viewport.frame ? viewport.frame : natural;
  const rect = { x0: at[0] - size[0] / 2, y0: at[1] - size[1] / 2, x1: at[0] + size[0] / 2, y1: at[1] + size[1] / 2 };
  const crop = viewport.cropped && viewport.frame ? rect : null;
  const items = [];
  for (const { el, g } of parts) {
    const b = new PlanBuilder();
    for (const l of g.lines) {
      const c = crop ? clipSegment(T(l.a), T(l.b), crop) : [T(l.a), T(l.b)];
      if (c) b.lines.push({ ...l, a: c[0], b: c[1] });
    }
    for (const f of g.fills) {
      const poly = crop ? clipToRect(f.poly.map(T), crop) : f.poly.map(T);
      if (poly.length < 3) continue;
      const holes = (f.holes || []).map((hh) => (crop ? clipToRect(hh.map(T), crop) : hh.map(T))).filter((hh) => hh.length >= 3);
      b.fills.push({ ...f, poly, holes });
    }
    for (const t of g.texts) {
      const p = T(t.at);
      if (crop && (p[0] < crop.x0 || p[0] > crop.x1 || p[1] < crop.y0 || p[1] > crop.y1)) continue;
      b.texts.push({ ...t, at: p, size: t.size / s });
    }
    items.push({ key: `${viewport.id}:${el.id}`, kind: el.kind, builder: b });
  }
  const frame = new PlanBuilder();
  viewportTitle(frame, view, rect, scene.doc, viewport);
  frame.pick([
    [rect.x0, rect.y0],
    [rect.x1, rect.y0],
    [rect.x1, rect.y1],
    [rect.x0, rect.y1],
  ]);
  return { builder: frame, items, rect, center, natural };
}

/** A segment clipped to a rectangle (Liang-Barsky), or null when it lies outside. */
export function clipSegment(a, b, r) {
  let t0 = 0;
  let t1 = 1;
  const d = [b[0] - a[0], b[1] - a[1]];
  for (const [p, q] of [
    [-d[0], a[0] - r.x0],
    [d[0], r.x1 - a[0]],
    [-d[1], a[1] - r.y0],
    [d[1], r.y1 - a[1]],
  ]) {
    if (p === 0) {
      if (q < 0) return null;
    } else {
      const t = q / p;
      if (p < 0) t0 = Math.max(t0, t);
      else t1 = Math.min(t1, t);
    }
  }
  if (t1 < t0) return null;
  return [
    [a[0] + d[0] * t0, a[1] + d[1] * t0],
    [a[0] + d[0] * t1, a[1] + d[1] * t1],
  ];
}

/** A polygon clipped to a rectangle (Sutherland-Hodgman). */
export function clipToRect(poly, r) {
  let out = poly;
  for (const [axis, lim, keepAbove] of [
    [0, r.x0, true],
    [0, r.x1, false],
    [1, r.y0, true],
    [1, r.y1, false],
  ]) {
    const src = out;
    out = [];
    const inside = (p) => (keepAbove ? p[axis] >= lim : p[axis] <= lim);
    for (let i = 0; i < src.length; i++) {
      const p = src[i];
      const q = src[(i + 1) % src.length];
      if (inside(p)) out.push(p);
      if (inside(p) !== inside(q)) {
        const t = (lim - p[axis]) / (q[axis] - p[axis]);
        out.push([p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t]);
      }
    }
    if (out.length < 3) return [];
  }
  return out;
}

/**
 * Drawing title of a viewport, by its style: 'bubble' (number in a circle,
 * name and scale, the default), 'simple' (name underlined over the scale)
 * or 'none'. Its text can be autotext: {View Name}, {Scale}, {Number}.
 */
export function viewportTitle(b, view, rect, doc, vp = null) {
  const style = vp?.titleStyle || 'bubble';
  if (style === 'none') return;
  const scale = view.kind === 'view3d' ? '' : `Scale ${scaleLabel(+view.scale || 100, doc.units)}`;
  const values = { 'view name': view.name, scale: scale.replace(/^Scale /, ''), number: String(view.sheetNumber || '1') };
  const name = vp?.titleText ? vp.titleText.replace(/\{([^{}]+)\}/g, (_, k) => values[k.trim().toLowerCase()] ?? '?') : view.name;
  const y = rect.y0 - 8;
  const x = rect.x0;
  if (style === 'simple') {
    b.text([x, y + 1.6], name, { size: 3.2, align: 'left', bold: true });
    b.line([x, y - 0.8], [Math.max(x + 50, x + name.length * 2.2), y - 0.8], W.medium);
    if (scale) b.text([x, y - 3.6], scale, { size: 2.2, align: 'left' });
    return;
  }
  const circle = [];
  for (let i = 0; i < 28; i++) circle.push([x + 4.5 + Math.cos((i / 28) * Math.PI * 2) * 4.5, y + Math.sin((i / 28) * Math.PI * 2) * 4.5]);
  b.fill(circle, [], BG);
  b.poly(circle, true, W.light);
  b.text([x + 4.5, y], values.number, { size: 3 });
  b.text([x + 12, y + 1.6], name, { size: 3.2, align: 'left', bold: true });
  b.line([x + 10.5, y - 0.8], [Math.max(x + 60, x + 12 + name.length * 2.2), y - 0.8], W.medium);
  b.text([x + 12, y - 3.6], scale, { size: 2.2, align: 'left' });
}
