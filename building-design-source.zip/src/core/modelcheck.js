/**
 * Model Check Report (Archicad's Design > Model Check): every model check
 * in one report — Physical Model Quality, MEP Model Quality and the
 * Structural Analytical Model Quality — with each problem's elements,
 * exportable as CSV or Markdown.
 */
import { physicalQuality } from './modelquality.js';
import { mepQuality } from './mepnet.js';
import { analyticalModel, analyticalQuality } from './analytical.js';

/** { sections: [{ id, name, items: [{ check, message, ids }] }], total, date }. */
export function modelCheckReport(doc, scene, { date = new Date() } = {}) {
  const sections = [];
  const safe = (fn) => {
    try {
      return fn();
    } catch {
      return [];
    }
  };
  sections.push({ id: 'physical', name: 'Physical Model Quality', items: safe(() => physicalQuality(doc, scene)).map((x) => ({ check: x.check, message: x.message, ids: x.ids || [] })) });
  sections.push({ id: 'mep', name: 'MEP Model Quality', items: safe(() => mepQuality(doc)).map((x) => ({ check: x.kind, message: x.message, ids: x.ids || [] })) });
  sections.push({
    id: 'analytical',
    name: 'Structural Analytical Model Quality',
    items: safe(() => {
      const m = analyticalModel(doc);
      return m.members.length || m.surfaces.length ? analyticalQuality(m) : [];
    }).map((x) => ({ check: x.check, message: x.message, ids: x.ids || [] })),
  });
  return { sections, total: sections.reduce((s, x) => s + x.items.length, 0), date: date.toISOString().slice(0, 10) };
}

const csvCell = (v) => (/[",;\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));

/** The report as CSV: section, check, message, element ids. */
export function reportCSV(r) {
  const rows = [['Section', 'Check', 'Message', 'Elements']];
  for (const s of r.sections) for (const it of s.items) rows.push([s.name, it.check, it.message, it.ids.join(' ')]);
  return rows.map((row) => row.map(csvCell).join(',')).join('\n');
}

/** The report as Markdown. */
export function reportMarkdown(r, projectName = 'Project') {
  const out = [`# Model Check Report — ${projectName}`, '', `Date: ${r.date}. ${r.total} problem${r.total === 1 ? '' : 's'}.`, ''];
  for (const s of r.sections) {
    out.push(`## ${s.name} (${s.items.length})`, '');
    if (!s.items.length) out.push('No problems.', '');
    else {
      out.push('| Check | Message | Elements |', '|---|---|---|');
      for (const it of s.items) out.push(`| ${it.check} | ${String(it.message).replace(/\|/g, '/')} | ${it.ids.join(' ')} |`);
      out.push('');
    }
  }
  return out.join('\n');
}
