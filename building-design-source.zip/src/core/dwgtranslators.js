/**
 * DXF-DWG Translation Setup (Archicad's DXF-DWG translators, reimplemented):
 * named import setups kept in the project, each with the drawing unit
 * ('auto' from the file, or millimetres per unit), whether the drawing's
 * middle moves to the origin, solid fills, what the layers become ('smart'
 * model from layers and drafting, 'model', 'drafting'), the role of each
 * layer by name and the layers left out.
 *
 *   project.dwgTranslators [{ id, name, unit, centre, fills, mode, roles: { layer: role }, skip: [layer] }]
 *   project.dwgTranslatorId  the one imports start from
 */
import { newId } from './doc.js';

export const DWG_PRESETS = [
  { id: 'dwg-auto', name: 'Automatic (from the file)', unit: 'auto', centre: true, fills: true, mode: null, roles: {}, skip: [] },
  { id: 'dwg-drafting', name: 'Drafting only, in place', unit: 'auto', centre: false, fills: true, mode: 'drafting', roles: {}, skip: [] },
  { id: 'dwg-survey-m', name: 'Survey in metres', unit: '1000', centre: true, fills: false, mode: 'drafting', roles: {}, skip: [] },
];

export const DWG_UNITS = [
  { value: 'auto', label: 'From the file' },
  { value: '1', label: 'Millimetres' },
  { value: '10', label: 'Centimetres' },
  { value: '1000', label: 'Metres' },
  { value: '25.4', label: 'Inches' },
  { value: '304.8', label: 'Feet' },
];

export function dwgTranslators(doc) {
  const own = doc.get('project')?.dwgTranslators;
  return Array.isArray(own) && own.length ? own : DWG_PRESETS;
}

/** The translator imports start from (the project's chosen one, else the first). */
export function dwgTranslatorFor(doc, id = null) {
  const list = dwgTranslators(doc);
  return list.find((t) => t.id === (id || doc.get('project')?.dwgTranslatorId)) || list[0];
}

/** Add or replace (by name) a translator and make it the current one (inside a transaction). */
export function saveDwgTranslator(doc, t) {
  const list = [...dwgTranslators(doc)];
  const i = list.findIndex((x) => x.name === t.name);
  const item = { id: i >= 0 ? list[i].id : newId('dwg'), unit: 'auto', centre: true, fills: true, mode: null, roles: {}, skip: [], ...t };
  if (i >= 0) list[i] = item;
  else list.push(item);
  doc.update('project', { dwgTranslators: list, dwgTranslatorId: item.id });
  return item;
}
