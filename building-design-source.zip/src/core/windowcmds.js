/**
 * Window menu helpers (pure): the layouts in Layout Book order, and the
 * library loading report.
 */
import { testLibraryParts } from './libtools.js';
import { libraryOf } from './libmanager.js';

/** Layouts in the order of the Layout Book: by number (natural order), then name. */
export function layoutsInOrder(doc) {
  const coll = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
  return doc.all('sheet').slice().sort((a, b) => coll.compare(String(a.number ?? ''), String(b.number ?? '')) || coll.compare(String(a.name ?? ''), String(b.name ?? '')));
}

/** The layout after (step 1) or before (-1) the given one, round the book; the first when none is open. */
export function adjacentLayout(doc, currentId, step = 1) {
  const list = layoutsInOrder(doc);
  if (!list.length) return null;
  const i = list.findIndex((s) => s.id === currentId);
  if (i < 0) return step > 0 ? list[0] : list.at(-1);
  return list[(i + step + list.length) % list.length];
}

/**
 * Library Loading Report: per library, the parts loaded, the ones that run, those that draw nothing or fail, and the
 * GDL commands skipped (with how many parts use them).
 */
export function libraryLoadingReport(doc) {
  const results = testLibraryParts(doc);
  const byLib = new Map();
  for (const r of results) {
    const t = doc.get(r.id);
    const lib = libraryOf(t);
    const e = byLib.get(lib) || { library: lib, parts: 0, ok: 0, empty: 0, failed: 0, skipped: new Map(), problems: [] };
    e.parts++;
    if (r.error) {
      e.failed++;
      e.problems.push(`${r.name}: ${r.error}`);
    } else if (!r.ok) {
      e.empty++;
      e.problems.push(`${r.name}: draws nothing`);
    } else e.ok++;
    for (const u of r.unknown || []) e.skipped.set(u, (e.skipped.get(u) || 0) + 1);
    byLib.set(lib, e);
  }
  return [...byLib.values()].map((e) => ({ ...e, skipped: [...e.skipped].sort((a, b) => b[1] - a[1]) }));
}
