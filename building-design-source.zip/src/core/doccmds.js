/**
 * Document menu calculations: the area list (a zone's area worked out from
 * rectangles and triangles, as an area calculation sheet shows it) and the
 * component list (layers by material, and the components listed on types).
 *
 *   type.listing: [{ code, name, qty, unit, per: 'piece' | 'length' | 'area' | 'volume' }]
 */
import earcut from 'earcut';
import { verticalExtent, wallAxis } from './model.js';
import { netSlabArea, netWallArea } from './projectprefs.js';
import { typeThickness } from './catalog.js';

const close = (a, b) => Math.abs(a - b) < 0.5;

/** Rectangle pieces of an orthogonal polygon with holes, or null when an edge is not square to the axes. */
function rectanglePieces(loops) {
  const edges = [];
  for (const loop of loops)
    for (let i = 0; i < loop.length; i++) {
      const a = loop[i];
      const b = loop[(i + 1) % loop.length];
      if (!close(a[0], b[0]) && !close(a[1], b[1])) return null;
      if (!close(a[0], b[0])) edges.push({ x0: Math.min(a[0], b[0]), x1: Math.max(a[0], b[0]), y: a[1] });
    }
  const xs = [...new Set(edges.flatMap((e) => [e.x0, e.x1]))].sort((p, q) => p - q);
  const out = [];
  let open = [];
  for (let i = 0; i + 1 < xs.length; i++) {
    const [x0, x1] = [xs[i], xs[i + 1]];
    if (x1 - x0 < 0.5) continue;
    const m = (x0 + x1) / 2;
    const ys = edges.filter((e) => e.x0 <= m && e.x1 >= m).map((e) => e.y).sort((p, q) => p - q);
    const next = [];
    for (let k = 0; k + 1 < ys.length; k += 2) {
      // A band the same height as one in the strip before carries on as one rectangle.
      const same = open.find((r) => close(r.y0, ys[k]) && close(r.y1, ys[k + 1]) && close(r.x1, x0));
      if (same) {
        same.x1 = x1;
        next.push(same);
      } else {
        const r = { x0, x1, y0: ys[k], y1: ys[k + 1] };
        out.push(r);
        next.push(r);
      }
    }
    open = next;
  }
  return out.map((r) => ({ kind: 'rect', w: r.x1 - r.x0, h: r.y1 - r.y0, area: (r.x1 - r.x0) * (r.y1 - r.y0) }));
}

/** Triangle pieces of any polygon: base (the longest side) and height. */
function trianglePieces(outer, holes) {
  const pts = [...outer, ...holes.flat()];
  const starts = [];
  let n = outer.length;
  for (const h of holes) {
    starts.push(n);
    n += h.length;
  }
  const idx = earcut(pts.flat(), starts);
  const out = [];
  for (let i = 0; i < idx.length; i += 3) {
    const [a, b, c] = [pts[idx[i]], pts[idx[i + 1]], pts[idx[i + 2]]];
    const area = Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2;
    const base = Math.max(Math.hypot(b[0] - a[0], b[1] - a[1]), Math.hypot(c[0] - b[0], c[1] - b[1]), Math.hypot(a[0] - c[0], a[1] - c[1]));
    if (area > 1) out.push({ kind: 'tri', w: base, h: (2 * area) / base, area });
  }
  return out;
}

/** A polygon cut into rectangles when it is orthogonal, into triangles otherwise; the areas add up to its area. */
export function decomposeArea(outer, holes = []) {
  return rectanglePieces([outer, ...holes]) || trianglePieces(outer, holes);
}

const m2 = (v) => (v / 1e6).toFixed(2);
const m = (v) => (v / 1000).toFixed(2);

/** One piece as a sum: "4.21 x 6.10 = 25.68", "1/2 x 3.00 x 2.00 = 3.00". */
export function pieceFormula(p) {
  return `${p.kind === 'tri' ? '1/2 x ' : ''}${m(p.w)} x ${m(p.h)} = ${m2(p.area)}`;
}

/** The area list of the project's zones: [{ id, name, number, level, pieces, area }] (mm²). */
export function areaListRows(doc, rooms) {
  const out = [];
  for (const r of doc.all('room')) {
    const region = rooms.room(r);
    if (!region) continue;
    const pieces = decomposeArea(region.outer, region.holes || []);
    out.push({ id: r.id, name: r.name || 'Room', number: r.number || '', level: doc.get(r.levelId)?.name || '', pieces, area: region.area });
  }
  return out;
}

/** Length, area and volume of an element for listing (mm, mm², mm³). */
export function elementMeasure(doc, el) {
  const type = doc.get(el.typeId);
  if (el.kind === 'wall') {
    const ax = wallAxis(doc, el);
    const area = netWallArea(doc, el);
    return { length: ax.length, area, volume: area * ax.half * 2 };
  }
  if (el.kind === 'floor' || el.kind === 'roof' || el.kind === 'ceiling') {
    const area = netSlabArea(doc, el);
    return { length: 0, area, volume: area * (type ? typeThickness(type) : 0) };
  }
  if (el.kind === 'beam' && el.a && el.b) return { length: Math.hypot(el.b[0] - el.a[0], el.b[1] - el.a[1]), area: 0, volume: 0 };
  if (el.kind === 'column') {
    const { base, top } = verticalExtent(doc, el);
    return { length: top - base, area: 0, volume: 0 };
  }
  return { length: 0, area: 0, volume: 0 };
}

const LAYERED = ['wall', 'floor', 'roof', 'ceiling'];

/** Layers by material and thickness across the layered elements: [{ material, fn, thickness, count, area, volume }]. */
export function layerComponents(doc) {
  const map = new Map();
  for (const kind of LAYERED)
    for (const el of doc.all(kind)) {
      const layers = doc.get(el.typeId)?.layers;
      if (!layers?.length) continue;
      const { area } = elementMeasure(doc, el);
      for (const l of layers) {
        const material = doc.get(l.materialId)?.name || '?';
        const key = `${material}|${l.thickness}|${l.function}`;
        const row = map.get(key) || { material, fn: l.function || '', thickness: +l.thickness || 0, count: 0, area: 0, volume: 0 };
        row.count++;
        row.area += area;
        row.volume += area * (+l.thickness || 0);
        map.set(key, row);
      }
    }
  return [...map.values()].sort((a, b) => a.material.localeCompare(b.material) || a.thickness - b.thickness);
}

/** Quantity of a listed component on one element, in its own unit of measure. */
export function listedQuantity(item, measure) {
  const q = +item.qty || 0;
  if (item.per === 'length') return (q * measure.length) / 1000;
  if (item.per === 'area') return (q * measure.area) / 1e6;
  if (item.per === 'volume') return (q * measure.volume) / 1e9;
  return q;
}

/** The components listed on the types of placed elements, added up: [{ code, name, unit, count, quantity }]. */
export function listedComponents(doc) {
  const map = new Map();
  for (const el of doc.items.values()) {
    const list = el.typeId && doc.get(el.typeId)?.listing;
    if (!list?.length) continue;
    const measure = elementMeasure(doc, el);
    for (const item of list) {
      const key = `${item.code}|${item.name}|${item.unit}`;
      const row = map.get(key) || { code: item.code || '', name: item.name || '', unit: item.unit || '', count: 0, quantity: 0 };
      row.count++;
      row.quantity += listedQuantity(item, measure);
      map.set(key, row);
    }
  }
  return [...map.values()].sort((a, b) => String(a.code).localeCompare(String(b.code)));
}

/** A table as CSV text. */
export function toCSV(rows) {
  return rows.map((r) => r.map((v) => (/[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v))).join(',')).join('\n');
}

/** Rendering engines and image settings kept with a 3D view (view.renderSettings). */
export const RENDER_ENGINES = [
  { value: 'raytrace', label: 'Ray tracing (real light, slower)', patch: { style: 'realistic' } },
  { value: 'realistic', label: 'Realistic (materials, sun and shadows)', patch: { style: 'realistic' } },
  { value: 'soft', label: 'Consistent colors', patch: { style: 'consistent' } },
  { value: 'shaded', label: 'Basic shaded', patch: { style: 'shaded' } },
  { value: 'sketch', label: 'Sketch (white model, lines)', patch: { style: 'hidden', renderEdges: true } },
];
export const RENDER_DEFAULTS = { engine: 'realistic', exposure: 0, contrast: 0, saturation: 0, lampDimmer: 1 };

/**
 * Image settings on RGBA pixels, in place: exposure in stops, contrast and
 * saturation from -1 to 1 (0 leaves them alone).
 */
export function adjustPixels(data, { exposure = 0, contrast = 0, saturation = 0 } = {}) {
  if (!exposure && !contrast && !saturation) return data;
  const gain = 2 ** exposure;
  const c = contrast >= 0 ? 1 + contrast * 2 : 1 + contrast;
  const s = 1 + saturation;
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i] * gain;
    const g = data[i + 1] * gain;
    const b = data[i + 2] * gain;
    const y = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    data[i] = Math.max(0, Math.min(255, (y + (r - y) * s - 127.5) * c + 127.5));
    data[i + 1] = Math.max(0, Math.min(255, (y + (g - y) * s - 127.5) * c + 127.5));
    data[i + 2] = Math.max(0, Math.min(255, (y + (b - y) * s - 127.5) * c + 127.5));
  }
  return data;
}
