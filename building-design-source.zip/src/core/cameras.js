/**
 * Cameras placed in plan (Archicad's Camera tool): where the viewer stands
 * and what they look at. A 3D view can go to a camera, a camera can take the
 * 3D view's position, and the cameras in order make a fly-through path.
 *
 *   camera { kind: 'camera', levelId, name, at: [x, y], eyeHeight, target: [x, y], targetHeight, fov, order }
 */
import { levelElevation } from './model.js';
import { cameraEye, cameraLooking } from './flythrough.js';

export const CAMERA_DEFAULTS = { eyeHeight: 1600, targetHeight: 1600, fov: 60 };

/** Cameras in path order. */
export function camerasInOrder(doc) {
  return doc.all('camera').slice().sort((a, b) => (+a.order || 0) - (+b.order || 0));
}

/** The next free camera name and order. */
export function nextCamera(doc) {
  const all = doc.all('camera');
  return { name: `Camera ${all.length + 1}`, order: all.reduce((m, c) => Math.max(m, +c.order || 0), 0) + 1 };
}

/** The orbit camera of a 3D view that stands at this camera. */
export function orbitOfCamera(doc, el) {
  const z = levelElevation(doc, el.levelId) || 0;
  const eyeZ = z + (el.eyeHeight ?? CAMERA_DEFAULTS.eyeHeight);
  const targetZ = z + (el.targetHeight ?? CAMERA_DEFAULTS.targetHeight);
  return cameraLooking([el.at[0], el.at[1], eyeZ], [el.target[0], el.target[1], targetZ], { fov: +el.fov || CAMERA_DEFAULTS.fov });
}

/** The fields of a camera that stands where an orbit camera does, on a level. */
export function cameraFromOrbit(doc, orbit, levelId) {
  const z = levelElevation(doc, levelId) || 0;
  const eye = cameraEye(orbit);
  return { levelId, at: [eye[0], eye[1]], eyeHeight: eye[2] - z, target: [orbit.target[0], orbit.target[1]], targetHeight: orbit.target[2] - z, fov: +orbit.fov || CAMERA_DEFAULTS.fov };
}
