/**
 * Line weights, as Archicad's Pens: the printed thickness (mm) of each
 * line weight class drawings use, set per project. Screens show them in
 * proportion, and PDF and SVG exports print them at these widths.
 */
export const WEIGHT_CLASSES = [
  { i: 1, name: 'Thin', use: 'Hatches, furniture, thin detail lines' },
  { i: 2, name: 'Light', use: 'Layer joints, room separations, light outlines' },
  { i: 3, name: 'Medium', use: 'Seen edges, medium lines, door leaves' },
  { i: 4, name: 'Cut', use: 'Cut walls, columns and slabs' },
  { i: 5, name: 'Heavy', use: 'Wide lines, emphasised outlines' },
];

export const DEFAULT_WEIGHTS_MM = [0.13, 0.13, 0.18, 0.25, 0.35, 0.5, 0.7, 1.0];

/** The printed widths in mm by weight class index (0 to 7). */
export function weightsOf(doc) {
  const w = doc?.project?.lineWeights;
  return DEFAULT_WEIGHTS_MM.map((d, i) => (Array.isArray(w) && +w[i] > 0 ? +w[i] : d));
}

/** On-screen widths in CSS pixels for the printed widths. */
export function screenWeights(mm) {
  return new Float32Array(mm.map((x) => Math.max(1, Math.round(x * 7.6 * 10) / 10)));
}
