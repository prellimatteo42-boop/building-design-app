/**
 * Boolean operations on plan polygons with holes, as Archicad's Add to
 * Polygon, Subtract from Polygon and merging fills: union, subtraction and
 * intersection. Each shape becomes a thin prism, the solids are combined
 * by CSG (csg.js), and the outline of the top faces is traced back.
 *
 *   shape { boundary: [[x, y], ...], holes: [[...], ...] }
 */
import { MeshBuilder } from './mesh.js';
import { meshPolygons, union, subtract, intersect } from './csg.js';
import { signedArea, pointInPolygon } from './geom.js';

const H = 1000;
const OPS = { union, subtract, intersect };

function solid(shape) {
  const b = new MeshBuilder();
  b.prism(shape.boundary, shape.holes || [], 0, H, [0, 0, 0, 255], { edges: false });
  return meshPolygons(b);
}

const K = (p) => `${Math.round(p[0] * 100)},${Math.round(p[1] * 100)}`;

/** Closed outlines traced from the top faces of solid polygons: [{ boundary, holes }]. */
function outlines(polys) {
  const tops = polys.filter((p) => p.plane.n[2] > 0.999 && Math.abs(p.plane.w - H) < 1e-2).map((p) => p.vs.map((v) => [v.p[0], v.p[1]]));
  // All corners, to split edges that pass through other faces' corners (T-junctions).
  const pts = new Map();
  for (const t of tops) for (const p of t) pts.set(K(p), p);
  const all = [...pts.values()];
  const edges = new Map();
  const addEdge = (a, b) => {
    const ka = K(a);
    const kb = K(b);
    if (ka === kb) return;
    const back = `${kb}>${ka}`;
    if (edges.has(back)) {
      const n = edges.get(back);
      if (n.count > 1) n.count--;
      else edges.delete(back);
      return;
    }
    const key = `${ka}>${kb}`;
    if (edges.has(key)) edges.get(key).count++;
    else edges.set(key, { a, b, count: 1 });
  };
  for (const t of tops)
    for (let i = 0; i < t.length; i++) {
      const a = t[i];
      const b = t[(i + 1) % t.length];
      const dx = b[0] - a[0];
      const dy = b[1] - a[1];
      const L2 = dx * dx + dy * dy;
      if (L2 < 1e-8) continue;
      const on = [];
      for (const p of all) {
        const s = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2;
        if (s <= 1e-6 || s >= 1 - 1e-6) continue;
        const cross = (p[0] - a[0]) * dy - (p[1] - a[1]) * dx;
        if (Math.abs(cross) / Math.sqrt(L2) < 0.01) on.push([s, p]);
      }
      on.sort((x, y) => x[0] - y[0]);
      const chain = [a, ...on.map((o) => o[1]), b];
      for (let j = 0; j + 1 < chain.length; j++) addEdge(chain[j], chain[j + 1]);
    }
  // Chain the boundary edges into loops.
  const from = new Map();
  for (const e of edges.values()) for (let c = 0; c < e.count; c++) {
    const k = K(e.a);
    if (!from.has(k)) from.set(k, []);
    from.get(k).push(e);
  }
  const loops = [];
  for (;;) {
    const startKey = [...from.keys()].find((k) => from.get(k).length);
    if (!startKey) break;
    const loop = [];
    let k = startKey;
    for (let guard = 0; guard < 100000; guard++) {
      const list = from.get(k);
      if (!list?.length) break;
      const e = list.pop();
      loop.push(e.a);
      k = K(e.b);
      if (k === startKey) break;
    }
    // Drop points on straight runs.
    const clean = loop.filter((p, i) => {
      const a = loop[(i - 1 + loop.length) % loop.length];
      const b = loop[(i + 1) % loop.length];
      return Math.abs((p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0])) > 1e-3;
    });
    if (clean.length >= 3 && Math.abs(signedArea(clean)) > 1) loops.push(clean);
  }
  const outers = loops.filter((l) => signedArea(l) > 0).map((l) => ({ boundary: l, holes: [] }));
  for (const h of loops.filter((l) => signedArea(l) < 0)) {
    const host = outers.filter((o) => pointInPolygon(h[0], o.boundary) || pointInPolygon([(h[0][0] + h[1][0]) / 2, (h[0][1] + h[1][1]) / 2], o.boundary)).sort((x, y) => signedArea(x.boundary) - signedArea(y.boundary))[0];
    if (host) host.holes.push(h);
  }
  return outers;
}

/** a op b for two shapes: 'union' | 'subtract' | 'intersect'. Returns the resulting shapes. */
export function polygonBoolean(a, b, op) {
  return outlines(OPS[op](solid(a), solid(b)));
}

/** Union of many shapes. */
export function unionAll(shapes) {
  if (!shapes.length) return [];
  let polys = solid(shapes[0]);
  for (const s of shapes.slice(1)) polys = union(polys, solid(s));
  return outlines(polys);
}

/** Element kinds whose outline polygon operations can change. */
export const POLY_KINDS = new Set(['floor', 'ceiling', 'region', 'mass', 'shaft', 'opening', 'propertyLine']);

/**
 * Polygon operation on elements (inside a transaction). The first is the
 * target; union merges the others of its kind into it, subtract cuts them
 * out of it, intersect keeps what all share. The tools are removed unless
 * keep is set; a target split in pieces gets copies. Returns { ids } or { error }.
 */
export function applyPolygonOp(doc, ids, op, { keep = false } = {}) {
  const els = ids.map((id) => doc.get(id)).filter((e) => e && POLY_KINDS.has(e.kind) && e.boundary?.length >= 3);
  if (els.length < 2) return { error: 'Select two or more slabs, ceilings, fills, masses or shafts; the first one selected is changed.' };
  const [target, ...tools] = els;
  if (op === 'union' && tools.some((t) => t.kind !== target.kind)) return { error: 'Only elements of the same kind can be merged.' };
  const shape = (e) => ({ boundary: e.boundary, holes: e.holes || [] });
  let result = [shape(target)];
  for (const t of tools) {
    const next = [];
    if (op === 'union') next.push(...unionAll([...result, shape(t)]));
    else for (const r of result) next.push(...polygonBoolean(r, shape(t), op));
    result = next;
  }
  if (!result.length) return { error: op === 'intersect' ? 'The shapes do not overlap.' : 'Nothing would be left.' };
  const out = [];
  result.forEach((r, i) => {
    const patch = { boundary: r.boundary, ...(target.holes || r.holes.length ? { holes: r.holes } : {}) };
    if (i === 0) {
      doc.update(target.id, patch);
      out.push(target.id);
    } else {
      const { id: _id, ...rest } = target;
      out.push(doc.add({ ...rest, ...patch }).id);
    }
  });
  if (!keep) for (const t of tools) doc.remove(t.id);
  return { ids: out };
}
