/**
 * Load categories and load combinations, as Archicad's (Options > Load
 * Categories / Load Combinations) for the structural analytical model:
 *
 *   - each variable load case (imposed, snow, wind) belongs to a category
 *     with its combination factors ψ0, ψ1, ψ2 (EN 1990 Table A1.1, the same
 *     values as NTC 2018 Tab. 2.5.I);
 *   - combinations are generated from the cases in use: ultimate (STR, set
 *     B) with each variable case leading in turn, and serviceability
 *     characteristic, frequent and quasi-permanent; partial factors from EN
 *     1990 (γG 1.35, γQ 1.5) or NTC 2018 (γG1 1.3, γG2 1.5, γQ 1.5).
 *
 * Case names are those of the SAF export: G1 self weight, G2 permanent, Q
 * imposed, S snow, W wind.
 *
 *   project.loadCategories = { live: 'A', snow: 'snowLow', wind: 'wind' }
 *   project.loadCombinations = { standard: 'EN' | 'NTC', uls: true, sls: true, custom: [{ name, category, factors }] }
 */

export const LOAD_CATEGORIES = [
  { value: 'A', label: 'Cat. A – Domestic, residential', psi: [0.7, 0.5, 0.3] },
  { value: 'B', label: 'Cat. B – Offices', psi: [0.7, 0.5, 0.3] },
  { value: 'C', label: 'Cat. C – Congregation areas', psi: [0.7, 0.7, 0.6] },
  { value: 'D', label: 'Cat. D – Shopping areas', psi: [0.7, 0.7, 0.6] },
  { value: 'E', label: 'Cat. E – Storage areas', psi: [1.0, 0.9, 0.8] },
  { value: 'F', label: 'Cat. F – Traffic, vehicles ≤ 30 kN', psi: [0.7, 0.7, 0.6] },
  { value: 'G', label: 'Cat. G – Traffic, 30–160 kN', psi: [0.7, 0.5, 0.3] },
  { value: 'H', label: 'Cat. H – Roofs', psi: [0, 0, 0] },
  { value: 'snowLow', label: 'Snow, site at or below 1000 m', psi: [0.5, 0.2, 0] },
  { value: 'snowHigh', label: 'Snow, site above 1000 m', psi: [0.7, 0.5, 0.2] },
  { value: 'wind', label: 'Wind', psi: [0.6, 0.2, 0] },
  { value: 'temperature', label: 'Temperature (non-fire)', psi: [0.6, 0.5, 0] },
];

export const CATEGORY_DEFAULTS = { live: 'A', snow: 'snowLow', wind: 'wind' };

export const STANDARDS = {
  EN: { label: 'EN 1990 (Eurocode)', gG1: 1.35, gG2: 1.35, gQ: 1.5 },
  NTC: { label: 'NTC 2018 (Italy)', gG1: 1.3, gG2: 1.5, gQ: 1.5 },
};


/** The SAF load cases by value, with the project's mapping and its own cases. */
export function safCases(project) {
  const base = {
    dead: { name: 'G2', desc: 'Permanent loads', action: 'Permanent', group: 'LG1', type: 'Standard' },
    live: { name: 'Q', desc: 'Imposed loads', action: 'Variable', group: 'LG2', type: 'Static', duration: 'Medium' },
    snow: { name: 'S', desc: 'Snow', action: 'Variable', group: 'LG3', type: 'Snow', duration: 'Short' },
    wind: { name: 'W', desc: 'Wind', action: 'Variable', group: 'LG4', type: 'Wind', duration: 'Short' },
  };
  (project?.customLoadCases || []).forEach((c, i) => {
    const permanent = c.action === 'permanent';
    base[c.value] = { name: `C${i + 1}`, desc: c.label, action: permanent ? 'Permanent' : 'Variable', group: `LG${5 + i}`, type: permanent ? 'Standard' : 'Static', ...(permanent ? {} : { duration: 'Medium' }) };
  });
  const map = project?.loadMapping || {};
  for (const k of Object.keys(base)) base[k] = { ...base[k], ...(map[k] || {}) };
  return base;
}

/** The names of the cases in combinations: self weight is always G1. */
export function caseNames(project) {
  const s = safCases(project);
  return { self: 'G1', ...Object.fromEntries(Object.entries(s).map(([k, v]) => [k, v.name])) };
}

export function categoriesOf(project) {
  return { ...CATEGORY_DEFAULTS, ...(project?.loadCategories || {}) };
}

export function combinationSettings(project) {
  return { standard: 'EN', uls: true, sls: true, custom: [], ...(project?.loadCombinations || {}) };
}

const psiOf = (project, kase) => LOAD_CATEGORIES.find((c) => c.value === (project?.customLoadCases?.find((x) => x.value === kase)?.category ?? categoriesOf(project)[kase]))?.psi || [0.7, 0.5, 0.3];
const round = (v) => Math.round(v * 1000) / 1000;

/**
 * The combinations for the load cases in use (variable ones among 'live', 'snow', 'wind'; 'dead' when present).
 * Returns [{ name, description, category: 'ULS' | 'SLS', standard (SAF national standard), factors: { G1: 1.35, ... } }].
 */
export function loadCombinations(project, usedCases = []) {
  const s = combinationSettings(project);
  const std = STANDARDS[s.standard] || STANDARDS.EN;
  const CASE_NAMES = caseNames(project);
  const custom = (project?.customLoadCases || []).filter((c) => usedCases.includes(c.value));
  const perm = { G1: 1, ...(usedCases.includes('dead') ? { [CASE_NAMES.dead]: 1 } : {}), ...Object.fromEntries(custom.filter((c) => c.action === 'permanent').map((c) => [CASE_NAMES[c.value], 1])) };
  const vars = [...['live', 'snow', 'wind'].filter((c) => usedCases.includes(c)), ...custom.filter((c) => c.action !== 'permanent').map((c) => c.value)];
  const scaled = (k) => Object.fromEntries(Object.entries(perm).map(([n, v]) => [n, round(v * (n === 'G1' ? std.gG1 : std.gG2) * k)]));
  const out = [];
  if (s.uls) {
    if (!vars.length) out.push({ name: 'ULS1', description: 'Permanent', category: 'ULS', standard: 'EN-ULS (STR/GEO) Set B', factors: scaled(1) });
    vars.forEach((lead, i) => {
      const f = scaled(1);
      for (const v of vars) f[CASE_NAMES[v]] = round(std.gQ * (v === lead ? 1 : psiOf(project, v)[0]));
      out.push({ name: `ULS${i + 1}`, description: `${CASE_NAMES[lead]} leading`, category: 'ULS', standard: 'EN-ULS (STR/GEO) Set B', factors: f });
    });
  }
  if (s.sls) {
    const leadSet = vars.length ? vars : [null];
    leadSet.forEach((lead, i) => {
      const f = { ...perm };
      for (const v of vars) f[CASE_NAMES[v]] = round(v === lead ? 1 : psiOf(project, v)[0]);
      out.push({ name: `SLS-C${i + 1}`, description: lead ? `Characteristic, ${CASE_NAMES[lead]} leading` : 'Characteristic', category: 'SLS', standard: 'EN-SLS Characteristic', factors: f });
    });
    leadSet.forEach((lead, i) => {
      const f = { ...perm };
      for (const v of vars) f[CASE_NAMES[v]] = round(psiOf(project, v)[v === lead ? 1 : 2]);
      out.push({ name: `SLS-F${i + 1}`, description: lead ? `Frequent, ${CASE_NAMES[lead]} leading` : 'Frequent', category: 'SLS', standard: 'EN-SLS Frequent', factors: dropZero(f) });
    });
    const qp = { ...perm };
    for (const v of vars) qp[CASE_NAMES[v]] = round(psiOf(project, v)[2]);
    out.push({ name: 'SLS-QP', description: 'Quasi-permanent', category: 'SLS', standard: 'EN-SLS Quasi-permanent', factors: dropZero(qp) });
  }
  for (const c of s.custom || []) if (c?.name && c.factors) out.push({ description: '', category: 'ULS', standard: 'EN-ULS (STR/GEO) Set B', ...c });
  return out;
}

function dropZero(f) {
  return Object.fromEntries(Object.entries(f).filter(([, v]) => v !== 0));
}

/** SAF rows of StructuralLoadCombination: Name, Description, Category, National standard, Type, then factor / multiplier / case triples. */
export function combinationRows(combos) {
  const n = Math.max(1, ...combos.map((c) => Object.keys(c.factors).length));
  const header = ['Name', 'Description', 'Category', 'National standard', 'Type'];
  for (let i = 1; i <= n; i++) header.push(`Load factor ${i}`, `Multiplier ${i}`, `Load case name ${i}`);
  const rows = combos.map((c) => {
    const r = [c.name, c.description, c.category, c.standard, 'Linear'];
    for (const [kase, f] of Object.entries(c.factors)) r.push(f, 1, kase);
    while (r.length < header.length) r.push('');
    return r;
  });
  return { header, rows };
}
