/**
 * Project integrity (Options > Data Safety): references to elements that no
 * longer exist, and coordinates that are not numbers. Repairs remove elements
 * that cannot live without what they point to and clear the optional links.
 */
const REQUIRED = ['hostId', 'viewId', 'levelId', 'placedId'];
const OPTIONAL = ['topLevelId', 'layerId', 'attachTopId'];
const POINTS = ['a', 'b', 'at'];

/** The problems found: [{ id, kind, problem, field, repair: 'remove' | 'clear' | null }]. */
export function checkIntegrity(doc) {
  const out = [];
  const missing = (ref) => ref != null && ref !== '' && !doc.has(ref);
  for (const el of doc.items.values()) {
    if (el.kind === 'project') continue;
    for (const f of REQUIRED) if (missing(el[f])) out.push({ id: el.id, kind: el.kind, field: f, problem: `${f} points to a missing element`, repair: 'remove' });
    for (const f of OPTIONAL) if (missing(el[f])) out.push({ id: el.id, kind: el.kind, field: f, problem: `${f} points to a missing element`, repair: 'clear' });
    if (missing(el.typeId)) out.push({ id: el.id, kind: el.kind, field: 'typeId', problem: 'its type is missing', repair: null });
    for (const f of POINTS) if (Array.isArray(el[f]) && el[f].some((v) => !Number.isFinite(+v))) out.push({ id: el.id, kind: el.kind, field: f, problem: `${f} is not a valid point`, repair: 'remove' });
  }
  return out;
}

/** Apply the repairs (inside a transaction). Returns how many elements changed. */
export function repairIntegrity(doc, problems) {
  const remove = new Set(problems.filter((p) => p.repair === 'remove').map((p) => p.id));
  let n = 0;
  for (const p of problems) {
    if (p.repair !== 'clear' || remove.has(p.id) || !doc.has(p.id)) continue;
    doc.update(p.id, { [p.field]: undefined });
    n++;
  }
  for (const id of remove) {
    if (!doc.has(id)) continue;
    doc.remove(id);
    n++;
  }
  return n;
}
