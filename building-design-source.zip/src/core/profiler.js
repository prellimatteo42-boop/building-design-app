/**
 * Profiler (Archicad's Profiler for morphs, reimplemented): a cross-section
 * made into a free body by
 *   - extrude: along a straight run between two points,
 *   - revolve: round a vertical axis, by an angle,
 *   - sweep:   along a 3D path (lines picked in plan, rising as asked),
 * with mitred corners. The body is a morph that keeps its recipe
 * (`el.profiler`), so it is rebuilt when the profile changes:
 *
 *   morph.profiler { mode: 'extrude' | 'revolve' | 'sweep', profileId? | shapes?, preset?, scale?,
 *                    path: [[x, y, z]] (extrude: two points; sweep: the path), closed?,
 *                    center: [x, y, z], angle (degrees), segments (revolve) }
 *
 * Profile coordinates: (x, y) in the cross-section, x to the right of the
 * direction of travel and y up (revolve: x is the distance from the axis,
 * y the height).
 */
import { MeshBuilder, hexToRgba } from './mesh.js';
import { triangulate, signedArea } from './geom.js';
import { PROFILES as SWEEP_PROFILES } from './sweeps.js';

export const PROFILER_MODES = [
  { value: 'extrude', label: 'Extrude between two points' },
  { value: 'revolve', label: 'Revolve round a vertical axis' },
  { value: 'sweep', label: 'Sweep along a path' },
];

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const addv = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const mul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const unit = (a) => {
  const l = Math.hypot(a[0], a[1], a[2]);
  return l > 1e-12 ? [a[0] / l, a[1] / l, a[2] / l] : [0, 0, 0];
};

/** The cross-section shapes of a profiler morph: [{ poly, holes, materialId }]. */
export function profilerShapes(doc, p) {
  if (p.shapes?.length) return p.shapes;
  const prof = p.profileId ? doc.get(p.profileId) : null;
  if (prof?.shapes?.length) return prof.shapes;
  const pre = SWEEP_PROFILES[p.preset || 'rect'] || SWEEP_PROFILES.rect;
  const [sx, sy] = p.scale || [300, 300];
  // Presets are in (out, up) from 0..1: centred across the run.
  return [{ poly: pre.pts.map(([x, y]) => [(x - 0.5) * sx, y * sy]), materialId: p.materialId || null }];
}

/**
 * Frames along a path: at each point { o, side, up, ks, ku } with the mitre scales of the side and up
 * directions at a corner (1 on straight runs). closed: the path loops back to its start.
 */
export function pathFrames(path, closed = false) {
  const n = path.length;
  const segs = [];
  for (let i = 0; i < (closed ? n : n - 1); i++) segs.push(unit(sub(path[(i + 1) % n], path[i])));
  const frameOf = (t, prevSide) => {
    let side = cross(t, [0, 0, 1]);
    if (Math.hypot(...side) < 1e-6) side = prevSide || [1, 0, 0];
    side = unit(side);
    return { side, up: unit(cross(side, t)) };
  };
  const segFrames = [];
  let last = null;
  for (const t of segs) {
    const f = frameOf(t, last);
    segFrames.push(f);
    last = f.side;
  }
  const out = [];
  for (let i = 0; i < n; i++) {
    const before = closed ? (i - 1 + segs.length) % segs.length : i - 1;
    const after = closed ? i % segs.length : i;
    const tA = before >= 0 ? segs[before] : null;
    const tB = after < segs.length ? segs[after] : null;
    const t = unit(tA && tB ? addv(tA, tB) : tA || tB);
    const f = frameOf(t, (tB ? segFrames[after] : segFrames[before])?.side);
    // Mitre: stretch across the corner so both runs keep their section.
    const seg = tB ? segFrames[after] : segFrames[before];
    const ks = 1 / Math.max(0.25, Math.abs(dot(f.side, seg.side)));
    const ku = 1 / Math.max(0.25, Math.abs(dot(f.up, seg.up)));
    out.push({ o: path[i], side: f.side, up: f.up, ks, ku });
  }
  return out;
}

/** Rings of a section loop at each station: station(i, [x, y]) gives the 3D point. */
function skin(b, loop, nSt, station, closed, col) {
  for (let i = 0; i < (closed ? nSt : nSt - 1); i++) {
    const i2 = (i + 1) % nSt;
    for (let k = 0; k < loop.length; k++) {
      const k2 = (k + 1) % loop.length;
      const A = station(i, loop[k]);
      const B = station(i2, loop[k]);
      const C = station(i2, loop[k2]);
      const D = station(i, loop[k2]);
      // A section point on the axis of revolution stays put: the quad is a triangle there.
      const same = (p, q) => Math.abs(p[0] - q[0]) + Math.abs(p[1] - q[1]) + Math.abs(p[2] - q[2]) < 1e-6;
      if (same(A, B) && same(C, D)) continue;
      if (same(A, B)) b.tri(A, C, D, col);
      else if (same(C, D)) b.tri(A, B, C, col);
      else b.quad(A, B, C, D, col);
    }
  }
}

function cap(b, outer, holes, station, i, flip, col) {
  const { points, tris } = triangulate(outer, holes);
  for (let t = 0; t + 2 < tris.length; t += 3) {
    const [p, q, r] = [points[tris[t]], points[tris[t + 1]], points[tris[t + 2]]];
    const ccw = (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]) > 0;
    const [a, c] = ccw !== flip ? [q, r] : [r, q];
    b.tri(station(i, p), station(i, a), station(i, c), col);
  }
}

/**
 * The body of a profiler recipe as a mesh, or null. colorOf(shape) gives each shape's colour.
 * Faces point out of the body whichever way the section and the path run.
 */
export function profilerMesh(doc, p, colorOf = () => [200, 200, 200, 255]) {
  const shapes = profilerShapes(doc, p).filter((s) => s.poly?.length >= 3);
  if (!shapes.length) return null;
  let nSt;
  let station;
  let closed = false;
  if (p.mode === 'revolve') {
    const c = p.center || [0, 0, 0];
    const ang = Math.max(1, Math.min(360, +p.angle || 360));
    closed = ang >= 359.999;
    const seg = Math.max(3, Math.min(256, Math.round(+p.segments || Math.max(8, ang / 10))));
    nSt = closed ? seg : seg + 1;
    const step = ((ang * Math.PI) / 180) / seg;
    const a0 = ((+p.startAngle || 0) * Math.PI) / 180;
    station = (i, [x, y]) => [c[0] + x * Math.cos(a0 + i * step), c[1] + x * Math.sin(a0 + i * step), c[2] + y];
  } else {
    const path = (p.path || []).filter((q) => Array.isArray(q) && q.length >= 2).map((q) => [q[0], q[1], q[2] || 0]);
    if (path.length < 2) return null;
    closed = p.mode === 'sweep' && !!p.closed && path.length >= 3;
    const fr = pathFrames(path, closed);
    nSt = path.length;
    station = (i, [x, y]) => addv(addv(fr[i].o, mul(fr[i].side, x * fr[i].ks)), mul(fr[i].up, y * fr[i].ku));
  }
  const b = new MeshBuilder();
  for (const sh of shapes) {
    const col = colorOf(sh);
    const outer = signedArea(sh.poly) >= 0 ? sh.poly : sh.poly.slice().reverse();
    const holes = (sh.holes || []).filter((h) => h.length >= 3).map((h) => (signedArea(h) >= 0 ? h.slice().reverse() : h));
    skin(b, outer, nSt, station, closed, col);
    for (const h of holes) skin(b, h, nSt, station, closed, col);
    if (!closed) {
      cap(b, outer, holes, station, 0, false, col);
      cap(b, outer, holes, station, nSt - 1, true, col);
    }
  }
  const m = b.build();
  // Turn the whole body round when its faces point in (negative volume).
  let vol = 0;
  const P = m.pos;
  for (let i = 0; i + 8 < P.length; i += 9) vol += dot([P[i], P[i + 1], P[i + 2]], cross([P[i + 3], P[i + 4], P[i + 5]], [P[i + 6], P[i + 7], P[i + 8]]));
  if (vol < 0) {
    const out = new MeshBuilder();
    for (let i = 0; i + 8 < P.length; i += 9) {
      const c = [m.col[(i / 9) * 12], m.col[(i / 9) * 12 + 1], m.col[(i / 9) * 12 + 2], m.col[(i / 9) * 12 + 3]];
      out.tri([P[i], P[i + 1], P[i + 2]], [P[i + 6], P[i + 7], P[i + 8]], [P[i + 3], P[i + 4], P[i + 5]], c);
    }
    return { mesh: out.build(), volume: -vol / 6 };
  }
  return { mesh: m, volume: vol / 6 };
}

/** Colour of a shape from its material (or the morph's). */
export function shapeColor(doc, el) {
  return (sh) => hexToRgba(doc.get(sh.materialId || el.materialId)?.color || '#c9c3b8', 1);
}

/**
 * A sweep path from picked elements (lines, model lines, walls and beams by their axes, splines and polylines by their
 * points), chained end to end, at a base height rising evenly by `rise` over the whole run. null when they do not chain.
 */
export function chainPath(els, z0 = 0, rise = 0, tol = 5) {
  const pieces = [];
  for (const el of els) {
    if (Array.isArray(el.points) && el.points.length >= 2) pieces.push(el.points.map((p) => [p[0], p[1]]));
    else if (el.a && el.b) pieces.push([[el.a[0], el.a[1]], [el.b[0], el.b[1]]]);
  }
  if (!pieces.length) return null;
  const near = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]) <= tol;
  let path = pieces.shift();
  while (pieces.length) {
    const i = pieces.findIndex((pc) => near(pc[0], path.at(-1)) || near(pc.at(-1), path.at(-1)) || near(pc[0], path[0]) || near(pc.at(-1), path[0]));
    if (i < 0) return null;
    const pc = pieces.splice(i, 1)[0];
    if (near(pc[0], path.at(-1))) path = [...path, ...pc.slice(1)];
    else if (near(pc.at(-1), path.at(-1))) path = [...path, ...pc.slice(0, -1).reverse()];
    else if (near(pc.at(-1), path[0])) path = [...pc, ...path.slice(1)];
    else path = [...pc.slice().reverse(), ...path.slice(1)];
  }
  const closed = path.length > 3 && near(path[0], path.at(-1));
  if (closed) path = path.slice(0, -1);
  const lengths = [0];
  for (let i = 1; i < path.length; i++) lengths.push(lengths[i - 1] + Math.hypot(path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1]));
  const total = lengths.at(-1) || 1;
  return { path: path.map((p, i) => [p[0], p[1], z0 + (closed ? 0 : (rise * lengths[i]) / total)]), closed };
}
