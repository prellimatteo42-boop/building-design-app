/**
 * Find & Select, as in Archicad: the elements matching every criterion of
 * a list (element type, type, layer, story, building material, zone
 * category). Only model and drawing elements are searched, not views,
 * types or settings.
 */
import { categoryOf, KIND_LABEL } from './catalog.js';
import { isView } from './doc.js';
import { layerIdOf, layersInOrder } from './layers.js';
import { zoneCategoryOf } from './zonecats.js';
import { classOf, classTree, classLabel } from './classify.js';

/** Building materials an element shows: its own, its type's and its type's layers'. */
export function elementMaterials(doc, el) {
  const out = new Set();
  const type = el.typeId ? doc.get(el.typeId) : null;
  for (const src of [el, type])
    if (src) {
      for (const k of ['materialId', 'panelMaterialId', 'frameMaterialId', 'paintId']) if (src[k]) out.add(src[k]);
      for (const l of src.layers || []) if (l.materialId) out.add(l.materialId);
      if (src.curtain?.materialId) out.add(src.curtain.materialId);
    }
  return out;
}

const storyOf = (doc, el) => el.levelId ?? doc.get(el.hostId)?.levelId ?? null;

export const CRITERIA = [
  {
    id: 'kind',
    label: 'Element Type',
    options: (doc, els) => [...new Set(els.map((e) => e.kind))].map((k) => ({ value: k, label: KIND_LABEL[k] || k })).sort((a, b) => a.label.localeCompare(b.label)),
    test: (doc, el, v) => el.kind === v,
  },
  {
    id: 'type',
    label: 'Type',
    options: (doc, els) => [...new Set(els.map((e) => e.typeId).filter(Boolean))].map((id) => doc.get(id)).filter(Boolean).map((t) => ({ value: t.id, label: `${KIND_LABEL[t.kind.replace(/Type$/, '')] || t.kind}: ${t.name}` })).sort((a, b) => a.label.localeCompare(b.label)),
    test: (doc, el, v) => el.typeId === v,
  },
  { id: 'layer', label: 'Layer', options: (doc) => layersInOrder(doc).map((l) => ({ value: l.id, label: l.name })), test: (doc, el, v) => layerIdOf(doc, el) === v },
  { id: 'story', label: 'Story', options: (doc) => doc.levels().map((l) => ({ value: l.id, label: l.name })), test: (doc, el, v) => storyOf(doc, el) === v },
  {
    id: 'material',
    label: 'Building Material',
    options: (doc) => doc.all('material').map((m) => ({ value: m.id, label: m.name })).sort((a, b) => a.label.localeCompare(b.label)),
    test: (doc, el, v) => elementMaterials(doc, el).has(v),
  },
  {
    id: 'classification',
    label: 'Classification',
    options: (doc) => doc.all('classSystem').flatMap((sys) => classTree(sys).map(({ item }) => ({ value: `${sys.id}|${item.code}`, label: `${doc.count('classSystem') > 1 ? `${sys.name}: ` : ''}${classLabel(item)}` }))),
    test: (doc, el, v) => {
      const [sid, code] = v.split('|');
      const sys = doc.get(sid);
      const item = sys && classOf(doc, el, sys);
      // An item also matches the elements of the items under it.
      return !!item && (item.code === code || item.code.startsWith(`${code}.`));
    },
  },
  {
    id: 'cadLayer',
    label: 'CAD Layer',
    options: (doc, els) => [...new Set(els.map((e) => e.cadLayer).filter(Boolean))].sort().map((n) => ({ value: n, label: n })),
    test: (doc, el, v) => el.cadLayer === v,
  },
  { id: 'zoneCategory', label: 'Zone Category', options: (doc) => doc.all('zoneCategory').map((z) => ({ value: z.id, label: z.name })), test: (doc, el, v) => el.kind === 'room' && zoneCategoryOf(doc, el)?.id === v },
];

/** Elements that Find & Select searches. */
export function searchable(doc) {
  return [...doc.items.values()].filter((el) => !isView(el) && el.kind !== 'viewport' && !!categoryOf(el, doc));
}

/** Elements matching every criterion [{ id, value }] (criteria without a value are ignored). */
export function findElements(doc, criteria) {
  const active = criteria.map((c) => ({ c: CRITERIA.find((x) => x.id === c.id), value: c.value })).filter((x) => x.c && x.value);
  return searchable(doc).filter((el) => active.every(({ c, value }) => c.test(doc, el, value)));
}
