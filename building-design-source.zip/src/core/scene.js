/**
 * Scene: derived data for a document, kept in sync with its edits.
 *
 *   - wall joins and room regions per level (WallSolver, RoomSolver)
 *   - 3D meshes per element
 *   - plan graphics per (view, element)
 *
 * Each cached result remembers the inputs it was built from (the element,
 * its type, levels, host, solved wall outline...). Items are immutable, so
 * comparing those inputs by identity tells whether to rebuild.
 */
import { applySurfaceTextures, texturedMaterials } from './surfaces2.js';
import { WallSolver, hubsOf } from './walls.js';
import { joinedLayers, STRUCTURE_DISPLAY } from './layerjoins.js';
import { RoomSolver, AreaSolver } from './rooms.js';
import { build3D } from './build3d.js';
import { planGraphics, planContext, columnOutline, hiddenInView, PlanBuilder } from './plan.js';
import { phasesInOrder, phaseLook, phased } from './phases.js';
import { hostedBy } from './model.js';
import { ANNOTATION_KINDS } from './annotate.js';
import { hiddenByFilters, viewGraphics, restyle, viewFilterItems } from './graphics.js';
import { worksharingOn, worksetable, worksetOf, worksetColor } from './worksets.js';
import { cropGraphics } from './crop.js';
import { MEP_KINDS, connected, fittingTrim } from './mep.js';
import { isView, Doc } from './doc.js';
import { upgradeDoc } from './template.js';
import { linkFrame, linkedLevel, appendPlan, combineMeshes } from './links.js';
import { zoneCategoryOf } from './zonecats.js';
import { applySEO } from './seo.js';
import { trimMesh, isTrimmer, trimsAnalytically, cutOpenings } from './rooftrim.js';

/** The columns on a wall's level whose box comes within a metre of the wall's line. */
function columnsNear(doc, w) {
  if (!w.a || !w.b) return [];
  const x0 = Math.min(w.a[0], w.b[0]) - 1000;
  const x1 = Math.max(w.a[0], w.b[0]) + 1000;
  const y0 = Math.min(w.a[1], w.b[1]) - 1000;
  const y1 = Math.max(w.a[1], w.b[1]) + 1000;
  return doc.all('column').filter((c) => c.levelId === w.levelId && c.at[0] >= x0 && c.at[0] <= x1 && c.at[1] >= y0 && c.at[1] <= y1);
}

export const MODEL_KINDS = ['topo', 'wall', 'floor', 'ceiling', 'roof', 'door', 'window', 'column', 'beam', 'brace', 'footing', 'wallFooting', 'stair', 'ramp', 'railing', 'component', 'modelLine', ...MEP_KINDS, 'mass', 'shell', 'morph', 'skylight', 'link', 'mepFitting', 'mepAccessory', 'mepFlex', 'cwJunction', 'glazedRoof', 'wallEnd', 'wallSweep', 'wallCladding', 'slabAccessory', 'roofAccessory', 'roomAccessory', 'structuralSupport', 'structuralLoad', 'truss', 'importedModel', 'modelText'];
export const PLAN_KINDS = [...MODEL_KINDS, 'camera', 'structuralLink', 'basePoint', 'scopeBox', 'matchline', 'wire', 'space', 'room', 'roomSeparator', 'area', 'areaBoundary', 'grid', 'refPlane', 'propertyLine', 'region', 'dimension', 'text', 'tag', 'treadNumbers', 'detailLine', ...ANNOTATION_KINDS, 'section', 'elevation'];

const LEVEL_SCOPED = new Set(['modelText', 'wire', 'truss', 'wall', 'roomSeparator', 'column', 'room', 'space', 'floor', 'ceiling', 'roof', 'stair', 'ramp', 'railing', 'component', 'beam', 'brace', 'footing', 'modelLine', 'area', 'areaBoundary', 'mass', ...MEP_KINDS]);

/** 2D views that show only their own annotations. */
export const DRAWN_ONLY = new Set(['drafting', 'legend']);

/** Kinds drawn only in area plans, and kinds area plans leave out. */
const AREA_ONLY = new Set(['area', 'areaBoundary']);
const NOT_IN_AREA_PLANS = new Set(['room', 'roomSeparator']);

export class Scene {
  constructor(doc) {
    this.doc = doc;
    this.walls = new WallSolver(doc);
    this.rooms = new RoomSolver(doc, this.walls, (c) => columnOutline(doc, c));
    this.areas = new AreaSolver(doc);
    this.meshes = new Map();
    this.plans = new Map();
    this.links = new Map();
    this.known = new Map();
    this.version = 0;
    this.listeners = new Set();
    this.index = new Map();
    this.ids = [];
    for (const it of doc.items.values()) this.remember(it);
    this.off = doc.on((ev) => this.changed(ev));
  }

  dispose() {
    this.off?.();
  }

  on(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /** Small integer per element id, for GPU picking and state textures. */
  indexOf(id) {
    let i = this.index.get(id);
    if (i === undefined) {
      i = this.ids.length + 1;
      this.ids.push(id);
      this.index.set(id, i);
    }
    return i;
  }

  idAt(index) {
    return index > 0 ? this.ids[index - 1] ?? null : null;
  }

  remember(it) {
    this.known.set(it.id, { kind: it.kind, levelId: it.levelId ?? this.doc.get(it.hostId)?.levelId ?? null });
  }

  changed(ev) {
    const doc = this.doc;
    let all = false;
    let columnType = false;
    const levels = new Set();
    for (const id of ev.ids) {
      const now = doc.get(id);
      const before = this.known.get(id);
      const kind = now?.kind ?? before?.kind;
      if (kind === 'level' || kind === 'wallType' || kind === 'material' || kind === 'project' || kind === 'layer') all = true;
      if (kind === 'phase') this.plans.clear();
      // Fill types draw inside other elements' plans and fills.
      if (kind === 'fillType' || kind === 'textStyle') this.plans.clear();
      // Column outlines bound rooms, and their size lives on the type.
      if (kind === 'columnType') columnType = true;
      if (LEVEL_SCOPED.has(kind)) {
        if (before?.levelId) levels.add(before.levelId);
        if (now?.levelId) levels.add(now.levelId);
      }
      if (now) this.remember(now);
      else this.known.delete(id);
      if (kind === 'material' || kind === 'project') {
        this.meshes.clear();
        this.plans.clear();
      }
    }
    // Room boundaries are recomputed when an edit is committed, not on every
    // frame of a drag (they are the most expensive derived data).
    const rooms = !ev.preview;
    if (all) {
      this.walls.invalidate();
      if (rooms) this.rooms.invalidate();
      this.areas.invalidate();
    } else {
      if (columnType && rooms) this.rooms.invalidate();
      for (const l of levels) {
        this.walls.invalidate(l);
        if (rooms) this.rooms.invalidate(l);
        this.areas.invalidate(l);
      }
    }
    for (const id of ev.ids)
      if (!doc.has(id)) {
        this.meshes.delete(id);
        for (const m of STRUCTURE_DISPLAY) this.meshes.delete(`${id}@${m.value}`);
      }
    this.version++;
    for (const fn of this.listeners) fn(ev);
  }

  /** Inputs a 3D mesh depends on. */
  deps3D(el) {
    const doc = this.doc;
    const d = [el, doc.get(el.typeId), doc.get(el.levelId), doc.get(el.topLevelId), doc.get(el.paintId), el.profileId ? doc.get(el.profileId) : null];
    // A beam stops at the columns its ends stand in.
    if (el.kind === 'beam') for (const c of doc.all('column')) if (Math.min(Math.hypot(c.at[0] - el.a[0], c.at[1] - el.a[1]), Math.hypot(c.at[0] - el.b[0], c.at[1] - el.b[1])) < 2000) d.push(c, doc.get(c.typeId), doc.get(c.levelId), doc.get(c.topLevelId));
    // A Profiler morph with its complex profile.
    if (el.profiler?.profileId) d.push(doc.get(el.profiler.profileId));
    // A roof with its skylights, a skylight with its roof.
    if (el.kind === 'roof') for (const s of hostedBy(doc, el.id)) d.push(s);
    // A stair or railing with the Archicad components its type runs for its pieces.
    if (el.kind === 'stair' || el.kind === 'railing') {
      const t = doc.get(el.typeId);
      for (const k of ['treadPartId', 'riserPartId', 'structurePartId', 'landingPartId', 'postPartId', 'railPartId', 'panelPartId']) d.push(t?.[k] ? doc.get(t[k]) : null);
    }
    if (el.kind === 'skylight') {
      const r = doc.get(el.hostId);
      d.push(r, r && doc.get(r.typeId), r && doc.get(r.levelId));
    }
    // Operators of solid element operations: their element and their body.
    for (const op of el.seo || []) {
      const o = doc.get(op.id);
      d.push(o, o && o.id !== el.id && !o.seo?.length ? this.mesh(o) : null);
    }
    // A wall or column trimmed to a roof: the roof and where it stands.
    if (el.attachTopId) {
      const roof = doc.get(el.attachTopId);
      d.push(roof, roof && doc.get(roof.typeId), roof && doc.get(roof.levelId));
    }
    if (el.kind === 'cwJunction') for (const id of el.walls || []) {
      const w = doc.get(id);
      d.push(w, w && doc.get(w.typeId), w && doc.get(w.levelId), w && doc.get(w.topLevelId));
    }
    if (el.kind === 'wall') {
      const g = this.walls.wall(el.id);
      d.push(g ? wallSignature(g) : null);
      for (const h of hostedBy(doc, el.id)) d.push(h, doc.get(h.typeId));
      for (const hub of hubsOf(this.walls.level(el.levelId), el.id)) d.push(hub.poly.map((p) => p.map((v) => v.toFixed(1)).join(',')).join(';'));
    } else if (el.hostId) {
      const host = doc.get(el.hostId);
      d.push(host, host && doc.get(host.typeId), host && doc.get(host.levelId), host && doc.get(host.topLevelId));
    } else if (el.kind === 'wallFooting' || el.kind === 'wallSweep' || el.kind === 'wallCladding' || el.kind === 'wallEnd') {
      const w = doc.get(el.wallId);
      d.push(w, w && doc.get(w.typeId), w && doc.get(w.levelId), w && doc.get(w.topLevelId));
      if (w && el.kind !== 'wallFooting') for (const o of hostedBy(doc, w.id)) d.push(o, doc.get(o.typeId));
      // Cladding finds its outer face and its corners from the level's other walls and their cladding.
      if (w && el.kind === 'wallCladding') {
        for (const x of doc.all('wall')) if (x.levelId === w.levelId) d.push(x, doc.get(x.typeId));
        for (const c of doc.all('wallCladding')) if (c !== el) d.push(c);
      }
    } else if (el.kind === 'slabAccessory' || el.kind === 'roofAccessory') {
      const host = doc.get(el.slabId || el.roofId);
      d.push(host, host && doc.get(host.typeId), host && doc.get(host.levelId), doc.get(el.materialId));
      if (host) for (const s of hostedBy(doc, host.id)) d.push(s);
    } else if (el.kind === 'roomAccessory') {
      // The room's outline comes from the walls round it; its doors break the skirting.
      const room = doc.get(el.roomId);
      d.push(room, room && doc.get(room.levelId), room && this.rooms?.room(room), doc.get(el.materialId));
      if (room) for (const x of doc.all('wall')) if (x.levelId === room.levelId) for (const o of hostedBy(doc, x.id)) d.push(o, doc.get(o.typeId));
    } else if (MEP_KINDS.includes(el.kind)) d.push(`${connected(doc, el, el.a)}|${connected(doc, el, el.b)}|${fittingTrim(doc, el, 0)}|${fittingTrim(doc, el, 1)}`);
    return d;
  }

  /**
   * Cached mesh of a model element (null when it has no 3D geometry). Walls
   * and their doors and windows have one per partial structure display mode
   * (layerjoins.js).
   */
  mesh(el, show = 'entire') {
    const partial = show !== 'entire' && (el.kind === 'wall' || ((el.kind === 'door' || el.kind === 'window') && !!el.hostId));
    const key = partial ? `${el.id}@${show}` : el.id;
    const deps = [...this.deps3D(el), ...this.doc.all('material').filter((m) => m.surface?.image)];
    const c = this.meshes.get(key);
    if (c && sameDeps(c.deps, deps)) return c.mesh;
    let mesh = null;
    try {
      mesh = el.kind === 'link' ? this.linkMesh(el) : build3D(partial ? { ...this.ctx3d(), show } : this.ctx3d(), el);
      // Trimmed to a roof or shell (rooftrim.js): walls and columns under roofs follow them in build3d.js.
      if (mesh && el.attachTopId) {
        const t = this.doc.get(el.attachTopId);
        const mode = el.attachTopMode || 'above';
        if (isTrimmer(t) && t.id !== el.id && t.attachTopId !== el.id && !trimsAnalytically(el, t)) mesh = trimMesh(this.doc, mesh, t, mode === 'plane' ? null : this.mesh(t), mode);
      }
      // Cut by the openings of a slab, roof or ceiling (Cut Additional Element with Opening).
      if (mesh && el.openingCuts?.length) mesh = cutOpenings(mesh, el.openingCuts);
      // Solid element operations (seo.js) cut the body before it is painted.
      if (mesh && el.seo?.length) mesh = applySEO(mesh, el.seo, (id) => {
        const o = this.doc.get(id);
        return o && o.id !== el.id && !o.seo?.some((x) => x.id === el.id) ? this.mesh(o, show) : null;
      });
      if (mesh && el.paintId) mesh = painted(mesh, this.doc.get(el.paintId));
      // 3D texture alignment (Set Origin / Set Direction).
      if (mesh?.tex && el.texAlign) mesh = alignedTextures(mesh, el.texAlign);
      // Surfaces: faces of a material with a picture show it.
      if (mesh) mesh = applySurfaceTextures(mesh, texturedMaterials(this.doc));
    } catch (err) {
      console.warn('Could not build', el.kind, el.id, err);
    }
    this.meshes.set(key, { deps, mesh });
    return mesh;
  }

  ctx3d() {
    return { doc: this.doc, walls: this.walls, rooms: this.rooms, material: (id) => this.doc.get(id) };
  }

  /** Elements that a plan view could show (filtering by view rules happens per element). */
  planCandidates(view) {
    const doc = this.doc;
    const out = [];
    // Drafting views and legends show only what is drawn in them.
    if (DRAWN_ONLY.has(view.kind)) {
      for (const el of doc.items.values()) if (el.viewId === view.id && !hiddenInView(doc, view, el)) out.push(el);
      return out;
    }
    // Callouts made in this view show their marker here.
    for (const v of doc.all(view.kind)) if (v.calloutOf === view.id) out.push(v);
    const areaPlan = view.kind === 'areaPlan';
    const phases = phasesInOrder(doc);
    for (const k of PLAN_KINDS) {
      if (areaPlan ? NOT_IN_AREA_PLANS.has(k) : AREA_ONLY.has(k)) continue;
      for (const el of doc.all(k)) {
        if (el.viewId && el.viewId !== view.id) continue;
        if (areaPlan && AREA_ONLY.has(k) && (el.scheme || 'gross') !== (view.scheme || 'gross')) continue;
        if (k === 'section' || k === 'elevation') {
          if (view.kind !== 'plan' && view.kind !== 'areaPlan') continue;
          // Interior elevations mark only their room's plan.
          if (el.interiorOf && el.levelId !== view.levelId) continue;
        }
        if (hiddenInView(doc, view, el) || hiddenByFilters(doc, view, el)) continue;
        if (phases.length > 1 && phased(el) && phaseLook(doc, view, el, phases) === 'hidden') continue;
        out.push(el);
      }
    }
    return out;
  }

  /** Inputs of an element's plan graphics, beyond its 3D inputs. */
  depsPlan(view, el, pc) {
    const doc = this.doc;
    const d = [view, doc.get(view.levelId), ...this.deps3D(el), ...viewFilterItems(doc, view)];
    // At fine detail a wall's layers also depend on the walls it meets.
    if (el.kind === 'wall') {
      if (pc && (pc.detail === 'fine' || pc.structure !== 'entire')) d.push(joinedLayers(pc, el)?.sig ?? null);
      // A wall gives way to the columns standing in it (junctions.js).
      for (const c of columnsNear(doc, el)) d.push(c, doc.get(c.typeId));
    } else if (el.kind === 'room' || el.kind === 'space') {
      d.push(this.rooms.room(el), doc.get(el.zoneId), el.kind === 'room' ? zoneCategoryOf(doc, el) : null);
      // A cropped zone's volume follows the roofs that crop it.
      for (const id of el.cropBy || []) {
        const c = doc.get(id);
        d.push(c, c && doc.get(c.typeId), c && doc.get(c.levelId));
      }
    }
    else if (el.kind === 'area') d.push(this.areas.area(el));
    else if (el.kind === 'dimension') for (const r of el.refs || []) d.push(doc.get(r.id));
    else if (el.kind === 'tag') {
      const t = doc.get(el.targetId);
      d.push(t, t && doc.get(t.hostId), t && doc.get(t.typeId), t?.kind === 'room' ? this.rooms.room(t) : t?.kind === 'area' ? this.areas.area(t) : null);
      // Autotext may read the level, the project or values computed from other elements.
      if (el.show === 'autotext') d.push(this.version, doc.get('project'), t && doc.get(t.levelId));
    } else if (el.kind === 'stair') d.push(doc.levelAbove(el.levelId));
    else if (el.kind === 'treadNumbers') d.push(doc.get(el.stairId), doc.get(doc.get(el.stairId)?.typeId), doc.get(doc.get(el.stairId)?.topLevelId));
    else if (el.kind === 'radialDim') d.push(doc.get(el.targetId), doc.get(doc.get(el.targetId)?.typeId));
    else if (el.kind === 'revisionCloud') d.push(doc.get(el.revisionId));
    else if (el.kind === 'viewRef') d.push(doc.get(el.targetId), this.version);
    // These read other elements of the model: redraw them after any change.
    else if (el.kind === 'spot' || el.kind === 'colorLegend') d.push(this.version, doc.get('project'));
    return d;
  }

  /** Cached plan graphics of an element in a view. */
  planOf(view, el, pc = null) {
    let cache = this.plans.get(view.id);
    if (!cache) this.plans.set(view.id, (cache = new Map()));
    const ctx = pc || planContext(this.doc, view, this.walls, this.rooms, this.areas);
    const deps = this.depsPlan(view, el, ctx);
    const c = cache.get(el.id);
    if (c && sameDeps(c.deps, deps)) return c.g;
    let g = null;
    try {
      g = el.kind === 'link' ? this.linkPlan(view, el) : planGraphics(ctx, el);
      if (g && (view.overrides || view.filters?.length || view.elOverrides || this.doc.get('project')?.objectStyles)) g = restyle(g, viewGraphics(this.doc, view, el));
      if (g && view.cropOn && view.crop && !el.viewId && !isView(el) && el.kind !== 'section' && el.kind !== 'elevation') g = cropGraphics(g, view.crop);
      if (g && phased(el) && phaseLook(this.doc, view, el) === 'dashed') g = dashed(g);
      if (g && view.wsDisplay === 'worksets' && worksharingOn(this.doc) && worksetable(this.doc, el)) g = restyle(g, { color: worksetColor(this.doc, worksetOf(this.doc, el)?.id) });
    } catch (err) {
      console.warn('Could not draw', el.kind, el.id, err);
    }
    cache.set(el.id, { deps, g, bounds: g?.bounds() ?? null });
    return g;
  }

  planBounds(view, id) {
    return this.plans.get(view.id)?.get(id)?.bounds ?? null;
  }

  /** Drop caches of views that no longer exist. */
  prune() {
    for (const id of this.plans.keys()) if (!this.doc.has(id)) this.plans.delete(id);
    for (const id of this.links.keys()) if (!this.doc.has(id)) this.links.delete(id);
  }

  // Linked projects ---------------------------------------------------------------------

  /** The linked project of a link element: { doc, scene } (parsed once per snapshot). */
  link(el) {
    let e = this.links.get(el.id);
    if (e && e.data === el.data) return e;
    let doc = null;
    try {
      doc = upgradeDoc(Doc.fromJSON(JSON.parse(el.data)));
    } catch {
      doc = null;
    }
    e = { data: el.data, doc, scene: doc ? new Scene(doc) : null, views: new Map() };
    this.links.set(el.id, e);
    return e;
  }

  linkMesh(el) {
    const { scene } = this.link(el);
    if (!scene) return null;
    const meshes = [];
    for (const k of MODEL_KINDS) {
      // Modules inside the module (nested hotlinks) come along, placed by their own links.
      for (const x of scene.doc.all(k)) {
        const m = k === 'link' ? scene.linkMesh(x) : scene.mesh(x);
        if (m?.pos) meshes.push(m);
      }
    }
    return combineMeshes(meshes, linkFrame(el));
  }

  linkPlan(view, el) {
    const e = this.link(el);
    const out = new PlanBuilder();
    const host = this.doc.get(view.levelId);
    if (!e.scene || !host) return out;
    const level = linkedLevel(e.doc, el, host.elevation);
    if (!level) return out;
    // One stand-in view per host view, kept while the host view is unchanged (for caching).
    let v = e.views.get(view.id);
    if (!v || v.src !== view || v.view.levelId !== level.id) {
      v = { src: view, view: { id: `${view.id}~${el.id}`, kind: view.kind === 'ceilingPlan' ? 'ceilingPlan' : 'plan', levelId: level.id, name: level.name, scale: view.scale, detail: view.detail, cutHeight: view.cutHeight, viewDepth: view.viewDepth } };
      e.views.set(view.id, v);
    }
    const f = linkFrame(el);
    const pc = planContext(e.doc, v.view, e.scene.walls, e.scene.rooms, e.scene.areas);
    for (const x of e.scene.planCandidates(v.view)) {
      if (x.kind === 'link' || x.viewId || isView(x) || !MODEL_KINDS.includes(x.kind)) continue;
      const g = e.scene.planOf(v.view, x, pc);
      if (g) appendPlan(out, g, f);
    }
    // Nested modules, drawn by the inner project's own links.
    for (const x of e.doc.all('link')) appendPlan(out, e.scene.linkPlan(v.view, x), f);
    return out;
  }
}

/** A mesh with every surface in a painted material's colour (and its transparency). */
function painted(mesh, mat) {
  if (mat?.kind !== 'material') return mesh;
  const n = parseInt(String(mat.color || '#c8c8c8').slice(1, 7), 16) || 0;
  const a = Math.round(255 * Math.max(0.05, Math.min(1, mat.opacity ?? 1)));
  const col = new Uint8Array(mesh.col.length);
  for (let i = 0; i < col.length; i += 4) {
    col[i] = (n >> 16) & 255;
    col[i + 1] = (n >> 8) & 255;
    col[i + 2] = n & 255;
    col[i + 3] = a;
  }
  return { ...mesh, col };
}

/** Demolished elements: every line dashed, cut fills left out. */
function dashed(g) {
  const b = new PlanBuilder();
  for (const l of g.lines) b.lines.push({ ...l, d: 2, w: Math.min(l.w, 3) });
  b.picks = g.picks;
  b.texts = g.texts;
  return b;
}

function wallSignature(g) {
  const r = (p) => `${p[0].toFixed(2)},${p[1].toFixed(2)}`;
  return `${r(g.L0)} ${r(g.L1)} ${r(g.R0)} ${r(g.R1)} ${g.base} ${g.top} ${g.ends.map((e) => e.kind + (e.angle ?? '')).join('/')} ${JSON.stringify(g.cuts)}`;
}

function sameDeps(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}

/** A mesh with its texture coordinates moved to a new origin (du, dv) and turned by angle (radians). */
export function alignedTextures(mesh, { du = 0, dv = 0, angle = 0 } = {}) {
  const c = Math.cos(-angle);
  const s = Math.sin(-angle);
  const tex = mesh.tex.map((g) => {
    const uv = new Float32Array(g.uv.length);
    for (let i = 0; i < uv.length; i += 2) {
      const u = g.uv[i] - du;
      const v = g.uv[i + 1] - dv;
      uv[i] = u * c - v * s;
      uv[i + 1] = u * s + v * c;
    }
    return { ...g, uv };
  });
  return { ...mesh, tex };
}
