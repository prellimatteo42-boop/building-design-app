/**
 * Revisions: a numbered list of changes issued with the drawings. Revision
 * clouds mark what changed in a view; a sheet's title block lists every
 * revision clouded on the sheet or in the views placed on it.
 *
 *   revision { seq, number, date, description, issuedTo, issuedBy, issued }
 */

export function newRevision(doc) {
  const seq = doc.all('revision').reduce((m, r) => Math.max(m, +r.seq || 0), 0) + 1;
  return { kind: 'revision', seq, number: String(seq), date: new Date().toISOString().slice(0, 10), description: `Revision ${seq}`, issuedTo: '', issuedBy: '', issued: false };
}

export function revisionsInOrder(doc) {
  return doc.all('revision').sort((a, b) => (+a.seq || 0) - (+b.seq || 0));
}

/** Revisions clouded on a sheet or in the views placed on it, in order. */
export function revisionsOnSheet(doc, sheet) {
  const views = new Set([sheet.id]);
  for (const vp of doc.all('viewport')) if (vp.viewId === sheet.id) views.add(vp.placedId);
  const ids = new Set();
  for (const c of doc.all('revisionCloud')) if (views.has(c.viewId) && c.revisionId) ids.add(c.revisionId);
  return revisionsInOrder(doc).filter((r) => ids.has(r.id));
}

/**
 * Changes, as in Archicad's Change Manager: every revision cloud is a change
 * marker with an ID ("C-01", given in order when it has none), a
 * description and the revision it is issued in. Returns them with the view
 * they are drawn in and the sheets that show that view.
 */
export function changesInOrder(doc) {
  const clouds = doc.all('revisionCloud');
  const sheetsOf = new Map();
  for (const vp of doc.all('viewport')) {
    if (!sheetsOf.has(vp.placedId)) sheetsOf.set(vp.placedId, []);
    sheetsOf.get(vp.placedId).push(vp.viewId);
  }
  const revs = new Map(revisionsInOrder(doc).map((r, i) => [r.id, i]));
  let n = 0;
  return clouds
    .map((c) => {
      const view = doc.get(c.viewId);
      const sheets = view?.kind === 'sheet' ? [view] : (sheetsOf.get(c.viewId) || []).map((id) => doc.get(id)).filter(Boolean);
      return { cloud: c, id: c.changeId || `C-${String(++n).padStart(2, '0')}`, description: c.changeDescription || '', revision: doc.get(c.revisionId) || null, view, sheets };
    })
    .sort((a, b) => (revs.get(a.revision?.id) ?? 1e9) - (revs.get(b.revision?.id) ?? 1e9) || String(a.id).localeCompare(String(b.id), undefined, { numeric: true }));
}

/** The next free change ID: C-01, C-02... */
export function nextChangeId(doc) {
  const used = new Set(doc.all('revisionCloud').map((c) => c.changeId).filter(Boolean));
  for (let i = 1; ; i++) {
    const id = `C-${String(i).padStart(2, '0')}`;
    if (!used.has(id)) return id;
  }
}
