/**
 * Story Settings, as in Archicad: stories numbered from the ground story
 * (0, with basements below it negative), each with its height to the next;
 * inserting a story above or below moves the stories over it up, deleting
 * one moves them down, and changing a story's height moves those above.
 */
import { planView } from './template.js';
import { deleteElements, uniqueName } from './ops.js';

export const DEFAULT_STORY_HEIGHT = 3000;

/** Stories in order: [{ level, number, height }] (height to the next story, or the default for the top one). */
export function storyTable(doc) {
  const lv = doc.levels();
  // The ground story: the lowest at or above elevation 0 (or the lowest of all).
  let g = lv.findIndex((l) => l.elevation >= -1);
  if (g < 0) g = lv.length - 1;
  return lv.map((level, i) => ({ level, number: i - g, height: i + 1 < lv.length ? lv[i + 1].elevation - level.elevation : (+level.storyHeight || DEFAULT_STORY_HEIGHT) }));
}

function shiftFrom(doc, elevation, dz, exceptId = null) {
  for (const l of doc.levels()) if (l.id !== exceptId && l.elevation >= elevation - 1e-6) doc.update(l.id, { elevation: l.elevation + dz });
}

/**
 * Insert a story above or below another (inside a transaction), with its
 * floor and ceiling plans; the stories it pushes move up. Returns the new level.
 */
export function insertStory(doc, refId, where = 'above', height = DEFAULT_STORY_HEIGHT, name = null) {
  const table = storyTable(doc);
  const i = table.findIndex((s) => s.level.id === refId);
  if (i < 0) return null;
  const ref = table[i];
  const at = where === 'below' ? ref.level.elevation : ref.level.elevation + ref.height;
  // Everything from the new story's elevation up moves up by its height.
  shiftFrom(doc, at, height);
  const level = doc.add({ kind: 'level', name: name || uniqueName(doc.levels().map((l) => l.name), `Level ${table.length + 1}`), elevation: at, storyHeight: height });
  doc.add(planView(doc, level));
  doc.add(planView(doc, level, 'ceilingPlan'));
  return level;
}

/** Delete a story with what is on it (inside a transaction); the stories above come down by its height. */
export function deleteStory(doc, id) {
  const table = storyTable(doc);
  const s = table.find((x) => x.level.id === id);
  if (!s || table.length <= 1) return false;
  const above = s.level.elevation + s.height;
  deleteElements(doc, [id]);
  shiftFrom(doc, above, -s.height);
  return true;
}

/** Change a story's height (inside a transaction): the stories above move by the difference. */
export function setStoryHeight(doc, id, height) {
  const s = storyTable(doc).find((x) => x.level.id === id);
  if (!s || !(height > 0)) return;
  const dz = height - s.height;
  if (Math.abs(dz) < 1e-6) return;
  shiftFrom(doc, s.level.elevation + s.height, dz, id);
  doc.update(id, { storyHeight: height });
}
