/**
 * Master layouts, as in Archicad: a sheet follows a master that sets its
 * paper size and its title block, a strip on the right, a bar along the
 * bottom or none, made of rows whose text is autotext of the project and
 * the sheet ({Project Name}, {Sheet Number}, ...).
 *
 *   masterLayout { kind: 'masterLayout', name, size, margin, strip: 'right' | 'bottom' | 'none',
 *                  rows: [{ label, text, size }] }
 *   sheet        masterId, optional: without one, the built-in title block
 */
import { revisionsOnSheet } from './revisions.js';

const ROWS = [
  { label: 'PROJECT', text: '{Project Name}', size: 4.2 },
  { label: 'PROJECT NUMBER', text: '{Project Number}', size: 3 },
  { label: 'CLIENT', text: '{Client}', size: 3 },
  { label: 'ADDRESS', text: '{Address}', size: 2.6 },
  { label: 'DRAWN BY', text: '{Drawn By}', size: 2.6 },
  { label: 'CHECKED BY', text: '{Checked By}', size: 2.6 },
  { label: 'DATE', text: '{Date}', size: 2.6 },
  { label: 'STATUS', text: '{Status}', size: 2.6 },
];

/** Master layouts of a new project. */
export function defaultMasterLayouts(imp = false) {
  return [
    { id: 'ml-standard', kind: 'masterLayout', name: 'Standard: Title Strip', size: imp ? 'ARCHD' : 'A1', margin: 10, strip: 'right', rows: ROWS.map((r) => ({ ...r })) },
    {
      id: 'ml-bottom',
      kind: 'masterLayout',
      name: 'Compact: Title Bar',
      size: imp ? 'TABLOID' : 'A3',
      margin: 10,
      strip: 'bottom',
      rows: [
        { label: 'PROJECT', text: '{Project Name}', size: 3.5 },
        { label: 'CLIENT', text: '{Client}', size: 2.5 },
        { label: 'DRAWN BY', text: '{Drawn By}', size: 2.5 },
        { label: 'DATE', text: '{Date}', size: 2.5 },
        { label: 'SCALE', text: '{Scales}', size: 2.5 },
      ],
    },
    { id: 'ml-blank', kind: 'masterLayout', name: 'Blank', size: imp ? 'ARCHD' : 'A1', margin: 10, strip: 'none', rows: [] },
  ];
}

/** The fields a master layout's rows can use, in braces. */
export const SHEET_FIELDS = ['Project Name', 'Project Number', 'Client', 'Address', 'Status', 'Author', 'Sheet Name', 'Sheet Number', 'Drawn By', 'Checked By', 'Date', 'Sheet Size', 'Revision', 'Sheet Count', 'Scales'];

/** Autotext of a sheet: the template with its {Field} tokens filled; unknown ones as "?". */
export function sheetText(doc, sheet, template, extra = {}) {
  const p = doc.project || {};
  const sheets = doc.all('sheet');
  const revs = revisionsOnSheet(doc, sheet);
  const values = {
    'project name': p.name,
    'project number': p.number,
    client: p.client,
    address: p.address,
    status: p.status,
    author: p.author,
    'sheet name': sheet.name,
    'sheet number': sheet.number,
    'drawn by': sheet.drawnBy || p.author,
    'checked by': sheet.checkedBy,
    date: sheet.issueDate || new Date().toISOString().slice(0, 10),
    'sheet size': sheet.size,
    revision: revs.length ? String(revs.at(-1).number ?? revs.at(-1).seq ?? '') : '',
    'sheet count': String(sheets.length),
    ...extra,
  };
  return String(template ?? '').replace(/\{([^{}]+)\}/g, (_, k) => {
    const v = values[k.trim().toLowerCase()];
    return v === undefined ? '?' : String(v ?? '');
  });
}
