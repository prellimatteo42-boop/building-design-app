/**
 * Reload Libraries and Set as Source Marker.
 *
 * Reload: GDL types made from library parts (gdl.source = the part's path)
 * take the part as the loaded library has it now — scripts, macros,
 * pictures and parameter defaults — keeping their names, sizes and each
 * placed object's own values.
 *
 * Source marker: a detail (a view with calloutOf and a crop) is defined by
 * its marker in its source view; a linked marker (viewRef) elsewhere can
 * become the source: the detail then comes from the linked marker's view,
 * cropped around it at the same size, and the old source gets a linked marker.
 */
import { partType } from './aclib.js';

/** Update the GDL types of a document from a library (inside a transaction). Returns { updated, missing }. */
export function reloadLibraryTypes(doc, lib) {
  const byPath = new Map([...lib.parts.values()].map((e) => [e.path, e]));
  let updated = 0;
  const missing = [];
  for (const t of doc.all('componentType', 'doorType', 'windowType')) {
    const src = t.gdl?.source;
    if (!src || !t.gdl.lenient) continue;
    const e = byPath.get(src);
    if (!e) {
      missing.push(t.name || src);
      continue;
    }
    const fresh = partType(lib, lib.get(e.name));
    if (!fresh?.gdl) continue;
    if (JSON.stringify(fresh.gdl) === JSON.stringify(t.gdl)) continue;
    doc.update(t.id, { gdl: fresh.gdl });
    updated++;
  }
  return { updated, missing };
}

/** Make a linked marker the source marker of its detail (inside a transaction). Returns a message, or throws. */
export function setAsSourceMarker(doc, refId) {
  const ref = doc.get(refId);
  if (ref?.kind !== 'viewRef') throw new Error('Select a linked view marker.');
  const detail = doc.get(ref.targetId);
  if (!detail?.calloutOf || !detail.crop) throw new Error('Only detail and worksheet markers can change their source here (sections and elevations are their own markers).');
  const oldSource = detail.calloutOf;
  const c = detail.crop;
  const w = c.x1 - c.x0;
  const h = c.y1 - c.y0;
  const center = [(c.x0 + c.x1) / 2, (c.y0 + c.y1) / 2];
  const at = ref.at || center;
  const src = doc.get(ref.viewId);
  if (!src) throw new Error('The linked marker is in no view.');
  doc.update(detail.id, { calloutOf: src.id, ...(src.levelId ? { levelId: src.levelId } : {}), crop: { ...c, x0: at[0] - w / 2, x1: at[0] + w / 2, y0: at[1] - h / 2, y1: at[1] + h / 2 } });
  doc.remove(ref.id);
  if (doc.get(oldSource)) doc.add({ kind: 'viewRef', viewId: oldSource, at: center, targetId: detail.id });
  return `${detail.name || 'The detail'} now comes from this view; its old source has a linked marker.`;
}
