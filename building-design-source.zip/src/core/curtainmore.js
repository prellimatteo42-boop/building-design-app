/**
 * Curtain wall extras, as in Archicad:
 *
 *   - Copy Cell Pattern: the panels and removed frames of a block of cells
 *     repeated along the wall (and/or up it);
 *   - Create Common Frames: where two curtain walls meet end to end, one
 *     frame instead of two (the second wall's end frames are removed);
 *   - Junction: at a corner of two curtain walls, a corner post replaces
 *     both end frames (`cwJunction` { walls: [id, id], at, levelId });
 *   - Join Wall(s) to Curtain Wall: ordinary walls that run into a curtain
 *     wall stop at its inner face;
 *   - Accessories on the frames (`wall.cwAccessory` { kind: 'fins' |
 *     'louvres' | 'caps', depth, width, spacing });
 *   - ArchiGlazing: a roof turned into a glazed roof (`glazedRoof`, with the
 *     roof's outline and slopes): glass on each face with rafters up the
 *     slope, transoms across and a frame round the edge.
 */
import { sub, dot, cross, dist, norm, perp } from './geom.js';
import { wallAxis, verticalExtent, levelElevation } from './model.js';
import { roofFaces, planeHeight } from './roof.js';

/** The curtain settings of a wall's type, or null when it is not a curtain wall. */
export const curtainOf = (doc, w) => (w?.kind === 'wall' && doc.get(w.typeId)?.curtain) || null;

// Copy Cell Pattern ---------------------------------------------------------------------------------

/**
 * Repeat a block of cells: { i0..i1 columns, j0..j1 rows } (inclusive, 0-based) over the grid nu × nv, along the
 * wall (alongU) and/or up it (alongV). Returns { panels, mullionsOff, frameClass } for the wall.
 */
export function copyCellPattern(w, nu, nv, src, { alongU = true, alongV = false } = {}) {
  const i0 = Math.max(0, Math.min(src.i0, src.i1));
  const i1 = Math.min(nu - 1, Math.max(src.i0, src.i1));
  const j0 = Math.max(0, Math.min(src.j0, src.j1));
  const j1 = Math.min(nv - 1, Math.max(src.j0, src.j1));
  const bu = i1 - i0 + 1;
  const bv = j1 - j0 + 1;
  const panels = { ...(w.panels || {}) };
  const off = new Set(w.mullionsOff || []);
  const srcPanel = (i, j) => w.panels?.[`${i}:${j}`] || 'glass';
  const srcOff = new Set(w.mullionsOff || []);
  const fc = { ...(w.frameClass || {}) };
  for (let i = 0; i < nu; i++)
    for (let j = 0; j < nv; j++) {
      const inU = i >= i0 && i <= i1;
      const inV = j >= j0 && j <= j1;
      if (inU && inV) continue;
      if (!alongU && !inU) continue;
      if (!alongV && !inV) continue;
      const si = i0 + ((((i - i0) % bu) + bu) % bu);
      const sj = j0 + ((((j - j0) % bv) + bv) % bv);
      const k = srcPanel(si, sj);
      if (k === 'glass') delete panels[`${i}:${j}`];
      else panels[`${i}:${j}`] = k;
      // The frames on the cell's left side and bottom follow the source cell's.
      for (const [key, skey] of [
        [`v:${i}:${j}`, `v:${si}:${sj}`],
        [`h:${j}:${i}`, `h:${sj}:${si}`],
      ])
      {
        srcOff.has(skey) ? off.add(key) : off.delete(key);
        if (w.frameClass?.[skey]) fc[key] = w.frameClass[skey];
        else delete fc[key];
      }
    }
  return { panels, mullionsOff: [...off], frameClass: Object.keys(fc).length ? fc : null };
}

// Common frames and junctions --------------------------------------------------------------------

/** Where two walls meet end to end: { ea, eb (0: a, 1: b), at } or null. */
export function sharedEnd(w1, w2, tol = 5) {
  for (const ea of [0, 1])
    for (const eb of [0, 1]) {
      const p = ea ? w1.b : w1.a;
      const q = eb ? w2.b : w2.a;
      if (dist(p, q) <= tol) return { ea, eb, at: p };
    }
  return null;
}

/** mullionsOff keys of every vertical frame segment at one end of a curtain wall (0: a, 1: b). */
export function endFrameKeys(nu, nv, end) {
  const i = end ? nu : 0;
  return Array.from({ length: nv }, (_, j) => `v:${i}:${j}`);
}

const cornerAngle = (doc, w1, w2) => {
  const d1 = wallAxis(doc, w1).dir;
  const d2 = wallAxis(doc, w2).dir;
  return Math.abs(cross(d1, d2));
};

/**
 * Create Common Frames / Junction for curtain walls (ids) whose ends meet, inside a transaction. With junction, walls
 * meeting at an angle get a corner post and both end frames go; walls in line keep one frame. Returns the number
 * of joints handled. grid(w) gives { nu, nv } of a wall.
 */
export function joinCurtainEnds(doc, ids, grid, { junction = false } = {}) {
  const walls = ids.map((id) => doc.get(id)).filter((w) => curtainOf(doc, w));
  let n = 0;
  for (let x = 0; x < walls.length; x++)
    for (let y = x + 1; y < walls.length; y++) {
      const w1 = doc.get(walls[x].id);
      const w2 = doc.get(walls[y].id);
      const s = sharedEnd(w1, w2);
      if (!s) continue;
      const g1 = grid(w1);
      const g2 = grid(w2);
      const angled = cornerAngle(doc, w1, w2) > 0.05;
      const off2 = new Set([...(w2.mullionsOff || []), ...endFrameKeys(g2.nu, g2.nv, s.eb)]);
      doc.update(w2.id, { mullionsOff: [...off2] });
      if (junction && angled) {
        const off1 = new Set([...(w1.mullionsOff || []), ...endFrameKeys(g1.nu, g1.nv, s.ea)]);
        doc.update(w1.id, { mullionsOff: [...off1] });
        if (!doc.all('cwJunction').some((j) => j.walls.includes(w1.id) && j.walls.includes(w2.id))) doc.add({ kind: 'cwJunction', walls: [w1.id, w2.id], at: s.at, levelId: w1.levelId });
      }
      n++;
    }
  return n;
}

/** A junction's corner post: { outline (plan), base, top, materialId }, square to the bisector of the two walls. */
export function junctionPost(doc, j) {
  const [w1, w2] = j.walls.map((id) => doc.get(id));
  const c = curtainOf(doc, w1);
  if (!c || !w2) return null;
  const d1 = wallAxis(doc, w1).dir;
  const d2 = wallAxis(doc, w2).dir;
  // Directions away from the corner along each wall.
  const s = sharedEnd(w1, w2, 50);
  const a1 = s?.ea ? [-d1[0], -d1[1]] : d1;
  const a2 = s?.eb ? [-d2[0], -d2[1]] : d2;
  let bis = norm([a1[0] + a2[0], a1[1] + a2[1]]);
  if (!Number.isFinite(bis[0])) bis = perp(a1);
  const side = Math.max(+c.mullionDepth || 150, +c.mullionWidth || 50) * 1.1;
  const half = side / 2;
  const n = perp(bis);
  const p = j.at;
  const P = (x, y) => [p[0] + bis[0] * x + n[0] * y, p[1] + bis[1] * x + n[1] * y];
  const { base, top } = verticalExtent(doc, w1);
  return { outline: [P(-half, -half), P(half, -half), P(half, half), P(-half, half)], base, top, materialId: c.materialId || 'mat-aluminum' };
}

// Join walls to curtain walls ---------------------------------------------------------------------

/**
 * Ordinary walls whose ends run into a curtain wall stop at its face on their side. Returns patches
 * [{ id, patch: { a } | { b } }] (not applied).
 */
export function wallsToCurtain(doc, wallIds, curtainIds) {
  const cws = curtainIds.map((id) => doc.get(id)).filter((w) => curtainOf(doc, w));
  const out = [];
  for (const id of wallIds) {
    const w = doc.get(id);
    if (!w || w.kind !== 'wall' || curtainOf(doc, w) || w.arc) continue;
    const ax = wallAxis(doc, w);
    for (const cw of cws) {
      const cax = wallAxis(doc, cw);
      const md = (+curtainOf(doc, cw).mullionDepth || 150) / 2;
      const nrm = cax.n;
      for (const end of [0, 1]) {
        const p = end ? w.b : w.a;
        const other = end ? w.a : w.b;
        const sp = dot(sub(p, cax.a), nrm);
        const so = dot(sub(other, cax.a), nrm);
        const u = dot(sub(p, cax.a), cax.dir);
        if (u < -ax.half || u > cax.length + ax.half) continue;
        // The end must be at the curtain wall or a little past it (up to 1 m), the wall coming from farther away.
        if (Math.abs(sp) > Math.max(1000, ax.half + md + 50) || Math.abs(so) <= Math.abs(sp) || Math.abs(so) < md) continue;
        if (Math.abs(sp) > ax.half + md + 50 && Math.sign(sp) === Math.sign(so)) continue;
        const side = Math.sign(so);
        const target = side * md;
        // Move the end along the wall's own direction to the face line.
        const d = sub(p, other);
        const dn = dot(d, nrm);
        if (Math.abs(dn) < 1e-6) continue;
        const t = (target - so) / dn;
        const q = [Math.round(other[0] + d[0] * t), Math.round(other[1] + d[1] * t)];
        if (dist(q, p) < 0.5) continue;
        out.push({ id, patch: end ? { b: q } : { a: q } });
      }
    }
  }
  return out;
}

// Accessories ----------------------------------------------------------------------------------------

export const CW_ACCESSORIES = [
  { value: 'fins', label: 'Vertical fins on the mullions', depth: 300, width: 40 },
  { value: 'louvres', label: 'Horizontal louvres over the panels', depth: 200, width: 30, spacing: 250 },
  { value: 'caps', label: 'Pressure caps on all frames', depth: 40, width: 60 },
];

/**
 * Boxes of a curtain wall's accessory in the wall's frame (u along, y out of the exterior face, z up):
 * [[u0, y0, z0, u1, y1, z1]].
 */
export function accessoryBoxes(acc, us, vs, mw, md, off = new Set()) {
  if (!acc?.kind) return [];
  const info = CW_ACCESSORIES.find((a) => a.value === acc.kind) || CW_ACCESSORIES[0];
  const depth = +acc.depth || info.depth;
  const width = +acc.width || info.width;
  const y0 = md / 2;
  const out = [];
  const H = vs.at(-1);
  if (acc.kind === 'fins' || acc.kind === 'caps') {
    for (let i = 0; i < us.length; i++)
      for (let j = 0; j + 1 < vs.length; j++) if (!off.has(`v:${i}:${j}`)) out.push([us[i] - width / 2, y0, vs[j], us[i] + width / 2, y0 + depth, vs[j + 1]]);
  }
  if (acc.kind === 'caps') {
    for (let j = 0; j < vs.length; j++)
      for (let i = 0; i + 1 < us.length; i++) if (!off.has(`h:${j}:${i}`)) out.push([us[i], y0, Math.max(0, vs[j] - width / 2), us[i + 1], y0 + depth, Math.min(H, vs[j] + width / 2)]);
  }
  if (acc.kind === 'louvres') {
    const sp = Math.max(50, +acc.spacing || info.spacing);
    for (let j = 0; j + 1 < vs.length; j++)
      for (let z = vs[j] + sp / 2; z < vs[j + 1] - width / 2; z += sp) out.push([us[0], y0 + 60, z - width / 2, us.at(-1), y0 + 60 + depth, z + width / 2]);
  }
  return out;
}

// ArchiGlazing ---------------------------------------------------------------------------------------

export const GLAZING_DEFAULTS = { spacing: 900, transoms: 1500, barWidth: 60, barDepth: 120 };

/** A glazed roof (not added) from a roof element: its outline, slopes and story, with the glazing settings. */
export function glazedRoofFrom(roof, opts = {}) {
  const keep = ['levelId', 'boundary', 'slopes', 'levels', 'overhangs', 'baseOffset', 'phaseId', 'layerId'];
  const out = { kind: 'glazedRoof', ...GLAZING_DEFAULTS, ...opts };
  for (const k of keep) if (roof[k] != null) out[k] = structuredClone(roof[k]);
  return out;
}

/**
 * Geometry of a glazed roof: faces (plan polygons with their planes), bars as 3D segments
 * [{ a, b, kind: 'rafter' | 'transom' | 'edge' }] on the glass plane, and the base height.
 */
export function glazingGeometry(doc, el) {
  if (!el.boundary || el.boundary.length < 3) return null;
  const base = levelElevation(doc, el.levelId) + (+el.baseOffset || 0);
  const { faces } = roofFaces(el.boundary, el.slopes, { levels: el.levels, overhangs: el.overhangs });
  const z = (p, pl) => base + (pl ? planeHeight(pl, p) : 0);
  const bars = [];
  const clipLine = (poly, o, d) => {
    // Parameter interval where the line o + t d lies inside the convex-or-not polygon (first in/out pair).
    const ts = [];
    for (let i = 0; i < poly.length; i++) {
      const p = poly[i];
      const q = poly[(i + 1) % poly.length];
      const e = sub(q, p);
      const den = cross(d, e);
      if (Math.abs(den) < 1e-9) continue;
      const w = sub(p, o);
      const t = cross(w, e) / den;
      const s = cross(w, d) / den;
      if (s >= -1e-9 && s <= 1 + 1e-9) ts.push(t);
    }
    ts.sort((a, b) => a - b);
    const out = [];
    for (let k = 0; k + 1 < ts.length; k += 2) if (ts[k + 1] - ts[k] > 1) out.push([ts[k], ts[k + 1]]);
    return out;
  };
  for (const f of faces) {
    const poly = f.poly;
    for (let i = 0; i < poly.length; i++) {
      const p = poly[i];
      const q = poly[(i + 1) % poly.length];
      bars.push({ a: [p[0], p[1], z(p, f.plane)], b: [q[0], q[1], z(q, f.plane)], kind: 'edge' });
    }
    const up = f.plane ? f.plane.m : [0, 1];
    const across = perp(up);
    const proj = (v) => poly.map((p) => dot(p, v));
    const lines = (dirAlong, dirStep, spacing, kind) => {
      const s = proj(dirStep);
      const lo = Math.min(...s);
      const hi = Math.max(...s);
      const n = Math.max(1, Math.round((hi - lo) / spacing));
      const step = (hi - lo) / n;
      for (let k = 1; k < n; k++) {
        const c = lo + k * step;
        const o = [dirStep[0] * c, dirStep[1] * c];
        for (const [t0, t1] of clipLine(poly, o, dirAlong)) {
          const a = [o[0] + dirAlong[0] * t0, o[1] + dirAlong[1] * t0];
          const b = [o[0] + dirAlong[0] * t1, o[1] + dirAlong[1] * t1];
          bars.push({ a: [a[0], a[1], z(a, f.plane)], b: [b[0], b[1], z(b, f.plane)], kind });
        }
      }
    };
    lines(up, across, +el.spacing || GLAZING_DEFAULTS.spacing, 'rafter');
    if (+el.transoms > 0) lines(across, up, +el.transoms, 'transom');
  }
  return { faces, bars, base, z };
}
