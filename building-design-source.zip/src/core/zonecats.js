/**
 * Zone categories, as in Archicad: each room (Archicad's zone) belongs to a
 * category with a name, a code and a color, used to fill zones in plan and
 * in schedules. A room without a category gets one from its name when a
 * keyword matches (a "Kitchen" is in Kitchen), so older projects color in
 * sensibly; choosing a category on the room overrides that.
 */

const CATS = [
  ['zc-living', 'Living', 'LIV', '#f2c879', ['living', 'lounge', 'dining', 'family', 'soggiorno', 'salotto', 'pranzo']],
  ['zc-sleeping', 'Sleeping', 'SLP', '#9fc3e8', ['bed', 'sleep', 'guest', 'camera', 'letto']],
  ['zc-kitchen', 'Kitchen', 'KIT', '#f0a27a', ['kitchen', 'pantry', 'cucina']],
  ['zc-sanitary', 'Sanitary', 'SAN', '#8fd3cf', ['bath', 'wc', 'toilet', 'shower', 'powder', 'laundry', 'bagno', 'lavanderia']],
  ['zc-circulation', 'Circulation', 'CIR', '#d9d9d2', ['hall', 'corridor', 'entry', 'foyer', 'lobby', 'stair', 'landing', 'ingresso', 'corridoio', 'disimpegno']],
  ['zc-storage', 'Storage', 'STO', '#c9b79c', ['store', 'storage', 'closet', 'wardrobe', 'cellar', 'ripostiglio', 'cantina']],
  ['zc-office', 'Office', 'OFF', '#b9a4dc', ['office', 'study', 'work', 'meeting', 'studio', 'ufficio']],
  ['zc-technical', 'Technical', 'TEC', '#a9b0b8', ['plant', 'mechanical', 'utility', 'boiler', 'server', 'garage', 'tecnico', 'centrale']],
  ['zc-outdoor', 'Outdoor', 'OUT', '#a8d39a', ['terrace', 'balcony', 'porch', 'deck', 'patio', 'terrazza', 'balcone', 'portico']],
];

export function defaultZoneCategories() {
  return CATS.map(([id, name, code, color]) => ({ id, kind: 'zoneCategory', name, code, color }));
}

/** The category a room name suggests, by keyword, or null. */
export function guessZoneCategory(name) {
  const n = String(name || '').toLowerCase();
  if (!n) return null;
  for (const [id, , , , words] of CATS) if (words.some((w) => n.includes(w))) return id;
  return null;
}

/** A room's category: the one chosen on it, or the one its name suggests (if the project has it). */
export function zoneCategoryOf(doc, room) {
  const own = room.zoneCategoryId && doc.get(room.zoneCategoryId);
  if (own) return own;
  if (room.zoneCategoryId === '') return null; // chosen: none
  const g = guessZoneCategory(room.name);
  return (g && doc.get(g)) || null;
}

/** [r, g, b, a] of a #rrggbb color. */
export function rgba(hex, a = 120) {
  const n = parseInt(String(hex || '#cccccc').replace('#', '').slice(0, 6), 16) || 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255, a];
}

/**
 * Stamp lines of a room by style: 'standard' (name, then number and area),
 * 'detailed' (also category, height and volume, and the floor finish),
 * 'compact' (number and area) or 'none'. Each line: { text, bold, size }
 * with size relative to the standard text.
 */
export function stampLines(room, info) {
  const style = room.stamp || 'standard';
  if (style === 'none') return [];
  const name = (room.name || 'Room').toUpperCase();
  const numArea = [room.number || '', info.area].filter(Boolean).join('   ');
  if (style === 'compact') return [{ text: numArea || name, bold: true, size: 1 }];
  const out = [{ text: name, bold: true, size: 1 }, { text: numArea, size: 0.8, color: info.color }];
  if (style === 'detailed') {
    if (info.category) out.push({ text: info.category, size: 0.7 });
    if (info.height) out.push({ text: `h ${info.height}   V ${info.volume}`, size: 0.7 });
    if (room.floorFinish) out.push({ text: room.floorFinish, size: 0.7 });
  }
  return out;
}
