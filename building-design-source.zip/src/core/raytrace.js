/**
 * Ray tracing: path tracing over the model's triangles, on the CPU, with no
 * dependencies, so it runs alike in workers and in tests.
 *
 * The scene is { pos: Float32Array (9 per triangle, mm), col: Uint8Array (4 per triangle) };
 * a colour's alpha says what the surface is: below 250 glass, 253 glossy, 254 satin, 255 matte.
 * Each pass adds one sample per pixel with its own random numbers, so several
 * workers can add up to one image.
 */
const LEAF = 4;
const EPS = 1; // mm

/** A bounding volume hierarchy over the triangles: { pos, col, min, max, left, count } with triangles reordered into its leaves. */
export function buildScene({ pos, col }) {
  const n = pos.length / 9;
  const order = new Uint32Array(n);
  const cx = new Float32Array(n);
  const cy = new Float32Array(n);
  const cz = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    order[i] = i;
    cx[i] = (pos[9 * i] + pos[9 * i + 3] + pos[9 * i + 6]) / 3;
    cy[i] = (pos[9 * i + 1] + pos[9 * i + 4] + pos[9 * i + 7]) / 3;
    cz[i] = (pos[9 * i + 2] + pos[9 * i + 5] + pos[9 * i + 8]) / 3;
  }
  const cap = Math.max(1, 2 * n);
  const min = new Float32Array(cap * 3);
  const max = new Float32Array(cap * 3);
  const left = new Uint32Array(cap);
  const count = new Uint32Array(cap);
  let used = 1;
  const stack = [[0, 0, n]];
  while (stack.length) {
    const [node, a, b] = stack.pop();
    let [x0, y0, z0, x1, y1, z1] = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];
    let [c0, c1, c2, c3, c4, c5] = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];
    for (let k = a; k < b; k++) {
      const t = order[k];
      for (let v = 0; v < 3; v++) {
        const [px, py, pz] = [pos[9 * t + 3 * v], pos[9 * t + 3 * v + 1], pos[9 * t + 3 * v + 2]];
        if (px < x0) x0 = px;
        if (px > x1) x1 = px;
        if (py < y0) y0 = py;
        if (py > y1) y1 = py;
        if (pz < z0) z0 = pz;
        if (pz > z1) z1 = pz;
      }
      c0 = Math.min(c0, cx[t]);
      c3 = Math.max(c3, cx[t]);
      c1 = Math.min(c1, cy[t]);
      c4 = Math.max(c4, cy[t]);
      c2 = Math.min(c2, cz[t]);
      c5 = Math.max(c5, cz[t]);
    }
    min[3 * node] = x0;
    min[3 * node + 1] = y0;
    min[3 * node + 2] = z0;
    max[3 * node] = x1;
    max[3 * node + 1] = y1;
    max[3 * node + 2] = z1;
    const [dx, dy, dz] = [c3 - c0, c4 - c1, c5 - c2];
    const span = Math.max(dx, dy, dz);
    if (b - a <= LEAF || span < 1e-6) {
      left[node] = a;
      count[node] = b - a;
      continue;
    }
    const axis = dx === span ? cx : dy === span ? cy : cz;
    const cut = (dx === span ? c0 : dy === span ? c1 : c2) + span / 2;
    let i = a;
    let j = b - 1;
    while (i <= j) {
      if (axis[order[i]] < cut) i++;
      else {
        const s = order[i];
        order[i] = order[j];
        order[j--] = s;
      }
    }
    const mid = i === a || i === b ? (a + b) >> 1 : i;
    const l = used;
    used += 2;
    left[node] = l;
    count[node] = 0;
    stack.push([l, a, mid], [l + 1, mid, b]);
  }
  const P = new Float32Array(9 * n);
  const C = new Uint8Array(4 * n);
  for (let k = 0; k < n; k++) {
    const t = order[k];
    for (let v = 0; v < 9; v++) P[9 * k + v] = pos[9 * t + v];
    for (let v = 0; v < 4; v++) C[4 * k + v] = col[4 * t + v];
  }
  return { pos: P, col: C, min, max, left, count, n };
}

const stackBuf = new Uint32Array(128);

/** Nearest triangle along a ray: its index, or -1. hit[0] gets the distance, hit[1..3] the unit normal facing the ray. */
export function closest(s, ox, oy, oz, dx, dy, dz, hit, clip = null) {
  return walk(s, ox, oy, oz, dx, dy, dz, Infinity, hit, false, clip);
}

/** Whether anything but glass stands within dist along a ray. */
export function blocked(s, ox, oy, oz, dx, dy, dz, dist, clip = null) {
  return walk(s, ox, oy, oz, dx, dy, dz, dist, null, true, clip) >= 0;
}

function walk(s, ox, oy, oz, dx, dy, dz, tMax, hit, any, clip) {
  if (!s.n) return -1;
  const { pos: P, col: C, min, max, left, count } = s;
  const [ix, iy, iz] = [1 / dx, 1 / dy, 1 / dz];
  let best = -1;
  let t = tMax;
  let sp = 0;
  stackBuf[sp++] = 0;
  while (sp) {
    const node = stackBuf[--sp];
    let t0 = (min[3 * node] - ox) * ix;
    let t1 = (max[3 * node] - ox) * ix;
    let lo = Math.min(t0, t1);
    let hi = Math.max(t0, t1);
    t0 = (min[3 * node + 1] - oy) * iy;
    t1 = (max[3 * node + 1] - oy) * iy;
    lo = Math.max(lo, Math.min(t0, t1));
    hi = Math.min(hi, Math.max(t0, t1));
    t0 = (min[3 * node + 2] - oz) * iz;
    t1 = (max[3 * node + 2] - oz) * iz;
    lo = Math.max(lo, Math.min(t0, t1));
    hi = Math.min(hi, Math.max(t0, t1));
    if (hi < Math.max(lo, 0) || lo > t) continue;
    const c = count[node];
    if (!c) {
      stackBuf[sp++] = left[node];
      stackBuf[sp++] = left[node] + 1;
      continue;
    }
    for (let k = left[node], e = k + c; k < e; k++) {
      if (any && C[4 * k + 3] < 250) continue;
      const q = 9 * k;
      const [ax, ay, az] = [P[q], P[q + 1], P[q + 2]];
      const [e1x, e1y, e1z, e2x, e2y, e2z] = [P[q + 3] - ax, P[q + 4] - ay, P[q + 5] - az, P[q + 6] - ax, P[q + 7] - ay, P[q + 8] - az];
      const px = dy * e2z - dz * e2y;
      const py = dz * e2x - dx * e2z;
      const pz = dx * e2y - dy * e2x;
      const det = e1x * px + e1y * py + e1z * pz;
      if (det > -1e-9 && det < 1e-9) continue;
      const inv = 1 / det;
      const [tx, ty, tz] = [ox - ax, oy - ay, oz - az];
      const u = (tx * px + ty * py + tz * pz) * inv;
      if (u < 0 || u > 1) continue;
      const qx = ty * e1z - tz * e1y;
      const qy = tz * e1x - tx * e1z;
      const qz = tx * e1y - ty * e1x;
      const v = (dx * qx + dy * qy + dz * qz) * inv;
      if (v < 0 || u + v > 1) continue;
      const d = (e2x * qx + e2y * qy + e2z * qz) * inv;
      if (d <= EPS * 0.01 || d >= t) continue;
      if (clip && clipped(clip, ox + dx * d, oy + dy * d, oz + dz * d)) continue;
      if (any) return k;
      t = d;
      best = k;
    }
  }
  if (best >= 0 && hit) {
    const q = 9 * best;
    const [e1x, e1y, e1z, e2x, e2y, e2z] = [P[q + 3] - P[q], P[q + 4] - P[q + 1], P[q + 5] - P[q + 2], P[q + 6] - P[q], P[q + 7] - P[q + 1], P[q + 8] - P[q + 2]];
    let nx = e1y * e2z - e1z * e2y;
    let ny = e1z * e2x - e1x * e2z;
    let nz = e1x * e2y - e1y * e2x;
    const m = Math.hypot(nx, ny, nz) || 1;
    const f = nx * dx + ny * dy + nz * dz > 0 ? -1 / m : 1 / m;
    nx *= f;
    ny *= f;
    nz *= f;
    hit[0] = t;
    hit[1] = nx;
    hit[2] = ny;
    hit[3] = nz;
  }
  return best;
}

/** Whether a point is cut away by the view's clip planes [nx, ny, nz, d] (gone where n.p > d). */
function clipped(planes, x, y, z) {
  for (const p of planes) if (p[0] * x + p[1] * y + p[2] * z > p[3]) return true;
  return false;
}

const toLinear = (b) => {
  const c = b / 255;
  return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
};
const LINEAR = Float32Array.from({ length: 256 }, (_, i) => toLinear(i));

/** A small, fast random number generator (xorshift32), one per worker. */
export function rng(seed) {
  let x = seed >>> 0 || 2463534242;
  return () => {
    x ^= x << 13;
    x >>>= 0;
    x ^= x >>> 17;
    x ^= x << 5;
    x >>>= 0;
    return x / 4294967296;
  };
}

/** The sky's radiance towards a direction (linear RGB into out). */
export function sky(dz, day, out) {
  const t = Math.max(-1, Math.min(1, dz));
  if (t < 0) {
    out[0] = 0.28 * day;
    out[1] = 0.26 * day;
    out[2] = 0.23 * day;
    return;
  }
  const k = Math.pow(1 - t, 3);
  out[0] = (0.22 + 0.68 * k) * day;
  out[1] = (0.42 + 0.5 * k) * day;
  out[2] = (0.82 + 0.16 * k) * day;
}

const tmp = new Float32Array(3);
const hit = new Float64Array(4);

/** One light path from a camera ray: linear RGB added to out[0..2]. */
function radiance(s, ox, oy, oz, dx, dy, dz, o, R, out) {
  let [Tr, Tg, Tb] = [1, 1, 1];
  const { sun, sunPower, day, lamps, clip, depth } = o;
  for (let bounce = 0, passes = 0; bounce < depth; bounce++) {
    const k = closest(s, ox, oy, oz, dx, dy, dz, hit, clip);
    if (k < 0) {
      sky(dz, day, tmp);
      out[0] += Tr * tmp[0];
      out[1] += Tg * tmp[1];
      out[2] += Tb * tmp[2];
      return;
    }
    const [t, nx, ny, nz] = hit;
    const [px, py, pz] = [ox + dx * t + nx * EPS, oy + dy * t + ny * EPS, oz + dz * t + nz * EPS];
    const [ar, ag, ab, aa] = [LINEAR[s.col[4 * k]], LINEAR[s.col[4 * k + 1]], LINEAR[s.col[4 * k + 2]], s.col[4 * k + 3]];
    const cos = Math.max(0, -(dx * nx + dy * ny + dz * nz));
    const glass = aa < 250;
    const shine = glass ? 2 : 255 - aa;
    if (shine > 0) {
      const f0 = glass ? 0.04 : shine === 2 ? 0.55 : 0.05;
      const F = f0 + (1 - f0) * (1 - cos) ** 5;
      if (R() < F) {
        const dot = 2 * cos;
        let [rx, ry, rz] = [dx + nx * dot, dy + ny * dot, dz + nz * dot];
        // A little roughness; none on glass.
        if (!glass) {
          const a = shine === 2 ? 0.03 : 0.12;
          rx += (R() - 0.5) * a;
          ry += (R() - 0.5) * a;
          rz += (R() - 0.5) * a;
          const m = Math.hypot(rx, ry, rz) || 1;
          rx /= m;
          ry /= m;
          rz /= m;
          if (!glass && shine === 2) {
            Tr *= Math.max(ar, 0.5);
            Tg *= Math.max(ag, 0.5);
            Tb *= Math.max(ab, 0.5);
          }
        }
        [ox, oy, oz, dx, dy, dz] = [px, py, pz, rx, ry, rz];
        continue;
      }
      if (glass) {
        // Straight through, tinted a little: thin panes bend nothing that shows.
        Tr *= 0.92 * (0.75 + 0.25 * ar);
        Tg *= 0.92 * (0.75 + 0.25 * ag);
        Tb *= 0.92 * (0.75 + 0.25 * ab);
        [ox, oy, oz] = [ox + dx * (t + EPS), oy + dy * (t + EPS), oz + dz * (t + EPS)];
        // Panes do not count as bounces, within reason.
        if (++passes < 8) bounce--;
        continue;
      }
    }
    // Sunlight, from a disc a little wider than the sun's, for soft edges.
    if (sunPower > 0) {
      let [lx, ly, lz] = [sun[0] + (R() - 0.5) * 0.04, sun[1] + (R() - 0.5) * 0.04, sun[2] + (R() - 0.5) * 0.04];
      const m = Math.hypot(lx, ly, lz) || 1;
      lx /= m;
      ly /= m;
      lz /= m;
      const c = lx * nx + ly * ny + lz * nz;
      if (c > 0 && !blocked(s, px, py, pz, lx, ly, lz, Infinity, clip)) {
        const e = (sunPower * c) / Math.PI;
        out[0] += Tr * ar * e * 1.0;
        out[1] += Tg * ag * e * 0.95;
        out[2] += Tb * ab * e * 0.85;
      }
    }
    // One lamp at a time, weighted by how many there are.
    if (lamps.length) {
      const l = lamps[Math.floor(R() * lamps.length)];
      const [vx, vy, vz] = [l.at[0] - px, l.at[1] - py, l.at[2] - pz];
      const d = Math.hypot(vx, vy, vz);
      if (d > 1 && d < l.range) {
        const [wx, wy, wz] = [vx / d, vy / d, vz / d];
        const c = wx * nx + wy * ny + wz * nz;
        if (c > 0 && !blocked(s, px, py, pz, wx, wy, wz, d - 2, clip)) {
          const q = 1 - (d / l.range) ** 2;
          const e = (c * q * q * lamps.length * 3) / (1 + (d / 2000) ** 2) / Math.PI;
          out[0] += Tr * ar * l.color[0] * e;
          out[1] += Tg * ag * l.color[1] * e;
          out[2] += Tb * ab * l.color[2] * e;
        }
      }
    }
    Tr *= ar;
    Tg *= ag;
    Tb *= ab;
    if (bounce > 1) {
      const keep = Math.max(Tr, Tg, Tb, 0.05);
      if (R() > keep) return;
      Tr /= keep;
      Tg /= keep;
      Tb /= keep;
    }
    // On to a random direction, more of them near the normal.
    const u = R();
    const a = 2 * Math.PI * R();
    const r = Math.sqrt(u);
    const z = Math.sqrt(1 - u);
    const ex = Math.abs(nx) > 0.9 ? [0, 1, 0] : [1, 0, 0];
    let bx = ny * ex[2] - nz * ex[1];
    let by = nz * ex[0] - nx * ex[2];
    let bz = nx * ex[1] - ny * ex[0];
    const m2 = Math.hypot(bx, by, bz) || 1;
    bx /= m2;
    by /= m2;
    bz /= m2;
    const cxv = ny * bz - nz * by;
    const cyv = nz * bx - nx * bz;
    const czv = nx * by - ny * bx;
    const [ca, sa] = [Math.cos(a) * r, Math.sin(a) * r];
    [ox, oy, oz, dx, dy, dz] = [px, py, pz, bx * ca + cxv * sa + nx * z, by * ca + cyv * sa + ny * z, bz * ca + czv * sa + nz * z];
  }
}

/**
 * One sample per pixel: a Float32Array of width × height × 3 (linear RGB, top row first).
 * cam: { eye, right, up, forward, tanH, persp, halfH }. o: { sun, sunPower, day, lamps, clip, depth }.
 */
export function tracePass(s, cam, W, H, o, seed) {
  const R = rng(seed);
  const img = new Float32Array(W * H * 3);
  const out = new Float64Array(3);
  const aspect = W / H;
  const { eye, right: r, up: u, forward: f, tanH, persp } = cam;
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      const sx = (2 * (x + R())) / W - 1;
      const sy = 1 - (2 * (y + R())) / H;
      out[0] = out[1] = out[2] = 0;
      if (persp) {
        const a = sx * aspect * tanH;
        const b = sy * tanH;
        let [dx, dy, dz] = [f[0] + r[0] * a + u[0] * b, f[1] + r[1] * a + u[1] * b, f[2] + r[2] * a + u[2] * b];
        const m = Math.hypot(dx, dy, dz);
        dx /= m;
        dy /= m;
        dz /= m;
        radiance(s, eye[0], eye[1], eye[2], dx, dy, dz, o, R, out);
      } else {
        const a = sx * aspect * cam.halfH;
        const b = sy * cam.halfH;
        radiance(s, eye[0] + r[0] * a + u[0] * b, eye[1] + r[1] * a + u[1] * b, eye[2] + r[2] * a + u[2] * b, f[0], f[1], f[2], o, R, out);
      }
      const i = 3 * (y * W + x);
      img[i] = Math.min(out[0], 8);
      img[i + 1] = Math.min(out[1], 8);
      img[i + 2] = Math.min(out[2], 8);
    }
  return img;
}

/** Linear light to display bytes (ACES-style tone curve, then sRGB), RGBA into out. */
export function toneMap(sum, samples, out, exposure = 1) {
  const n = sum.length / 3;
  const k = exposure / Math.max(1, samples);
  const curve = (v) => {
    const c = Math.max(0, (v * (2.51 * v + 0.03)) / (v * (2.43 * v + 0.59) + 0.14));
    const g = c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055;
    return Math.max(0, Math.min(255, Math.round(g * 255)));
  };
  for (let i = 0; i < n; i++) {
    out[4 * i] = curve(sum[3 * i] * k);
    out[4 * i + 1] = curve(sum[3 * i + 1] * k);
    out[4 * i + 2] = curve(sum[3 * i + 2] * k);
    out[4 * i + 3] = 255;
  }
}
