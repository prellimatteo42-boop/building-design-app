/**
 * Measuring a room from one photo taken square to a wall: the far wall's corners in the picture, something of known
 * width on that wall, and something of known length running along the floor towards the camera. The camera is a pinhole
 * at the picture's centre, so one known length on the wall gives the scale there and one along the floor gives the distance.
 */

const mid = (p, q) => [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2];

/**
 * { wall: { top_left, top_right, bottom_right, bottom_left } px, width_ref: { a, b, mm } on the wall, depth_ref: { near, far, mm } on the floor,
 *   vanishing_point (optional: where lines running away from the camera meet), image: [w, h] }.
 * Returns { room_width, room_height, camera_distance, eye_height, camera_x (from the left corner), fov (vertical degrees), pixels_per_mm } or { error }.
 */
export function measurePhoto({ wall, width_ref, depth_ref, vanishing_point, image }) {
  const { top_left: tl, top_right: tr, bottom_right: br, bottom_left: bl } = wall || {};
  if (![tl, tr, br, bl].every(Array.isArray)) return { error: 'Give the four corners of the far wall, in pixels' };
  if (!width_ref?.a || !width_ref?.b || !(+width_ref.mm > 0)) return { error: 'Give width_ref: two points on the far wall and their distance in mm' };
  if (!Array.isArray(image) || !(image[0] > 0)) return { error: 'Give image: [width, height] in pixels' };
  const s = Math.hypot(width_ref.b[0] - width_ref.a[0], width_ref.b[1] - width_ref.a[1]) / +width_ref.mm;
  if (!(s > 0)) return { error: 'width_ref has no length in the picture' };
  const room_width = (Math.hypot(tr[0] - tl[0], tr[1] - tl[1]) + Math.hypot(br[0] - bl[0], br[1] - bl[1])) / 2 / s;
  const room_height = (Math.hypot(bl[0] - tl[0], bl[1] - tl[1]) + Math.hypot(br[0] - tr[0], br[1] - tr[1])) / 2 / s;
  const vp = Array.isArray(vanishing_point) ? vanishing_point : [image[0] / 2, image[1] / 2];
  const floorAtWall = mid(bl, br)[1];
  const eye_height = (floorAtWall - vp[1]) / s;
  const out = { room_width: Math.round(room_width), room_height: Math.round(room_height), eye_height: Math.round(eye_height), camera_x: Math.round((vp[0] - tl[0]) / s), pixels_per_mm: Math.round(s * 1e4) / 1e4 };
  if (depth_ref?.near && depth_ref?.far && +depth_ref.mm > 0) {
    const yFar = depth_ref.far[1] - vp[1];
    const yNear = depth_ref.near[1] - vp[1];
    if (!(yFar > 0) || !(yNear > yFar)) return { ...out, warning: 'depth_ref: the near point must be lower in the picture than the far one, and both below the horizon' };
    const k = yNear / yFar;
    // Offset from the wall of the far point, seen from its height in the picture.
    const offset = (floorAtWall - depth_ref.far[1]) > 0 ? (floorAtWall - vp[1]) / yFar : 1;
    const zFar = (+depth_ref.mm * k) / (k - 1);
    const distance = zFar * offset;
    const f = s * distance;
    out.camera_distance = Math.round(distance);
    out.fov = Math.round(((2 * Math.atan(image[1] / 2 / f) * 180) / Math.PI) * 10) / 10;
  }
  return out;
}

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const unit = (a) => {
  const m = Math.hypot(...a) || 1;
  return a.map((v) => v / m);
};

/** Where lines of the picture, each [[x, y], [x, y]], meet: the best point in the least-squares sense, or null if they are parallel. */
export function vanishingPoint(lines) {
  let [a, b, c, d, e] = [0, 0, 0, 0, 0];
  for (const [p, q] of lines) {
    const n = unit([p[1] - q[1], q[0] - p[0], 0]);
    const k = n[0] * p[0] + n[1] * p[1];
    a += n[0] * n[0];
    b += n[0] * n[1];
    c += n[1] * n[1];
    d += n[0] * k;
    e += n[1] * k;
  }
  const det = a * c - b * b;
  if (Math.abs(det) < 1e-6) return null;
  return [(c * d - b * e) / det, (a * e - b * d) / det];
}

/**
 * Measures a room from a photo taken at an angle, from the lines of its two wall directions. All in the picture's pixels:
 * { image: [w, h], lines_x, lines_y: floor or ceiling edges (and anything parallel) along each of the two directions, two or more each,
 *   origin: the floor corner to measure from, ref: { a, b, mm }, a known length lying on the floor, points: { name: [x, y] } on the floor to locate }.
 * Returns { eye [x, y, z], target [x, y, z], fov (vertical degrees), points: { name: [x, y] } } in mm from that corner, x along lines_x, y along lines_y; or { error }.
 */
export function measureObliquePhoto({ image, lines_x, lines_y, origin, ref, points = {} }) {
  if (!Array.isArray(image) || !lines_x?.length || !lines_y?.length || !origin || !ref?.a || !ref?.b || !(+ref.mm > 0)) return { error: 'Give image, lines_x and lines_y (two or more each), origin, and ref { a, b, mm }' };
  const [vx, vy] = [vanishingPoint(lines_x), vanishingPoint(lines_y)];
  if (!vx || !vy) return { error: 'The lines of one direction do not meet: the photo is square to that wall, so use the other form of measure_photo' };
  const c = [image[0] / 2, image[1] / 2];
  const f2 = -((vx[0] - c[0]) * (vy[0] - c[0]) + (vx[1] - c[1]) * (vy[1] - c[1]));
  if (!(f2 > 0)) return { error: 'These lines cannot be two square directions of a room seen by a camera: check that each set really runs one way' };
  const f = Math.sqrt(f2);
  const ray = (p) => [(p[0] - c[0]) / f, (p[1] - c[1]) / f, 1];
  let X = unit(ray(vx));
  let Y = unit(ray(vy));
  let Z = unit(cross(X, Y));
  // Picture y runs down, so up is towards negative camera y.
  if (Z[1] > 0) Z = Z.map((v) => -v);
  const world = (d) => [dot(d, X), dot(d, Y), dot(d, Z)];
  // On the floor, with the camera one unit above it.
  const floor = (p) => {
    const d = world(ray(p));
    if (d[2] >= 0) return null;
    const t = -1 / d[2];
    return [d[0] * t, d[1] * t];
  };
  const [o, a, b] = [floor(origin), floor(ref.a), floor(ref.b)];
  if (!o || !a || !b) return { error: 'origin and ref must be on the floor, below the horizon' };
  const scale = +ref.mm / Math.hypot(a[0] - b[0], a[1] - b[1]);
  const signs = [1, 1];
  const named = Object.entries(points).map(([k, p]) => [k, floor(p)]).filter(([, q]) => q);
  // The room lies on the positive side of its corner: the axes turn to make it so.
  for (const k of [0, 1]) {
    const spread = [a, b, ...named.map(([, q]) => q)].reduce((s, q) => s + (q[k] - o[k]), 0);
    if (spread < 0) signs[k] = -1;
  }
  const toRoom = (q) => [Math.round((q[0] - o[0]) * scale * signs[0]), Math.round((q[1] - o[1]) * scale * signs[1])];
  const eyeXY = toRoom([0, 0]);
  const H = Math.round(scale);
  const ahead = world([0, 0, 1]);
  const flat = Math.hypot(ahead[0], ahead[1]) || 1;
  const reach = 3000;
  const target = [Math.round(eyeXY[0] + ((ahead[0] * signs[0]) / flat) * reach), Math.round(eyeXY[1] + ((ahead[1] * signs[1]) / flat) * reach), Math.round(H + (ahead[2] / flat) * reach)];
  return { eye: [eyeXY[0], eyeXY[1], H], target, fov: Math.round(((2 * Math.atan(image[1] / 2 / f) * 180) / Math.PI) * 10) / 10, focal_px: Math.round(f), points: Object.fromEntries(named.map(([k, q]) => [k, toRoom(q)])) };
}
