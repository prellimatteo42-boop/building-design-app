/**
 * Measuring a room from one photo taken square to a wall: the far wall's corners in the picture, something of known
 * width on that wall, and something of known length running along the floor towards the camera. The camera is a pinhole
 * at the picture's centre, so one known length on the wall gives the scale there and one along the floor gives the distance.
 */

const mid = (p, q) => [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2];

/**
 * { wall: { top_left, top_right, bottom_right, bottom_left } px, width_ref: { a, b, mm } on the wall, depth_ref: { near, far, mm } on the floor,
 *   vanishing_point (optional: where lines running away from the camera meet), image: [w, h] }.
 * Returns { room_width, room_height, camera_distance, eye_height, camera_x (from the left corner), fov (vertical degrees), pixels_per_mm } or { error }.
 */
export function measurePhoto({ wall, width_ref, depth_ref, vanishing_point, image }) {
  const { top_left: tl, top_right: tr, bottom_right: br, bottom_left: bl } = wall || {};
  if (![tl, tr, br, bl].every(Array.isArray)) return { error: 'Give the four corners of the far wall, in pixels' };
  if (!width_ref?.a || !width_ref?.b || !(+width_ref.mm > 0)) return { error: 'Give width_ref: two points on the far wall and their distance in mm' };
  if (!Array.isArray(image) || !(image[0] > 0)) return { error: 'Give image: [width, height] in pixels' };
  const s = Math.hypot(width_ref.b[0] - width_ref.a[0], width_ref.b[1] - width_ref.a[1]) / +width_ref.mm;
  if (!(s > 0)) return { error: 'width_ref has no length in the picture' };
  const room_width = (Math.hypot(tr[0] - tl[0], tr[1] - tl[1]) + Math.hypot(br[0] - bl[0], br[1] - bl[1])) / 2 / s;
  const room_height = (Math.hypot(bl[0] - tl[0], bl[1] - tl[1]) + Math.hypot(br[0] - tr[0], br[1] - tr[1])) / 2 / s;
  const vp = Array.isArray(vanishing_point) ? vanishing_point : [image[0] / 2, image[1] / 2];
  const floorAtWall = mid(bl, br)[1];
  const eye_height = (floorAtWall - vp[1]) / s;
  const out = { room_width: Math.round(room_width), room_height: Math.round(room_height), eye_height: Math.round(eye_height), camera_x: Math.round((vp[0] - tl[0]) / s), pixels_per_mm: Math.round(s * 1e4) / 1e4 };
  if (depth_ref?.near && depth_ref?.far && +depth_ref.mm > 0) {
    const yFar = depth_ref.far[1] - vp[1];
    const yNear = depth_ref.near[1] - vp[1];
    if (!(yFar > 0) || !(yNear > yFar)) return { ...out, warning: 'depth_ref: the near point must be lower in the picture than the far one, and both below the horizon' };
    const k = yNear / yFar;
    // Offset from the wall of the far point, seen from its height in the picture.
    const offset = (floorAtWall - depth_ref.far[1]) > 0 ? (floorAtWall - vp[1]) / yFar : 1;
    const zFar = (+depth_ref.mm * k) / (k - 1);
    const distance = zFar * offset;
    const f = s * distance;
    out.camera_distance = Math.round(distance);
    out.fov = Math.round(((2 * Math.atan(image[1] / 2 / f) * 180) / Math.PI) * 10) / 10;
  }
  return out;
}
