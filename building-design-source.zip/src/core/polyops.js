/**
 * Archicad's Polygon Operations extension for GDL (INITADDONSCOPE
 * "PolyOperations"), as its reference describes it: polygons and polylines
 * stored by name in containers, operations from the source container into
 * the destination one, results named resPolygonID<n> / resPolylineID<n>.
 *
 * Shapes here: a polygon is { contours: [[{ x, y, a, info }]] }, its first
 * contour the outline and the others holes, each vertex starting the edge
 * to the next (a: the edge's central angle in degrees, 0 straight; info:
 * the integer the edge inherits); a polyline is { pts: [...], closed }.
 * Boolean operations work on arcs cut into short straight edges.
 */
import { unionAll, polygonBoolean } from './polybool.js';
import { signedArea } from './geom.js';

const D2R = Math.PI / 180;

/** The points along an edge from p to q with central angle a (degrees), q excluded. */
function edgePoints(p, q, a) {
  if (!a) return [[p.x, p.y]];
  const L = Math.hypot(q.x - p.x, q.y - p.y);
  if (L < 1e-9) return [[p.x, p.y]];
  const t = a * D2R;
  const d = L / (2 * Math.tan(t / 2));
  const c = [(p.x + q.x) / 2 - ((q.y - p.y) / L) * d, (p.y + q.y) / 2 + ((q.x - p.x) / L) * d];
  const a0 = Math.atan2(p.y - c[1], p.x - c[0]);
  const r = Math.hypot(p.x - c[0], p.y - c[1]);
  const n = Math.max(2, Math.ceil(Math.abs(a) / 5));
  return Array.from({ length: n }, (_, k) => [c[0] + r * Math.cos(a0 + (t * k) / n), c[1] + r * Math.sin(a0 + (t * k) / n)]);
}

/** A contour's vertices with its arcs cut into straight edges (each piece keeps its edge's info). */
function flatContour(c) {
  const out = [];
  c.forEach((v, i) => {
    const w = c[(i + 1) % c.length];
    for (const [x, y] of edgePoints(v, w, v.a)) out.push({ x, y, a: 0, info: v.info });
  });
  return out;
}

/** A polyline's points with its arcs cut into straight edges, its last point (or its first again, closed) at the end. */
function flatOpen(pts, closed) {
  const out = [];
  const m = closed ? pts.length : pts.length - 1;
  for (let i = 0; i < m; i++) for (const [x, y] of edgePoints(pts[i], pts[(i + 1) % pts.length], pts[i].a)) out.push({ x, y, a: 0, info: pts[i].info });
  const last = closed ? pts[0] : pts.at(-1);
  if (last) out.push({ x: last.x, y: last.y, a: 0, info: last.info });
  return out;
}

const area2 = (c) => signedArea(c.map((v) => [v.x, v.y]));

/** Outline counterclockwise, holes clockwise, no zero-length edges or repeated closing point. */
function regular(poly) {
  const contours = [];
  poly.contours.forEach((c0, k) => {
    const c = c0.filter((v, i) => {
      const w = c0[(i + 1) % c0.length];
      return Math.hypot(w.x - v.x, w.y - v.y) > 1e-7;
    });
    if (c.length < 3 || Math.abs(area2(c)) < 1e-12) return;
    const ccw = area2(c) > 0;
    contours.push((k === 0) === ccw ? c : reverse(c));
  });
  return contours.length ? { contours } : null;
}

/** A contour walked the other way: each edge keeps its angle (negated) and info. */
function reverse(c) {
  const n = c.length;
  return Array.from({ length: n }, (_, i) => {
    const v = c[n - 1 - i];
    const e = c[(2 * n - 2 - i) % n];
    return { x: v.x, y: v.y, a: -e.a, info: e.info };
  });
}

/** The info of the source edge a point lies on, else 0. */
function infoAt(sources, x, y) {
  let best = 0;
  let bd = 1e-4;
  for (const c of sources)
    for (let i = 0; i < c.length; i++) {
      const p = c[i];
      const q = c[(i + 1) % c.length];
      const L2 = (q.x - p.x) ** 2 + (q.y - p.y) ** 2 || 1e-18;
      const t = Math.max(0, Math.min(1, ((x - p.x) * (q.x - p.x) + (y - p.y) * (q.y - p.y)) / L2));
      const d = Math.hypot(x - p.x - t * (q.x - p.x), y - p.y - t * (q.y - p.y));
      if (d < bd) (bd = d), (best = p.info);
    }
  return best;
}

/** Shapes from polybool ({ boundary, holes }) as polygons whose edges inherit the sources' infos. */
function fromOutlines(outlines, sources) {
  return outlines
    .map((o) => {
      const mk = (loop) =>
        loop.map((p, i) => {
          const q = loop[(i + 1) % loop.length];
          return { x: p[0], y: p[1], a: 0, info: infoAt(sources, (p[0] + q[0]) / 2, (p[1] + q[1]) / 2) };
        });
      return regular({ contours: [mk(o.boundary), ...(o.holes || []).map(mk)] });
    })
    .filter(Boolean);
}

const toShape = (poly) => {
  const flat = poly.contours.map(flatContour);
  return { boundary: flat[0].map((v) => [v.x, v.y]), holes: flat.slice(1).map((c) => c.map((v) => [v.x, v.y])) };
};

/** Intersection of two lines, each a point and a direction; null when parallel. */
function cross(p, d, q, e) {
  const den = d[0] * e[1] - d[1] * e[0];
  if (Math.abs(den) < 1e-12) return null;
  const t = ((q[0] - p[0]) * e[1] - (q[1] - p[1]) * e[0]) / den;
  return [p[0] + d[0] * t, p[1] + d[1] * t];
}

/**
 * A chain of vertices with each edge moved sideways (offsets[i] for edge i:
 * positive to its right, out of a counterclockwise outline), the vertices
 * where the moved edges meet. Open chains keep their end edges' ends square,
 * or move them along given vectors.
 */
function offsetChain(vs, offsets, closed, ends = null) {
  const n = vs.length;
  const m = closed ? n : n - 1;
  const lines = [];
  for (let i = 0; i < m; i++) {
    const p = vs[i];
    const q = vs[(i + 1) % n];
    const L = Math.hypot(q.x - p.x, q.y - p.y) || 1;
    const d = [(q.x - p.x) / L, (q.y - p.y) / L];
    const right = [d[1], -d[0]];
    const o = offsets[i] || 0;
    lines.push({ p: [p.x + right[0] * o, p.y + right[1] * o], d });
  }
  if (!lines.length) return vs.map((v) => ({ ...v }));
  const out = [];
  for (let i = 0; i < n; i++) {
    const inn = closed ? lines[(i - 1 + m) % m] : lines[i - 1];
    const own = lines[i] || null;
    let pt;
    if (!closed && i === 0) pt = ends ? cross([vs[0].x, vs[0].y], ends[0], own.p, own.d) || own.p : own.p;
    else if (!closed && i === n - 1) {
      const end = [inn.p[0] + inn.d[0] * Math.hypot(vs[i].x - vs[i - 1].x, vs[i].y - vs[i - 1].y), inn.p[1] + inn.d[1] * Math.hypot(vs[i].x - vs[i - 1].x, vs[i].y - vs[i - 1].y)];
      pt = ends ? cross([vs[i].x, vs[i].y], ends[1], inn.p, inn.d) || end : end;
    } else pt = cross(inn.p, inn.d, own.p, own.d) || own.p;
    out.push({ x: pt[0], y: pt[1], a: 0, info: vs[i].info });
  }
  return out;
}

/** Clip a contour to the half-plane ca·x + cb·y > cc (the new edge along the line has info 0). */
function clipHalf(c, ca, cb, cc) {
  const inside = (v) => ca * v.x + cb * v.y > cc - 1e-12;
  const out = [];
  for (let i = 0; i < c.length; i++) {
    const p = c[i];
    const q = c[(i + 1) % c.length];
    const pi = inside(p);
    const qi = inside(q);
    if (pi) out.push(p);
    if (pi !== qi) {
      const fp = ca * p.x + cb * p.y - cc;
      const fq = ca * q.x + cb * q.y - cc;
      const t = fp / (fp - fq);
      out.push({ x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t, a: 0, info: pi ? 0 : p.info });
    }
  }
  return out;
}

function pointInside(x, y, contours) {
  let r = false;
  for (const c of contours)
    for (let i = 0, j = c.length - 1; i < c.length; j = i++) {
      const a = c[i];
      const b = c[j];
      if (a.y > y !== b.y > y && x < ((b.x - a.x) * (y - a.y)) / (b.y - a.y) + a.x) r = !r;
    }
  return r;
}

/** The pieces of a polyline inside a polygon. */
function clipPolyline(line, poly) {
  const contours = poly.contours.map(flatContour);
  const chain = flatOpen(line.pts, line.closed);
  const pieces = [];
  let cur = [];
  for (let i = 0; i + 1 < chain.length; i++) {
    const p = chain[i];
    const q = chain[i + 1];
    // Cut the segment where it crosses the polygon's edges.
    const ts = [0, 1];
    for (const c of contours)
      for (let k = 0; k < c.length; k++) {
        const a = c[k];
        const b = c[(k + 1) % c.length];
        const d = [q.x - p.x, q.y - p.y];
        const e = [b.x - a.x, b.y - a.y];
        const den = d[0] * e[1] - d[1] * e[0];
        if (Math.abs(den) < 1e-12) continue;
        const t = ((a.x - p.x) * e[1] - (a.y - p.y) * e[0]) / den;
        const u = ((a.x - p.x) * d[1] - (a.y - p.y) * d[0]) / den;
        if (t > 1e-9 && t < 1 - 1e-9 && u >= 0 && u <= 1) ts.push(t);
      }
    ts.sort((x, y) => x - y);
    for (let k = 0; k + 1 < ts.length; k++) {
      const tm = (ts[k] + ts[k + 1]) / 2;
      const at = (t) => ({ x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t, a: 0, info: p.info });
      if (pointInside(p.x + (q.x - p.x) * tm, p.y + (q.y - p.y) * tm, contours)) {
        if (!cur.length) cur.push(at(ts[k]));
        cur.push(at(ts[k + 1]));
      } else if (cur.length) {
        pieces.push(cur);
        cur = [];
      }
    }
  }
  if (cur.length) pieces.push(cur);
  return pieces.filter((p) => p.length >= 2).map((pts) => ({ pts, closed: false }));
}

/** One channel of the extension: its containers and the parameters set for the next operations. */
export class PolyOps {
  constructor() {
    this.containers = new Map();
    this.src = null;
    this.dst = null;
    this.params = {};
    this.seq = 0;
  }

  container(name) {
    const k = String(name);
    if (!this.containers.has(k)) this.containers.set(k, new Map());
    return this.containers.get(k);
  }

  get source() {
    return this.container(this.src ?? '');
  }

  get destination() {
    return this.container(this.dst ?? '');
  }

  /** PREPAREFUNCTION: containers, storing shapes and setting operation parameters. */
  prepare(cmd, name, args) {
    switch (String(cmd).toUpperCase()) {
      case 'CREATECONTAINER':
        this.container(name);
        return 1;
      case 'DELETECONTAINER':
        this.containers.delete(String(name));
        return 1;
      case 'EMPTYCONTAINER':
        this.container(name).clear();
        return 1;
      case 'SETSOURCECONTAINER':
        this.src = String(name);
        this.container(name);
        return 1;
      case 'SETDESTINATIONCONTAINER':
        this.dst = String(name);
        this.container(name);
        return 1;
      case 'DISPOSE':
        this.container(args[0] ?? this.src).delete(String(name));
        return 1;
      case 'STORE': {
        const [nv, nc, verts, ends, def = 0, infos] = args;
        const rows = gdlRows(verts, 3).slice(0, Math.round(nv) || undefined);
        const endIdx = gdlList(ends).slice(0, Math.round(nc) || undefined);
        const inf = gdlList(infos);
        const contours = [];
        let from = 0;
        for (const e of endIdx.length ? endIdx : [rows.length]) {
          const c = [];
          // Each contour repeats its first vertex at its end: that one starts no edge.
          for (let i = from; i < Math.min(e, rows.length) - 1; i++) c.push({ x: rows[i][0], y: rows[i][1], a: rows[i][2] || 0, info: inf[i] ?? def });
          if (c.length) contours.push(c);
          from = e;
        }
        if (contours.length) this.source.set(String(name), { contours });
        return 1;
      }
      case 'STOREPOLYLINE': {
        const [nv, verts, def = 0, infos] = args;
        const rows = gdlRows(verts, 3).slice(0, Math.round(nv) || undefined);
        const inf = gdlList(infos);
        const pts = rows.map((r, i) => ({ x: r[0], y: r[1], a: r[2] || 0, info: inf[i] ?? def }));
        const closed = pts.length > 2 && Math.hypot(pts[0].x - pts.at(-1).x, pts[0].y - pts.at(-1).y) < 1e-9;
        this.source.set(String(name), { pts: closed ? pts.slice(0, -1) : pts, closed });
        return 1;
      }
      case 'STOREDICTPOLYGON':
      case 'STOREDICTPOLYLINE': {
        const d = args[0] || {};
        const contour = (c) => (gdlList(c?.EDGES) || []).map((e) => ({ x: +e?.BEGPOINT?.X || 0, y: +e?.BEGPOINT?.Y || 0, a: +e?.TYPE ? +e?.ARCANGLE || 0 : 0, info: +e?.EDGEINFO || +d.DEFAULTINHEDGEINFO || 0 }));
        if (String(cmd).toUpperCase() === 'STOREDICTPOLYGON') this.source.set(String(name), { contours: [contour(d.CONTOUR), ...gdlList(d.HOLES).map(contour)].filter((c) => c.length) });
        else this.source.set(String(name), { pts: contour(d.CONTOUR), closed: !!+d.ISCLOSED });
        return 1;
      }
      case 'HALFPLANEPARAMS':
        this.params.half = args.slice(0, 3).map(Number);
        return 1;
      case 'OFFSETPARAMS':
        this.params.offset = [Math.round(+args[0] || 1), +args[1] || 0];
        return 1;
      case 'MULTIPLEEDGEOFFSETPARAMS': {
        const n = Math.round(+args[0] || 0);
        const flat = args.slice(1).flatMap((v) => (Array.isArray(v) ? gdlList(v) : [v]));
        this.params.multi = Array.from({ length: n }, (_, i) => [Math.round(+flat[2 * i] || 0), +flat[2 * i + 1] || 0]);
        return 1;
      }
      case 'POLYLINEOFFSETVECTORS':
        this.params.vectors = [[+args[0] || 0, +args[1] || 0], [+args[2] || 0, +args[3] || 0]];
        return 1;
      default:
        return 0;
    }
  }

  /** A result into the destination container under a new name. */
  put(shape, kind = 'Polygon') {
    const name = `res${kind}ID${++this.seq}`;
    this.destination.set(name, shape);
    return name;
  }

  /**
   * CALLFUNCTION: an operation (results' names into out[0], their count
   * returned) or a query (its values into out). `out` holds the values to
   * assign to the variables passed for them.
   */
  call(cmd, arg, out) {
    const c = String(cmd).trim();
    const U = c.toUpperCase();
    const get = (n) => this.source.get(String(n)) || this.destination.get(String(n));
    const results = (shapes, kind = 'Polygon') => {
      const names = shapes.filter(Boolean).map((s) => this.put(s, kind));
      out[0] = names;
      return names.length;
    };
    // Boolean operations: "a + b", "a - b", "a / b".
    const bool = /^(.+?)\s+([+\-/])\s+(.+)$/.exec(c);
    if (bool && !/^(GET|STORE|OFFSET|COPY|CLIP|POLYCUT|REGULARIZE|RESIZE|CENTRE)/i.test(c)) {
      const A = this.source.get(bool[1].trim());
      const B = this.source.get(bool[3].trim());
      if (!A || !B || !A.contours || !B.contours) return results([]);
      const op = bool[2] === '+' ? 'union' : bool[2] === '-' ? 'subtract' : 'intersect';
      const shapes = op === 'union' ? unionAll([toShape(A), toShape(B)]) : polygonBoolean(toShape(A), toShape(B), op);
      return results(fromOutlines(shapes, [...A.contours, ...B.contours].map(flatContour)));
    }
    switch (U) {
      case 'COPYPOLYGON': {
        const s = get(arg);
        return results(s ? [structuredClone(s)] : [], s?.pts ? 'Polyline' : 'Polygon');
      }
      case 'REGULARIZE': {
        const s = get(arg);
        if (!s?.contours) return results([]);
        const flat = s.contours.map(flatContour);
        const fixed = regular({ contours: s.contours });
        // A contour crossing itself is made whole by joining it with itself.
        const shapes = fixed ? unionAll([toShape(fixed)]) : [];
        return results(shapes.length > 1 || (fixed && s.contours.some((k) => k.some((v) => v.a))) ? fromOutlines(shapes, flat) : [fixed]);
      }
      case 'POLYCUT': {
        const s = get(arg);
        const [ca, cb, cc] = this.params.half || [0, 0, 0];
        if (!s?.contours) return results([]);
        return results([regular({ contours: s.contours.map((k) => clipHalf(flatContour(k), ca, cb, cc)) })]);
      }
      case 'OFFSETEDGE':
      case 'OFFSETMULTIPLEEDGES':
      case 'RESIZECONTOUR': {
        const s = get(arg);
        if (!s?.contours) return results([]);
        const reg = regular({ contours: s.contours.map(flatContour) });
        if (!reg) return results([]);
        // Edges count through the contours as stored: each contour's vertices, then the next.
        const offsets = reg.contours.map((k) => new Array(k.length).fill(0));
        const edgeAt = (idx) => {
          let i = idx - 1;
          for (let k = 0; k < reg.contours.length; k++) {
            if (i < reg.contours[k].length) return [k, i];
            i -= reg.contours[k].length + 1;
          }
          return null;
        };
        if (U === 'RESIZECONTOUR') {
          const [k, d] = this.params.offset || [1, 0];
          if (offsets[k - 1]) offsets[k - 1].fill(k === 1 ? d : -d);
        } else
          for (const [idx, d] of U === 'OFFSETEDGE' ? [this.params.offset || [1, 0]] : this.params.multi || []) {
            const at = edgeAt(idx);
            if (at) offsets[at[0]][at[1]] = at[0] === 0 ? d : -d;
          }
        return results([regular({ contours: reg.contours.map((k, i) => offsetChain(k, offsets[i], true)) })]);
      }
      case 'OFFSETPOLYLINE':
      case 'OFFSETPOLYLINEWITHVECTORS': {
        const s = get(arg);
        if (!s?.pts) return results([]);
        if (U === 'OFFSETPOLYLINEWITHVECTORS' && s.closed) return -1;
        const pts = s.closed ? flatContour(s.pts) : flatOpen(s.pts, false);
        const m = s.closed ? pts.length : pts.length - 1;
        // Positive to the left along the line.
        let offsets = new Array(m).fill(-(this.params.offset?.[1] || 0));
        if (U === 'OFFSETPOLYLINEWITHVECTORS' && this.params.multi?.length) {
          offsets = new Array(m).fill(0);
          for (const [i, d] of this.params.multi) if (i >= 1 && i <= m) offsets[i - 1] = -d;
        }
        const ends = U === 'OFFSETPOLYLINEWITHVECTORS' ? this.params.vectors : null;
        return results([{ pts: offsetChain(pts, offsets, s.closed, ends), closed: s.closed }], 'Polyline');
      }
      case 'CLIPPOLYLINE': {
        const [ln, pn] = String(arg).trim().split(/\s+/);
        const line = get(ln);
        const poly = get(pn);
        if (!line?.pts || !poly?.contours) return results([], 'Polyline');
        return results(clipPolyline(line, poly), 'Polyline');
      }
      case 'CENTREOFGRAVITY': {
        const s = get(arg);
        if (!s?.contours) return 0;
        let A = 0;
        let cx = 0;
        let cy = 0;
        for (const k of s.contours.map(flatContour))
          for (let i = 0; i < k.length; i++) {
            const p = k[i];
            const q = k[(i + 1) % k.length];
            const f = p.x * q.y - q.x * p.y;
            A += f;
            cx += (p.x + q.x) * f;
            cy += (p.y + q.y) * f;
          }
        if (Math.abs(A) < 1e-12) return 0;
        out[0] = cx / (3 * A);
        out[1] = cy / (3 * A);
        return 1;
      }
      case 'GETSOURCEPOLYGONS':
      case 'GETDESTINATIONPOLYGONS':
      case 'GETSOURCEPOLYLINES':
      case 'GETDESTINATIONPOLYLINES': {
        const box = U.startsWith('GETSOURCE') ? this.source : this.destination;
        const lines = U.endsWith('POLYLINES');
        out[0] = [...box].filter(([, s]) => !!s.pts === lines).map(([n]) => n);
        return out[0].length;
      }
      case 'GETVERTICES':
      case 'GETPOLYLINEVERTICES': {
        const s = get(arg);
        const vals = [];
        // Each contour (and a closed polyline) repeats its first vertex at its end, which starts no edge.
        if (s?.contours) for (const k of s.contours) vals.push(...k.flatMap((v) => [v.x, v.y, v.a]), k[0].x, k[0].y, 0);
        else if (s?.pts) vals.push(...s.pts.flatMap((v, i) => [v.x, v.y, !s.closed && i === s.pts.length - 1 ? 0 : v.a]), ...(s.closed ? [s.pts[0].x, s.pts[0].y, 0] : []));
        out[0] = vals;
        return vals.length;
      }
      case 'GETCONTOURENDS': {
        const s = get(arg);
        const ends = [];
        let at = 0;
        for (const k of s?.contours || []) ends.push((at += k.length + 1));
        out[0] = ends;
        return ends.length;
      }
      case 'GETINHEDGEINFOS':
      case 'GETPOLYLINEINHEDGEINFOS': {
        const s = get(arg);
        const vals = [];
        if (s?.contours) for (const k of s.contours) vals.push(...k.map((v) => v.info), k[0].info);
        else if (s?.pts) vals.push(...s.pts.map((v) => v.info), ...(s.closed ? [s.pts[0].info] : []));
        out[0] = vals;
        return vals.length;
      }
      case 'GETSOURCEDICTPOLYGON':
      case 'GETDESTINATIONDICTPOLYGON':
      case 'GETSOURCEDICTPOLYLINE':
      case 'GETDESTINATIONDICTPOLYLINE': {
        const s = (U.startsWith('GETSOURCE') ? this.source : this.destination).get(String(arg));
        if (!s) return 0;
        const edges = (k) => [0, ...k.map((v) => ({ TYPE: v.a ? 1 : 0, BEGPOINT: { X: v.x, Y: v.y }, ...(v.a ? { ARCANGLE: v.a } : {}), EDGEINFO: v.info }))];
        out[0] = s.contours ? { ISCLOSED: 1, CONTOUR: { EDGES: edges(s.contours[0]) }, ...(s.contours.length > 1 ? { HOLES: [0, ...s.contours.slice(1).map((k) => ({ EDGES: edges(k) }))] } : {}) } : { ISCLOSED: s.closed ? 1 : 0, CONTOUR: { EDGES: edges(s.closed ? s.pts : s.pts) } };
        return s.contours ? s.contours.reduce((n, k) => n + k.length, 0) : s.pts.length;
      }
      default:
        return 0;
    }
  }
}

/** A GDL array's values (counted from 1) as a JavaScript list. */
export function gdlList(a) {
  return Array.isArray(a) ? a.slice(1) : a == null ? [] : [a];
}

/** A GDL 2D array's rows (or a flat one in rows of `per`) as JavaScript lists. */
export function gdlRows(a, per) {
  const list = gdlList(a);
  if (list.length && Array.isArray(list[0])) return list.map((r) => gdlList(r));
  const out = [];
  for (let i = 0; i + per - 1 < list.length; i += per) out.push(list.slice(i, i + per));
  return out;
}
