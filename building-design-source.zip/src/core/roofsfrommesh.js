/**
 * Create Roofs from Mesh (Archicad's): the faces of a mesh become roofs. The mesh's triangles are grouped into
 * planes (normals within a degree, points within a few millimetres); each group's outline becomes a single-plane
 * roof whose eave is its lowest, most level edge, with the plane's pitch, so the roof lies on the face. Flat faces
 * give flat roofs.
 */
import { delaunay } from './topo.js';
import { levelElevation } from './model.js';
import { signedArea } from './geom.js';

const sub3 = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];

/** Coplanar groups of a mesh's triangles: [{ tris: [[i, j, k]], n (unit normal, z up), d }]. */
export function planarGroups(points, tris, { angle = 1, tol = 5 } = {}) {
  const cosT = Math.cos((angle * Math.PI) / 180);
  const info = tris.map(([i, j, k]) => {
    let n = cross3(sub3(points[j], points[i]), sub3(points[k], points[i]));
    const l = Math.hypot(...n) || 1;
    n = n.map((v) => v / l);
    if (n[2] < 0) n = n.map((v) => -v);
    return { n, d: n[0] * points[i][0] + n[1] * points[i][1] + n[2] * points[i][2] };
  });
  // Adjacency through shared edges.
  const edgeTris = new Map();
  tris.forEach((t, ti) => [[t[0], t[1]], [t[1], t[2]], [t[2], t[0]]].forEach(([a, b]) => {
    const k = a < b ? `${a},${b}` : `${b},${a}`;
    (edgeTris.get(k) || edgeTris.set(k, []).get(k)).push(ti);
  }));
  const group = new Array(tris.length).fill(-1);
  const groups = [];
  for (let s = 0; s < tris.length; s++) {
    if (group[s] >= 0) continue;
    const g = { tris: [], n: info[s].n, d: info[s].d };
    const stack = [s];
    group[s] = groups.length;
    while (stack.length) {
      const t = stack.pop();
      g.tris.push(tris[t]);
      const tri = tris[t];
      for (const [a, b] of [[tri[0], tri[1]], [tri[1], tri[2]], [tri[2], tri[0]]]) {
        for (const o of edgeTris.get(a < b ? `${a},${b}` : `${b},${a}`) || []) {
          if (group[o] >= 0) continue;
          const no = info[o].n;
          const same = no[0] * g.n[0] + no[1] * g.n[1] + no[2] * g.n[2] >= cosT && tris[o].every((v) => Math.abs(g.n[0] * points[v][0] + g.n[1] * points[v][1] + g.n[2] * points[v][2] - g.d) <= tol);
          if (!same) continue;
          group[o] = groups.length;
          stack.push(o);
        }
      }
    }
    groups.push(g);
  }
  return groups;
}

/** The outer boundary loop of a group of triangles (vertex indices), from its edges used once. */
function outline(tris) {
  const count = new Map();
  for (const t of tris) for (const [a, b] of [[t[0], t[1]], [t[1], t[2]], [t[2], t[0]]]) {
    const k = a < b ? `${a},${b}` : `${b},${a}`;
    count.set(k, (count.get(k) || 0) + 1);
  }
  const next = new Map();
  for (const t of tris) for (const [a, b] of [[t[0], t[1]], [t[1], t[2]], [t[2], t[0]]]) if (count.get(a < b ? `${a},${b}` : `${b},${a}`) === 1) next.set(a, b);
  const start = next.keys().next().value;
  if (start == null) return [];
  const loop = [start];
  for (let v = next.get(start); v != null && v !== start && loop.length <= next.size; v = next.get(v)) loop.push(v);
  return loop;
}

/** Roofs (not added) for a mesh element (topo { points: [[x, y, z]] }), on its level, of a roof type. */
export function roofsFromMesh(doc, mesh, typeId) {
  const P = mesh.points || [];
  const tris = delaunay(P);
  const base = levelElevation(doc, mesh.levelId);
  const out = [];
  for (const g of planarGroups(P, tris)) {
    let loop = outline(g.tris);
    if (loop.length < 3) continue;
    let pts = loop.map((i) => P[i]);
    if (signedArea(pts.map((p) => [p[0], p[1]])) < 0) pts = pts.reverse();
    const boundary = pts.map((p) => [Math.round(p[0]), Math.round(p[1])]);
    const slope = (Math.acos(Math.min(1, g.n[2])) * 180) / Math.PI;
    if (slope < 0.5) {
      out.push({ kind: 'roof', typeId, levelId: mesh.levelId, boundary, slopes: boundary.map(() => null), baseOffset: Math.round(pts[0][2] - base) });
      continue;
    }
    // The eave: the edge whose ends are lowest and closest in height.
    let best = null;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      const score = Math.abs(a[2] - b[2]) * 4 + (a[2] + b[2]) / 2;
      if (!best || score < best.score) best = { i, score, z: Math.min(a[2], b[2]) };
    }
    const slopes = boundary.map((_, i) => (i === best.i ? Math.round(slope * 100) / 100 : null));
    out.push({ kind: 'roof', typeId, levelId: mesh.levelId, boundary, slopes, baseOffset: Math.round(best.z - base) });
  }
  return out;
}
