/**
 * Align and Distribute, as in Archicad's Edit > Align and Distribute: move
 * selected elements so their bounding boxes line up on a side or centre of
 * the selection, or sit at equal spacing between the outermost ones.
 *
 *   box { id, x0, y0, x1, y1 } in model millimetres
 */

/** Moves [{ id, d: [dx, dy] }] that align boxes: left, centerX, right, bottom, centerY, top. */
export function alignMoves(boxes, mode) {
  if (boxes.length < 2) return [];
  const x0 = Math.min(...boxes.map((b) => b.x0));
  const x1 = Math.max(...boxes.map((b) => b.x1));
  const y0 = Math.min(...boxes.map((b) => b.y0));
  const y1 = Math.max(...boxes.map((b) => b.y1));
  return boxes.map((b) => {
    const d = [0, 0];
    if (mode === 'left') d[0] = x0 - b.x0;
    else if (mode === 'right') d[0] = x1 - b.x1;
    else if (mode === 'centerX') d[0] = (x0 + x1) / 2 - (b.x0 + b.x1) / 2;
    else if (mode === 'bottom') d[1] = y0 - b.y0;
    else if (mode === 'top') d[1] = y1 - b.y1;
    else if (mode === 'centerY') d[1] = (y0 + y1) / 2 - (b.y0 + b.y1) / 2;
    return { id: b.id, d };
  });
}

/**
 * Moves that space boxes evenly along x or y: the outermost stay put and
 * the gaps between neighbours become equal (or, by 'centers', the centres
 * equally spaced).
 */
export function distributeMoves(boxes, axis = 'x', by = 'gaps') {
  if (boxes.length < 3) return [];
  const [lo, hi] = axis === 'x' ? ['x0', 'x1'] : ['y0', 'y1'];
  const k = axis === 'x' ? 0 : 1;
  const sorted = boxes.slice().sort((a, b) => a[lo] + a[hi] - (b[lo] + b[hi]));
  const first = sorted[0];
  const last = sorted.at(-1);
  const out = [];
  if (by === 'centers') {
    const c0 = (first[lo] + first[hi]) / 2;
    const step = ((last[lo] + last[hi]) / 2 - c0) / (sorted.length - 1);
    sorted.forEach((b, i) => {
      const d = [0, 0];
      d[k] = c0 + step * i - (b[lo] + b[hi]) / 2;
      out.push({ id: b.id, d });
    });
    return out;
  }
  const sizes = sorted.reduce((s, b) => s + (b[hi] - b[lo]), 0);
  const gap = (last[hi] - first[lo] - sizes) / (sorted.length - 1);
  let at = first[lo];
  for (const b of sorted) {
    const d = [0, 0];
    d[k] = at - b[lo];
    out.push({ id: b.id, d });
    at += b[hi] - b[lo] + gap;
  }
  return out;
}

const centre = (b) => [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2];

/**
 * Along XY: centres equally spaced on the line from the first to the last element (the two farthest apart),
 * so a diagonal row lines up on both axes at once.
 */
export function distributeXYMoves(boxes) {
  if (boxes.length < 3) return [];
  let best = null;
  for (const a of boxes)
    for (const b of boxes) {
      const d = Math.hypot(centre(a)[0] - centre(b)[0], centre(a)[1] - centre(b)[1]);
      if (!best || d > best.d) best = { a, b, d };
    }
  return alongLineMoves(boxes, centre(best.a), centre(best.b));
}

/**
 * Special Distribute: the elements' centres on the line a→b, in their order along it — spread from a to b
 * (by: 'fit'), or from a at a given spacing (by: 'spacing').
 */
export function alongLineMoves(boxes, a, b, { by = 'fit', spacing = 1000 } = {}) {
  const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
  if (L < 1e-6 || !boxes.length) return [];
  const u = [(b[0] - a[0]) / L, (b[1] - a[1]) / L];
  const t = (bx) => (centre(bx)[0] - a[0]) * u[0] + (centre(bx)[1] - a[1]) * u[1];
  const sorted = boxes.slice().sort((x, y) => t(x) - t(y));
  const step = by === 'spacing' ? spacing : sorted.length > 1 ? L / (sorted.length - 1) : 0;
  return sorted.map((bx, i) => {
    const c = centre(bx);
    const p = [a[0] + u[0] * step * i, a[1] + u[1] * step * i];
    return { id: bx.id, d: [p[0] - c[0], p[1] - c[1]] };
  });
}

/** Special Align: each element moved across the line a→b until its centre (or the side facing it) is on it. */
export function alignToLineMoves(boxes, a, b, { ref = 'center' } = {}) {
  const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
  if (L < 1e-6) return [];
  const n = [-(b[1] - a[1]) / L, (b[0] - a[0]) / L];
  return boxes.map((bx) => {
    const corners = [[bx.x0, bx.y0], [bx.x1, bx.y0], [bx.x1, bx.y1], [bx.x0, bx.y1]];
    const s = (p) => (p[0] - a[0]) * n[0] + (p[1] - a[1]) * n[1];
    let off = s(centre(bx));
    // 'near': the side of the outline nearest the line touches it.
    if (ref === 'near') {
      const ss = corners.map(s);
      off = off > 0 ? Math.min(...ss) : Math.max(...ss);
    }
    return { id: bx.id, d: [-n[0] * off, -n[1] * off] };
  });
}
