/**
 * Scripting (Archicad's Python palette, reimplemented for this app): a script
 * is JavaScript run with an `api` object over the open project. Each run that
 * changes the model is one undo step. The API:
 *
 *   api.doc                         the project document (read)
 *   api.elements(kind?, filter?)    elements, by kind and/or a test
 *   api.selection() / api.select(ids)
 *   api.change(name, fn)            make changes (fn gets the doc) as one undo step
 *   api.update(id, patch)           change one element (inside or outside change)
 *   api.add(item) / api.remove(id)
 *   api.run(command, args)          run any command of the app
 *   api.commands()                  the commands' names
 *   api.quantities(kind)            count, length (walls, beams), area (slabs, rooms)
 *   api.log(...values)              print to the console
 */
export const SCRIPT_EXAMPLES = [
  { name: 'Count elements by kind', code: "const n = {};\nfor (const k of ['wall', 'door', 'window', 'room', 'floor']) n[k] = api.elements(k).length;\nreturn n;" },
  { name: 'Mark the doors D01, D02...', code: "api.change('Number doors', () => {\n  api.elements('door').forEach((d, i) => api.update(d.id, { mark: `D${String(i + 1).padStart(2, '0')}` }));\n});\nreturn api.elements('door').map((d) => d.mark);" },
  { name: 'Select walls longer than 5 m', code: "const long = api.elements('wall', (w) => Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]) > 5000);\napi.select(long.map((w) => w.id));\nreturn `${long.length} walls selected`;" },
  { name: 'Room areas', code: "return api.quantities('room');" },
];

function quantities(app, kind) {
  const els = app.doc.all(kind);
  const out = { count: els.length };
  if (kind === 'wall' || kind === 'beam') out.length_m = Math.round(els.reduce((t, e) => t + Math.hypot(e.b[0] - e.a[0], e.b[1] - e.a[1]), 0)) / 1000;
  if (kind === 'room') out.areas_m2 = Object.fromEntries(els.map((r) => [r.name || r.id, Math.round((app.scene.rooms.room(r)?.area || 0) / 1e4) / 100]));
  if (kind === 'floor') {
    const area = (b) => Math.abs(b.reduce((s, p, i) => s + p[0] * b[(i + 1) % b.length][1] - b[(i + 1) % b.length][0] * p[1], 0)) / 2;
    out.area_m2 = Math.round(els.reduce((t, e) => t + area(e.boundary || []), 0) / 1e4) / 100;
  }
  return out;
}

/** The API a script sees. log collects what it prints. */
export function scriptApi(app, log) {
  const doc = app.doc;
  let depth = 0;
  const api = {
    doc,
    elements: (kind = null, test = null) => {
      const list = kind ? doc.all(kind) : [...doc.items.values()];
      return test ? list.filter(test) : list;
    },
    selection: () => [...app.selection],
    select: (ids) => app.select([...ids]),
    change: (name, fn) => {
      let r;
      depth++;
      try {
        if (depth > 1) r = fn(doc);
        else app.commit(String(name || 'Script'), () => (r = fn(doc)));
      } finally {
        depth--;
      }
      return r;
    },
    update: (id, patch) => (depth ? doc.update(id, patch) : api.change('Script', () => doc.update(id, patch))),
    add: (item) => (depth ? doc.add(item) : api.change('Script', () => doc.add(item))),
    remove: (id) => (depth ? doc.remove(id) : api.change('Script', () => doc.remove(id))),
    run: (cmd, args) => app.run(cmd, args),
    commands: () => app.commandNames?.() || [],
    quantities: (kind) => quantities(app, kind),
    log: (...v) => log.push(v.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ')),
  };
  return api;
}

/** Run a script: { result, log, error }. */
export async function runScript(app, code) {
  const log = [];
  const api = scriptApi(app, log);
  try {
    // eslint-disable-next-line no-new-func
    const fn = new Function('api', `"use strict"; return (async () => {\n${code}\n})();`);
    const result = await fn(api);
    return { result, log, error: null };
  } catch (err) {
    return { result: undefined, log, error: err?.message || String(err) };
  }
}
