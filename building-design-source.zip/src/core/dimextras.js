/**
 * Dimension extras, as in Archicad:
 *
 *   - Parapet Dimensions (Create / Refresh / Remove): the sill (parapet)
 *     height of windows and doors written in plan next to each opening, on
 *     the room side of the wall, measured from the story (or the wall base).
 *     They are text blocks tied to their opening (`auto.kind = 'parapet'`),
 *     so Refresh rewrites value and place after the model changes.
 *   - Secondary Dimensions (Convert / Refresh / Remove Converted): each
 *     segment of a linear dimension gets its value in a second unit, as a
 *     text block on the other side of the dimension line. They are not live,
 *     as in Archicad: Refresh updates value and place.
 *   - Reference levels (Project Preferences > Reference Levels): two named
 *     heights besides the project zero; spot elevations can read from them
 *     and the 1st / 2nd Reference Level option picks the one the element
 *     settings report elevations to.
 */
import { add, scale, perp, angleOf } from './geom.js';
import { wallAxis, openingSize, verticalExtent, levelElevation } from './model.js';
import { axisPoint, axisTangent } from './walls.js';
import { readableAngle, dimensionGeometry } from './plan.js';
import { formatDimension, formatInUnit } from './units.js';

const DEG = 180 / Math.PI;

// Parapet dimensions -------------------------------------------------------------------------------

export const PARAPET_DEFAULTS = { prefix: 'SH', from: 'story', side: 'interior', doors: false };

export function parapetOptions(project) {
  return { ...PARAPET_DEFAULTS, ...(project?.parapetDims || {}) };
}

/** Sill height of an opening: from its wall's story (or the wall's base), in mm. Null when it has no host wall. */
export function sillHeight(doc, el, from = 'story') {
  const host = doc.get(el.hostId);
  if (!host || host.kind !== 'wall') return null;
  const { sill } = openingSize(doc, el);
  const base = verticalExtent(doc, host).base;
  const z = base + (el.kind === 'window' || el.kind === 'opening' ? sill : 0);
  return from === 'wall' ? z - base : z - levelElevation(doc, host.levelId);
}

/** The text block of an opening's parapet dimension (not added), or null. */
export function parapetText(doc, el, view, units, opts = PARAPET_DEFAULTS) {
  const host = doc.get(el.hostId);
  if (!host || host.kind !== 'wall' || host.levelId !== view.levelId) return null;
  const h = sillHeight(doc, el, opts.from);
  if (h == null) return null;
  const ax = wallAxis(doc, host);
  const dir = axisTangent(ax, el.t);
  const n = perp(dir);
  const ext = (host.flipped ? -1 : 1) * (el.flipFacing ? -1 : 1);
  const side = opts.side === 'exterior' ? ext : -ext;
  const sc = +view.scale || 100;
  // Clear of the wall face by 3.5 mm on paper (the text is 2.5 mm high, centred on its point).
  const at = add(axisPoint(ax, el.t, 0), scale(n, side * (ax.half + 3.5 * sc)));
  const value = formatDimension(h, units, 'sill');
  return {
    kind: 'text',
    viewId: view.id,
    at,
    text: opts.prefix ? `${opts.prefix} ${value}` : value,
    rotation: Math.round(readableAngle(angleOf(dir)) * DEG * 1000) / 1000,
    align: 'center',
    auto: { kind: 'parapet', hostId: el.id },
  };
}

const isParapet = (t) => t.kind === 'text' && t.auto?.kind === 'parapet';

/**
 * Create (or refresh) the parapet dimensions of a plan view, inside a transaction. ids: only these openings
 * (default every window, and doors when opts.doors, on the view's story). Returns { added, updated, removed }.
 */
export function placeParapetDims(doc, view, units, { ids = null, opts = PARAPET_DEFAULTS, refresh = false } = {}) {
  const out = { added: 0, updated: 0, removed: 0 };
  const existing = new Map(doc.all('text').filter((t) => isParapet(t) && t.viewId === view.id).map((t) => [t.auto.hostId, t]));
  const kinds = opts.doors ? ['window', 'door'] : ['window'];
  const openings = refresh
    ? [...existing.keys()].map((id) => doc.get(id)).filter(Boolean)
    : kinds.flatMap((k) => doc.all(k)).filter((o) => !ids || ids.includes(o.id));
  for (const o of openings) {
    const t = parapetText(doc, o, view, units, opts);
    const old = existing.get(o.id);
    if (!t) {
      if (old) (doc.remove(old.id), out.removed++);
      continue;
    }
    if (old) {
      const { kind: _k, viewId: _v, ...patch } = t;
      void _k;
      void _v;
      doc.update(old.id, patch);
      out.updated++;
    } else {
      doc.add(t);
      out.added++;
    }
  }
  if (refresh) for (const [hid, t] of existing) if (!doc.get(hid)) (doc.remove(t.id), out.removed++);
  return out;
}

/** Remove parapet dimensions of a view (or only those of the given openings or texts). Returns how many. */
export function removeParapetDims(doc, view, ids = null) {
  let n = 0;
  for (const t of doc.all('text')) if (isParapet(t) && t.viewId === view.id && (!ids || ids.includes(t.id) || ids.includes(t.auto.hostId))) (doc.remove(t.id), n++);
  return n;
}

// Secondary dimensions -----------------------------------------------------------------------------

export const SECONDARY_UNITS = [
  { value: 'm', label: 'Metres' },
  { value: 'cm', label: 'Centimetres' },
  { value: 'mm', label: 'Millimetres' },
  { value: 'ftin', label: 'Feet & inches' },
  { value: 'ft', label: 'Decimal feet' },
  { value: 'in', label: 'Decimal inches' },
];

export { formatInUnit };

/** Secondary texts for one dimension (not added): one per segment, under the dimension line. */
export function secondaryTexts(doc, dim, view, { unit = 'm', decimals = 2 } = {}) {
  if (dim.kind !== 'dimension' || !dim.refs || dim.refs.length < 2 || !dim.dir) return [];
  const g = dimensionGeometry(doc, null, dim);
  const sorted = g.order.map((i) => g.pos[i]);
  const ang = readableAngle(angleOf(g.dir));
  const up = [-Math.sin(ang), Math.cos(ang)];
  const sc = +view.scale || 100;
  const out = [];
  for (let i = 0; i + 1 < sorted.length; i++) {
    const v = sorted[i + 1] - sorted[i];
    if (v < 0.5) continue;
    const m = g.at((sorted[i] + sorted[i + 1]) / 2);
    out.push({
      kind: 'text',
      viewId: dim.viewId,
      at: add(m, scale(up, -1.7 * sc)),
      text: formatInUnit(v, unit, decimals),
      rotation: Math.round(ang * DEG * 1000) / 1000,
      align: 'center',
      size: 1.8,
      auto: { kind: 'secondary', dimId: dim.id, seg: i, unit, decimals },
    });
  }
  return out;
}

const isSecondary = (t) => t.kind === 'text' && t.auto?.kind === 'secondary';

/**
 * Convert dimensions (inside a transaction): the given dimensions, or every linear dimension of the view. Earlier
 * converted texts of those dimensions are replaced. Returns the number of texts placed.
 */
export function convertDimensions(doc, view, { ids = null, unit = 'm', decimals = 2 } = {}) {
  const dims = doc.all('dimension').filter((d) => d.viewId === view.id && (!ids || ids.includes(d.id)));
  const set = new Set(dims.map((d) => d.id));
  for (const t of doc.all('text')) if (isSecondary(t) && set.has(t.auto.dimId)) doc.remove(t.id);
  let n = 0;
  for (const d of dims) for (const t of secondaryTexts(doc, d, view, { unit, decimals })) (doc.add(t), n++);
  return n;
}

/** Refresh converted dimensions of a view (or of the given dimensions): value and place, with their own unit. */
export function refreshConverted(doc, view, ids = null) {
  const byDim = new Map();
  for (const t of doc.all('text')) if (isSecondary(t) && t.viewId === view.id && (!ids || ids.includes(t.auto.dimId) || ids.includes(t.id))) byDim.set(t.auto.dimId, t.auto);
  let n = 0;
  for (const [id, a] of byDim) {
    for (const t of doc.all('text')) if (isSecondary(t) && t.auto.dimId === id) doc.remove(t.id);
    const d = doc.get(id);
    if (d) for (const t of secondaryTexts(doc, d, view, a)) (doc.add(t), n++);
  }
  return n;
}

export function removeConverted(doc, view, ids = null) {
  let n = 0;
  for (const t of doc.all('text')) if (isSecondary(t) && t.viewId === view.id && (!ids || ids.includes(t.auto.dimId) || ids.includes(t.id))) (doc.remove(t.id), n++);
  return n;
}

// Reference levels: in coords.js (spot elevations read them too).
export { REFERENCE_DEFAULTS, referenceLevels, shownReference, heightToReference } from './coords.js';
