/** Looking into one room in 3D, and telling a photograph of a room from a drawing of a plan. */

/** The section box and camera that show a room from above and from the south-east, its near walls cut away. */
export function roomCutaway(doc, scene, room) {
  const outer = scene.rooms.room(room)?.outer;
  if (!outer?.length) return null;
  const xs = outer.map((p) => p[0]);
  const ys = outer.map((p) => p[1]);
  const [x0, x1, y0, y1] = [Math.min(...xs), Math.max(...xs), Math.min(...ys), Math.max(...ys)];
  const z = doc.get(room.levelId).elevation;
  return {
    sectionBox: { min: [x0 - 1000, y0 + 1, z - 200], max: [x1 - 1, y1 + 1000, z + 2500] },
    camera: { target: [(x0 + x1) / 2, (y0 + y1) / 2, z + 500], dist: Math.max(x1 - x0, y1 - y0) * 2.1 + 1500, yaw: -0.8, pitch: 0.72, persp: true, fov: 40, fitted: true },
  };
}

/**
 * Whether the pixels (RGBA, any size) look like a photograph or rendering rather than a scanned or exported plan.
 * A plan has paper, one colour over at least a third of it even when its rooms are hatched; a photo has no such colour, and carries colour.
 */
export function looksLikePhoto(data) {
  const bins = new Map();
  let n = 0;
  let coloured = 0;
  for (let i = 0; i + 3 < data.length; i += 4) {
    const [r, g, b] = [data[i], data[i + 1], data[i + 2]];
    const key = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
    bins.set(key, (bins.get(key) || 0) + 1);
    n++;
    if (Math.max(r, g, b) - Math.min(r, g, b) > 24) coloured++;
  }
  if (!n) return false;
  return Math.max(...bins.values()) / n < 0.25 && coloured / n > 0.3;
}
