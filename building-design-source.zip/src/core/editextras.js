/**
 * Edit menu commands, as in Archicad:
 *
 *   Invert Wall Direction       start and end swap; the reference line stays where it is, so a wall drawn on a
 *                               face moves to the line's other side; doors and windows keep their place and swing;
 *   Modify Wall Reference Line  the reference line moves to another face or the centre and the wall stays put;
 *   Relink Home Story           the element belongs to another story at the same height (its offsets change);
 *   Unlock All                  every pinned element is free again.
 */
import { wallAxis, levelElevation } from './model.js';
import { add, scale, dist } from './geom.js';

export const REFERENCE_LINES = [
  { value: 'exterior', label: 'Exterior face' },
  { value: 'center', label: 'Center' },
  { value: 'interior', label: 'Interior face' },
];

const shiftOf = (line, half) => (line === 'exterior' ? -half : line === 'interior' ? half : 0);

/** Invert a wall's direction (inside a transaction). */
export function invertWallDirection(doc, id) {
  const w = doc.get(id);
  if (w?.kind !== 'wall') return false;
  const length = wallAxis(doc, w).length;
  const patch = { a: w.b, b: w.a, joinA: w.joinB, joinB: w.joinA };
  if (w.arc) patch.arc = -w.arc;
  for (const k of ['topOffsetA', 'topOffsetB']) if (k in w) patch[k === 'topOffsetA' ? 'topOffsetB' : 'topOffsetA'] = w[k];
  doc.update(id, patch);
  // Openings measured from the start: from the other end now, facing and hinged as before.
  for (const k of ['door', 'window', 'opening'])
    for (const el of doc.all(k)) {
      if (el.hostId !== id) continue;
      const p = { t: Math.round((length - (+el.t || 0)) * 10) / 10 };
      if (k !== 'opening') Object.assign(p, { flipFacing: !el.flipFacing, flipHand: !el.flipHand });
      if (el.corner) p.corner = el.corner === 'a' ? 'b' : 'a';
      doc.update(el.id, p);
    }
  return true;
}

/** Move a straight wall's reference line to `line` keeping the wall where it is (inside a transaction). */
export function modifyReferenceLine(doc, id, line) {
  const w = doc.get(id);
  if (w?.kind !== 'wall' || (w.locationLine || 'center') === line) return false;
  const ax = wallAxis(doc, w);
  const d = shiftOf(w.locationLine, ax.half) - shiftOf(line, ax.half);
  if (w.arc) {
    // A curved wall's drawn arc moves off its centre: its ends move along the end radii.
    const off = (w.flipped ? -1 : 1) * d;
    doc.update(id, { locationLine: line, ...arcShift(w, off) });
    return true;
  }
  const off = scale(ax.ext, d);
  doc.update(id, { locationLine: line, a: add(w.a, off).map(round1), b: add(w.b, off).map(round1) });
  return true;
}

const round1 = (v) => Math.round(v * 10) / 10;

/** The ends of an arc wall moved `off` across it (positive to the left of a→b at each end), same sweep. */
function arcShift(w, off) {
  // The arc through a and b with sweep w.arc: its centre and radius.
  const sweep = w.arc;
  const chord = dist(w.a, w.b);
  const r = chord / 2 / Math.sin(Math.abs(sweep) / 2);
  const mx = (w.a[0] + w.b[0]) / 2;
  const my = (w.a[1] + w.b[1]) / 2;
  const ux = (w.b[0] - w.a[0]) / chord;
  const uy = (w.b[1] - w.a[1]) / chord;
  const h = r * Math.cos(sweep / 2) * Math.sign(sweep);
  const c = [mx - uy * h, my + ux * h];
  const k = (r - Math.sign(sweep) * off) / r;
  const P = (p) => [round1(c[0] + (p[0] - c[0]) * k), round1(c[1] + (p[1] - c[1]) * k)];
  return { a: P(w.a), b: P(w.b) };
}

/** Kinds and the offset fields that hold their height on their story. */
export const HEIGHT_FIELDS = { wall: ['baseOffset'], column: ['baseOffset'], beam: ['offset'], floor: ['offset'], roof: ['baseOffset'], ceiling: ['offset'], component: ['offset'], lamp: ['offset'], stair: ['baseOffset'], railing: ['offset'], mass: ['offset'], morph: ['offset'], shell: ['offset'], duct: ['offset'], pipe: ['offset'], cableTray: ['offset'], conduit: ['offset'], mepEquipment: ['offset'], room: ['offset'] };

/** Relink an element to another story keeping its height (inside a transaction). Returns true when changed. */
export function relinkHomeStory(doc, id, levelId) {
  const el = doc.get(id);
  if (!el?.levelId || el.levelId === levelId || !doc.get(levelId)) return false;
  const delta = levelElevation(doc, el.levelId) - levelElevation(doc, levelId);
  const patch = { levelId };
  for (const f of HEIGHT_FIELDS[el.kind] || ['offset']) patch[f] = Math.round((+el[f] || 0) + delta);
  doc.update(id, patch);
  return true;
}

/** Unpin every pinned element (inside a transaction). Returns how many. */
export function unlockAll(doc) {
  let n = 0;
  for (const el of doc.filter((x) => x.pinned)) (doc.update(el.id, { pinned: false }), n++);
  return n;
}
