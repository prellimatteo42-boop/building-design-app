/**
 * Parameters shown in the properties palette and type editor. Each
 * descriptor: { key, label, group, type, get(el, ctx), set(el, value, ctx)
 * -> patch, options(ctx), ro(el, ctx) }.
 *
 * Types: length, number, angle, text, textarea, bool, select, level,
 * levelOpt (a level or none), material, readonly, button.
 */
import { applyGdlChange } from './paramscript.js';
import { autotextFields, AUTOTEXT_DEFAULTS } from './autotext.js';
import { classifiable, autoClass, classTree, classLabel } from './classify.js';
import { splineLength } from './spline.js';
import { polylineLength } from './polyline.js';
import { grossArea, reducedArea, calculatedArea } from './zonecalc.js';
import { structuralUnits, loadToDisplay, loadFromDisplay, loadUnitLabel } from './projectprefs.js';
import { formatAngle } from './units.js';
import { categoryOf } from './catalog.js';
import { powerOf } from './electrical.js';
import { verticalExtent, openingSize, stairLayout, rampLayout, wallLength } from './model.js';
import { typeThickness, KIND_LABEL } from './catalog.js';
import { thermalProperties, uValueLabel } from './materials.js';
import { zoneCategoryOf } from './zonecats.js';
import { STRUCTURE_DISPLAY } from './layerjoins.js';
import { STORY_RULES, STORY_KINDS } from './plan.js';
import { profilesFor } from './profiles.js';
import { roofGeometry } from './build3d.js';
import { area as polyArea, perimeter, dist } from './geom.js';
import { scaleOptions } from './units.js';
import { STAIR_SHAPES } from './stairs.js';
import { DETAIL_FAMILIES, radialTarget } from './annotate.js';
import { applyTemplatePatch, templateKindOf } from './graphics.js';
import { phasesInOrder, phased, PHASE_FILTERS, phaseFilters } from './phases.js';
import { mepSize, systemOf, SYSTEMS } from './mep.js';
import { braceHeights } from './build3d.js';
import { topoBoundary } from './topo.js';
import { massFloorArea } from './massing.js';
import { spaceLoads, SPACE_TYPES } from './spaces.js';
import { lockAll } from './constraints.js';
import { PROFILES } from './sweeps.js';
import { CLADDING_PATTERNS, WALL_ACCESSORIES, framingGeometry, framingList } from './cladding.js';
import { SLAB_ACCESSORIES, ROOF_ACCESSORIES, SHEATHING } from './accessories.js';
import { roomVolume } from './zonecrop.js';
import { FIXITY, loadCases, loadTotal } from './structural.js';
import { END_RELEASES } from './analytical.js';
import { runSlope, runLength } from './mepnet.js';
import { PATTERNS } from './truss.js';
import { worksharingOn, worksetable, worksetOf, worksets } from './worksets.js';
import { optionable, optionLabel } from './designopts.js';
import { stairRules, checkStair } from './stairrules.js';
import { stairPartKind, isLandingPart } from './stairparts.js';
import { planeHeight } from './roof.js';
import { SLAB_REF_PLANES, refOffset, offsetForRef } from './slabref.js';
import { heightToReference, referenceLevels, shownReference } from './coords.js';
import { layered, layerIdOf, layersInOrder } from './layers.js';
import { isLamp, LAMP_DEFAULTS, DAYLIGHT } from './lamps.js';

export const GROUPS = ['Constraints', 'Construction', 'Light', 'Graphics', 'Underlay', 'Text', 'Dimensions', 'Rules', 'Structural', 'Energy Analysis', 'Identity Data', 'Parameters', 'IFC', 'Phasing', 'Extents', 'Camera', 'Other'];

const P = (key, label, group, type, extra = {}) => ({ key, label, group, type, ...extra });

const mark = P('mark', 'Mark', 'Identity Data', 'text');
const JOIN_STYLES = [
  { value: 'miter', label: 'Miter' },
  { value: 'butt', label: 'Butt (this wall stops)' },
];
const comments = P('comments', 'Comments', 'Identity Data', 'text');
// End releases of a structural member in the analytical model (analytical.js).
const endRelease = P('endRelease', 'End Releases', 'Structural', 'select', { get: (el) => el.endRelease || 'rigid', options: () => END_RELEASES });

const LOCATION = [
  { value: 'center', label: 'Wall Centerline' },
  { value: 'exterior', label: 'Exterior Face' },
  { value: 'interior', label: 'Interior Face' },
];

const len = (key, label, group, extra) => P(key, label, group, 'length', extra);
const ro = (key, label, group, get, type = 'length') => P(key, label, group, 'readonly', { get, format: type });
// Thermal data of a layered element's type, from its building materials (materials.js).
const thermal = [
  ro('uValue', 'Heat Transfer Coefficient (U)', 'Analytical Properties', (el, c) => uValueLabel(c.doc, c.doc.get(el.typeId)) || 'Not available', 'text'),
  ro('thermalMass', 'Mass per Area', 'Analytical Properties', (el, c) => {
    const t = thermalProperties(c.doc, c.doc.get(el.typeId));
    return t ? `${Math.round(t.mass)} kg/m²` : '';
  }, 'text'),
];

const baseLevel = P('levelId', 'Base Constraint', 'Constraints', 'level');
const topConstraint = P('topLevelId', 'Top Constraint', 'Constraints', 'levelOpt', { none: 'Unconnected' });

const INSTANCE = {
  wall: [
    P('locationLine', 'Location Line', 'Constraints', 'select', { options: () => LOCATION }),
    P('fireRating', 'Fire Rating', 'Fire Safety', 'text'),
    baseLevel,
    len('baseOffset', 'Base Offset', 'Constraints'),
    topConstraint,
    len('height', 'Unconnected Height', 'Constraints', { ro: (el) => !!el.topLevelId, get: (el, c) => (el.topLevelId ? wallHeight(el, c) : el.height) }),
    len('topOffset', 'Top Offset', 'Constraints', { ro: (el) => !el.topLevelId }),
    P('roomBounding', 'Room Bounding', 'Constraints', 'bool'),
    P('slant', 'Geometry', 'Construction', 'select', {
      get: (el) => el.slant || '',
      set: (el, v) => ({ slant: v || null }),
      options: () => [
        { value: '', label: 'Straight' },
        { value: 'slanted', label: 'Slanted' },
        { value: 'double', label: 'Double slanted' },
      ],
    }),
    P('slantOuter', 'Slant (degrees)', 'Construction', 'number', { get: (el) => +el.slantOuter || 0, ro: (el) => !el.slant }),
    P('slantInner', 'Inner Face Slant (degrees)', 'Construction', 'number', { get: (el) => +el.slantInner || 0, ro: (el) => el.slant !== 'double' }),
    P('flipped', 'Flipped', 'Construction', 'bool'),
    P('joinA', 'Join at Start', 'Construction', 'bool'),
    P('joinB', 'Join at End', 'Construction', 'bool'),
    P('joinStyleA', 'Corner at Start', 'Construction', 'select', { get: (el) => el.joinStyleA || 'miter', options: () => JOIN_STYLES }),
    P('joinStyleB', 'Corner at End', 'Construction', 'select', { get: (el) => el.joinStyleB || 'miter', options: () => JOIN_STYLES }),
    P('structural', 'Structural', 'Structural', 'bool'),
    // A curved wall's bend (core/arc.js); 0 makes it straight.
    P('arcAngle', 'Arc Angle (degrees)', 'Construction', 'number', {
      get: (el) => Math.round(((el.arc || 0) * 180) / Math.PI * 100) / 100,
      set: (el, v) => ({ arc: Math.max(-359, Math.min(359, +v || 0)) * (Math.PI / 180) }),
    }),
    ro('length', 'Length', 'Dimensions', (el) => wallLength(el)),
    ro('width', 'Width', 'Dimensions', (el, c) => typeThickness(c.doc.get(el.typeId))),
    ro('area', 'Area', 'Dimensions', (el, c) => wallLength(el) * wallHeight(el, c), 'area'),
    ro('volume', 'Volume', 'Dimensions', (el, c) => wallLength(el) * wallHeight(el, c) * typeThickness(c.doc.get(el.typeId)), 'volume'),
    ...thermal,
    mark,
    comments,
  ],
  door: [
    ro('level', 'Level', 'Constraints', (el, c) => c.doc.get(c.doc.get(el.hostId)?.levelId)?.name ?? '', 'text'),
    ro('host', 'Host', 'Constraints', (el, c) => c.doc.get(c.doc.get(el.hostId)?.typeId)?.name ?? '', 'text'),
    P('flipFacing', 'Flip Facing', 'Construction', 'bool'),
    P('flipHand', 'Flip Hand', 'Construction', 'bool'),
    len('t', 'Position Along Wall', 'Constraints'),
    ro('width', 'Width', 'Dimensions', (el, c) => openingSize(c.doc, el).width),
    ro('heightV', 'Height', 'Dimensions', (el, c) => openingSize(c.doc, el).height),
    len('frameWidth', 'Frame Width', 'Dimensions', { get: (el, c) => el.frameWidth ?? c.doc.get(el.typeId)?.frameWidth }),
    P('openAngle', 'Open Angle in 3D (deg)', 'Construction', 'number', { get: (el) => el.openAngle ?? 0 }),
    P('exit', 'Escape Exit', 'Fire Safety', 'bool'),
    P('fireRating', 'Fire Rating', 'Fire Safety', 'text'),
    mark,
    comments,
  ],
  window: [
    ro('level', 'Level', 'Constraints', (el, c) => c.doc.get(c.doc.get(el.hostId)?.levelId)?.name ?? '', 'text'),
    len('sill', 'Sill Height', 'Constraints', { get: (el, c) => openingSize(c.doc, el).sill }),
    ro('head', 'Head Height', 'Constraints', (el, c) => {
      const s = openingSize(c.doc, el);
      return s.sill + s.height;
    }),
    len('t', 'Position Along Wall', 'Constraints'),
    P('flipFacing', 'Flip Facing', 'Construction', 'bool'),
    ro('width', 'Width', 'Dimensions', (el, c) => openingSize(c.doc, el).width),
    ro('heightV', 'Height', 'Dimensions', (el, c) => openingSize(c.doc, el).height),
    len('frameWidth', 'Frame Width', 'Dimensions', { get: (el, c) => el.frameWidth ?? c.doc.get(el.typeId)?.frameWidth }),
    len('frameDepth', 'Frame Depth', 'Dimensions', { get: (el, c) => el.frameDepth ?? c.doc.get(el.typeId)?.frameDepth }),
    len('reveal', 'Reveal', 'Dimensions', { get: (el) => el.reveal ?? 0 }),
    len('transomAt', 'Transom Height', 'Dimensions', { get: (el) => el.transomAt ?? 0 }),
    // A sloped head (a window under a roof): its height at each jamb; equal heights make it a rectangle again.
    len('headLeft', 'Height at Left Jamb', 'Dimensions', { get: (el, c) => headAt(el, c, -1), set: (el, v, c) => headPatch(el, c, -1, +v) }),
    len('headRight', 'Height at Right Jamb', 'Dimensions', { get: (el, c) => headAt(el, c, 1), set: (el, v, c) => headPatch(el, c, 1, +v) }),
    P('boxWindow', 'Box Window', 'Construction', 'bool'),
    P('sillBoard', 'Sill Board', 'Construction', 'bool', { get: (el) => el.sillBoard !== false }),
    mark,
    comments,
  ],
  opening: [len('width', 'Width', 'Dimensions'), len('height', 'Height', 'Dimensions'), len('sill', 'Sill Height', 'Constraints'), len('t', 'Position Along Wall', 'Constraints')],
  floor: [
    P('levelId', 'Level', 'Constraints', 'level'),
    P('fireRating', 'Fire Rating', 'Fire Safety', 'text'),
    len('offset', 'Height Offset From Level', 'Constraints'),
    P('refPlane', 'Reference Plane', 'Constraints', 'select', { get: (el) => el.refPlane || 'top', options: () => SLAB_REF_PLANES }),
    len('refOffset', 'Reference Plane Offset From Level', 'Constraints', { get: (el, c) => refOffset(el, c.doc.get(el.typeId)), set: (el, v, c) => ({ offset: offsetForRef(el, c.doc.get(el.typeId), v) }) }),
    P('structural', 'Structural', 'Structural', 'bool'),
    ro('thickness', 'Thickness', 'Dimensions', (el, c) => typeThickness(c.doc.get(el.typeId))),
    ro('area', 'Area', 'Dimensions', (el) => slabArea(el), 'area'),
    ro('perimeter', 'Perimeter', 'Dimensions', (el) => perimeter(el.boundary || [])),
    ro('volume', 'Volume', 'Dimensions', (el, c) => slabArea(el) * typeThickness(c.doc.get(el.typeId)), 'volume'),
    ...thermal,
    mark,
    comments,
  ],
  ceiling: [P('levelId', 'Level', 'Constraints', 'level'), len('offset', 'Height Offset From Level', 'Constraints'), ro('area', 'Area', 'Dimensions', (el) => slabArea(el), 'area'), ro('perimeter', 'Perimeter', 'Dimensions', (el) => perimeter(el.boundary || [])), mark, comments],
  roof: [
    P('fascia', 'Fascia', 'Accessories', 'bool'),
    P('gutters', 'Gutters', 'Accessories', 'bool'),
    P('downpipes', 'Downpipes', 'Accessories', 'bool', { get: (el) => el.downpipes !== false, ro: (el) => !el.gutters }),
    P('levelId', 'Base Level', 'Constraints', 'level'),
    len('baseOffset', 'Base Offset From Level', 'Constraints'),
    P('slope', 'Slope (degrees)', 'Construction', 'number', {
      get: (el) => (el.slopes || []).find((s) => s != null) ?? 0,
      set: (el, v) => ({ slopes: (el.slopes || el.boundary.map(() => v)).map((s) => (s == null ? null : Math.max(0, Math.min(80, +v)))) }),
    }),
    // A second level breaks the slope at a height above the base (a mansard or gambrel); see roof.js.
    len('upperHeight', 'Upper Level Height (0: none)', 'Construction', {
      get: (el) => el.levels?.[0]?.height ?? 0,
      set: (el, v) => ({ levels: +v > 0 ? [{ height: +v, slope: el.levels?.[0]?.slope ?? 20 }] : [] }),
    }),
    P('upperSlope', 'Upper Level Slope (degrees)', 'Construction', 'number', {
      get: (el) => el.levels?.[0]?.slope ?? 20,
      set: (el, v) => ({ levels: el.levels?.[0] ? [{ ...el.levels[0], slope: Math.max(1, Math.min(80, +v)) }] : [] }),
    }),
    len('overhang', 'Eaves Overhang', 'Construction', {
      get: (el) => (el.overhangs || []).find((o) => +o > 0) ?? 0,
      set: (el, v) => ({ overhangs: el.boundary.map(() => Math.max(0, +v || 0)) }),
    }),
    ro('thickness', 'Thickness', 'Dimensions', (el, c) => typeThickness(c.doc.get(el.typeId))),
    ro('area', 'Footprint Area', 'Dimensions', (el) => polyArea(el.boundary || []), 'area'),
    ...thermal,
    ro('ridge', 'Ridge Height', 'Dimensions', (el, c) => {
      try {
        const g = roofGeometry(c.doc, el);
        let mx = 0;
        for (const f of g.faces) for (const p of f.poly) if (f.plane) mx = Math.max(mx, planeHeight(f.plane, p));
        return mx;
      } catch {
        return 0;
      }
    }),
    mark,
    comments,
  ],
  column: [
    P('levelId', 'Base Level', 'Constraints', 'level'),
    len('baseOffset', 'Base Offset', 'Constraints'),
    topConstraint,
    len('topOffset', 'Top Offset', 'Constraints', { ro: (el) => !el.topLevelId }),
    len('height', 'Unconnected Height', 'Constraints', { ro: (el) => !!el.topLevelId }),
    P('rotation', 'Rotation', 'Constraints', 'angle'),
    len('topWidth', 'Top Width (tapered)', 'Dimensions', { get: (el, c) => +el.topWidth || +c.doc.get(el.typeId)?.width || 0 }),
    len('topDepth', 'Top Depth (tapered)', 'Dimensions', { get: (el, c) => +el.topDepth || +c.doc.get(el.typeId)?.depth || 0 }),
    P('structural', 'Structural', 'Structural', 'bool'),
    mark,
    comments,
  ],
  beam: [P('levelId', 'Reference Level', 'Constraints', 'level'), len('endWidth', 'End Width', 'Dimensions'), len('endDepth', 'End Depth', 'Dimensions'), len('offset', 'Top Offset From Level', 'Constraints'), ro('length', 'Length', 'Dimensions', (el) => dist(el.a, el.b)), endRelease, mark, comments],
  stair: [
    P('levelId', 'Base Level', 'Constraints', 'level'),
    P('external', 'External (Escape Route)', 'Fire Safety', 'bool'),
    len('baseOffset', 'Base Offset', 'Constraints'),
    P('topLevelId', 'Top Level', 'Constraints', 'levelOpt', { none: 'Unconnected' }),
    len('topOffset', 'Top Offset', 'Constraints', { ro: (el) => !el.topLevelId }),
    len('height', 'Unconnected Height', 'Constraints', { ro: (el) => !!el.topLevelId }),
    P('shape', 'Shape', 'Construction', 'select', { get: (el) => el.shape || 'straight', options: () => STAIR_SHAPES }),
    P('turn', 'Turn', 'Construction', 'select', {
      get: (el) => el.turn || 'left',
      options: () => [
        { value: 'left', label: 'Left' },
        { value: 'right', label: 'Right' },
      ],
    }),
    len('width', 'Width', 'Dimensions', { get: (el, c) => stairLayout(c.doc, el).width }),
    P('risers', 'Number of Risers', 'Dimensions', 'number', { get: (el, c) => stairLayout(c.doc, el).risers, set: (el, v) => ({ risers: Math.max(2, Math.round(+v)) }) }),
    ro('riserHeight', 'Actual Riser Height', 'Dimensions', (el, c) => stairLayout(c.doc, el).riserHeight),
    len('tread', 'Tread Depth', 'Dimensions', { get: (el, c) => stairLayout(c.doc, el).tread }),
    ro('run', 'Run Length', 'Dimensions', (el, c) => stairLayout(c.doc, el).runLength),
    ro('rules', 'Stair Rules', 'Dimensions', (el, c) => stairRulesStatus(c.doc, el), 'text'),
    P('railings', 'Handrails', 'Construction', 'bool'),
    mark,
    comments,
  ],
  railing: [P('levelId', 'Level', 'Constraints', 'level'), len('offset', 'Offset From Level', 'Constraints'), ro('length', 'Length', 'Dimensions', (el) => pathLength(el.path || [])), mark, comments],
  component: [
    P('levelId', 'Level', 'Constraints', 'level'),
    len('offset', 'Offset From Level', 'Constraints'),
    P('rotation', 'Rotation', 'Constraints', 'angle'),
    ro('wd', 'Width', 'Dimensions', (el, c) => c.doc.get(el.typeId)?.width ?? 0),
    ro('dp', 'Depth', 'Dimensions', (el, c) => c.doc.get(el.typeId)?.depth ?? 0),
    ro('ht', 'Height', 'Dimensions', (el, c) => c.doc.get(el.typeId)?.height ?? 0),
    mark,
    comments,
  ],
  room: [
    P('name', 'Name', 'Identity Data', 'text'),
    P('number', 'Number', 'Identity Data', 'text'),
    ro('level', 'Level', 'Constraints', (el, c) => c.doc.get(el.levelId)?.name ?? '', 'text'),
    len('upperOffset', 'Height', 'Constraints'),
    P('beds', 'Beds', 'Fire Safety', 'number'),
    P('occupants', 'Occupants (override)', 'Fire Safety', 'number'),
    ro('escapeLength', 'Longest Way Out (m)', 'Fire Safety', (el) => (el.egress ? el.egress.les : ''), 'text'),
    ro('deadEnd', 'Dead End (m)', 'Fire Safety', (el) => (el.egress ? el.egress.lcc : ''), 'text'),
    // Archicad's construction methods: Automatic (from the walls around the point) or Manual (a drawn outline).
    P('construction', 'Construction', 'Constraints', 'select', {
      get: (el) => (Array.isArray(el.boundary) ? 'manual' : 'automatic'),
      options: () => [{ value: 'automatic', label: 'Automatic' }, { value: 'manual', label: 'Manual' }],
      // Manual keeps the outline the room has now.
      set: (el, v, c) => (v === 'automatic' ? { boundary: null } : Array.isArray(el.boundary) ? {} : { boundary: c?.scene?.rooms.room(el)?.outer?.map((p) => [p[0], p[1]]) ?? null }),
    }),
    ro('area', 'Area', 'Dimensions', (el, c) => c.scene?.rooms.room(el)?.area ?? 0, 'area'),
    ro('grossArea', 'Gross Area', 'Dimensions', (el, c) => grossArea(c.doc, c.scene?.rooms.room(el), el), 'area'),
    ro('reducedArea', 'Reduced Area', 'Dimensions', (el, c) => reducedArea(c.doc, c.scene?.rooms.room(el), el), 'area'),
    ro('calculatedArea', 'Calculated Area', 'Dimensions', (el, c) => calculatedArea(c.doc, c.scene?.rooms.room(el), el), 'area'),
    ro('perimeter', 'Perimeter', 'Dimensions', (el, c) => c.scene?.rooms.room(el)?.perimeter ?? 0),
    ro('volume', 'Volume', 'Dimensions', (el, c) => roomVolume(c.doc, el, c.scene?.rooms.room(el))?.volume ?? 0, 'volume'),
    ro('netHeight', 'Net Height (cropped)', 'Dimensions', (el, c) => {
      const v = roomVolume(c.doc, el, c.scene?.rooms.room(el));
      return v?.cropped ? v.netHeight : 0;
    }),
    P('zoneCategoryId', 'Category', 'Identity Data', 'select', {
      get: (el, c) => (el.zoneCategoryId === '' ? '' : zoneCategoryOf(c.doc, el)?.id ?? ''),
      options: (c) => [{ value: '', label: 'None' }, ...c.doc.all('zoneCategory').map((z) => ({ value: z.id, label: `${z.code ? `${z.code} ` : ''}${z.name}` }))],
    }),
    P('stamp', 'Zone Stamp', 'Graphics', 'select', { get: (el) => el.stamp || 'standard', options: () => ZONE_STAMPS }),
    P('department', 'Department', 'Identity Data', 'text'),
    P('floorFinish', 'Floor Finish', 'Identity Data', 'text'),
    P('wallFinish', 'Wall Finish', 'Identity Data', 'text'),
    P('ceilingFinish', 'Ceiling Finish', 'Identity Data', 'text'),
    P('occupant', 'Occupant', 'Identity Data', 'text'),
    comments,
  ],
  roomSeparator: [ro('length', 'Length', 'Dimensions', (el) => dist(el.a, el.b))],
  grid: [
    P('name', 'Name', 'Identity Data', 'text'),
    P('bubbles', 'Bubbles', 'Graphics', 'select', {
      options: () => [
        { value: 'both', label: 'Both ends' },
        { value: 'start', label: 'Start' },
        { value: 'end', label: 'End' },
      ],
    }),
    ro('length', 'Length', 'Dimensions', (el) => dist(el.a, el.b)),
  ],
  level: [P('name', 'Name', 'Identity Data', 'text'), len('elevation', 'Elevation', 'Constraints')],
  dimension: [
    P('eq', 'Equal Spacing (EQ)', 'Constraints', 'bool', { get: (el) => !!el.eq, ro: (el) => (el.refs?.length ?? 0) < 3 }),
    P('eqDisplay', 'EQ Display', 'Constraints', 'select', { get: (el) => el.eqDisplay || 'eq', options: () => [{ value: 'eq', label: 'EQ' }, { value: 'value', label: 'Values' }], ro: (el) => !el.eq }),
    P('locked', 'Locked', 'Constraints', 'bool', { get: (el) => !!el.locks?.length, set: (el, v, c) => lockAll(c.doc, c.scene?.walls, el, !!v) }),
    P('override', 'Text Override', 'Text', 'text'),
    ro('refs', 'References', 'Other', (el) => String(el.refs?.length ?? 0), 'text'),
  ],
  text: [
    P('text', 'Text', 'Text', 'textarea'),
    P('styleId', 'Text Style', 'Text', 'select', { get: (el) => el.styleId || '', set: (el, v) => ({ styleId: v || null }), options: (c) => [{ value: '', label: 'None (own settings)' }, ...c.doc.all('textStyle').map((t) => ({ value: t.id, label: `${t.name} (${t.size} mm${t.bold ? ', bold' : ''})` }))] }),
    P('size', 'Size (mm on paper)', 'Text', 'select', { ro: (el) => !!el.styleId, options: () => [1.8, 2.5, 3.5, 5, 7].map((v) => ({ value: v, label: `${v} mm` })) }),
    P('rotation', 'Rotation', 'Text', 'angle'),
    P('bold', 'Bold', 'Text', 'bool', { ro: (el) => !!el.styleId }),
    P('align', 'Alignment', 'Text', 'select', {
      options: () => [
        { value: 'left', label: 'Left' },
        { value: 'center', label: 'Center' },
        { value: 'right', label: 'Right' },
      ],
    }),
  ],
  viewport: [
    P('titleStyle', 'Title', 'Graphics', 'select', {
      get: (el) => el.titleStyle || 'bubble',
      options: () => [
        { value: 'bubble', label: 'Number, name and scale' },
        { value: 'simple', label: 'Name and scale' },
        { value: 'none', label: 'No title' },
      ],
    }),
    P('cropped', 'Crop to Frame', 'Graphics', 'bool', { get: (el) => !!el.cropped }),
    P('frameW', 'Frame Width (mm on paper)', 'Graphics', 'number', { get: (el) => el.frame?.[0] ?? null, set: (el, v) => (+v > 0 ? { frame: [+v, el.frame?.[1] ?? +v] } : null) }),
    P('frameH', 'Frame Height (mm on paper)', 'Graphics', 'number', { get: (el) => el.frame?.[1] ?? null, set: (el, v) => (+v > 0 ? { frame: [el.frame?.[0] ?? +v, +v] } : null) }),
    P('titleText', 'Title Text', 'Text', 'textarea', { get: (el) => el.titleText ?? '{View Name}', set: (el, v) => ({ titleText: v === '{View Name}' || !v ? null : v }), hint: () => 'Fields in braces: {View Name} {Scale} {Number}' }),
  ],
  tag: [
    P('show', 'Shows', 'Graphics', 'select', {
      get: (el) => el.show || 'mark',
      options: () => [
        { value: 'mark', label: 'Mark' },
        { value: 'type', label: 'Type' },
        { value: 'material', label: 'Material' },
        { value: 'keynote', label: 'Keynote' },
        { value: 'name', label: 'Name' },
        { value: 'autotext', label: 'Autotext' },
      ],
    }),
    P('template', 'Autotext', 'Text', 'textarea', {
      get: (el, c) => el.template ?? AUTOTEXT_DEFAULTS[c.doc.get(el.targetId)?.kind] ?? '{Type}',
      ro: (el) => (el.show || 'mark') !== 'autotext',
      hint: (el, c) => `Fields in braces: ${autotextFields(c.doc.get(el.targetId), c.doc).map((f) => `{${f.label}}`).join(' ')}`,
    }),
    P('frame', 'Frame', 'Graphics', 'bool', { ro: (el) => (el.show || 'mark') !== 'autotext' }),
    P('leader', 'Leader Line', 'Graphics', 'bool'),
    ro('target', 'Tags', 'Other', (el, c) => describe(c.doc, c.doc.get(el.targetId)), 'text'),
  ],
  region: [
    P('deductFromZones', 'Subtract from Zones', 'Graphics', 'bool'),
    P('pattern', 'Fill Pattern', 'Graphics', 'select', {
      options: (c) => [
        ...['diag', 'cross', 'concrete', 'insulation', 'brick', 'wood', 'earth', 'solid', 'none'].map((v) => ({ value: v, label: v === 'none' ? 'Gray tone' : v[0].toUpperCase() + v.slice(1) })),
        ...c.doc.all('fillType').map((f) => ({ value: f.id, label: `Fill type: ${f.name}` })),
      ],
    }),
    P('outline', 'Show Outline', 'Graphics', 'bool'),
    ro('area', 'Area', 'Dimensions', (el) => polyArea(el.boundary || []), 'area'),
  ],
  detailLine: [
    P('style', 'Line Style', 'Graphics', 'select', { options: (c) => lineStyleOptions(c.doc) }),
    ro('length', 'Length', 'Dimensions', (el) => dist(el.a, el.b)),
  ],
  modelLine: [
    P('levelId', 'Level', 'Constraints', 'level'),
    len('offset', 'Offset From Level', 'Constraints'),
    P('style', 'Line Style', 'Graphics', 'select', { options: (c) => lineStyleOptions(c.doc) }),
    ro('length', 'Length', 'Dimensions', (el) => dist(el.a, el.b)),
  ],
  refPlane: [P('name', 'Name', 'Identity Data', 'text'), ro('length', 'Length', 'Dimensions', (el) => dist(el.a, el.b))],
  ramp: [
    P('levelId', 'Base Level', 'Constraints', 'level'),
    len('baseOffset', 'Base Offset', 'Constraints'),
    P('topLevelId', 'Top Level', 'Constraints', 'levelOpt', { none: 'Unconnected' }),
    len('topOffset', 'Top Offset', 'Constraints', { ro: (el) => !el.topLevelId }),
    len('height', 'Unconnected Height', 'Constraints', { ro: (el) => !!el.topLevelId }),
    len('width', 'Width', 'Dimensions', { get: (el, c) => rampLayout(c.doc, el).width }),
    P('slopeRatio', 'Slope (1 in ...)', 'Dimensions', 'number', { get: (el, c) => rampLayout(c.doc, el).ratio, set: (el, v) => ({ slopeRatio: Math.max(1, +v) }) }),
    ro('run', 'Run Length', 'Dimensions', (el, c) => rampLayout(c.doc, el).run),
    ro('rise', 'Rise', 'Dimensions', (el, c) => rampLayout(c.doc, el).rise),
    P('railings', 'Handrails', 'Construction', 'bool', { get: (el) => el.railings !== false }),
    mark,
    comments,
  ],
  area: [
    P('name', 'Name', 'Identity Data', 'text'),
    P('number', 'Number', 'Identity Data', 'text'),
    ro('scheme', 'Area Scheme', 'Identity Data', (el) => schemeLabel(el.scheme), 'text'),
    ro('level', 'Level', 'Constraints', (el, c) => c.doc.get(el.levelId)?.name ?? '', 'text'),
    P('areaType', 'Area Type', 'Identity Data', 'select', { get: (el) => el.areaType || 'floor', options: () => AREA_TYPES }),
    ro('area', 'Area', 'Dimensions', (el, c) => c.scene?.areas.area(el)?.area ?? 0, 'area'),
    ro('perimeter', 'Perimeter', 'Dimensions', (el, c) => c.scene?.areas.area(el)?.perimeter ?? 0),
    comments,
  ],
  areaBoundary: [ro('scheme', 'Area Scheme', 'Identity Data', (el) => schemeLabel(el.scheme), 'text'), ro('length', 'Length', 'Dimensions', (el) => dist(el.a, el.b))],
  angularDim: [ro('angle', 'Angle', 'Dimensions', (el, c) => formatAngle(((el.a1 - el.a0) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI), 2, c.doc.units), 'text'), len('r', 'Arc Radius', 'Graphics')],
  radialDim: [P('diameter', 'Show Diameter', 'Graphics', 'bool'), ro('value', 'Value', 'Dimensions', (el, c) => radialTarget(c.doc, el).r * (el.diameter ? 2 : 1))],
  spot: [
    ro('mode', 'Type', 'Identity Data', (el) => ({ elevation: 'Spot Elevation', coordinate: 'Spot Coordinate', slope: 'Spot Slope' })[el.mode] || '', 'text'),
    P('origin', 'Relative To', 'Constraints', 'select', {
      get: (el) => el.origin || (el.mode === 'coordinate' ? 'survey' : 'project'),
      options: (c) => [
        { value: 'project', label: 'Project base point' },
        { value: 'survey', label: 'Survey point' },
        ...referenceLevels(c.doc.get('project')).map((r, i) => ({ value: `ref${i + 1}`, label: r.name })),
      ],
      ro: (el) => el.mode === 'slope',
    }),
  ],
  revisionCloud: [
    P('changeId', 'Change ID', 'Identity Data', 'text'),
    P('changeDescription', 'Change Description', 'Identity Data', 'text'),
    P('revisionId', 'Revision', 'Identity Data', 'select', { options: (c) => c.doc.all('revision').sort((a, b) => (a.seq ?? 0) - (b.seq ?? 0)).map((r) => ({ value: r.id, label: `${r.number ?? r.seq}: ${r.description || ''}` })) }),
    P('showTag', 'Show Revision Tag', 'Graphics', 'bool', { get: (el) => el.showTag !== false }),
  ],
  insulation: [len('width', 'Insulation Width', 'Dimensions'), ro('length', 'Length', 'Dimensions', (el) => dist(el.a, el.b))],
  detailItem: [
    P('family', 'Component', 'Identity Data', 'select', { options: () => DETAIL_FAMILIES }),
    len('w', 'Width', 'Dimensions'),
    len('h', 'Height', 'Dimensions'),
    P('rotation', 'Rotation', 'Graphics', 'angle'),
  ],
  spline: [
    P('closed', 'Closed', 'Graphics', 'bool'),
    P('style', 'Line Style', 'Graphics', 'select', { options: (c) => lineStyleOptions(c.doc) }),
    ro('length', 'Length', 'Dimensions', (el) => splineLength(el.path || [], !!el.closed)),
  ],
  polyline: [
    P('closed', 'Closed', 'Graphics', 'bool'),
    P('style', 'Line Style', 'Graphics', 'select', { options: (c) => lineStyleOptions(c.doc) }),
    ro('length', 'Length', 'Dimensions', (el) => polylineLength(el)),
  ],
  camera: [
    P('name', 'Name', 'Identity Data', 'text'),
    len('eyeHeight', 'Eye Height', 'Dimensions'),
    len('targetHeight', 'Target Height', 'Dimensions'),
    P('fov', 'View Cone (degrees)', 'Dimensions', 'number'),
  ],
  detailArc: [len('r', 'Radius', 'Dimensions'), P('style', 'Line Style', 'Graphics', 'select', { options: (c) => lineStyleOptions(c.doc) })],
  symbol: [P('rotation', 'Rotation', 'Graphics', 'angle'), P('size', 'Size', 'Graphics', 'number', { get: (el) => +el.size || 1 })],
  space: [
    P('levelId', 'Level', 'Constraints', 'level', { ro: () => true }),
    len('height', 'Height', 'Dimensions'),
    ro('area', 'Area', 'Dimensions', (el, c) => spaceLoads(el, c.scene?.rooms.room(el))?.area * 1e6 || 0, 'area'),
    P('number', 'Number', 'Identity Data', 'text'),
    P('name', 'Name', 'Identity Data', 'text'),
    P('spaceType', 'Space Type', 'Energy Analysis', 'select', { get: (el) => el.spaceType || 'office', options: () => SPACE_TYPES.map((t) => ({ value: t.value, label: t.label })) }),
    P('zoneId', 'Zone', 'Energy Analysis', 'select', { get: (el) => el.zoneId || '', set: (el, v) => ({ zoneId: v || null }), options: (c) => [{ value: '', label: 'None' }, ...c.doc.all('zone').map((z) => ({ value: z.id, label: z.name }))] }),
    P('people', 'Number of People', 'Energy Analysis', 'text', { get: (el, c) => (el.people != null && el.people !== '' ? el.people : spaceLoads(el, c.scene?.rooms.room(el))?.people ?? ''), set: (el, v) => ({ people: v === '' ? null : Math.max(0, Math.round(+v) || 0) }) }),
    ro('cooling', 'Cooling Load (estimate, W)', 'Energy Analysis', (el, c) => Math.round(spaceLoads(el, c.scene?.rooms.room(el))?.cooling || 0), 'text'),
    ro('heating', 'Heating Load (estimate, W)', 'Energy Analysis', (el, c) => Math.round(spaceLoads(el, c.scene?.rooms.room(el))?.heating || 0), 'text'),
  ],
  zone: [P('name', 'Name', 'Identity Data', 'text')],
  wire: [P('circuit', 'Circuit', 'Identity Data', 'text'), P('ticks', 'Conductor Ticks', 'Graphics', 'select', { get: (el) => +el.ticks || 0, options: () => [0, 2, 3, 4].map((v) => ({ value: v, label: String(v) })) }), comments],
  truss: [
    P('levelId', 'Reference Level', 'Constraints', 'level'),
    len('offset', 'Bottom Chord Height', 'Constraints'),
    len('height', 'Height Override (0 = type)', 'Dimensions', { get: (el) => el.height || 0, set: (el, v) => ({ height: +v > 0 ? +v : null }) }),
    ro('length', 'Span', 'Dimensions', (el) => (el.a && el.b ? Math.hypot(el.b[0] - el.a[0], el.b[1] - el.a[1]) : 0)),
    mark,
    comments,
  ],
  scopeBox: [P('name', 'Name', 'Identity Data', 'text'), len('z0', 'Bottom Elevation', 'Extents'), len('z1', 'Top Elevation', 'Extents'), ro('views', 'Views Using It', 'Identity Data', (el, c) => String(c.doc.filter((v) => v.scopeBoxId === el.id).length), 'text')],
  wallSweep: [
    len('z', 'Offset From Wall Base', 'Constraints'),
    P('side', 'Face', 'Constraints', 'select', { get: (el) => el.side || 'exterior', options: () => [{ value: 'exterior', label: 'Exterior' }, { value: 'interior', label: 'Interior' }] }),
    P('comments', 'Comments', 'Identity Data', 'text'),
  ],
  wallCladding: [
    P('accessory', 'Accessory', 'Constraints', 'select', { get: (el) => el.accessory || 'cladding', options: () => WALL_ACCESSORIES }),
    P('side', 'Face', 'Constraints', 'select', { get: (el) => el.side || 'exterior', options: () => [{ value: 'exterior', label: 'Exterior' }, { value: 'interior', label: 'Interior' }] }),
    P('materialId', 'Material', 'Materials and Finishes', 'material'),
    P('comments', 'Comments', 'Identity Data', 'text'),
  ],
  slabAccessory: [
    P('accessory', 'Accessory', 'Constraints', 'select', { get: (el) => el.accessory || 'floor', options: () => SLAB_ACCESSORIES }),
    len('joistSpacing', 'Joist Spacing', 'Construction', { get: (el) => el.joistSpacing ?? 400 }),
    len('joistWidth', 'Joist Width', 'Construction', { get: (el) => el.joistWidth ?? 50 }),
    len('joistDepth', 'Joist Depth', 'Construction', { get: (el) => el.joistDepth ?? 220 }),
    len('stemWidth', 'Stem Wall Width', 'Construction', { get: (el) => el.stemWidth ?? 200 }),
    len('stemHeight', 'Stem Wall Height', 'Construction', { get: (el) => el.stemHeight ?? 600 }),
    len('footingWidth', 'Footing Width', 'Construction', { get: (el) => el.footingWidth ?? 600 }),
    len('footingDepth', 'Footing Depth', 'Construction', { get: (el) => el.footingDepth ?? 300 }),
    P('sill', 'Sill Plate', 'Construction', 'bool', { get: (el) => el.sill !== false }),
    P('materialId', 'Material', 'Materials and Finishes', 'material'),
    P('comments', 'Comments', 'Identity Data', 'text'),
  ],
  roofAccessory: [
    P('accessory', 'Accessory', 'Constraints', 'select', { get: (el) => el.accessory || 'surfacer', options: () => ROOF_ACCESSORIES }),
    P('sheathing', 'Sheathing Type', 'Construction', 'select', { get: (el) => el.sheathing || 'tiles', options: () => SHEATHING }),
    len('tileWidth', 'Tile or Sheet Width', 'Construction', { get: (el) => el.tileWidth ?? (el.sheathing === 'metal' ? 600 : 300) }),
    len('course', 'Tile Course (along the slope)', 'Construction', { get: (el) => el.course ?? 340 }),
    len('boardWidth', 'Ceiling Board Width', 'Construction', { get: (el) => el.boardWidth ?? 120 }),
    len('boardThickness', 'Ceiling Board Thickness', 'Construction', { get: (el) => el.boardThickness ?? 15 }),
    P('materialId', 'Material', 'Materials and Finishes', 'material'),
    P('comments', 'Comments', 'Identity Data', 'text'),
  ],
  roomAccessory: [
    len('skirtingHeight', 'Skirting Height', 'Construction', { get: (el) => el.skirtingHeight ?? 100 }),
    len('skirtingDepth', 'Skirting Depth', 'Construction', { get: (el) => el.skirtingDepth ?? 15 }),
    P('cornice', 'Cornice', 'Construction', 'bool'),
    len('corniceHeight', 'Cornice Height', 'Construction', { get: (el) => el.corniceHeight ?? 80 }),
    P('materialId', 'Material', 'Materials and Finishes', 'material'),
    P('comments', 'Comments', 'Identity Data', 'text'),
  ],
  structuralSupport: [
    P('levelId', 'Level', 'Constraints', 'level'),
    len('offset', 'Offset From Level', 'Constraints'),
    P('fixity', 'Support Type', 'Structural', 'select', { get: (el) => el.fixity || 'pinned', options: () => FIXITY }),
    P('comments', 'Comments', 'Identity Data', 'text'),
  ],
  structuralLoad: [
    P('levelId', 'Level', 'Constraints', 'level'),
    len('offset', 'Offset From Level', 'Constraints'),
    P('loadCase', 'Load Case', 'Structural', 'select', { get: (el) => el.loadCase || 'dead', options: (c) => loadCases(c.doc.get('project')) }),
    P('value', 'Value', 'Structural', 'number', { get: (el, c) => Math.round(loadToDisplay(+el.value || 0, el.type, structuralUnits(c.doc.get('project'))) * 1000) / 1000, set: (el, v, c) => ({ value: loadFromDisplay(+v, el.type, structuralUnits(c.doc.get('project'))) }) }),
    ro('valueUnit', 'Value Unit', 'Structural', (el, c) => loadUnitLabel(el.type, structuralUnits(c.doc.get('project'))), 'text'),
    ro('total', 'Total Force', 'Structural', (el, c) => { const u = structuralUnits(c.doc.get('project')); return `${loadToDisplay(loadTotal(el), 'point', u).toFixed(2)} ${loadUnitLabel('point', u)}`; }, 'text'),
    P('comments', 'Comments', 'Identity Data', 'text'),
  ],
  basePoint: [
    ro('role', 'Point', 'Identity Data', (el) => (el.role === 'survey' ? 'Survey Point' : 'Project Base Point'), 'text'),
    len('n', 'N/S (northing here)', 'Constraints', { ro: (el) => el.role !== 'survey' }),
    len('e', 'E/W (easting here)', 'Constraints', { ro: (el) => el.role !== 'survey' }),
    len('elevation', 'Elevation', 'Constraints'),
  ],
  matchline: [P('name', 'Name', 'Identity Data', 'text'), len('z0', 'Bottom Elevation', 'Extents'), len('z1', 'Top Elevation', 'Extents')],
  viewRef: [P('targetId', 'Target View', 'Identity Data', 'select', { options: (c) => c.doc.filter((v) => ['plan', 'ceilingPlan', 'areaPlan', 'elevation', 'section', 'drafting', 'view3d', 'legend'].includes(v.kind)).map((v) => ({ value: v.id, label: v.name })) })],
  modelText: [
    P('text', 'Text', 'Text', 'text'),
    len('size', 'Letter Height', 'Dimensions'),
    len('depth', 'Depth', 'Dimensions'),
    P('plane', 'Orientation', 'Constraints', 'select', { get: (el) => el.plane || 'vertical', options: () => [{ value: 'vertical', label: 'Standing' }, { value: 'horizontal', label: 'Flat' }] }),
    P('levelId', 'Level', 'Constraints', 'level'),
    len('offset', 'Base Above Level', 'Constraints'),
    P('rotation', 'Rotation', 'Constraints', 'angle'),
    P('materialId', 'Material', 'Materials and Finishes', 'material'),
  ],
  importedModel: [
    P('name', 'Name', 'Identity Data', 'text'),
    len('z', 'Elevation Offset', 'Constraints'),
    P('rotation', 'Rotation', 'Constraints', 'angle'),
    ro('source', 'Source', 'Identity Data', (el) => el.source || '', 'text'),
    ro('count', 'Elements', 'Identity Data', (el) => String(el.count || 0), 'text'),
    ro('types', 'Contents', 'Identity Data', (el) => Object.entries(el.types || {}).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, v]) => `${v} ${k.toLowerCase()}`).join(', '), 'text'),
  ],
  link: [
    P('name', 'Name', 'Identity Data', 'text'),
    len('z', 'Elevation Offset', 'Constraints'),
    P('rotation', 'Rotation', 'Constraints', 'angle'),
    ro('source', 'Source', 'Identity Data', (el) => el.path || 'Device file', 'text'),
    P('reload', 'Linked Project', 'Identity Data', 'button', { action: 'reloadLinkFrom', text: 'Reload From...' }),
  ],
  image: [
    P('name', 'Name', 'Identity Data', 'text'),
    len('w', 'Width', 'Dimensions', { set: (el, v) => ({ w: +v, h: (+v * (+el.h || 1)) / (+el.w || 1) }) }),
    len('h', 'Height', 'Dimensions', { set: (el, v) => ({ h: +v, w: (+v * (+el.w || 1)) / (+el.h || 1) }) }),
    P('rotation', 'Rotation', 'Graphics', 'angle'),
    P('opacity', 'Opacity (0 to 1)', 'Graphics', 'number', { get: (el) => el.opacity ?? 1, set: (el, v) => ({ opacity: Math.max(0.05, Math.min(1, +v)) }) }),
  ],
  colorLegend: [ro('by', 'Colors By', 'Graphics', (el, c) => ROOM_FILL_LABEL[c.doc.get(el.viewId)?.roomFillBy || 'name'], 'text')],
  footing: [P('levelId', 'Level', 'Constraints', 'level'), len('offset', 'Top Offset From Level', 'Constraints'), P('rotation', 'Rotation', 'Constraints', 'angle'), mark, comments],
  wallFooting: [ro('wall', 'Wall', 'Constraints', (el, c) => c.doc.get(c.doc.get(el.wallId)?.typeId)?.name ?? '', 'text'), ro('length', 'Length', 'Dimensions', (el, c) => (c.doc.get(el.wallId) ? dist(c.doc.get(el.wallId).a, c.doc.get(el.wallId).b) : 0)), mark, comments],
  brace: [
    endRelease,
    P('levelId', 'Start Level', 'Constraints', 'level'),
    len('baseOffset', 'Start Offset', 'Constraints'),
    P('topLevelId', 'End Level', 'Constraints', 'levelOpt', { none: 'Unconnected' }),
    len('topOffset', 'End Offset', 'Constraints', { ro: (el) => !el.topLevelId }),
    len('height', 'Unconnected Rise', 'Constraints', { ro: (el) => !!el.topLevelId }),
    ro('length', 'Length', 'Dimensions', (el, c) => {
      const { z0, z1 } = braceHeights(c.doc, el);
      return Math.hypot(dist(el.a, el.b), z1 - z0);
    }),
    mark,
    comments,
  ],
  duct: mepParams('duct'),
  pipe: mepParams('pipe'),
  cableTray: mepParams('cableTray'),
  conduit: mepParams('conduit'),
  topo: [
    len('thickness', 'Thickness', 'Dimensions'),
    len('contour', 'Contour Interval', 'Graphics'),
    ro('points', 'Points', 'Dimensions', (el) => String(el.points?.length ?? 0), 'text'),
    ro('area', 'Projected Area', 'Dimensions', (el) => polyArea(topoBoundary(el)), 'area'),
    P('materialId', 'Material', 'Materials and Finishes', 'material'),
    P('editPoints', 'Points', 'Other', 'button', { action: 'topo-points', text: 'Edit...' }),
  ],
  propertyLine: [ro('area', 'Area', 'Dimensions', (el) => polyArea(el.boundary || []), 'area'), ro('perimeter', 'Perimeter', 'Dimensions', (el) => perimeter(el.boundary || [])), comments],
  skylight: [
    ro('host', 'Roof', 'Constraints', (el, c) => c.doc.get(c.doc.get(el.hostId)?.typeId)?.name ?? '', 'text'),
    len('width', 'Width (across the slope)', 'Dimensions'),
    len('length', 'Length (along the slope)', 'Dimensions'),
    mark,
    comments,
  ],
  morph: [
    P('levelId', 'Level', 'Constraints', 'level'),
    len('baseOffset', 'Base Offset', 'Constraints', { ro: (el) => !!el.tris }),
    // Setting the height levels every corner (core/morph.js).
    len('height', 'Height (all corners)', 'Dimensions', { ro: (el) => !!el.tris, get: (el) => +el.height || 3000, set: (el, v) => ({ height: +v, heights: null }) }),
    ro('kindOf', 'Body', 'Dimensions', (el) => (el.tris ? `Frozen, ${el.tris.length / 9} triangles` : `Prism, ${el.boundary?.length ?? 0} corners`), 'text'),
    P('materialId', 'Material', 'Materials and Finishes', 'material'),
    mark,
    comments,
  ],
  shell: [
    P('levelId', 'Level', 'Constraints', 'level'),
    len('baseOffset', 'Base Offset', 'Constraints'),
    P('shape', 'Shape', 'Construction', 'select', { get: (el) => el.shape || 'vault', options: () => [{ value: 'vault', label: 'Barrel Vault' }, { value: 'dome', label: 'Dome' }] }),
    len('span', 'Span (vault)', 'Dimensions', { ro: (el) => el.shape === 'dome' }),
    len('radius', 'Base Radius (dome)', 'Dimensions', { ro: (el) => el.shape !== 'dome' }),
    len('rise', 'Rise', 'Dimensions'),
    len('thickness', 'Thickness', 'Dimensions'),
    P('materialId', 'Material', 'Materials and Finishes', 'material'),
    mark,
    comments,
  ],
  mass: [
    P('name', 'Name', 'Identity Data', 'text'),
    P('levelId', 'Level', 'Constraints', 'level'),
    len('baseOffset', 'Base Offset', 'Constraints'),
    len('height', 'Height', 'Dimensions'),
    ro('footprint', 'Footprint Area', 'Dimensions', (el) => polyArea(el.boundary || []), 'area'),
    ro('gross', 'Gross Floor Area', 'Dimensions', (el, c) => massFloorArea(c.doc, el), 'area'),
    ro('volume', 'Volume', 'Dimensions', (el) => polyArea(el.boundary || []) * (+el.height || 0), 'volume'),
    comments,
  ],
  group: [
    ro('level', 'Reference Level', 'Constraints', (el, c) => c.doc.get(el.levelId)?.name ?? '', 'text'),
    P('rotation', 'Rotation', 'Constraints', 'angle', { ro: () => true }),
    ro('members', 'Members', 'Identity Data', (el, c) => String(c.doc.filter((x) => x.groupId === el.id).length), 'text'),
    ro('instances', 'Instances of Group', 'Identity Data', (el, c) => String(c.doc.all('group').filter((g) => g.typeId === el.typeId).length), 'text'),
    comments,
  ],
};

/** Built-in line styles and the project's own, for style pickers. */
export function lineStyleOptions(doc) {
  return [...LINE_STYLES, ...(doc ? doc.all('lineStyle').map((s) => ({ value: s.id, label: s.name })) : [])];
}

export const LINE_STYLES = ['thin', 'medium', 'wide', 'dashed', 'hidden', 'center'].map((v) => ({ value: v, label: v[0].toUpperCase() + v.slice(1) }));

/** Parameters of a duct, pipe, cable tray or conduit run. */
function mepParams(kind) {
  const round = (el, c) => mepSize(c.doc, el).round;
  const out = [
    P('levelId', 'Reference Level', 'Constraints', 'level'),
    len('offset', 'Middle Elevation', 'Constraints'),
    // A sloping run: the middle elevation at its end, or its slope in percent (mepnet.js).
    len('endOffset', 'End Middle Elevation', 'Constraints', { get: (el) => (el.endOffset != null ? +el.endOffset : +el.offset || 0) }),
    P('slope', 'Slope (%)', 'Constraints', 'number', {
      get: (el, c) => {
        const s = runSlope(c.doc, el);
        return s == null ? null : Math.round(s * 100) / 100;
      },
      set: (el, v) => {
        const l = dist(el.a, el.b);
        return l < 1 ? null : { endOffset: (+el.offset || 0) + (l * +v) / 100 };
      },
      ro: (el) => dist(el.a, el.b) < 1,
    }),
  ];
  if (SYSTEMS[kind].length > 1) out.push(P('system', 'System Type', 'Identity Data', 'select', { get: (el) => systemOf(el).value, options: () => SYSTEMS[kind] }));
  if (kind === 'pipe' || kind === 'conduit') out.push(len('diameter', 'Diameter', 'Dimensions', { get: (el, c) => mepSize(c.doc, el).w }));
  else {
    out.push(len('width', 'Width', 'Dimensions', { get: (el, c) => mepSize(c.doc, el).w, ro: round }));
    out.push(len('height', 'Height', 'Dimensions', { get: (el, c) => mepSize(c.doc, el).h, ro: round }));
    if (kind === 'duct') out.push(len('diameter', 'Diameter', 'Dimensions', { get: (el, c) => mepSize(c.doc, el).w, ro: (el, c) => !round(el, c) }));
  }
  out.push(ro('length', 'Length', 'Dimensions', (el, c) => runLength(c.doc, el)), mark, comments);
  return out;
}

const ZONE_STAMPS = [
  { value: 'standard', label: 'Name, number and area' },
  { value: 'detailed', label: 'Detailed (category, height, volume, finish)' },
  { value: 'compact', label: 'Number and area' },
  { value: 'none', label: 'None' },
];

const ROOM_FILL_LABEL = { category: 'Category', name: 'Name', department: 'Department', occupant: 'Occupant', floorFinish: 'Floor Finish', number: 'Number' };

export const AREA_SCHEMES = [
  { value: 'gross', label: 'Gross Building' },
  { value: 'rentable', label: 'Rentable' },
];

export const AREA_TYPES = [
  { value: 'floor', label: 'Floor Area' },
  { value: 'office', label: 'Office Area' },
  { value: 'store', label: 'Store Area' },
  { value: 'common', label: 'Building Common Area' },
  { value: 'major', label: 'Major Vertical Penetration' },
  { value: 'exterior', label: 'Exterior Area' },
];

export function schemeLabel(s) {
  return AREA_SCHEMES.find((x) => x.value === (s || 'gross'))?.label ?? s;
}

const DETAIL = [
  { value: 'coarse', label: 'Coarse' },
  { value: 'medium', label: 'Medium' },
  { value: 'fine', label: 'Fine' },
];

const STYLES = [
  { value: 'wireframe', label: 'Wireframe' },
  { value: 'hidden', label: 'Hidden Line' },
  { value: 'shaded', label: 'Shaded' },
  { value: 'consistent', label: 'Consistent Colors' },
  { value: 'realistic', label: 'Realistic' },
];

const templated = (el) => !!el.templateId;
const viewName = P('name', 'View Name', 'Identity Data', 'text');
const viewScale = P('scale', 'View Scale', 'Graphics', 'select', { options: (c) => scaleOptions(c.doc.units), get: (el) => el.scale, set: (el, v) => ({ scale: +v }), ro: templated });
const viewDetail = P('detail', 'Detail Level', 'Graphics', 'select', { options: () => DETAIL, ro: templated });
const vis = P('vis', 'Visibility/Graphics', 'Graphics', 'button', { action: 'visibility', text: 'Edit...' });
const shadowsP = P('shadows', 'Cast Shadows', 'Graphics', 'bool', { get: (el) => !!el.shadows });
// Lamps lighting the 3D view (lamps.js), and how much daylight is left.
const lampLightP = P('lampLight', 'Lamp Light', 'Graphics', 'bool', { get: (el) => !!el.lampLight });
const daylightP = P('daylight', 'Time of Day', 'Graphics', 'select', { get: (el) => el.daylight || 'day', options: () => DAYLIGHT.map((d) => ({ value: d.value, label: d.label })), ro: (el) => !el.lampLight });
const viewStyle = P('style', 'Visual Style', 'Graphics', 'select', { options: () => STYLES, ro: templated });
const viewTemplate = P('templateId', 'View Template', 'Identity Data', 'select', {
  get: (el) => el.templateId || '',
  options: (c) => [{ value: '', label: '<None>' }, ...c.doc.all('viewTemplate').filter((t) => t.viewKind === templateKindOf(c.items?.[0]?.kind || 'plan')).map((t) => ({ value: t.id, label: t.name }))],
  set: (el, v, c) => (v ? applyTemplatePatch(c.doc.get(v)) : { templateId: null }),
});

/** A crop rectangle around what the view shows now (or a default area). */
export function defaultCrop(app, view) {
  const c = app?.controllers?.get(view.id) || (app && app.controllerFor?.(view));
  c?.sync?.();
  const b = c?.extents?.();
  const pad = 1000;
  return b ? { x0: b.x0 - pad, y0: b.y0 - pad, x1: b.x1 + pad, y1: b.y1 + pad } : { x0: -5000, y0: -5000, x1: 15000, y1: 12000 };
}

const cropOn = P('cropOn', 'Crop View', 'Extents', 'bool', { set: (el, v, c) => ({ cropOn: !!v, ...(v && !el.crop ? { crop: defaultCrop(c.app, el) } : {}) }) });
const cropShow = P('cropShow', 'Crop Region Visible', 'Extents', 'bool', { set: (el, v, c) => ({ cropShow: !!v, ...(v && !el.crop ? { crop: defaultCrop(c.app, el) } : {}) }) });

// Pen sets, as in Archicad: how a 2D view's colours print (renderer2d.js).
export const PEN_SETS = [
  { value: 'color', label: 'Color' },
  { value: 'grayscale', label: 'Grayscale' },
  { value: 'bw', label: 'Black and White' },
];
const penSet = P('penSet', 'Pen Set', 'Graphics', 'select', { get: (el) => el.penSet || 'color', options: () => PEN_SETS, ro: templated });

// Partial structure display (layerjoins.js), in plans, sections, elevations and 3D.
const structureDisplay = P('structureDisplay', 'Partial Structure Display', 'Graphics', 'select', { get: (el) => el.structureDisplay || 'entire', options: () => STRUCTURE_DISPLAY, ro: templated });

const VIEW = {
  plan: [
    viewScale,
    viewDetail,
    vis,
    P('roomFill', 'Room Color Fill', 'Graphics', 'bool', { ro: templated }),
    P('roomFillBy', 'Color Scheme', 'Graphics', 'select', { get: (el) => el.roomFillBy || 'name', options: () => Object.entries(ROOM_FILL_LABEL).map(([value, label]) => ({ value, label: `Rooms by ${label}` })), ro: templated }),
    structureDisplay,
    penSet,
    viewTemplate,
    P('underlay', 'Underlay', 'Underlay', 'select', {
      get: (el) => el.underlay || '',
      set: (el, v) => ({ underlay: v || null }),
      options: (c) => [{ value: '', label: 'None' }, { value: 'below', label: 'Level below' }, ...c.doc.levels().map((l) => ({ value: l.id, label: l.name }))],
    }), len('cutHeight', 'Cut Plane Height', 'Extents', { ro: templated }), len('viewDepth', 'View Depth Offset', 'Extents', { ro: templated }), cropOn, cropShow, ro('level', 'Associated Level', 'Identity Data', (el, c) => c.doc.get(el.levelId)?.name ?? '', 'text'), viewName],
  ceilingPlan: [viewScale, viewDetail, penSet, vis, len('cutHeight', 'Cut Plane Height', 'Extents', { ro: templated }), cropOn, cropShow, ro('level', 'Associated Level', 'Identity Data', (el, c) => c.doc.get(el.levelId)?.name ?? '', 'text'), viewTemplate, viewName],
  areaPlan: [
    viewScale,
    viewDetail,
    penSet,
    vis,
    len('cutHeight', 'Cut Plane Height', 'Extents', { ro: templated }),
    cropOn,
    cropShow,
    ro('scheme', 'Area Scheme', 'Identity Data', (el) => schemeLabel(el.scheme), 'text'),
    ro('level', 'Associated Level', 'Identity Data', (el, c) => c.doc.get(el.levelId)?.name ?? '', 'text'),
    viewTemplate,
    viewName,
  ],
  view3d: [
    viewStyle,
    viewDetail,
    structureDisplay,
    vis,
    shadowsP,
    lampLightP,
    daylightP,
    P('sectionBoxOn', 'Section Box', 'Extents', 'bool', { get: (el) => !!el.sectionBox, set: () => null, action: 'section-box' }),
    P('persp', 'Perspective', 'Camera', 'bool', { get: (el, c) => c.app?.vc?.cam?.persp !== false, set: () => null, action: 'toggle-persp' }),
    viewTemplate,
    viewName,
  ],
  drafting: [viewScale, viewDetail, penSet, vis, viewName],
  legend: [viewScale, viewDetail, penSet, vis, viewName],
  elevation: [viewScale, viewStyle, viewDetail, structureDisplay, penSet, vis, shadowsP, len('depth', 'Far Clip Offset', 'Extents'), viewTemplate, viewName],
  section: [viewScale, viewStyle, viewDetail, structureDisplay, penSet, vis, shadowsP, len('depth', 'Far Clip Offset', 'Extents'), viewTemplate, viewName],
  schedule: [viewName, ro('category', 'Category', 'Other', (el) => el.category, 'text'), P('fields', 'Fields', 'Other', 'button', { action: 'schedule-fields', text: 'Edit...' })],
  sheet: [
    P('number', 'Sheet Number', 'Identity Data', 'text'),
    P('name', 'Sheet Name', 'Identity Data', 'text'),
    P('drawnBy', 'Drawn By', 'Identity Data', 'text'),
    P('checkedBy', 'Checked By', 'Identity Data', 'text'),
    P('issueDate', 'Issue Date', 'Identity Data', 'text'),
    P('masterId', 'Master Layout', 'Graphics', 'select', {
      get: (el) => el.masterId || '',
      set: (el, v, c) => (v ? { masterId: v, size: c.doc.get(v)?.size || el.size } : { masterId: null }),
      options: (c) => [{ value: '', label: 'Built-in title block' }, ...c.doc.all('masterLayout').map((m) => ({ value: m.id, label: m.name }))],
    }),
    P('size', 'Sheet Size', 'Graphics', 'select', { ro: (el) => !!el.masterId, options: () => SHEET_SIZES.map((s) => ({ value: s.id, label: s.label })) }),
    P('penSet', 'Pen Set', 'Graphics', 'select', { get: (el) => el.penSet || 'color', options: () => PEN_SETS }),
  ],
};

export const SHEET_SIZES = [
  { id: 'A3', label: 'A3 (420 x 297 mm)', w: 420, h: 297 },
  { id: 'A2', label: 'A2 (594 x 420 mm)', w: 594, h: 420 },
  { id: 'A1', label: 'A1 (841 x 594 mm)', w: 841, h: 594 },
  { id: 'A0', label: 'A0 (1189 x 841 mm)', w: 1189, h: 841 },
  { id: 'ARCHC', label: 'ARCH C (24 x 18 in)', w: 609.6, h: 457.2 },
  { id: 'ARCHD', label: 'ARCH D (36 x 24 in)', w: 914.4, h: 609.6 },
  { id: 'ARCHE', label: 'ARCH E (48 x 36 in)', w: 1219.2, h: 914.4 },
  { id: 'TABLOID', label: 'Tabloid (17 x 11 in)', w: 431.8, h: 279.4 },
];

const MAT = (key, label) => P(key, label, 'Materials and Finishes', 'material');

export const TYPE_PARAMS = {
  wallType: [
    P('function', 'Function', 'Construction', 'select', {
      options: () => [
        { value: 'exterior', label: 'Exterior' },
        { value: 'interior', label: 'Interior' },
        { value: 'foundation', label: 'Foundation' },
      ],
    }),
    P('layers', 'Structure', 'Construction', 'button', { action: 'edit-layers', text: 'Edit...' }),
    ro('thick', 'Thickness', 'Construction', (t) => typeThickness(t)),
    P('mark', 'Type Mark', 'Identity Data', 'text'),
    P('description', 'Description', 'Identity Data', 'text'),
  ],
  floorType: [P('layers', 'Structure', 'Construction', 'button', { action: 'edit-layers', text: 'Edit...' }), ro('thick', 'Thickness', 'Construction', (t) => typeThickness(t)), P('mark', 'Type Mark', 'Identity Data', 'text')],
  roofType: [P('layers', 'Structure', 'Construction', 'button', { action: 'edit-layers', text: 'Edit...' }), ro('thick', 'Thickness', 'Construction', (t) => typeThickness(t)), P('mark', 'Type Mark', 'Identity Data', 'text')],
  ceilingType: [P('layers', 'Structure', 'Construction', 'button', { action: 'edit-layers', text: 'Edit...' }), len('pattern', 'Grid Spacing (0 for none)', 'Graphics'), P('mark', 'Type Mark', 'Identity Data', 'text')],
  doorType: [
    len('width', 'Width', 'Dimensions'),
    len('height', 'Height', 'Dimensions'),
    len('frameWidth', 'Frame Width', 'Dimensions'),
    len('thickness', 'Panel Thickness', 'Dimensions'),
    P('glazing', 'Glazed Panel', 'Construction', 'bool'),
    MAT('panelMaterialId', 'Panel Material'),
    MAT('frameMaterialId', 'Frame Material'),
    P('mark', 'Type Mark', 'Identity Data', 'text'),
  ],
  windowType: [len('width', 'Width', 'Dimensions'), len('height', 'Height', 'Dimensions'), len('sill', 'Default Sill Height', 'Dimensions'), len('frameWidth', 'Frame Width', 'Dimensions'), len('frameDepth', 'Frame Depth', 'Dimensions'), MAT('frameMaterialId', 'Frame Material'), P('mark', 'Type Mark', 'Identity Data', 'text')],
  columnType: [
    P('shape', 'Shape', 'Construction', 'select', {
      options: () => [
        { value: 'rect', label: 'Rectangular' },
        { value: 'round', label: 'Round' },
      ],
    }),
    len('width', 'Width (b)', 'Dimensions'),
    len('depth', 'Depth (h)', 'Dimensions'),
    MAT('materialId', 'Material'),
    P('mark', 'Type Mark', 'Identity Data', 'text'),
  ],
  beamType: [len('width', 'Width', 'Dimensions'), len('depth', 'Depth', 'Dimensions'), MAT('materialId', 'Material'), P('mark', 'Type Mark', 'Identity Data', 'text')],
  stairType: [
    len('maxRiser', 'Maximum Riser Height', 'Dimensions'),
    len('riserMin', 'Minimum Riser Height', 'Dimensions'),
    len('tread', 'Minimum Tread Depth', 'Dimensions'),
    len('treadMax', 'Maximum Tread Depth (0: none)', 'Dimensions'),
    len('width', 'Default Width', 'Dimensions'),
    // Rules on riser and tread together (stairrules.js); each applies when switched on.
    P('ruleStep', 'Step Rule: 2 × Riser + Tread', 'Rules', 'bool'),
    len('stepMin', 'Step Rule Minimum', 'Rules'),
    len('stepMax', 'Step Rule Maximum', 'Rules'),
    P('ruleSum', 'Riser + Tread Rule', 'Rules', 'bool'),
    len('sumMin', 'Riser + Tread Minimum', 'Rules'),
    len('sumMax', 'Riser + Tread Maximum', 'Rules'),
    P('ruleRatio', 'Riser / Tread Rule', 'Rules', 'bool'),
    P('ratioMin', 'Riser / Tread Minimum', 'Rules', 'number'),
    P('ratioMax', 'Riser / Tread Maximum', 'Rules', 'number'),
    P('rulePitch', 'Pitch Rule', 'Rules', 'bool'),
    P('pitchMin', 'Pitch Minimum (degrees)', 'Rules', 'number'),
    P('pitchMax', 'Pitch Maximum (degrees)', 'Rules', 'number'),
    len('thickness', 'Thickness', 'Construction'),
    P('monolithic', 'Monolithic', 'Construction', 'bool'),
    // Treads and risers from Archicad's library (its Stair and Railing components), run for each piece.
    P('treadPartId', 'Tread Component', 'Components', 'select', { options: (c) => stairPartOptions(c.doc, 'tread') }),
    P('riserPartId', 'Riser Component', 'Components', 'select', { options: (c) => stairPartOptions(c.doc, 'riser') }),
    P('structurePartId', 'Structure Component', 'Components', 'select', { options: (c) => stairPartOptions(c.doc, ['stringer', 'beam', 'cantilevered'], false) }),
    P('landingPartId', 'Landing Structure Component', 'Components', 'select', { options: (c) => stairPartOptions(c.doc, ['stringer', 'beam', 'cantilevered'], true) }),
    len('riserThickness', 'Riser Thickness', 'Components'),
    MAT('materialId', 'Material'),
  ],
  footingType: [len('width', 'Width', 'Dimensions'), len('length', 'Length', 'Dimensions'), len('thickness', 'Thickness', 'Dimensions'), MAT('materialId', 'Material'), P('mark', 'Type Mark', 'Identity Data', 'text')],
  wallFootingType: [len('width', 'Width', 'Dimensions'), len('thickness', 'Thickness', 'Dimensions'), MAT('materialId', 'Material'), P('mark', 'Type Mark', 'Identity Data', 'text')],
  trussType: [
    P('pattern', 'Pattern', 'Construction', 'select', { get: (t) => t.pattern || 'pratt', options: () => PATTERNS }),
    len('height', 'Height (or rise)', 'Dimensions'),
    P('panels', 'Panels (0 = automatic)', 'Dimensions', 'number', { get: (t) => t.panels || 0 }),
    len('chord', 'Chord Size', 'Dimensions'),
    len('web', 'Web Size', 'Dimensions'),
    MAT('materialId', 'Material'),
    P('mark', 'Type Mark', 'Identity Data', 'text'),
  ],
  wallSweepType: [
    P('profile', 'Profile', 'Construction', 'select', { get: (t) => t.profile || 'rect', options: () => Object.entries(PROFILES).map(([value, p]) => ({ value, label: p.label })) }),
    P('reveal', 'Cuts Into the Wall (Reveal)', 'Construction', 'bool', { get: (t) => !!t.reveal }),
    len('width', 'Projection (or Depth)', 'Dimensions'),
    len('height', 'Height', 'Dimensions'),
    MAT('materialId', 'Material'),
    P('mark', 'Type Mark', 'Identity Data', 'text'),
  ],
  ductType: [
    P('shape', 'Shape', 'Construction', 'select', {
      options: () => [
        { value: 'rect', label: 'Rectangular' },
        { value: 'round', label: 'Round' },
      ],
    }),
    len('width', 'Width', 'Dimensions'),
    len('height', 'Height', 'Dimensions'),
    len('diameter', 'Diameter', 'Dimensions'),
    MAT('materialId', 'Material'),
  ],
  pipeType: [len('diameter', 'Diameter', 'Dimensions'), MAT('materialId', 'Material')],
  cableTrayType: [len('width', 'Width', 'Dimensions'), len('height', 'Height', 'Dimensions'), MAT('materialId', 'Material')],
  conduitType: [len('diameter', 'Diameter', 'Dimensions'), MAT('materialId', 'Material')],
  rampType: [
    P('slopeRatio', 'Maximum Slope (1 in ...)', 'Dimensions', 'number'),
    len('width', 'Default Width', 'Dimensions'),
    len('thickness', 'Thickness', 'Construction'),
    MAT('materialId', 'Material'),
    P('mark', 'Type Mark', 'Identity Data', 'text'),
  ],
  railingType: [
    len('height', 'Rail Height', 'Dimensions'),
    len('spacing', 'Baluster Spacing', 'Dimensions'),
    len('rail', 'Rail Size', 'Dimensions'),
    P('glass', 'Glass Panels', 'Construction', 'bool'),
    // Posts, toprail and panels from Archicad's library (its Stair and Railing components), in place of the above.
    P('postPartId', 'Post Component', 'Components', 'select', { options: (c) => stairPartOptions(c.doc, 'post') }),
    len('postSpacing', 'Post Spacing', 'Components'),
    P('railPartId', 'Toprail Component', 'Components', 'select', { options: (c) => stairPartOptions(c.doc, 'rail') }),
    P('panelPartId', 'Panel Component', 'Components', 'select', { options: (c) => stairPartOptions(c.doc, 'panel') }),
    MAT('materialId', 'Material'),
  ],
  componentType: [len('width', 'Width', 'Dimensions'), len('depth', 'Depth', 'Dimensions'), len('height', 'Height', 'Dimensions'), len('elevation', 'Default Elevation', 'Dimensions'), ro('category', 'Category', 'Identity Data', (t) => t.category, 'text'), P('mark', 'Type Mark', 'Identity Data', 'text')],
};

// Every model type can carry a keynote, shown by keynote tags.
/** The Archicad stair and railing components of a kind (tread, riser, post, rail, panel) among a document's object types. */
function stairPartOptions(doc, kind, landing = null) {
  const kinds = [].concat(kind);
  const fits = (t) => kinds.includes(stairPartKind(t)) && (landing === null || isLandingPart(t) === landing);
  return [{ value: '', label: 'None' }, ...doc.all('componentType').filter(fits).map((t) => ({ value: t.id, label: t.name }))];
}

for (const k of ['wallType', 'floorType', 'roofType', 'ceilingType', 'doorType', 'windowType', 'columnType', 'beamType', 'stairType', 'rampType', 'railingType', 'componentType']) {
  TYPE_PARAMS[k].push(P('keynote', 'Keynote', 'Identity Data', 'text'));
}

const phaseOptions = (c, none) => [...(none ? [{ value: '', label: none }] : []), ...phasesInOrder(c.doc).map((p) => ({ value: p.id, label: p.name }))];
const lastPhase = (c) => phasesInOrder(c.doc).at(-1)?.id ?? '';
const PHASE_PARAMS = [
  P('phaseId', 'Phase Created', 'Phasing', 'select', { get: (el, c) => el.phaseId || lastPhase(c), options: (c) => phaseOptions(c) }),
  P('demolishedId', 'Phase Demolished', 'Phasing', 'select', { get: (el) => el.demolishedId || '', set: (el, v) => ({ demolishedId: v || null }), options: (c) => phaseOptions(c, 'None') }),
];
const VIEW_PHASE = [
  P('phaseId', 'Phase', 'Phasing', 'select', { get: (el, c) => el.phaseId || lastPhase(c), options: (c) => phaseOptions(c), ro: templated }),
  P('phaseFilter', 'Phase Filter', 'Phasing', 'select', { get: (el) => el.phaseFilter || 'all', options: (c) => phaseFilters(c.doc) ?? PHASE_FILTERS, ro: templated }),
];
const PHASED_VIEWS = new Set(['plan', 'ceilingPlan', 'areaPlan', 'view3d', 'elevation', 'section']);

// Show on Stories (plan.js): slabs, roofs, objects and the like on other stories too.
const showOnStories = P('showOnStories', 'Show On Stories', 'Constraints', 'select', { get: (el) => el.showOnStories || 'home', options: () => STORY_RULES });

// Complex profile (profiles.js) of walls, beams and columns.
const profileParam = P('profileId', 'Profile', 'Construction', 'select', {
  get: (el) => el.profileId || '',
  set: (el, v) => ({ profileId: v || null }),
  options: (c) => [{ value: '', label: 'None (from the type)' }, ...profilesFor(c.doc, c.items?.[0]?.kind).map((p) => ({ value: p.id, label: p.name }))],
});

/** The parameters of each kind of wall accessory (cladding.js). */
const WALL_ACCESSORY_PARAMS = {
  cladding: [
    P('pattern', 'Pattern', 'Construction', 'select', { get: (el) => el.pattern || 'horizontal', options: () => CLADDING_PATTERNS }),
    len('board', 'Board or Panel Width', 'Construction'),
    len('panelHeight', 'Panel Height', 'Construction'),
    len('gap', 'Joint Gap', 'Construction'),
    len('thickness', 'Thickness', 'Construction'),
    len('cavity', 'Cavity (Battens)', 'Construction'),
  ],
  moldings: [
    len('baseHeight', 'Base Molding Height', 'Construction', { get: (el) => el.baseHeight ?? 120 }),
    len('chairHeight', 'Chair Rail Height (0: none)', 'Construction', { get: (el) => el.chairHeight ?? 900 }),
    len('crownHeight', 'Crown Molding Height', 'Construction', { get: (el) => el.crownHeight ?? 90 }),
    P('wainscot', 'Wainscot Panels', 'Construction', 'bool', { get: (el) => el.wainscot !== false }),
    len('panelWidth', 'Panel Width', 'Construction', { get: (el) => el.panelWidth ?? 600 }),
  ],
  battered: [
    len('thickBottom', 'Thickness at Bottom', 'Construction', { get: (el) => el.thickBottom ?? 150 }),
    len('thickTop', 'Thickness at Top', 'Construction', { get: (el) => el.thickTop ?? 60 }),
    len('extendBelow', 'Extend Below Wall', 'Construction', { get: (el) => el.extendBelow ?? 0 }),
    len('extendAbove', 'Extend Above Wall', 'Construction', { get: (el) => el.extendAbove ?? 0 }),
  ],
  framing: [
    len('spacing', 'Stud Spacing', 'Construction', { get: (el) => el.spacing ?? 400 }),
    len('studWidth', 'Stud Width', 'Construction', { get: (el) => el.studWidth ?? 45 }),
    len('studDepth', 'Stud Depth', 'Construction', { get: (el) => el.studDepth ?? 140 }),
    len('header', 'Header Height', 'Construction', { get: (el) => el.header ?? 200 }),
    ro('lumber', 'Lumber', 'Analytical Properties', (el, c) => {
      const g = framingGeometry(c.doc, el);
      return g ? framingList(g).map((r) => `${r.count} ${r.role}${r.count === 1 ? '' : 's'} ${(r.length / 1000).toFixed(2)} m`).join(', ') : '';
    }, 'text'),
  ],
};

// Elevations read from the 1st or 2nd reference level (Archicad's Info Box option).
const REF_KINDS = new Set(['wall', 'column', 'window', 'door', 'opening']);
function refExtent(doc, el) {
  if (el.kind === 'wall' || el.kind === 'column') return verticalExtent(doc, el);
  const host = doc.get(el.hostId);
  if (!host) return null;
  const { base } = verticalExtent(doc, host);
  const { height, sill } = openingSize(doc, el);
  const z0 = base + (el.kind === 'door' ? 0 : sill);
  return { base: z0, top: z0 + height };
}
const refName = (c) => referenceLevels(c.doc.get('project'))[shownReference(c.doc.get('project')) - 1].name;
const REF_PARAMS = [
  ro('refBottom', 'Bottom to Reference Level', 'Constraints', (el, c) => {
    const e = refExtent(c.doc, el);
    return e ? heightToReference(c.doc.get('project'), e.base) : null;
  }),
  ro('refTop', 'Top to Reference Level', 'Constraints', (el, c) => {
    const e = refExtent(c.doc, el);
    return e ? heightToReference(c.doc.get('project'), e.top) : null;
  }),
  ro('refName', 'Reference Level', 'Constraints', (el, c) => refName(c), 'text'),
];

export function instanceParams(el) {
  if (VIEW[el.kind]) return PHASED_VIEWS.has(el.kind) ? [...VIEW[el.kind], ...VIEW_PHASE] : VIEW[el.kind];
  let base = INSTANCE[el.kind] || [mark, comments];
  if (el.kind === 'wallCladding') base = [...base.slice(0, 2), ...(WALL_ACCESSORY_PARAMS[el.accessory || 'cladding'] || []), ...base.slice(2)];
  if (el.kind === 'wall' || el.kind === 'beam' || el.kind === 'column') base = [...base, profileParam];
  if (STORY_KINDS.has(el.kind)) base = [...base, showOnStories];
  if (REF_KINDS.has(el.kind)) base = [...base, ...REF_PARAMS];
  return phased(el) ? [...base, ...PHASE_PARAMS] : base;
}

const WS_VIEWS = new Set(['plan', 'ceilingPlan', 'areaPlan', 'view3d', 'elevation', 'section']);

/** Workset of an element, and per-view workset settings, once worksets are on. */
/** The paint on a model element, once it has some. */
function paintParams(doc, el) {
  if (!el.paintId) return [];
  return [P('paintId', 'Painted With', 'Materials and Finishes', 'select', { options: (c) => [{ value: '', label: 'Not painted' }, ...c.doc.all('material').map((m) => ({ value: m.id, label: m.name }))], set: (e, v) => ({ paintId: v || null }) })];
}

/** The layer of an element, and the layer combination of a view (layers.js). */
function layerParams(doc, el) {
  if (WS_VIEWS.has(el.kind))
    return [
      P('layerComboId', 'Layer Combination', 'Graphics', 'select', {
        get: (v) => v.layerComboId || '',
        set: (v, val) => ({ layerComboId: val || null }),
        options: (c) => [{ value: '', label: 'Custom (layer settings)' }, ...c.doc.all('layerCombo').map((x) => ({ value: x.id, label: x.name }))],
      }),
    ];
  if (!layered(doc, el)) return [];
  return [P('layerId', 'Layer', 'Identity Data', 'select', { get: (e, c) => layerIdOf(c.doc, e) ?? '', options: (c) => layersInOrder(c.doc).map((l) => ({ value: l.id, label: l.name })) })];
}

/** The item of each classification system an element belongs to (classify.js). */
function classParams(doc, el) {
  if (!classifiable(doc, el)) return [];
  return doc.all('classSystem').map((sys) =>
    P(`class:${sys.id}`, `Classification${doc.count('classSystem') > 1 ? ` (${sys.name})` : ''}`, 'Identity Data', 'select', {
      get: (e, c) => {
        const own = e.classes?.[sys.id];
        return own !== undefined ? own || '-' : '';
      },
      set: (e, v) => {
        const { [sys.id]: _old, ...rest } = e.classes || {};
        return { classes: v === '' ? rest : { ...rest, [sys.id]: v === '-' ? '' : v } };
      },
      options: (c) => {
        const auto = autoClass(c.doc, c.items?.[0] || el, c.doc.get(sys.id));
        return [
          { value: '', label: `Automatic${auto ? `: ${classLabel(auto)}` : ''}` },
          { value: '-', label: 'Unclassified' },
          ...classTree(c.doc.get(sys.id)).map(({ item, depth }) => ({ value: item.code, label: `${'\u2003'.repeat(depth)}${classLabel(item)}` })),
        ];
      },
    }),
  );
}

/** A GDL object's parameters (gdlobject.js), set per placed object over its type's values. */
/** A lighting fixture's light (lamps.js): on/off, flux, colour temperature, reach and emitter height. */
function electricalParams(doc, el) {
  if (!['lighting', 'electricalFixtures', 'electricalEquipment'].includes(categoryOf(el, doc))) return [];
  return [P('electricalLoad', 'Electrical Load (W)', 'Electrical', 'number', { get: (e) => powerOf(doc, e) })];
}

function lampParams(doc, el) {
  if (!isLamp(doc, el)) return [];
  const off = (e) => e.lightOn === false;
  return [
    P('lightOn', 'Light On', 'Light', 'bool', { get: (e) => e.lightOn !== false }),
    P('lightLumens', 'Luminous Flux (lm)', 'Light', 'number', { get: (e) => +e.lightLumens || LAMP_DEFAULTS.lumens, ro: off }),
    P('lightKelvin', 'Colour Temperature (K)', 'Light', 'number', { get: (e) => +e.lightKelvin || LAMP_DEFAULTS.kelvin, ro: off }),
    len('lightRange', 'Reach (0 = from the flux)', 'Light', { get: (e) => +e.lightRange || 0, ro: off }),
  ];
}

function gdlParams(doc, el) {
  if (el.kind !== 'component') return [];
  const type = doc.get(el.typeId);
  if (type?.family !== 'gdl') return [];
  const KIND = { length: 'length', number: 'number', integer: 'number', angle: 'angle', boolean: 'bool', string: 'text' };
  return (type.gdl?.params || []).map((p) => {
    const get = (e) => e.gdlValues?.[p.name] ?? p.value;
    // A change runs the parameter script for it, as in Archicad (what follows the changed parameter follows it).
    const set = (e, v) => ({ gdlValues: applyGdlChange(type, e.gdlValues || {}, { [p.name]: p.kind === 'boolean' ? !!v : p.kind === 'string' || p.kind === 'material' ? v : +v }) });
    if (p.kind === 'material') return P(`gdl:${p.name}`, p.label || p.name, 'Parameters', 'select', { get, set, options: (c) => c.doc.all('material').map((m) => ({ value: m.id, label: m.name })) });
    return P(`gdl:${p.name}`, p.label || p.name, 'Parameters', KIND[p.kind] || 'text', { get, set });
  });
}

/** What an element opened from an IFC file brought with it: its GlobalId and property sets, read-only. */
function ifcParams(el) {
  if (!el.ifcGuid && !el.ifcProps) return [];
  const out = [];
  if (el.ifcGuid) out.push(ro('ifc:guid', 'IFC GlobalId', 'IFC', () => el.ifcGuid, 'text'));
  for (const [k, v] of Object.entries(el.ifcProps || {})) out.push(ro(`ifc:${k}`, k, 'IFC', (e) => {
    const x = e.ifcProps?.[k];
    return typeof x === 'boolean' ? (x ? 'Yes' : 'No') : x == null ? '' : String(x);
  }, 'text'));
  return out;
}

export function worksetParams(doc, el) {
  const out = [...layerParams(doc, el), ...classParams(doc, el), ...optionParams(doc, el), ...scopeParams(doc, el), ...paintParams(doc, el), ...electricalParams(doc, el), ...lampParams(doc, el), ...gdlParams(doc, el), ...ifcParams(el)];
  if (!worksharingOn(doc)) return out;
  if (WS_VIEWS.has(el.kind))
    return [
      ...out,
      P('worksets', 'Worksets', 'Graphics', 'button', { action: 'viewWorksets', text: 'Edit...' }),
      P('wsDisplay', 'Worksharing Display', 'Graphics', 'select', {
        get: (v) => v.wsDisplay || 'off',
        options: () => [
          { value: 'off', label: 'Off' },
          { value: 'worksets', label: 'Colour by workset' },
        ],
      }),
    ];
  if (!worksetable(doc, el)) return out;
  return [...out, P('worksetId', 'Workset', 'Identity Data', 'select', { get: (e, c) => worksetOf(c.doc, e)?.id ?? '', options: (c) => worksets(c.doc).map((w) => ({ value: w.id, label: w.name })) })];
}

/** The scope box a plan or 3D view takes its crop region or section box from. */
function scopeParams(doc, el) {
  if (!doc.count('scopeBox') || !['plan', 'ceilingPlan', 'areaPlan', 'view3d'].includes(el.kind)) return [];
  return [P('scopeBoxId', 'Scope Box', 'Extents', 'select', { get: (v) => v.scopeBoxId || '', set: (v, val) => ({ scopeBoxId: val || null }), options: (c) => [{ value: '', label: 'None' }, ...c.doc.all('scopeBox').map((s) => ({ value: s.id, label: s.name }))] })];
}

/** Design option of an element, and the options a view shows, once there are option sets. */
function optionParams(doc, el) {
  if (!doc.count('optionSet')) return [];
  if (WS_VIEWS.has(el.kind)) return [P('designOptions', 'Design Options', 'Graphics', 'button', { action: 'viewOptions', text: 'Edit...' })];
  if (!optionable(doc, el)) return [];
  return [ro('optionId', 'Design Option', 'Identity Data', (e, c) => optionLabel(c.doc, e.optionId), 'text')];
}

export function paramValue(d, el, ctx) {
  if (d.get) return d.get(el, ctx);
  return el[d.key];
}

/** Patch for setting a parameter (null means the descriptor handles it with an action). */
/** A window's height at its left (side -1) or right (1) jamb: from its outline when it has one. */
function headAt(el, c, side) {
  const { width, height } = openingSize(c.doc, el);
  if (!Array.isArray(el.outline) || el.outline.length < 3) return height;
  const x = (side * width) / 2;
  const ys = el.outline.filter((p) => Math.abs(p[0] - x) < 1).map((p) => p[1]);
  return ys.length ? Math.max(...ys) : height;
}

/** The patch giving a window this height at one jamb, keeping the other: a trapezoid, or a rectangle when equal. */
function headPatch(el, c, side, v) {
  if (!(v > 0)) return null;
  const { width } = openingSize(c.doc, el);
  const left = side < 0 ? v : headAt(el, c, -1);
  const right = side > 0 ? v : headAt(el, c, 1);
  if (Math.abs(left - right) < 1) return { outline: null, height: Math.round(left) };
  return { height: Math.round(Math.max(left, right)), outline: [[-width / 2, 0], [width / 2, 0], [width / 2, Math.round(right)], [-width / 2, Math.round(left)]] };
}

export function paramPatch(d, el, value, ctx) {
  if (d.set) return d.set(el, value, ctx);
  if (d.type === 'number') return { [d.key]: +value };
  if (d.type === 'select' && typeof paramValue(d, el, ctx) === 'number') return { [d.key]: +value };
  return { [d.key]: value };
}

export function isReadOnly(d, el, ctx) {
  return d.type === 'readonly' || (typeof d.ro === 'function' && d.ro(el, ctx));
}

function wallHeight(el, c) {
  const { base, top } = verticalExtent(c.doc, el);
  return top - base;
}

function slabArea(el) {
  const outer = polyArea(el.boundary || []);
  return outer - (el.holes || []).reduce((s, h) => s + polyArea(h), 0);
}

/** Whether a stair meets its type's rules, in words. */
export function stairRulesStatus(doc, el) {
  const lay = stairLayout(doc, el);
  const broken = checkStair(stairRules(doc.get(el.typeId)), lay.riserHeight, lay.tread);
  return broken.length ? `Breaks: ${broken.map((b) => b.label.toLowerCase()).join(', ')}` : 'Met';
}

function pathLength(p) {
  let s = 0;
  for (let i = 0; i + 1 < p.length; i++) s += dist(p[i], p[i + 1]);
  return s;
}

export function describe(doc, el) {
  if (!el) return '';
  if (el.kind === 'room') return `Room ${el.number || ''} ${el.name || ''}`.trim();
  if (el.kind === 'area') return `Area ${el.name || ''}`.trim();
  if (el.kind === 'level' || el.kind === 'grid' || (el.kind === 'refPlane' && el.name)) return `${KIND_LABEL[el.kind]} ${el.name}`;
  const t = doc.get(el.typeId);
  const base = KIND_LABEL[el.kind] || el.kind;
  return t ? `${base}: ${t.name}` : base;
}

