/**
 * Node and edge editing of polygon elements (the Pet palette's Insert and
 * Delete Node, Offset Edge and Offset All Edges). Edge i runs from node i to
 * node i + 1; data kept per edge (roof slopes and overhangs) stays with its
 * edge.
 */
import { sub, dot, norm, lineIntersect, signedArea, offsetPolygon } from './geom.js';

/** Arrays an element keeps per boundary edge. */
const PER_EDGE = ['slopes', 'overhangs'];

/** Patch inserting node p after node i, splitting edge i in two halves that keep its data. */
export function insertNode(el, i, p) {
  const b = el.boundary;
  if (!b || i < 0 || i >= b.length) return null;
  const patch = { boundary: [...b.slice(0, i + 1), p, ...b.slice(i + 1)] };
  for (const k of PER_EDGE) if (Array.isArray(el[k]) && el[k].length === b.length) patch[k] = [...el[k].slice(0, i + 1), el[k][i], ...el[k].slice(i + 1)];
  // Per-node heights (morphs): the new node takes the mean of its neighbours.
  if (Array.isArray(el.heights) && el.heights.length === b.length) {
    const j = (i + 1) % b.length;
    patch.heights = [...el.heights.slice(0, i + 1), (+el.heights[i] + +el.heights[j]) / 2, ...el.heights.slice(i + 1)];
  }
  return patch;
}

/**
 * Patch deleting node i, or null when the polygon would have fewer than
 * three nodes. The two edges at the node become one with the data of the
 * edge that led into it.
 */
export function deleteNode(el, i) {
  const b = el.boundary;
  if (!b || b.length <= 3 || i < 0 || i >= b.length) return null;
  const patch = { boundary: b.filter((_, j) => j !== i) };
  for (const k of PER_EDGE) if (Array.isArray(el[k]) && el[k].length === b.length) patch[k] = el[k].filter((_, j) => j !== i);
  if (Array.isArray(el.heights) && el.heights.length === b.length) patch.heights = el.heights.filter((_, j) => j !== i);
  return patch;
}

/** Midpoint of edge i. */
export function edgeMid(el, i) {
  const b = el.boundary;
  const a = b[i];
  const c = b[(i + 1) % b.length];
  return [(a[0] + c[0]) / 2, (a[1] + c[1]) / 2];
}

/** Unit outward normal of edge i (outward whatever the winding). */
export function edgeNormal(boundary, i) {
  const a = boundary[i];
  const b = boundary[(i + 1) % boundary.length];
  const d = norm(sub(b, a));
  // Right of travel is outward for a counterclockwise polygon.
  return signedArea(boundary) >= 0 ? [d[1], -d[0]] : [-d[1], d[0]];
}

/** Signed distance of p from edge i's line, positive outward. */
export function edgeDistance(boundary, i, p) {
  return dot(sub(p, boundary[i]), edgeNormal(boundary, i));
}

/**
 * Boundary with edge i moved outward by d, parallel to itself. Its nodes
 * slide along the neighbouring edges (or straight out where a neighbour is
 * parallel), so the other edges keep their directions.
 */
export function offsetEdge(boundary, i, d) {
  const n = boundary.length;
  const j = (i + 1) % n;
  const o = edgeNormal(boundary, i);
  const a = [boundary[i][0] + o[0] * d, boundary[i][1] + o[1] * d];
  const b = [boundary[j][0] + o[0] * d, boundary[j][1] + o[1] * d];
  const dir = sub(b, a);
  const prev = boundary[(i - 1 + n) % n];
  const next = boundary[(j + 1) % n];
  const pa = lineIntersect(a, dir, prev, sub(boundary[i], prev));
  const pb = lineIntersect(a, dir, boundary[j], sub(next, boundary[j]));
  const out = boundary.slice();
  out[i] = pa ? pa.point : a;
  out[j] = pb ? pb.point : b;
  return out;
}

/** Boundary with every edge moved outward by d (negative shrinks), nodes in their order. */
export function offsetAllEdges(boundary, d) {
  const out = offsetPolygon(boundary, d);
  return signedArea(boundary) < 0 ? out.slice().reverse() : out;
}
