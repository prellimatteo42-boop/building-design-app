/**
 * Standard steel sections for Import Standard Steel Profile: European series
 * (EN 10365 for I, H and U sections, EN 10210 and 10219 for hollow sections,
 * EN 10056 for angles), dimensions in mm. UPN flanges are drawn at their mean
 * thickness; their taper is left out.
 */
const I = (rows) => rows.map(([n, h, b, tw, tf, r]) => ({ size: String(n), h, b, tw, tf, r }));

export const STEEL_SERIES = [
  { value: 'IPE', label: 'IPE', shape: 'I', rows: I([[80, 80, 46, 3.8, 5.2, 5], [100, 100, 55, 4.1, 5.7, 7], [120, 120, 64, 4.4, 6.3, 7], [140, 140, 73, 4.7, 6.9, 7], [160, 160, 82, 5, 7.4, 9], [180, 180, 91, 5.3, 8, 9], [200, 200, 100, 5.6, 8.5, 12], [220, 220, 110, 5.9, 9.2, 12], [240, 240, 120, 6.2, 9.8, 15], [270, 270, 135, 6.6, 10.2, 15], [300, 300, 150, 7.1, 10.7, 15], [330, 330, 160, 7.5, 11.5, 18], [360, 360, 170, 8, 12.7, 18], [400, 400, 180, 8.6, 13.5, 21], [450, 450, 190, 9.4, 14.6, 21], [500, 500, 200, 10.2, 16, 21], [550, 550, 210, 11.1, 17.2, 24], [600, 600, 220, 12, 19, 24]]) },
  { value: 'HEA', label: 'HEA', shape: 'I', rows: I([[100, 96, 100, 5, 8, 12], [120, 114, 120, 5, 8, 12], [140, 133, 140, 5.5, 8.5, 12], [160, 152, 160, 6, 9, 15], [180, 171, 180, 6, 9.5, 15], [200, 190, 200, 6.5, 10, 18], [220, 210, 220, 7, 11, 18], [240, 230, 240, 7.5, 12, 21], [260, 250, 260, 7.5, 12.5, 24], [280, 270, 280, 8, 13, 24], [300, 290, 300, 8.5, 14, 27], [320, 310, 300, 9, 15.5, 27], [340, 330, 300, 9.5, 16.5, 27], [360, 350, 300, 10, 17.5, 27], [400, 390, 300, 11, 19, 27], [450, 440, 300, 11.5, 21, 27], [500, 490, 300, 12, 23, 27], [550, 540, 300, 12.5, 24, 27], [600, 590, 300, 13, 25, 27], [650, 640, 300, 13.5, 26, 27], [700, 690, 300, 14.5, 27, 27], [800, 790, 300, 15, 28, 30], [900, 890, 300, 16, 30, 30], [1000, 990, 300, 16.5, 31, 30]]) },
  { value: 'HEB', label: 'HEB', shape: 'I', rows: I([[100, 100, 100, 6, 10, 12], [120, 120, 120, 6.5, 11, 12], [140, 140, 140, 7, 12, 12], [160, 160, 160, 8, 13, 15], [180, 180, 180, 8.5, 14, 15], [200, 200, 200, 9, 15, 18], [220, 220, 220, 9.5, 16, 18], [240, 240, 240, 10, 17, 21], [260, 260, 260, 10, 17.5, 24], [280, 280, 280, 10.5, 18, 24], [300, 300, 300, 11, 19, 27], [320, 320, 300, 11.5, 20.5, 27], [340, 340, 300, 12, 21.5, 27], [360, 360, 300, 12.5, 22.5, 27], [400, 400, 300, 13.5, 24, 27], [450, 450, 300, 14, 26, 27], [500, 500, 300, 14.5, 28, 27], [550, 550, 300, 15, 29, 27], [600, 600, 300, 15.5, 30, 27], [650, 650, 300, 16, 31, 27], [700, 700, 300, 17, 32, 27], [800, 800, 300, 17.5, 33, 30], [900, 900, 300, 18.5, 35, 30], [1000, 1000, 300, 19, 36, 30]]) },
  { value: 'HEM', label: 'HEM', shape: 'I', rows: I([[100, 120, 106, 12, 20, 12], [120, 140, 126, 12.5, 21, 12], [140, 160, 146, 13, 22, 12], [160, 180, 166, 14, 23, 15], [180, 200, 186, 14.5, 24, 15], [200, 220, 206, 15, 25, 18], [220, 240, 226, 15.5, 26, 18], [240, 270, 248, 18, 32, 21], [260, 290, 268, 18, 32.5, 24], [280, 310, 288, 18.5, 33, 24], [300, 340, 310, 21, 39, 27]]) },
  { value: 'UPN', label: 'UPN', shape: 'U', rows: I([[80, 80, 45, 6, 8, 8], [100, 100, 50, 6, 8.5, 8.5], [120, 120, 55, 7, 9, 9], [140, 140, 60, 7, 10, 10], [160, 160, 65, 7.5, 10.5, 10.5], [180, 180, 70, 8, 11, 11], [200, 200, 75, 8.5, 11.5, 11.5], [220, 220, 80, 9, 12.5, 12.5], [240, 240, 85, 9.5, 13, 13], [260, 260, 90, 10, 14, 14], [280, 280, 95, 10, 15, 15], [300, 300, 100, 10, 16, 16]]) },
  { value: 'L', label: 'L equal angle', shape: 'L', rows: [[40, 4], [50, 5], [60, 6], [70, 7], [80, 8], [90, 9], [100, 10], [120, 12], [150, 15], [200, 20]].map(([a, t]) => ({ size: `${a}x${a}x${t}`, a, t })) },
  { value: 'SHS', label: 'SHS square hollow', shape: 'R', rows: [[40, 3], [50, 4], [60, 4], [80, 5], [100, 5], [120, 6], [150, 8], [200, 10], [250, 10], [300, 12]].map(([b, t]) => ({ size: `${b}x${b}x${t}`, h: b, b, t })) },
  { value: 'RHS', label: 'RHS rectangular hollow', shape: 'R', rows: [[60, 40, 4], [80, 40, 4], [100, 50, 5], [120, 60, 5], [150, 100, 6], [200, 100, 6], [250, 150, 8], [300, 200, 10], [400, 200, 12]].map(([h, b, t]) => ({ size: `${h}x${b}x${t}`, h, b, t })) },
  { value: 'CHS', label: 'CHS circular hollow', shape: 'C', rows: [[48.3, 3.2], [60.3, 4], [76.1, 4], [88.9, 5], [114.3, 5], [139.7, 6], [168.3, 6.3], [219.1, 8], [273, 10], [323.9, 10], [406.4, 12]].map(([d, t]) => ({ size: `${d}x${t}`, d, t })) },
];

const rect = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
const circle = (r, n = 40) => Array.from({ length: n }, (_, i) => [r * Math.cos((2 * Math.PI * i) / n), r * Math.sin((2 * Math.PI * i) / n)]);

/** A quarter circle of radius r about c from angle a0, going `sweep` radians, 4 chords. */
const fillet = (c, r, a0, sweep) => Array.from({ length: 5 }, (_, i) => [c[0] + r * Math.cos(a0 + (sweep * i) / 4), c[1] + r * Math.sin(a0 + (sweep * i) / 4)]);

/** I section with root radii, bottom at y = 0, centred on x = 0, counterclockwise. */
function iPoly({ h, b, tw, tf, r }) {
  const x = b / 2;
  const w = tw / 2;
  const Q = Math.PI / 2;
  return [[-x, 0], [x, 0], [x, tf], ...fillet([w + r, tf + r], r, -Q, -Q), ...fillet([w + r, h - tf - r], r, Math.PI, -Q), [x, h - tf], [x, h], [-x, h], [-x, h - tf], ...fillet([-w - r, h - tf - r], r, Q, -Q), ...fillet([-w - r, tf + r], r, 0, -Q), [-x, tf]];
}

/** Channel with its web on x = 0, flanges towards +x. */
function uPoly({ h, b, tw, tf, r }) {
  const Q = Math.PI / 2;
  return [[0, 0], [b, 0], [b, tf], ...fillet([tw + r, tf + r], r, -Q, -Q), ...fillet([tw + r, h - tf - r], r, Math.PI, -Q), [b, h - tf], [b, h], [0, h]];
}

const lPoly = ({ a, t }) => [[0, 0], [a, 0], [a, t], [t, t], [t, a], [0, a]];

/** The polygon, holes and height of a section. */
function sectionOf(series, row) {
  if (series.shape === 'I') return { poly: iPoly(row), holes: [], y: [0, row.h] };
  if (series.shape === 'U') return { poly: uPoly(row), holes: [], y: [0, row.h] };
  if (series.shape === 'L') return { poly: lPoly(row), holes: [], y: [0, row.a] };
  if (series.shape === 'R') return { poly: rect(-row.b / 2, 0, row.b / 2, row.h), holes: [rect(-row.b / 2 + row.t, row.t, row.b / 2 - row.t, row.h - row.t).reverse()], y: [0, row.h] };
  const R = row.d / 2;
  return { poly: circle(R).map(([x, y]) => [x, y + R]), holes: [circle(R - row.t).map(([x, y]) => [x, y + R]).reverse()], y: [0, row.d] };
}

/** A profile (not yet added) for a section of a series, for beams or columns (columns are centred on their point). */
export function steelProfile(seriesValue, size, use = 'beam', materialId = 'mat-steel') {
  const series = STEEL_SERIES.find((s) => s.value === seriesValue);
  const row = series?.rows.find((r) => r.size === String(size));
  if (!row) return null;
  const s = sectionOf(series, row);
  const shift = use === 'column' ? -(s.y[0] + s.y[1]) / 2 : 0;
  const move = (loop) => loop.map(([x, y]) => [Math.round(x * 100) / 100, Math.round((y + shift) * 100) / 100]);
  return { kind: 'profile', name: `${series.value} ${size}`, use, shapes: [{ poly: move(s.poly), holes: s.holes.map(move), materialId }] };
}
