/**
 * Surface hatches in elevations (Archicad's vectorial hatching of surfaces): on the faces turned to the viewer whose
 * material has a hatch, its pattern's lines (tiles in courses, seams of a metal roof, diagonals, a grid) clipped to the
 * face, as 3D segments the hidden line drawing keeps only where they are seen.
 */
/** Hatch of a material's surface: its own setting, else one that suits roofing. */
const DEFAULT_HATCH = { 'mat-roofing': 'tiles', 'mat-roof-metal': 'seams' };
const PATTERNS = {
  tiles: [{ angle: 0, step: 250 }],
  seams: [{ angle: Math.PI / 2, step: 500 }],
  diag: [{ angle: Math.PI / 4, step: 300 }],
  grid: [{ angle: 0, step: 300 }, { angle: Math.PI / 2, step: 300 }],
  brick: [{ angle: 0, step: 75 }],
};

/** The hatch of an element's outside surface (its type's first layer), or null. */
export function surfaceHatchOf(doc, el) {
  const type = doc.get(el.typeId);
  const id = el.materialId || type?.layers?.[0]?.materialId || type?.materialId;
  if (!id) return null;
  const mat = doc.get(id);
  const h = mat?.surfaceHatch ?? DEFAULT_HATCH[id];
  return h && h !== 'none' && PATTERNS[h] ? h : null;
}

/** Lines of a pattern across a convex polygon (view coordinates, mm), clipped to it. */
function patternLines(poly, pattern) {
  const out = [];
  for (const { angle, step } of PATTERNS[pattern] || []) {
    const d = [Math.cos(angle), Math.sin(angle)];
    const n = [-d[1], d[0]];
    const ns = poly.map((p) => p[0] * n[0] + p[1] * n[1]);
    const lo = Math.ceil(Math.min(...ns) / step) * step;
    const hi = Math.max(...ns);
    for (let c = lo; c <= hi; c += step) {
      // Where the line n·p = c crosses the polygon's edges.
      const hits = [];
      for (let i = 0; i < poly.length; i++) {
        const a = poly[i];
        const b = poly[(i + 1) % poly.length];
        const fa = a[0] * n[0] + a[1] * n[1] - c;
        const fb = b[0] * n[0] + b[1] * n[1] - c;
        if ((fa < 0) === (fb < 0) || fa === fb) continue;
        const t = fa / (fa - fb);
        hits.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
      }
      if (hits.length >= 2) {
        hits.sort((p, q) => p[0] * d[0] + p[1] * d[1] - (q[0] * d[0] + q[1] * d[1]));
        out.push([hits[0], hits.at(-1)]);
      }
    }
  }
  return out;
}

/**
 * The hatch lines of an elevation as 3D segments on the surfaces they lie on ([x, y, z] pairs, flat), for the hidden
 * line drawing to keep where they are seen: elements = [{ mesh, hatch, up }] (up: only faces turned upwards, a roof's
 * covering and not its ends or soffit); the pattern is laid out in the view's
 * plane (u along, z up) and lifted back onto each face. Null over maxTris hatched faces.
 */
export function hatchSegments(frame, elements, { maxTris = 60000 } = {}) {
  const L = frame.look || [0, 1];
  const R = frame.right || [1, 0];
  const O = frame.origin || [0, 0];
  const ro = R[0] * O[0] + R[1] * O[1];
  const out = [];
  let n = 0;
  for (const { mesh, hatch, up } of elements) {
    if (!hatch) continue;
    const P = mesh?.pos;
    if (!P) continue;
    for (let t = 0; t < P.length; t += 9) {
      const pts = [0, 1, 2].map((k) => [P[t + 3 * k], P[t + 3 * k + 1], P[t + 3 * k + 2]]);
      const e1 = [pts[1][0] - pts[0][0], pts[1][1] - pts[0][1], pts[1][2] - pts[0][2]];
      const e2 = [pts[2][0] - pts[0][0], pts[2][1] - pts[0][1], pts[2][2] - pts[0][2]];
      const nx = e1[1] * e2[2] - e1[2] * e2[1];
      const ny = e1[2] * e2[0] - e1[0] * e2[2];
      const nl = Math.hypot(nx, ny, e1[0] * e2[1] - e1[1] * e2[0]) || 1;
      // Only faces turned to the viewer (and up, for a roof's covering).
      if ((nx * L[0] + ny * L[1]) / nl > -0.05) continue;
      if (up && (e1[0] * e2[1] - e1[1] * e2[0]) / nl < 0.2) continue;
      if (++n > maxTris) return null;
      const v = pts.map((p) => [R[0] * p[0] + R[1] * p[1] - ro, p[2]]);
      const det = (v[1][0] - v[0][0]) * (v[2][1] - v[0][1]) - (v[1][1] - v[0][1]) * (v[2][0] - v[0][0]);
      if (Math.abs(det) < 1) continue;
      // Back from the view plane to the face: barycentric weights of a view point.
      const lift = (q) => {
        const w1 = ((q[0] - v[0][0]) * (v[2][1] - v[0][1]) - (q[1] - v[0][1]) * (v[2][0] - v[0][0])) / det;
        const w2 = ((v[1][0] - v[0][0]) * (q[1] - v[0][1]) - (v[1][1] - v[0][1]) * (q[0] - v[0][0])) / det;
        const w0 = 1 - w1 - w2;
        return [0, 1, 2].map((k) => w0 * pts[0][k] + w1 * pts[1][k] + w2 * pts[2][k]);
      };
      for (const [a, b] of patternLines(v, hatch)) out.push(...lift(a), ...lift(b));
    }
  }
  return new Float32Array(out);
}
