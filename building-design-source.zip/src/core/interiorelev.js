/**
 * Interior elevations, as in Archicad: one elevation view per wall of a
 * room, looking at it from inside, cropped to the room across (cropU) and
 * between its level and the next (cropZ). Their markers show only on the
 * room's own plan.
 */
import { add, sub, scale, dot, norm, perp, len, ensureCCW } from './geom.js';
import { VIEW_DEFAULTS } from './template.js';

const COMPASS = ['East', 'North', 'West', 'South'];

/** Elevation views (not yet added) for a room whose outline is region.outer. */
export function interiorElevations(doc, room, region, viewScale = 50) {
  const outer = ensureCCW(region.outer);
  const level = doc.get(room.levelId);
  const z0 = +level?.elevation || 0;
  const z1 = doc.levelAbove(room.levelId)?.elevation ?? z0 + (+room.upperOffset || 3000);
  const base = `${room.name || 'Room'}${room.number ? ` ${room.number}` : ''}`;
  const out = [];
  const used = new Map();
  for (let i = 0; i < outer.length; i++) {
    const a = outer[i];
    const b = outer[(i + 1) % outer.length];
    const length = len(sub(b, a));
    if (length < 600) continue;
    const dir = norm(sub(b, a));
    // Inside a counterclockwise outline is to the left of each edge.
    const inward = perp(dir);
    const reach = Math.max(...outer.map((p) => dot(sub(p, a), inward)));
    const d = Math.min(1000, reach / 2);
    const mid = scale(add(a, b), 0.5);
    const origin = add(mid, scale(inward, d));
    const look = [-inward[0], -inward[1]];
    const right = [look[1], -look[0]];
    const us = [dot(sub(a, origin), right), dot(sub(b, origin), right)];
    const angle = Math.atan2(look[1], look[0]);
    const compass = COMPASS[((Math.round(angle / (Math.PI / 2)) % 4) + 4) % 4];
    const n = (used.get(compass) || 0) + 1;
    used.set(compass, n);
    out.push({
      kind: 'elevation',
      name: `${base} - ${compass}${n > 1 ? ` ${n}` : ''}`,
      origin,
      look: angle,
      scale: viewScale,
      width: length,
      ...VIEW_DEFAULTS.elevation,
      // Past the wall surface, not through the wall.
      depth: d + 250,
      cropU: [Math.min(...us) - 20, Math.max(...us) + 20],
      cropZ: [z0 - 10, z1 + 10],
      levelId: room.levelId,
      interiorOf: room.id,
    });
  }
  return out;
}
