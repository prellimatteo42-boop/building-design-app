/**
 * Straightening a photo of a plan taken at an angle: the sheet of paper is
 * the largest bright area of the photo; its four corners are found from
 * its outline, and the photo is mapped through the perspective that takes
 * them to a rectangle as long and wide as the sheet's sides.
 */
import { otsu, maskLoops } from './recognizeimage.js';
import { convexHull, signedArea, pointInPolygon } from './geom.js';

/** The homography taking four points src to four points dst (3x3, row-major). */
export function homography(src, dst) {
  // Solve the 8x8 system for h11..h32 (h33 = 1).
  const A = [];
  const b = [];
  for (let i = 0; i < 4; i++) {
    const [x, y] = src[i];
    const [u, v] = dst[i];
    A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]);
    b.push(u);
    A.push([0, 0, 0, x, y, 1, -v * x, -v * y]);
    b.push(v);
  }
  const h = solve(A, b);
  return [h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], 1];
}

function solve(A, b) {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    [M[c], M[p]] = [M[p], M[c]];
    const d = M[c][c] || 1e-12;
    for (let k = c; k <= n; k++) M[c][k] /= d;
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = M[r][c];
      for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  return M.map((row) => row[n]);
}

export const applyH = (H, p) => {
  const w = H[6] * p[0] + H[7] * p[1] + H[8];
  return [(H[0] * p[0] + H[1] * p[1] + H[2]) / w, (H[3] * p[0] + H[4] * p[1] + H[5]) / w];
};

/**
 * The four corners of the sheet in a grey photo (top left, top right,
 * bottom right, bottom left, in pixels), or null when no sheet stands out.
 */
export function sheetCorners({ gray, w, h }) {
  const level = otsu(gray);
  const bright = new Uint8Array(w * h);
  for (let i = 0; i < w * h; i++) bright[i] = gray[i] > level ? 1 : 0;
  // The largest bright region.
  const label = new Int32Array(w * h).fill(-1);
  let best = null;
  const stack = [];
  for (let i0 = 0, n = 0; i0 < w * h; i0++) {
    if (!bright[i0] || label[i0] >= 0) continue;
    const cells = [];
    label[i0] = n;
    stack.push(i0);
    while (stack.length) {
      const i = stack.pop();
      cells.push(i);
      const x = i % w;
      for (const j of [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, i - w, i + w])
        if (j >= 0 && j < w * h && bright[j] && label[j] < 0) {
          label[j] = n;
          stack.push(j);
        }
    }
    if (!best || cells.length > best.length) best = cells;
    n++;
  }
  if (!best || best.length < 0.1 * w * h) return null;
  // Its outline's hull, and the four hull points furthest towards the four diagonal directions.
  const mask = new Uint8Array(w * h);
  for (const i of best) mask[i] = 1;
  const loops = maskLoops(mask, w, h, 2);
  const outer = loops.reduce((a, l) => (Math.abs(signedArea(l)) > Math.abs(signedArea(a || [])) ? l : a), null);
  if (!outer) return null;
  const hull = convexHull(outer);
  const pick = (fx, fy) => hull.reduce((a, p) => (fx * p[0] + fy * p[1] > fx * a[0] + fy * a[1] ? p : a));
  const corners = [pick(-1, -1), pick(1, -1), pick(1, 1), pick(-1, 1)];
  // A sheet, not a sliver: the quad covers most of the hull.
  const quad = Math.abs(signedArea(corners));
  if (quad < 0.8 * Math.abs(signedArea(hull))) return null;
  // A photo: around the sheet lies the table, darker than paper. White all round is a plan's own room.
  let out = 0;
  let lit = 0;
  for (let y = 0; y < h; y += 2)
    for (let x = 0; x < w; x += 2) {
      if (pointInPolygon([x + 0.5, y + 0.5], corners)) continue;
      out++;
      if (bright[y * w + x]) lit++;
    }
  if (out && lit > 0.5 * out) return null;
  return corners;
}

/**
 * Straighten an RGBA photo: corners [tl, tr, br, bl] in its pixels (found
 * when not given). Returns { data, w, h, corners } of the straightened sheet,
 * as wide as the photo's longer top/bottom side.
 */
export function rectifyPhoto({ data, w, h }, corners = null) {
  if (!corners) {
    const gray = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) gray[i] = (data[4 * i] * 0.299 + data[4 * i + 1] * 0.587 + data[4 * i + 2] * 0.114) | 0;
    corners = sheetCorners({ gray, w, h });
    if (!corners) return null;
  }
  const d = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]);
  const W = Math.round(Math.max(d(corners[0], corners[1]), d(corners[3], corners[2])));
  const H = Math.round(Math.max(d(corners[0], corners[3]), d(corners[1], corners[2])));
  // From the straightened sheet back into the photo, sampled bilinearly.
  const back = homography([[0, 0], [W, 0], [W, H], [0, H]], corners);
  const out = new Uint8ClampedArray(W * H * 4);
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      const [sx, sy] = applyH(back, [x + 0.5, y + 0.5]);
      const x0 = Math.floor(sx - 0.5);
      const y0 = Math.floor(sy - 0.5);
      const fx = sx - 0.5 - x0;
      const fy = sy - 0.5 - y0;
      const o = (y * W + x) * 4;
      for (let k = 0; k < 4; k++) {
        const px = (xx, yy) => data[(Math.min(h - 1, Math.max(0, yy)) * w + Math.min(w - 1, Math.max(0, xx))) * 4 + k];
        out[o + k] = (1 - fy) * ((1 - fx) * px(x0, y0) + fx * px(x0 + 1, y0)) + fy * ((1 - fx) * px(x0, y0 + 1) + fx * px(x0 + 1, y0 + 1));
      }
    }
  return { data: out, w: W, h: H, corners };
}
