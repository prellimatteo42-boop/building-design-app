/**
 * Junctions between elements of different kinds, settled as in Archicad:
 * the element whose building material has the higher intersection priority
 * cuts the other; on equal priorities the kind decides, in this order from
 * strongest: mesh, morph, column, beam, slab, wall, shell, roof.
 *
 * In plan a column that wins takes its outline out of the walls it stands
 * in: their fills lose that part and their lines stop at its edge.
 */
import { materialPriority } from './materials.js';
import { layerPriority, subtractConvex, LAYER_PRIORITY } from './layerjoins.js';
import { verticalExtent } from './model.js';
import { bbox, bboxIntersects, ensureCCW, signedArea, dot, sub, perp } from './geom.js';

/** Strength of each kind on equal material priority. */
export const KIND_RANK = { mesh: 8, topo: 8, morph: 7, column: 6, beam: 5, floor: 4, ceiling: 4, wall: 3, shell: 2, roof: 1 };

/** The intersection priority of an element: its core's building material (or its type's material). */
export function elementPriority(doc, el) {
  const type = doc.get(el.typeId);
  if (type?.layers?.length) {
    const core = type.layers.find((l) => l.function === 'structure') || type.layers[0];
    return layerPriority(core, doc);
  }
  const m = type?.materialId ? materialPriority(doc.get(type.materialId)) : null;
  return m ?? LAYER_PRIORITY.structure;
}

/** Whether a wins its junction with b: higher material priority, else the stronger kind. */
export function winsJunction(doc, a, b) {
  const pa = elementPriority(doc, a);
  const pb = elementPriority(doc, b);
  if (pa !== pb) return pa > pb;
  return (KIND_RANK[a.kind] ?? 3) > (KIND_RANK[b.kind] ?? 3);
}

function isConvex(poly) {
  let sign = 0;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const c = poly[(i + 2) % poly.length];
    const k = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
    if (Math.abs(k) < 1e-9) continue;
    if (sign && Math.sign(k) !== sign) return false;
    sign = Math.sign(k);
  }
  return true;
}

/**
 * The outlines of the columns cut at height z that stand in wall w (its
 * footprint poly) and win the junction with it: convex, counterclockwise.
 */
export function columnCutters(doc, w, poly, z, outlineOf) {
  const box = bbox(poly);
  const out = [];
  for (const c of doc.all('column')) {
    if (c.levelId !== w.levelId) continue;
    const { base, top } = verticalExtent(doc, c);
    if (!(base <= z && top > z)) continue;
    const o = outlineOf(c);
    if (!o || o.length < 3 || !bboxIntersects(box, bbox(o))) continue;
    const ccw = ensureCCW(o);
    if (!isConvex(ccw) || Math.abs(signedArea(ccw)) < 1) continue;
    // Standing in the wall: some of the wall is left out by it.
    const rest = subtractConvex(ensureCCW(poly), ccw);
    if (rest.length === 1 && Math.abs(Math.abs(signedArea(rest[0])) - Math.abs(signedArea(poly))) < 1) continue;
    if (winsJunction(doc, c, w)) out.push(ccw);
  }
  return out;
}

/** The parts of segment a-b outside every convex polygon of cutters. */
export function segmentOutside(a, b, cutters) {
  let parts = [[0, 1]];
  const d = sub(b, a);
  for (const poly of cutters) {
    // The stretch [t0, t1] of the segment inside this polygon (Cyrus-Beck).
    let t0 = 0;
    let t1 = 1;
    for (let i = 0; i < poly.length && t0 <= t1; i++) {
      const q = poly[i];
      const n = perp(sub(poly[(i + 1) % poly.length], q));
      const num = dot(n, sub(a, q));
      const den = dot(n, d);
      if (Math.abs(den) < 1e-12) {
        if (num < 0) t1 = -1;
        continue;
      }
      const t = -num / den;
      if (den > 0) t0 = Math.max(t0, t);
      else t1 = Math.min(t1, t);
    }
    if (t1 - t0 <= 1e-9) continue;
    parts = parts.flatMap(([s0, s1]) => [[s0, Math.min(s1, t0)], [Math.max(s0, t1), s1]].filter(([u, v]) => v - u > 1e-6));
  }
  return parts.map(([s0, s1]) => [[a[0] + d[0] * s0, a[1] + d[1] * s0], [a[0] + d[0] * s1, a[1] + d[1] * s1]]);
}

/** A plan builder that leaves out what lies in the cutters: fills lose those parts, lines stop at them. */
export function cutBuilder(b, cutters) {
  return new Proxy(b, {
    get(target, prop) {
      if (prop === 'fill')
        return (poly, holes, ...rest) => {
          let parts = [ensureCCW(poly)];
          if (!holes?.length && isConvex(parts[0])) for (const c of cutters) parts = parts.flatMap((p) => subtractConvex(p, c));
          for (const p of parts) target.fill(p, holes, ...rest);
        };
      if (prop === 'line')
        return (a, c, ...rest) => {
          for (const [p, q] of segmentOutside(a, c, cutters)) target.line(p, q, ...rest);
        };
      const v = target[prop];
      return typeof v === 'function' ? v.bind(target) : v;
    },
  });
}
