/**
 * Site and roof tools, as in Archicad:
 *
 *   - Create Roof Level Lines: contour lines of the roof faces in plan, at a
 *     height interval (detail lines in the view);
 *   - Split into Single-plane Roofs: each face of a multi-plane roof as a
 *     roof of its own, on the same plane;
 *   - Current Site Report (SiteMaker): the terrain's plan and surface area,
 *     its volume over the lowest point, and the cut and fill under the
 *     building pads (slabs on the terrain);
 *   - Gravitate: objects and columns set on the surface under them (shell,
 *     roof, slab, mesh or morph);
 *   - Wall End: a rounded or pier end on a wall (`wallEnd` { wallId, end, shape }).
 */
import { sub, dot, cross, perp, signedArea, pointInPolygon, area as polyArea, arcPoints, add, scale } from './geom.js';
import { roofFaces, planeHeight } from './roof.js';
import { levelElevation, wallAxis, verticalExtent } from './model.js';
import { topoHeightAt, topoSurface } from './topo.js';
import { typeThickness } from './catalog.js';

/** Parameter intervals [t0, t1] where the line o + t·d lies inside a polygon. */
function insideIntervals(poly, o, d) {
  const ts = [];
  for (let i = 0; i < poly.length; i++) {
    const p = poly[i];
    const q = poly[(i + 1) % poly.length];
    const e = sub(q, p);
    const den = cross(d, e);
    if (Math.abs(den) < 1e-12) continue;
    const w = sub(p, o);
    const t = cross(w, e) / den;
    const s = cross(w, d) / den;
    if (s >= -1e-9 && s < 1 - 1e-9) ts.push(t);
  }
  ts.sort((a, b) => a - b);
  const out = [];
  for (let k = 0; k + 1 < ts.length; k += 2) if (ts[k + 1] - ts[k] > 1) out.push([ts[k], ts[k + 1]]);
  return out;
}

/** Roof level lines: [{ a, b, z }] (plan mm, z absolute) every `interval` mm of height on each face. */
export function roofLevelLines(doc, roof, interval = 500) {
  if (!roof?.boundary || roof.boundary.length < 3 || !(interval > 0)) return [];
  const base = levelElevation(doc, roof.levelId) + (+roof.baseOffset || 0);
  const { faces } = roofFaces(roof.boundary, roof.slopes, { levels: roof.levels, overhangs: roof.overhangs });
  const out = [];
  for (const f of faces) {
    const pl = f.plane;
    if (!pl || !(pl.k > 0)) continue;
    const hs = f.poly.map((p) => planeHeight(pl, p));
    const h0 = Math.min(...hs);
    const h1 = Math.max(...hs);
    const dir = perp(pl.m);
    for (let z = Math.ceil((h0 + 1) / interval) * interval; z < h1 - 1; z += interval) {
      // Points where the plane is at z: dot(x - p, m) = (z - h) / k.
      const c = (z - (pl.h || 0)) / pl.k + dot(pl.p, pl.m);
      const o = scale(pl.m, c);
      for (const [t0, t1] of insideIntervals(f.poly, o, dir)) out.push({ a: add(o, scale(dir, t0)).map(Math.round), b: add(o, scale(dir, t1)).map(Math.round), z: base + z });
    }
  }
  return out;
}

/** Single-plane roofs (not added) for each sloped face of a roof, on the same planes. */
export function splitRoof(doc, roof) {
  const { faces } = roofFaces(roof.boundary, roof.slopes, { levels: roof.levels, overhangs: roof.overhangs });
  const out = [];
  for (const f of faces) {
    const pl = f.plane;
    if (!pl) continue;
    let poly = f.poly.map((p) => [Math.round(p[0] * 10) / 10, Math.round(p[1] * 10) / 10]);
    if (signedArea(poly) < 0) poly = poly.slice().reverse();
    // The eave: an edge across the slope (perpendicular to m), the lowest one.
    let best = null;
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i];
      const b = poly[(i + 1) % poly.length];
      const d = sub(b, a);
      const l = Math.hypot(d[0], d[1]);
      if (l < 1) continue;
      if (Math.abs(dot(d, pl.m)) / l > 1e-3) continue;
      const hgt = planeHeight(pl, a);
      if (!best || hgt < best.h) best = { i, h: hgt };
    }
    if (!best) continue;
    const slopes = poly.map((_, i) => (i === best.i ? pl.slope : null));
    const { id: _id, boundary: _b, slopes: _s, overhangs: _o, levels: _l, ...rest } = roof;
    void _id, _b, _s, _o, _l;
    out.push({ ...structuredClone(rest), boundary: poly, slopes, baseOffset: Math.round(((+roof.baseOffset || 0) + best.h) * 10) / 10 });
  }
  return out;
}

/**
 * Current Site Report: for each terrain { id, planArea (m²), surfaceArea (m²), volume (m³ over its lowest point),
 * low, high (mm), pads: [{ id, cut, fill (m³) }] } — pads are slabs over the terrain, cut where the ground is above
 * their underside and fill where it is below.
 */
export function siteReport(doc, { cell = 250 } = {}) {
  const out = [];
  for (const t of doc.all('topo')) {
    const sf = topoSurface(t);
    const { P, tris } = sf;
    if (P.length < 3) continue;
    let planArea = 0;
    let surfaceArea = 0;
    let volume = 0;
    const low = Math.min(...P.map((p) => p[2]));
    const high = Math.max(...P.map((p) => p[2]));
    for (const [i, j, k] of tris) {
      const a = P[i];
      const b = P[j];
      const c = P[k];
      const pa = Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2;
      const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
      const v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
      const n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
      planArea += pa;
      surfaceArea += Math.hypot(n[0], n[1], n[2]) / 2;
      volume += pa * ((a[2] + b[2] + c[2]) / 3 - low);
    }
    const pads = [];
    for (const f of doc.all('floor')) {
      if (!f.boundary || f.boundary.length < 3) continue;
      const top = levelElevation(doc, f.levelId) + (+f.offset || 0);
      const bottom = top - (typeThickness(doc.get(f.typeId)) || 300);
      let cut = 0;
      let fill = 0;
      let inside = 0;
      const xs = f.boundary.map((p) => p[0]);
      const ys = f.boundary.map((p) => p[1]);
      for (let x = Math.min(...xs) + cell / 2; x < Math.max(...xs); x += cell)
        for (let y = Math.min(...ys) + cell / 2; y < Math.max(...ys); y += cell) {
          if (!pointInPolygon([x, y], f.boundary)) continue;
          const z = topoHeightAt(t, [x, y], sf);
          if (z == null) continue;
          inside++;
          if (z > bottom) cut += (z - bottom) * cell * cell;
          else fill += (bottom - z) * cell * cell;
        }
      // Only slabs that sit on this terrain (most of them over it, near its height).
      if (inside * cell * cell < polyArea(f.boundary) * 0.5 || bottom > high + 1000) continue;
      pads.push({ id: f.id, cut: cut / 1e9, fill: fill / 1e9 });
    }
    out.push({ id: t.id, name: t.name || 'Terrain', planArea: planArea / 1e6, surfaceArea: surfaceArea / 1e6, volume: volume / 1e9, low, high, pads });
  }
  return out;
}

/** Heights where a vertical line at (x, y) meets the triangles of a mesh (only faces looking up with `up`). */
export function verticalHits(mesh, x, y, { up = false } = {}) {
  const P = mesh?.pos;
  const out = [];
  if (!P) return out;
  for (let i = 0; i < P.length; i += 9) {
    const a = [P[i], P[i + 1], P[i + 2]];
    const b = [P[i + 3], P[i + 4], P[i + 5]];
    const c = [P[i + 6], P[i + 7], P[i + 8]];
    const det = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1]);
    if (Math.abs(det) < 1e-9) continue;
    if (up) {
      const nz = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
      if (nz <= 0) continue;
    }
    const l1 = ((b[1] - c[1]) * (x - c[0]) + (c[0] - b[0]) * (y - c[1])) / det;
    const l2 = ((c[1] - a[1]) * (x - c[0]) + (a[0] - c[0]) * (y - c[1])) / det;
    const l3 = 1 - l1 - l2;
    if (l1 >= -1e-9 && l2 >= -1e-9 && l3 >= -1e-9) out.push(l1 * a[2] + l2 * b[2] + l3 * c[2]);
  }
  return out;
}

export const GRAVITY_KINDS = ['shell', 'roof', 'floor', 'topo', 'morph', 'mass'];

/**
 * Gravitate (inside a transaction): components and columns set on the top surface under (or nearest) their base.
 * meshOf gives the 3D body of an element. Returns the number moved.
 */
export function gravitate(doc, ids, meshOf, kinds = GRAVITY_KINDS) {
  const targets = kinds.flatMap((k) => doc.all(k));
  let n = 0;
  for (const id of ids) {
    const el = doc.get(id);
    if (!el || !Array.isArray(el.at) || !['component', 'column'].includes(el.kind)) continue;
    const lv = levelElevation(doc, el.levelId);
    const cur = lv + (el.kind === 'column' ? +el.baseOffset || 0 : +el.offset || 0);
    let best = null;
    for (const t of targets) {
      if (t.id === el.id) continue;
      for (const z of verticalHits(meshOf(t), el.at[0], el.at[1], { up: true })) if (best == null || Math.abs(z - cur) < Math.abs(best - cur)) best = z;
    }
    if (best == null) continue;
    const off = Math.round(best - lv);
    doc.update(el.id, el.kind === 'column' ? { baseOffset: off } : { offset: off });
    n++;
  }
  return n;
}

// Wall ends -------------------------------------------------------------------------------------------

export const WALL_END_SHAPES = [
  { value: 'round', label: 'Rounded' },
  { value: 'pier', label: 'Pier (wider square end)' },
];

/** Plan outline of a wall end, its base and top: { outline, base, top } or null. */
export function wallEndShape(doc, el) {
  const w = doc.get(el.wallId);
  if (!w || w.kind !== 'wall' || w.arc) return null;
  const ax = wallAxis(doc, w);
  const p = el.end ? ax.b : ax.a;
  const out = el.end ? ax.dir : [-ax.dir[0], -ax.dir[1]];
  const { base, top } = verticalExtent(doc, w);
  const r = ax.half;
  if (el.shape === 'pier') {
    const s = r * (+el.scale || 1.6);
    const n = perp(out);
    const P = (x, y) => [p[0] + out[0] * x + n[0] * y, p[1] + out[1] * x + n[1] * y];
    return { outline: [P(-s, -s), P(s * 0.6, -s), P(s * 0.6, s), P(-s, s)], base, top };
  }
  // A half disc beyond the end of the wall.
  const a0 = Math.atan2(out[1], out[0]) - Math.PI / 2;
  return { outline: arcPoints(p, r, a0, a0 + Math.PI, Math.PI / 16), base, top };
}
