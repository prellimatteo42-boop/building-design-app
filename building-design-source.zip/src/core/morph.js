/**
 * Morphs, as in Archicad: free-form bodies. A morph is either
 *   - a prism: a footprint `boundary` (with `holes`) from the level plus
 *     baseOffset up to a top whose every corner has its own height
 *     (`heights`, relative to the base; `height` for corners without one),
 *     so tops can slope and twist; or
 *   - a frozen body: `tris`, absolute triangle corners [x, y, z] in threes
 *     with `cols` (one rgba per triangle), from Convert to Morph.
 * In plan a morph is cut by the cut plane like a wall, or shows its outline.
 */
import { profilerMesh, shapeColor } from './profiler.js';
import { MeshBuilder, hexToRgba } from './mesh.js';
import { levelElevation } from './model.js';
import { triangulate, ensureCCW, signedArea } from './geom.js';

/** Height of corner i above the base. */
export function cornerHeight(el, i) {
  const h = el.heights?.[i];
  return Number.isFinite(+h) && h !== null && h !== '' ? +h : +el.height || 3000;
}

export function buildMorph(ctx, el, color = null) {
  // A Profiler body keeps its recipe and is rebuilt from it.
  if (el.profiler) {
    const r = profilerMesh(ctx.doc, el.profiler, color ? () => color : shapeColor(ctx.doc, el));
    return r ? withEdges(r.mesh, Number.isFinite(+el.smoothAngle) ? +el.smoothAngle : 20) : null;
  }
  const b = new MeshBuilder();
  if (Array.isArray(el.tris) && el.tris.length >= 9) {
    for (let t = 0; t + 8 < el.tris.length; t += 9) {
      const c = el.cols?.[t / 9] || color || [190, 190, 190, 255];
      b.tri([el.tris[t], el.tris[t + 1], el.tris[t + 2]], [el.tris[t + 3], el.tris[t + 4], el.tris[t + 5]], [el.tris[t + 6], el.tris[t + 7], el.tris[t + 8]], c);
    }
    // Feature edges come from the faces' angles: under the smoothing angle (Smooth & Merge Faces) faces merge.
    // A body cut by Intersect Morph Faces keeps the edges it had and its lines of intersection, not those of the
    // pieces its faces were split into.
    if (el.ownEdges && Array.isArray(el.lines)) return { ...b.build(), edges: new Float32Array(el.lines) };
    const mesh = withEdges(b.build(), Number.isFinite(+el.smoothAngle) ? +el.smoothAngle : 20);
    // Lines of intersection (Intersect Morph Faces) are edges too, flat as they may lie.
    if (Array.isArray(el.lines) && el.lines.length >= 6) {
      const e = new Float32Array(mesh.edges.length + el.lines.length);
      e.set(mesh.edges);
      e.set(el.lines, mesh.edges.length);
      return { ...mesh, edges: e };
    }
    return mesh;
  }
  if (!el.boundary || el.boundary.length < 3) return null;
  const col = color || hexToRgba(ctx.doc.get(el.materialId)?.color || '#c9c3b8', 1);
  const z0 = levelElevation(ctx.doc, el.levelId) + (+el.baseOffset || 0);
  // Corners counterclockwise, each with its top height.
  const ccw = signedArea(el.boundary) >= 0;
  const idx = el.boundary.map((_, i) => i);
  if (!ccw) idx.reverse();
  const pts = idx.map((i) => el.boundary[i]);
  const tops = idx.map((i) => z0 + cornerHeight(el, i));
  const holes = (el.holes || []).map((h) => ensureCCW(h).slice().reverse());
  const { points: all, tris } = triangulate(pts, holes);
  // Holes take the mean top height.
  const meanTop = tops.reduce((sum, z) => sum + z, 0) / tops.length;
  const zTop = (k) => (k < pts.length ? tops[k] : meanTop);
  for (let t = 0; t + 2 < tris.length; t += 3) {
    let [i, j, k] = [tris[t], tris[t + 1], tris[t + 2]];
    // Counterclockwise from above, so the top faces up.
    const [a0, c0, d0] = [all[i], all[j], all[k]];
    if ((c0[0] - a0[0]) * (d0[1] - a0[1]) - (c0[1] - a0[1]) * (d0[0] - a0[0]) < 0) [j, k] = [k, j];
    const [a, c, d] = [all[i], all[j], all[k]];
    b.tri([a[0], a[1], zTop(i)], [c[0], c[1], zTop(j)], [d[0], d[1], zTop(k)], col);
    b.tri([a[0], a[1], z0], [d[0], d[1], z0], [c[0], c[1], z0], col);
  }
  const ring = (loop, zt, outward) => {
    for (let i = 0; i < loop.length; i++) {
      const j = (i + 1) % loop.length;
      const p = loop[i];
      const q = loop[j];
      const quad = [[p[0], p[1], z0], [q[0], q[1], z0], [q[0], q[1], zt(j)], [p[0], p[1], zt(i)]];
      if (outward) b.quad(...quad, col);
      else b.quad(quad[1], quad[0], quad[3], quad[2], col);
      b.edge(quad[0], quad[1]);
      b.edge(quad[3], quad[2]);
      // A curved morph's sides are one merged face: no edges between their pieces.
      if (!el.curved) b.edge(quad[0], quad[3]);
    }
  };
  ring(pts, (i) => tops[i], true);
  let off = pts.length;
  for (const h of holes) {
    const start = off;
    ring(h, () => meanTop, true);
    off = start + h.length;
  }
  return b.build();
}

/** Edges where faces meet at more than an angle in degrees (a frozen body keeps its outline). */
function withEdges(mesh, angle = 20) {
  const P = mesh.pos;
  const key = (i) => `${Math.round(P[i] * 10)},${Math.round(P[i + 1] * 10)},${Math.round(P[i + 2] * 10)}`;
  const map = new Map();
  for (let t = 0; t < P.length; t += 9) {
    const a = [P[t + 3] - P[t], P[t + 4] - P[t + 1], P[t + 5] - P[t + 2]];
    const c = [P[t + 6] - P[t], P[t + 7] - P[t + 1], P[t + 8] - P[t + 2]];
    const n = [a[1] * c[2] - a[2] * c[1], a[2] * c[0] - a[0] * c[2], a[0] * c[1] - a[1] * c[0]];
    const l = Math.hypot(...n) || 1;
    for (let e = 0; e < 3; e++) {
      const i = t + e * 3;
      const j = t + ((e + 1) % 3) * 3;
      const ki = key(i);
      const kj = key(j);
      const k = ki < kj ? `${ki}|${kj}` : `${kj}|${ki}`;
      if (!map.has(k)) map.set(k, { i, j, ns: [] });
      map.get(k).ns.push(n.map((x) => x / l));
    }
  }
  const edges = [];
  for (const e of map.values()) {
    const sharp = e.ns.length !== 2 || e.ns[0][0] * e.ns[1][0] + e.ns[0][1] * e.ns[1][1] + e.ns[0][2] * e.ns[1][2] < Math.cos((Math.max(0, Math.min(179, angle)) * Math.PI) / 180);
    if (sharp) edges.push(P[e.i], P[e.i + 1], P[e.i + 2], P[e.j], P[e.j + 1], P[e.j + 2]);
  }
  return { ...mesh, edges: new Float32Array(edges) };
}

/**
 * Loops where the horizontal plane at z cuts a closed mesh, in plan.
 * Segments of triangles crossing z are chained end to end.
 */
export function sliceMesh(mesh, z) {
  const P = mesh.pos;
  const segs = [];
  for (let t = 0; t < P.length; t += 9) {
    const hits = [];
    for (let e = 0; e < 3; e++) {
      const i = t + e * 3;
      const j = t + ((e + 1) % 3) * 3;
      const da = P[i + 2] - z;
      const db = P[j + 2] - z;
      if ((da < 0 && db > 0) || (da > 0 && db < 0)) {
        const s = da / (da - db);
        hits.push([P[i] + (P[j] - P[i]) * s, P[i + 1] + (P[j + 1] - P[i + 1]) * s]);
      }
    }
    if (hits.length === 2) segs.push(hits);
  }
  const key = (p) => `${Math.round(p[0] * 2)},${Math.round(p[1] * 2)}`;
  const at = new Map();
  segs.forEach((s, i) => s.forEach((p) => (at.has(key(p)) ? at.get(key(p)).push(i) : at.set(key(p), [i]))));
  const used = new Uint8Array(segs.length);
  const loops = [];
  for (let i = 0; i < segs.length; i++) {
    if (used[i]) continue;
    used[i] = 1;
    const loop = [segs[i][0], segs[i][1]];
    for (let guard = 0; guard < segs.length; guard++) {
      const cur = loop.at(-1);
      const next = (at.get(key(cur)) || []).find((j) => !used[j]);
      if (next === undefined) break;
      used[next] = 1;
      const s = segs[next];
      loop.push(key(s[0]) === key(cur) ? s[1] : s[0]);
    }
    if (loop.length > 3 && key(loop[0]) === key(loop.at(-1))) loop.pop();
    if (loop.length >= 3) loops.push(loop);
  }
  return loops;
}

/** Convex hull of the body seen from above (its plan outline when it is not cut). */
export function morphOutline(mesh) {
  const pts = [];
  for (let i = 0; i < mesh.pos.length; i += 3) pts.push([mesh.pos[i], mesh.pos[i + 1]]);
  pts.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lower = [];
  for (const p of pts) {
    while (lower.length >= 2 && cross(lower.at(-2), lower.at(-1), p) <= 0) lower.pop();
    lower.push(p);
  }
  const upper = [];
  for (let i = pts.length - 1; i >= 0; i--) {
    const p = pts[i];
    while (upper.length >= 2 && cross(upper.at(-2), upper.at(-1), p) <= 0) upper.pop();
    upper.push(p);
  }
  return [...lower.slice(0, -1), ...upper.slice(0, -1)];
}

/** A frozen morph from meshes (Convert to Morph): their triangles and colours. */
export function freezeMeshes(meshes) {
  const tris = [];
  const cols = [];
  for (const m of meshes) {
    if (!m?.pos) continue;
    for (let t = 0; t < m.pos.length; t += 9) {
      for (let k = 0; k < 9; k++) tris.push(Math.round(m.pos[t + k] * 10) / 10);
      const c = (t / 9) * 3 * 4;
      cols.push([m.col[c], m.col[c + 1], m.col[c + 2], m.col[c + 3]]);
    }
  }
  return { tris, cols };
}
