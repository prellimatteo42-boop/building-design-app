/** Change tracking: who changed what, while the project is open. */
export class ChangeLog {
  constructor(doc, label = (el) => el?.name || el?.kind || '') {
    this.entries = [];
    this.known = new Set(doc.items.keys());
    this.label = label;
  }

  /** Note a change to the document: ids changed, by this person or another. */
  record(doc, ev, now = Date.now()) {
    if (ev.preview) return 0;
    let n = 0;
    for (const id of ev.ids || []) {
      const el = doc.get(id);
      if (id === 'project' || el?.kind === 'syncEntry') continue;
      const action = !el ? 'deleted' : this.known.has(id) ? 'modified' : 'added';
      if (el) this.known.add(id);
      else this.known.delete(id);
      this.entries.push({ at: now, id, kind: el?.kind || '', name: this.label(el), action, who: ev.remote ? 'Others' : 'You' });
      n++;
    }
    if (this.entries.length > 5000) this.entries.splice(0, this.entries.length - 5000);
    return n;
  }

  /** Entries, newest first, of some elements or all. */
  list(ids = null) {
    const set = ids ? new Set(ids) : null;
    return this.entries.filter((e) => !set || set.has(e.id)).slice().reverse();
  }

  clear() {
    this.entries.length = 0;
  }
}
