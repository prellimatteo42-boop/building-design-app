/**
 * Stair rules: limits on the riser height R and the tread depth T (the
 * going), and on their combinations, the way stair codes state them:
 *
 *   riser   Rmin ≤ R ≤ Rmax          Rmax is the type's Maximum Riser Height
 *   tread   Tmin ≤ T ≤ Tmax          Tmin is the type's Minimum Tread Depth
 *   step    Smin ≤ 2R + T ≤ Smax     the step rule (after Blondel)
 *   sum     Σmin ≤ R + T ≤ Σmax
 *   ratio   Qmin ≤ R / T ≤ Qmax
 *   pitch   αmin ≤ atan(R / T) ≤ αmax
 *
 * Each is a pair of straight lines in the (T, R) plane, so for a given tread
 * the risers allowed form one interval, and for a given riser the treads do
 * too. Rules other than riser and tread apply only when switched on in the
 * type; a bound left empty does not apply.
 *
 * stairFixes proposes ways to meet the rules, least change first: keep the
 * risers and change the tread, keep the tread and change the risers, then
 * change both.
 */

const EPS = 1e-6;

/**
 * The rules of a stair type: { riser, tread, step, sum, ratio, pitch } as
 * [min, max], null when off. An empty or zero maximum is no maximum.
 */
export function stairRules(type = {}) {
  const num = (v) => (v === undefined || v === null || v === '' || !Number.isFinite(+v) ? null : +v);
  const max = (v) => (num(v) > 0 ? num(v) : null);
  const pair = (on, a, b) => (on ? [num(a), max(b)] : null);
  return {
    riser: [num(type.riserMin), max(type.maxRiser) ?? 180],
    tread: [num(type.tread) ?? 0, max(type.treadMax)],
    step: pair(type.ruleStep, type.stepMin, type.stepMax),
    sum: pair(type.ruleSum, type.sumMin, type.sumMax),
    ratio: pair(type.ruleRatio, type.ratioMin, type.ratioMax),
    pitch: pair(type.rulePitch, type.pitchMin, type.pitchMax),
  };
}

const lo = (r) => r?.[0] ?? null;
const hi = (r) => r?.[1] ?? null;
const tan = (deg) => Math.tan((deg * Math.PI) / 180);

/** [min, max] riser height for a tread depth (or for any allowed tread when it is null). */
export function riserRange(rules, tread = null) {
  const [t0, t1] = tread == null ? [lo(rules.tread) ?? 0, hi(rules.tread) ?? Infinity] : [tread, tread];
  const mins = [lo(rules.riser) ?? 0];
  const maxs = [hi(rules.riser) ?? Infinity];
  if (lo(rules.step) != null) mins.push((lo(rules.step) - t1) / 2);
  if (hi(rules.step) != null) maxs.push((hi(rules.step) - t0) / 2);
  if (lo(rules.sum) != null) mins.push(lo(rules.sum) - t1);
  if (hi(rules.sum) != null) maxs.push(hi(rules.sum) - t0);
  if (lo(rules.ratio) != null) mins.push(lo(rules.ratio) * t0);
  if (hi(rules.ratio) != null) maxs.push(hi(rules.ratio) * t1);
  if (lo(rules.pitch) != null) mins.push(t0 * tan(lo(rules.pitch)));
  if (hi(rules.pitch) != null && hi(rules.pitch) < 90) maxs.push(t1 * tan(hi(rules.pitch)));
  return [Math.max(...mins), Math.min(...maxs)];
}

/** [min, max] tread depth for a riser height. */
export function treadRange(rules, riser) {
  const mins = [lo(rules.tread) ?? 0];
  const maxs = [hi(rules.tread) ?? Infinity];
  if (lo(rules.step) != null) mins.push(lo(rules.step) - 2 * riser);
  if (hi(rules.step) != null) maxs.push(hi(rules.step) - 2 * riser);
  if (lo(rules.sum) != null) mins.push(lo(rules.sum) - riser);
  if (hi(rules.sum) != null) maxs.push(hi(rules.sum) - riser);
  if (hi(rules.ratio) != null && hi(rules.ratio) > 0) mins.push(riser / hi(rules.ratio));
  if (lo(rules.ratio) != null && lo(rules.ratio) > 0) maxs.push(riser / lo(rules.ratio));
  if (hi(rules.pitch) != null && hi(rules.pitch) < 90) mins.push(riser / tan(hi(rules.pitch)));
  if (lo(rules.pitch) != null && lo(rules.pitch) > 0) maxs.push(riser / tan(lo(rules.pitch)));
  return [Math.max(...mins), Math.min(...maxs)];
}

/**
 * Numbers of risers that can climb `rise` within the rules, fewest first:
 * [{ risers, riser }]. With a tread, only those that allow that tread.
 */
export function availableRisers(rules, rise, tread = null) {
  if (!(rise > 0)) return [];
  const [rMin, rMax] = riserRange(rules, tread);
  if (!(rMax > 0) || rMin - rMax > EPS) return [];
  const out = [];
  const first = Math.max(2, Math.ceil(rise / rMax - EPS));
  const last = rMin > 0 ? Math.floor(rise / rMin + EPS) : first + 200;
  for (let n = first; n <= last && out.length < 200; n++) {
    const r = rise / n;
    const [t0, t1] = treadRange(rules, r);
    if (t0 - t1 > EPS) continue;
    if (tread != null && (tread < t0 - EPS || tread > t1 + EPS)) continue;
    out.push({ risers: n, riser: r });
  }
  return out;
}

/** The rules a riser and tread break: [{ rule, label, value, min, max }]. */
export function checkStair(rules, riser, tread) {
  const out = [];
  const test = (rule, label, value, range) => {
    if (!range) return;
    const [min, max] = range;
    if ((min != null && value < min - EPS) || (max != null && value > max + EPS)) out.push({ rule, label, value, min, max });
  };
  test('riser', 'Riser height', riser, rules.riser);
  test('tread', 'Tread depth', tread, rules.tread);
  test('step', 'Step rule (2 × riser + tread)', 2 * riser + tread, rules.step);
  test('sum', 'Riser + tread', riser + tread, rules.sum);
  test('ratio', 'Riser / tread', tread > 0 ? riser / tread : Infinity, rules.ratio);
  test('pitch', 'Pitch', (Math.atan2(riser, tread) * 180) / Math.PI, rules.pitch);
  return out;
}

/**
 * Ways to meet the rules for a stair climbing `rise` with `risers` risers of
 * tread `tread`, least change first: [{ kind, risers, tread, riser, run }].
 * Empty when it already meets them or when nothing can.
 */
export function stairFixes(rules, { rise, risers, tread }) {
  if (!checkStair(rules, rise / risers, tread).length) return [];
  const out = [];
  const add = (kind, n, t) => {
    if (out.some((f) => f.risers === n && Math.abs(f.tread - t) < 0.5)) return;
    if (checkStair(rules, rise / n, t).length) return;
    out.push({ kind, risers: n, tread: t, riser: rise / n, run: (n - 1) * t });
  };
  const nearestTread = (r) => {
    const [t0, t1] = treadRange(rules, r);
    return t0 - t1 > EPS ? null : Math.min(Math.max(tread, t0), t1);
  };
  // Keep the risers, change the tread.
  const [r0, r1] = riserRange(rules);
  const r = rise / risers;
  if (r >= r0 - EPS && r <= r1 + EPS) {
    const t = nearestTread(r);
    if (t != null) add('tread', risers, t);
  }
  // Keep the tread, change the risers (the nearest count that allows it).
  const withTread = availableRisers(rules, rise, tread).sort((a, b) => Math.abs(a.risers - risers) - Math.abs(b.risers - risers));
  if (withTread.length) add('risers', withTread[0].risers, tread);
  // Change both: the nearest count, and the nearest tread it allows.
  const any = availableRisers(rules, rise).sort((a, b) => Math.abs(a.risers - risers) - Math.abs(b.risers - risers));
  for (const a of any.slice(0, 3)) {
    const t = nearestTread(a.riser);
    if (t != null) add('both', a.risers, t);
  }
  return out;
}

