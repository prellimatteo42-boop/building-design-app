/**
 * Element ID Manager, as in Archicad: new IDs for a set of elements in one
 * go, ordered by level and by their place in plan, written as a prefix, an
 * optional level code, a counter with a fixed number of digits and a
 * suffix ("D1.03"). Rooms, areas and spaces take the ID as their number;
 * other elements as their mark.
 */
import { wallAxis } from './model.js';
import { add, scale } from './geom.js';
import { KIND_LABEL } from './catalog.js';

export const ID_ORDERS = [
  { value: 'rows', label: 'In rows: top to bottom, left to right' },
  { value: 'columns', label: 'In columns: left to right, top to bottom' },
  { value: 'current', label: 'By current ID' },
  { value: 'given', label: 'In the order given' },
];

export const LEVEL_CODES = [
  { value: 'none', label: 'None' },
  { value: 'index', label: 'Level number (ground = 0)' },
  { value: 'name', label: 'Level name' },
];

const NUMBERED = new Set(['room', 'area', 'space']);

/** The field an element's ID is kept in. */
export function idField(el) {
  return NUMBERED.has(el.kind) ? 'number' : 'mark';
}

/** A point standing for an element in plan, or null. */
export function elementPoint(doc, el) {
  if (el.hostId && el.t != null) {
    const host = doc.get(el.hostId);
    if (host?.a && host?.b) {
      const ax = wallAxis(doc, host);
      return add(ax.a, scale(ax.dir, +el.t));
    }
  }
  if (Array.isArray(el.at)) return el.at;
  if (el.a && el.b) return [(el.a[0] + el.b[0]) / 2, (el.a[1] + el.b[1]) / 2];
  const poly = el.boundary || el.points || el.outline;
  if (Array.isArray(poly) && poly.length) {
    let x = 0;
    let y = 0;
    for (const p of poly) (x += p[0]), (y += p[1]);
    return [x / poly.length, y / poly.length];
  }
  return null;
}

/** Level numbers with the level nearest elevation 0 as 0, those below negative. */
function levelNumbers(doc) {
  const levels = doc.levels();
  let ground = 0;
  levels.forEach((l, i) => Math.abs(+l.elevation || 0) < Math.abs(+levels[ground].elevation || 0) && (ground = i));
  return new Map(levels.map((l, i) => [l.id, i - ground]));
}

/**
 * New IDs for elements: Map id -> ID. opts: { prefix, suffix, levelCode,
 * separator, start, step, digits, order, restartPerLevel, perKind, band }
 * where band is how far apart (mm) two elements may be across a row or
 * column and still count as one.
 */
export function assignIds(doc, els, opts = {}) {
  const o = { prefix: '', suffix: '', levelCode: 'none', separator: '', start: 1, step: 1, digits: 0, order: 'rows', restartPerLevel: true, perKind: false, band: 500, ...opts };
  const nums = levelNumbers(doc);
  const levels = doc.levels();
  const levelIdx = new Map(levels.map((l, i) => [l.id, i]));
  const items = els.map((el, i) => ({ el, i, p: elementPoint(doc, el) || [0, 0], lv: levelIdx.get(el.levelId) ?? -1 }));
  const band = Math.max(1, +o.band || 500);
  const cmp = (a, b) => {
    if (o.restartPerLevel || o.levelCode !== 'none') if (a.lv !== b.lv) return a.lv - b.lv;
    if (o.order === 'given') return a.i - b.i;
    if (o.order === 'current') return String(a.el[idField(a.el)] ?? '').localeCompare(String(b.el[idField(b.el)] ?? ''), undefined, { numeric: true }) || a.i - b.i;
    // Plan y grows upwards: top rows first.
    const rowA = Math.round(-a.p[1] / band);
    const rowB = Math.round(-b.p[1] / band);
    const colA = Math.round(a.p[0] / band);
    const colB = Math.round(b.p[0] / band);
    if (o.order === 'columns') return colA - colB || b.p[1] - a.p[1] || a.i - b.i;
    return rowA - rowB || a.p[0] - b.p[0] || a.i - b.i;
  };
  items.sort(cmp);
  const counters = new Map();
  const out = new Map();
  for (const it of items) {
    const key = `${o.restartPerLevel ? it.lv : ''}|${o.perKind ? it.el.kind : ''}`;
    const n = counters.has(key) ? counters.get(key) : +o.start || 0;
    counters.set(key, n + (+o.step || 1));
    const lv = levels[it.lv];
    const code = o.levelCode === 'index' ? String(nums.get(lv?.id) ?? '') : o.levelCode === 'name' ? String(lv?.name ?? '') : '';
    const count = String(n).padStart(Math.max(0, +o.digits || 0), '0');
    out.set(it.el.id, `${o.prefix}${code}${code ? o.separator : ''}${count}${o.suffix}`);
  }
  return out;
}

/** A readable name for an element in lists. */
export function idLabel(doc, el) {
  return `${KIND_LABEL[el.kind] || el.kind}${el.name ? ` ${el.name}` : ''}${doc.get(el.typeId)?.name ? ` (${doc.get(el.typeId).name})` : ''}`;
}
