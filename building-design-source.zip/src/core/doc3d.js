/**
 * 3D Documents, as in Archicad: a 3D view's viewpoint drawn as a 2D
 * drawing (here a parallel projection along the camera's direction, the
 * axonometry of the 3D view) that takes dimensions, labels, texts and fills
 * like any drafting view and can be placed on layouts. The drawing is a
 * hidden-line projection of the model (core/hiddenline.js); its lines are
 * tagged `doc3d: true` so Rebuild replaces them and leaves the annotations
 * the user added.
 *
 *   drafting view { ..., doc3d: { camera, sourceViewId, hiddenCats, hiddenIds, res } }
 *
 * Drawing coordinates: u along the camera's right, v along its up (mm).
 */
import { hiddenLineEdges, viewMeshes } from './hiddenline.js';

/** Right, up and back unit vectors of a 3D camera (yaw, pitch as the model view uses them). */
export function cameraBasis(cam) {
  const yaw = +cam?.yaw || 0;
  const pitch = +cam?.pitch || 0;
  const back = [Math.cos(pitch) * Math.cos(yaw), Math.cos(pitch) * Math.sin(yaw), Math.sin(pitch)];
  const right = [-Math.sin(yaw), Math.cos(yaw), 0];
  const up = [back[1] * right[2] - back[2] * right[1], back[2] * right[0] - back[0] * right[2], back[0] * right[1] - back[1] * right[0]];
  return { back, right, up };
}

/** The projection of a camera for hiddenLineEdges: [u, v, depth] with depth growing away from the eye. */
export function axonFrame(cam) {
  const { back, right, up } = cameraBasis(cam);
  const t = cam?.target || [0, 0, 0];
  return {
    project: (x, y, z) => {
      const d = [x - t[0], y - t[1], z - t[2]];
      return [d[0] * right[0] + d[1] * right[1] + d[2] * right[2], d[0] * up[0] + d[1] * up[1] + d[2] * up[2], -(d[0] * back[0] + d[1] * back[1] + d[2] * back[2])];
    },
    near: -1e9,
    far: 1e9,
  };
}

/** A model point in the drawing's coordinates. */
export function projectPoint(cam, p) {
  const [u, v] = axonFrame(cam).project(p[0], p[1], p[2] || 0);
  return [u, v];
}

/** The lines of a 3D document: [{ a, b, style }] (outlines medium, the rest thin). */
export function document3dLines(doc, spec, meshOf, kinds, { res } = {}) {
  const meshes = viewMeshes(doc, { hiddenCats: spec.hiddenCats || [], hiddenIds: spec.hiddenIds || [] }, meshOf, kinds);
  return hiddenLineEdges(meshes, axonFrame(spec.camera), { res: res || spec.res || 20 }).map((l) => ({ a: l.a, b: l.b, style: l.outline ? 'medium' : 'thin' }));
}

/** Replace the model lines of a 3D document view (inside a transaction). Returns the number of lines. */
export function rebuildDocument3d(doc, view, meshOf, kinds) {
  if (!view?.doc3d) return 0;
  for (const el of doc.all('detailLine')) if (el.viewId === view.id && el.doc3d) doc.remove(el.id);
  const lines = document3dLines(doc, view.doc3d, meshOf, kinds);
  for (const l of lines) doc.add({ kind: 'detailLine', viewId: view.id, a: l.a, b: l.b, style: l.style, doc3d: true });
  return lines.length;
}

export const isDocument3d = (v) => v?.kind === 'drafting' && !!v.doc3d;
