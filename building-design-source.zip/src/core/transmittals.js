/**
 * Transmittal sets, as in Archicad's Layout Book: a named, dated set of
 * layouts sent to someone. One set is open at a time (the last one not
 * closed); layouts are added to it and taken out of it; closing it freezes
 * it, and the last closed set can be reopened.
 *
 *   project.transmittals = [{ id, name, date, issuedTo, issuedBy, description, sheets: [id], closed }]
 */
export const transmittalsOf = (project) => project?.transmittals || [];

/** The open set, or null. */
export function currentSet(project) {
  const list = transmittalsOf(project);
  for (let i = list.length - 1; i >= 0; i--) if (!list[i].closed) return list[i];
  return null;
}

const withSet = (project, id, fn) => transmittalsOf(project).map((t) => (t.id === id ? fn(t) : t));

/** Patches for project.transmittals (return { transmittals }). */
export function createSet(project, { name, date = new Date().toISOString().slice(0, 10), issuedTo = '', issuedBy = '', description = '' } = {}) {
  const list = transmittalsOf(project).map((t) => (t.closed ? t : { ...t, closed: true }));
  const n = list.length + 1;
  const id = `ts${Date.now().toString(36)}${n}`;
  return { transmittals: [...list, { id, name: name || `Transmittal ${n}`, date, issuedTo, issuedBy, description, sheets: [], closed: false }] };
}

export function addToCurrent(project, sheetIds) {
  const cur = currentSet(project);
  if (!cur) return null;
  return { transmittals: withSet(project, cur.id, (t) => ({ ...t, sheets: [...new Set([...t.sheets, ...sheetIds])] })) };
}

export function removeFromCurrent(project, sheetIds) {
  const cur = currentSet(project);
  if (!cur) return null;
  return { transmittals: withSet(project, cur.id, (t) => ({ ...t, sheets: t.sheets.filter((s) => !sheetIds.includes(s)) })) };
}

export function closeCurrent(project) {
  const cur = currentSet(project);
  return cur ? { transmittals: withSet(project, cur.id, (t) => ({ ...t, closed: true })) } : null;
}

export function reopenLast(project) {
  const list = transmittalsOf(project);
  if (currentSet(project) || !list.length) return null;
  return { transmittals: withSet(project, list.at(-1).id, (t) => ({ ...t, closed: false })) };
}

export function deleteCurrent(project) {
  const cur = currentSet(project);
  return cur ? { transmittals: transmittalsOf(project).filter((t) => t.id !== cur.id) } : null;
}

export function updateSet(project, id, fields) {
  return { transmittals: withSet(project, id, (t) => ({ ...t, ...fields })) };
}

/** The sets a layout was sent in, oldest first. */
export function sheetHistory(project, sheetId) {
  return transmittalsOf(project).filter((t) => t.sheets.includes(sheetId));
}
