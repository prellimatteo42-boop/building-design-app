/**
 * Parametric furniture as GDL objects: wardrobes and glass-fronted closets, cabinets, bedside units, bookcases,
 * kitchen units, desks, tables, beds, rugs, curtains, pictures and table lamps.
 * Width A, depth B and height ZZYZX stay parameters of the object, as do doors, drawers and shelves, so each
 * piece can be changed afterwards. Its back is at y = B and its front at y = 0.
 */
export const FURNITURE_KINDS = ['wardrobe', 'closet', 'cabinet', 'nightstand', 'bookcase', 'kitchen_base', 'kitchen_wall', 'desk', 'table', 'round_table', 'bed', 'rug', 'curtain', 'picture', 'table_lamp'];

const DEFAULTS = {
  wardrobe: { width: 2400, depth: 600, height: 2300, doors: 3, drawers: 0, shelves: 3 },
  cabinet: { width: 1200, depth: 450, height: 800, doors: 2, drawers: 0, shelves: 1 },
  bookcase: { width: 900, depth: 300, height: 2000, doors: 0, drawers: 0, shelves: 4 },
  kitchen_base: { width: 1800, depth: 600, height: 900, doors: 3, drawers: 0, shelves: 1 },
  kitchen_wall: { width: 1800, depth: 350, height: 700, doors: 3, drawers: 0, shelves: 1 },
  desk: { width: 1400, depth: 700, height: 750, doors: 0, drawers: 0, shelves: 0 },
  table: { width: 1600, depth: 900, height: 750, doors: 0, drawers: 0, shelves: 0 },
  bed: { width: 1600, depth: 2050, height: 950, doors: 0, drawers: 0, shelves: 0 },
  closet: { width: 2000, depth: 600, height: 2500, doors: 2, drawers: 0, shelves: 4 },
  nightstand: { width: 550, depth: 420, height: 420, doors: 0, drawers: 2, shelves: 0 },
  round_table: { width: 450, depth: 450, height: 520, doors: 0, drawers: 0, shelves: 0 },
  rug: { width: 2400, depth: 1700, height: 12, doors: 0, drawers: 0, shelves: 0 },
  curtain: { width: 1800, depth: 120, height: 2700, doors: 0, drawers: 0, shelves: 0 },
  picture: { width: 900, depth: 30, height: 900, doors: 0, drawers: 0, shelves: 0 },
  table_lamp: { width: 320, depth: 320, height: 360, doors: 0, drawers: 0, shelves: 0 },
};

const COLORS = {
  white: [0.93, 0.93, 0.91], bianco: [0.93, 0.93, 0.91], black: [0.1, 0.1, 0.1], nero: [0.1, 0.1, 0.1], grey: [0.55, 0.55, 0.55], grigio: [0.55, 0.55, 0.55], oak: [0.72, 0.56, 0.38], rovere: [0.72, 0.56, 0.38], walnut: [0.36, 0.23, 0.14], noce: [0.36, 0.23, 0.14], wood: [0.62, 0.45, 0.28], legno: [0.62, 0.45, 0.28], blue: [0.2, 0.33, 0.55], blu: [0.2, 0.33, 0.55], green: [0.3, 0.45, 0.32], verde: [0.3, 0.45, 0.32], red: [0.6, 0.18, 0.15], rosso: [0.6, 0.18, 0.15], beige: [0.82, 0.76, 0.65], sand: [0.82, 0.76, 0.65], tortora: [0.7, 0.65, 0.59], taupe: [0.7, 0.65, 0.59], arancione: [0.9, 0.45, 0.1], orange: [0.9, 0.45, 0.1],
};

/** An RGB triple from a colour name or #rrggbb; `fallback` when it is neither. */
export function colorOf(name, fallback = COLORS.white) {
  const s = String(name ?? '').trim().toLowerCase();
  if (COLORS[s]) return COLORS[s];
  const m = /^#([0-9a-f]{6})$/.exec(s);
  if (m) return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16) / 255);
  return fallback;
}

const material = (name, c) => `DEFINE MATERIAL "${name}" 2, ${c.map((v) => v.toFixed(3)).join(', ')}`;
/** A see-through material: type 20 keeps the transparency, the ninth of its values. */
const seeThrough = (name, c, t) => `DEFINE MATERIAL "${name}" 20, ${c.map((v) => v.toFixed(3)).join(', ')}, 0, 0, 0, ${t}, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0`;
const box = (x, y, z, a, b, c) => `ADD ${x}, ${y}, ${z}\nBLOCK ${a}, ${b}, ${c}\nDEL 1`;
const plan = 'RECT2 0, 0, A, B';

function cabinetScript(kind) {
  const sleek = kind === 'nightstand';
  const hung = kind === 'kitchen_wall' || sleek;
  const worktop = kind === 'kitchen_base';
  const lines = [
    `MATERIAL "body"`,
    't = thick',
    `H = ZZYZX${worktop ? ' - 0.04' : ''}`,
    `base = ${hung ? 0 : 0.08}`,
    `IF base > 0 THEN`,
    box(0.03, 0.05, 0, 'A - 0.06', 'B - 0.08', 'base'),
    'ENDIF',
    box(0, 0, 'base', 't', 'B', 'H - base'),
    box('A - t', 0, 'base', 't', 'B', 'H - base'),
    box('t', 0, 'base', 'A - 2 * t', 'B', 't'),
    box('t', 0, 'H - t', 'A - 2 * t', 'B', 't'),
    box('t', 'B - 0.008', 'base + t', 'A - 2 * t', 0.008, 'H - base - 2 * t'),
    'IF shelves > 0 THEN',
    'FOR i = 1 TO shelves',
    box('t', 0.03, 'base + t + i * (H - base - 2 * t) / (shelves + 1)', 'A - 2 * t', 'B - 0.05', 't'),
    'NEXT i',
    'ENDIF',
  ];
  if (kind === 'wardrobe') lines.push(`MATERIAL "metal"`, box('t', 'B / 2 - 0.01', 'H - 0.09', 'A - 2 * t', 0.02, 0.02), `MATERIAL "body"`);
  lines.push(
    'zd = base + t',
    'hd = H - base - 2 * t',
    'IF drawers > 0 THEN',
    'dh = hd / drawers',
    'FOR i = 1 TO drawers',
    `MATERIAL "front"`,
    box('t + 0.002', -0.018, 'zd + (i - 1) * dh + 0.002', 'A - 2 * t - 0.004', 0.018, 'dh - 0.004'),
    ...(sleek ? [] : [`MATERIAL "metal"`, box('A / 2 - 0.08', -0.038, 'zd + (i - 0.5) * dh - 0.006', 0.16, 0.02, 0.012)]),
    'NEXT i',
    'ENDIF',
    'IF drawers = 0 AND doors > 0 THEN',
    'dw = (A - 2 * t) / doors',
    'FOR i = 1 TO doors',
    `MATERIAL "front"`,
    box('t + (i - 1) * dw + 0.002', -0.018, 'zd + 0.002', 'dw - 0.004', 0.018, 'hd - 0.004'),
    `MATERIAL "metal"`,
    box('t + (i - 1) * dw + dw * (1 - (i MOD 2) * 0.86 - 0.07)', -0.038, 'zd + hd * 0.42', 0.012, 0.02, 'MIN(0.3, hd * 0.2)'),
    'NEXT i',
    'ENDIF',
  );
  if (worktop) lines.push(`MATERIAL "top"`, box(-0.02, -0.03, 'H', 'A + 0.04', 'B + 0.03', 0.04));
  return lines.join('\n');
}

function tableScript(kind) {
  const lines = ['MATERIAL "body"', box(0, 0, 'ZZYZX - thick', 'A', 'B', 'thick'), 'MATERIAL "metal"'];
  for (const [x, y] of [['0.04', '0.04'], ['A - 0.1', '0.04'], ['0.04', 'B - 0.1'], ['A - 0.1', 'B - 0.1']]) lines.push(box(x, y, 0, 0.06, 0.06, 'ZZYZX - thick'));
  if (kind === 'desk') lines.push('MATERIAL "front"', box('A - 0.45', 'B * 0.1', 'ZZYZX - thick - 0.45', 0.4, 'B * 0.8', 0.45));
  return lines.join('\n');
}

/** A soft shape: an ellipsoid with these half-sizes round its centre. */
const pillow = (x, y, z, rx, ry, rz) => `ADD ${x}, ${y}, ${z}\nMUL ${rx}, ${ry}, ${rz}\nSPHERE 1\nDEL 2`;

function bedScript() {
  return [
    'RESOL 28',
    'MATERIAL "body"',
    // Frame on four legs, a headboard across its whole width.
    box(0, 0, 0.2, 'A', 'B - 0.06', 0.1),
    box(0.03, 0.03, 0, 0.05, 0.05, 0.2),
    box('A - 0.08', 0.03, 0, 0.05, 0.05, 0.2),
    box(0.03, 'B - 0.14', 0, 0.05, 0.05, 0.2),
    box('A - 0.08', 'B - 0.14', 0, 0.05, 0.05, 0.2),
    box(0, 'B - 0.06', 0, 'A', 0.06, 'ZZYZX'),
    // Mattress and bedding, which falls a little over the sides and the foot.
    'MATERIAL "front"',
    box(0.03, 0.02, 0.3, 'A - 0.06', 'B - 0.1', 0.2),
    box(-0.015, -0.015, 0.34, 'A + 0.03', 'B - 0.55', 0.18),
    // A throw folded across the foot.
    'MATERIAL "accent"',
    box(-0.022, -0.022, 0.36, 'A + 0.044', 'B * 0.33', 0.17),
    // Pillows against the headboard: two large ones behind, two smaller in front.
    'MATERIAL "top"',
    pillow('A * 0.27', 'B - 0.2', 0.67, 'A * 0.23', 0.13, 0.17),
    pillow('A * 0.73', 'B - 0.2', 0.67, 'A * 0.23', 0.13, 0.17),
    'MATERIAL "pillow"',
    pillow('A * 0.3', 'B - 0.4', 0.62, 'A * 0.19', 0.09, 0.13),
    pillow('A * 0.7', 'B - 0.4', 0.62, 'A * 0.19', 0.09, 0.13),
  ].join('\n');
}

/** A built-in closet: glass doors in a thin dark frame over part of its width, hanging space on the left and shelves on the right. */
function closetScript() {
  const lines = [
    'MATERIAL "body"',
    't = thick',
    box(0, 0, 0, 't', 'B', 'ZZYZX'),
    box('A - t', 0, 0, 't', 'B', 'ZZYZX'),
    box('t', 0, 0, 'A - 2 * t', 'B', 't'),
    box('t', 0, 'ZZYZX - t', 'A - 2 * t', 'B', 't'),
    box('t', 'B - t', 't', 'A - 2 * t', 't', 'ZZYZX - 2 * t'),
    box('A / 2 - t / 2', 0.04, 't', 't', 'B - 0.04', 'ZZYZX - 2 * t'),
    'IF shelves > 0 THEN',
    'FOR i = 1 TO shelves',
    box('A / 2 + t / 2', 0.03, 't + i * (ZZYZX - 2 * t) / (shelves + 1)', 'A / 2 - 1.5 * t', 'B - 0.03', 't'),
    'NEXT i',
    'ENDIF',
    'MATERIAL "metal"',
    box('t', 'B / 2 - 0.01', 'ZZYZX - 0.32', 'A / 2 - 1.5 * t', 0.02, 0.02),
    'n = MAX(1, doors)',
    'dw = A * cover / n',
    'IF cover > 0 THEN',
    'FOR i = 0 TO n - 1',
    'x = i * dw',
    'MATERIAL "glassframe"',
    box('x', -0.03, 0, 0.03, 0.03, 'ZZYZX'),
    box('x + dw - 0.03', -0.03, 0, 0.03, 0.03, 'ZZYZX'),
    box('x + 0.03', -0.03, 0, 'dw - 0.06', 0.03, 0.03),
    box('x + 0.03', -0.03, 'ZZYZX - 0.03', 'dw - 0.06', 0.03, 0.03),
    'MATERIAL "glass"',
    box('x + 0.03', -0.017, 0.03, 'dw - 0.06', 0.006, 'ZZYZX - 0.06'),
    'NEXT i',
    'ENDIF',
  ];
  return lines.join('\n');
}

function roundTableScript() {
  return ['MATERIAL "body"', 'ADD A / 2, B / 2, 0', 'CYLIND 0.012, MIN(A, B) * 0.3', 'CYLIND ZZYZX, 0.018', 'ADDZ ZZYZX - 0.018', 'CYLIND 0.018, MIN(A, B) / 2', 'DEL 2'].join('\n');
}

/** A curtain: a thin sheet folded in waves, drawn from a rail at its top. */
function curtainScript() {
  return [
    'MATERIAL "body"',
    'n = MAX(8, INT(A / 0.02))',
    'FOR i = 0 TO n',
    'x = A * i / n',
    'PUT x, B / 2 + (B / 2 - 0.006) * SIN(360 * x / 0.2), 1',
    'NEXT i',
    'FOR i = n TO 0 STEP -1',
    'x = A * i / n',
    'PUT x, B / 2 + (B / 2 - 0.006) * SIN(360 * x / 0.2) + 0.005, 1',
    'NEXT i',
    'PRISM_ NSP / 3, ZZYZX, GET(NSP)',
    'MATERIAL "metal"',
    box(0, 'B / 2 - 0.01', 'ZZYZX', 'A', 0.02, 0.02),
  ].join('\n');
}

/** A picture: frame and canvas; the canvas shows a colour or, when it has one, the object's own image (its picture 1), which goes wherever the object goes. */
function pictureScript(showsImage) {
  const lines = ['MATERIAL "body"', box(0, 0.002, 0, 'A', 'B - 0.002', 'ZZYZX'), 'MATERIAL "top"', box('frame', 0.001, 'frame', 'A - 2 * frame', 0.001, 'ZZYZX - 2 * frame')];
  if (showsImage) lines.push('ADD frame, 0, frame', 'ROTX 90', 'PICTURE 1, A - 2 * frame, ZZYZX - 2 * frame, 0', 'DEL 2');
  return lines.join('\n');
}

function lampScript() {
  return [
    'MATERIAL "body"',
    'ADD A / 2, B / 2, 0',
    'CYLIND 0.015, MIN(A, B) * 0.3',
    'CONE ZZYZX * 0.62, 0.05, 0.03, 90, 90',
    'MATERIAL "front"',
    'ADDZ ZZYZX * 0.6',
    'ELLIPS ZZYZX * 0.4, MIN(A, B) / 2',
    'DEL 2',
  ].join('\n');
}

function plan2D(kind) {
  if (kind === 'bed') return `${plan}\nLINE2 0, B - 0.65, A, B - 0.65\nRECT2 A * 0.06, B - 0.55, A * 0.46, B - 0.13\nRECT2 A * 0.54, B - 0.55, A * 0.94, B - 0.13`;
  if (kind === 'table' || kind === 'desk' || kind === 'picture') return plan;
  if (kind === 'round_table' || kind === 'table_lamp') return 'CIRCLE2 A / 2, B / 2, MIN(A, B) / 2';
  if (kind === 'rug') return `${plan}\nRECT2 0.06, 0.06, A - 0.06, B - 0.06`;
  if (kind === 'curtain') return `${plan}\nLINE2 0, B / 2, A, B / 2`;
  // Doors shown by their joints along the front.
  return `${plan}\nLINE2 0, 0.02, A, 0.02\nIF doors > 1 THEN\nFOR i = 1 TO doors - 1\nLINE2 A * i / doors, 0, A * i / doors, 0.05\nNEXT i\nENDIF`;
}

/**
 * A GDL object definition for a piece of furniture, in the form a component type holds:
 * { name, category, width, depth, height, gdl: { params, script3d, script2d } }. spec: { kind, width, depth, height (mm), doors, drawers, shelves, color, front_color, top_color, accent_color, pillow_color, glass_share (closet: 0..1 of its width behind glass), frame (picture, mm), image (picture: a data URL it shows), name }.
 */
export function furnitureObject(spec = {}) {
  const kind = FURNITURE_KINDS.includes(spec.kind) ? spec.kind : 'cabinet';
  const d = DEFAULTS[kind];
  const num = (v, fb) => (Number.isFinite(+v) && v !== null && v !== '' ? +v : fb);
  const thin = kind === 'rug' || kind === 'curtain' || kind === 'picture';
  const width = Math.max(200, num(spec.width, d.width));
  const depth = Math.max(thin ? 10 : 100, num(spec.depth, d.depth));
  const height = Math.max(thin ? 3 : 100, num(spec.height, d.height));
  const body = colorOf(spec.color, kind === 'bed' ? COLORS.oak : kind === 'closet' ? COLORS.walnut : COLORS.white);
  const front = colorOf(spec.front_color ?? spec.color, kind === 'bed' ? COLORS.beige : body);
  const top = colorOf(spec.top_color, kind === 'bed' ? COLORS.white : COLORS.grey);
  const accent = colorOf(spec.accent_color ?? spec.front_color, front);
  const soft = colorOf(spec.pillow_color ?? spec.top_color, top);
  // A curtain is sheer unless asked otherwise.
  const bodyDef = kind === 'curtain' && spec.opaque !== true ? seeThrough('body', body, 0.28) : material('body', body);
  const defs = [bodyDef, material('front', front), material('top', top), material('accent', accent), material('pillow', soft), material('metal', [0.45, 0.45, 0.47]), material('glassframe', [0.07, 0.07, 0.08]), seeThrough('glass', [0.55, 0.6, 0.62], 0.75)].join('\n');
  const scripts = { bed: bedScript, closet: closetScript, round_table: roundTableScript, rug: () => `MATERIAL "body"\n${box(0, 0, 0, 'A', 'B', 'ZZYZX')}`, curtain: curtainScript, picture: () => pictureScript(!!spec.image), table_lamp: lampScript };
  const script = scripts[kind] ? scripts[kind]() : kind === 'table' || kind === 'desk' ? tableScript(kind) : cabinetScript(kind);
  const params = [
    { name: 'thick', label: 'Panel thickness', kind: 'length', value: kind === 'table' || kind === 'desk' ? 30 : 18 },
    { name: 'doors', label: 'Doors', kind: 'integer', value: Math.max(0, Math.round(num(spec.doors, d.doors))) },
    { name: 'drawers', label: 'Drawers', kind: 'integer', value: Math.max(0, Math.round(num(spec.drawers, d.drawers))) },
    { name: 'shelves', label: 'Shelves', kind: 'integer', value: Math.max(0, Math.round(num(spec.shelves, d.shelves))) },
  ];
  if (kind === 'closet') params.push({ name: 'cover', label: 'Share behind glass', kind: 'number', value: Math.max(0, Math.min(1, num(spec.glass_share, 0.5))) });
  if (kind === 'picture') params.push({ name: 'frame', label: 'Frame width', kind: 'length', value: Math.max(0, num(spec.frame, 0)) });
  const label = { wardrobe: 'Wardrobe', cabinet: 'Cabinet', bookcase: 'Bookcase', kitchen_base: 'Kitchen base unit', kitchen_wall: 'Kitchen wall unit', desk: 'Desk', table: 'Table', bed: 'Bed', closet: 'Glass closet', nightstand: 'Bedside unit', round_table: 'Round side table', rug: 'Rug', curtain: 'Curtain', picture: 'Picture', table_lamp: 'Table lamp' }[kind];
  return {
    name: spec.name || `${label} ${Math.round(width)} x ${Math.round(depth)} x ${Math.round(height)}`,
    category: kind.startsWith('kitchen') ? 'casework' : kind === 'table_lamp' ? 'lighting' : 'furniture',
    width,
    depth,
    height,
    gdl: { params, script3d: `${defs}\n${script}`, script2d: plan2D(kind), ...(spec.image ? { pictures: { 1: spec.image } } : {}) },
  };
}

/** English search words for the Italian names people use. */
const WORDS = { armadio: 'wardrobe', armadi: 'wardrobe', guardaroba: 'wardrobe', divano: 'sofa couch', poltrona: 'armchair', letto: 'bed', comodino: 'nightstand bedside', tavolo: 'table', tavolino: 'coffee table', scrivania: 'desk', sedia: 'chair', sgabello: 'stool', libreria: 'bookcase shelf', mensola: 'shelf', cucina: 'kitchen counter', frigorifero: 'fridge refrigerator', forno: 'oven range', lavello: 'sink', lavandino: 'sink', lavabo: 'sink vanity washbasin', wc: 'toilet', water: 'toilet', bidet: 'bidet', doccia: 'shower', vasca: 'bath tub bathtub', lampada: 'lamp light', lampadario: 'chandelier pendant lamp', tappeto: 'rug carpet', pianta: 'plant', albero: 'tree', specchio: 'mirror', tenda: 'curtain', televisore: 'tv television', lavatrice: 'washing machine', caminetto: 'fireplace', mobile: 'cabinet', credenza: 'sideboard cabinet', persona: 'person people', auto: 'car' };

/** The words to look for: the query's own, and their English names. */
export function searchWords(query) {
  const own = String(query ?? '').toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  return own.map((w) => [w, ...(WORDS[w] || '').split(' ').filter(Boolean)]);
}

/** Whether a text answers a query: each word of it, in Italian or English, is found. */
export function matchesQuery(text, query) {
  const t = String(text ?? '').toLowerCase();
  return searchWords(query).every((alts) => alts.some((a) => t.includes(a)));
}

/**
 * Where an object goes against a side of a rectangular extent { x0, y0, x1, y1 }: { at, rotation }, its back to the wall.
 * side: north, south, east, west; along: 0 start .. 1 end of the side (0.5 by default). w, d: its width and depth.
 */
export function placeAgainst(box, side, w, d, along = 0.5, gap = 10) {
  const a = Math.max(0, Math.min(1, along));
  const lerp = (p, q, half) => p + half + (q - p - 2 * half) * a;
  if (side === 'north') return { at: [lerp(box.x0, box.x1, w / 2), box.y1 - d / 2 - gap], rotation: 0 };
  if (side === 'south') return { at: [lerp(box.x0, box.x1, w / 2), box.y0 + d / 2 + gap], rotation: 180 };
  if (side === 'east') return { at: [box.x1 - d / 2 - gap, lerp(box.y0, box.y1, w / 2)], rotation: -90 };
  return { at: [box.x0 + d / 2 + gap, lerp(box.y0, box.y1, w / 2)], rotation: 90 };
}
