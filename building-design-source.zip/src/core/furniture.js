/**
 * Parametric furniture as GDL objects: wardrobes and glass-fronted closets, cabinets, bedside units, bookcases,
 * kitchen units, desks, tables, beds, rugs, curtains, pictures and table lamps.
 * Width A, depth B and height ZZYZX stay parameters of the object, as do doors, drawers and shelves, so each
 * piece can be changed afterwards. Its back is at y = B and its front at y = 0.
 */
export const FURNITURE_KINDS = ['wardrobe', 'closet', 'cabinet', 'nightstand', 'bookcase', 'kitchen_base', 'kitchen_wall', 'desk', 'table', 'round_table', 'bed', 'rug', 'curtain', 'picture', 'table_lamp', 'shoes', 'hat', 'folded_clothes', 'wall_plate', 'cove_light'];

const DEFAULTS = {
  wardrobe: { width: 2400, depth: 600, height: 2300, doors: 3, drawers: 0, shelves: 3 },
  cabinet: { width: 1200, depth: 450, height: 800, doors: 2, drawers: 0, shelves: 1 },
  bookcase: { width: 900, depth: 300, height: 2000, doors: 0, drawers: 0, shelves: 4 },
  kitchen_base: { width: 1800, depth: 600, height: 900, doors: 3, drawers: 0, shelves: 1 },
  kitchen_wall: { width: 1800, depth: 350, height: 700, doors: 3, drawers: 0, shelves: 1 },
  desk: { width: 1400, depth: 700, height: 750, doors: 0, drawers: 0, shelves: 0 },
  table: { width: 1600, depth: 900, height: 750, doors: 0, drawers: 0, shelves: 0 },
  bed: { width: 1600, depth: 2050, height: 950, doors: 0, drawers: 0, shelves: 0 },
  closet: { width: 2000, depth: 600, height: 2500, doors: 2, drawers: 0, shelves: 4 },
  nightstand: { width: 550, depth: 420, height: 420, doors: 0, drawers: 2, shelves: 0 },
  round_table: { width: 450, depth: 450, height: 520, doors: 0, drawers: 0, shelves: 0 },
  rug: { width: 2400, depth: 1700, height: 12, doors: 0, drawers: 0, shelves: 0 },
  curtain: { width: 1800, depth: 120, height: 2700, doors: 0, drawers: 0, shelves: 0 },
  picture: { width: 900, depth: 30, height: 900, doors: 0, drawers: 0, shelves: 0 },
  table_lamp: { width: 320, depth: 320, height: 360, doors: 0, drawers: 0, shelves: 0 },
  shoes: { width: 220, depth: 290, height: 100, doors: 0, drawers: 0, shelves: 0 },
  hat: { width: 340, depth: 340, height: 130, doors: 0, drawers: 0, shelves: 0 },
  folded_clothes: { width: 320, depth: 280, height: 140, doors: 0, drawers: 0, shelves: 0 },
  wall_plate: { width: 86, depth: 10, height: 86, doors: 0, drawers: 0, shelves: 0 },
  cove_light: { width: 3000, depth: 60, height: 30, doors: 0, drawers: 0, shelves: 0 },
};

const COLORS = {
  white: [0.93, 0.93, 0.91], bianco: [0.93, 0.93, 0.91], black: [0.1, 0.1, 0.1], nero: [0.1, 0.1, 0.1], grey: [0.55, 0.55, 0.55], grigio: [0.55, 0.55, 0.55], oak: [0.72, 0.56, 0.38], rovere: [0.72, 0.56, 0.38], walnut: [0.36, 0.23, 0.14], noce: [0.36, 0.23, 0.14], wood: [0.62, 0.45, 0.28], legno: [0.62, 0.45, 0.28], blue: [0.2, 0.33, 0.55], blu: [0.2, 0.33, 0.55], green: [0.3, 0.45, 0.32], verde: [0.3, 0.45, 0.32], red: [0.6, 0.18, 0.15], rosso: [0.6, 0.18, 0.15], beige: [0.82, 0.76, 0.65], sand: [0.82, 0.76, 0.65], tortora: [0.7, 0.65, 0.59], taupe: [0.7, 0.65, 0.59], arancione: [0.9, 0.45, 0.1], orange: [0.9, 0.45, 0.1],
};

/** An RGB triple from a colour name or #rrggbb; `fallback` when it is neither. */
export function colorOf(name, fallback = COLORS.white) {
  const s = String(name ?? '').trim().toLowerCase();
  if (COLORS[s]) return COLORS[s];
  const m = /^#([0-9a-f]{6})$/.exec(s);
  if (m) return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16) / 255);
  return fallback;
}

const material = (name, c) => `DEFINE MATERIAL "${name}" 2, ${c.map((v) => v.toFixed(3)).join(', ')}`;
/** A see-through material: type 20 keeps the transparency, the ninth of its values. */
const seeThrough = (name, c, t) => `DEFINE MATERIAL "${name}" 20, ${c.map((v) => v.toFixed(3)).join(', ')}, 0, 0, 0, ${t}, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0`;
const box = (x, y, z, a, b, c) => `ADD ${x}, ${y}, ${z}\nBLOCK ${a}, ${b}, ${c}\nDEL 1`;
const plan = 'RECT2 0, 0, A, B';

function cabinetScript(kind) {
  // A bedside unit: no handles, a shadow gap between its drawers, set back on a plinth.
  const sleek = kind === 'nightstand';
  const hung = kind === 'kitchen_wall';
  const worktop = kind === 'kitchen_base';
  const lines = [
    `MATERIAL "body"`,
    't = thick',
    `H = ZZYZX${worktop ? ' - 0.04' : ''}`,
    `base = ${hung ? 0 : 0.08}`,
    `IF base > 0 THEN`,
    box(0.03, 0.05, 0, 'A - 0.06', 'B - 0.08', 'base'),
    'ENDIF',
    box(0, 0, 'base', 't', 'B', 'H - base'),
    box('A - t', 0, 'base', 't', 'B', 'H - base'),
    box('t', 0, 'base', 'A - 2 * t', 'B', 't'),
    box('t', 0, 'H - t', 'A - 2 * t', 'B', 't'),
    box('t', 'B - 0.008', 'base + t', 'A - 2 * t', 0.008, 'H - base - 2 * t'),
    'IF shelves > 0 THEN',
    'FOR i = 1 TO shelves',
    box('t', 0.03, 'base + t + i * (H - base - 2 * t) / (shelves + 1)', 'A - 2 * t', 'B - 0.05', 't'),
    'NEXT i',
    'ENDIF',
  ];
  if (kind === 'wardrobe') lines.push(`MATERIAL "metal"`, box('t', 'B / 2 - 0.01', 'H - 0.09', 'A - 2 * t', 0.02, 0.02), `MATERIAL "body"`);
  lines.push(
    'zd = base + t',
    'hd = H - base - 2 * t',
    ...(sleek ? ['MATERIAL "glassframe"', box('t', -0.001, 'zd', 'A - 2 * t', 0.001, 'hd'), 'MATERIAL "front"', box(-0.004, -0.022, 'H - 0.016', 'A + 0.008', 'B + 0.026', 0.016)] : []),
    'IF drawers > 0 THEN',
    'dh = hd / drawers',
    'FOR i = 1 TO drawers',
    `MATERIAL "front"`,
    ...(sleek ? [box(0, -0.018, 'zd + (i - 1) * dh + 0.014', 'A', 0.018, 'dh - 0.014')] : [box('t + 0.002', -0.018, 'zd + (i - 1) * dh + 0.002', 'A - 2 * t - 0.004', 0.018, 'dh - 0.004')]),
    ...(sleek ? [] : [`MATERIAL "metal"`, box('A / 2 - 0.08', -0.038, 'zd + (i - 0.5) * dh - 0.006', 0.16, 0.02, 0.012)]),
    'NEXT i',
    'ENDIF',
    'IF drawers = 0 AND doors > 0 THEN',
    'dw = (A - 2 * t) / doors',
    'FOR i = 1 TO doors',
    `MATERIAL "front"`,
    box('t + (i - 1) * dw + 0.002', -0.018, 'zd + 0.002', 'dw - 0.004', 0.018, 'hd - 0.004'),
    `MATERIAL "metal"`,
    box('t + (i - 1) * dw + dw * (1 - (i MOD 2) * 0.86 - 0.07)', -0.038, 'zd + hd * 0.42', 0.012, 0.02, 'MIN(0.3, hd * 0.2)'),
    'NEXT i',
    'ENDIF',
  );
  if (worktop) lines.push(`MATERIAL "top"`, box(-0.02, -0.03, 'H', 'A + 0.04', 'B + 0.03', 0.04));
  return lines.join('\n');
}

function tableScript(kind) {
  const lines = ['MATERIAL "body"', box(0, 0, 'ZZYZX - thick', 'A', 'B', 'thick'), 'MATERIAL "metal"'];
  for (const [x, y] of [['0.04', '0.04'], ['A - 0.1', '0.04'], ['0.04', 'B - 0.1'], ['A - 0.1', 'B - 0.1']]) lines.push(box(x, y, 0, 0.06, 0.06, 'ZZYZX - thick'));
  if (kind === 'desk') lines.push('MATERIAL "front"', box('A - 0.45', 'B * 0.1', 'ZZYZX - thick - 0.45', 0.4, 'B * 0.8', 0.45));
  return lines.join('\n');
}

/** A pillow standing against the headboard: a rounded front, thick in the middle, leaning back. centre x, y, z; half-width, half-height, depth. */
const pillow = (x, y, z, rx, rz, t) => [
  `ADD ${x}, ${y}, ${z}`,
  'ROTX 80',
  'FOR k = 0 TO 27',
  'c = COS(k * 360 / 28)',
  's = SIN(k * 360 / 28)',
  `PUT ${rx} * SGN(c) * ABS(c) ^ 0.55, ${rz} * SGN(s) * ABS(s) ^ 0.55, 1`,
  'NEXT k',
  `PRISM_ NSP / 3, ${t}, GET(NSP)`,
  'DEL 2',
].join('\n');

function bedScript() {
  const lines = ['RESOL 28', 'MATERIAL "body"'];
  // Mattress and bedding sit in a frame; on legs the frame is a thin rail and the floor shows under it.
  lines.push('zr = IF_LEGS', 'hr = IF_RAIL');
  const leg = (x, y) => (`ADD ${x}, ${y}, 0\nCONE zr, 0.014, 0.032, 90, 90\nDEL 1`);
  lines.push('IF legs > 0 THEN', leg(0.045, 0.045), leg('A - 0.045', 0.045), leg(0.045, 'B - 0.1'), leg('A - 0.045', 'B - 0.1'), 'ELSE', box(0.03, 0.03, 0, 'A - 0.06', 'B - 0.1', 'zr'), 'ENDIF');
  lines.push(box(0, 0, 'zr', 'A', 0.028, 'hr'), box(0, 'B - 0.1', 'zr', 'A', 0.028, 'hr'), box(0, 0, 'zr', 0.028, 'B - 0.08', 'hr'), box('A - 0.028', 0, 'zr', 0.028, 'B - 0.08', 'hr'));
  lines.push(box(0.03, 0.03, 'zr + 0.03', 'A - 0.06', 'B - 0.13', 0.02));
  // A headboard leaning back a little.
  lines.push('ADD 0, B - 0.05, 0', 'ROTX -6', box(0, 0, 0, 'A', 0.05, 'ZZYZX'), 'DEL 2');
  // Mattress, bedding and pillows may come from a library instead: the frame then carries them.
  lines.push('IF bedding > 0 THEN');
  lines.push('MATERIAL "front"', box(0.035, 0.035, 'zr + hr - 0.03', 'A - 0.07', 'B - 0.14', 0.23));
  lines.push('MATERIAL "accent"', box(0.03, 0.03, 'zr + hr - 0.015', 'A - 0.06', 'B * 0.34', 0.235));
  lines.push('MATERIAL "top"', pillow('A * 0.27', 'B - 0.22', 'zr + hr + 0.34', 'A * 0.24', 0.2, 0.16), pillow('A * 0.73', 'B - 0.22', 'zr + hr + 0.34', 'A * 0.24', 0.2, 0.16));
  lines.push('MATERIAL "pillow"', pillow('A * 0.5', 'B - 0.44', 'zr + hr + 0.3', 'A * 0.17', 0.14, 0.12));
  lines.push('ENDIF');
  return lines.join('\n').replace('zr = IF_LEGS', 'zr = 0.26').replace('hr = IF_RAIL', 'hr = 0.1');
}

/** A built-in closet: glass doors in a thin dark frame over part of its width, hanging space on the left and shelves on the right, the clothes in it if asked. */
function closetScript() {
  const lines = [
    'MATERIAL "body"',
    't = thick',
    box(0, 0, 0, 't', 'B', 'ZZYZX'),
    box('A - t', 0, 0, 't', 'B', 'ZZYZX'),
    box('t', 0, 0, 'A - 2 * t', 'B', 't'),
    box('t', 0, 'ZZYZX - t', 'A - 2 * t', 'B', 't'),
    box('t', 'B - t', 't', 'A - 2 * t', 't', 'ZZYZX - 2 * t'),
    box('A / 2 - t / 2', 0.04, 't', 't', 'B - 0.04', 'ZZYZX - 2 * t'),
    'IF shelves > 0 THEN',
    'FOR i = 1 TO shelves',
    box('A / 2 + t / 2', 0.03, 't + i * (ZZYZX - 2 * t) / (shelves + 1)', 'A / 2 - 1.5 * t', 'B - 0.03', 't'),
    'NEXT i',
    'ENDIF',
    'MATERIAL "metal"',
    box('t', 'B / 2 - 0.01', 'ZZYZX - 0.32', 'A / 2 - 1.5 * t', 0.02, 0.02),
    'IF lit > 0 THEN',
    // Light: bars in the glass door's frame, a strip under the top of the shelf side.
    'MATERIAL "led"',
    'FOR i = 0 TO 1',
    box('A * cover * (0.3 + i * 0.18)', -0.008, 'ZZYZX * 0.12', 0.018, 0.004, 'ZZYZX * 0.5'),
    box('A * cover * (0.3 + i * 0.18)', -0.008, 'ZZYZX * 0.72', 0.018, 0.004, 'ZZYZX * 0.1'),
    'NEXT i',
    box('A / 2 + t', 0.05, 'ZZYZX - t - 0.012', 'A / 2 - 2 * t', 'B - 0.1', 0.01),
    'ENDIF',
    'IF filled > 0 THEN',
    // Clothes on the rail, folded piles on the shelves, shoes on the floor of the shelf side.
    'cw = (A / 2 - 1.5 * t - 0.1) / 9',
    'FOR i = 0 TO 8',
    'MATERIAL "accent"',
    'IF i MOD 3 = 1 THEN MATERIAL "pillow"',
    'IF i MOD 3 = 2 THEN MATERIAL "top"',
    box('t + 0.05 + i * cw', 'B / 2 - 0.2', 'ZZYZX - 0.32 - 1.05 - (i MOD 2) * 0.12', 'cw * 0.72', 0.4, '1.05 + (i MOD 2) * 0.12'),
    'NEXT i',
    'IF shelves > 1 THEN',
    'FOR i = 2 TO shelves',
    'z = t + i * (ZZYZX - 2 * t) / (shelves + 1) + t',
    'MATERIAL "pillow"',
    box('A * 0.62', 0.12, 'z', 'A * 0.13', 'B * 0.6', 0.05),
    'MATERIAL "accent"',
    box('A * 0.625', 0.13, 'z + 0.05', 'A * 0.12', 'B * 0.58', 0.05),
    'MATERIAL "top"',
    box('A * 0.8', 0.12, 'z', 'A * 0.12', 'B * 0.55', 0.08),
    'NEXT i',
    'ENDIF',
    // A shoe shelf that slopes up to the back, with a dark and a light pair on it.
    'ADD A / 2 + t, 0.04, t + 0.04',
    'ROTX 18',
    'MATERIAL "body"',
    box(0, 0, 0, 'A / 2 - 2 * t', 'B - 0.1', 't'),
    'FOR i = 0 TO 3',
    'MATERIAL "glassframe"',
    'IF i > 1 THEN MATERIAL "pillow"',
    box('0.04 + i * (A / 2 - 2 * t - 0.08) / 4', 0.05, 't', 0.1, 0.27, 0.08),
    'NEXT i',
    'DEL 2',
    'ENDIF',
    'n = MAX(1, doors)',
    'dw = A * cover / n',
    'IF cover > 0 THEN',
    'FOR i = 0 TO n - 1',
    'x = i * dw',
    'MATERIAL "glassframe"',
    box('x', -0.03, 0, 0.03, 0.03, 'ZZYZX'),
    box('x + dw - 0.03', -0.03, 0, 0.03, 0.03, 'ZZYZX'),
    box('x + 0.03', -0.03, 0, 'dw - 0.06', 0.03, 0.03),
    box('x + 0.03', -0.03, 'ZZYZX - 0.03', 'dw - 0.06', 0.03, 0.03),
    'MATERIAL "glass"',
    box('x + 0.03', -0.017, 0.03, 'dw - 0.06', 0.006, 'ZZYZX - 0.06'),
    'NEXT i',
    'ENDIF',
  ];
  return lines.join('\n');
}

function shoesScript() {
  const one = (x) => [box(x, 0, 0, 'A * 0.42', 'B', 0.025), 'MATERIAL "body"', pillowLike(`${x} + A * 0.21`, 'B * 0.62', 0.025, 'A * 0.2', 'B * 0.36', 'ZZYZX'), box(`${x} + A * 0.03`, 'B * 0.02', 0.025, 'A * 0.36', 'B * 0.5', 'ZZYZX * 0.4'), 'MATERIAL "front"'].join('\n');
  return ['RESOL 16', 'MATERIAL "front"', one('0'), one('A * 0.58')].join('\n');
}

/** A rounded lump: a half ellipsoid on the plane z. */
const pillowLike = (x, y, z, rx, ry, h) => `ADD ${x}, ${y}, ${z}\nMUL ${rx}, ${ry}, 1\nELLIPS ${h}, 1\nDEL 2`;

function hatScript() {
  return ['RESOL 28', 'MATERIAL "body"', 'ADD A / 2, B / 2, 0', 'CYLIND 0.008, MIN(A, B) / 2', 'MATERIAL "front"', 'CYLIND ZZYZX * 0.2, MIN(A, B) * 0.3', 'MATERIAL "body"', 'ADDZ ZZYZX * 0.2', 'ELLIPS ZZYZX * 0.8, MIN(A, B) * 0.3', 'DEL 2'].join('\n');
}

function foldedScript() {
  const lines = ['h = ZZYZX / 4'];
  ['"body"', '"front"', '"top"', '"accent"'].forEach((m, i) => lines.push(`MATERIAL ${m}`, box(`${i % 2 ? 0.006 : 0}`, 0, `${i} * h`, 'A - 0.012', 'B', 'h * 0.96')));
  return lines.join('\n');
}

/** A socket or switch on a wall: back to the wall at y = B, its plate facing -y; doors is the number of outlets. */
function plateScript() {
  return ['MATERIAL "body"', box(0, 0, 0, 'A', 'B', 'ZZYZX'), 'MATERIAL "front"', 'n = MAX(1, doors)', 'FOR i = 0 TO n - 1', box('A * (i + 0.2) / n', -0.001, 'ZZYZX * 0.25', 'A * 0.6 / n', 0.001, 'ZZYZX * 0.5'), 'NEXT i'].join('\n');
}

/** A strip of light along the top of a wall: it lights the wall with several lamps along its length. */
function coveScript() {
  return ['MATERIAL "body"', box(0, 0, 0, 'A', 'B', 'ZZYZX')].join('\n');
}

/** A round side table: a thin top wider than what carries it, on a stem and small foot or on a solid drum. */
function roundTableScript() {
  return ['RESOL 36', 'MATERIAL "body"', 'ADD A / 2, B / 2, 0', 'IF drum > 0 THEN', 'CYLIND ZZYZX - 0.008, MIN(A, B) * 0.36', 'ELSE', 'CYLIND 0.012, MIN(A, B) * 0.3', 'CYLIND ZZYZX, 0.018', 'ENDIF', 'ADDZ ZZYZX - 0.008', 'CYLIND 0.008, MIN(A, B) / 2', 'DEL 2'].join('\n');
}

/** A curtain: a thin sheet folded in waves, drawn from a rail at its top. */
function curtainScript() {
  return [
    'MATERIAL "body"',
    'n = MAX(8, INT(A / 0.02))',
    'FOR i = 0 TO n',
    'x = A * i / n',
    'PUT x, B / 2 + (B / 2 - 0.006) * SIN(360 * x / 0.2), 1',
    'NEXT i',
    'FOR i = n TO 0 STEP -1',
    'x = A * i / n',
    'PUT x, B / 2 + (B / 2 - 0.006) * SIN(360 * x / 0.2) + 0.005, 1',
    'NEXT i',
    'PRISM_ NSP / 3, ZZYZX, GET(NSP)',
    'MATERIAL "metal"',
    box(0, 'B / 2 - 0.01', 'ZZYZX', 'A', 0.02, 0.02),
  ].join('\n');
}

/** A picture: frame and canvas; the canvas shows a colour or, when it has one, the object's own image (its picture 1), which goes wherever the object goes. */
function pictureScript(showsImage) {
  const lines = ['MATERIAL "body"', box(0, 0.002, 0, 'A', 'B - 0.002', 'ZZYZX'), 'MATERIAL "top"', box('frame', 0.001, 'frame', 'A - 2 * frame', 0.001, 'ZZYZX - 2 * frame')];
  if (showsImage) lines.push('ADD frame, 0, frame', 'ROTX 90', 'PICTURE 1, A - 2 * frame, ZZYZX - 2 * frame, 0', 'DEL 2');
  return lines.join('\n');
}

function lampScript() {
  return [
    'MATERIAL "body"',
    'ADD A / 2, B / 2, 0',
    'RESOL 32',
    'CYLIND 0.012, MIN(A, B) * 0.22',
    'CONE ZZYZX * 0.74, MIN(A, B) * 0.17, MIN(A, B) * 0.12, 90, 90',
    'MATERIAL "front"',
    'ADDZ ZZYZX * 0.68',
    'ELLIPS ZZYZX * 0.32, MIN(A, B) / 2',
    'DEL 2',
  ].join('\n');
}

function plan2D(kind) {
  if (kind === 'bed') return `${plan}\nLINE2 0, B - 0.65, A, B - 0.65\nRECT2 A * 0.06, B - 0.55, A * 0.46, B - 0.13\nRECT2 A * 0.54, B - 0.55, A * 0.94, B - 0.13`;
  if (kind === 'table' || kind === 'desk' || kind === 'picture') return plan;
  if (kind === 'round_table' || kind === 'table_lamp') return 'CIRCLE2 A / 2, B / 2, MIN(A, B) / 2';
  if (kind === 'rug') return `${plan}\nRECT2 0.06, 0.06, A - 0.06, B - 0.06`;
  if (kind === 'curtain') return `${plan}\nLINE2 0, B / 2, A, B / 2`;
  // A socket or a switch as drawings show them: a circle with a stroke, or two for a switch.
  if (kind === 'wall_plate') return `${plan}\nCIRCLE2 A / 2, -0.08, 0.05\nLINE2 A / 2, -0.03, A / 2, 0`;
  if (['shoes', 'hat', 'folded_clothes', 'cove_light'].includes(kind)) return plan;
  // Doors shown by their joints along the front.
  return `${plan}\nLINE2 0, 0.02, A, 0.02\nIF doors > 1 THEN\nFOR i = 1 TO doors - 1\nLINE2 A * i / doors, 0, A * i / doors, 0.05\nNEXT i\nENDIF`;
}

/**
 * A GDL object definition for a piece of furniture, in the form a component type holds:
 * { name, category, width, depth, height, gdl: { params, script3d, script2d } }. spec: { kind, width, depth, height (mm), doors, drawers, shelves, color, front_color, top_color, accent_color, pillow_color, glass_share (closet: 0..1 of its width behind glass), frame (picture, mm), image (picture: a data URL it shows), name }.
 */
export function furnitureObject(spec = {}) {
  const kind = FURNITURE_KINDS.includes(spec.kind) ? spec.kind : 'cabinet';
  const d = DEFAULTS[kind];
  const num = (v, fb) => (Number.isFinite(+v) && v !== null && v !== '' ? +v : fb);
  const thin = ['rug', 'curtain', 'picture', 'shoes', 'hat', 'folded_clothes', 'wall_plate', 'cove_light', 'table_lamp'].includes(kind);
  const width = Math.max(thin ? 30 : 200, num(spec.width, d.width));
  const depth = Math.max(thin ? 5 : 100, num(spec.depth, d.depth));
  const height = Math.max(thin ? 3 : 100, num(spec.height, d.height));
  const body = colorOf(spec.color, kind === 'bed' ? COLORS.oak : kind === 'closet' ? COLORS.walnut : COLORS.white);
  const front = colorOf(spec.front_color ?? spec.color, kind === 'bed' ? COLORS.beige : body);
  const top = colorOf(spec.top_color, kind === 'bed' ? COLORS.white : COLORS.grey);
  const accent = colorOf(spec.accent_color ?? spec.front_color, front);
  const soft = colorOf(spec.pillow_color ?? spec.top_color, top);
  // A curtain is sheer unless asked otherwise.
  const bodyDef = kind === 'curtain' && spec.opaque !== true ? seeThrough('body', body, 0.28) : material('body', body);
  const defs = [bodyDef, material('front', front), material('top', top), material('accent', accent), material('pillow', soft), material('metal', [0.45, 0.45, 0.47]), material('glassframe', [0.07, 0.07, 0.08]), material('led', [1, 0.96, 0.84]), seeThrough('glass', [0.55, 0.6, 0.62], 0.75)].join('\n');
  const scripts = { bed: bedScript, closet: closetScript, round_table: roundTableScript, rug: () => `MATERIAL "body"\n${box(0, 0, 0, 'A', 'B', 'ZZYZX')}`, curtain: curtainScript, picture: () => pictureScript(!!spec.image), table_lamp: lampScript, shoes: shoesScript, hat: hatScript, folded_clothes: foldedScript, wall_plate: plateScript, cove_light: coveScript };
  const script = scripts[kind] ? scripts[kind]() : kind === 'table' || kind === 'desk' ? tableScript(kind) : cabinetScript(kind);
  const params = [
    { name: 'thick', label: 'Panel thickness', kind: 'length', value: kind === 'table' || kind === 'desk' ? 30 : 18 },
    { name: 'doors', label: 'Doors', kind: 'integer', value: Math.max(0, Math.round(num(spec.doors, d.doors))) },
    { name: 'drawers', label: 'Drawers', kind: 'integer', value: Math.max(0, Math.round(num(spec.drawers, d.drawers))) },
    { name: 'shelves', label: 'Shelves', kind: 'integer', value: Math.max(0, Math.round(num(spec.shelves, d.shelves))) },
  ];
  if (kind === 'closet') params.push({ name: 'cover', label: 'Share behind glass', kind: 'number', value: Math.max(0, Math.min(1, num(spec.glass_share, 0.5))) });
  if (kind === 'closet') params.push({ name: 'lit', label: 'Lit inside', kind: 'integer', value: spec.lit ? 1 : 0 });
  if (kind === 'bed') params.push({ name: 'legs', label: 'On legs', kind: 'integer', value: spec.legs === false ? 0 : 1 }, { name: 'bedding', label: 'With bedding', kind: 'integer', value: spec.bedding === false ? 0 : 1 });
  if (kind === 'round_table') params.push({ name: 'drum', label: 'Solid drum base', kind: 'integer', value: spec.base === 'drum' ? 1 : 0 });
  if (kind === 'closet') params.push({ name: 'filled', label: 'With clothes', kind: 'integer', value: spec.filled === false ? 0 : 1 });
  if (kind === 'picture') params.push({ name: 'frame', label: 'Frame width', kind: 'length', value: Math.max(0, num(spec.frame, 0)) });
  const label = { wardrobe: 'Wardrobe', cabinet: 'Cabinet', bookcase: 'Bookcase', kitchen_base: 'Kitchen base unit', kitchen_wall: 'Kitchen wall unit', desk: 'Desk', table: 'Table', bed: 'Bed', closet: 'Glass closet', nightstand: 'Bedside unit', round_table: 'Round side table', rug: 'Rug', curtain: 'Curtain', picture: 'Picture', table_lamp: 'Table lamp', shoes: 'Shoes', hat: 'Hat', folded_clothes: 'Folded clothes', wall_plate: spec.function === 'switch' ? 'Switch' : 'Socket', cove_light: 'Cove light' }[kind];
  return {
    name: spec.name || `${label} ${Math.round(width)} x ${Math.round(depth)} x ${Math.round(height)}`,
    category: kind.startsWith('kitchen') ? 'casework' : ['table_lamp', 'cove_light'].includes(kind) ? 'lighting' : kind === 'wall_plate' ? 'electricalFixtures' : 'furniture',
    ...(kind === 'bed' ? { supportHeight: 310 } : {}),
    ...(kind === 'wall_plate' ? { electricalLoad: spec.function === 'switch' ? 0 : 200, plateFunction: spec.function === 'switch' ? 'switch' : 'socket' } : {}),
    ...(kind === 'cove_light' ? { lightLine: true, lightKelvin: 3800, lightLumens: Math.round((width / 1000) * 700) } : {}),
    ...(kind === 'closet' && spec.lit ? { lightLine: true, lightHigh: true, lightKelvin: 3800, lightLumens: 900 } : {}),
    width,
    depth,
    height,
    gdl: { params, script3d: `${defs}\n${script}`, script2d: plan2D(kind), ...(spec.image ? { pictures: { 1: spec.image } } : {}) },
  };
}

/** English search words for the Italian names people use. */
const WORDS = { armadio: 'wardrobe', armadi: 'wardrobe', guardaroba: 'wardrobe', divano: 'sofa couch', poltrona: 'armchair', letto: 'bed', comodino: 'nightstand bedside', tavolo: 'table', tavolino: 'coffee table', scrivania: 'desk', sedia: 'chair', sgabello: 'stool', libreria: 'bookcase shelf', mensola: 'shelf', cucina: 'kitchen counter', frigorifero: 'fridge refrigerator', forno: 'oven range', lavello: 'sink', lavandino: 'sink', lavabo: 'sink vanity washbasin', wc: 'toilet', water: 'toilet', bidet: 'bidet', doccia: 'shower', vasca: 'bath tub bathtub', lampada: 'lamp light', scarpe: 'shoes shoe', cappello: 'hat', vestiti: 'clothes folded', libri: 'book', presa: 'socket plate', interruttore: 'switch plate', faretto: 'spot recessed', gola: 'cove', vassoio: 'tray', vaso: 'vase',  lampadario: 'chandelier pendant lamp', tappeto: 'rug carpet', pianta: 'plant', albero: 'tree', specchio: 'mirror', tenda: 'curtain', televisore: 'tv television', lavatrice: 'washing machine', caminetto: 'fireplace', mobile: 'cabinet', credenza: 'sideboard cabinet', persona: 'person people', auto: 'car' };

/** The words to look for: the query's own, and their English names. */
export function searchWords(query) {
  const own = String(query ?? '').toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  return own.map((w) => [w, ...(WORDS[w] || '').split(' ').filter(Boolean)]);
}

/** Whether a text answers a query: each word of it, in Italian or English, is found. */
export function matchesQuery(text, query) {
  const t = String(text ?? '').toLowerCase();
  return searchWords(query).every((alts) => alts.some((a) => t.includes(a)));
}

/**
 * Where an object goes against a side of a rectangular extent { x0, y0, x1, y1 }: { at, rotation }, its back to the wall.
 * side: north, south, east, west; along: 0 start .. 1 end of the side (0.5 by default). w, d: its width and depth.
 */
export function placeAgainst(box, side, w, d, along = 0.5, gap = 10) {
  const a = Math.max(0, Math.min(1, along));
  const lerp = (p, q, half) => p + half + (q - p - 2 * half) * a;
  if (side === 'north') return { at: [lerp(box.x0, box.x1, w / 2), box.y1 - d / 2 - gap], rotation: 0 };
  if (side === 'south') return { at: [lerp(box.x0, box.x1, w / 2), box.y0 + d / 2 + gap], rotation: 180 };
  if (side === 'east') return { at: [box.x1 - d / 2 - gap, lerp(box.y0, box.y1, w / 2)], rotation: -90 };
  return { at: [box.x0 + d / 2 + gap, lerp(box.y0, box.y1, w / 2)], rotation: 90 };
}
