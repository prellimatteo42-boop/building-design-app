/**
 * Parametric furniture as GDL objects: wardrobes, cabinets, bookcases, kitchen units, desks, tables and beds.
 * Width A, depth B and height ZZYZX stay parameters of the object, as do doors, drawers and shelves, so each
 * piece can be changed afterwards. Its back is at y = B and its front at y = 0.
 */
export const FURNITURE_KINDS = ['wardrobe', 'cabinet', 'bookcase', 'kitchen_base', 'kitchen_wall', 'desk', 'table', 'bed'];

const DEFAULTS = {
  wardrobe: { width: 2400, depth: 600, height: 2300, doors: 3, drawers: 0, shelves: 3 },
  cabinet: { width: 1200, depth: 450, height: 800, doors: 2, drawers: 0, shelves: 1 },
  bookcase: { width: 900, depth: 300, height: 2000, doors: 0, drawers: 0, shelves: 4 },
  kitchen_base: { width: 1800, depth: 600, height: 900, doors: 3, drawers: 0, shelves: 1 },
  kitchen_wall: { width: 1800, depth: 350, height: 700, doors: 3, drawers: 0, shelves: 1 },
  desk: { width: 1400, depth: 700, height: 750, doors: 0, drawers: 0, shelves: 0 },
  table: { width: 1600, depth: 900, height: 750, doors: 0, drawers: 0, shelves: 0 },
  bed: { width: 1600, depth: 2000, height: 900, doors: 0, drawers: 0, shelves: 0 },
};

const COLORS = {
  white: [0.93, 0.93, 0.91], bianco: [0.93, 0.93, 0.91], black: [0.1, 0.1, 0.1], nero: [0.1, 0.1, 0.1], grey: [0.55, 0.55, 0.55], grigio: [0.55, 0.55, 0.55], oak: [0.72, 0.56, 0.38], rovere: [0.72, 0.56, 0.38], walnut: [0.36, 0.23, 0.14], noce: [0.36, 0.23, 0.14], wood: [0.62, 0.45, 0.28], legno: [0.62, 0.45, 0.28], blue: [0.2, 0.33, 0.55], blu: [0.2, 0.33, 0.55], green: [0.3, 0.45, 0.32], verde: [0.3, 0.45, 0.32], red: [0.6, 0.18, 0.15], rosso: [0.6, 0.18, 0.15], beige: [0.82, 0.76, 0.65], sand: [0.82, 0.76, 0.65],
};

/** An RGB triple from a colour name or #rrggbb; `fallback` when it is neither. */
export function colorOf(name, fallback = COLORS.white) {
  const s = String(name ?? '').trim().toLowerCase();
  if (COLORS[s]) return COLORS[s];
  const m = /^#([0-9a-f]{6})$/.exec(s);
  if (m) return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16) / 255);
  return fallback;
}

const material = (name, c) => `DEFINE MATERIAL "${name}" 2, ${c.map((v) => v.toFixed(3)).join(', ')}`;
const box = (x, y, z, a, b, c) => `ADD ${x}, ${y}, ${z}\nBLOCK ${a}, ${b}, ${c}\nDEL 1`;
const plan = 'RECT2 0, 0, A, B';

function cabinetScript(kind) {
  const hung = kind === 'kitchen_wall';
  const worktop = kind === 'kitchen_base';
  const lines = [
    `MATERIAL "body"`,
    't = thick',
    `H = ZZYZX${worktop ? ' - 0.04' : ''}`,
    `base = ${hung ? 0 : 0.08}`,
    `IF base > 0 THEN`,
    box(0.03, 0.05, 0, 'A - 0.06', 'B - 0.08', 'base'),
    'ENDIF',
    box(0, 0, 'base', 't', 'B', 'H - base'),
    box('A - t', 0, 'base', 't', 'B', 'H - base'),
    box('t', 0, 'base', 'A - 2 * t', 'B', 't'),
    box('t', 0, 'H - t', 'A - 2 * t', 'B', 't'),
    box('t', 'B - 0.008', 'base + t', 'A - 2 * t', 0.008, 'H - base - 2 * t'),
    'IF shelves > 0 THEN',
    'FOR i = 1 TO shelves',
    box('t', 0.03, 'base + t + i * (H - base - 2 * t) / (shelves + 1)', 'A - 2 * t', 'B - 0.05', 't'),
    'NEXT i',
    'ENDIF',
  ];
  if (kind === 'wardrobe') lines.push(`MATERIAL "metal"`, box('t', 'B / 2 - 0.01', 'H - 0.09', 'A - 2 * t', 0.02, 0.02), `MATERIAL "body"`);
  lines.push(
    'zd = base + t',
    'hd = H - base - 2 * t',
    'IF drawers > 0 THEN',
    'dh = hd / drawers',
    'FOR i = 1 TO drawers',
    `MATERIAL "front"`,
    box('t + 0.002', -0.018, 'zd + (i - 1) * dh + 0.002', 'A - 2 * t - 0.004', 0.018, 'dh - 0.004'),
    `MATERIAL "metal"`,
    box('A / 2 - 0.08', -0.038, 'zd + (i - 0.5) * dh - 0.006', 0.16, 0.02, 0.012),
    'NEXT i',
    'ENDIF',
    'IF drawers = 0 AND doors > 0 THEN',
    'dw = (A - 2 * t) / doors',
    'FOR i = 1 TO doors',
    `MATERIAL "front"`,
    box('t + (i - 1) * dw + 0.002', -0.018, 'zd + 0.002', 'dw - 0.004', 0.018, 'hd - 0.004'),
    `MATERIAL "metal"`,
    box('t + (i - 1) * dw + dw * (1 - (i MOD 2) * 0.86 - 0.07)', -0.038, 'zd + hd * 0.42', 0.012, 0.02, 'MIN(0.3, hd * 0.2)'),
    'NEXT i',
    'ENDIF',
  );
  if (worktop) lines.push(`MATERIAL "top"`, box(-0.02, -0.03, 'H', 'A + 0.04', 'B + 0.03', 0.04));
  return lines.join('\n');
}

function tableScript(kind) {
  const lines = ['MATERIAL "body"', box(0, 0, 'ZZYZX - thick', 'A', 'B', 'thick'), 'MATERIAL "metal"'];
  for (const [x, y] of [['0.04', '0.04'], ['A - 0.1', '0.04'], ['0.04', 'B - 0.1'], ['A - 0.1', 'B - 0.1']]) lines.push(box(x, y, 0, 0.06, 0.06, 'ZZYZX - thick'));
  if (kind === 'desk') lines.push('MATERIAL "front"', box('A - 0.45', 'B * 0.1', 'ZZYZX - thick - 0.45', 0.4, 'B * 0.8', 0.45));
  return lines.join('\n');
}

function bedScript() {
  return [
    'MATERIAL "body"',
    box(0, 0, 0.1, 'A', 'B', 0.2),
    box('A * 0.02', 'B - 0.08', 0, 'A * 0.96', 0.08, 'ZZYZX'),
    box(0.02, 0.02, 0, 0.06, 0.06, 0.1),
    box('A - 0.08', 0.02, 0, 0.06, 0.06, 0.1),
    'MATERIAL "front"',
    box(0.02, 0.02, 0.3, 'A - 0.04', 'B - 0.1', 0.2),
    'MATERIAL "top"',
    box('A * 0.06', 'B - 0.55', 0.5, 'A * 0.4', 0.42, 0.12),
    box('A * 0.54', 'B - 0.55', 0.5, 'A * 0.4', 0.42, 0.12),
  ].join('\n');
}

function plan2D(kind) {
  if (kind === 'bed') return `${plan}\nLINE2 0, B - 0.65, A, B - 0.65\nRECT2 A * 0.06, B - 0.55, A * 0.46, B - 0.13\nRECT2 A * 0.54, B - 0.55, A * 0.94, B - 0.13`;
  if (kind === 'table' || kind === 'desk') return plan;
  // Doors shown by their joints along the front.
  return `${plan}\nLINE2 0, 0.02, A, 0.02\nIF doors > 1 THEN\nFOR i = 1 TO doors - 1\nLINE2 A * i / doors, 0, A * i / doors, 0.05\nNEXT i\nENDIF`;
}

/**
 * A GDL object definition for a piece of furniture, in the form a component type holds:
 * { name, category, width, depth, height, gdl: { params, script3d, script2d } }. spec: { kind, width, depth, height (mm), doors, drawers, shelves, color, front_color, top_color, name }.
 */
export function furnitureObject(spec = {}) {
  const kind = FURNITURE_KINDS.includes(spec.kind) ? spec.kind : 'cabinet';
  const d = DEFAULTS[kind];
  const num = (v, fb) => (Number.isFinite(+v) && v !== null && v !== '' ? +v : fb);
  const width = Math.max(200, num(spec.width, d.width));
  const depth = Math.max(100, num(spec.depth, d.depth));
  const height = Math.max(100, num(spec.height, d.height));
  const body = colorOf(spec.color, kind === 'bed' ? COLORS.oak : COLORS.white);
  const front = colorOf(spec.front_color ?? spec.color, kind === 'bed' ? COLORS.beige : body);
  const top = colorOf(spec.top_color, kind === 'bed' ? COLORS.white : COLORS.grey);
  const defs = [material('body', body), material('front', front), material('top', top), material('metal', [0.45, 0.45, 0.47])].join('\n');
  const script = kind === 'bed' ? bedScript() : kind === 'table' || kind === 'desk' ? tableScript(kind) : cabinetScript(kind);
  const params = [
    { name: 'thick', label: 'Panel thickness', kind: 'length', value: kind === 'table' || kind === 'desk' ? 30 : 18 },
    { name: 'doors', label: 'Doors', kind: 'integer', value: Math.max(0, Math.round(num(spec.doors, d.doors))) },
    { name: 'drawers', label: 'Drawers', kind: 'integer', value: Math.max(0, Math.round(num(spec.drawers, d.drawers))) },
    { name: 'shelves', label: 'Shelves', kind: 'integer', value: Math.max(0, Math.round(num(spec.shelves, d.shelves))) },
  ];
  const label = { wardrobe: 'Wardrobe', cabinet: 'Cabinet', bookcase: 'Bookcase', kitchen_base: 'Kitchen base unit', kitchen_wall: 'Kitchen wall unit', desk: 'Desk', table: 'Table', bed: 'Bed' }[kind];
  return {
    name: spec.name || `${label} ${Math.round(width)} x ${Math.round(depth)} x ${Math.round(height)}`,
    category: kind.startsWith('kitchen') ? 'casework' : 'furniture',
    width,
    depth,
    height,
    gdl: { params, script3d: `${defs}\n${script}`, script2d: plan2D(kind) },
  };
}

/** English search words for the Italian names people use. */
const WORDS = { armadio: 'wardrobe', armadi: 'wardrobe', guardaroba: 'wardrobe', divano: 'sofa couch', poltrona: 'armchair', letto: 'bed', comodino: 'nightstand bedside', tavolo: 'table', tavolino: 'coffee table', scrivania: 'desk', sedia: 'chair', sgabello: 'stool', libreria: 'bookcase shelf', mensola: 'shelf', cucina: 'kitchen counter', frigorifero: 'fridge refrigerator', forno: 'oven range', lavello: 'sink', lavandino: 'sink', lavabo: 'sink vanity washbasin', wc: 'toilet', water: 'toilet', bidet: 'bidet', doccia: 'shower', vasca: 'bath tub bathtub', lampada: 'lamp light', lampadario: 'chandelier pendant lamp', tappeto: 'rug carpet', pianta: 'plant', albero: 'tree', specchio: 'mirror', tenda: 'curtain', televisore: 'tv television', lavatrice: 'washing machine', caminetto: 'fireplace', mobile: 'cabinet', credenza: 'sideboard cabinet', persona: 'person people', auto: 'car' };

/** The words to look for: the query's own, and their English names. */
export function searchWords(query) {
  const own = String(query ?? '').toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  return own.map((w) => [w, ...(WORDS[w] || '').split(' ').filter(Boolean)]);
}

/** Whether a text answers a query: each word of it, in Italian or English, is found. */
export function matchesQuery(text, query) {
  const t = String(text ?? '').toLowerCase();
  return searchWords(query).every((alts) => alts.some((a) => t.includes(a)));
}

/**
 * Where an object goes against a side of a rectangular extent { x0, y0, x1, y1 }: { at, rotation }, its back to the wall.
 * side: north, south, east, west; along: 0 start .. 1 end of the side (0.5 by default). w, d: its width and depth.
 */
export function placeAgainst(box, side, w, d, along = 0.5, gap = 10) {
  const a = Math.max(0, Math.min(1, along));
  const lerp = (p, q, half) => p + half + (q - p - 2 * half) * a;
  if (side === 'north') return { at: [lerp(box.x0, box.x1, w / 2), box.y1 - d / 2 - gap], rotation: 0 };
  if (side === 'south') return { at: [lerp(box.x0, box.x1, w / 2), box.y0 + d / 2 + gap], rotation: 180 };
  if (side === 'east') return { at: [box.x1 - d / 2 - gap, lerp(box.y0, box.y1, w / 2)], rotation: -90 };
  return { at: [box.x0 + d / 2 + gap, lerp(box.y0, box.y1, w / 2)], rotation: 90 };
}
