/**
 * Circular arcs for curved walls. An arc runs from a to b turning by
 * `sweep` radians (positive counterclockwise). Positions along it are arc
 * lengths u from a; offsets are along the left normal of the direction of
 * travel (towards the centre when the arc turns left).
 */
import { sub, len, norm, perp, add, scale } from './geom.js';

/** { c, r, a0, sweep, length } of the arc from a to b, or null for a straight run. */
export function arcOf(a, b, sweep) {
  const s = +sweep || 0;
  const chord = len(sub(b, a));
  if (Math.abs(s) < 1e-4 || chord < 1e-6) return null;
  const r = chord / (2 * Math.sin(Math.abs(s) / 2));
  const mid = scale(add(a, b), 0.5);
  const n = perp(norm(sub(b, a)));
  const c = add(mid, scale(n, Math.sign(s) * r * Math.cos(s / 2)));
  const a0 = Math.atan2(a[1] - c[1], a[0] - c[0]);
  return { c, r, a0, sweep: s, length: r * Math.abs(s) };
}

/** The same arc with its radius moved by an offset along the left normal. */
export function offsetArc(arc, off) {
  const r = arc.r - Math.sign(arc.sweep) * off;
  return { ...arc, r, length: r * Math.abs(arc.sweep) };
}

const angleAt = (arc, u) => arc.a0 + (arc.sweep * u) / (arc.length || 1);

/** Point at arc length u, offset along the left normal. */
export function arcPoint(arc, u, off = 0) {
  const t = angleAt(arc, u);
  const rr = arc.r - Math.sign(arc.sweep) * off;
  return [arc.c[0] + Math.cos(t) * rr, arc.c[1] + Math.sin(t) * rr];
}

/** Unit direction of travel at arc length u. */
export function arcTangent(arc, u) {
  const t = angleAt(arc, u);
  const s = Math.sign(arc.sweep);
  return [-Math.sin(t) * s, Math.cos(t) * s];
}

/** Arc length of the point on the arc nearest p (may fall outside 0..length). */
export function arcParam(arc, p) {
  let d = Math.atan2(p[1] - arc.c[1], p[0] - arc.c[0]) - arc.a0;
  const s = Math.sign(arc.sweep);
  // Unwrap in the direction of travel, centred on the middle of the arc.
  const mid = arc.sweep / 2;
  while (s * (d - mid) > Math.PI) d -= s * 2 * Math.PI;
  while (s * (d - mid) < -Math.PI) d += s * 2 * Math.PI;
  return (d / arc.sweep) * arc.length;
}

/** Sweep of the arc from a to b through m (three points), or 0 when they line up. */
export function sweepThrough(a, m, b) {
  const ax = a[0], ay = a[1], bx = m[0], by = m[1], cx = b[0], cy = b[1];
  const d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));
  if (Math.abs(d) < 1e-9) return 0;
  const ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d;
  const uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d;
  const ang = (p) => Math.atan2(p[1] - uy, p[0] - ux);
  const norm2 = (x) => ((x % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
  const toM = norm2(ang(m) - ang(a));
  const toB = norm2(ang(b) - ang(a));
  // Counterclockwise if m comes before b going counterclockwise from a.
  return toM < toB ? toB : -(2 * Math.PI - toB);
}

/** Arc lengths splitting [u0, u1] into steps of at most maxAngle radians, ends included. */
export function arcSteps(arc, u0, u1, maxAngle = Math.PI / 36) {
  const span = Math.abs(((u1 - u0) / (arc.length || 1)) * arc.sweep);
  const n = Math.max(1, Math.ceil(span / maxAngle));
  const out = [];
  for (let i = 0; i <= n; i++) out.push(u0 + ((u1 - u0) * i) / n);
  return out;
}
