/**
 * Grid System, as in Archicad: a whole grid at once from spacings. Lines
 * across x are numbered (1, 2, 3...), lines across y lettered (A, B, C...);
 * every line overhangs the grid by `overhang`. Optional associative
 * dimension chains measure the spacings and the overall size.
 */
import { add } from './geom.js';

/** Spacings from text such as "5000, 2x4000, 3500" (n x d repeats d). */
export function parseSpacings(text, parse = (s) => +s) {
  const out = [];
  for (const part of String(text || '').split(/[,;]+/)) {
    const t = part.trim();
    if (!t) continue;
    const m = t.match(/^(\d+)\s*[x*]\s*(.+)$/i);
    const n = m ? Math.min(100, +m[1]) : 1;
    const d = parse(m ? m[2] : t);
    if (!Number.isFinite(d) || d <= 0) return null;
    for (let i = 0; i < n; i++) out.push(d);
  }
  return out;
}

/** Spreadsheet-style letters: A ... Z, AA, AB ... */
export function letterName(i) {
  let s = '';
  let n = i + 1;
  while (n > 0) {
    const r = (n - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

/**
 * Grid elements (and dimension chains when viewId is given), not yet added.
 * opts: { origin, xs, ys (spacings), firstNumber, firstLetter (index), overhang, viewId, dimOffset }
 */
export function gridSystem({ origin = [0, 0], xs = [], ys = [], firstNumber = 1, firstLetter = 0, overhang = 2500, viewId = null, dimOffset = 1500 }) {
  const xAt = [0];
  for (const d of xs) xAt.push(xAt.at(-1) + d);
  const yAt = [0];
  for (const d of ys) yAt.push(yAt.at(-1) + d);
  const W = xAt.at(-1);
  const H = yAt.at(-1);
  const P = (x, y) => add(origin, [x, y]);
  const grids = [];
  xAt.forEach((x, i) => grids.push({ kind: 'grid', name: String(firstNumber + i), a: P(x, -overhang), b: P(x, H + overhang), bubbles: 'both', axis: 'x', i }));
  yAt.forEach((y, i) => grids.push({ kind: 'grid', name: letterName(firstLetter + i), a: P(-overhang, y), b: P(W + overhang, y), bubbles: 'both', axis: 'y', i }));
  const dims = [];
  if (viewId) {
    // Below the grid along x, left of it along y: spacings, then the overall size.
    const chain = (axis, list, off) => {
      const along = axis === 'x';
      const line = along ? P(0, -off) : P(-off, 0);
      return { kind: 'dimension', viewId, dir: along ? [1, 0] : [0, 1], line, refs: list.map((g) => ({ gridIndex: grids.indexOf(g), at: along ? [g.a[0], line[1]] : [line[0], g.a[1]] })) };
    };
    const gx = grids.filter((g) => g.axis === 'x');
    const gy = grids.filter((g) => g.axis === 'y');
    if (gx.length > 1) dims.push(chain('x', gx, dimOffset), ...(gx.length > 2 ? [chain('x', [gx[0], gx.at(-1)], dimOffset * 1.6)] : []));
    if (gy.length > 1) dims.push(chain('y', gy, dimOffset), ...(gy.length > 2 ? [chain('y', [gy[0], gy.at(-1)], dimOffset * 1.6)] : []));
  }
  return { grids, dims };
}
