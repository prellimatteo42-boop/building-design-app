/**
 * Annual energy balance, as Archicad's Energy Evaluation reports it: the
 * heating and cooling needs month by month, the energy the systems deliver
 * for them, its primary energy, CO₂ emissions and cost. A monthly
 * quasi-steady-state method in the spirit of EN ISO 13790 / 52016-1:
 *
 *   - losses: (H_T + H_V) · (θ_set − θ_e,month) · hours, with H_T and H_V
 *     from the zone heat-loss report (energy.js);
 *   - gains: internal (W/m² of floor) and solar through the windows, from
 *     the irradiation on each window's orientation (clear-sky days scaled
 *     by a clearness index, beam and diffuse on a vertical surface);
 *   - gains utilisation by the building's time constant;
 *   - needs to delivered energy by the systems' efficiency, then primary
 *     energy, CO₂ and cost by the energy source factors.
 *
 * A screening estimate for comparing design options, not a dynamic
 * simulation. Climate: monthly mean temperatures of a city in the list
 * (approximate long-term values) or of the project's own entries.
 *
 *   project.energy { climate: { name, temps: [12], kt }, internalGains (W/m²), mass ('light'|'medium'|'heavy'),
 *                    cooling (°C set point), heating: { source, efficiency }, coolingSystem: { source, efficiency }, sources: { [id]: { primary, co2, price } } }
 */
import { energyReport } from './energy.js';
import { DEFAULT_LOCATION } from './sun.js';
import { hourlyClimate, simulateBlock, irradiationOn } from './energyhourly.js';

export const CLIMATES = [
  { name: 'Milano', lat: 45.46, temps: [2.5, 4.7, 9.0, 13.1, 17.4, 21.6, 24.2, 23.6, 19.4, 14.0, 8.2, 3.6], kt: 0.45 },
  { name: 'Torino', lat: 45.07, temps: [1.6, 3.6, 8.2, 12.3, 16.5, 20.6, 23.1, 22.3, 18.3, 12.6, 6.8, 2.6], kt: 0.48 },
  { name: 'Venezia', lat: 45.44, temps: [3.3, 4.9, 8.6, 12.6, 17.4, 21.4, 23.7, 23.3, 19.6, 14.6, 9.2, 4.6], kt: 0.48 },
  { name: 'Bologna', lat: 44.49, temps: [2.1, 4.4, 9.0, 13.2, 17.9, 22.4, 25.1, 24.4, 19.8, 14.1, 8.1, 3.3], kt: 0.48 },
  { name: 'Firenze', lat: 43.77, temps: [5.6, 7.0, 10.0, 13.1, 17.5, 21.8, 24.8, 24.6, 20.7, 15.6, 10.1, 6.3], kt: 0.5 },
  { name: 'Roma', lat: 41.9, temps: [8.3, 9.0, 11.4, 14.0, 18.3, 22.4, 25.3, 25.6, 22.0, 17.6, 12.9, 9.5], kt: 0.53 },
  { name: 'Napoli', lat: 40.85, temps: [9.4, 9.9, 12.0, 14.6, 18.7, 22.6, 25.6, 25.8, 22.6, 18.4, 13.8, 10.6], kt: 0.53 },
  { name: 'Bari', lat: 41.12, temps: [8.7, 9.3, 11.4, 14.3, 18.6, 22.9, 25.6, 25.6, 22.3, 18.0, 13.5, 10.0], kt: 0.55 },
  { name: 'Palermo', lat: 38.12, temps: [11.6, 11.8, 13.4, 15.8, 19.4, 23.4, 26.3, 26.8, 24.0, 20.2, 16.2, 12.9], kt: 0.56 },
  { name: 'London', lat: 51.51, temps: [5.2, 5.3, 7.6, 9.9, 13.3, 16.5, 18.7, 18.5, 15.7, 12.0, 8.0, 5.5], kt: 0.38 },
  { name: 'Paris', lat: 48.86, temps: [5.0, 5.6, 8.8, 11.6, 15.2, 18.6, 20.6, 20.4, 16.8, 12.8, 8.2, 5.5], kt: 0.42 },
  { name: 'Berlin', lat: 52.52, temps: [0.6, 2.3, 5.1, 10.2, 14.8, 17.9, 20.3, 19.7, 15.3, 10.5, 5.4, 1.8], kt: 0.4 },
  { name: 'Madrid', lat: 40.42, temps: [6.3, 7.9, 11.2, 12.9, 16.9, 22.6, 25.9, 25.4, 20.8, 15.1, 9.9, 6.9], kt: 0.58 },
  { name: 'New York', lat: 40.71, temps: [0.5, 1.6, 5.8, 11.6, 16.9, 22.1, 25.3, 24.7, 20.9, 14.8, 9.0, 3.6], kt: 0.48 },
  { name: 'San Francisco', lat: 37.77, temps: [10.7, 12.0, 13.0, 13.8, 15.0, 16.4, 16.7, 17.3, 17.9, 16.6, 13.5, 10.8], kt: 0.55 },
];

/** Energy sources: non-renewable primary energy factor, kg CO₂ per kWh delivered, price per kWh (editable). */
export const SOURCES = {
  gas: { label: 'Natural gas', primary: 1.05, co2: 0.2, price: 0.12 },
  electricity: { label: 'Electricity (grid)', primary: 1.95, co2: 0.28, price: 0.3 },
  district: { label: 'District heating', primary: 1.5, co2: 0.15, price: 0.11 },
  oil: { label: 'Heating oil', primary: 1.07, co2: 0.27, price: 0.13 },
  wood: { label: 'Wood / pellets', primary: 0.2, co2: 0.03, price: 0.08 },
};

export const HEATING_SYSTEMS = [
  { value: 'boiler', label: 'Condensing gas boiler', source: 'gas', efficiency: 0.95 },
  { value: 'heatpump', label: 'Air-to-water heat pump', source: 'electricity', efficiency: 3.2 },
  { value: 'district', label: 'District heating', source: 'district', efficiency: 0.98 },
  { value: 'electric', label: 'Electric heaters', source: 'electricity', efficiency: 1 },
  { value: 'oil', label: 'Oil boiler', source: 'oil', efficiency: 0.85 },
  { value: 'biomass', label: 'Pellet boiler', source: 'wood', efficiency: 0.85 },
];

const MASS = { light: 80, medium: 165, heavy: 260 }; // kJ/(m²K) of floor
const DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
const MID = [17, 47, 75, 105, 135, 162, 198, 228, 258, 288, 318, 344];
export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const RAD = Math.PI / 180;

/** The climate for a project: its own, else the listed city nearest its location, else one estimated from latitude. */
export function climateFor(project) {
  const own = project?.energy?.climate;
  if (own?.temps?.length === 12) return { kt: 0.5, ...own };
  const loc = { ...DEFAULT_LOCATION, ...(project?.location || {}) };
  const byName = CLIMATES.find((c) => String(loc.name || '').toLowerCase().includes(c.name.toLowerCase()));
  if (byName) return byName;
  let best = null;
  for (const c of CLIMATES) if (Math.abs(c.lat - loc.lat) < 3 && (!best || Math.abs(c.lat - loc.lat) < Math.abs(best.lat - loc.lat))) best = c;
  if (best && loc.lat > 0) return { ...best, lat: loc.lat };
  // A rough curve: warmest a month after the summer solstice, colder and wider swings away from the equator.
  const a = Math.abs(loc.lat);
  const mean = 27 - 0.35 * a;
  const amp = 0.3 * a;
  const temps = Array.from({ length: 12 }, (_, m) => Math.round((mean - amp * Math.cos(((m - (loc.lat >= 0 ? 0.5 : 6.5)) / 12) * 2 * Math.PI)) * 10) / 10);
  return { name: `Estimated for latitude ${loc.lat.toFixed(1)}°`, lat: loc.lat, temps, kt: 0.5 };
}

/**
 * Mean daily irradiation (kWh/m²) in a month on a surface: vertical with a
 * compass azimuth (degrees clockwise from north), or horizontal (azimuth null).
 */
export function monthlyIrradiation(lat, month, azimuth, kt = 0.5, albedo = 0.2) {
  const n = MID[month];
  const phi = lat * RAD;
  const dec = 23.45 * RAD * Math.sin((2 * Math.PI * (284 + n)) / 365);
  const ws = Math.acos(Math.max(-1, Math.min(1, -Math.tan(phi) * Math.tan(dec))));
  const gsc = 1367;
  const h0 = ((24 / Math.PI) * gsc * (1 + 0.033 * Math.cos((2 * Math.PI * n) / 365)) * (Math.cos(phi) * Math.cos(dec) * Math.sin(ws) + ws * Math.sin(phi) * Math.sin(dec))) / 1000; // kWh/m²·day
  const H = kt * Math.max(0, h0);
  if (azimuth == null) return H;
  const fd = Math.max(0.1, Math.min(1, 1.391 - 3.56 * kt + 4.189 * kt * kt - 2.137 * kt * kt * kt));
  const Hd = fd * H;
  const Hb = H - Hd;
  // Beam ratio on the vertical surface by summing the sun over the day.
  const g = (azimuth - 180) * RAD; // from south, west positive
  let sumZ = 0;
  let sumT = 0;
  for (let w = -ws; w <= ws; w += 0.02) {
    const cz = Math.sin(dec) * Math.sin(phi) + Math.cos(dec) * Math.cos(phi) * Math.cos(w);
    if (cz <= 0) continue;
    // Vertical surface (tilt 90°).
    const ct = -Math.sin(dec) * Math.cos(phi) * Math.cos(g) + Math.cos(dec) * Math.sin(phi) * Math.cos(g) * Math.cos(w) + Math.cos(dec) * Math.sin(g) * Math.sin(w);
    sumZ += cz;
    sumT += Math.max(0, ct);
  }
  const Rb = sumZ > 0 ? sumT / sumZ : 0;
  return Hb * Rb + Hd * 0.5 + H * albedo * 0.5;
}

/** Settings with their defaults. */
export function energySettings(project) {
  const e = project?.energy || {};
  const sys = HEATING_SYSTEMS.find((s) => s.value === e.heatingSystem) || HEATING_SYSTEMS[0];
  return {
    inside: e.inside ?? 20,
    cooling: e.cooling ?? 26,
    internalGains: e.internalGains ?? 4,
    mass: e.mass || 'medium',
    shading: e.shading ?? 0.9,
    frame: e.frame ?? 0.25,
    heatingSystem: sys.value,
    heatingEfficiency: e.heatingEfficiency ?? sys.efficiency,
    heatingSource: sys.source,
    coolingEfficiency: e.coolingEfficiency ?? 3,
    coolingOn: e.coolingOn !== false && e.coolingOn !== 'false',
    // A night setback below the heating set point (0 or empty: none).
    setback: +e.setback > 0 ? +e.setback : null,
    profile: e.profile || 'constant',
    // Environment Settings: how exposed to wind the site is and how much the horizon shades it.
    windFactor: { sheltered: 0.8, normal: 1, exposed: 1.3 }[project?.energyEnvironment?.wind] ?? 1,
    horizonFactor: Math.max(0.3, 1 - (+project?.energyEnvironment?.horizon || 0) / 60),
    sources: Object.fromEntries(Object.entries(SOURCES).map(([k, v]) => [k, { ...v, ...(e.sources?.[k] || {}) }])),
  };
}

/** Ventilation systems: infiltration that stays, heat recovery, fan power. */
export const VENTILATION = [
  { value: 'natural', label: 'Natural (windows, infiltration)' },
  { value: 'mechanical', label: 'Mechanical, no heat recovery' },
  { value: 'mvhr', label: 'Mechanical with heat recovery' },
];
export const METHODS = [
  { value: 'monthly', label: 'Monthly (EN ISO 13790)' },
  { value: 'hourly', label: 'Hourly simulation' },
];

/**
 * Building systems with their defaults: ventilation { type, ach (mechanical rate, 1/h), recovery, sfp (W per m³/h) },
 * domestic hot water { demand (kWh/m²a), system ('heating' or a heating system) }, solar thermal (m² of collectors),
 * photovoltaics { kwp, tilt, azimuth, selfUse (share of the production used on site) }.
 */
export function buildingSystems(project) {
  const e = project?.energy || {};
  return {
    ventilation: { type: 'natural', ach: 0.5, recovery: 0.8, sfp: 0.35, infiltration: 0.1, ...(e.ventilation || {}) },
    dhw: { demand: 0, system: 'heating', ...(e.dhw || {}) },
    solarThermal: +e.solarThermal || 0,
    pv: { kwp: 0, tilt: 30, azimuth: 180, selfUse: 0.4, ...(e.pv || {}) },
  };
}

/**
 * Thermal blocks (Archicad's Energy Model Review): rooms grouped with their own set points, internal gains,
 * air changes and gains profile. project.energy.blocks [{ id, name, roomIds, inside?, cooling?, setback?,
 * internalGains?, ach?, profile? }]; rooms in no block form the default block. Returns [{ id, name, rows, own }].
 */
export function thermalBlocks(doc, report) {
  const defs = doc.get('project')?.energy?.blocks || [];
  const taken = new Set();
  const out = [];
  for (const b of defs) {
    const rows = report.rows.filter((r) => b.roomIds?.includes(r.room.id) && !taken.has(r.room.id));
    rows.forEach((r) => taken.add(r.room.id));
    out.push({ id: b.id, name: b.name || 'Block', rows, own: b });
  }
  const rest = report.rows.filter((r) => !taken.has(r.room.id));
  if (rest.length || !out.length) out.unshift({ id: 'default', name: defs.length ? 'Other zones' : 'Building', rows: rest, own: {} });
  return out.filter((b) => b.rows.length);
}

/** Heat loss coefficient (W/K) of a block by ventilation, with the ventilation system. */
function ventilationH(b, s, sys, defaultAch) {
  const V = b.rows.reduce((t, r) => t + r.volume, 0);
  const ach = b.own.ach ?? null;
  const v = sys.ventilation;
  if (v.type === 'natural') {
    const base = ach == null ? b.rows.reduce((t, r) => t + r.HV, 0) : 0.34 * ach * V;
    return { HV: base * s.windFactor, airflow: 0 };
  }
  const n = ach ?? v.ach ?? defaultAch;
  const rec = v.type === 'mvhr' ? Math.max(0, Math.min(0.95, +v.recovery || 0)) : 0;
  return { HV: 0.34 * V * ((+v.infiltration || 0) * s.windFactor + n * (1 - rec)), airflow: n * V };
}

/** Monthly balance of one block (the EN ISO 13790 monthly method). */
function monthlyBlock(climate, s, b) {
  const a = 1 + b.tau / 15;
  const util = (g) => (g <= 0 ? 1 : Math.abs(g - 1) < 1e-6 ? a / (a + 1) : (1 - g ** a) / (1 - g ** (a + 1)));
  const months = [];
  for (let m = 0; m < 12; m++) {
    const hours = DAYS[m] * 24;
    const te = climate.temps[m];
    const solar = b.windows.reduce((sum, w) => sum + w.area * w.g * (1 - s.frame) * s.shading * s.horizonFactor * monthlyIrradiation(climate.lat ?? 45, m, w.azimuth, climate.kt) * DAYS[m], 0);
    const internal = (b.internalGains * b.area * hours) / 1000;
    const gains = solar + internal;
    const loss = (b.H * Math.max(0, b.inside - te) * hours) / 1000;
    const heating = loss > 0 ? Math.max(0, loss - util(gains / loss) * gains) : 0;
    // Cooling: gains the losses at the cooling set point cannot carry away.
    let cooling = 0;
    if (b.cooling != null) {
      const lossC = (b.H * (b.cooling - te) * hours) / 1000;
      if (lossC <= 0) cooling = gains - lossC;
      else {
        const g = gains / lossC;
        const etaLs = g <= 0 ? 1 : Math.abs(g - 1) < 1e-6 ? a / (a + 1) : (1 - g ** -a) / (1 - g ** -(a + 1));
        cooling = Math.max(0, gains - etaLs * lossC);
      }
    }
    months.push({ heating, cooling, loss, solar, internal });
  }
  return { months };
}

/**
 * The annual balance: { climate, settings, systems, method, blocks, months: [{ month, te, loss, solar, internal,
 * heating, cooling }] (kWh), annual: { heating, cooling, perArea, dhw, fans, pv, pvUsed, pvExported, solarThermal,
 * delivered: { [source]: kWh }, primary, co2 (kg), cost, peakHeating, peakCooling (W, hourly), overheatingHours },
 * area, report }.
 */
export function annualEnergy(doc, scene) {
  const project = doc.get('project');
  const report = energyReport(doc, scene);
  const climate = climateFor(project);
  const s = energySettings(project);
  const sys = buildingSystems(project);
  const method = project?.energy?.method === 'hourly' ? 'hourly' : 'monthly';
  const A = report.totals.area;
  const blocks = thermalBlocks(doc, report).map((b) => {
    const area = b.rows.reduce((t, r) => t + r.area, 0);
    const HT = b.rows.reduce((t, r) => t + r.HT, 0);
    const { HV, airflow } = ventilationH(b, s, sys, report.settings.ach);
    const H = HT + HV;
    const Cm = (MASS[b.own.mass || s.mass] || 165) * 1000 * area; // J/K
    return {
      id: b.id,
      name: b.name,
      area,
      HT,
      HV,
      H,
      airflow,
      Cm,
      tau: H > 0 ? Cm / 3600 / H : 0,
      windows: b.rows.flatMap((r) => r.faces || []).filter((f) => f.kind === 'window'),
      inside: b.own.inside ?? s.inside,
      cooling: b.own.cooling === null ? null : (b.own.cooling ?? (s.coolingOn ? s.cooling : null)),
      setback: b.own.setback ?? s.setback,
      internalGains: b.own.internalGains ?? s.internalGains,
      profile: b.own.profile || s.profile,
      shading: s.shading,
      frame: s.frame,
      horizonFactor: s.horizonFactor,
    };
  });
  const hc = method === 'hourly' || sys.pv.kwp > 0 || sys.solarThermal > 0 ? hourlyClimate(climate) : null;
  const months = MONTHS.map((month, m) => ({ month, te: climate.temps[m], loss: 0, solar: 0, internal: 0, heating: 0, cooling: 0 }));
  let peakHeating = 0;
  let peakCooling = 0;
  let overheatingHours = 0;
  for (const b of blocks) {
    const r = method === 'hourly' ? simulateBlock(hc, b) : monthlyBlock(climate, s, b);
    b.result = { heating: 0, cooling: 0 };
    r.months.forEach((x, m) => {
      for (const k of ['loss', 'solar', 'internal', 'heating', 'cooling']) months[m][k] += x[k];
      b.result.heating += x.heating;
      b.result.cooling += x.cooling;
    });
    if (method === 'hourly') {
      peakHeating += r.peakHeating;
      peakCooling += r.peakCooling;
      overheatingHours = Math.max(overheatingHours, r.overheatingHours);
      Object.assign(b.result, { peakHeating: r.peakHeating, peakCooling: r.peakCooling, overheatingHours: r.overheatingHours, tmin: r.tmin, tmax: r.tmax });
    }
  }
  const heating = months.reduce((t, x) => t + x.heating, 0);
  const cooling = months.reduce((t, x) => t + x.cooling, 0);
  // Domestic hot water, less what solar collectors give (30% of the irradiation on a 35° south plane, month by month,
  // at most 95% of the month's need: storage and circulation losses).
  const dhwNeed = (sys.dhw.demand || 0) * A;
  let solarThermal = 0;
  if (dhwNeed > 0 && sys.solarThermal > 0) {
    const irr = irradiationOn(hc, 35, 180).months;
    for (let m = 0; m < 12; m++) solarThermal += Math.min((0.95 * dhwNeed * DAYS[m]) / 365, irr[m] * sys.solarThermal * 0.3);
  }
  const dhwSys = sys.dhw.system === 'heating' ? { source: s.heatingSource, efficiency: s.heatingEfficiency } : HEATING_SYSTEMS.find((x) => x.value === sys.dhw.system) || { source: s.heatingSource, efficiency: s.heatingEfficiency };
  const fans = blocks.reduce((t, b) => t + (sys.ventilation.sfp * b.airflow * 8760) / 1000, 0);
  const delivered = {};
  const add = (k, v) => v > 0 && (delivered[k] = (delivered[k] || 0) + v);
  add(s.heatingSource, heating / (s.heatingEfficiency || 1));
  add(dhwSys.source, Math.max(0, dhwNeed - solarThermal) / (dhwSys.efficiency || 1));
  add('electricity', cooling / (s.coolingEfficiency || 1) + fans);
  // Photovoltaics: the share used on site (pv.selfUse of the production, 40% without a battery) up to the
  // electricity bought month by month; the rest is exported.
  let pv = 0;
  let pvUsed = 0;
  if (sys.pv.kwp > 0) {
    const irr = irradiationOn(hc, +sys.pv.tilt || 0, sys.pv.azimuth ?? 180).months;
    const elecMonth = (delivered.electricity || 0) / 12;
    for (let m = 0; m < 12; m++) {
      const y = irr[m] * sys.pv.kwp * 0.8;
      pv += y;
      pvUsed += Math.min(y * Math.max(0, Math.min(1, sys.pv.selfUse ?? 0.4)), elecMonth);
    }
    if (delivered.electricity) delivered.electricity = Math.max(0, delivered.electricity - pvUsed);
  }
  let primary = 0;
  let co2 = 0;
  let cost = 0;
  for (const [k, kwh] of Object.entries(delivered)) {
    const f = s.sources[k];
    primary += kwh * f.primary;
    co2 += kwh * f.co2;
    cost += kwh * f.price;
  }
  const used = heating + cooling + dhwNeed;
  return {
    climate,
    settings: s,
    systems: sys,
    method,
    blocks,
    months,
    area: A,
    report,
    annual: {
      heating,
      cooling,
      dhw: dhwNeed,
      fans,
      pv,
      pvUsed,
      pvExported: pv - pvUsed,
      solarThermal,
      renewableShare: used + fans > 0 ? (pvUsed + solarThermal) / (used + fans) : 0,
      perArea: A ? (heating + cooling) / A : 0,
      heatingPerArea: A ? heating / A : 0,
      coolingPerArea: A ? cooling / A : 0,
      delivered,
      primary,
      primaryPerArea: A ? primary / A : 0,
      co2,
      cost,
      peakHeating: method === 'hourly' ? peakHeating : null,
      peakCooling: method === 'hourly' ? peakCooling : null,
      overheatingHours: method === 'hourly' ? overheatingHours : null,
    },
  };
}
