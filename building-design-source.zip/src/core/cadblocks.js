/**
 * Import Blocks from DXF/DWG (Archicad's): each block a drawing inserts becomes a library part with its 2D
 * symbol (lines, arcs, texts, at the block's base point), and each insertion of it a placed object at its point
 * and rotation, instead of loose lines. Nested blocks are drawn into their parent's symbol.
 */
import { flattenCAD } from './cadflatten.js';

const R = (v) => Math.round(v * 100000) / 100000;

/** The 2D GDL of a block (metres, from its base point), and its size in mm. */
export function blockSymbol(cad, name, unitMm = 1) {
  const b = cad.blocks?.[name];
  if (!b) return null;
  const bx = +b.basePoint?.x || 0;
  const by = +b.basePoint?.y || 0;
  const flat = flattenCAD({ entities: b.entities, blocks: cad.blocks });
  const k = unitMm / 1000;
  const q = (p) => `${R((p[0] - bx) * k)}, ${R((p[1] - by) * k)}`;
  const lines = [`! Block "${name}" from a DWG/DXF drawing.`];
  const pts = [];
  for (const l of flat.lines) (lines.push(`LINE2 ${q(l.a)}, ${q(l.b)}`), pts.push(l.a, l.b));
  for (const a of flat.arcs) {
    const deg = (x) => R((x * 180) / Math.PI);
    if (Math.abs(a.a1 - a.a0) >= Math.PI * 2 - 1e-6) lines.push(`CIRCLE2 ${q(a.c)}, ${R(a.r * k)}`);
    else lines.push(`ARC2 ${q(a.c)}, ${R(a.r * k)}, ${deg(a.a0)}, ${deg(a.a1)}`);
    pts.push([a.c[0] - a.r, a.c[1] - a.r], [a.c[0] + a.r, a.c[1] + a.r]);
  }
  for (const t of flat.texts) (lines.push(`TEXT2 ${q(t.at)}, "${String(t.text).replace(/"/g, "'")}"`), pts.push(t.at));
  if (lines.length === 1) return null;
  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  const width = Math.max(1, Math.round((Math.max(...xs) - Math.min(...xs)) * unitMm));
  const depth = Math.max(1, Math.round((Math.max(...ys) - Math.min(...ys)) * unitMm));
  return { script2d: lines.join('\n'), width, depth };
}

/** Top-level insertions: [{ name, at (drawing units), rotation (degrees), scale }], skipping anonymous blocks. */
export function blockInserts(cad) {
  return (cad.entities || [])
    .filter((e) => e.type === 'INSERT' && e.name && !String(e.name).startsWith('*') && cad.blocks?.[e.name] && e.isVisible !== false)
    .map((e) => ({ name: e.name, at: [+e.insertionPoint?.x || 0, +e.insertionPoint?.y || 0], rotation: (((+e.rotation || 0) * 180) / Math.PI) % 360, scale: [+e.xScale || 1, +e.yScale || 1], layer: e.layer }));
}

/**
 * Library parts and objects (not added) for a drawing's blocks. T maps drawing points to model mm (the same
 * centring and unit as a plain import). Returns { types: [type], placed: [{ name, at, rotation, mirrored }] }.
 */
export function blocksAsObjects(cad, { unitMm = 1, T = (p) => p.map((v) => v * unitMm) } = {}) {
  const inserts = blockInserts(cad);
  const types = [];
  for (const name of [...new Set(inserts.map((i) => i.name))]) {
    const sym = blockSymbol(cad, name, unitMm);
    if (!sym) continue;
    types.push({ kind: 'componentType', family: 'gdl', familyName: 'DWG Block', category: 'genericAnnotations', name, width: sym.width, depth: sym.depth, height: 0, gdl: { params: [], script3d: '', script2d: sym.script2d, lenient: true } });
  }
  const have = new Set(types.map((t) => t.name));
  const placed = inserts.filter((i) => have.has(i.name)).map((i) => ({ name: i.name, at: T(i.at), rotation: Math.round(i.rotation * 1000) / 1000, mirrored: i.scale[0] * i.scale[1] < 0 }));
  return { types, placed };
}
