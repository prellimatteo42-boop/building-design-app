/**
 * Layers. Every model element and annotation sits on a layer; a layer can be
 * hidden (its elements are not drawn) or locked (they are drawn but cannot be
 * selected or changed). A layer combination remembers, under a name, which
 * layers are hidden and locked; a view set to a combination shows the layers
 * that way, and other views follow the layers' own settings.
 *
 *   layer       { kind: 'layer', name, hidden, locked }
 *   layerCombo  { kind: 'layerCombo', name, states: { [layerId]: { hidden, locked } } }
 *   element     layerId, optional: without one, the default layer of its category
 *   view        layerComboId, optional
 *
 * Views, types, levels and view markers are not on layers.
 */
import { categoryOf } from './catalog.js';
import { isView } from './doc.js';

/** The starting layers, each with the categories whose elements it holds by default. */
const LAYERS = [
  { id: 'ly-walls', name: 'Walls', cats: ['walls', 'wallSweeps'] },
  { id: 'ly-openings', name: 'Doors and Windows', cats: ['doors', 'windows'] },
  { id: 'ly-slabs', name: 'Slabs and Ceilings', cats: ['floors', 'ceilings'] },
  { id: 'ly-roofs', name: 'Roofs', cats: ['roofs'] },
  { id: 'ly-structure', name: 'Structure', cats: ['columns', 'beams', 'braces', 'trusses', 'structuralFoundations'] },
  { id: 'ly-circulation', name: 'Stairs and Railings', cats: ['stairs', 'ramps', 'railings'] },
  { id: 'ly-interior', name: 'Furniture and Fittings', cats: ['furniture', 'casework', 'plumbing', 'equipment', 'lighting', 'genericModels', 'electricalFixtures', 'legendComponents'] },
  { id: 'ly-services', name: 'Building Services', cats: ['ducts', 'pipes', 'cableTrays', 'conduits', 'mechanical', 'airTerminals', 'sprinklers', 'wires', 'electricalEquipment'] },
  { id: 'ly-site', name: 'Site and Landscape', cats: ['topography', 'site', 'parking', 'planting', 'entourage', 'propertyLines'] },
  { id: 'ly-massing', name: 'Massing', cats: ['masses'] },
  { id: 'ly-zones', name: 'Zones and Areas', cats: ['rooms', 'roomSeparators', 'areas', 'areaBoundaries', 'spaces'] },
  { id: 'ly-grids', name: 'Grids and References', cats: ['grids', 'refPlanes'] },
  { id: 'ly-dimensions', name: 'Dimensions', cats: ['dimensions'] },
  { id: 'ly-notes', name: 'Text and Labels', cats: ['text', 'tags', 'genericAnnotations', 'colorLegends'] },
  { id: 'ly-drafting', name: 'Drafting', cats: ['lines', 'detailItems', 'revisionClouds', 'rasterImages', 'modelLines'] },
  { id: 'ly-links', name: 'Linked Projects', cats: ['links'] },
  { id: 'ly-general', name: 'General', cats: [] },
];

const DEFAULT_OF = new Map(LAYERS.flatMap((l) => l.cats.map((c) => [c, l.id])));
const NOT_LAYERED = new Set(['levels', 'markers', 'siteCoordinates', 'scopeBoxes', 'matchlines', 'viewReferences']);

/** Layer items for a new project. */
export function defaultLayers() {
  return LAYERS.map((l) => ({ id: l.id, kind: 'layer', name: l.name, hidden: false, locked: false }));
}

/** Whether an element sits on a layer. */
export function layered(doc, el) {
  if (!el || isView(el) || el.kind.endsWith('Type') || el.kind === 'layer' || el.kind === 'layerCombo') return false;
  const cat = categoryOf(el, doc);
  return !!cat && !NOT_LAYERED.has(cat);
}

/** The id of the layer an element is on (its own, or its category's default), or null. */
export function layerIdOf(doc, el) {
  if (!layered(doc, el)) return null;
  if (el.layerId && doc.has(el.layerId)) return el.layerId;
  const id = DEFAULT_OF.get(categoryOf(el, doc)) || 'ly-general';
  return doc.has(id) ? id : null;
}

/** { hidden, locked, wireframe } of a layer in a view: from the view's combination, or the layer's own. */
export function layerState(doc, view, layerId) {
  const layer = doc.get(layerId);
  const combo = view?.layerComboId ? doc.get(view.layerComboId) : null;
  const s = combo?.states?.[layerId];
  if (s) return { hidden: !!s.hidden, locked: !!s.locked, wireframe: !!s.wireframe };
  return { hidden: !!layer?.hidden, locked: !!layer?.locked, wireframe: !!layer?.wireframe };
}

/** Whether an element's layer shows as wireframe in a view's 3D (Archicad's layer 3D mode). */
export function wireframeByLayer(doc, view, el) {
  const id = layerIdOf(doc, el) ?? (el.hostId ? layerIdOf(doc, doc.get(el.hostId)) : null);
  return !!id && layerState(doc, view, id).wireframe;
}

/** Whether an element's layer is hidden in a view. */
export function hiddenByLayer(doc, view, el) {
  const id = layerIdOf(doc, el);
  return !!id && layerState(doc, view, id).hidden;
}

/** Whether an element's layer is locked in a view. */
export function lockedByLayer(doc, view, el) {
  const id = layerIdOf(doc, el);
  return !!id && layerState(doc, view, id).locked;
}

/** Layers in the order they are listed. */
export function layersInOrder(doc) {
  return doc.all('layer').slice().sort((a, b) => (a.id === 'ly-general' ? -1 : b.id === 'ly-general' ? 1 : a.name.localeCompare(b.name)));
}

/** The current settings of every layer, as a combination's states. */
export function currentStates(doc) {
  const out = {};
  for (const l of doc.all('layer')) out[l.id] = { hidden: !!l.hidden, locked: !!l.locked, wireframe: !!l.wireframe };
  return out;
}

/**
 * Change one layer's hidden or locked state as seen in a view. A view that
 * follows a layer combination first takes the combination's states onto the
 * layers and becomes custom, so only that layer changes (inside a transaction).
 */
export function setLayerState(doc, view, layerId, patch) {
  const combo = view?.layerComboId ? doc.get(view.layerComboId) : null;
  if (combo) {
    for (const l of doc.all('layer')) {
      const s = combo.states?.[l.id];
      if (s) doc.update(l.id, { hidden: !!s.hidden, locked: !!s.locked, wireframe: !!s.wireframe });
    }
    doc.update(view.id, { layerComboId: null });
  }
  doc.update(layerId, patch);
}

/**
 * Intersection group of an element's layer, as in Archicad: walls on layers
 * with different group numbers do not join or cut each other. 1 by default.
 */
export function intersectionGroup(doc, el) {
  const project = doc.get('project');
  if (project?.autoIntersection === false) return el.id; // Auto Intersection off: nothing joins
  if (project?.layerIntersections === false) return 1;
  const id = layerIdOf(doc, el);
  const g = id ? doc.get(id)?.intersectionGroup : undefined;
  return Number.isFinite(+g) && g !== '' && g != null ? +g : 1;
}
