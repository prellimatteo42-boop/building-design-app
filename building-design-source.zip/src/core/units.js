/**
 * Lengths are stored in millimetres. Projects display them either in
 * imperial feet and inches (with a fractional precision) or in metric
 * millimetres, centimetres or metres.
 *
 * units: { system: 'imperial' | 'metric', metric: 'mm' | 'cm' | 'm', fraction: 8, decimals: 0 }
 */

export const MM_PER_INCH = 25.4;
export const MM_PER_FOOT = 304.8;

export const DEFAULT_UNITS = Object.freeze({ system: 'metric', metric: 'mm', fraction: 8, decimals: 0 });

function gcd(a, b) {
  while (b) [a, b] = [b, a % b];
  return a;
}

/** Feet and inches, e.g. 10' - 6 1/2". `fraction` is the denominator of the rounding. */
export function formatImperial(mm, fraction = 8, { feet = true } = {}) {
  if (!Number.isFinite(mm)) return '';
  const neg = mm < 0;
  let totalUnits = Math.round((Math.abs(mm) / MM_PER_INCH) * fraction);
  const unitsPerFoot = 12 * fraction;
  let ft = feet ? Math.floor(totalUnits / unitsPerFoot) : 0;
  totalUnits -= ft * unitsPerFoot;
  const inches = Math.floor(totalUnits / fraction);
  let num = totalUnits - inches * fraction;
  let den = fraction;
  if (num) {
    const g = gcd(num, den);
    num /= g;
    den /= g;
  }
  const inchText = `${inches}${num ? ` ${num}/${den}` : ''}"`;
  const s = feet ? `${ft}' - ${inchText}` : inchText;
  return neg ? `-${s}` : s;
}

export function formatMetric(mm, unit = 'mm', decimals = 0) {
  if (!Number.isFinite(mm)) return '';
  const div = unit === 'm' ? 1000 : unit === 'cm' ? 10 : 1;
  const v = mm / div;
  const d = unit === 'm' ? Math.max(decimals, 3) : decimals;
  let s = v.toFixed(d);
  if (s.includes('.') && unit === 'm') s = s.replace(/0+$/, '').replace(/\.$/, '');
  if (s === '-0') s = '0';
  return unit === 'mm' ? s : `${s} ${unit}`;
}

/** Display a length using the project's units. */
export function formatLength(mm, units = DEFAULT_UNITS) {
  return units.system === 'imperial' ? formatImperial(mm, units.fraction || 8) : withComma(formatMetric(mm, units.metric || 'mm', units.decimals || 0), units);
}

/** A metric number written with a decimal comma when the project asks for it (Italian, German... drawings). */
export function withComma(s, units = DEFAULT_UNITS) {
  return units?.decimalComma && units.system !== 'imperial' ? String(s).replace(/(\d)\.(\d)/g, '$1,$2') : s;
}

/** A length in a unit with a number of decimals (for ft & in: the inch fraction denominator). */
export function formatInUnit(mm, unit = 'm', decimals = 2) {
  const d = Math.max(0, Math.min(6, Math.round(+decimals || 0)));
  if (unit === 'ftin') return formatImperial(mm, [2, 4, 8, 16, 32, 64].includes(+decimals) ? +decimals : 8);
  if (unit === 'ft') return `${(mm / MM_PER_FOOT).toFixed(d)}'`;
  if (unit === 'in') return `${(mm / MM_PER_INCH).toFixed(d)}"`;
  const div = unit === 'm' ? 1000 : unit === 'cm' ? 10 : 1;
  return (mm / div).toFixed(d);
}

/** The kinds of dimension that can have their own unit (Project Preferences > Dimensions). */
export const DIMENSION_KINDS = [
  { value: 'linear', label: 'Linear' },
  { value: 'radial', label: 'Radial' },
  { value: 'level', label: 'Level and elevation' },
  { value: 'sill', label: 'Sill height' },
];

/** Text of a dimension of this kind when the project gives that kind its own unit, otherwise null. */
export function dimensionOverride(mm, units = DEFAULT_UNITS, kind = 'linear') {
  const o = units.dim?.[kind];
  if (!o?.unit || o.unit === 'default') return null;
  const step = +o.round || 0;
  return formatInUnit(step > 0 ? Math.round(mm / step) * step : mm, o.unit, o.decimals);
}

/** Dimension text: metric dimensions omit the unit, as on drawings. */
export function formatDimension(mm, units = DEFAULT_UNITS, kind = 'linear') {
  const own = dimensionOverride(mm, units, kind);
  if (own != null) return withComma(own, units);
  if (units.system === 'imperial') return formatImperial(mm, units.fraction || 8);
  const div = units.metric === 'm' ? 1000 : units.metric === 'cm' ? 10 : 1;
  const d = units.metric === 'm' ? Math.max(2, units.decimals || 0) : units.decimals || 0;
  return withComma((mm / div).toFixed(d), units);
}

export const AREA_UNITS = [
  { value: 'm2', label: 'Square metres', div: 1e6, suffix: 'm²' },
  { value: 'cm2', label: 'Square centimetres', div: 100, suffix: 'cm²' },
  { value: 'mm2', label: 'Square millimetres', div: 1, suffix: 'mm²' },
  { value: 'ha', label: 'Hectares', div: 1e10, suffix: 'ha' },
  { value: 'ft2', label: 'Square feet', div: MM_PER_FOOT * MM_PER_FOOT, suffix: 'SF' },
  { value: 'in2', label: 'Square inches', div: MM_PER_INCH * MM_PER_INCH, suffix: 'in²' },
  { value: 'yd2', label: 'Square yards', div: 9 * MM_PER_FOOT * MM_PER_FOOT, suffix: 'yd²' },
  { value: 'ac', label: 'Acres', div: 43560 * MM_PER_FOOT * MM_PER_FOOT, suffix: 'ac' },
];

export const VOLUME_UNITS = [
  { value: 'm3', label: 'Cubic metres', div: 1e9, suffix: 'm³' },
  { value: 'l', label: 'Litres', div: 1e6, suffix: 'l' },
  { value: 'cm3', label: 'Cubic centimetres', div: 1000, suffix: 'cm³' },
  { value: 'ft3', label: 'Cubic feet', div: MM_PER_FOOT ** 3, suffix: 'CF' },
  { value: 'in3', label: 'Cubic inches', div: MM_PER_INCH ** 3, suffix: 'in³' },
  { value: 'yd3', label: 'Cubic yards', div: 27 * MM_PER_FOOT ** 3, suffix: 'yd³' },
  { value: 'gal', label: 'US gallons', div: 3785411.784, suffix: 'gal' },
];

export const ANGLE_UNITS = [
  { value: 'deg', label: 'Decimal degrees' },
  { value: 'dms', label: 'Degrees, minutes, seconds' },
  { value: 'grad', label: 'Grads' },
  { value: 'rad', label: 'Radians' },
];

export const LAYOUT_UNITS = [
  { value: 'mm', label: 'Millimetres' },
  { value: 'cm', label: 'Centimetres' },
  { value: 'in', label: 'Inches' },
  { value: 'pt', label: 'Points' },
];

export function formatArea(mm2, units = DEFAULT_UNITS) {
  if (!Number.isFinite(mm2)) return '';
  const u = AREA_UNITS.find((x) => x.value === units.area) || AREA_UNITS.find((x) => x.value === (units.system === 'imperial' ? 'ft2' : 'm2'));
  const d = units.areaDecimals ?? (units.system === 'imperial' && !units.area ? 0 : 2);
  return `${(mm2 / u.div).toFixed(d)} ${u.suffix}`;
}

export function formatVolume(mm3, units = DEFAULT_UNITS) {
  if (!Number.isFinite(mm3)) return '';
  const u = VOLUME_UNITS.find((x) => x.value === units.volume) || VOLUME_UNITS.find((x) => x.value === (units.system === 'imperial' ? 'ft3' : 'm3'));
  return `${(mm3 / u.div).toFixed(units.volumeDecimals ?? 2)} ${u.suffix}`;
}

/** An angle in radians, in the project's angle unit when `units` is given. */
export function formatAngle(rad, decimals = 2, units = null) {
  const d = units?.angleDecimals ?? decimals;
  const kind = units?.angle || 'deg';
  if (kind === 'rad') return `${rad.toFixed(Math.max(d, 3))} rad`;
  if (kind === 'grad') return `${Math.round(((rad * 200) / Math.PI) * 10 ** d) / 10 ** d}g`;
  const deg = (rad * 180) / Math.PI;
  if (kind === 'dms') {
    const total = Math.round(Math.abs(deg) * 3600);
    return `${deg < 0 ? '-' : ''}${Math.floor(total / 3600)}° ${Math.floor(total / 60) % 60}' ${total % 60}"`;
  }
  return `${Math.round(deg * 10 ** d) / 10 ** d}°`;
}

/** A typed angle in degrees, read in the project's angle unit unless it carries its own mark. */
export function parseAngleDegrees(text, units = null) {
  const s = String(text ?? '').trim().replace(',', '.');
  const dms = /^(-?\d+(?:\.\d+)?)\s*°\s*(?:(\d+(?:\.\d+)?)\s*')?\s*(?:(\d+(?:\.\d+)?)\s*")?$/.exec(s);
  if (dms) return (dms[1].startsWith('-') ? -1 : 1) * (Math.abs(+dms[1]) + (+dms[2] || 0) / 60 + (+dms[3] || 0) / 3600);
  const v = parseFloat(s);
  if (/g$/i.test(s) || (units?.angle === 'grad' && /^[-\d.]+$/.test(s))) return v * 0.9;
  if (/rad$/i.test(s) || (units?.angle === 'rad' && /^[-\d.]+$/.test(s))) return (v * 180) / Math.PI;
  return v;
}

/** A distance on the paper (mm) in the project's layout unit. */
export function formatPaper(mm, units = DEFAULT_UNITS) {
  const d = units.layoutDecimals ?? (units.layout === 'in' ? 3 : units.layout === 'pt' ? 1 : 0);
  if (units.layout === 'in') return `${(mm / MM_PER_INCH).toFixed(d)}"`;
  if (units.layout === 'pt') return `${((mm / MM_PER_INCH) * 72).toFixed(d)} pt`;
  if (units.layout === 'cm') return `${(mm / 10).toFixed(d)} cm`;
  return `${mm.toFixed(d)} mm`;
}

export function formatSlope(deg) {
  return `${Math.round(deg * 100) / 100}°`;
}

/**
 * Parse a typed length. Accepts feet and inches (10' 6", 10'-6 1/2", 6",
 * 10.5'), metric with a unit (3.2m, 350cm, 2400mm) and bare numbers, which
 * are read in the project's default unit (inches never; bare numbers in
 * imperial projects are feet, as in most building tools). Sums and
 * differences are allowed: 3000 + 250, 10' - 6". Returns NaN when invalid.
 */
export function parseLength(text, units = DEFAULT_UNITS) {
  if (typeof text === 'number') return text;
  let s = String(text ?? '')
    .trim()
    .toLowerCase()
    .replace(/[’′]/g, "'")
    .replace(/[”″]/g, '"')
    .replace(/,/g, '.');
  if (!s) return NaN;
  // Feet-inch separators: 10'-6" and 10' - 6" both mean ten feet six inches.
  s = s.replace(/'\s*-\s*(?=\d)/g, "' ");
  const terms = [];
  let sign = 1;
  let rest = s;
  const re = /^\s*([+-])?\s*/;
  while (rest.length) {
    const m = re.exec(rest);
    if (m[1]) sign = m[1] === '-' ? -1 : 1;
    rest = rest.slice(m[0].length);
    if (!rest) break;
    const t = parseTerm(rest, units);
    if (!t) return NaN;
    terms.push(sign * t.value);
    rest = rest.slice(t.length);
    sign = 1;
    const op = /^\s*([+-])/.exec(rest);
    if (!op && rest.trim()) {
      // Two lengths without an operator: 10' 6" (feet then inches) add up.
      continue;
    }
  }
  if (!terms.length) return NaN;
  return terms.reduce((a, b) => a + b, 0);
}

const NUM = String.raw`(\d+(?:\.\d*)?|\.\d+)`;
const FRAC = String.raw`(?:\s+(\d+)\/(\d+)|\s*(\d+)\/(\d+))`;

function parseTerm(s, units) {
  let m;
  // Inches with an optional fraction: 6", 6 1/2", 1/2"
  if ((m = new RegExp(`^${NUM}(?:\\s+(\\d+)\\/(\\d+))?\\s*(?:"|in(?:ch(?:es)?)?\\b)`).exec(s))) {
    let v = parseFloat(m[1]);
    if (m[2]) v += parseInt(m[2], 10) / parseInt(m[3], 10);
    return { value: v * MM_PER_INCH, length: m[0].length };
  }
  if ((m = /^(\d+)\/(\d+)\s*(?:"|in\b)/.exec(s))) {
    return { value: (parseInt(m[1], 10) / parseInt(m[2], 10)) * MM_PER_INCH, length: m[0].length };
  }
  // Feet: 10', 10.5ft
  if ((m = new RegExp(`^${NUM}\\s*(?:'|ft\\b|feet\\b|foot\\b)`).exec(s))) {
    return { value: parseFloat(m[1]) * MM_PER_FOOT, length: m[0].length };
  }
  // Metric with unit
  if ((m = new RegExp(`^${NUM}\\s*(mm|cm|m)\\b`).exec(s))) {
    const f = m[2] === 'm' ? 1000 : m[2] === 'cm' ? 10 : 1;
    return { value: parseFloat(m[1]) * f, length: m[0].length };
  }
  // Bare number, possibly with a fraction (imperial inches after feet are handled above).
  if ((m = new RegExp(`^${NUM}${FRAC}?`).exec(s))) {
    let v = parseFloat(m[1]);
    const fn = m[2] || m[4];
    const fd = m[3] || m[5];
    if (fn) v += parseInt(fn, 10) / parseInt(fd, 10);
    if (units.system === 'imperial') v *= MM_PER_FOOT;
    else v *= units.metric === 'm' ? 1000 : units.metric === 'cm' ? 10 : 1;
    return { value: v, length: m[0].length };
  }
  return null;
}

/** Parse an angle in degrees ("45", "45°", "-30 deg"). Returns radians or NaN. */
export function parseAngle(text) {
  const m = /^\s*(-?\d+(?:\.\d*)?|-?\.\d+)\s*(?:°|deg|degrees)?\s*$/i.exec(String(text ?? ''));
  return m ? (parseFloat(m[1]) * Math.PI) / 180 : NaN;
}

/** Common drawing scales: value is the ratio denominator. */
export const SCALES_METRIC = [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000];
export const SCALES_IMPERIAL = [
  { label: '12" = 1\'-0"', value: 1 },
  { label: '6" = 1\'-0"', value: 2 },
  { label: '3" = 1\'-0"', value: 4 },
  { label: '1 1/2" = 1\'-0"', value: 8 },
  { label: '1" = 1\'-0"', value: 12 },
  { label: '3/4" = 1\'-0"', value: 16 },
  { label: '1/2" = 1\'-0"', value: 24 },
  { label: '3/8" = 1\'-0"', value: 32 },
  { label: '1/4" = 1\'-0"', value: 48 },
  { label: '3/16" = 1\'-0"', value: 64 },
  { label: '1/8" = 1\'-0"', value: 96 },
  { label: '1/16" = 1\'-0"', value: 192 },
  { label: '1/32" = 1\'-0"', value: 384 },
];

export function scaleLabel(value, units = DEFAULT_UNITS) {
  if (units.system === 'imperial') {
    const s = SCALES_IMPERIAL.find((x) => x.value === value);
    if (s) return s.label;
  }
  return `1 : ${value}`;
}

export function scaleOptions(units = DEFAULT_UNITS) {
  return units.system === 'imperial' ? SCALES_IMPERIAL : SCALES_METRIC.map((v) => ({ label: `1 : ${v}`, value: v }));
}

/** Round a model length to a sensible increment for snapping while drawing. */
export function snapIncrement(mmPerPixel, units = DEFAULT_UNITS) {
  if (units.system === 'imperial') {
    const steps = [MM_PER_INCH / 8, MM_PER_INCH / 4, MM_PER_INCH / 2, MM_PER_INCH, MM_PER_INCH * 3, MM_PER_INCH * 6, MM_PER_FOOT, MM_PER_FOOT * 5, MM_PER_FOOT * 10];
    return steps.find((s) => s >= mmPerPixel * 4) ?? steps.at(-1);
  }
  const steps = [1, 5, 10, 50, 100, 500, 1000, 5000];
  return steps.find((s) => s >= mmPerPixel * 4) ?? steps.at(-1);
}

/** A typed distance on the paper (mm): bare numbers are in the layout unit. */
export function parsePaper(text, units = DEFAULT_UNITS) {
  const raw = String(text ?? '').trim().replace(',', '.');
  if (/^[-+]?[\d.]+$/.test(raw)) return +raw * (units.layout === 'in' ? MM_PER_INCH : units.layout === 'pt' ? MM_PER_INCH / 72 : units.layout === 'cm' ? 10 : 1);
  return parseLength(raw, units);
}
