/**
 * Stair Landing Calculation Guidelines: on a stair's landings, the walking
 * line across the landing, its length, and where it would end for the
 * landing rule l = n · (2R + T) + T (n whole steps of the step length, plus
 * a tread: the usual rule, after DIN 18065), so the landing can be sized to
 * keep the walking rhythm.
 */
import { add, sub, scale, dist } from './geom.js';
import { stairFlights } from './stairs.js';

/** [{ path: [points], length, step, ideal: [{ n, length, at }], ok }] for each landing of a stair. */
export function landingGuides(doc, el) {
  const lay = stairFlights(doc, el);
  const out = [];
  const step = 2 * lay.riserHeight + lay.tread;
  for (let i = 0; i + 1 < lay.flights.length; i++) {
    const f1 = lay.flights[i];
    const f2 = lay.flights[i + 1];
    // The walking line: from the first flight's last tread nosing (its run), on its middle, to the next flight's start.
    const a = add(f1.start, scale(f1.dir, f1.run));
    const b = f2.start;
    // The corner where the walking line turns: along the first flight's direction until in line with the second.
    const t = Math.max(0, (b[0] - a[0]) * f1.dir[0] + (b[1] - a[1]) * f1.dir[1]);
    const c = add(a, scale(f1.dir, t));
    const path = dist(c, b) > 1 && t > 1 ? [a, c, b] : [a, b];
    const length = path.slice(1).reduce((s, p, k) => s + dist(path[k], p), 0);
    const ideal = [];
    for (let n = 0; n <= 4; n++) {
      const l = n * step + lay.tread;
      if (l > length * 1.6 + step) break;
      if (l < lay.tread) continue;
      ideal.push({ n, length: Math.round(l), at: pointAlong(path, l) });
    }
    const ok = ideal.some((x) => Math.abs(x.length - length) <= 0.05 * step);
    out.push({ path, length: Math.round(length), step: Math.round(step), ideal, ok });
  }
  return out;
}

/** The point at distance s along a polyline (beyond its end: on the last segment's line). */
export function pointAlong(path, s) {
  let rest = s;
  for (let k = 1; k < path.length; k++) {
    const l = dist(path[k - 1], path[k]);
    if (rest <= l || k === path.length - 1) {
      const d = sub(path[k], path[k - 1]);
      return add(path[k - 1], scale(d, l > 0 ? rest / l : 0));
    }
    rest -= l;
  }
  return path[0];
}
