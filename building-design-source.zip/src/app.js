/**
 * The application: one open project (document + scene), its open views,
 * the selection, the active tool, panels, settings and file handling.
 */
import { classWeights, applyMepSystems, applyOperationProfiles } from './core/attrs.js';
import { ChangeLog } from './core/changelog.js';
import { goToCamera } from './ui/documenu.js';
import { structuralUnits } from './core/projectprefs.js';
import { safCases } from './core/structcombos.js';
import { applyUiPrefs } from './ui/optionsmore.js';
import { zoneRulesSection } from './ui/projectprefs.js';
import { dwgTranslatorFor, saveDwgTranslator } from './core/dwgtranslators.js';
import { filterSAFModel, safTranslator } from './core/safimport.js';
import { buildShell, buildCube } from './ui/shell.js';
import { Ribbon } from './ui/ribbon.js';
import { contextualPanels, GROUP_EDIT_PANEL } from './ui/ribbon-def.js';
import { PropertiesPanel, pluralLabel } from './ui/properties.js';
import { ProjectBrowser } from './ui/browser.js';
import { installTooltips, hideTooltip, setTooltipMode } from './ui/tooltip.js';
import * as options from './ui/options.js';
import { Assistant, describeStep } from './ui/assistant.js';
import { connectBridge } from './assistant/bridge.js';
import { placeUnderlay } from './assistant/tools.js';
import { Workspace, AC_SHORTCUTS, acKeyCommand } from './ui/workspace.js';
import { uiLanguage } from './ui/aclang.js';
import { roomCutaway, looksLikePhoto } from './core/roomview.js';
import { applyExtrasAtStart } from './ui/acextras.js';
import { applyGroupA } from './ui/groupa.js';
import { QuickLayers } from './ui/quicklayers.js';
import { SeoPalette } from './ui/seopalette.js';
import { libraryDialog } from './ui/library.js';
import { masterLayoutsDialog } from './ui/masters.js';
import { classificationDialog } from './ui/classify.js';
import { issuesDialog } from './ui/issues.js';
import { fillTypesDialog } from './ui/filltypes.js';
import { TracePalette } from './ui/trace.js';
import { ComparePalette } from './ui/compare.js';
import { COMPARE_COLORS } from './core/compare.js';
import { SIM_COLORS } from './core/construction.js';
import { applyFillet } from './core/fillet.js';
import { explodeGraphics, addExploded } from './core/explode.js';
import { independentDrawing } from './core/hiddenline.js';
import { analyticalModel, safSheets } from './core/analytical.js';
import { writeXLSX } from './io/xlsx.js';
import * as energyUi from './ui/energy.js';
import { Tracker } from './ui/tracker.js';
import { draftingOf } from './core/drafting.js';
import { download } from './io/storage.js';
import { safeFileName } from './io/native.js';
import { viewFrame, elevationAnnotations } from './core/elevation.js';
import { segmentsOf, convertLines } from './core/convert.js';
import { applyPolygonOp } from './core/polybool.js';
import { alignMoves, distributeMoves, distributeXYMoves, alongLineMoves, alignToLineMoves } from './core/distribute.js';
import { cutPlanesDialog } from './ui/cutplanes.js';
import { FlyPalette } from './ui/flythrough.js';
import { HistoryPalette } from './ui/history.js';
import { weightsOf, screenWeights, WEIGHT_CLASSES, DEFAULT_WEIGHTS_MM } from './core/pens.js';
import { hiddenByStoryFilter } from './core/filter3d.js';
import { areaRules } from './core/zonecalc.js';
import { parseSurveyPoints, centrePoints, SURVEY_ORDERS } from './core/topo.js';
import { flattenCAD, layerCounts, INSUNITS_MM } from './core/cadflatten.js';
import { placeCAD, defaultRoles, removeCADImport } from './io/cadplace.js';
import { ROLES, buildRecognized, stampCheck, shiftRecognized, recognizedMiddle, addRecognizedAnnotations } from './core/recognize.js';
import { interiorDimension } from './core/autodim.js';
import { recognizePDF, statedScales } from './core/recognizepdf.js';
import { recognizeImage, guessScale } from './core/recognizeimage.js';
import { rectifyPhoto } from './core/rectify.js';
import { gdlObjectsDialog } from './ui/gdleditor.js';
import { archicadLibraryDialog } from './ui/aclibrary.js';
import { complianceDialog } from './ui/compliance.js';
import { imagePointToModel, imageScale } from './core/floorplan.js';
import { hiddenByLayer, lockedByLayer, wireframeByLayer, layered } from './core/layers.js';
import { lastViewKey, LayerHistory, layerSnapshot } from './core/navlast.js';
import { showMenu, closeMenus } from './ui/menu.js';
import { toast, confirmDialog, promptDialog, openDialog as openDialogFn } from './ui/dialog.js';
import { makeRoofFraming } from './core/roofmaker.js';
import { checkSolidity, coverWithFaces, curveMorphEdges, mergeBodies, intersectFaces } from './core/morphops.js';
import { croppersOver } from './core/zonecrop.js';
import { supportsFor, loadsFor, loadSummary, LOAD_CASES } from './core/structural.js';
import { ROOF_TYPES, wallLoop, wizardRoof, roofBase } from './core/roofwizard.js';
import { levelElevation, verticalExtent } from './core/model.js';
import { h, clear, MOD } from './ui/dom.js';
import { icon, KIND_ICON } from './ui/icons.js';
import { COMMANDS, applyShortcuts } from './commands.js';
import { Scene, MODEL_KINDS } from './core/scene.js';
import { createProject, default3DView, upgradeDoc } from './core/template.js';
import { createSampleProject } from './core/sample.js';
import { isView, isFlatView, newId, PLAN_VIEW_KINDS, isPlanView } from './core/doc.js';
import { defaultCrop } from './core/props.js';
import { categoryOf, defaultTypeFor, KIND_LABEL } from './core/catalog.js';
import { favoritesFor, favoriteFrom, favoritePatch } from './core/favorites.js';
import { describe as describeEl } from './core/props.js';
import { formatArea, formatLength, parseLength } from './core/units.js';
import { temporaryDimensions } from './editor/tempdims.js';
import { drawTempDim } from './views/overlay.js';
import { deleteElements, moveElements, uniqueName, expandGroups } from './core/ops.js';
import { groupable, createGroup, propagateGroup, ungroup } from './core/groups.js';
import { viewGraphics, hiddenByFilters, templateSettings, templateKindOf, hasGraphics } from './core/graphics.js';
import { phaseLook, phased } from './core/phases.js';
import { Viewport } from './views/viewport.js';
import { PlanController } from './views/plan.js';
import { ModelController } from './views/model.js';
import { outerSide, WALL_ACCESSORIES, framingGeometry, framingList } from './core/cladding.js';
import { SLAB_ACCESSORIES } from './core/accessories.js';
import { ScheduleController } from './views/schedule.js';
import { SheetController } from './views/sheet.js';
import { SelectTool } from './editor/select.js';
import { SketchTool, createLevel } from './editor/draw.js';
import { FLAG } from './render/gl.js';
import { pointInPolygon as insidePolygon } from './core/geom.js';
import * as dialogs from './ui/dialogs.js';
import { isTrimmer, trimmerFor, TRIMMABLE_KINDS } from './core/rooftrim.js';
import * as exporters from './io/exporters.js';
import * as files from './io/files.js';
import {
  isSignedIn,
  getUser,
  signIn,
  signOut,
  canSignOut,
  whenPuter,
  cachedProfilePicture,
  fetchProfilePicture,
  clearProfilePicture,
  puterAvailable,
} from './platform.js';
import { renderViewbar } from './ui/viewbar.js';
import { renderHome } from './ui/home.js';
import { Settings } from './settings.js';
import { offsetPatch } from './core/editplane.js';
import { SyncManager } from './io/sync.js';
import { solveConstraints } from './core/constraints.js';
import { applyGlobals } from './core/globals.js';
import { applyScopeBoxes } from './core/scopebox.js';
import { applyViewClones } from './core/viewclones.js';
import { exteriorDimensions } from './core/autodim.js';
import { interiorElevations } from './core/interiorelev.js';
import { elevatePatch } from './core/elevate.js';
import { freezeMeshes, cornerHeight } from './core/morph.js';
import { railingsOnStair, railingsOnSlabEdges } from './core/autorail.js';
import { levelDimensions } from './core/autolevels.js';
import { gravityPatch, GRAVITY } from './core/gravity.js';
import { worksharingOn, worksetable, worksets, defaultWorkset, DATUM_KINDS } from './core/worksets.js';
import { setEditingOption, editingOption, optionable, optionLabel, optionSets, optionsOf } from './core/designopts.js';

const PLAN_KINDS = new Set(PLAN_VIEW_KINDS);

export class App {
  constructor(root) {
    this.root = root;
    this.doc = null;
    this.scene = null;
    this.selection = new Set();
    this.hoverId = null;
    this.tool = null;
    this.openViews = [];
    this.activeViewId = null;
    this.controllers = new Map();
    this.viewStates = new Map();
    this.zoomHistories = new Map();
    // Trace & Reference per view (core/trace.js): a way of looking, not saved.
    this.traces = new Map();
    // Guide lines per view ({ p, d }: a point and a unit direction), not saved.
    this.guides = new Map();
    this.currentTypes = new Map();
    // Favorites armed per element kind: new elements of that kind take their settings (core/favorites.js).
    this.armedFavorites = new Map();
    // Settings picked up with the eyedropper, per element kind (favorites that are not saved).
    this.pickedSettings = new Map();
    this.toolOpts = new Map();
    this.temp = new Map();
    this.reveal = new Set();
    this.keyBuffer = '';
    this.navMode = null;
    this.clipboard = null;
    this.file = null;
    this.settingsStore = new Settings();
    this.flagsVersion = 0;
    this.sync = new SyncManager(this);
    this.activeWorksetId = null;
  }

  get settings() {
    return this.settingsStore.values;
  }

  get activeView() {
    return this.doc?.get(this.activeViewId) ?? null;
  }

  get vc() {
    return this.controllers.get(this.activeViewId) ?? null;
  }

  // Startup ------------------------------------------------------------------------------

  async start() {
    this.settingsStore.load();
    this.applyPreferences();
    this.applyTheme();
    this.shell = buildShell(this);
    this.tracker = new Tracker(this);
    applyExtrasAtStart(this);
    applyGroupA(this);
    if (this.settings.scrollBars) import('./ui/scrollbars.js').then(({ ScrollBars }) => (this.scrollBars ||= new ScrollBars(this)).set(true));
    // Hide Tab Bar / Hide Quick Options Bar, as last left.
    if (this.shell?.vtabs) this.shell.vtabs.hidden = !!this.settings.hideTabBar;
    if (this.shell?.viewbar) this.shell.viewbar.hidden = !!this.settings.hideQuickOptions;
    this.ribbon = new Ribbon(this);
    this.shell.root.querySelector('.ribbon-slot').replaceWith(this.ribbon.el);
    this.root.append(this.shell.root);
    buildCube(this, this.shell.cubeInner, this.shell.viewcube);
    installTooltips(document);
    this.props = new PropertiesPanel(this, this.shell.propsBody);
    this.browser = new ProjectBrowser(this, this.shell.browserBody, this.shell.browserSearch);
    this.workspace = new Workspace(this);
    this.quickLayers = new QuickLayers(this);
    this.tracePalette = new TracePalette(this);
    this.comparePalette = new ComparePalette(this);
    this.flyPalette = new FlyPalette(this);
    this.historyPalette = new HistoryPalette(this);
    this.seoPalette = new SeoPalette(this);
    this.viewport = new Viewport(this, this.shell.canvasWrap, this.shell.glCanvas, this.shell.overlay);
    this.workspace.apply(!!this.settings.workspaceAc);
    this.bindKeys();
    this.bindDock();
    this.sync.on(() => this.renderCollab());
    this.buildPhonebar();
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => this.applyTheme());
    window.addEventListener('beforeunload', (e) => {
      if (this.doc?.modified && this.file?.source !== 'local') {
        e.preventDefault();
        e.returnValue = '';
      }
    });
    this.renderAccount();
    const params = new URLSearchParams(location.search);
    const recovered = params.has('sample') ? false : await files.recover(this);
    if (params.has('sample')) this.openSample();
    else if (!recovered) this.showHome();
    // Linked drawings (xrefs, external drawings): say when their files change.
    import('./ui/xrefs.js').then((m) => m.watchLinks(this));
    // Claude Code and other MCP clients reach the open project through the dev server.
    if (import.meta.env?.DEV)
      connectBridge(
        this,
        (name, input, result) => this.assistantStep(name, input, result),
        () => toast('Claude Code now works in another Building Design window. Reload this page to give it back here.'),
      );
    whenPuter().then(async (ok) => {
      if (!ok) return;
      this.renderAccount();
      await this.settingsStore.syncFromCloud();
      this.applyPreferences();
      this.ribbon.renderBody();
      this.applyTheme();
      files.handleLaunchItems(this);
    });
  }

  fatal(message, err) {
    console.error(err);
    toast(message, { kind: 'error', timeout: 0 });
  }

  toast(msg, opts) {
    return toast(msg, opts);
  }

  // Document --------------------------------------------------------------------------------

  setDoc(doc, file = null) {
    this.cancelTool(true);
    for (const c of this.controllers.values()) c.dispose?.();
    this.controllers.clear();
    this.viewStates.clear();
    this.traces.clear();
    this.compareHighlight = null;
    // Palettes showing the old project's state.
    queueMicrotask(() => this.historyPalette?.render());
    this.guides.clear();
    this.scene?.dispose();
    this.viewport.r3.clear();
    this.viewport.r3.origin = [0, 0, 0];
    this.originSet = false;
    upgradeDoc(doc);
    this.groupEdit = null;
    // New model elements belong to the phase of the view they are drawn in.
    doc.addHooks = [
      (item) => (!item.phaseId && phased(item) && this.activeView?.phaseId ? { phaseId: this.activeView.phaseId } : null),
      // ...and to the active workset of whoever draws them.
      // ...and to the design option being edited.
      // ...and to the layer chosen in the Info Box for the tool placing them.
      (item) => (!item.layerId && this.tool?.placingKind === item.kind && this.toolOptions(item.kind, {}).layerId ? { layerId: this.toolOptions(item.kind, {}).layerId } : null),
      // ...and to the active layer, for what the tools place.
      (item) => (!item.layerId && doc.project?.activeLayerId && doc.has(doc.project.activeLayerId) && this.tool && !(this.tool instanceof SelectTool) && layered(doc, item) ? { layerId: doc.project.activeLayerId } : null),
      (item) => (!item.optionId && editingOption() && doc.has(editingOption()) && optionable(doc, item) ? { optionId: editingOption() } : null),
      (item) => (!item.worksetId && worksharingOn(doc) && worksetable(doc, item) ? { worksetId: DATUM_KINDS.has(item.kind) ? worksets(doc).find((w) => w.shared)?.id ?? this.activeWorkset()?.id : this.activeWorkset()?.id } : null),
    ];
    // An armed favorite sets what the tool places of its kind.
    doc.addOverrides = [
      (item) => {
        const fav = doc.get(this.armedFavorites.get(item.kind)) || this.pickedSettings.get(item.kind);
        if (!fav || !this.tool || this.tool instanceof SelectTool || this.tool.placingKind !== item.kind) return null;
        return favoritePatch(doc, fav, item);
      },
      // 3D input on a raised, picked or surface-aligned editing plane: the element sits at the clicked height.
      (item) => {
        const vc = this.vc;
        if (!vc?.is3D || this.activeView?.kind !== 'view3d' || !vc.placedAt || this.tool?.placingKind !== item.kind) return null;
        if (!vc.editPlane && !this.settings.alignToSurface && !this.settings.surfaceSnap) return null;
        const lv = doc.get(item.levelId);
        return lv ? offsetPatch(item.kind, vc.inputPoints?.[0]?.[2] ?? vc.placedAt[2], lv.elevation) : null;
      },
      // Gravity: objects and columns rest on the slab, roof or mesh under them (core/gravity.js).
      (item) => (this.tool?.placingKind === item.kind && (item.kind === 'component' || item.kind === 'column') ? gravityPatch(doc, this.settings.gravity, item) : null),
    ];
    // Dimension constraints follow every edit.
    doc.solver = (drivers) => new Set([...applyGlobals(doc, drivers), ...solveConstraints(doc, this.scene?.walls, drivers), ...applyScopeBoxes(doc, drivers), ...applyViewClones(doc, drivers)]);
    this.doc = doc;
    applyMepSystems(doc.project);
    applyOperationProfiles(doc.project);
    this.file = file;
    this.docId = file?.recoveryId || newId('doc');
    this.scene = new Scene(doc);
    this.selection.clear();
    this.hoverId = null;
    this.temp.clear();
    this.reveal.clear();
    this.modelVersion = -1;
    this.currentTypes.clear();
    this.armedFavorites.clear();
    this.pickedSettings.clear();
    this.openViews = [];
    this.activeViewId = null;
    this.layerHistory = new LayerHistory();
    this.layerHistory.observe(layerSnapshot(doc));
    this.changeLog = new ChangeLog(doc, (el) => (el ? describeEl(doc, el) || el.name || el.kind : ''));
    doc.on((ev) => (this.layerHistory.observe(layerSnapshot(doc)), this.changeLog.record(doc, ev), this.docChanged(ev)));
    const start = doc.get(doc.get('project')?.startViewId);
    const first = (isView(start) ? start : null) || doc.all('plan').sort((a, b) => (doc.get(a.levelId)?.elevation ?? 0) - (doc.get(b.levelId)?.elevation ?? 0))[0] || doc.all('view3d')[0];
    if (first) this.openView(first.id);
    this.renderBrowser();
    this.updateTitle();
    this.props.render();
    this.ribbon.refresh();
    this.setPrompt('Ready');
    files.scheduleRecovery(this);
    this.activeWorksetId = null;
    setEditingOption(null);
    this.sync.attach(null, null, doc.modified);
    this.renderCollab();
  }

  // Collaboration --------------------------------------------------------------------------------

  activeWorkset() {
    const w = this.doc?.get(this.activeWorksetId);
    return w?.kind === 'workset' ? w : defaultWorkset(this.doc);
  }

  setActiveWorkset(id) {
    this.activeWorksetId = id;
    this.renderCollab();
  }

  /** Edit a design option (null: the main model). Every view shows the option being edited. */
  editOption(id) {
    setEditingOption(id && this.doc.has(id) ? id : null);
    this.scene.version++;
    this.flagsVersion++;
    this.renderCollab();
    this.ribbon.refresh();
    this.requestRender();
    this.setPrompt(id ? `Editing ${optionLabel(this.doc, id)}. New elements go into this option.` : 'Editing the main model.');
  }

  /** Synchronizing needs the project in the cloud; offer to put it there. */
  async requireShared() {
    if (this.sync.active) return true;
    const ok = await confirmDialog('Save to Puter first', 'Working together needs the project in your Puter cloud storage. Save it there now? You can then share it with Share Project.', { confirm: 'Save to Puter' });
    if (ok) await this.saveAs();
    return this.sync.active;
  }

  /** Status bar: synchronization state and the active workset. */
  renderCollab() {
    const sb = this.shell?.syncBtn;
    if (!sb || !this.doc) return;
    const st = this.sync.state;
    sb.hidden = st === 'off';
    const label = { synced: 'Up to date', pending: 'Changes to share', syncing: 'Synchronizing...', offline: 'Offline' }[st] || '';
    clear(sb);
    sb.append(icon(st === 'offline' ? 'cloud-off' : st === 'syncing' ? 'refresh' : 'cloud', 14), h('span', label));
    sb.dataset.state = st;
    sb.setAttribute('data-tip-desc', st === 'pending' ? 'Click to synchronize: bring in others\' changes and share yours' : 'Changes others save appear automatically. Click to synchronize now.');
    const opt = this.shell.optSelect;
    const sets = optionSets(this.doc);
    opt.parentElement.hidden = !sets.length;
    if (sets.length) {
      clear(opt);
      opt.append(h('option', { value: '' }, 'Main Model'));
      for (const set of sets) opt.append(h('optgroup', { label: set.name }, optionsOf(this.doc, set.id).map((o) => h('option', { value: o.id }, `${o.name}${o.primary ? ' (primary)' : ''}`))));
      opt.value = editingOption() && this.doc.has(editingOption()) ? editingOption() : '';
      opt.parentElement.classList.toggle('active', !!opt.value);
    }
    const ws = this.shell.wsSelect;
    const on = worksharingOn(this.doc);
    ws.parentElement.hidden = !on;
    if (on) {
      clear(ws);
      for (const w of worksets(this.doc)) ws.append(h('option', { value: w.id }, w.name));
      ws.value = this.activeWorkset()?.id ?? '';
    }
  }

  docChanged(ev) {
    if (!ev.preview && this.sync.active && !ev.remote && this.sync.state === 'synced') this.sync.setState('pending');
    if (!ev.preview && [...ev.ids].some((id) => ['workset', 'optionSet', 'designOption'].includes(this.doc.get(id)?.kind) || !this.doc.has(id))) this.renderCollab();
    // Selection may refer to deleted items.
    let selChanged = false;
    for (const id of [...this.selection])
      if (!this.doc.has(id)) {
        this.selection.delete(id);
        selChanged = true;
      }
    // Views closed when deleted.
    for (const id of [...this.openViews]) if (!this.doc.has(id)) this.closeView(id, true);
    if (!ev.preview) {
      this.scene.prune();
      this.quickLayers?.render();
      this.tracePalette?.render();
      this.historyPalette?.render();
      this.renderBrowser();
      this.props.render();
      this.ribbon.refresh();
      this.updateTitle();
      this.renderViewbar();
      files.scheduleRecovery(this);
    }
    if (selChanged) this.selectionChanged();
    this.flagsVersion++;
    this.requestRender();
  }

  undo() {
    if (this.tool && !(this.tool instanceof SelectTool)) this.cancelTool();
    const label = this.doc.undo();
    if (label) this.setPrompt(`Undid: ${label}`);
  }

  redo() {
    const label = this.doc.redo();
    if (label) this.setPrompt(`Redid: ${label}`);
  }

  /** Run fn in a transaction; errors become a toast. Returns fn's result. */
  commit(label, fn) {
    try {
      return this.doc.transact(label, fn);
    } catch (err) {
      console.error(err);
      toast(`Could not complete "${label}": ${err.message || err}`, { kind: 'error' });
      return undefined;
    }
  }

  // Views -----------------------------------------------------------------------------------

  controllerFor(view) {
    let c = this.controllers.get(view.id);
    if (c) return c;
    if (PLAN_KINDS.has(view.kind) || view.kind === 'drafting' || view.kind === 'legend') c = new PlanController(this, view);
    else if (view.kind === 'view3d' || view.kind === 'elevation' || view.kind === 'section') c = new ModelController(this, view);
    else if (view.kind === 'schedule') c = new ScheduleController(this, view);
    else if (view.kind === 'sheet' || view.kind === 'masterLayout') c = new SheetController(this, view);
    else return null;
    this.controllers.set(view.id, c);
    return c;
  }

  openView(id) {
    const view = this.doc.get(id);
    // Master layouts open as drawing windows too (their drawing shows on every layout that uses them).
    if (!view || !(isView(view) || view.kind === 'masterLayout')) return;
    if (!this.openViews.includes(id)) this.openViews.push(id);
    if (view.kind === 'drafting' && view.doc3d) this.lastDocument3dId = id;
    // While views are tiled, a newly opened drawing view joins them.
    const tiles = this.viewport.tileIds;
    if (tiles && !tiles.includes(id) && this.controllerFor(view)?.graphical) this.viewport.setTiles([...tiles, id]);
    this.activateView(id);
  }

  /** Show the open drawing views side by side. */
  tileViews() {
    const ids = this.openViews.filter((id) => {
      const v = this.doc.get(id);
      return v && this.controllerFor(v)?.graphical;
    });
    if (ids.length < 2) return this.toast('Open two or more plans, sections, elevations, 3D views or sheets to tile them.');
    this.shell.viewcube.hidden = true;
    this.viewport.setTiles(ids);
    this.setPrompt('Views tiled. Click or scroll in a view to work in it; Tab Views (TW) shows one view again.');
    this.ribbon.refresh();
  }

  tabViews() {
    this.viewport.setTiles(null);
    this.vc?.updateCube?.();
    this.ribbon.refresh();
    this.requestRender();
  }

  activateView(id) {
    const view = this.doc.get(id);
    if (!view) return;
    const prev = this.vc;
    if (this.tool && !(this.tool instanceof SelectTool)) {
      const kinds = this.tool.viewKinds;
      if (kinds && !kinds.includes(view.kind) && !this.input3D(kinds, view)) this.cancelTool(true);
    }
    // The flat view shown before (Trace & Reference - As last shown in Active Content).
    const was = this.doc.get(this.activeViewId);
    if (was && was.id !== id && isFlatView(was) && was.kind !== 'sheet') this.lastFlatViewId = was.id;
    // Temporarily Displace Reference lasts until the view is left.
    const tr = was && was.id !== id ? this.traces.get(was.id) : null;
    if (tr?.tempFrom) {
      const { tempFrom, ...rest } = tr;
      this.traces.set(was.id, { ...rest, offset: tempFrom });
    }
    const lastKey = lastViewKey(view);
    if (lastKey) (this.lastViewByKey ||= {})[lastKey] = id;
    this.activeViewId = id;
    const c = this.controllerFor(view);
    if (prev && prev !== c) prev.deactivate?.();
    const graphical = !!c?.graphical;
    this.shell.domView.hidden = graphical;
    this.viewport.setController(graphical ? c : null);
    if (!graphical) {
      this.shell.viewcube.hidden = true;
      c?.mount(this.shell.domView);
    }
    this.renderNav();
    this.renderTabs();
    this.renderViewbar();
    this.renderBrowser();
    this.props.render();
    this.updateTitle();
    this.flagsVersion++;
    this.requestRender();
    this.ribbon.refresh();
  }

  closeView(id, silent = false) {
    const i = this.openViews.indexOf(id);
    if (i < 0) return;
    this.openViews.splice(i, 1);
    const tiles = this.viewport.tileIds;
    if (tiles?.includes(id)) this.viewport.setTiles(tiles.filter((x) => x !== id));
    const c = this.controllers.get(id);
    if (c) {
      c.deactivate?.();
      c.dispose?.();
      this.controllers.delete(id);
    }
    if (this.activeViewId === id) {
      const next = this.openViews[Math.min(i, this.openViews.length - 1)];
      if (next) this.activateView(next);
      else {
        this.activeViewId = null;
        this.viewport.setController(null);
        this.showHome(true);
      }
    } else if (!silent) this.renderTabs();
    this.renderTabs();
  }

  closeInactiveViews() {
    for (const id of [...this.openViews]) if (id !== this.activeViewId) this.closeView(id, true);
    this.renderTabs();
  }

  cycleView(dir) {
    if (this.openViews.length < 2) return;
    const i = this.openViews.indexOf(this.activeViewId);
    this.activateView(this.openViews[(i + dir + this.openViews.length) % this.openViews.length]);
  }

  selectViewInBrowser(view) {
    // A single click on a view shows its properties without opening it.
    this.browserViewSel = view.id;
  }

  renderTabs() {
    const el = this.shell.vtabs;
    clear(el);
    if (this.workspace?.on) el.append(h('button.vtab-tile', { type: 'button', 'aria-label': 'Tile Views', 'data-tip': 'Tile Views', onClick: () => this.run('tileViews') }, icon('tileViews', 17)));
    this.openViews.forEach((id, i) => {
      const v = this.doc?.get(id);
      if (!v) return;
      const active = id === this.activeViewId;
      el.append(
        h(
          `div.vtab${active ? '.active' : ''}`,
          { role: 'presentation' },
          h(
            'button.vtab-btn',
            {
              type: 'button',
              role: 'tab',
              'aria-selected': String(active),
              tabindex: active ? '0' : '-1',
              title: v.name,
              onClick: () => this.activateView(id),
              onAuxclick: (e) => e.button === 1 && this.closeView(id),
              onKeydown: (e) => {
                if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
                  const j = (i + (e.key === 'ArrowRight' ? 1 : -1) + this.openViews.length) % this.openViews.length;
                  this.activateView(this.openViews[j]);
                  requestAnimationFrame(() => el.querySelector('.vtab.active .vtab-btn')?.focus());
                } else if (e.key === 'Delete') {
                  e.preventDefault();
                  e.stopPropagation();
                  this.closeView(id);
                }
              },
              onContextmenu: (e) => {
                e.preventDefault();
                showMenu({ x: e.clientX, y: e.clientY }, [
                  { label: 'Close', icon: 'x', action: () => this.closeView(id) },
                  { label: 'Close Inactive Views', icon: 'closeHidden', action: () => this.closeInactiveViews() },
                ]);
              },
            },
            icon(KIND_ICON[v.kind] || 'file', 14),
            h('span.vtab-name', this.workspace?.on ? `[${this.workspace.tr(this.viewName(v))}]` : this.viewName(v)),
          ),
          h('button.icon-btn.sm.vtab-close', { type: 'button', tabindex: '-1', 'aria-hidden': 'true', title: `Close ${v.name}`, onClick: () => this.closeView(id) }, icon('x', 13)),
        ),
      );
    });
    el.querySelector('.vtab.active')?.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
  }

  renderNav() {
    const nav = this.shell.nav;
    clear(nav);
    const c = this.vc;
    nav.hidden = !c?.graphical;
    if (!c?.graphical) return;
    nav.classList.toggle('plan', !c.is3D);
    const btn = (cmd, label, ic, onClick) => h('button.icon-btn', { type: 'button', 'aria-label': label, 'data-tip': label, onClick }, icon(ic, 17));
    nav.append(
      btn('zoomFit', 'Zoom to fit', 'zoomFit', () => this.zoomFit()),
      btn('zoomIn', 'Zoom in', 'zoom-in', () => c.zoomBy(1.5)),
      btn('zoomOut', 'Zoom out', 'zoom-out', () => c.zoomBy(1 / 1.5)),
      btn('zoomRegion', 'Zoom in region', 'zoomRegion', () => this.run('zoomRegion')),
    );
    const panBtn = btn('navPan', 'Pan with the left button or one finger', 'hand', () => this.setNavMode(this.navMode === 'pan' ? null : 'pan'));
    panBtn.setAttribute('aria-pressed', String(this.navMode === 'pan'));
    nav.append(panBtn);
    if (c.is3D) {
      const orbitBtn = btn('navOrbit', 'Orbit with the left button', 'orbit', () => this.setNavMode(this.navMode === 'orbit' ? null : 'orbit'));
      orbitBtn.setAttribute('aria-pressed', String(this.navMode === 'orbit'));
      nav.append(orbitBtn);
    }
  }

  setNavMode(m) {
    this.navMode = m;
    this.renderNav();
    this.setPrompt(m === 'pan' ? 'Pan mode: drag to pan. Click the hand again to leave.' : m === 'orbit' ? 'Orbit mode: drag to orbit. Click the button again to leave.' : 'Ready');
  }

  renderViewbar() {
    renderViewbar(this);
    this.renderBanner();
  }

  renderBanner() {
    const b = this.shell.banner;
    const t = this.temp.get(this.activeViewId);
    const reveal = this.reveal.has(this.activeViewId);
    clear(b);
    const ge = this.groupEdit;
    b.hidden = !t && !reveal && !ge;
    if (ge) {
      const type = this.doc.get(this.doc.get(ge.groupId)?.typeId);
      b.append(
        h('span', `Editing group: ${type?.name || 'Group'}`),
        h('button.btn.sm.primary', { type: 'button', onClick: () => this.finishGroupEdit(true) }, 'Finish'),
        h('button.btn.sm', { type: 'button', onClick: () => this.finishGroupEdit(false) }, 'Cancel'),
      );
    } else if (t) b.append(h('span', t.mode === 'isolate' ? 'Temporary isolate' : 'Temporary hide'), h('button.btn.sm', { type: 'button', onClick: () => this.temporary('reset') }, 'Reset'));
    else if (reveal) b.append(h('span', 'Revealing hidden elements'), h('button.btn.sm', { type: 'button', onClick: () => this.toggleReveal() }, 'Close'));
  }

  zoomFit() {
    const c = this.vc;
    if (!c) return;
    if (c.is2D) c.zoomExtents();
    else c.zoomExtents?.();
    this.viewChanged();
  }

  viewChanged() {
    const c = this.vc;
    if (c?.cam) this.viewStates.set(this.activeViewId, structuredClone(c.cam));
    this.updateCoords();
  }

  orient3D(yaw, pitch, fit = false) {
    const c = this.vc;
    if (c?.is3D) c.orient(yaw, pitch, fit);
  }

  open3D() {
    let v = this.doc.all('view3d')[0];
    if (!v) {
      v = default3DView();
      this.commit('3D view', () => this.doc.add(v));
    }
    this.openView(v.id);
  }

  /**
   * Archicad's Show Selection/Marquee in 3D (F5): the 3D view with only the
   * selection (and what its walls host), or the part of the marquee's story
   * inside the marquee, as a section box.
   */
  show3D() {
    const doc = this.doc;
    const mq = this.marquee && doc.has(this.marquee.levelId) ? this.marquee : null;
    const ids = new Set(expandGroups(doc, this.selection));
    for (const el of doc.items.values()) if (el.hostId && ids.has(el.hostId)) ids.add(el.id);
    this.open3D();
    const v = this.activeView;
    if (v?.kind !== 'view3d') return;
    if (!ids.size && mq) {
      const level = doc.get(mq.levelId);
      const z0 = +level.elevation || 0;
      const z1 = doc.levelAbove(level.id)?.elevation ?? z0 + 3000;
      this.temp.delete(v.id);
      this.commit('Marquee in 3D', () => doc.update(v.id, { sectionBox: { min: [mq.x0, mq.y0, z0 - 1], max: [mq.x1, mq.y1, z1 - 1] } }));
    } else if (ids.size) this.temp.set(v.id, { mode: 'isolate', ids });
    else this.temp.delete(v.id);
    this.select([]);
    this.flagsVersion++;
    this.renderViewbar();
    // Frame it once the 3D view has its model and size.
    requestAnimationFrame(() => this.vc?.zoomExtents?.(true, false, ids.size ? ids : null));
  }

  // Publisher sets (Navigator map; io/exporters.js publishPDF) ------------------------------------

  /** A new set: every layout in number order, or else every floor plan. */
  newPublisherSet() {
    const doc = this.doc;
    const sheets = doc.all('sheet').sort((a, b) => String(a.number).localeCompare(String(b.number), undefined, { numeric: true }));
    const items = (sheets.length ? sheets : doc.all('plan').filter((v) => !v.cloneId).sort((a, b) => (doc.get(a.levelId)?.elevation ?? 0) - (doc.get(b.levelId)?.elevation ?? 0))).map((v) => v.id);
    const name = uniqueName(doc.all('publisherSet').map((x) => x.name), sheets.length ? 'Layouts' : 'Floor Plans');
    let id;
    this.commit('New publisher set', () => (id = doc.add({ kind: 'publisherSet', name, items }).id));
    this.browser?.setMap?.('publisher');
    return id;
  }

  publishSet(id) {
    const set = this.doc.get(id);
    if (!set?.items?.length) return this.toast('The set is empty. Add views to it first.', { kind: 'error' });
    return exporters.publishPDF(this, set.items, set.name);
  }

  /** File > Publish: the Publisher map, with a first set when there is none. */
  publisher() {
    if (!this.doc.count('publisherSet')) this.newPublisherSet();
    this.browser?.setMap?.('publisher');
    if (!this.workspace?.on) this.toast('Publisher sets are in the Navigator of the Archicad workspace (View > Archicad-Style Workspace).');
  }

  /** Height of one corner of a morph prism, typed in (core/morph.js). */
  async morphNodeHeight(id, i) {
    const doc = this.doc;
    const el = doc.get(id);
    if (!el?.boundary) return;
    const text = await promptDialog('Node Height', 'Height of this corner above the morph base', formatLength(cornerHeight(el, i), doc.units), { okLabel: 'Set', validate: (v) => (Number.isFinite(parseLength(v, doc.units)) ? null : 'Enter a height.') });
    if (text == null) return;
    const h = parseLength(text, doc.units);
    const heights = el.boundary.map((_, k) => (k === i ? h : cornerHeight(el, k)));
    this.commit('Node height', () => doc.update(id, { heights }));
  }

  /** Archicad's Convert to Morph: the selected elements (and what their walls host) become one frozen body. */
  convertToMorph() {
    const doc = this.doc;
    const ids = new Set([...expandGroups(doc, this.selection)].filter((id) => MODEL_KINDS.includes(doc.get(id)?.kind)));
    for (const el of doc.items.values()) if (el.hostId && ids.has(el.hostId)) ids.add(el.id);
    const els = [...ids].map((id) => doc.get(id));
    const meshes = els.map((el) => this.scene.mesh(el)).filter((m) => m?.pos?.length);
    if (!meshes.length) return this.toast('Select model elements with a 3D body first.', { kind: 'error' });
    const { tris, cols } = freezeMeshes(meshes);
    let id;
    this.commit('Convert to Morph', () => {
      id = doc.add({ kind: 'morph', levelId: els.find((e) => e.levelId)?.levelId ?? this.activeLevelId(), tris, cols, baseOffset: 0 }).id;
      deleteElements(doc, [...ids]);
    });
    this.select([id]);
    this.toast(`Converted ${els.length} element${els.length === 1 ? '' : 's'} to a morph.`, { kind: 'success' });
  }

  /** The selected morphs that are bodies of triangles (frozen ones). */
  selectedBodies() {
    return [...this.selection].map((id) => this.doc.get(id)).filter((el) => el?.kind === 'morph' && Array.isArray(el.tris) && el.tris.length >= 9);
  }

  /** Check Solidity (Design > Modify Morph): whether each selected morph is a closed body. */
  checkMorphSolidity() {
    const morphs = [...this.selection].map((id) => this.doc.get(id)).filter((el) => el?.kind === 'morph');
    if (!morphs.length) return this.toast('Select morphs first.', { kind: 'error' });
    const lines = morphs.map((m, i) => {
      if (!m.tris) return `Morph ${i + 1}: solid (a prism morph)`;
      const r = checkSolidity(m.tris);
      if (r.solid) return `Morph ${i + 1}: solid, ${r.triangles} faces`;
      const bad = [r.open && `${r.open} open edges`, r.nonManifold && `${r.nonManifold} edges on more than two faces`, r.flipped && `${r.flipped} edges between faces turned opposite ways`].filter(Boolean).join(', ');
      return `Morph ${i + 1}: not solid (${bad})${r.open ? '. Cover with Faces closes its holes.' : ''}`;
    });
    const allSolid = lines.every((l) => /: solid/.test(l));
    this.toast(lines.join('\n'), { kind: allSolid ? 'success' : 'error' });
    return lines;
  }

  /** Cover with Faces: close the holes (loops of open edges) of the selected morphs. */
  coverMorphFaces() {
    const bodies = this.selectedBodies();
    if (!bodies.length) return this.toast('Select morphs made of faces (Convert to Morph) first.', { kind: 'error' });
    let n = 0;
    this.commit('Cover with Faces', () => {
      for (const m of bodies) {
        const r = coverWithFaces(m.tris);
        if (!r.holes) continue;
        n += r.holes;
        const cols = (m.cols || []).slice();
        const last = cols.at(-1) || [190, 190, 190, 255];
        while (cols.length < r.tris.length / 9) cols.push(last);
        this.doc.update(m.id, { tris: r.tris, cols });
      }
    });
    this.toast(n ? `Closed ${n} hole${n === 1 ? '' : 's'}.` : 'The selected morphs have no holes.', { kind: n ? 'success' : 'info' });
    return n;
  }

  /** Smooth & Merge Faces: faces of the selected morphs meeting under an angle merge (their edges not drawn). */
  async smoothMorphFaces(angle) {
    const bodies = this.selectedBodies();
    if (!bodies.length) return this.toast('Select morphs made of faces (Convert to Morph) first.', { kind: 'error' });
    if (angle == null) {
      const text = await promptDialog('Smooth & Merge Faces', 'Faces meeting under this angle (degrees) merge', String(bodies[0].smoothAngle ?? 20), { okLabel: 'Merge', validate: (v) => (Number.isFinite(+v) && +v >= 0 && +v < 180 ? null : 'Enter an angle from 0 to 179.') });
      if (text == null) return;
      angle = +text;
    }
    this.commit('Smooth & Merge Faces', () => bodies.forEach((m) => this.doc.update(m.id, { smoothAngle: +angle })));
  }

  /** Railings on the selected stairs (both sides) and slabs (free edges), with the current railing type (core/autorail.js). */
  railingsOnSelection() {
    const doc = this.doc;
    const typeId = this.currentType('railing')?.id;
    const sel = [...this.selection].map((id) => doc.get(id)).filter(Boolean);
    const rails = [
      ...sel.filter((e) => e.kind === 'stair').flatMap((s) => railingsOnStair(doc, s, typeId)),
      ...sel.filter((e) => e.kind === 'floor').flatMap((f) => railingsOnSlabEdges(doc, f, typeId)),
    ];
    if (!rails.length) return this.toast('Select stairs or slabs: railings go on the sides of stairs and on the free edges of slabs.', { kind: 'error' });
    const ids = [];
    this.commit('Railings', () => rails.forEach((r) => ids.push(doc.add(r).id)));
    this.select(ids);
    this.toast(`Placed ${ids.length} railing${ids.length === 1 ? '' : 's'}.`, { kind: 'success' });
  }

  /** The plan of the story above (d = 1) or below (d = -1) the active one. */
  gotoStory(d) {
    const levels = this.doc.levels();
    const i = levels.findIndex((l) => l.id === this.activeLevelId());
    const next = levels[i + d];
    if (!next) return this.toast(d > 0 ? 'This is the top story.' : 'This is the lowest story.');
    const plan = this.doc.all('plan').find((p) => p.levelId === next.id && !p.calloutOf && !p.cloneId) || this.doc.all('plan').find((p) => p.levelId === next.id);
    if (plan) this.openView(plan.id);
  }

  /** Archicad's Elevate: move the selection up or down by a distance typed in (core/elevate.js). */
  async elevateSelection() {
    const doc = this.doc;
    const els = [...expandGroups(doc, this.selection)].map((id) => doc.get(id)).filter(Boolean);
    const movable = els.filter((e) => elevatePatch(doc, e, 0));
    if (!movable.length) return this.toast('Select elements with a height above their level (walls, slabs, roofs, columns, objects, windows...).', { kind: 'error' });
    const text = await promptDialog('Elevate', 'Vertical distance (negative goes down)', formatLength(0, doc.units), { okLabel: 'Elevate', validate: (v) => (Number.isFinite(parseLength(v, doc.units)) ? null : 'Enter a distance.') });
    if (text == null) return;
    const dz = parseLength(text, doc.units);
    if (!dz) return;
    this.commit('Elevate', () => movable.forEach((e) => doc.update(e.id, elevatePatch(doc, doc.get(e.id), dz))));
    this.toast(`Moved ${movable.length} element${movable.length === 1 ? '' : 's'} ${dz > 0 ? 'up' : 'down'} by ${formatLength(Math.abs(dz), doc.units)}.`);
  }

  /** Archicad's Interior Elevations: one elevation per wall of each selected room. */
  interiorElevations() {
    const doc = this.doc;
    const rooms = [...this.selection].map((id) => doc.get(id)).filter((e) => e?.kind === 'room');
    if (!rooms.length) return this.toast('Select one or more rooms (zones) first.', { kind: 'error' });
    const views = [];
    for (const r of rooms) {
      const region = this.scene.rooms.room(r);
      if (region) views.push(...interiorElevations(doc, r, region, this.doc.units.system === 'imperial' ? 48 : 50));
    }
    if (!views.length) return this.toast('The selected rooms are not enclosed.', { kind: 'error' });
    const ids = [];
    this.commit('Interior elevations', () => views.forEach((v) => ids.push(doc.add(v).id)));
    this.renderBrowser();
    this.toast(`Created ${ids.length} interior elevations.`, { kind: 'success' });
    this.openView(ids[0]);
  }

  /** Level dimensions of slabs, walls and roofs on a chain beside the building, in a section or elevation (core/autolevels.js). */
  autoLevelDims() {
    const v = this.activeView;
    if (v?.kind !== 'section' && v?.kind !== 'elevation') return this.toast('Open a section or an elevation first.', { kind: 'error' });
    this.syncModel();
    const spots = levelDimensions(this.doc, v, (el) => this.scene.mesh(el));
    if (!spots.length) return this.toast('Nothing to measure in this view.', { kind: 'error' });
    const ids = [];
    this.commit('Level dimensions', () => spots.forEach((s) => ids.push(this.doc.add(s).id)));
    this.select(ids);
    this.toast(`Placed ${ids.length} level dimensions.`, { kind: 'success' });
  }

  /** Archicad's Exterior Dimensioning: chains around the selected walls, or every wall of the plan's story. */
  autoDimExterior() {
    const v = this.activeView;
    if (v?.kind !== 'plan') return this.toast('Open a floor plan to dimension its walls.', { kind: 'error' });
    const doc = this.doc;
    const sel = [...this.selection].map((id) => doc.get(id)).filter((e) => e?.kind === 'wall');
    const walls = sel.length ? sel : doc.all('wall').filter((w) => w.levelId === v.levelId);
    const dims = exteriorDimensions(doc, walls, v.id, +v.scale || 100);
    if (!dims.length) return this.toast('No walls to dimension here.', { kind: 'error' });
    const ids = [];
    this.commit('Exterior dimensions', () => dims.forEach((d) => ids.push(doc.add(d).id)));
    this.select(ids);
    this.toast(`Placed ${ids.length} dimension chains around ${sel.length ? 'the selected walls' : 'the story'}.`, { kind: 'success' });
  }

  new3DView() {
    const names = this.doc.all('view3d').map((v) => v.name);
    const v = { ...default3DView(uniqueName(names, '3D View 2')) };
    this.commit('New 3D view', () => this.doc.add(v));
    this.openView(v.id);
  }

  duplicateView(id, { detailing = false } = {}) {
    const v = this.doc.get(id || this.activeViewId);
    if (!v || !isView(v) || v.kind === 'schedule' || v.kind === 'sheet') return this.toast('Choose a plan, 3D view or section to duplicate.', { kind: 'error' });
    const names = this.doc.filter((x) => isView(x)).map((x) => x.name);
    const { id: _id, ...rest } = v;
    void _id;
    let copy;
    this.commit(detailing ? 'Duplicate view with detailing' : 'Duplicate view', () => {
      copy = this.doc.add({ ...rest, id: newId('v'), name: uniqueName(names, `${v.name} Copy 1`) });
      if (!detailing) return;
      for (const el of this.doc.filter((x) => x.viewId === v.id && x.kind !== 'viewport')) {
        const { id: _eid, ...er } = el;
        void _eid;
        this.doc.add({ ...er, viewId: copy.id });
      }
    });
    if (copy) this.openView(copy.id);
  }

  /**
   * Import PDF: pages of a PDF (a floor plan from a CAD program or a scan)
   * as underlays in the plan, side by side. With the drawing's scale the
   * pictures come in at true size; otherwise calibrate them afterwards.
   */
  async importPDF(file = null) {
    const f = file || (await files.pickFile('application/pdf,.pdf'));
    if (!f) return;
    if (f.size > 60e6) return this.toast('That PDF is larger than 60 MB.', { kind: 'error' });
    let pdf;
    try {
      const { openPDF } = await import('./io/pdfread.js');
      pdf = await openPDF(new Uint8Array(await f.arrayBuffer()));
    } catch (err) {
      return this.toast(`That PDF could not be read: ${err.message || err}`, { kind: 'error' });
    }
    const units = this.doc.units;
    const pages = h('input.input', { type: 'text', value: pdf.pages > 1 ? `1-${Math.min(pdf.pages, 4)}` : '1', 'aria-label': 'Pages' });
    // The scale the sheet states in its title block, when it does.
    let stated = [];
    let firstVec = null;
    try {
      firstVec = await pdf.vectors(1);
      stated = statedScales(firstVec.texts);
    } catch {
      firstVec = null;
    }
    const scales = [...new Set([20, 50, 100, 200, 500, 1000, ...stated])].sort((a, b) => a - b);
    const preset = stated[0] || 100;
    const scale = h('select.input', { 'aria-label': 'Drawing scale' }, h('option', { value: '' }, 'Not known: calibrate afterwards'), ...scales.map((s) => h('option', { value: s, selected: s === preset }, `1:${s}${stated.includes(s) ? ' (stated on the sheet)' : ''}`)));
    const dpi = h('select.input', { 'aria-label': 'Resolution' }, ...[150, 200, 300].map((d) => h('option', { value: d, selected: d === 200 }, `${d} dpi`)));
    const isPlan = this.activeView?.kind === 'plan' && !!this.activeView.levelId;
    const canModel = isPlan && !!firstVec?.paths?.some((q) => q.fill);
    const as = h('select.input', { 'aria-label': 'Import as' },
      h('option', { value: 'model', disabled: !canModel, selected: canModel && !!stated.length }, 'Model: walls, doors, windows, columns and zones (PDFs from CAD programs)'),
      h('option', { value: 'picture', selected: !(canModel && stated.length) }, 'Picture (scans and any PDF)'),
      h('option', { value: 'lines' }, 'Lines and text (PDFs from CAD programs)'),
      h('option', { value: 'both' }, 'Both, one over the other'));
    const first = await pdf.size(1);
    const ok = await openDialogFn({
      title: 'Import PDF',
      size: 'sm',
      body: h('div',
        h('p.dialog-text', `${f.name}: ${pdf.pages} page${pdf.pages === 1 ? '' : 's'}, ${Math.round(first.widthMm)} x ${Math.round(first.heightMm)} mm.`),
        h('label.field', h('span.field-label', 'Pages (for example 1, or 1-3, 5)'), pages),
        h('label.field', h('span.field-label', 'Scale of the drawing'), scale),
        h('label.field', h('span.field-label', 'Import as'), as),
        h('label.field', h('span.field-label', 'Resolution of pictures'), dpi),
        h('p.field-hint', 'Model reads the first page chosen: walls from the cut fills, doors and windows in the gaps between them (a door by its swing), free-standing columns, and zones at the zone stamps, with the page as a picture under them to check against. Pictures go in the plan to trace over, or for the assistant to model. Lines and text become drafting in the view: select them and use Convert Selection. With the scale, pages come in at true size (lines need it; 1:100 is assumed without).')),
      initialFocus: 'input',
      actions: [
        { label: 'Cancel', value: null },
        { label: 'Import', primary: true, value: true },
      ],
    });
    if (!ok) return pdf.close();
    const want = [];
    for (const part of pages.value.split(/[,\s]+/)) {
      const m = /^(\d+)(?:-(\d+))?$/.exec(part.trim());
      if (!m) continue;
      for (let i = +m[1]; i <= +(m[2] || m[1]); i++) if (i >= 1 && i <= pdf.pages && !want.includes(i)) want.push(i);
    }
    if (!want.length) return pdf.close(), this.toast('Choose pages that are in the PDF.', { kind: 'error' });
    const k = +scale.value || 0;
    const mode = as.value;
    if (mode === 'model') return this.modelFromPdf(pdf, want[0], k, f.name, +dpi.value, want[0] === 1 ? firstVec : null);
    let x = 0;
    const ids = [];
    let lines = 0;
    this.setPrompt(`Reading ${want.length} page${want.length === 1 ? '' : 's'}...`);
    for (const i of want) {
      const size = await pdf.size(i);
      const kk = k || (mode === 'picture' ? 0 : 100);
      const width = kk ? size.widthMm * kk : 20000;
      if (mode !== 'lines') {
        const { canvas, widthMm, heightMm } = await pdf.render(i, { dpi: +dpi.value });
        const el = placeUnderlay(this, { src: canvas.toDataURL('image/png'), name: `${f.name.replace(/\.pdf$/i, '')} - page ${i}`, px: [canvas.width, canvas.height], width, at: [x, 0], calibrated: !!kk, pageMm: [widthMm, heightMm] });
        if (el) ids.push(el.id);
      }
      if (mode !== 'picture') {
        const vec = await pdf.vectors(i);
        const made = this.placePdfVectors(vec, kk, [x, 0]);
        ids.push(...made);
        lines += vec.segments.length;
      }
      x += width * 1.05;
    }
    pdf.close();
    if (ids.length) {
      this.select(ids);
      this.run('zoomFit');
    }
    if (mode !== 'picture') this.setPrompt(`Placed ${lines} lines at 1:${k || 100}. Select them and use Convert Selection to make walls, slabs or zones.`);
    else this.setPrompt(k ? `Placed ${ids.length} page${ids.length === 1 ? '' : 's'} at 1:${k}.` : 'Pages placed. Use Calibrate Image to set their scale from a length you know, or ask the assistant to model them.');
  }

  /**
   * Make a model from one page of a CAD PDF in the active plan, at 1:k (the
   * stated scale when k is 0), with the page as a picture under it. Reports
   * how many zones measure as their stamps say.
   */
  async modelFromPdf(pdf, page, k, name, dpi = 200, vec = null) {
    const view = this.activeView;
    try {
      vec = vec || (await pdf.vectors(page));
      const rec = recognizePDF(vec, { scale: k || null });
      if (rec.error) return this.toast(rec.error, { kind: 'error' }), { error: rec.error };
      const { canvas, widthMm, heightMm } = await pdf.render(page, { dpi });
      // The building's middle at the origin, the page moved with it.
      const mid = recognizedMiddle(rec);
      shiftRecognized(rec, [-mid[0], -mid[1]]);
      placeUnderlay(this, { src: canvas.toDataURL('image/png'), name: `${name.replace(/\.pdf$/i, '')} - page ${page}`, px: [canvas.width, canvas.height], width: widthMm * rec.scale, at: [-mid[0], -mid[1]], calibrated: true, pageMm: [widthMm, heightMm] });
      let out;
      this.commit('Model from PDF', () => {
        out = buildRecognized(this.doc, rec, { levelId: view.levelId });
        addRecognizedAnnotations(this.doc, rec, view.id, interiorDimension);
      });
      this.run('zoomFit');
      const check = stampCheck(this.doc, this.scene || new Scene(this.doc), out.rooms, rec.plan.rooms);
      this.setPrompt(`1:${rec.scale}: ${out.walls.length} walls, ${out.doors.length} doors, ${out.windows.length} windows, ${out.columns.length} columns and ${out.rooms.length} zones made${check.total ? `; ${check.match} of ${check.total} zones measure as their stamps say` : ''}.`);
      if (out.skipped?.length) this.toast(out.skipped.slice(0, 3).join('; '), { kind: 'info' });
      return { scale: rec.scale, stated: rec.stated, walls: out.walls.length, doors: out.doors.length, windows: out.windows.length, columns: out.columns.length, zones: out.rooms.length, stampsMatched: check.match, stamps: check.total, skipped: out.skipped?.slice(0, 10) };
    } catch (err) {
      this.toast(`The PDF could not be modelled: ${err.message || err}`, { kind: 'error' });
      return { error: String(err.message || err) };
    } finally {
      pdf.close();
    }
  }

  /**
   * Straighten a photo of a plan taken at an angle (the selected picture,
   * else the last placed): the sheet's corners are found, or given in the
   * picture's pixels [top left, top right, bottom right, bottom left], and
   * the picture becomes the sheet seen square on. It then needs calibrating.
   */
  async straightenImage(imageId = null, corners = null, { quiet = false } = {}) {
    const sel = this.selection?.size ? [...this.selection].map((id) => this.doc.get(id)).find((e) => e?.kind === 'image') : null;
    const img = imageId ? this.doc.get(imageId) : sel || this.doc.all('image').at(-1);
    const fail = (msg) => (quiet || this.toast(msg, { kind: 'error' }), { error: msg });
    if (img?.kind !== 'image') return fail('Select a photo of a plan first.');
    const pic = await new Promise((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('The picture could not be read'));
      el.src = img.src;
    });
    const k = Math.min(1, 3000 / Math.max(pic.naturalWidth, pic.naturalHeight));
    const w = Math.round(pic.naturalWidth * k);
    const h = Math.round(pic.naturalHeight * k);
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(pic, 0, 0, w, h);
    const [pw, ph] = img.px || [pic.naturalWidth, pic.naturalHeight];
    const given = Array.isArray(corners) && corners.length === 4 ? corners.map((p) => [(+p[0] * w) / pw, (+p[1] * h) / ph]) : null;
    const out = rectifyPhoto({ data: ctx.getImageData(0, 0, w, h).data, w, h }, given);
    if (!out) return fail('The sheet\'s corners could not be found: give them (Pet palette or the assistant).');
    // A scan or an export is the sheet already: nothing to straighten.
    const near = (p, q) => Math.abs(p[0] - q[0]) < 0.02 * w && Math.abs(p[1] - q[1]) < 0.02 * h;
    if (!given && near(out.corners[0], [0, 0]) && near(out.corners[1], [w, 0]) && near(out.corners[2], [w, h]) && near(out.corners[3], [0, h])) return { id: img.id, unchanged: true };
    const o = document.createElement('canvas');
    o.width = out.w;
    o.height = out.h;
    o.getContext('2d').putImageData(new ImageData(out.data, out.w, out.h), 0, 0);
    const src = o.toDataURL('image/jpeg', 0.92);
    this.commit('Straighten picture', () => this.doc.update(img.id, { src, px: [out.w, out.h], h: (img.w * out.h) / out.w, calibrated: false }));
    this.setPrompt('Picture straightened. Calibrate it from a length you know, then use Model from Picture.');
    return { id: img.id, pixels: [out.w, out.h], corners: out.corners.map((p) => [Math.round((p[0] * pw) / w), Math.round((p[1] * ph) / h)]) };
  }

  /**
   * Make a model from a picture of a plan placed in a floor plan (the
   * selected one, else the last placed): its thick dark strokes become
   * walls, the gaps doors and windows, the enclosed floor zones. The picture
   * must be calibrated. Returns a summary, or { error }.
   */
  async modelFromImage(imageId = null) {
    const sel = this.selection?.size ? [...this.selection].map((id) => this.doc.get(id)).find((e) => e?.kind === 'image') : null;
    const img = imageId ? this.doc.get(imageId) : sel || this.doc.all('image').at(-1);
    const fail = (msg) => (this.toast(msg, { kind: 'error' }), { error: msg });
    if (img?.kind !== 'image') return fail('Select a picture of a plan first (Import Image or PDF).');
    const view = this.doc.get(img.viewId);
    if (view?.kind !== 'plan' || !view.levelId) return fail('The picture must be in a floor plan.');
    if (!img.calibrated) return fail('Calibrate the picture first: Calibrate Image, then click a length you know.');
    this.setPrompt('Reading the picture...');
    const pic = await new Promise((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('The picture could not be read'));
      el.src = img.src;
    });
    // At most about 12 million pixels.
    const k = Math.min(1, Math.sqrt(12e6 / (pic.naturalWidth * pic.naturalHeight)));
    const w = Math.max(1, Math.round(pic.naturalWidth * k));
    const h = Math.max(1, Math.round(pic.naturalHeight * k));
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(pic, 0, 0, w, h);
    const data = ctx.getImageData(0, 0, w, h).data;
    const gray = new Uint8Array(w * h);
    for (let i = 0; i < gray.length; i++) gray[i] = (data[4 * i] * 0.299 + data[4 * i + 1] * 0.587 + data[4 * i + 2] * 0.114) | 0;
    const [pw, ph] = img.px || [pic.naturalWidth, pic.naturalHeight];
    const toModel = (p) => imagePointToModel(img, [(p[0] / w) * pw, (p[1] / h) * ph]);
    const rec = recognizeImage({ gray, w, h }, { mmPerPx: (imageScale(img) * pw) / w, toModel });
    if (!rec.plan.walls.length) return this.setPrompt('Ready'), fail('No walls were found: the picture needs walls drawn as thick dark strokes.');
    let out;
    this.commit('Model from picture', () => (out = buildRecognized(this.doc, { plan: rec.plan, columns: [] }, { levelId: view.levelId })));
    const zones = rec.plan.rooms.map((r) => Math.round(r.area * 100) / 100);
    this.setPrompt(`${out.walls.length} walls, ${out.doors.length} doors, ${out.windows.length} windows and ${out.rooms.length} zones made from the picture. Name the zones, and check the model against the picture.`);
    return { walls: out.walls.length, doors: out.doors.length, windows: out.windows.length, zones: out.rooms.map((id, i) => ({ id, area: zones[i] })), skipped: out.skipped?.slice(0, 10) };
  }

  /** A PDF page's vector drawing as detail lines and text in the plan, at 1:k, its bottom left at `at`. Returns the new ids. */
  placePdfVectors(vec, k, at = [0, 0], view = null) {
    const v = view || (this.activeView && isPlanView(this.activeView) ? this.activeView : this.doc.all('plan')[0]);
    if (!v) return [];
    const P = (x, y) => [at[0] + x * k, at[1] + y * k];
    const ids = [];
    const vs = +v.scale || 100;
    this.commit('Import PDF lines', () => {
      for (const s of vec.segments) ids.push(this.doc.add({ kind: 'detailLine', viewId: v.id, a: P(s[0], s[1]), b: P(s[2], s[3]), style: 'thin' }).id);
      for (const t of vec.texts) ids.push(this.doc.add({ kind: 'text', viewId: v.id, at: P(...t.at), text: t.text, size: Math.max(0.5, Math.round(((t.size * k) / vs) * 10) / 10), rotation: ((t.angle || 0) * 180) / Math.PI, align: 'left' }).id);
    });
    return ids;
  }

  /** Place a raster image (PNG, JPEG, SVG...) in the active 2D view, to trace over or show. */
  importImage() {
    const v = this.activeView;
    const c = this.vc;
    if (!v || !c?.is2D || v.kind === 'sheet') return this.toast('Open a plan, drafting view or legend to place an image.', { kind: 'error' });
    const input = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/gif,image/webp,image/svg+xml', hidden: true });
    input.addEventListener('change', () => {
      const file = input.files?.[0];
      input.remove();
      if (!file) return;
      if (file.size > 12e6) return this.toast('That image is larger than 12 MB. Please use a smaller one.', { kind: 'error' });
      const reader = new FileReader();
      reader.onload = () => {
        const src = String(reader.result);
        const img = new Image();
        img.onload = () => {
          // Half the visible width, centred in the view.
          const viewW = this.viewport.width / c.cam.zoom;
          const w = viewW * 0.5;
          const hh = (w * img.naturalHeight) / Math.max(1, img.naturalWidth);
          const at = [c.cam.cx - w / 2, c.cam.cy - hh / 2];
          let el;
          this.commit('Import image', () => (el = this.doc.add({ kind: 'image', viewId: v.id, at, w, h: hh, rotation: 0, opacity: 1, src, name: file.name, px: [img.naturalWidth, img.naturalHeight] })));
          this.select([el.id]);
          this.setPrompt('Image placed. Drag it to move, drag its corner to scale it, or use Calibrate Image to set its scale from a known length.');
        };
        img.onerror = () => this.toast('That file could not be read as an image.', { kind: 'error' });
        img.src = src;
      };
      reader.readAsDataURL(file);
    });
    document.body.append(input);
    input.click();
  }

  newFlatView(kind) {
    return dialogs.newFlatViewDialog(this, kind);
  }

  toggleCrop(key) {
    const v = this.activeView;
    if (!v || !isPlanView(v)) return this.toast('Crop regions are for plan views.', { kind: 'error' });
    const on = !v[key];
    this.commit(key === 'cropOn' ? 'Crop view' : 'Show crop region', () => this.doc.update(v.id, { [key]: on, ...(on && !v.crop ? { crop: defaultCrop(this, v) } : {}) }));
    this.renderViewbar();
  }

  /** The level new elements go on: the plan's level, else the first level. */
  activeLevelId() {
    const v = this.activeView;
    if (v?.levelId) return v.levelId;
    return this.lastLevelId && this.doc.has(this.lastLevelId) ? this.lastLevelId : this.doc.levels()[0]?.id;
  }

  requirePlan() {
    const v = this.activeView;
    if (v && PLAN_KINDS.has(v.kind)) return true;
    const plan = this.doc.all('plan').find((p) => p.levelId === this.activeLevelId()) || this.doc.all('plan')[0];
    if (plan) {
      this.openView(plan.id);
      this.toast(`Switched to ${plan.name}: this tool works in floor plans.`);
      return true;
    }
    return false;
  }

  // Model sync for 3D ------------------------------------------------------------------------------

  syncModel() {
    // The active view's partial structure display decides which wall layers are built.
    const show = this.activeView?.structureDisplay || 'entire';
    if (this.modelVersion === this.scene.version && this.modelShow === show) return;
    const r3 = this.viewport.r3;
    const keep = new Set();
    for (const k of MODEL_KINDS)
      for (const el of this.doc.all(k)) {
        const m = this.scene.mesh(el, show);
        if (!m) continue;
        keep.add(el.id);
        r3.set(el.id, this.scene.indexOf(el.id), m);
      }
    r3.retain(keep);
    if (!this.originSet) {
      const b = r3.bounds();
      if (b) {
        // Keep vertex coordinates small near the model for float precision.
        r3.origin = [Math.round((b.min[0] + b.max[0]) / 2e4) * 1e4, Math.round((b.min[1] + b.max[1]) / 2e4) * 1e4, 0];
        for (const c of r3.chunks) c.dirty = true;
        this.originSet = true;
      }
    }
    this.modelVersion = this.scene.version;
    this.modelShow = show;
  }

  requestRender() {
    this.viewport?.requestRender();
  }

  // Selection and highlight ----------------------------------------------------------------------------

  select(ids, mode = 'replace') {
    const before = [...this.selection].join();
    if (mode === 'replace') this.selection = new Set(ids);
    else if (mode === 'add') ids.forEach((id) => this.selection.add(id));
    else if (mode === 'remove') ids.forEach((id) => this.selection.delete(id));
    if ([...this.selection].join() !== before) this.selectionChanged();
  }

  selectionChanged() {
    this.props.filter = null;
    this.flagsVersion++;
    this.props.render();
    this.updateContextual();
    this.updateSelInfo();
    this.ribbon.refresh();
    if (this.tool instanceof SelectTool || !this.tool) this.setPrompt(this.tool?.prompt || 'Ready');
    this.requestRender();
  }

  refreshSelection() {
    this.props.render();
    this.requestRender();
  }

  updateContextual() {
    this.quickLayers?.render();
    this.tracePalette?.render();
    this.seoPalette?.render();
    this.workspace?.update();
    if (this.tool && !(this.tool instanceof SelectTool)) {
      this.ribbon.setContextual({ id: `tool-${this.tool.constructor.name}`, label: `Modify | ${this.tool.title}`, panels: contextualPanels([]).slice(1, 2) });
      return;
    }
    const sel = [...this.selection].map((id) => this.doc.get(id)).filter(Boolean);
    const groupPanel = this.groupEdit ? [GROUP_EDIT_PANEL] : [];
    if (!sel.length) return this.ribbon.setContextual(this.groupEdit ? { id: 'ctx-groupedit', label: 'Modify | Edit Group', panels: groupPanel } : null);
    const kinds = [...new Set(sel.map((e) => e.kind))];
    const label = kinds.length === 1 ? pluralLabel(kinds[0]) : 'Multi-Select';
    this.ribbon.setContextual({ id: `ctx-${kinds.length === 1 ? kinds[0] : 'multi'}`, label: `Modify | ${label}`, panels: [...groupPanel, ...contextualPanels(kinds)] });
  }

  updateSelInfo() {
    const n = this.selection.size;
    const el = this.shell.selInfo;
    el.hidden = !n;
    el.replaceChildren(icon('filter', 13), h('span', `${n} selected`));
  }

  setHover(id) {
    if (this.hoverId === id) return;
    this.hoverId = id;
    this.flagsVersion++;
    const el = id ? this.doc.get(id) : null;
    if (el && (this.tool instanceof SelectTool || !this.tool)) this.setPrompt(this.describe(el));
    else if (!id && (this.tool instanceof SelectTool || !this.tool)) this.setPrompt(this.tool?.prompt || 'Ready');
    this.requestRender();
  }

  /** Flags for an element in a view (the active one by default): selection, hover, hidden, isolate. */
  flagsOf(id, view = this.activeView) {
    if (typeof id === 'string' && id.startsWith('t:')) return this.traces?.get(view?.id)?.split != null ? FLAG.dim | FLAG.split : FLAG.dim;
    if (typeof id === 'string' && id.startsWith('u:')) return FLAG.dim;
    let f = 0;
    if (this.selection.has(id)) f |= FLAG.selected;
    if (this.hoverId === id && !this.settings.noHoverHighlight) f |= FLAG.hover;
    const gid = this.doc?.get(id)?.groupId;
    if (gid) {
      if (this.selection.has(gid)) f |= FLAG.selected;
      if (this.hoverId === gid && !this.settings.noHoverHighlight) f |= FLAG.hover;
    }
    if (this.groupEdit && gid !== this.groupEdit.groupId && groupable(this.doc.get(id))) f |= FLAG.dim;
    const active = view?.id === this.activeViewId;
    if (view) {
      const el = this.doc.get(id);
      const reveal = this.reveal.has(view.id);
      if (el && this.hiddenInView(view, el)) f |= reveal ? FLAG.halftone : FLAG.hidden;
      else if (el && hasGraphics(this.doc, view) && viewGraphics(this.doc, view, el).halftone) f |= FLAG.halftone;
      if (el && this.phaseCount > 1 && phased(el)) {
        const look = phaseLook(this.doc, view, el);
        if (look === 'hidden') f |= reveal ? FLAG.halftone : FLAG.hidden;
        else if (look === 'halftone' || look === 'dashed') f |= FLAG.halftone;
      }
      // Trace & Reference > Transparent Fills and Zones: the active plan's fills and zones see-through.
      if (el && (el.kind === 'region' || el.kind === 'room') && this.traces?.get(view.id)?.transparentFills && this.traces.get(view.id).on) f |= FLAG.transparent;
      // Load Case palette: loads of a hidden case are hidden.
      if (el?.kind === 'structuralLoad' && this.settings.hiddenLoadCases?.includes(el.loadCase || 'dead')) f |= FLAG.hidden;
      // Construction Simulation: what is not built yet (or already demolished) at the simulation date is hidden.
      if (el && this.sim4d && view.kind === 'view3d' && this.sim4d.state(el) === 'hidden') f |= FLAG.hidden;
      const t = this.temp.get(view.id);
      if (t) {
        const inSet = t.ids.has(id) || (el?.hostId && t.ids.has(el.hostId));
        if ((t.mode === 'hide' && inSet) || (t.mode === 'isolate' && !inSet && !(el?.kind === 'level' || el?.kind === 'grid'))) f |= reveal ? FLAG.halftone : FLAG.hidden;
      }
      if (active && el && this.tool?.dimOthers && !this.tool.dimOthers.has(id)) f |= FLAG.dim;
    }
    return f;
  }

  hiddenInView(view, el) {
    if (view.hiddenIds?.includes(el.id)) return true;
    if (el.groupId && view.hiddenIds?.includes(el.groupId)) return true;
    const cat = categoryOf(el, this.doc);
    if (cat && view.hiddenCats?.includes(cat)) return true;
    if (hiddenByLayer(this.doc, view, el)) return true;
    if (hiddenByStoryFilter(this.doc, view, el)) return true;
    if (el.hostId) {
      const host = this.doc.get(el.hostId);
      if (host && (view.hiddenIds?.includes(host.id) || hiddenByLayer(this.doc, view, host))) return true;
    }
    return hiddenByFilters(this.doc, view, el);
  }

  /** Refresh the per-element state texture before drawing. */
  updateStateFlags(c = null) {
    const view = c?.view || this.activeView;
    const key = `${this.flagsVersion}|${view?.id}|${this.scene?.version}`;
    if (this.flagsKey === key) return;
    this.flagsKey = key;
    this.phaseCount = this.doc?.count('phase') ?? 0;
    const entries = [];
    const scene = this.scene;
    if (!scene) return;
    // 3D views show colour and transparency overrides on surfaces.
    const surfaces = view && !isPlanView(view) && view.kind !== 'drafting' && view.kind !== 'legend' && !!(view.overrides || view.filters?.length || view.elOverrides);
    const model3d = !!view && ['view3d', 'elevation', 'section'].includes(view.kind) && (!!view.layerComboId || this.doc.all('layer').some((l) => l.wireframe));
    for (let i = 0; i < scene.ids.length; i++) {
      const id = scene.ids[i];
      let f = this.flagsOf(id, view);
      let rgba = null;
      if (surfaces && !(f & FLAG.hidden)) {
        const el = this.doc.get(id);
        const g = el ? viewGraphics(this.doc, view, el, { surfaces: true }) : null;
        if (g?.color || g?.transparency) {
          const n = parseInt(String(g.color || '#ffffff').slice(1, 7), 16) || 0;
          rgba = [(n >> 16) & 255, (n >> 8) & 255, n & 255, Math.round(255 * (1 - Math.min(0.95, (+g.transparency || 0) / 100)))];
          if (g.color) f |= FLAG.color;
          if (g.transparency) f |= FLAG.transparent;
        }
      }
      // Wireframe layers: surfaces almost clear, so the model edges show the element.
      if (model3d && !(f & FLAG.hidden) && wireframeByLayer(this.doc, view, this.doc.get(id) || {})) {
        f |= FLAG.transparent;
        rgba = [rgba?.[0] ?? 255, rgba?.[1] ?? 255, rgba?.[2] ?? 255, 6];
      }
      // Construction Simulation: elements being built, demolished or put up for a while are coloured.
      if (this.sim4d && view?.kind === 'view3d' && !(f & FLAG.hidden)) {
        const el = this.doc.get(id);
        const c = el && SIM_COLORS[this.sim4d.state(el)];
        if (c) {
          f |= FLAG.color;
          rgba = [...c, 255];
        }
      }
      // Model Compare: new elements green, modified ones orange (3D surfaces).
      const cmp = this.compareHighlight;
      if (cmp && !(f & FLAG.hidden)) {
        const c = cmp.added.has(id) ? COMPARE_COLORS.added : cmp.modified.has(id) ? COMPARE_COLORS.modified : null;
        if (c) {
          f |= FLAG.color;
          rgba = [...c, 255];
        }
      }
      if (f) entries.push([i + 1, f, rgba]);
    }
    this.viewport.state.setAll(entries);
  }

  selectAllInView() {
    const c = this.vc;
    if (!c?.graphical) return;
    let ids = [];
    if (c.is2D) {
      c.sync();
      ids = [...c.layer.items.keys()].filter((id) => !(this.flagsOf(id) & FLAG.hidden));
    } else ids = [...this.viewport.r3.items.keys()].filter((id) => !(this.flagsOf(id) & FLAG.hidden));
    this.select(ids);
  }

  selectSimilar(scope = 'view') {
    const first = this.doc.get([...this.selection][0]);
    if (!first) return;
    const match = (el) => el.kind === first.kind && (first.typeId ? el.typeId === first.typeId : true);
    let ids = this.doc.filter(match).map((e) => e.id);
    if (scope === 'view' && this.vc?.is2D) {
      this.vc.sync();
      ids = ids.filter((id) => this.vc.layer.items.has(id));
    }
    this.select(ids);
    this.setPrompt(`${ids.length} selected.`);
  }

  selectInstancesOfType(typeId) {
    this.select(this.doc.filter((e) => e.typeId === typeId).map((e) => e.id));
  }

  // Groups ---------------------------------------------------------------------------------------

  /** What a click on elements selects: a member's group, unless that group is being edited. */
  /** Who this copy of the app is, for reservations. */
  userTag() {
    return this.user?.username || 'me';
  }

  pickTargets(ids) {
    const out = [];
    for (const id of ids) {
      const el = this.doc.get(id);
      let t = id;
      if (this.groupEdit) {
        // While a group is edited, only its members (and annotations) can be picked.
        if (groupable(el) && el.groupId !== this.groupEdit.groupId) continue;
      } else if (el?.groupId && this.doc.has(el.groupId) && !this.settings.suspendGroups) t = el.groupId;
      // Selection options in the status bar.
      const target = this.doc.get(t);
      if (target?.pinned && this.settings.selectPinned === false) continue;
      // Elements on locked layers are shown but cannot be picked.
      if (target && lockedByLayer(this.doc, this.activeView, target)) continue;
      // Reserved by someone else: shown but not editable.
      if (target?.reservedBy && target.reservedBy !== this.userTag()) continue;
      if (this.settings.selectLinks === false && target?.kind === 'link') continue;
      if (!out.includes(t)) out.push(t);
    }
    return out;
  }

  async createGroup() {
    const ids = [...this.selection];
    if (!ids.length) return this.toast('Select the elements to group first.', { kind: 'error' });
    const names = this.doc.all('groupType').map((t) => t.name);
    const name = await promptDialog('Create Model Group', 'Group name', uniqueName(names, `Group ${names.length + 1}`), { okLabel: 'Create', validate: (v) => (!v ? 'Enter a name.' : names.includes(v) ? 'A group with this name exists.' : null) });
    if (!name) return;
    let g = null;
    this.commit('Create group', () => (g = createGroup(this.doc, ids, { name, levelId: this.activeLevelId() })));
    if (!g) return this.toast('None of the selected elements can be grouped (views, levels, grids and annotations cannot).', { kind: 'error' });
    this.select([g.id]);
    this.setPrompt(`Created ${name}. Place more copies with Place Group, and edit them all at once with Edit Group.`);
  }

  startGroupEdit(groupId) {
    const g = this.doc.get(groupId || [...this.selection][0]);
    if (g?.kind !== 'group') return this.toast('Select a model group to edit.', { kind: 'error' });
    this.cancelTool(true);
    this.groupEdit = { groupId: g.id, undoDepth: this.doc.undoStack.length };
    this.doc.addDefaults = { fields: { groupId: g.id }, accept: (it) => groupable(it) && !it.groupId };
    this.select([]);
    this.flagsVersion++;
    this.updateContextual();
    this.renderBanner();
    this.requestRender();
    this.setPrompt('Editing the group: change its members, add or remove elements, then click Finish.');
  }

  finishGroupEdit(keep = true) {
    const ge = this.groupEdit;
    if (!ge) return;
    this.doc.addDefaults = null;
    this.groupEdit = null;
    this.cancelTool(true);
    if (!keep) {
      while (this.doc.undoStack.length > ge.undoDepth && this.doc.canUndo) this.doc.undo();
    } else if (this.doc.has(ge.groupId)) {
      let n = 0;
      this.commit('Finish group', () => (n = propagateGroup(this.doc, ge.groupId)));
      if (n) this.toast(`Updated ${n} other instance${n === 1 ? '' : 's'} of the group.`, { kind: 'success' });
    }
    this.select(this.doc.has(ge.groupId) ? [ge.groupId] : []);
    this.flagsVersion++;
    this.updateContextual();
    this.renderBanner();
    this.requestRender();
  }

  ungroupSelection() {
    const groups = [...this.selection].filter((id) => this.doc.get(id)?.kind === 'group');
    if (!groups.length) return this.toast('Select a model group.', { kind: 'error' });
    const members = groups.flatMap((g) => this.doc.filter((el) => el.groupId === g).map((el) => el.id));
    this.commit('Ungroup', () => groups.forEach((g) => ungroup(this.doc, g)));
    this.select(members);
  }

  viewName(v) {
    return v.kind === 'sheet' ? `${v.number || ''} - ${v.name}` : v.name;
  }

  describe(el) {
    return describeEl(this.doc, el);
  }

  formatArea(v) {
    return formatArea(v, this.doc.units);
  }

  nudge(d) {
    const ids = [...this.selection];
    this.commit('Nudge', () => moveElements(this.doc, ids, d));
  }

  // Tools ------------------------------------------------------------------------------------

  commandDef(name) {
    return COMMANDS[name];
  }

  /** Every command's name. */
  commandNames() {
    return Object.keys(COMMANDS);
  }

  run(name, args) {
    const d = COMMANDS[name];
    if (!d) return;
    if (d.enabled && !d.enabled(this)) {
      if (name === 'move' || name === 'copy' || name === 'rotate' || name === 'mirrorPick' || name === 'mirrorDraw' || name === 'array') this.toast('Select elements first.', { kind: 'error' });
      return;
    }
    closeMenus();
    hideTooltip();
    this.lastCommand = name;
    try {
      d.run(this, args);
    } catch (err) {
      console.error(err);
      this.toast(`Something went wrong: ${err.message}`, { kind: 'error' });
    }
    this.ribbon.refresh();
  }

  isCommandActive(cmd) {
    if (cmd === 'thinLines') return !!this.settings.thinLines;
    if (cmd === 'workPlaneGrid') return !!this.settings.workPlaneGrid;
    if (cmd === 'cropView') return !!this.activeView?.cropOn;
    if (cmd === 'cropShow') return !!this.activeView?.cropShow;
    if (cmd === 'roomFill') return !!this.activeView?.roomFill;
    if (cmd === 'revealHidden') return this.reveal.has(this.activeViewId);
    if (cmd === 'sectionBox') return !!this.activeView?.sectionBox;
    if (cmd === 'modify') return !this.tool || this.tool instanceof SelectTool;
    const toggle = COMMANDS[cmd]?.toggle;
    if (toggle) return !!toggle(this);
    if (this.tool && this.tool.commandName === cmd) return true;
    return null;
  }

  /** Can a plan tool work in this 3D view, on its editing plane (Archicad's 3D input)? */
  input3D(kinds, view) {
    return view?.kind === 'view3d' && this.settings.input3d !== false && kinds === PLAN_VIEW_KINDS;
  }

  startTool(Cls, opts = {}) {
    if (!this.doc) return;
    const probe = new Cls(this, opts);
    const kinds = probe.viewKinds;
    if (kinds && !kinds.includes(this.activeView?.kind) && !this.input3D(kinds, this.activeView)) {
      if (kinds.includes('plan')) {
        if (!this.requirePlan()) return;
      } else {
        const v = this.doc.filter((x) => kinds.includes(x.kind))[0];
        if (!v) return this.toast(`Open a ${kinds.join(' or ')} view to use ${probe.title}.`, { kind: 'error' });
        this.openView(v.id);
        this.toast(`Switched to ${v.name}.`);
      }
    }
    this.setTool(probe, this.lastCommand);
  }

  setTool(tool, commandName = null) {
    if (this.tool) {
      if (this.doc?.inTransaction) this.doc.rollback();
      this.tool.stop?.();
    }
    this.tool = tool;
    this.constraint = null;
    this.tracker?.hide();
    if (tool) tool.commandName = commandName;
    if (tool && !(tool instanceof SelectTool) && commandName) this.lastToolCommand = commandName;
    const ok = tool?.start?.();
    if (ok === false) return;
    this.shell.canvasWrap.style.cursor = tool && !(tool instanceof SelectTool) ? 'crosshair' : '';
    this.renderOptions();
    this.updateContextual();
    this.props.render();
    this.setPrompt(tool?.prompt || 'Ready');
    this.ribbon.refresh();
    this.requestRender();
    if (tool && !(tool instanceof SelectTool)) this.viewport.overlay.focus({ preventScroll: true });
  }

  cancelTool(silent = false) {
    if (!this.selectTool) this.selectTool = new SelectTool(this);
    if (this.tool === this.selectTool && silent) return;
    this.setTool(this.selectTool);
    this.selectTool.start();
    if (!silent) this.setPrompt('Ready');
  }

  toolNeedsTouch() {
    return this.tool && !(this.tool instanceof SelectTool);
  }

  toolEvent(type, ev) {
    if (!this.doc) return;
    if (!this.tool) this.cancelTool(true);
    const t = this.tool;
    if (ev) this.lastPointer = ev;
    if (type === 'move') this.updateCoords(ev);
    // Archicad's eyedropper (Alt + click) and syringe (Ctrl + Alt + click), in its workspace.
    if (type === 'down' && ev?.alt && this.workspace?.on && this.vc && this.pickOrInject(ev)) return;
    try {
      if (type === 'down') t.down(ev);
      else if (type === 'move') {
        t.move(ev);
        this.tracker?.update(ev);
      }
      else if (type === 'up') t.up?.(ev);
      else if (type === 'dblclick') t.dblclick?.(ev);
      else if (type === 'leave') {
        t.leave?.();
        this.tracker?.hide();
        if (t instanceof SelectTool) this.setHover(null);
      }
    } catch (err) {
      console.error(err);
    }
    if (type === 'down' || type === 'up') {
      this.ribbon.refresh();
      this.shell.undoBtn.disabled = !this.doc.canUndo;
    }
  }

  renderOptions() {
    const bar = this.shell.optionsbar;
    const had = bar.childElementCount > 0;
    clear(bar);
    const t = this.tool;
    if (t && !(t instanceof SelectTool)) {
      const opts = t.options?.();
      bar.append(h('span.ob-title', icon(KIND_ICON[t.placingKind] || 'modify', 13), t.title));
      if (t.placingKind) bar.append(this.favoritesButton(t.placingKind));
      if (t.placingKind === 'component' || t.placingKind === 'column') {
        const g = h('select.input.sm', { 'aria-label': 'Gravity', 'data-tip': 'Place on the slab, roof or mesh under the point' }, GRAVITY.map((x) => h('option', { value: x.value, selected: x.value === (this.settings.gravity || 'off') }, x.label)));
        g.addEventListener('change', () => this.settingsStore.set('gravity', g.value));
        g.addEventListener('keydown', (e) => e.stopPropagation());
        bar.append(h('div.ob-group', g));
      }
      if (opts) for (const o of [].concat(opts)) if (o) bar.append(o);
    }
    // In Archicad's workspace the options are laid out as its Info Box panels.
    this.workspace?.arrangeInfo?.(bar);
    // The bar showing or hiding moves the canvas: resize now, so the next click lands where it points.
    if (had !== bar.childElementCount > 0) this.viewport?.resize?.();
  }

  setPrompt(text) {
    if (this.shell) this.shell.prompt.textContent = text || '';
  }

  updateCoords(ev) {
    const c = this.vc;
    const el = this.shell.coords;
    if (!ev?.p || !c?.is2D) {
      if (!c?.is2D) el.textContent = '';
      return;
    }
    const u = this.doc.units;
    // Read from the user origin, when one is set.
    const o = draftingOf(this.doc.project).userOrigin;
    el.textContent = `X ${formatLength(ev.p[0] - o[0], u)}   Y ${formatLength(ev.p[1] - o[1], u)}`;
  }

  /** Remembered options per tool. */
  toolOptions(key, defaults) {
    if (!this.toolOpts.has(key)) this.toolOpts.set(key, { ...defaults });
    const o = this.toolOpts.get(key);
    for (const k in defaults) if (!(k in o)) o[k] = defaults[k];
    return o;
  }

  currentType(kind) {
    const id = this.currentTypes.get(kind);
    return defaultTypeFor(this.doc, kind, id);
  }

  setCurrentType(kind, typeId) {
    this.currentTypes.set(kind, typeId);
  }

  // Favorites (core/favorites.js) ------------------------------------------------------------------

  /** A Favorites menu button for an element kind. */
  favoritesButton(kind) {
    const fav = this.doc.get(this.armedFavorites.get(kind)) || this.pickedSettings.get(kind);
    return h('button.btn.sm.fav-btn', { type: 'button', 'aria-haspopup': 'menu', 'data-tip': 'Favorites: saved settings of this tool', onClick: (e) => this.favoritesMenu(e.currentTarget, kind) }, icon('selectionLoad', 14), fav ? fav.name : 'Favorites');
  }

  favoritesMenu(at, kind) {
    const doc = this.doc;
    const armed = this.armedFavorites.get(kind);
    const sel = [...this.selection].map((id) => doc.get(id)).filter((e) => e?.kind === kind);
    const list = favoritesFor(doc, kind);
    showMenu(
      at,
      [
        list.length ? { header: sel.length ? `Apply to the ${sel.length} selected` : 'Use for new elements' } : { header: 'No favorites yet' },
        ...list.map((f) => ({ label: f.name, radio: true, checked: !sel.length && f.id === armed, action: () => this.applyFavorite(f) })),
        { separator: true },
        { label: sel.length === 1 ? 'Save Selection as Favorite...' : 'Save Current Settings as Favorite...', icon: 'selectionSave', disabled: sel.length > 1 || (!sel.length && !this.tool?.placingKind), action: () => this.saveFavorite(sel[0] || null, kind) },
        armed || this.pickedSettings.has(kind) ? { label: 'Stop Using Favorite', action: () => this.armFavorite(kind, null) } : null,
        { label: 'Manage Favorites...', icon: 'types', disabled: !doc.count('favorite'), action: () => dialogs.favoritesDialog(this) },
      ].filter(Boolean),
      { label: 'Favorites' },
    );
  }

  armFavorite(kind, id) {
    if (id) this.armedFavorites.set(kind, id);
    else this.armedFavorites.delete(kind);
    this.pickedSettings.delete(kind);
    this.renderOptions();
    this.workspace?.update();
  }

  /** Apply a favorite to the selected elements of its kind, or arm it and start its tool. */
  applyFavorite(fav) {
    const doc = this.doc;
    const sel = [...this.selection].map((id) => doc.get(id)).filter((e) => e?.kind === fav.elementKind);
    if (sel.length) {
      this.commit(`Favorite: ${fav.name}`, () => sel.forEach((e) => doc.update(e.id, favoritePatch(doc, fav, e))));
      return this.toast(`Applied "${fav.name}" to ${sel.length} element${sel.length === 1 ? '' : 's'}.`);
    }
    if (fav.typeId && doc.has(fav.typeId)) this.setCurrentType(fav.elementKind, fav.typeId);
    this.armedFavorites.set(fav.elementKind, fav.id);
    this.pickedSettings.delete(fav.elementKind);
    if (this.tool?.placingKind === fav.elementKind) {
      this.renderOptions();
      this.props?.render();
    } else this.placeType(doc.get(fav.typeId) || this.currentType(fav.elementKind) || { id: null }, fav.elementKind);
  }

  /**
   * Eyedropper: the settings of the element clicked become its tool's
   * settings, and that tool starts. Syringe (with Ctrl): the element takes
   * its tool's settings (an armed favorite, picked settings, or the current
   * type). Returns whether an element was clicked.
   */
  pickOrInject(ev) {
    const doc = this.doc;
    const el = this.pickTargets(this.vc.hitTest(ev.x, ev.y)).map((id) => doc.get(id)).find((e) => e && (e.typeId || e.kind === 'room') && !isView(e));
    if (!el) return false;
    const kind = el.kind;
    if (ev.ctrl) {
      const fav = doc.get(this.armedFavorites.get(kind)) || this.pickedSettings.get(kind);
      const patch = fav ? favoritePatch(doc, fav, el) : this.currentType(kind) ? { typeId: this.currentType(kind).id } : null;
      if (!patch) return true;
      this.commit('Inject settings', () => doc.update(el.id, patch));
      this.toast(`Applied the ${KIND_LABEL[kind] || kind} settings${fav?.name && fav.id ? ` "${fav.name}"` : ''} to the element.`);
      return true;
    }
    this.pickedSettings.set(kind, favoriteFrom(doc, el, 'Picked up'));
    this.armedFavorites.delete(kind);
    if (el.typeId) this.setCurrentType(kind, el.typeId);
    if (this.tool?.placingKind === kind) {
      this.renderOptions();
      this.props?.render();
    } else this.placeType(doc.get(el.typeId) || { id: null }, kind);
    this.toast(`Picked up the settings of ${this.describe(el)}. Ctrl+Alt+click applies them to other elements.`);
    return true;
  }

  async saveFavorite(el, kind) {
    const doc = this.doc;
    const names = doc.all('favorite').map((f) => f.name);
    const base = el ? doc.get(el.typeId)?.name || KIND_LABEL[kind] || kind : this.currentType(kind)?.name || KIND_LABEL[kind] || kind;
    const name = await promptDialog('Save as Favorite', 'Favorite name', uniqueName(names, base), { okLabel: 'Save', validate: (v) => (!v ? 'Enter a name.' : names.includes(v) ? 'A favorite with this name exists.' : null) });
    if (!name) return;
    const fav = el ? favoriteFrom(doc, el, name) : { kind: 'favorite', name, elementKind: kind, typeId: this.currentType(kind)?.id ?? null, params: {} };
    let id;
    this.commit('Save favorite', () => (id = doc.add(fav).id));
    if (!el) this.armFavorite(kind, id);
    this.renderBrowser();
    this.toast(`Saved favorite "${name}".`, { kind: 'success' });
  }

  placeType(type, kind) {
    this.setCurrentType(kind, type.id);
    const cmd = { wall: 'wall', room: 'room', door: 'door', window: 'window', floor: 'floor', roof: 'roof', ceiling: 'ceiling', column: 'column', beam: 'beam', stair: 'stair', ramp: 'ramp', railing: 'railing', component: 'component', group: 'groupPlace', footing: 'footing', wallFooting: 'wallFooting', brace: 'brace', duct: 'duct', pipe: 'pipe', cableTray: 'cableTray', conduit: 'conduit', wallSweep: 'wallSweep', truss: 'truss' }[kind];
    if (cmd) this.run(cmd);
  }

  showTypeProperties(type, kind) {
    this.setCurrentType(kind, type.id);
  }

  // Elements -----------------------------------------------------------------------------------

  editElement(id, ev) {
    const el = this.doc.get(id);
    if (!el) return;
    if (el.kind === 'section' || el.kind === 'elevation' || isView(el)) return this.openView(el.id);
    if (el.kind === 'viewport' && this.doc.has(el.placedId)) return this.openView(el.placedId);
    if (el.kind === 'camera') return goToCamera(this, el);
    if (el.kind === 'viewRef' && this.doc.has(el.targetId)) return this.openView(el.targetId);
    if (el.kind === 'group') return this.startGroupEdit(el.id);
    if (el.kind === 'floor' || el.kind === 'roof' || el.kind === 'ceiling' || el.kind === 'railing') {
      this.select([id]);
      return this.editBoundary();
    }
    if (el.kind === 'text') return this.editText(el, ev);
    if (el.kind === 'level') {
      const plan = this.doc.all('plan').find((p) => p.levelId === el.id);
      if (plan) return this.openView(plan.id);
    }
    if (el.typeId) return this.editTypeDialog(this.doc.get(el.typeId));
  }

  editText(el, ev) {
    const t = this.tool instanceof SelectTool ? this.tool : null;
    if (!t) return;
    t.openInput(ev.x, ev.y, {
      label: 'Edit text',
      multiline: true,
      value: el.text,
      onSubmit: (v) => {
        if (v.trim()) this.commit('Edit text', () => this.doc.update(el.id, { text: v }));
        return true;
      },
    });
  }

  editBoundary() {
    const el = this.doc.get([...this.selection][0]);
    if (!el || !['floor', 'roof', 'ceiling', 'railing'].includes(el.kind)) return this.toast('Select a floor, roof, ceiling or railing.', { kind: 'error' });
    if (!this.requirePlan()) return;
    this.select([]);
    this.setTool(new SketchTool(this, { kind: el.kind, editId: el.id }), 'editBoundary');
    this.toast('Redraw the boundary, then click Finish. Tip: to adjust a few corners, select the element and drag its vertex grips instead.');
  }

  /** The accessory dialog: one choice of object (Archicad's accessory dialogs pick one object to place). */
  async chooseAccessory(title, options, hint) {
    const pick = h('select.input', { 'aria-label': 'Accessory' }, ...options.map((o, i) => h('option', { value: o.value, selected: i === 0 }, o.label)));
    const ok = await openDialogFn({
      title,
      size: 'sm',
      body: h('div', h('label.field', h('span.field-label', 'Accessory'), pick), hint ? h('p.field-hint', hint) : null),
      initialFocus: 'select',
      actions: [
        { label: 'Cancel', value: null },
        { label: 'Place', primary: true, value: true },
      ],
    });
    return ok ? pick.value : null;
  }

  /**
   * Wall Accessories, as Archicad's: on each selected wall (straight or curved), cladding
   * (on its outward face, found by itself), moldings and panelings (on its
   * inward face), a battered veneer, stud framing inside it, or a canted wall
   * (the wall slanted). Each follows its wall; its settings are in its properties.
   */
  async wallAccessories(type) {
    const doc = this.doc;
    const walls = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'wall');
    if (!walls.length) return this.toast('Select walls first.', { kind: 'error' });
    if (!type) type = await this.chooseAccessory('Wall Accessories', [...WALL_ACCESSORIES, { value: 'canted', label: 'Canted Wall' }], 'Cladding and veneers go on the outward face, moldings on the inward one; framing is drawn inside the wall; a canted wall leans the wall itself by 10°. Change any of them in their properties.');
    if (!type) return;
    if (type === 'canted') {
      this.commit('Canted Wall', () => walls.forEach((w) => doc.update(w.id, { slant: 'slanted', slantOuter: w.slantOuter || 10 })));
      return this.toast(`${walls.length} wall${walls.length === 1 ? '' : 's'} canted: change the angle in Slant.`, { kind: 'success' });
    }
    const DEFAULTS = {
      cladding: { pattern: 'horizontal', board: 150, gap: 10, thickness: 20, cavity: 30, materialId: 'mat-wood' },
      moldings: { baseHeight: 120, chairHeight: 900, crownHeight: 90, wainscot: true, panelWidth: 600, materialId: 'mat-paint-white' },
      battered: { thickBottom: 150, thickTop: 60, extendBelow: 0, extendAbove: 0, materialId: 'mat-stone' },
      framing: { spacing: 400, studWidth: 45, studDepth: 140, header: 200, materialId: 'mat-wood' },
    };
    const ids = [];
    this.commit('Wall Accessories', () => {
      for (const w of walls) {
        const out = outerSide(doc, w);
        const side = type === 'moldings' ? (out === 'exterior' ? 'interior' : 'exterior') : out;
        ids.push(doc.add({ kind: 'wallCladding', wallId: w.id, side, accessory: type, ...DEFAULTS[type] }).id);
      }
    });
    this.select(ids);
    let note = '';
    if (type === 'framing') {
      const list = ids.map((id) => framingGeometry(doc, doc.get(id))).filter(Boolean).flatMap((g) => framingList(g));
      const pieces = list.reduce((s, r) => s + r.count, 0);
      const metres = list.reduce((s, r) => s + r.length, 0) / 1000;
      note = `: ${pieces} pieces, ${metres.toFixed(1)} m of lumber`;
    }
    const name = WALL_ACCESSORIES.find((o) => o.value === type)?.label || 'Accessory';
    this.toast(`${name} added to ${ids.length} wall${ids.length === 1 ? '' : 's'}${note}.`, { kind: 'success' });
    return ids;
  }

  /** Slab Accessories, as Archicad's: floor construction (joists under it) or a footing under its edge. */
  async slabAccessories(type) {
    const doc = this.doc;
    const slabs = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'floor');
    if (!slabs.length) return this.toast('Select slabs first.', { kind: 'error' });
    if (!type) type = await this.chooseAccessory('Slab Accessories', SLAB_ACCESSORIES, 'Floor Construction puts joists under the slab across its shorter span with a rim joist round it; Footing puts a stem wall on a concrete footing under its edge, with a sill plate.');
    if (!type) return;
    const ids = [];
    this.commit('Slab Accessories', () => {
      for (const s of slabs) ids.push(doc.add({ kind: 'slabAccessory', slabId: s.id, accessory: type, materialId: type === 'footing' ? 'mat-concrete' : 'mat-wood' }).id);
    });
    this.select(ids);
    this.toast(`${SLAB_ACCESSORIES.find((o) => o.value === type)?.label} added to ${ids.length} slab${ids.length === 1 ? '' : 's'}.`, { kind: 'success' });
    return ids;
  }

  /** Roof Accessories, as Archicad's: the Roof Surfacer (tiles or metal sheets) or a wood ceiling under it. */
  async roofAccessories(type) {
    const doc = this.doc;
    const roofs = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'roof');
    if (!roofs.length) return this.toast('Select roofs first.', { kind: 'error' });
    const options = [{ value: 'tiles', label: 'Roof Surfacer: tiles' }, { value: 'metal', label: 'Roof Surfacer: metal sheets' }, { value: 'woodCeiling', label: 'Wood Ceiling' }];
    if (!type) type = await this.chooseAccessory('Roof Accessories', options, 'The Roof Surfacer sheathes the roof tile by tile, with caps on its ridges and hips, or with standing-seam sheets; the Wood Ceiling lines its underside with boards. Fascia and gutters are in the roof\'s own properties.');
    if (!type) return;
    const ids = [];
    this.commit('Roof Accessories', () => {
      for (const r of roofs) {
        const el = type === 'woodCeiling' ? { accessory: 'woodCeiling', materialId: 'mat-wood' } : { accessory: 'surfacer', sheathing: type, materialId: type === 'metal' ? 'mat-roof-metal' : null };
        ids.push(doc.add({ kind: 'roofAccessory', roofId: r.id, ...el }).id);
      }
    });
    this.select(ids);
    this.toast(`${options.find((o) => o.value === type)?.label} added to ${ids.length} roof${ids.length === 1 ? '' : 's'}.`, { kind: 'success' });
    return ids;
  }

  /**
   * Create Room Accessories, as Archicad's Interior Wizard: a skirting round each
   * selected room (all rooms of the level when none is selected), broken at its
   * doors. It follows the room; Update Room Accessories remakes any that were
   * removed and drops those whose room is gone.
   */
  createRoomAccessories() {
    const doc = this.doc;
    let rooms = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'room');
    if (!rooms.length) rooms = doc.all('room').filter((r) => !this.activeView?.levelId || r.levelId === this.activeView.levelId);
    if (!rooms.length) return this.toast('Place rooms first.', { kind: 'error' });
    const have = new Set(doc.all('roomAccessory').map((a) => a.roomId));
    const ids = [];
    this.commit('Create Room Accessories', () => {
      for (const r of rooms) if (!have.has(r.id)) ids.push(doc.add({ kind: 'roomAccessory', roomId: r.id, skirtingHeight: 100, skirtingDepth: 15, cornice: false, materialId: 'mat-paint-white' }).id);
    });
    this.toast(ids.length ? `Skirting added to ${ids.length} room${ids.length === 1 ? '' : 's'}.` : 'Those rooms already have their accessories.', { kind: ids.length ? 'success' : 'info' });
    return ids;
  }

  /** Update Room Accessories: drop the accessories of rooms that are gone and rebuild the rest from their rooms now. */
  updateRoomAccessories() {
    const doc = this.doc;
    const gone = doc.all('roomAccessory').filter((a) => doc.get(a.roomId)?.kind !== 'room');
    if (gone.length) this.commit('Update Room Accessories', () => gone.forEach((a) => doc.remove(a.id)));
    this.scene?.rooms?.invalidate?.();
    this.scene?.invalidate?.();
    this.requestRender?.();
    const n = doc.all('roomAccessory').length;
    this.toast(`${n} room accessor${n === 1 ? 'y' : 'ies'} updated${gone.length ? `, ${gone.length} removed with their rooms` : ''}.`, { kind: 'success' });
    return { updated: n, removed: gone.length };
  }

  /** Modify Segmentation (Design > Modify Morph): how many pieces each curved edge of the selected morphs has. */
  async modifySegmentation(segments) {
    const doc = this.doc;
    const morphs = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'morph' && el.curved);
    if (!morphs.length) return this.toast('Select curved morphs (Curve & Merge Edges) first.', { kind: 'error' });
    if (segments == null) {
      const text = await promptDialog('Modify Segmentation', 'Pieces per curved edge (1 to 64)', String(morphs[0].segments || 8), { okLabel: 'Apply', validate: (v) => (Number.isInteger(+v) && +v >= 1 && +v <= 64 ? null : 'Enter a whole number from 1 to 64.') });
      if (text == null) return;
      segments = +text;
    }
    this.commit('Modify Segmentation', () => morphs.forEach((m) => doc.update(m.id, curveMorphEdges(m, segments))));
    this.toast(`${morphs.length} morph${morphs.length === 1 ? '' : 's'}: ${segments} piece${segments === 1 ? '' : 's'} per curved edge.`, { kind: 'success' });
  }

  /** Intersect Morph Faces: where the selected morphs' faces cut through each other, they split and the cut becomes an edge. */
  intersectMorphFaces() {
    const doc = this.doc;
    const morphs = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'morph');
    if (!morphs.length) return this.toast('Select morphs first.', { kind: 'error' });
    const parts = morphs.map((m) => (Array.isArray(m.tris) ? { tris: m.tris, cols: m.cols || [] } : freezeMeshes([this.scene.mesh(m)].filter(Boolean))));
    let r;
    try {
      r = intersectFaces(parts);
    } catch (err) {
      return this.toast(err.message, { kind: 'error' });
    }
    if (!r.cuts) return this.toast('The selected morphs\' faces do not cut through each other.', { kind: 'info' });
    this.commit('Intersect Morph Faces', () => {
      morphs.forEach((m, i) => {
        const b = r.bodies[i];
        // Its edges before the cut (feature edges of its body) and the new lines of intersection.
        const before = Array.from(this.scene.mesh(m)?.edges || []);
        doc.update(m.id, { tris: b.tris.map((v) => Math.round(v * 10) / 10), cols: b.cols, lines: [...before, ...b.lines], ownEdges: true, boundary: null, holes: null, heights: null, curved: false });
      });
    });
    this.toast(`${r.cuts} face crossing${r.cuts === 1 ? '' : 's'} cut into edges.`, { kind: 'success' });
    return r.cuts;
  }

  /** Merge Elements: the selected morphs become one body; faces they share go. */
  mergeMorphs() {
    const doc = this.doc;
    const morphs = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'morph');
    if (morphs.length < 2) return this.toast('Select two or more morphs.', { kind: 'error' });
    const parts = morphs.map((m) => (Array.isArray(m.tris) ? { tris: m.tris, cols: m.cols || [] } : freezeMeshes([this.scene.mesh(m)].filter(Boolean))));
    const r = mergeBodies(parts);
    this.commit('Merge Elements', () => {
      doc.update(morphs[0].id, { tris: r.tris, cols: r.cols, boundary: null, holes: null, heights: null, curved: false, ownEdges: false, lines: null });
      deleteElements(doc, morphs.slice(1).map((m) => m.id));
    });
    this.select([morphs[0].id]);
    this.toast(`Merged ${morphs.length} morphs${r.removed ? `; ${r.removed} shared faces removed` : ''}.`, { kind: 'success' });
    return r;
  }

  /** Curve & Merge Edges (Design > Modify Morph): the selected prism morphs' straight edges become one smooth curve. */
  curveMorphEdges() {
    const doc = this.doc;
    const morphs = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'morph');
    if (!morphs.length) return this.toast('Select morphs first.', { kind: 'error' });
    let curved = 0;
    let merged = 0;
    this.commit('Curve & Merge Edges', () => {
      for (const m of morphs) {
        if (Array.isArray(m.tris)) {
          // A body of faces: its segmented curved edges merge (faces under 45° join).
          doc.update(m.id, { smoothAngle: Math.max(45, +m.smoothAngle || 0) });
          merged++;
        } else if (m.curved) merged++;
        else {
          const patch = curveMorphEdges(m);
          if (patch) {
            doc.update(m.id, patch);
            curved++;
          }
        }
      }
    });
    this.toast([curved && `${curved} morph${curved === 1 ? '' : 's'} curved`, merged && `${merged} with edges merged`].filter(Boolean).join(', ') + '.', { kind: 'success' });
    return { curved, merged };
  }

  /**
   * Corner Window, as Archicad's: on two selected walls that meet at a corner,
   * a window on each running to the corner, the walls open through it and
   * the two windows' glass meeting there without a post.
   */
  cornerWindow() {
    const doc = this.doc;
    const walls = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'wall');
    if (walls.length !== 2) return this.toast('Select the two walls that meet at the corner.', { kind: 'error' });
    const [w1, w2] = walls;
    // The ends that meet (within 50 mm).
    let pair = null;
    for (const e1 of ['a', 'b']) for (const e2 of ['a', 'b']) if (!pair && Math.hypot(w1[e1][0] - w2[e2][0], w1[e1][1] - w2[e2][1]) < 50) pair = [e1, e2];
    if (!pair) return this.toast('The selected walls do not meet at a corner.', { kind: 'error' });
    const type = this.currentType('window');
    if (!type) return this.toast('There is no window type to use.', { kind: 'error' });
    const W = +type.width || 1200;
    const ids = [];
    this.commit('Corner Window', () => {
      [w1, w2].forEach((w, i) => {
        const L = Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]);
        const width = Math.min(W, L - 100);
        const corner = pair[i];
        ids.push(doc.add({ kind: 'window', typeId: type.id, hostId: w.id, t: corner === 'b' ? L - width / 2 : width / 2, width, corner }).id);
      });
      doc.update(ids[0], { cornerWith: ids[1] });
      doc.update(ids[1], { cornerWith: ids[0] });
    });
    this.select(ids);
    this.toast('Corner window placed.', { kind: 'success' });
  }

  /**
   * Trim (or untrim) the selected elements to a roof or shell, as Archicad's
   * Trim Elements to Roof/Shell: the selected roofs and shells trim the other
   * selected elements (or, with none selected, the roof above each does).
   * Walls and columns under a roof follow its underside (and reach it); other
   * bodies lose their part above it (mode 'above'), below it ('below'), or
   * above the endless plane of a single-plane roof ('plane', Crop to
   * Single-plane Roof). See rooftrim.js.
   */
  attachTop(attach, mode = 'above') {
    const doc = this.doc;
    const sel = [...this.selection].map((id) => doc.get(id)).filter(Boolean);
    const trimmers = sel.filter((el) => isTrimmer(el) && (mode !== 'plane' || el.kind === 'roof'));
    const els = sel.filter((el) => TRIMMABLE_KINDS.has(el.kind) && !trimmers.includes(el));
    if (!els.length) return this.toast('Select the elements to trim (with the roofs or shells to trim them to).', { kind: 'error' });
    let n = 0;
    this.commit(attach ? 'Trim to roof' : 'Undo trim to roof', () => {
      for (const el of els) {
        if (!attach) {
          if (el.attachTopId) {
            doc.update(el.id, { attachTopId: null, attachTopMode: null });
            n++;
          }
          continue;
        }
        const t = trimmerFor(doc, el, trimmers);
        if (!t || (mode === 'plane' && t.kind !== 'roof')) continue;
        doc.update(el.id, { attachTopId: t.id, attachTopMode: mode === 'above' ? null : mode });
        n++;
      }
    });
    if (attach) this.toast(n ? `Trimmed ${n} element${n === 1 ? '' : 's'} to the roof.` : 'No roof or shell was found for the selected elements.', { kind: n ? 'success' : 'error' });
    return n;
  }

  /**
   * RoofMaker: timber framing under the selected roofs (rafters, ridge, hips,
   * wall plates and purlins), remade when run again.
   */
  /**
   * Crop Zone: the selected zones are cut off under the roofs selected with
   * them (or, with none, the roofs over them), so their volume is the space
   * under the roof. Undo All Crops clears it.
   */
  cropZones() {
    const doc = this.doc;
    const sel = [...this.selection].map((id) => doc.get(id)).filter(Boolean);
    const rooms = sel.filter((el) => el.kind === 'room');
    if (!rooms.length) return this.toast('Select zones (and the roofs or slabs to crop them with).', { kind: 'error' });
    const chosen = sel.filter((el) => el.kind === 'roof' || el.kind === 'floor' || el.kind === 'ceiling').map((el) => el.id);
    let n = 0;
    this.commit('Crop Zone', () => {
      for (const r of rooms) {
        const by = chosen.length ? chosen : croppersOver(doc, r, this.scene.rooms.room(r));
        if (!by.length) continue;
        doc.update(r.id, { cropBy: by, upperOffset: +r.upperOffset > 0 ? r.upperOffset : 3000 });
        n++;
      }
    });
    this.toast(n ? `${n} zone${n === 1 ? '' : 's'} cropped.` : 'No roof over the selected zones: select the roofs with them.', { kind: n ? 'success' : 'error' });
    return n;
  }

  /** Undo All Crops: the zones' volumes go back to their full height. */
  uncropZones() {
    const doc = this.doc;
    let rooms = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'room');
    if (!rooms.length) rooms = doc.all('room');
    rooms = rooms.filter((r) => r.cropBy?.length);
    if (rooms.length) this.commit('Undo All Crops', () => rooms.forEach((r) => doc.update(r.id, { cropBy: null })));
    this.toast(rooms.length ? `${rooms.length} zone${rooms.length === 1 ? '' : 's'} back to full height.` : 'No cropped zones.', { kind: 'info' });
    return rooms.length;
  }

  /**
   * Update Zones: every zone measured again from the walls round it now (manual
   * zones keep their outline); reports the zones whose area changed since the
   * last update and those no longer enclosed.
   */
  updateZones() {
    const doc = this.doc;
    this.scene.rooms.invalidate();
    const changed = [];
    const open = [];
    this.commit('Update Zones', () => {
      for (const r of doc.all('room')) {
        const reg = this.scene.rooms.room(r);
        if (!reg?.outer) {
          open.push(r.name || r.number || r.id);
          continue;
        }
        const area = Math.round(reg.area / 1e4) / 100;
        if (r.updatedArea != null && Math.abs(r.updatedArea - area) > 0.005) changed.push(`${r.name || r.number || 'Zone'} ${r.updatedArea} → ${area} m²`);
        if (r.updatedArea !== area) doc.update(r.id, { updatedArea: area });
      }
    });
    this.requestRender();
    const n = doc.all('room').length;
    this.toast([`${n} zone${n === 1 ? '' : 's'} updated.`, changed.length && `Changed: ${changed.join(', ')}.`, open.length && `Not enclosed: ${open.join(', ')}.`].filter(Boolean).join(' '), { kind: open.length ? 'error' : 'success' });
    return { updated: n, changed, open };
  }

  /** Flip Railing on Reference Line: the selected railings mirrored over their path (it runs the other way). */
  flipRailings() {
    const doc = this.doc;
    const rails = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'railing' && Array.isArray(el.path));
    if (!rails.length) return this.toast('Select railings first.', { kind: 'error' });
    this.commit('Flip Railing', () => rails.forEach((r) => doc.update(r.id, { path: r.path.slice().reverse(), ...(Array.isArray(r.heights) ? { heights: r.heights.slice().reverse() } : {}), flipped: !r.flipped })));
    this.toast(`${rails.length} railing${rails.length === 1 ? '' : 's'} flipped.`, { kind: 'success' });
  }

  /**
   * Roof Wizard: a roof of a chosen type over the selected walls (round their
   * outer faces, the walls trimmed to it so gables close) or a selected slab.
   */
  async roofWizard(opts) {
    const doc = this.doc;
    const sel = [...this.selection].map((id) => doc.get(id)).filter(Boolean);
    const walls = sel.filter((el) => el.kind === 'wall' && !el.arc);
    const slab = sel.find((el) => el.kind === 'floor');
    const outline = walls.length >= 3 ? wallLoop(doc, walls) : slab?.boundary;
    if (!outline) return this.toast('Select the walls round the building (a closed loop) or a slab.', { kind: 'error' });
    if (!opts) {
      const type = h('select.input', { 'aria-label': 'Roof type' }, ...ROOF_TYPES.map((t) => h('option', { value: t.value }, t.label)));
      const slope = h('input.input', { type: 'number', value: 30, min: 5, max: 75, 'aria-label': 'Slope' });
      const over = h('input.input', { type: 'number', value: 500, min: 0, max: 3000, 'aria-label': 'Overhang' });
      const ok = await openDialogFn({
        title: 'Roof Wizard',
        size: 'sm',
        body: h('div', h('label.field', h('span.field-label', 'Roof type'), type), h('label.field', h('span.field-label', 'Slope (degrees)'), slope), h('label.field', h('span.field-label', 'Overhang (mm)'), over), h('p.field-hint', 'Mansard and gambrel roofs break to a 20° upper slope 1.8 m up, from a 65° lower one.')),
        initialFocus: 'select',
        actions: [
          { label: 'Cancel', value: null },
          { label: 'Create Roof', primary: true, value: true },
        ],
      });
      if (!ok) return;
      opts = { type: type.value, slope: +slope.value || 30, overhang: +over.value || 0 };
    }
    const shape = wizardRoof(outline, opts);
    const base = walls.length ? roofBase(doc, walls) : { levelId: slab.levelId, baseOffset: +slab.offset || 0 };
    let id;
    this.commit('Roof Wizard', () => {
      id = doc.add({ kind: 'roof', typeId: this.currentType('roof')?.id ?? doc.all('roofType')[0]?.id, ...base, ...shape }).id;
      for (const w of walls) doc.update(w.id, { attachTopId: id });
    });
    this.select([id]);
    this.toast(`${ROOF_TYPES.find((t) => t.value === opts.type)?.label || 'Roof'} roof created${walls.length ? `, ${walls.length} walls trimmed to it` : ''}.`, { kind: 'success' });
    return id;
  }

  /** Create Structural Supports: under the columns and walls of the lowest level. */
  /** Structural Analytical Model display on the 3D view (opens the default 3D view when another is active). */
  toggleAnalytical() {
    let v = this.activeView;
    if (v?.kind !== 'view3d') {
      this.open3D();
      v = this.activeView;
    }
    if (v?.kind !== 'view3d') return;
    const on = !v.analytical;
    this.commit(on ? 'Show analytical model' : 'Hide analytical model', () => this.doc.update(v.id, { analytical: on }));
    if (on) {
      const am = analyticalModel(this.doc);
      this.toast(`Analytical model: ${am.members.length} members, ${am.surfaces.length} surfaces, ${am.nodes.length} nodes, ${am.supports.length + am.edgeSupports.length} supports.${am.notes.length ? ` ${am.notes[0]}` : ''}`);
    }
    this.requestRender();
  }

  /** Export SAF: the analytical model as an Excel workbook for structural analysis programs. */
  exportSAF() {
    const am = analyticalModel(this.doc);
    if (!am.members.length && !am.surfaces.length) return this.toast('There are no load-bearing elements to export.', { kind: 'error' });
    const name = this.doc.project?.name || this.file?.name || 'Project';
    // The SAF translator decides what goes out (members, surfaces, supports, loads, combinations).
    const bytes = writeXLSX(safSheets(filterSAFModel(am, safTranslator(this.doc)), { projectName: name, imperial: structuralUnits(this.doc.get('project')).system === 'imperial', cases: safCases(this.doc.get('project')) }));
    download(new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), `${safeFileName(String(name).replace(/\.[^.]+$/, ''))} SAF.xlsx`);
    this.toast(`Exported ${am.members.length} members, ${am.surfaces.length} surfaces and ${am.nodes.length} nodes.${am.notes.length ? ` ${am.notes.join(' ')}` : ''}`, { kind: 'success' });
  }

  createStructuralSupports() {
    const doc = this.doc;
    const add = supportsFor(doc);
    if (!add.length) return this.toast('Every column and wall of the lowest level has its support.', { kind: 'info' });
    this.commit('Create Structural Supports', () => add.forEach((s) => doc.add(s)));
    this.toast(`${add.length} support${add.length === 1 ? '' : 's'} created.`, { kind: 'success' });
    return add.length;
  }

  /** Create/Update Loads: the slabs' and roofs' self-weight and imposed or snow loads, made again from them now. */
  updateStructuralLoads(opts) {
    const doc = this.doc;
    const add = loadsFor(doc, opts);
    this.commit('Create/Update Loads', () => {
      for (const l of doc.all('structuralLoad')) if (l.auto) doc.remove(l.id);
      add.forEach((l) => doc.add(l));
    });
    const sum = loadSummary(doc);
    const text = Object.entries(sum).map(([k, v]) => `${LOAD_CASES.find((c) => c.value === k)?.label || k} ${v.toFixed(1)} kN`).join(', ');
    this.toast(`${add.length} loads. Totals: ${text || 'none'}.`, { kind: 'success' });
    return sum;
  }

  /** A structural load on the selection: a point load on columns, a line load on walls and beams, a surface load on slabs. */
  addStructuralLoad(type, value, loadCase = this.settings.activeLoadCase || 'live') {
    const doc = this.doc;
    const sel = [...this.selection].map((id) => doc.get(id)).filter(Boolean);
    const ids = [];
    this.commit('Structural Load', () => {
      for (const el of sel) {
        let load = null;
        if (type === 'point' && el.kind === 'column') {
          const top = (el.topLevelId ? levelElevation(doc, el.topLevelId) + (+el.topOffset || 0) : levelElevation(doc, el.levelId) + (+el.baseOffset || 0) + (+el.height || 3000)) - levelElevation(doc, el.levelId);
          load = { at: [el.at[0], el.at[1]], offset: top };
        } else if (type === 'line' && (el.kind === 'wall' || el.kind === 'beam') && !el.arc) {
          const top = el.kind === 'wall' ? verticalExtent(doc, el).top - levelElevation(doc, el.levelId) : +el.offset || 0;
          load = { a: [el.a[0], el.a[1]], b: [el.b[0], el.b[1]], offset: top };
        } else if (type === 'surface' && (el.kind === 'floor' || el.kind === 'roof') && el.boundary?.length >= 3) load = { boundary: el.boundary.map((p) => [p[0], p[1]]), offset: el.kind === 'floor' ? +el.offset || 0 : +el.baseOffset || 0 };
        if (load) ids.push(doc.add({ kind: 'structuralLoad', levelId: el.levelId, type, value: value ?? { point: 10, line: 5, surface: 2 }[type], loadCase, hostId: el.id, ...load }).id);
      }
    });
    if (!ids.length) return this.toast({ point: 'Select columns.', line: 'Select walls or beams.', surface: 'Select slabs or roofs.' }[type], { kind: 'error' });
    this.select(ids);
    this.toast(`${ids.length} ${type} load${ids.length === 1 ? '' : 's'}; set the value and case in their properties.`, { kind: 'success' });
    return ids;
  }

  /** RoofMaker's Create collar beams / Create tie beams: turn them on in the selected roofs' framing and remake it. */
  roofFramingWith(what) {
    const doc = this.doc;
    const roofs = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'roof');
    if (!roofs.length) return this.toast('Select a roof first.', { kind: 'error' });
    let n = 0;
    this.commit(what === 'collars' ? 'Collar beams' : 'Tie beams', () => {
      for (const r of roofs) {
        doc.update(r.id, { framing: { ...(r.framing || {}), [what]: true } });
        n += makeRoofFraming(doc, doc.get(r.id)).filter((id) => doc.get(id)?.framingRole === (what === 'collars' ? 'collar' : 'tie')).length;
      }
    });
    this.toast(n ? `${n} ${what === 'collars' ? 'collar' : 'tie'} beam${n === 1 ? '' : 's'}, with the rest of the roof's framing.` : 'No opposite roof planes to tie.', { kind: n ? 'success' : 'error' });
    return n;
  }

  roofFraming() {
    const doc = this.doc;
    const roofs = [...this.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'roof');
    if (!roofs.length) return this.toast('Select a roof first.', { kind: 'error' });
    let n = 0;
    this.commit('Roof framing', () => {
      for (const r of roofs) n += makeRoofFraming(doc, r).length;
    });
    this.toast(n ? `${n} timber members under ${roofs.length === 1 ? 'the roof' : `${roofs.length} roofs`}.` : 'The roof has no sloping planes to frame.', { kind: n ? 'success' : 'error' });
    return n;
  }

  flipSelection() {
    this.commit('Flip', () => {
      for (const id of this.selection) {
        const el = this.doc.get(id);
        if (el?.kind === 'wall') this.doc.update(id, { flipped: !el.flipped });
        else if (el?.kind === 'door' || el?.kind === 'window') this.doc.update(id, { flipFacing: !el.flipFacing });
        else if (el?.kind === 'section') this.doc.update(id, { flip: !el.flip });
      }
    });
  }

  renameItem(id) {
    const it = this.doc.get(id);
    if (!it) return;
    promptDialog('Rename', 'Name', it.name || '', { validate: (v) => (!v ? 'Enter a name.' : null) }).then((name) => {
      if (name && name !== it.name) this.commit('Rename', () => this.doc.update(id, { name }));
    });
  }

  async deleteItem(id) {
    const it = this.doc.get(id);
    if (!it) return;
    if (it.kind.endsWith('Type')) {
      const used = this.doc.filter((e) => e.typeId === id).length;
      if (this.doc.all(it.kind).length <= 1) return this.toast('A category needs at least one type.', { kind: 'error' });
      if (used) {
        const ok = await confirmDialog('Delete type', `${used} element${used === 1 ? ' uses' : 's use'} this type and will also be deleted.`, { confirm: 'Delete', danger: true });
        if (!ok) return;
      }
      this.commit('Delete type', () => deleteElements(this.doc, [id, ...this.doc.filter((e) => e.typeId === id).map((e) => e.id)]));
      return;
    }
    if (isView(it)) {
      const ok = await confirmDialog('Delete view', `Delete "${it.name}"? Annotations drawn in it are deleted too.`, { confirm: 'Delete', danger: true });
      if (!ok) return;
    }
    this.commit('Delete', () => deleteElements(this.doc, [id]));
  }

  duplicateType(t) {
    const names = this.doc.all(t.kind).map((x) => x.name);
    const { id: _id, ...rest } = t;
    void _id;
    let copy;
    this.commit('Duplicate type', () => (copy = this.doc.add({ ...rest, name: uniqueName(names, `${t.name} 2`) })));
    if (copy) this.editTypeDialog(copy);
  }

  levelCommand() {
    const v = this.activeView;
    if (v && (v.kind === 'elevation' || v.kind === 'section')) return this.run('levelInElevation');
    dialogs.addLevelDialog(this).then((r) => {
      if (r) createLevel(this, r.elevation, r.name);
    });
  }

  toggleViewProp(key) {
    const v = this.activeView;
    if (!v) return;
    this.commit('View', () => this.doc.update(v.id, { [key]: !v[key] }));
  }

  hideInView(what) {
    const v = this.activeView;
    if (!v || !this.selection.size) return;
    const sel = [...this.selection].map((id) => this.doc.get(id)).filter(Boolean);
    if (what === 'category') {
      const cats = new Set([...(v.hiddenCats || []), ...sel.map((e) => categoryOf(e, this.doc)).filter(Boolean)]);
      this.commit('Hide category', () => this.doc.update(v.id, { hiddenCats: [...cats] }));
    } else {
      const ids = new Set([...(v.hiddenIds || []), ...sel.map((e) => e.id)]);
      this.commit('Hide in view', () => this.doc.update(v.id, { hiddenIds: [...ids] }));
    }
    this.select([]);
    this.setPrompt('Hidden in this view. Use Reveal Hidden Elements to show and unhide them.');
  }

  unhideSelected() {
    const v = this.activeView;
    if (!v) return;
    const sel = new Set(this.selection);
    const cats = new Set([...this.selection].map((id) => categoryOf(this.doc.get(id), this.doc)));
    this.commit('Unhide', () => this.doc.update(v.id, { hiddenIds: (v.hiddenIds || []).filter((id) => !sel.has(id)), hiddenCats: (v.hiddenCats || []).filter((c) => !cats.has(c)) }));
  }

  temporary(mode) {
    const id = this.activeViewId;
    if (mode === 'reset') this.temp.delete(id);
    else {
      if (!this.selection.size) return;
      this.temp.set(id, { mode, ids: new Set(this.selection) });
      this.select([]);
    }
    this.flagsVersion++;
    this.renderViewbar();
    this.requestRender();
  }

  toggleReveal() {
    const id = this.activeViewId;
    if (this.reveal.has(id)) this.reveal.delete(id);
    else this.reveal.add(id);
    this.flagsVersion++;
    this.renderViewbar();
    this.ribbon.refresh();
    this.requestRender();
  }

  toggleSectionBox() {
    const v = this.activeView;
    if (v?.kind !== 'view3d') return this.toast('Open a 3D view to use the section box.', { kind: 'error' });
    if (v.sectionBox) this.commit('Section box', () => this.doc.update(v.id, { sectionBox: null }));
    else {
      this.syncModel();
      const ids = this.selection.size ? this.selection : null;
      const b = this.viewport.r3.bounds(ids);
      if (!b) return;
      const pad = 300;
      this.commit('Section box', () => this.doc.update(v.id, { sectionBox: { min: b.min.map((x) => x - pad), max: b.max.map((x) => x + pad) } }));
    }
    this.renderViewbar();
  }

  /** Switch between the ribbon workspace and the Archicad-style one (ui/workspace.js). */
  toggleWorkspace() {
    this.settingsStore.set('workspaceAc', !this.settings.workspaceAc);
    this.workspace.apply(!!this.settings.workspaceAc);
    this.ribbon.refresh();
  }

  toggleSetting(key) {
    this.settingsStore.set(key, !this.settings[key]);
    this.ribbon.refresh();
    this.renderViewbar();
    this.requestRender();
  }

  toggleSnaps() {
    const s = { ...this.settings.snaps, enabled: this.settings.snaps.enabled === false };
    this.settingsStore.set('snaps', s);
    this.shell.snapBtn.setAttribute('aria-pressed', String(s.enabled !== false));
    this.setPrompt(s.enabled !== false ? 'Snaps on' : 'Snaps off');
  }

  togglePane(which) {
    const dock = this.shell.dock;
    const phone = matchMedia('(max-width: 760px)').matches;
    if (phone) {
      const open = dock.classList.contains('phone-open') && dock.classList.contains(`phone-${which}`);
      dock.classList.remove('phone-open', 'phone-props', 'phone-browser');
      if (!open) dock.classList.add('phone-open', `phone-${which}`);
      this.renderPhonebar();
      return;
    }
    const cls = which === 'props' ? 'props-hidden' : 'browser-hidden';
    const other = which === 'props' ? 'browser-hidden' : 'props-hidden';
    if (dock.classList.contains(cls)) dock.classList.remove(cls);
    else if (dock.classList.contains(other)) {
      // Hiding the last pane hides the whole dock.
      this.shell.main.classList.toggle('dock-hidden');
    } else dock.classList.add(cls);
    this.settingsStore.set('dockState', { props: !dock.classList.contains('props-hidden'), browser: !dock.classList.contains('browser-hidden'), hidden: this.shell.main.classList.contains('dock-hidden') });
    // In Archicad's workspace the Properties panel stays closed unless it was opened on purpose.
    if (which === 'props' && this.workspace?.on) this.settingsStore.set('acShowProps', !dock.classList.contains('props-hidden'));
  }

  // Context menu ----------------------------------------------------------------------------------

  /** What the right-click menu offers to ask the assistant about the selection. */
  assistantMenu() {
    const it = uiLanguage(this.settings) === 'it';
    const els = [...this.selection].map((id) => this.doc.get(id)).filter(Boolean);
    const room = els.find((e) => e.kind === 'room');
    const items = [];
    if (room) {
      items.push({ label: '3D Cutaway of Room', icon: 'sectionBox', action: () => this.showRoomCutaway() });
      items.push({ label: 'Furnish with the Assistant...', icon: 'sparkles', action: () => this.askAssistant(it ? `Arreda la stanza "${room.name}" con gli oggetti delle librerie, poi controlla il risultato.` : `Furnish the room "${room.name}" with objects from the libraries, then check the result.`) });
    }
    items.push({ label: 'Ask the Assistant about This...', icon: 'sparkles', action: () => this.askAssistant(it ? 'Riguardo a ciò che ho selezionato: ' : 'About what I have selected: ') });
    return items;
  }

  contextMenu(ev) {
    const c = this.vc;
    if (!c) return;
    let hit = null;
    if (c.hitTest) hit = c.hitTest(ev.x, ev.y)[0] ?? null;
    if (hit && !this.selection.has(hit)) this.select([hit]);
    const sel = this.selection.size;
    const items = [];
    if (this.tool && !(this.tool instanceof SelectTool)) items.push({ label: 'Cancel', icon: 'x', action: () => this.cancelTool() });
    if (this.lastToolCommand) items.push({ label: `Repeat ${COMMANDS[this.lastToolCommand]?.label}`, icon: COMMANDS[this.lastToolCommand]?.icon, action: () => this.run(this.lastToolCommand) });
    if (items.length) items.push({ separator: true });
    if (sel) {
      items.push(
        { label: 'Select All Instances in View', icon: 'pointer', action: () => this.selectSimilar('view') },
        { label: 'Select All Instances in Project', icon: 'pointer', action: () => this.selectSimilar('project') },
        { separator: true },
        { label: 'Move', icon: 'move', shortcut: 'MV', action: () => this.run('move') },
        { label: 'Copy', icon: 'copyEl', shortcut: 'CO', action: () => this.run('copy') },
        { label: 'Rotate', icon: 'rotate', shortcut: 'RO', action: () => this.run('rotate') },
        { label: 'Mirror', icon: 'mirror', shortcut: 'MM', action: () => this.run('mirrorPick') },
        { separator: true },
        { label: 'Hide in View', icon: 'hideEl', submenu: [
          { label: 'Elements', action: () => this.hideInView('element') },
          { label: 'Category', action: () => this.hideInView('category') },
        ] },
        { label: 'Override Graphics in View...', icon: 'wsDisplay', shortcut: 'OG', action: () => this.run('overrideEl') },
        { label: 'Isolate Temporarily', icon: 'isolate', shortcut: 'HI', action: () => this.temporary('isolate') },
        this.reveal.has(this.activeViewId) ? { label: 'Unhide in View', icon: 'eye', action: () => this.unhideSelected() } : null,
        { separator: true },
        { label: 'Edit Type', icon: 'types', action: () => this.editTypeDialog() },
        { label: 'Delete', icon: 'trash', shortcut: 'Del', action: () => this.run('delete') },
        { separator: true },
        ...this.assistantMenu(),
      );
    } else {
      items.push(
        { label: 'Zoom to Fit', icon: 'zoomFit', shortcut: 'ZF', action: () => this.zoomFit() },
        { label: 'Zoom in Region', icon: 'zoomRegion', shortcut: 'ZR', action: () => this.run('zoomRegion') },
        this.clipboard ? { label: 'Paste', icon: 'paste', shortcut: `${MOD}+V`, action: () => this.paste() } : null,
        { label: 'Select All in View', icon: 'pointer', shortcut: `${MOD}+A`, action: () => this.selectAllInView() },
        { separator: true },
        { label: 'View Properties', icon: 'sliders', action: () => this.togglePane('props') },
      );
    }
    showMenu({ x: ev.original.clientX, y: ev.original.clientY }, items.filter(Boolean), { label: 'Context menu' });
  }

  // Clipboard ------------------------------------------------------------------------------------

  copyToClipboard(cut = false) {
    const ids = [...expandGroups(this.doc, this.selection)];
    const items = ids.map((id) => this.doc.get(id)).filter((el) => el && !isView(el) && el.kind !== 'level' && el.id !== 'project');
    if (!items.length) return;
    // Hosted elements of copied walls come along.
    const set = new Set(items.map((e) => e.id));
    for (const k of ['door', 'window', 'opening']) for (const el of this.doc.all(k)) if (set.has(el.hostId) && !set.has(el.id)) items.push(el);
    this.clipboard = { items: structuredClone(items), levelId: this.activeLevelId(), viewId: this.activeViewId };
    if (cut) {
      this.commit('Cut', () => deleteElements(this.doc, ids));
      this.select([]);
    }
    this.setPrompt(`${cut ? 'Cut' : 'Copied'} ${items.length} element${items.length === 1 ? '' : 's'}. Paste places them in the same position on the active level.`);
    this.ribbon.refresh();
  }

  /** Paste onto several levels: the clipboard's model elements, aligned with where they were copied. */
  pasteToLevels(levelIds = null) {
    const cb = this.clipboard;
    if (!cb) return this.toast('Copy elements first.', { kind: 'error' });
    const chosen = levelIds ? Promise.resolve(levelIds.map((id) => this.doc.get(id)).filter(Boolean)) : dialogs.chooseLevelsDialog(this, 'Paste Aligned to Selected Levels', 'Paste');
    chosen.then((levels) => {
      if (!levels?.length) return;
      const all = [];
      for (const l of levels) all.push(...this.paste(l.id, true));
      this.select(all);
      this.setPrompt(`Pasted on ${levels.length} level${levels.length === 1 ? '' : 's'}.`);
    });
  }

  /** Start placing another element like the selected one (same kind and type). */
  createSimilar() {
    const el = this.doc.get([...this.selection][0]);
    if (!el) return this.toast('Select an element first.', { kind: 'error' });
    const type = this.doc.get(el.typeId);
    if (type) return this.placeType(type, el.kind === 'column' ? 'column' : el.kind);
    const byKind = { room: 'room', grid: 'grid', level: 'level', text: 'text', dimension: 'dimension', detailLine: 'detailLine', region: 'region', roomSeparator: 'roomSeparator', refPlane: 'refPlane', modelLine: 'modelLine', area: 'area', areaBoundary: 'areaBoundary', revisionCloud: 'revisionCloud', insulation: 'insulation', detailItem: 'detailItem', detailArc: 'detailArc', spot: 'spotElevation', symbol: 'symbol', tag: 'tag', section: 'section', elevation: 'elevation' };
    const cmd = byKind[el.kind];
    if (!cmd) return this.toast('There is no tool for this kind of element.', { kind: 'error' });
    if (el.kind === 'detailLine' || el.kind === 'modelLine') this.toolOptions(el.kind, {}).style = el.style;
    if (el.kind === 'detailItem') Object.assign(this.toolOptions('detailItem', {}), { family: el.family });
    if (el.kind === 'symbol') Object.assign(this.toolOptions('symbol', {}), { family: el.family });
    this.run(cmd);
  }

  selectionFilterDialog() {
    return dialogs.selectionFilterDialog(this);
  }

  paste(toLevelId = null, quiet = false) {
    const cb = this.clipboard;
    if (!cb) return [];
    const levelId = toLevelId || this.activeLevelId();
    const targetView = this.activeViewId;
    const ids = [];
    this.commit('Paste', () => {
      const map = new Map();
      for (const it of cb.items) {
        if (it.hostId && cb.items.some((x) => x.id === it.hostId)) continue;
        if (it.hostId && !this.doc.has(it.hostId)) continue;
        // Pasting to other levels takes the model, not the annotations of the copied view.
        if (toLevelId && it.viewId) continue;
        const { id, ...rest } = it;
        const patch = {};
        if (rest.levelId && levelId) patch.levelId = levelId;
        if (rest.viewId) patch.viewId = targetView;
        if (rest.topLevelId && rest.levelId !== levelId) {
          const above = this.doc.levelAbove(levelId);
          patch.topLevelId = above?.id ?? null;
        }
        const n = this.doc.add({ ...rest, ...patch });
        map.set(id, n.id);
        ids.push(n.id);
      }
      for (const it of cb.items) {
        if (!it.hostId || !map.has(it.hostId)) continue;
        const { id, ...rest } = it;
        const n = this.doc.add({ ...rest, hostId: map.get(it.hostId) });
        map.set(id, n.id);
        ids.push(n.id);
      }
      // Pasted members belong to the pasted copy of their group.
      for (const it of cb.items) if (it.groupId && map.has(it.id)) this.doc.update(map.get(it.id), { groupId: map.get(it.groupId) ?? this.doc.addDefaults?.fields?.groupId ?? null });
    });
    if (quiet) return ids;
    this.select(ids);
    this.setPrompt(`Pasted ${ids.length} element${ids.length === 1 ? '' : 's'}. Use Move (MV) to position them.`);
    return ids;
  }

  // Keyboard ----------------------------------------------------------------------------------

  bindKeys() {
    document.addEventListener('keydown', (e) => this.keydown(e));
    // Space held down turns a click of a polygon tool into Archicad's Magic Wand (editor/draw.js).
    document.addEventListener('keyup', (e) => {
      if (e.key === ' ') this.spaceDown = false;
    });
    window.addEventListener('blur', () => (this.spaceDown = false));
  }

  keydown(e) {
    const tgt = e.target;
    const typing = tgt instanceof HTMLInputElement || tgt instanceof HTMLTextAreaElement || tgt instanceof HTMLSelectElement || tgt?.isContentEditable;
    if (document.querySelector('dialog[open]')) return;
    const mod = e.ctrlKey || e.metaKey;
    const key = e.key;
    // Walk mode in 3D: W/S or arrows move along the view, A/D sideways, Q/E down and up (Shift: faster).
    if (!typing && !mod && this.settings.navMode === 'walk' && this.vc?.is3D && this.vc.cam) {
      const k = key.toLowerCase();
      const step = (e.shiftKey ? 2000 : 500) * (this.settings.walkSpeed || 1);
      const { back, right } = this.vc.basis();
      const fwd = [-back[0], -back[1]];
      const fl = Math.hypot(fwd[0], fwd[1]) || 1;
      const mv = { w: [fwd[0] / fl, fwd[1] / fl, 0], arrowup: [fwd[0] / fl, fwd[1] / fl, 0], s: [-fwd[0] / fl, -fwd[1] / fl, 0], arrowdown: [-fwd[0] / fl, -fwd[1] / fl, 0], a: [-right[0], -right[1], 0], arrowleft: [-right[0], -right[1], 0], d: [right[0], right[1], 0], arrowright: [right[0], right[1], 0], q: [0, 0, -1], e: [0, 0, 1] }[k];
      if (mv) {
        e.preventDefault();
        const t = this.vc.cam.target;
        this.vc.cam.target = [t[0] + mv[0] * step, t[1] + mv[1] * step, t[2] + mv[2] * step];
        this.vc.userMoved = true;
        return this.requestRender();
      }
    }
    // Global accelerators work everywhere except in text fields.
    // Archicad's shortcuts in its workspace (ui/workspace.js), outside text fields.
    if (mod && this.workspace?.on && !typing && this.doc) {
      const cmd = acKeyCommand(e) || (!e.altKey ? AC_SHORTCUTS[`${e.shiftKey ? 'Shift+' : ''}${key.toLowerCase()}`] : null);
      if (cmd && this.commandDef(cmd)) {
        e.preventDefault();
        return this.run(cmd);
      }
    }
    if (mod && !e.altKey) {
      const k = key.toLowerCase();
      const map = { z: e.shiftKey ? 'redo' : 'undo', y: 'redo', s: e.shiftKey ? 'saveAs' : 'save', o: 'open', n: 'new', p: 'print', k: 'search' };
      if (!typing) Object.assign(map, { c: 'copyClip', x: 'cutClip', v: 'paste', a: 'selectAll', f: 'findSelect' });
      if (k === 'tab') {
        e.preventDefault();
        return this.cycleView(e.shiftKey ? -1 : 1);
      }
      if (map[k] && (!typing || ['s', 'o', 'n', 'p', 'k'].includes(k))) {
        e.preventDefault();
        return this.run(map[k]);
      }
      return;
    }
    if (key === 'F1') {
      e.preventDefault();
      return this.run('help');
    }
    if (typing || !this.doc) return;
    // Space held with a polygon tool is the Magic Wand; other tools keep Space (walls and doors flip with it).
    if (key === ' ' && this.tool?.magicWand && !tgt?.closest?.('button, a, [role="treeitem"], [role="tab"], .menu')) {
      e.preventDefault();
      if (!this.spaceDown) {
        this.spaceDown = true;
        this.setPrompt('Magic Wand: click inside an area, on an element or on a wall to trace its outline.');
      }
      return;
    }
    // Archicad's keys: F2 the floor plan of the current level, F3 the 3D window, F5 the selection or marquee in 3D.
    if (key === 'F5') {
      e.preventDefault();
      return this.run('show3d');
    }
    if (key === 'F2' || key === 'F3') {
      e.preventDefault();
      if (key === 'F3') return this.run('view3d');
      const plans = this.doc.all('plan').filter((p) => !p.calloutOf);
      const plan = plans.find((p) => p.levelId === this.activeView?.levelId) || plans[0];
      return plan && this.openView(plan.id);
    }
    if (tgt?.closest?.('.tree, .rb-tabs, .vtabs, .menu')) {
      if (key !== 'Escape') return;
    }
    if (this.tool?.key?.(e)) return;
    // The Tracker takes typed coordinates while a drawing tool is active (Tab, or a number to start with).
    if (!e.altKey && this.tracker?.drawingTool() && (key === 'Tab' || /^[0-9.,-]$/.test(key)) && this.tracker.edit(key === 'Tab' ? null : key)) {
      e.preventDefault();
      return;
    }
    if (key === 'Escape') {
      e.preventDefault();
      this.keyBuffer = '';
      // A cursor constraint goes first, then the tool's step back.
      if (this.constraint) {
        this.constraint = null;
        this.setPrompt('Constraint released.');
        this.requestRender();
        return;
      }
      if (this.navMode) return this.setNavMode(null);
      if (this.tool && !(this.tool instanceof SelectTool)) {
        if (this.tool.cancel()) this.cancelTool();
        else this.setPrompt(this.tool.prompt);
        this.requestRender();
        return;
      }
      return;
    }
    if (key === 'Delete' || (key === 'Backspace' && this.selection.size)) {
      e.preventDefault();
      return this.run('delete');
    }
    if (key === 'Enter' && this.lastToolCommand && (!this.tool || this.tool instanceof SelectTool)) {
      e.preventDefault();
      return this.run(this.lastToolCommand);
    }
    // Two-letter shortcuts.
    if (/^[a-z]$/i.test(key) && !e.altKey) {
      this.keyBuffer = (this.keyBuffer + key.toUpperCase()).slice(-2);
      clearTimeout(this.keyTimer);
      this.keyTimer = setTimeout(() => (this.keyBuffer = ''), 1500);
      this.setPrompt(`Shortcut: ${this.keyBuffer}`);
      if (this.keyBuffer.length === 2) {
        const name = Object.keys(COMMANDS).find((n) => COMMANDS[n].keys === this.keyBuffer);
        this.keyBuffer = '';
        if (name) {
          e.preventDefault();
          return this.run(name);
        }
        this.setPrompt('No command has that shortcut. Press F1 for the list.');
      }
    }
  }

  // Panels ----------------------------------------------------------------------------------------

  renderBrowser() {
    this.browser?.render();
    const t = this.shell?.root.querySelector('#browser-title');
    const name = this.workspace?.on ? 'Navigator' : 'Project Browser';
    if (t) t.textContent = this.doc ? `${name} - ${this.file?.name || this.doc.project.name}` : name;
  }

  updateTitle() {
    const t = this.shell.title;
    clear(t);
    if (!this.doc) {
      t.append(h('span.title-name', 'Building Design'));
      document.title = 'Building Design';
      return;
    }
    const name = this.file?.name || this.doc.project.name || 'Untitled';
    t.append(h('span.title-name', name));
    if (this.doc.modified) t.append(h('span.title-dot', { 'aria-label': 'Unsaved changes', role: 'img' }));
    const v = this.activeView;
    if (v) t.append(h('span.title-view', `- ${this.viewName(v)}`));
    document.title = `${this.doc.modified ? '* ' : ''}${name} - Building Design`;
    this.shell.undoBtn.disabled = !this.doc.canUndo;
    this.shell.redoBtn.disabled = !this.doc.canRedo;
  }

  bindDock() {
    const s = this.settings.dockState;
    if (s) {
      this.shell.dock.classList.toggle('props-hidden', s.props === false);
      this.shell.dock.classList.toggle('browser-hidden', s.browser === false);
      this.shell.main.classList.toggle('dock-hidden', !!s.hidden);
    }
    const w = this.settings.dockWidth;
    if (w) this.shell.root.style.setProperty('--dock-w', `${w}px`);
    const ph = this.settings.propsHeight;
    if (ph) this.shell.dock.style.setProperty('--props-h', `${ph}%`);
    const drag = (el, onMove, onEnd) => {
      el.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        el.setPointerCapture(e.pointerId);
        const move = (ev) => onMove(ev);
        const up = () => {
          el.removeEventListener('pointermove', move);
          el.removeEventListener('pointerup', up);
          onEnd?.();
        };
        el.addEventListener('pointermove', move);
        el.addEventListener('pointerup', up);
      });
    };
    drag(
      this.shell.dockResize,
      (ev) => {
        const r = this.shell.main.getBoundingClientRect();
        // The panel is on the left, or on the right in the Archicad-style workspace.
        const w2 = Math.max(200, Math.min(560, this.workspace?.on ? r.right - ev.clientX : ev.clientX - r.left));
        this.shell.root.style.setProperty('--dock-w', `${w2}px`);
        this.shell.dockResize.setAttribute('aria-valuenow', String(Math.round(w2)));
        this.dockW = w2;
      },
      () => this.dockW && this.settingsStore.set('dockWidth', this.dockW),
    );
    drag(
      this.shell.dockSplit,
      (ev) => {
        const r = this.shell.dock.getBoundingClientRect();
        const p = Math.max(15, Math.min(85, ((ev.clientY - r.top) / r.height) * 100));
        this.shell.dock.style.setProperty('--props-h', `${p}%`);
        this.shell.dockSplit.setAttribute('aria-valuenow', String(Math.round(p)));
        this.propsH = p;
      },
      () => this.propsH && this.settingsStore.set('propsHeight', this.propsH),
    );
    const keyResize = (el, prop, step, min, max, unit, save) =>
      el.addEventListener('keydown', (e) => {
        if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight' && e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
        e.preventDefault();
        e.stopPropagation();
        const target = prop === '--dock-w' ? this.shell.root : this.shell.dock;
        const cur = parseFloat(getComputedStyle(target).getPropertyValue(prop)) || (prop === '--dock-w' ? 290 : 52);
        const d = e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -step : step;
        const v = Math.max(min, Math.min(max, cur + d));
        target.style.setProperty(prop, `${v}${unit}`);
        el.setAttribute('aria-valuenow', String(Math.round(v)));
        this.settingsStore.set(save, v);
      });
    keyResize(this.shell.dockResize, '--dock-w', 16, 200, 560, 'px', 'dockWidth');
    keyResize(this.shell.dockSplit, '--props-h', 4, 15, 85, '%', 'propsHeight');
  }

  buildPhonebar() {
    this.renderPhonebar();
  }

  renderPhonebar() {
    const bar = this.shell.phonebar;
    clear(bar);
    const dock = this.shell.dock;
    const btn = (label, ic, action, pressed) => h('button.pb-btn', { type: 'button', 'aria-pressed': pressed == null ? null : String(pressed), onClick: action }, icon(ic, 20), h('span', label));
    bar.append(
      btn('Tools', 'wall', () => dialogs.toolsSheet(this)),
      btn('Views', 'layers', () => this.togglePane('browser'), dock.classList.contains('phone-browser') && dock.classList.contains('phone-open')),
      btn('Properties', 'sliders', () => this.togglePane('props'), dock.classList.contains('phone-props') && dock.classList.contains('phone-open')),
      btn('Undo', 'undo', () => this.run('undo')),
      btn('Modify', 'modify', () => dialogs.modifySheet(this)),
    );
  }

  // Selection overlay (temporary dimensions and room reference) -----------------------------------------

  drawSelectionOverlay(ctx, vc, vp) {
    this.tempDims = [];
    if (!vc?.is2D || this.selection.size !== 1 || !(this.tool instanceof SelectTool) || this.tool.drag?.started) return;
    const el = this.doc.get([...this.selection][0]);
    if (!el || el.pinned) return;
    for (const d of temporaryDimensions(this.doc, el)) {
      const rect = drawTempDim(ctx, vc.modelToScreen(d.a), vc.modelToScreen(d.b), formatLength(d.value, this.doc.units), vp.theme.selCss, vp.theme, d.offsetPx ?? 18);
      if (rect) this.tempDims.push({ ...d, rect });
    }
  }

  /** A click on a temporary dimension's value opens it for editing. */
  tempDimAt(x, y) {
    return (this.tempDims || []).find((d) => x >= d.rect.x && x <= d.rect.x + d.rect.w && y >= d.rect.y && y <= d.rect.y + d.rect.h) ?? null;
  }

  editTempDim(d, ev) {
    this.tool.openInput(ev.x, ev.y, {
      label: 'Distance',
      value: formatLength(d.value, this.doc.units),
      onSubmit: (v) => {
        const mm = parseLength(v, this.doc.units);
        if (!Number.isFinite(mm) || mm < 0) return false;
        this.commit('Edit dimension', () => d.apply(this.doc, mm));
        return true;
      },
    });
  }

  // Theme ----------------------------------------------------------------------------------------

  get themePref() {
    return this.settings.theme || 'system';
  }

  applyTheme() {
    const t = this.themePref;
    if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t;
    else delete document.documentElement.dataset.theme;
    try {
      localStorage.setItem('bd.theme', t);
    } catch {
      /* ignore */
    }
    requestAnimationFrame(() => this.viewport?.readTheme());
  }

  setTheme(value) {
    this.settingsStore.set('theme', value || 'system');
    this.applyTheme();
    this.ribbon?.refresh();
  }

  themeMenu(anchor) {
    const cur = this.themePref;
    showMenu(
      anchor,
      [
        { label: 'System', icon: 'monitor', checked: cur === 'system', radio: true, action: () => this.setTheme('system') },
        { label: 'Light', icon: 'sun-l', checked: cur === 'light', radio: true, action: () => this.setTheme('light') },
        { label: 'Dark', icon: 'moon', checked: cur === 'dark', radio: true, action: () => this.setTheme('dark') },
      ],
      { label: 'Theme' },
    );
  }

  // Account ----------------------------------------------------------------------------------------

  async renderAccount() {
    const el = this.shell.account;
    const seq = (this.accountSeq = (this.accountSeq || 0) + 1);
    if (!puterAvailable()) return clear(el);
    const signed = await isSignedIn();
    if (seq !== this.accountSeq) return;
    clear(el);
    if (!signed) {
      el.append(h('button.btn.sm', { type: 'button', onClick: () => this.signIn() }, icon('log-in', 14), h('span.hide-phone', 'Sign in')));
      return;
    }
    const user = await getUser();
    if (seq !== this.accountSeq) return;
    this.user = user;
    const name = user?.username || 'Account';
    const pic = cachedProfilePicture(name);
    const avatar = pic ? h('img.avatar', { src: pic, alt: '' }) : h('span.avatar.initials', name.slice(0, 1).toUpperCase());
    const btn = h('button.avatar-btn', { type: 'button', 'aria-label': `Account: ${name}`, 'aria-haspopup': 'menu', 'data-tip': name, onClick: (e) => this.accountMenu(e.currentTarget) }, avatar);
    el.append(btn);
    fetchProfilePicture(name).then((url) => {
      if (url && url !== pic) btn.replaceChildren(h('img.avatar', { src: url, alt: '' }));
    });
  }

  accountMenu(anchor) {
    const items = [{ header: this.user?.username || 'Signed in' }, { label: 'Open from Puter', icon: 'cloud', action: () => this.openDialog('cloud') }, { label: 'Shared With Me', icon: 'users', action: () => this.openDialog('shared') }];
    if (canSignOut()) items.push({ separator: true }, { label: 'Sign out', icon: 'log-out', action: () => this.signOut() });
    showMenu(anchor, items, { alignRight: true, label: 'Account' });
  }

  async signIn() {
    try {
      await signIn();
      await this.renderAccount();
      await this.settingsStore.syncFromCloud();
      this.applyPreferences();
      this.ribbon.renderBody();
      this.applyTheme();
      return true;
    } catch {
      this.toast('Sign-in was cancelled.');
      return false;
    }
  }

  signOut() {
    signOut();
    clearProfilePicture();
    this.user = null;
    this.renderAccount();
  }

  // Menus -------------------------------------------------------------------------------------------

  selectionOptionsMenu(anchor) {
    const flip = (k) => this.settingsStore.set(k, this.settings[k] === false);
    showMenu(anchor, [
      { label: 'Select Pinned Elements', checked: this.settings.selectPinned !== false, action: () => flip('selectPinned') },
      { label: 'Drag Elements When Selecting', checked: this.settings.dragOnSelect !== false, action: () => flip('dragOnSelect') },
      { separator: true },
      { label: 'Options...', icon: 'settings', action: () => this.run('options') },
    ], { label: 'Selection options' });
  }

  appMenu(anchor) {
    const recent = files.recentFiles().slice(0, 6);
    showMenu(
      anchor,
      [
        { label: 'New Project...', icon: 'file-plus', shortcut: `${MOD}+N`, action: () => this.run('new') },
        { label: 'Open...', icon: 'folder-open', shortcut: `${MOD}+O`, action: () => this.run('open') },
        recent.length ? { label: 'Recent', icon: 'history', submenu: recent.map((r) => ({ label: r.name, icon: r.source === 'cloud' ? 'cloud' : 'device', action: () => files.openRecent(this, r) })) } : null,
        { separator: true },
        { label: 'Save', icon: 'save', shortcut: `${MOD}+S`, action: () => this.run('save') },
        { label: 'Save As...', icon: 'save-all', action: () => this.run('saveAs') },
        { label: 'Export...', icon: 'download', action: () => this.run('export') },
        { label: 'Print or Export PDF...', icon: 'printer', shortcut: `${MOD}+P`, action: () => this.run('print') },
        { separator: true },
        { label: 'Share Project...', icon: 'share', action: () => this.run('share') },
        { label: 'Project Information...', icon: 'info', action: () => this.run('projectInfo') },
        { separator: true },
        { label: 'Home', icon: 'house', action: () => this.showHome() },
        { label: 'Options...', icon: 'settings', action: () => this.run('options') },
        { label: 'Keyboard Shortcuts...', icon: 'keyboard', action: () => this.run('shortcuts') },
        { label: 'About Building Design', icon: 'info', action: () => this.run('about') },
      ].filter(Boolean),
      { label: 'File', className: 'app-menu' },
    );
  }

  commandPalette() {
    dialogs.commandPalette(this);
  }

  // Home --------------------------------------------------------------------------------------------

  showHome(keepDoc = false) {
    void keepDoc;
    this.viewport.setController(null);
    this.shell.viewcube.hidden = true;
    this.shell.nav.hidden = true;
    this.shell.domView.hidden = false;
    this.activeHome = true;
    renderHome(this, this.shell.domView);
    if (!this.doc) {
      clear(this.shell.vtabs);
      this.updateTitle();
    }
  }

  newProject(system) {
    const doc = createProject({ system });
    if (uiLanguage(this.settings) === 'it') {
      const [ground, first] = doc.levels();
      doc.transact('Names', () => {
        for (const [lv, name] of [[ground, 'Piano Terra'], [first, 'Piano']]) {
          if (!lv) continue;
          doc.update(lv.id, { name });
          for (const v of doc.all('plan')) if (v.levelId === lv.id) doc.update(v.id, { name });
        }
      });
    }
    this.setDoc(doc, null);
    this.toast(`New ${system === 'imperial' ? 'imperial' : 'metric'} project. Start with Wall (WA) in the Architecture tab.`);
  }

  openSample() {
    const doc = createSampleProject({ system: this.settings.units === 'imperial' ? 'imperial' : 'metric' });
    this.setDoc(doc, null);
  }

  /** Starts a new or sample project after offering to save unsaved changes. */
  async startProject(kind) {
    if (!(await files.confirmDiscard(this))) return false;
    if (kind === 'sample') this.openSample();
    else this.newProject(kind);
    return true;
  }

  // Files and dialogs (implemented in io/files.js and ui/dialogs.js) ------------------------------------

  newProjectDialog() {
    return dialogs.newProjectDialog(this);
  }
  openDialog(tab) {
    return files.openDialog(this, tab);
  }
  save() {
    return files.save(this);
  }
  saveAs() {
    return files.saveAs(this);
  }
  exportDialog(format) {
    return dialogs.exportDialog(this, format);
  }
  shareDialog() {
    return dialogs.shareDialog(this);
  }
  layerSettingsDialog() {
    return dialogs.layerSettingsDialog(this);
  }
  fixStairDialog() {
    const stair = [...this.selection].map((id) => this.doc.get(id)).find((el) => el?.kind === 'stair');
    if (!stair) return this.toast('Select a stair first.', { kind: 'error' });
    return dialogs.fixStairDialog(this, stair);
  }
  editTypeDialog(type) {
    const t = type || this.doc.get(this.doc.get([...this.selection][0])?.typeId) || (this.tool?.placingKind ? this.currentType(this.tool.placingKind) : null);
    if (!t) return this.toast('Select an element with a type, or choose a type in the Project Browser.', { kind: 'error' });
    return dialogs.typeDialog(this, t);
  }
  visibilityDialog() {
    return dialogs.visibilityDialog(this);
  }
  projectInfoDialog() {
    return dialogs.projectInfoDialog(this);
  }
  unitsDialog() {
    return dialogs.unitsDialog(this);
  }
  materialsDialog() {
    return dialogs.materialsDialog(this);
  }

  energyDialog() {
    return energyUi.energyDialog(this);
  }

  /** Plan graphics of elements in the active plan view (sync first). */
  planBuildersOf(ids) {
    const c = this.vc;
    if (!c?.is2D || !c.layer) return [];
    c.sync();
    return ids.map((id) => c.layer.items.get(id)?.g).filter(Boolean);
  }

  /** Explode into Current View: the selection's plan graphics become drafting in this view. */
  async explodeSelection() {
    const view = this.activeView;
    const ids = [...this.selection].filter((id) => !this.doc.get(id)?.kind?.endsWith('Type'));
    if (!this.vc?.is2D || view?.kind === 'sheet') return this.toast('Open a plan or drafting view and select what to explode.', { kind: 'error' });
    if (!ids.length) return this.toast('Select the elements to explode.', { kind: 'error' });
    const keep = h('input', { type: 'checkbox' });
    const ok = await openDialogFn({
      title: 'Explode into Current View',
      size: 'sm',
      body: h('div', h('p.dialog-text', `${ids.length} element${ids.length === 1 ? '' : 's'} become lines, fills and text in ${view.name}, which you can edit freely.`), h('label.check', keep, h('span', 'Keep the original elements'))),
      actions: [
        { label: 'Cancel', value: null },
        { label: 'Explode', primary: true, value: true },
      ],
    });
    if (!ok) return;
    const parts = explodeGraphics(this.planBuildersOf(ids), +view.scale || 100);
    let made = [];
    this.commit('Explode', () => {
      made = addExploded(this.doc, view.id, parts);
      if (!keep.checked) deleteElements(this.doc, ids);
    });
    this.select(made);
    this.toast(`Exploded into ${parts.lines.length} lines, ${parts.fills.length} fills and ${parts.texts.length} texts.`, { kind: 'success' });
  }

  /** Save as Worksheet: what the active plan shows (or the selection) as a new drafting view. */
  saveAsWorksheet() {
    const view = this.activeView;
    const c = this.vc;
    if (view && (view.kind === 'elevation' || view.kind === 'section')) return this.independentDrawing();
    if (!c?.is2D || !view || view.kind === 'sheet') return this.toast('Open a plan, section or elevation to save it as a worksheet.', { kind: 'error' });
    c.sync();
    const ids = this.selection.size ? [...this.selection] : [...c.layer.items.keys()].filter((id) => this.doc.has(id) && !(this.flagsOf(id) & FLAG.hidden));
    const parts = explodeGraphics(this.planBuildersOf(ids), +view.scale || 100);
    const names = this.doc.all('drafting').map((v) => v.name);
    const ws = { id: newId('v'), kind: 'drafting', name: uniqueName(names, `${view.name} - Worksheet`), scale: +view.scale || 100, detail: 'fine', hiddenCats: [], hiddenIds: [] };
    this.commit('Save as worksheet', () => {
      this.doc.add(ws);
      addExploded(this.doc, ws.id, parts);
    });
    this.openView(ws.id);
    this.toast(`Saved as ${ws.name}: ${parts.lines.length} lines, ${parts.fills.length} fills, ${parts.texts.length} texts.`, { kind: 'success' });
  }

  /**
   * Create Independent Section/Elevation (Archicad): the active section or
   * elevation drawn as 2D lines and fills in a new drafting view that no
   * longer follows the model: cut fills, visible projected edges, levels.
   */
  independentDrawing() {
    const view = this.activeView;
    if (!view || (view.kind !== 'elevation' && view.kind !== 'section')) return this.toast('Open a section or an elevation first.', { kind: 'error' });
    const doc = this.doc;
    const meshOf = (el) => this.scene.mesh(el);
    const parts = independentDrawing(doc, view, meshOf, MODEL_KINDS);
    // Levels and the view's own annotations, as the view shows them.
    if (this.vc?.annot) {
      const frame = viewFrame(view);
      const range = this.vc.modelRange?.(frame);
      if (range) {
        const ann = elevationAnnotations(doc, view, frame, range, this.scene.walls, meshOf);
        const extra = explodeGraphics(ann.map((x) => x.g), +view.scale || 100);
        parts.lines.push(...extra.lines);
        parts.fills.push(...extra.fills);
        parts.texts.push(...extra.texts);
      }
    }
    const names = doc.all('drafting').map((v) => v.name);
    const ws = { id: newId('v'), kind: 'drafting', name: uniqueName(names, `${view.name} - Independent`), scale: +view.scale || 100, detail: 'fine', hiddenCats: [], hiddenIds: [], sourceViewId: view.id };
    this.commit(view.kind === 'section' ? 'Create independent section' : 'Create independent elevation', () => {
      doc.add(ws);
      addExploded(doc, ws.id, parts);
    });
    this.openView(ws.id);
    this.toast(`Created ${ws.name}: ${parts.lines.length} lines, ${parts.fills.length} fills, ${parts.texts.length} texts.`, { kind: 'success' });
    return ws;
  }

  /** On-screen line widths for the project's line weights, cached while the project record is the same. */
  penWeightsPx() {
    const p = this.doc?.project;
    if (this._penKey !== p) {
      this._penKey = p;
      this._penPx = screenWeights(classWeights(p, weightsOf(this.doc)) || weightsOf(this.doc));
    }
    return this._penPx;
  }

  /** Line Weights dialog (Archicad's Pens): the printed width of each line weight class. */
  lineWeightsDialog() {
    const doc = this.doc;
    const body = h('div');
    const render = () => {
      clear(body);
      const w = weightsOf(doc);
      const rows = WEIGHT_CLASSES.map((c) => {
        const inp = h('input.input.sm', { type: 'number', min: 0.05, max: 3, step: 0.01, value: w[c.i], 'aria-label': `${c.name} width in mm` });
        inp.addEventListener('keydown', (e) => e.stopPropagation());
        inp.addEventListener('change', () => {
          const v = Math.max(0.05, Math.min(3, +inp.value || DEFAULT_WEIGHTS_MM[c.i]));
          const next = weightsOf(doc).slice();
          next[c.i] = v;
          this.commit('Line weights', () => doc.update('project', { lineWeights: next }));
          this.requestRender();
          render();
        });
        const sample = h('span.lw-sample', { style: { height: `${Math.max(1, w[c.i] * 7.6)}px` } });
        return h('tr', h('td', h('strong', c.name)), h('td', h('span.lw-in', inp, 'mm')), h('td', sample), h('td.file-meta', c.use));
      });
      body.append(
        h('table.layers-table', h('thead', h('tr', h('th', 'Weight'), h('th', 'Printed width'), h('th', 'Preview'), h('th', 'Used for'))), h('tbody', rows)),
        h('div', { style: { marginTop: '10px' } }, h('button.btn.sm', { type: 'button', onClick: () => (this.commit('Line weights', () => doc.update('project', { lineWeights: null })), this.requestRender(), render()) }, 'Reset to Defaults')),
        h('p.field-hint', 'Widths apply to PDF and SVG exports and, in proportion, on screen. Thin Lines (View menu) still shows every line thin.'),
      );
    };
    render();
    return openDialogFn({ title: 'Line Weights', size: 'md', body, actions: [{ label: 'Close', primary: true, value: null }] });
  }

  /**
   * Import DWG: a CAD drawing (DWG, read with LibreDWG in a worker) into the
   * active 2D view as lines, arcs, text and solid fills, layer by layer, at
   * its units; each item keeps its CAD layer for Find & Select and Convert Selection.
   */
  /**
   * Import a DWG or DXF into the active 2D view. opts.settings (a DXF-DWG translator or an xref's own settings) fills
   * the dialog; with opts.silent the import runs on them without asking. Returns { settings, res } or undefined.
   */
  async importDWG(file = null, opts = {}) {
    const f = file || (await files.pickFile('.dwg,.DWG,.dxf,.DXF'));
    if (!f) return;
    const view = this.activeView;
    if (!this.vc?.is2D || view?.kind === 'sheet') return this.toast('Open a plan, drafting view or detail to import a DWG into.', { kind: 'error' });
    if (f.size > 80e6) return this.toast('That DWG is larger than 80 MB.', { kind: 'error' });
    this.setPrompt(`Reading ${f.name}...`);
    let cad;
    try {
      const { readCAD } = await import('./io/dwgread.js');
      cad = await readCAD(new Uint8Array(await f.arrayBuffer()), { dxf: /\.dxf$/i.test(f.name) });
    } catch (err) {
      this.setPrompt('Ready');
      return this.toast(`That DWG could not be read: ${err.message || err}`, { kind: 'error' });
    }
    const all = flattenCAD(cad);
    const counts = [...layerCounts(all)].sort((a, b) => b[1] - a[1]);
    const unitMm = INSUNITS_MM[cad.units] ?? 1;
    // The DXF-DWG translator (or an xref's own settings) gives the starting choices.
    const tr = opts.settings || dwgTranslatorFor(this.doc);
    const unitStart = tr.unit && tr.unit !== 'auto' ? +tr.unit : unitMm;
    const unit = h('select.input', { 'aria-label': 'Drawing unit' }, [['1', 'Millimetres'], ['10', 'Centimetres'], ['1000', 'Metres'], ['25.4', 'Inches'], ['304.8', 'Feet']].map(([v, l]) => h('option', { value: v, selected: Math.abs(+v - unitStart) < 1e-9 }, l)));
    const centre = h('input', { type: 'checkbox', checked: tr.centre !== false });
    const fills = h('input', { type: 'checkbox', checked: tr.fills !== false });
    // Smart Merge: an earlier import of this file in this view is replaced.
    const earlier = [...this.doc.items.values()].filter((el) => el.cadSource === f.name && (el.viewId === view.id || (!el.viewId && el.levelId === view.levelId))).length;
    const smart = h('input', { type: 'checkbox', checked: earlier > 0 });
    const isPlan = view.kind === 'plan' && !!view.levelId;
    const roleOf = defaultRoles(counts.map(([name]) => name));
    for (const [k, v] of Object.entries(tr.roles || {})) if (roleOf.has(k)) roleOf.set(k, v);
    const hasModel = [...roleOf.values()].some((r) => !['drafting', 'ignore'].includes(r));
    const want = tr.mode && (isPlan || tr.mode === 'drafting') ? tr.mode : null;
    const mode = h('select.input', { 'aria-label': 'Import as' },
      h('option', { value: 'smart', selected: want ? want === 'smart' : isPlan && hasModel, disabled: !isPlan }, 'Model from layers, the rest as drafting'),
      h('option', { value: 'model', selected: want === 'model', disabled: !isPlan }, 'Model only'),
      h('option', { value: 'drafting', selected: want ? want === 'drafting' : !isPlan || !hasModel }, 'Drafting only'));
    const skipped = new Set(tr.skip || []);
    const boxes = counts.map(([name, n]) => {
      const cb = h('input', { type: 'checkbox', checked: !skipped.has(name), value: name });
      const role = h('select.input.sm', { 'aria-label': `Role of ${name || 'no layer'}` }, ROLES.map((r) => h('option', { value: r.value, selected: roleOf.get(name) === r.value }, r.label)));
      return { cb, role, name, row: h('label.check.dwg-layer', cb, h('span.file-name', name || '(no layer)'), h('span.file-meta', String(n)), role) };
    });
    const list = h('div.dwg-layers', boxes.map((b) => b.row));
    const setAll = (v) => boxes.forEach((b) => (b.cb.checked = v));
    const current = () => ({ unit: unit.value, centre: centre.checked, fills: fills.checked, mode: mode.value, roles: Object.fromEntries(boxes.map((b) => [b.name, b.role.value])), skip: boxes.filter((b) => !b.cb.checked).map((b) => b.name) });
    const saveTr = h('button.btn.sm', { type: 'button', onClick: async () => {
      const name = await promptDialog('Save as DXF-DWG Translator', 'Name', tr.name && !opts.settings ? `${tr.name} copy` : 'My translator');
      if (!name) return;
      this.commit('Save DXF-DWG translator', () => saveDwgTranslator(this.doc, { name, ...current() }));
      this.toast(`Translator "${name}" saved.`);
    } }, 'Save as Translator...');
    const ok = opts.silent ? true : await openDialogFn({
      title: 'Import DWG',
      size: 'lg',
      body: h('div',
        h('p.dialog-text', `${f.name}: ${all.lines.length} lines, ${all.arcs.length} arcs, ${all.texts.length} texts, ${all.fills.length} fills on ${counts.length} layers.${tr.name ? ` Translator: ${tr.name}.` : ''}`),
        h('div.row2', h('label.field', h('span.field-label', 'Import as'), mode), h('label.field', h('span.field-label', 'Drawing unit'), unit)),
        h('div.inline', { style: { gap: '14px' } }, h('label.check', centre, h('span', 'Move the drawing\'s middle to the origin')), h('label.check', fills, h('span', 'Solid fills as filled regions'))),
        earlier ? h('label.check', smart, h('span', `Replace the ${earlier} elements an earlier import of ${f.name} brought here (Smart Merge)`)) : null,
        h('div.inline', { style: { gap: '6px', margin: '6px 0' } }, h('span.field-label', 'Layers'), h('button.btn.sm', { type: 'button', onClick: () => setAll(true) }, 'All'), h('button.btn.sm', { type: 'button', onClick: () => setAll(false) }, 'None'), saveTr),
        list,
        h('p.field-hint', isPlan
          ? 'Each layer\'s role is read from its name. Walls come from the cut fills or outlines on wall layers, doors and windows from the symbols in the gaps between them, glazing away from walls becomes curtain walls, zone outlines become rooms numbered from their stamps. Other layers come in as drafting that remembers its CAD layer.'
          : 'Everything comes in as drafting in this view, each piece remembering its CAD layer. Open a floor plan to make a model from the layers.')),
      actions: [
        { label: 'Cancel', value: null },
        { label: 'Import', primary: true, value: true },
      ],
    });
    if (!ok) return this.setPrompt('Ready');
    const settings = current();
    const keep = new Set(boxes.filter((b) => b.cb.checked).map((b) => b.name));
    const roles = new Map(boxes.map((b) => [b.name, b.role.value]));
    let res;
    let replaced = 0;
    this.commit(opts.label || 'Import DWG', () => {
      if (earlier && (smart.checked || opts.silent)) replaced = removeCADImport(this.doc, f.name, view);
      res = placeCAD(this.doc, cad, { view, layers: keep, roles, unitMm: +unit.value || 1, centre: centre.checked, fills: fills.checked, mode: mode.value, source: f.name });
      opts.inside?.(settings, res);
    });
    if (replaced) this.toast(`Smart Merge: ${replaced} elements of the earlier import replaced.`);
    this.run('zoomFit');
    const m = res.model;
    const made = m ? `${m.walls.length} walls, ${m.doors.length} doors, ${m.windows.length} windows, ${m.columns.length} columns and ${m.rooms.length} zones made, ` : '';
    this.setPrompt(`${made}${res.drafting} drafting items from ${f.name}.`);
    if (m?.skipped?.length) this.toast(m.skipped.slice(0, 3).join('; '), { kind: 'info' });
    return { settings, res };
  }

  /**
   * Make a model from any drawing file, the best way for its kind: an IFC
   * opens as elements; a DWG or DXF as a model from its layers; a PDF from a
   * CAD program as a model from its vectors, else as a picture; a picture
   * (a scan, a photo, an export) is straightened when it is a photo, and
   * modelled at its scale (estimated from its walls and doors when it was
   * not given). Returns a summary of what was made and what to check.
   */
  async modelFromFile(file, { scale = 0 } = {}) {
    const name = file.name || 'drawing';
    const ext = (/\.([a-z0-9]+)$/i.exec(name)?.[1] || '').toLowerCase();
    if (ext === 'ifc') return { kind: 'ifc', ...(await this.openIFC(file)) };
    let plan = this.activeView?.kind === 'plan' ? this.activeView : this.doc.all('plan').find((v) => v.levelId === this.activeLevelId?.()) || this.doc.all('plan')[0];
    if (!plan) return { error: 'This project has no floor plan to model in.' };
    if (this.activeView?.id !== plan.id) this.openView(plan.id);
    if (ext === 'dwg' || ext === 'dxf') {
      const { readCAD } = await import('./io/dwgread.js');
      const cad = await readCAD(new Uint8Array(await file.arrayBuffer()), { dxf: ext === 'dxf' });
      let res;
      this.commit('Model from DWG', () => (res = placeCAD(this.doc, cad, { view: plan, unitMm: INSUNITS_MM[cad.units] ?? 1, mode: 'smart' })));
      this.run('zoomFit');
      const m = res.model;
      this.setPrompt(`${name}: ${m.walls.length} walls, ${m.doors.length} doors, ${m.windows.length} windows, ${m.columns.length} columns and ${m.rooms.length} zones made, ${res.drafting} drafting items.`);
      return { kind: 'cad', walls: m.walls.length, doors: m.doors.length, windows: m.windows.length, columns: m.columns.length, zones: m.rooms.length, drafting: res.drafting };
    }
    let src;
    let px;
    let pageMm = null;
    let stated = 0;
    if (ext === 'pdf') {
      const { openPDF } = await import('./io/pdfread.js');
      const pdf = await openPDF(new Uint8Array(await file.arrayBuffer()));
      const vec = await pdf.vectors(1);
      const rec = recognizePDF(vec, { scale: scale || null });
      if (!rec.error && rec.plan.walls.length >= 3) return { kind: 'pdf', ...(await this.modelFromPdf(pdf, 1, scale, name, 200, vec)) };
      // A scan in a PDF: its page as a picture.
      stated = scale || statedScales(vec.texts)[0] || 0;
      const r = await pdf.render(1, { dpi: 200 });
      pdf.close();
      src = r.canvas.toDataURL('image/png');
      px = [r.canvas.width, r.canvas.height];
      pageMm = [r.widthMm, r.heightMm];
    } else if (['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'].includes(ext)) {
      src = await new Promise((resolve, reject) => {
        const fr = new FileReader();
        fr.onload = () => resolve(String(fr.result));
        fr.onerror = () => reject(new Error('The picture could not be read'));
        fr.readAsDataURL(file);
      });
      const pic = await new Promise((resolve) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.src = src;
      });
      px = [pic.naturalWidth, pic.naturalHeight];
    } else return { error: `${name}: drop a DWG, DXF, IFC, PDF or a picture of a plan.` };
    const known = stated && pageMm ? pageMm[0] * stated : 0;
    const img = placeUnderlay(this, { src, name, px, width: known || 20000, calibrated: !!known, ...(pageMm ? { pageMm } : {}) });
    let straightened = false;
    if (!pageMm) {
      // A photo: a sheet that does not fill the picture.
      const st = await this.straightenImage(img.id, null, { quiet: true }).catch(() => null);
      straightened = !!st && !st.error && !st.unchanged;
    }
    let el = this.doc.get(img.id);
    let estimated = false;
    if (!el.calibrated) {
      const mm = await this.guessImageScale(el);
      if (!mm) return { kind: 'picture', image: el.id, straightened, error: 'No walls stand out on this picture: calibrate it and trace it.' };
      this.commit('Estimated scale', () => this.doc.update(el.id, { w: mm * (el.px?.[0] || 1), h: mm * (el.px?.[1] || 1), calibrated: true, scaleEstimated: true }));
      el = this.doc.get(img.id);
      estimated = true;
    }
    const made = await this.modelFromImage(el.id);
    this.run('zoomFit');
    return { kind: 'picture', image: el.id, straightened, scaleEstimated: estimated, ...made, ...(estimated ? { next: 'The scale was estimated from the walls and doors: check one length you know (calibrate_image) and model again if it is off.' } : {}) };
  }

  /** A file dropped on the app: a project opens, any drawing is modelled (modelFromFile). */
  async dropFile(file) {
    if (/\.bdp$/i.test(file.name)) {
      if (!(await files.confirmDiscard(this))) return;
      return files.loadBuffer(this, await file.arrayBuffer(), { name: file.name.replace(/\.bdp$/i, ''), source: 'device' });
    }
    // A photograph of a room is not a plan: the recognizer would read noise as walls. The assistant can rebuild it.
    if (/^image\//.test(file.type) && (await this.isPhoto(file))) {
      this.askAssistant(uiLanguage(this.settings) === 'it' ? 'Questa è una foto di una stanza: ricreala nel progetto con pareti, aperture, pavimento e arredi, stimando le misure e rispettando i colori.' : 'This is a photo of a room: rebuild it in the project with walls, openings, floor and furniture, estimating the sizes and keeping the colours.');
      this.assistant?.attach(file);
      this.toast('This looks like a photo of a room. If it is a plan, import it from the File menu.');
      return { photo: true };
    }
    this.setPrompt(`Reading ${file.name}...`);
    try {
      const out = await this.modelFromFile(file);
      if (out?.error) this.toast(out.error, { kind: 'error' });
      else if (out?.scaleEstimated) this.toast('The picture\'s scale was estimated from its walls and doors. Check a length you know with Calibrate Image.', { kind: 'info' });
      return out;
    } catch (err) {
      this.setPrompt('Ready');
      this.toast(`${file.name} could not be read: ${err.message || err}`, { kind: 'error' });
      return { error: String(err.message || err) };
    }
  }

  /** Whether a picture looks like a photograph rather than a drawing of a plan. */
  async isPhoto(file) {
    try {
      const bmp = await createImageBitmap(file);
      const cv = new OffscreenCanvas(96, 96);
      const g = cv.getContext('2d', { willReadFrequently: true });
      g.drawImage(bmp, 0, 0, 96, 96);
      return looksLikePhoto(g.getImageData(0, 0, 96, 96).data);
    } catch {
      return false;
    }
  }

  /** Opens the assistant with a request written out, for the user to complete or send. */
  askAssistant(text = '') {
    this.toggleAssistant(true);
    if (!this.assistant) return;
    this.assistant.input.value = text;
    this.assistant.input.focus();
  }

  /** Shows the inside of the selected room (or the only room) in the 3D view. */
  showRoomCutaway() {
    const doc = this.doc;
    const r = [...this.selection].map((id) => doc.get(id)).find((e) => e?.kind === 'room') || (doc.all('room').length === 1 ? doc.all('room')[0] : null);
    const v = doc.all('view3d')[0];
    const cut = r && v ? roomCutaway(doc, this.scene, r) : null;
    if (!cut) return this.toast('Select a room with walls round it first.', { kind: 'error' });
    this.commit('3D cutaway of room', () => doc.update(v.id, { sectionBox: cut.sectionBox }));
    this.openView(v.id);
    this.vc.cam = cut.camera;
    this.vc.userMoved = true;
    this.vc.vp?.requestRender();
  }

  /** A picture's likely millimetres per pixel, from its walls and doors (recognizeimage.js). */
  async guessImageScale(img) {
    const pic = await new Promise((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('The picture could not be read'));
      el.src = img.src;
    });
    const k = Math.min(1, Math.sqrt(6e6 / (pic.naturalWidth * pic.naturalHeight)));
    const w = Math.round(pic.naturalWidth * k);
    const h = Math.round(pic.naturalHeight * k);
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(pic, 0, 0, w, h);
    const data = ctx.getImageData(0, 0, w, h).data;
    const gray = new Uint8Array(w * h);
    for (let i = 0; i < gray.length; i++) gray[i] = (data[4 * i] * 0.299 + data[4 * i + 1] * 0.587 + data[4 * i + 2] * 0.114) | 0;
    const s = guessScale({ gray, w, h });
    return s ? (s * w) / (img.px?.[0] || pic.naturalWidth) : null;
  }

  /** Open an IFC file as elements of this project, on its storeys' levels. */
  async openIFC(file = null) {
    const f = file || (await files.pickFile('.ifc,.IFC'));
    if (!f) return null;
    if (f.size > 200e6) return this.toast('That IFC file is larger than 200 MB.', { kind: 'error' }), null;
    this.setPrompt(`Reading ${f.name}...`);
    let out;
    try {
      const text = await f.text();
      const { ifcToModel } = await import('./io/ifcmodel.js');
      this.commit('Open IFC', () => (out = ifcToModel(this.doc, text, { name: f.name, prefs: this.settings.ifcLocal })));
    } catch (err) {
      this.setPrompt('Ready');
      return this.toast(`That IFC file could not be read: ${err.message || err}`, { kind: 'error' }), null;
    }
    this.run('zoomFit');
    const parts = [['walls', out.walls], ['curtain walls', out.curtainWalls], ['slabs', out.slabs], ['doors', out.doors], ['windows', out.windows], ['columns', out.columns], ['beams', out.beams], ['roofs', out.roofs], ['foundations', out.foundations], ['duct, pipe and tray runs', out.runs], ['zones', out.spaces]].filter(([, n]) => n).map(([k, n]) => `${n} ${k}`);
    this.setPrompt(`${f.name}: ${parts.join(', ') || 'nothing of this app\'s kinds'}${out.levels ? `, on ${out.levels} new level${out.levels === 1 ? '' : 's'}` : ''}${out.other ? `; ${out.other} other elements shown as an imported model` : ''}.`);
    return out;
  }

  /** Text Styles dialog: named text looks; changing one changes every note using it. */
  textStylesDialog() {
    const doc = this.doc;
    const body = h('div');
    const render = () => {
      clear(body);
      const rows = doc.all('textStyle').map((t) => {
        const upd = (patch) => (this.commit('Text style', () => doc.update(t.id, patch)), render());
        const name = h('input.input.sm', { type: 'text', value: t.name, 'aria-label': `Name of ${t.name}` });
        name.addEventListener('keydown', (e) => e.stopPropagation());
        name.addEventListener('change', () => name.value.trim() && upd({ name: name.value.trim() }));
        const size = h('select.input.sm', { 'aria-label': `Size of ${t.name}` }, [1.5, 1.8, 2, 2.5, 3, 3.5, 5, 7, 10].map((v) => h('option', { value: v, selected: +t.size === v }, `${v} mm`)));
        size.addEventListener('change', () => upd({ size: +size.value }));
        const bold = h('input', { type: 'checkbox', checked: !!t.bold, 'aria-label': `${t.name} bold` });
        bold.addEventListener('change', () => upd({ bold: bold.checked }));
        const align = h('select.input.sm', { 'aria-label': `Alignment of ${t.name}` }, ['left', 'center', 'right'].map((a) => h('option', { value: a, selected: (t.align || 'left') === a }, a[0].toUpperCase() + a.slice(1))));
        align.addEventListener('change', () => upd({ align: align.value }));
        const n = doc.filter((e) => e.kind === 'text' && e.styleId === t.id).length;
        const del = h('button.icon-btn.sm', { type: 'button', 'aria-label': `Delete ${t.name}`, onClick: () => {
          this.commit('Delete text style', () => {
            // Notes keep the look they had.
            for (const e of doc.filter((x) => x.kind === 'text' && x.styleId === t.id)) doc.update(e.id, { styleId: null, size: t.size, bold: t.bold, align: t.align });
            doc.remove(t.id);
          });
          render();
        } }, icon('trash', 13));
        return h('tr', h('td', name), h('td', size), h('td', bold), h('td', align), h('td.file-meta', n ? `${n} note${n === 1 ? '' : 's'}` : ''), h('td', del));
      });
      body.append(
        h('table.layers-table', h('thead', h('tr', h('th', 'Name'), h('th', 'Size'), h('th', 'Bold'), h('th', 'Alignment'), h('th', 'Used'), h('th', ''))), h('tbody', rows)),
        h('div', { style: { marginTop: '8px' } }, h('button.btn.sm', { type: 'button', onClick: () => (this.commit('New text style', () => doc.add({ kind: 'textStyle', name: uniqueName(doc.all('textStyle').map((x) => x.name), 'Style 1'), size: 2.5, bold: false, align: 'left' })), render()) }, icon('plus', 14), 'New Style')),
        h('p.field-hint', 'Choose a style for a note in its properties or in the Text tool\'s options. Sizes are millimetres on paper.'),
      );
    };
    render();
    return openDialogFn({ title: 'Text Styles', size: 'md', body, actions: [{ label: 'Close', primary: true, value: null }] });
  }

  /** Import Survey Points: a terrain mesh through the points of a CSV, TXT or XYZ file. */
  async importSurveyPoints(file = null) {
    const f = file || (await files.pickFile('.csv,.txt,.xyz,.pts,text/plain,text/csv'));
    if (!f) return;
    const text = await f.text();
    const order = h('select.input', { 'aria-label': 'Columns' }, SURVEY_ORDERS.map((o) => h('option', { value: o.value }, o.label)));
    const unit = h('select.input', { 'aria-label': 'Unit' }, ['m', 'mm', 'cm', 'ft'].map((u) => h('option', { value: u }, u)));
    const centre = h('input', { type: 'checkbox', checked: true });
    const info = h('p.field-hint');
    const update = () => {
      const pts = parseSurveyPoints(text, { order: order.value, unit: unit.value });
      if (!pts.length) return (info.textContent = 'No points found: each line needs three numbers (or an ID and three numbers).');
      const r = (k) => [Math.min(...pts.map((p) => p[k])), Math.max(...pts.map((p) => p[k]))];
      const [x, y, z] = [r(0), r(1), r(2)];
      info.textContent = `${pts.length} points over ${formatLength(x[1] - x[0], this.doc.units)} x ${formatLength(y[1] - y[0], this.doc.units)}, heights ${formatLength(z[0], this.doc.units)} to ${formatLength(z[1], this.doc.units)}.`;
    };
    order.addEventListener('change', update);
    unit.addEventListener('change', update);
    update();
    const ok = await openDialogFn({
      title: 'Import Survey Points',
      size: 'sm',
      body: h('div', h('p.dialog-text', f.name), h('label.field', h('span.field-label', 'Columns'), order), h('label.field', h('span.field-label', 'Unit'), unit), h('label.check', centre, h('span', 'Move the points so their middle is at the project origin')), info),
      actions: [
        { label: 'Cancel', value: null },
        { label: 'Make Mesh', primary: true, value: true },
      ],
    });
    if (!ok) return;
    let pts = parseSurveyPoints(text, { order: order.value, unit: unit.value });
    if (pts.length < 3) return this.toast('A mesh needs at least three points.', { kind: 'error' });
    if (centre.checked) pts = centrePoints(pts);
    const imp = this.doc.units.system === 'imperial';
    let el;
    this.commit('Import survey points', () => (el = this.doc.add({ kind: 'topo', points: pts, thickness: imp ? 914.4 : 1000, contour: imp ? 304.8 : 500, materialId: 'mat-earth' })));
    this.select([el.id]);
    this.toast(`Mesh made from ${pts.length} points.`, { kind: 'success' });
  }

  /** Zone Calculation Rules: how much of a room counts where it is low under a roof. */
  areaRulesDialog() {
    const doc = this.doc;
    const units = doc.units;
    const body = h('div');
    const save = (rules) => {
      this.commit('Zone calculation rules', () => doc.update('project', { areaRules: rules }));
      render();
    };
    const render = () => {
      clear(body);
      const rules = areaRules(doc).slice().sort((a, b) => a.below - b.below);
      const rows = rules.map((r, i) => {
        const below = h('input.input.sm', { type: 'text', value: formatLength(r.below, units), 'aria-label': `Rule ${i + 1} height` });
        below.addEventListener('keydown', (e) => e.stopPropagation());
        below.addEventListener('change', () => {
          const v = parseLength(below.value, units);
          if (v > 0) save(rules.map((x, j) => (j === i ? { ...x, below: v } : x)));
          else render();
        });
        const pct = h('input.input.sm', { type: 'number', min: 0, max: 100, step: 5, value: r.percent, 'aria-label': `Rule ${i + 1} percentage` });
        pct.addEventListener('keydown', (e) => e.stopPropagation());
        pct.addEventListener('change', () => save(rules.map((x, j) => (j === i ? { ...x, percent: Math.max(0, Math.min(100, +pct.value || 0)) } : x))));
        return h('tr', h('td', 'Lower than'), h('td', below), h('td', 'counts'), h('td', h('span.lw-in', pct, '%')), h('td', h('button.icon-btn.sm', { type: 'button', 'aria-label': `Remove rule ${i + 1}`, onClick: () => save(rules.filter((_, j) => j !== i)) }, icon('trash', 13))));
      });
      body.append(
        h('table.layers-table', h('tbody', rows.length ? rows : h('tr', h('td', 'No reductions: every part of a room counts in full.')))),
        h('div.inline', { style: { gap: '6px', marginTop: '8px' } },
          h('button.btn.sm', { type: 'button', onClick: () => save([...rules, { below: (rules.at(-1)?.below || 1000) + 500, percent: 50 }]) }, icon('plus', 14), 'Add Rule'),
          h('button.btn.sm', { type: 'button', onClick: () => save([{ below: 1500, percent: 0 }]) }, 'Under 1.5 m: 0 %'),
          h('button.btn.sm', { type: 'button', onClick: () => save([{ below: 1000, percent: 0 }, { below: 2000, percent: 50 }]) }, 'Under 1 m: 0 %, under 2 m: 50 %')),
        h('p.field-hint', 'The Reduced Area of rooms (Properties, schedules, autotext) counts the parts where the clear height under a roof is lower than a threshold only by its percentage. Gross Area runs to the wall centre lines.'),
        zoneRulesSection(this),
      );
    };
    render();
    return openDialogFn({ title: 'Zones', size: 'md', body, actions: [{ label: 'Close', primary: true, value: null }] });
  }

  /** Filter Elements in 3D: the stories the active 3D view shows. */
  filter3dDialog() {
    const view = this.activeView;
    if (view?.kind !== 'view3d') return this.toast('Open a 3D view to filter it.', { kind: 'error' });
    const doc = this.doc;
    const f = view.storyFilter || {};
    const opts = (sel) => [h('option', { value: '' }, 'Any'), ...doc.levels().map((l) => h('option', { value: l.id, selected: l.id === sel }, l.name))];
    const from = h('select.input', { 'aria-label': 'From story' }, opts(f.from));
    const to = h('select.input', { 'aria-label': 'To story' }, opts(f.to));
    const apply = (from0, to0) => {
      this.commit('Filter 3D', () => doc.update(view.id, { storyFilter: from0 || to0 ? { from: from0 || null, to: to0 || null } : null }));
      this.flagsVersion++;
      this.requestRender();
    };
    from.addEventListener('change', () => apply(from.value, to.value));
    to.addEventListener('change', () => apply(from.value, to.value));
    const each = h('div.inline', { style: { gap: '4px', flexWrap: 'wrap' } }, doc.levels().map((l) => h('button.btn.sm', { type: 'button', onClick: () => ((from.value = to.value = l.id), apply(l.id, l.id)) }, `Only ${l.name}`)), h('button.btn.sm', { type: 'button', onClick: () => ((from.value = to.value = ''), apply('', '')) }, 'All Stories'));
    return openDialogFn({
      title: 'Filter Elements in 3D',
      size: 'sm',
      body: h('div', h('div.row2', h('label.field', h('span.field-label', 'From story'), from), h('label.field', h('span.field-label', 'To story'), to)), each, h('p.field-hint', 'Elements show by the story they stand on; doors and windows by their wall. Categories are filtered in Visibility/Graphics.')),
      actions: [{ label: 'Close', primary: true, value: null }],
    });
  }

  cutPlanesDialog() {
    return cutPlanesDialog(this);
  }

  /** Align and Distribute palette-dialog: line up or space the selection by its plan bounding boxes. */
  alignDistributeDialog() {
    const c = this.vc;
    if (!c?.is2D) return this.toast('Open a plan or 2D view to align and distribute.', { kind: 'error' });
    const run = (label, moves) => {
      const live = moves.filter((m) => Math.hypot(m.d[0], m.d[1]) > 0.01);
      if (!live.length) return;
      this.commit(label, () => live.forEach((m) => moveElements(this.doc, [m.id], m.d)));
    };
    const boxes = () => {
      c.sync();
      return [...this.selection].map((id) => ({ id, ...c.bounds.get(id) })).filter((b) => Number.isFinite(b.x0));
    };
    const btn = (label, ic, fn) => h('button.btn.sm', { type: 'button', onClick: () => {
      const bs = boxes();
      if (bs.length < 2) return this.toast('Select two or more elements (three to distribute).', { kind: 'error' });
      fn(bs);
    } }, icon(ic, 14), label);
    const by = h('select.input.sm', { 'aria-label': 'Distribute by' }, h('option', { value: 'gaps' }, 'Equal gaps'), h('option', { value: 'centers' }, 'Equal centre spacing'));
    const lineSpacing = h('input.input.sm.num', { type: 'number', min: 0, step: 10, placeholder: 'fit', 'aria-label': 'Spacing along the line' });
    lineSpacing.addEventListener('keydown', (e) => e.stopPropagation());
    // Special Align / Distribute: the dialog closes, two clicks give the line, then the moves apply.
    const lineThen = (p1, p2, fn) => {
      document.querySelector('dialog[open]')?._close?.(null);
      import('./ui/drafting.js').then(({ PickPointsTool }) => this.setTool(new PickPointsTool(this, { n: 2, title: 'Line', prompts: [p1, p2], done: fn })));
    };
    return openDialogFn({
      title: 'Align and Distribute',
      size: 'sm',
      body: h('div',
        h('h3.dlg-sub', 'Align'),
        h('div.inline', { style: { gap: '6px', flexWrap: 'wrap' } },
          btn('Left', 'align', (bs) => run('Align left', alignMoves(bs, 'left'))),
          btn('Centre', 'align', (bs) => run('Align centre', alignMoves(bs, 'centerX'))),
          btn('Right', 'align', (bs) => run('Align right', alignMoves(bs, 'right'))),
          btn('Bottom', 'align', (bs) => run('Align bottom', alignMoves(bs, 'bottom'))),
          btn('Middle', 'align', (bs) => run('Align middle', alignMoves(bs, 'centerY'))),
          btn('Top', 'align', (bs) => run('Align top', alignMoves(bs, 'top')))),
        h('h3.dlg-sub', 'Distribute'),
        h('label.field', h('span.field-label', 'Spacing'), by),
        h('div.inline', { style: { gap: '6px' } },
          btn('Horizontally', 'array', (bs) => run('Distribute', distributeMoves(bs, 'x', by.value))),
          btn('Vertically', 'array', (bs) => run('Distribute', distributeMoves(bs, 'y', by.value))),
          btn('Along XY', 'array', (bs) => run('Distribute along XY', distributeXYMoves(bs)))),
        h('h3.dlg-sub', 'Special Align and Distribute'),
        h('label.field', h('span.field-label', 'Spacing along the line (mm, empty to fit)'), lineSpacing),
        h('div.inline', { style: { gap: '6px', flexWrap: 'wrap' } },
          btn('Align to a line...', 'align', (bs) => lineThen('Click the start of the line', 'Click the end of the line', ([a, b]) => run('Special align', alignToLineMoves(bs, a, b)))),
          btn('Distribute along a line...', 'array', (bs) => lineThen('Click where the row starts', 'Click where it ends', ([a, b]) => run('Special distribute', alongLineMoves(bs, a, b, +lineSpacing.value > 0 ? { by: 'spacing', spacing: +lineSpacing.value } : {}))))),
        h('p.field-hint', 'Uses each element\'s outline in this view. Doors and windows slide along their walls.')),
      actions: [{ label: 'Close', primary: true, value: null }],
    });
  }

  /** Polygon operations on the selection: the first selected element is changed by the others. */
  polygonOp(op) {
    let res;
    const label = { union: 'Merge polygons', subtract: 'Subtract polygons', intersect: 'Intersect polygons' }[op];
    this.commit(label, () => (res = applyPolygonOp(this.doc, [...this.selection], op)));
    if (res?.error) return this.toast(res.error, { kind: 'error' });
    this.select(res.ids);
  }

  /** Convert Selection: selected lines become walls, slabs, zones or fills. */
  async convertSelectionDialog() {
    const view = this.activeView;
    const els = [...this.selection].map((id) => this.doc.get(id));
    const segs = segmentsOf(els);
    if (!segs.length) return this.toast('Select lines, arcs or splines to convert (for example from an imported DXF).', { kind: 'error' });
    const levelId = view?.levelId || null;
    const to = h('select.input', { 'aria-label': 'Make' },
      h('option', { value: 'wallPairs', disabled: !levelId }, 'Walls from pairs of face lines'),
      h('option', { value: 'walls', disabled: !levelId }, 'Walls along the lines (centre lines)'),
      h('option', { value: 'slabs', disabled: !levelId }, 'Slabs from closed shapes'),
      h('option', { value: 'zones', disabled: !levelId }, 'Zones from closed shapes'),
      h('option', { value: 'fills' }, 'Fills from closed shapes'));
    to.value = levelId ? 'wallPairs' : 'fills';
    const del = h('input', { type: 'checkbox', checked: true });
    const ok = await openDialogFn({
      title: 'Convert Selection',
      size: 'sm',
      body: h('div', h('p.dialog-text', `${segs.length} line piece${segs.length === 1 ? '' : 's'} selected${levelId ? ` on ${this.doc.get(levelId)?.name}` : ''}.`), h('label.field', h('span.field-label', 'Make'), to), h('label.check', del, h('span', 'Delete the lines afterwards')), h('p.field-hint', 'Face lines 50 to 600 mm apart pair up into walls of that thickness, with the nearest wall type; wall ends that nearly meet are joined.')),
      actions: [
        { label: 'Cancel', value: null },
        { label: 'Convert', primary: true, value: true },
      ],
    });
    if (!ok) return;
    let res;
    this.commit('Convert selection', () => {
      res = convertLines(this.doc, segs, to.value, { levelId, viewId: view.id, floorTypeId: this.currentType('floor')?.id });
      if (del.checked && res.ids.length) deleteElements(this.doc, [...new Set(segs.map((s) => s.id))]);
    });
    this.select(res.ids);
    this.toast(res.ids.length ? `Made ${res.ids.length} element${res.ids.length === 1 ? '' : 's'}.${res.skipped.length ? ` ${res.skipped.join('. ')}.` : ''}` : `Nothing made. ${res.skipped.join('. ')}`, { kind: res.ids.length ? 'success' : 'error' });
  }

  /** Fillet/Chamfer: the selected polygons' corners, or two selected lines. */
  async filletDialog() {
    const ids = [...this.selection];
    const units = this.doc.units;
    const mode = h('select.input', { 'aria-label': 'Fillet or chamfer' }, h('option', { value: 'fillet' }, 'Fillet (round)'), h('option', { value: 'chamfer' }, 'Chamfer (bevel)'));
    mode.value = this.settings.filletMode || 'fillet';
    const r = h('input.input', { type: 'text', value: formatLength(this.settings.filletRadius ?? 500, units), 'aria-label': 'Radius or distance' });
    const ok = await openDialogFn({
      title: 'Fillet/Chamfer',
      size: 'sm',
      body: h('div', h('label.field', h('span.field-label', 'Type'), mode), h('label.field', h('span.field-label', 'Radius or distance'), r), h('p.field-hint', 'Applies to every corner of the selected slabs, ceilings, fills and masses, or joins two selected lines. 0 just makes two lines meet.')),
      initialFocus: 'input',
      actions: [
        { label: 'Cancel', value: null },
        { label: 'Apply', primary: true, value: true },
      ],
    });
    if (!ok) return;
    const radius = parseLength(r.value, units);
    if (!Number.isFinite(radius) || radius < 0) return this.toast('Enter a length.', { kind: 'error' });
    this.settings.filletMode = mode.value;
    this.settings.filletRadius = radius;
    let res;
    this.commit(mode.value === 'fillet' ? 'Fillet' : 'Chamfer', () => (res = applyFillet(this.doc, ids, { mode: mode.value, r: radius })));
    if (res?.error) this.toast(res.error, { kind: 'error' });
  }

  /** Trace & Reference on or off in the active view (the story below when there was none). */
  toggleTrace() {
    const id = this.activeViewId;
    if (!id) return;
    const t = this.traces.get(id);
    this.traces.set(id, t ? { ...t, on: !t.on } : { refId: 'below', offset: [0, 0], rotation: 0, on: true });
    this.tracePalette.render();
    this.requestRender();
  }

  fillTypesDialog() {
    return fillTypesDialog(this);
  }

  issuesDialog() {
    return issuesDialog(this);
  }

  classificationDialog() {
    return classificationDialog(this);
  }

  masterLayoutsDialog() {
    return masterLayoutsDialog(this);
  }

  /** The Object Library palette; Place starts the Object tool with the chosen type. */
  complianceDialog() {
    return complianceDialog(this);
  }

  archicadLibraryDialog() {
    return archicadLibraryDialog(this);
  }

  gdlObjectsDialog(opts) {
    return gdlObjectsDialog(this, opts);
  }

  libraryDialog() {
    return libraryDialog(this, { startPlacing: () => this.run('component') });
  }

  profileManagerDialog(id) {
    return dialogs.profileManagerDialog(this, id);
  }

  collisionDialog() {
    return dialogs.collisionDialog(this);
  }

  findSelectDialog() {
    return dialogs.findSelectDialog(this);
  }

  gridSystemDialog() {
    return dialogs.gridSystemDialog(this);
  }

  cloneFolderDialog(id) {
    return dialogs.cloneFolderDialog(this, id);
  }

  zoneCategoriesDialog() {
    return dialogs.zoneCategoriesDialog(this);
  }
  levelsDialog() {
    return dialogs.levelsDialog(this);
  }
  typesDialog() {
    return dialogs.typesDialog(this);
  }
  snapsDialog() {
    return dialogs.snapsDialog(this);
  }
  purgeDialog() {
    return dialogs.purgeDialog(this);
  }
  shortcutsDialog() {
    return options.shortcutsDialog(this);
  }

  optionsDialog(tab) {
    return options.optionsDialog(this, tab);
  }

  /** Open a plan of the elements' level, select them and zoom to them. */
  showElements(ids) {
    const live = ids.filter((id) => this.doc.has(id));
    const first = this.doc.get(live[0]);
    const plan = first?.levelId && this.doc.all('plan').find((p) => p.levelId === first.levelId && !p.calloutOf);
    if (plan && this.activeView?.levelId !== first.levelId) this.openView(plan.id);
    this.select(live);
    this.vc?.zoomExtents?.(true, new Set(live));
  }

  /** A change made by Claude Code through the bridge: logged in the assistant panel, or a toast. */
  assistantStep(name, input, result) {
    const text = describeStep(name, input, result);
    if (this.assistant && !this.shell.assist.hidden) this.assistant.logStep(text, !!result?.error);
    else toast(`Claude Code: ${text}`, result?.error ? { kind: 'error' } : undefined);
  }

  /** Show or hide the assistant panel (created the first time). */
  toggleAssistant(show) {
    const pane = this.shell.assist;
    const open = show ?? pane.hidden;
    if (open && !this.assistant) this.assistant = new Assistant(this, pane);
    pane.hidden = !open;
    this.shell.assistBtn.setAttribute('aria-pressed', String(open));
    if (open) setTimeout(() => this.assistant?.input?.focus(), 0);
    this.viewport.resize();
  }

  elementOverrideDialog() {
    return dialogs.elementOverrideDialog(this);
  }

  /** User preferences that live outside the settings object. */
  applyPreferences() {
    applyShortcuts(this.settings.shortcuts || {});
    setTooltipMode(this.settings.tooltips);
    applyUiPrefs(this);
    this.workspace?.apply(!!this.settings.workspaceAc);
  }
  helpDialog() {
    return dialogs.helpDialog(this);
  }
  aboutDialog() {
    return dialogs.aboutDialog(this);
  }
  planViewDialog() {
    return dialogs.planViewDialog(this);
  }
  areaPlanDialog() {
    return dialogs.areaPlanDialog(this);
  }
  revisionsDialog() {
    return dialogs.revisionsDialog(this);
  }
  changeManagerDialog() {
    return dialogs.changeManagerDialog(this);
  }
  filtersDialog() {
    return dialogs.filtersDialog(this);
  }
  templatesDialog() {
    return dialogs.templatesDialog(this);
  }
  startingViewDialog() {
    return dialogs.startingViewDialog(this);
  }

  async templateFromView() {
    const v = this.activeView;
    if (!v || !['plan', 'areaPlan', 'ceilingPlan', 'view3d', 'elevation', 'section'].includes(v.kind)) return this.toast('Open a plan, 3D view, elevation or section first.', { kind: 'error' });
    const names = this.doc.all('viewTemplate').map((t) => t.name);
    const name = await promptDialog('New View Template', 'Template name', uniqueName(names, `${v.name} Template`), { okLabel: 'Create', validate: (x) => (!x ? 'Enter a name.' : names.includes(x) ? 'A template with this name exists.' : null) });
    if (!name) return;
    this.commit('New view template', () => this.doc.add({ kind: 'viewTemplate', name, viewKind: templateKindOf(v.kind), settings: templateSettings(v) }));
    this.toast(`Created the view template "${name}". Assign it to views in their properties, or in View Templates.`, { kind: 'success' });
  }
  findReplaceDialog() {
    return dialogs.findReplaceDialog(this);
  }
  newScheduleDialog(category) {
    return dialogs.newScheduleDialog(this, category);
  }
  newSheet() {
    return dialogs.newSheet(this);
  }
  placeViewDialog(viewId) {
    return dialogs.placeViewDialog(this, viewId);
  }
  exportSchedule(id) {
    return files.exportScheduleCSV(this, id);
  }
  exportScheduleXLSX(id) {
    return files.exportSchedulesXLSX(this, id);
  }
  importDXF() {
    return files.importDXF(this);
  }
  scheduleFieldsDialog(id) {
    return dialogs.scheduleFieldsDialog(this, id);
  }
  scheduleFilterDialog(id) {
    return dialogs.scheduleFilterDialog(this, id);
  }
}

