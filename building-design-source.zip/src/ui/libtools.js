/**
 * Library commands: Save Selection as Object / Door / Window / Stair Tread /
 * Riser / Railing Post / Panel / Label / Drawing Title / MEP Part, Save
 * GDL, and the Library Developer tools (Place All Objects, Test All
 * Library Parts, Search Callers, Check for Missing Attributes, XML export
 * and import, Import 3DS as GDL Object).
 */
import { connectorsFromSelection } from '../core/mepnet.js';
import { h } from './dom.js';
import { openDialog, promptDialog } from './dialog.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { uniqueName } from '../core/ops.js';
import { materialOf } from '../core/plan.js';
import { MODEL_KINDS } from '../core/scene.js';
import { gdlFromMeshes, gdl2DFrom, partType, gdlText, SAVE_TARGETS } from '../core/savegdl.js';
import { placeAllPositions, testLibraryParts, searchCallers, missingAttributes, libraryXML, placedXML, readPlacedXML, placeFromXML, read3DS, gdlFrom3DS, gdlFromGLTF, materialForGLTF } from '../core/libtools.js';

const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const LABELS = { object: 'Object', door: 'Door', window: 'Window', stairTread: 'Stair Tread', stairRiser: 'Stair Riser', railingPost: 'Railing Post', railingPanel: 'Railing Panel', label: 'Label', drawingTitle: 'Drawing Title', mepPart: 'MEP Part' };

/** The selection's 3D bodies with their materials, for GDL. */
function selectionMeshes(app) {
  const out = [];
  for (const id of app.selection) {
    const el = app.doc.get(id);
    if (!el || !MODEL_KINDS.includes(el.kind)) continue;
    const mesh = app.scene.mesh(el);
    if (mesh?.pos?.length) out.push({ mesh, materialId: materialOf(app.doc, el)?.id || null });
  }
  return out;
}

/** The selection's 2D drawing: detail lines, fills and texts in the active view. */
function selection2D(app) {
  const g = { lines: [], polys: [], texts: [] };
  for (const id of app.selection) {
    const el = app.doc.get(id);
    if (!el) continue;
    if (el.kind === 'detailLine' && el.a && el.b) g.lines.push({ a: el.a, b: el.b });
    else if (el.kind === 'region' && el.boundary) g.polys.push({ pts: el.boundary, closed: true });
    else if (el.kind === 'text') g.texts.push({ at: el.at, text: el.text, size: el.size });
    else if (el.kind === 'spline' && el.path) g.polys.push({ pts: el.path, closed: false });
  }
  return g;
}

export async function saveSelectionAs(app, target) {
  const t = SAVE_TARGETS[target] || SAVE_TARGETS.object;
  let g;
  try {
    g = t.twoD ? gdl2DFrom(selection2D(app)) : gdlFromMeshes(selectionMeshes(app), { opening: target === 'door' || target === 'window' });
  } catch (e) {
    return app.toast(e.message, { kind: 'error' });
  }
  if (!g) return app.toast(t.twoD ? 'Select the lines, fills and texts to save in a view.' : 'Select the 3D elements to save.', { kind: 'error' });
  const names = app.doc.filter((x) => x.kind === t.kind).map((x) => x.name);
  const name = await promptDialog(`Save Selection as ${LABELS[target]}`, 'Name', uniqueName(names, `My ${LABELS[target]}`));
  if (!name) return;
  const type = partType(target, name, g);
  // A MEP part gets connectors at the open ends of the selected runs (from the selection's lowest corner).
  if (target === 'mepPart') {
    const ms = selectionMeshes(app).map((x) => x.mesh.bounds).filter(Boolean);
    const origin = [Math.min(...ms.map((b) => b.min[0])), Math.min(...ms.map((b) => b.min[1])), Math.min(...ms.map((b) => b.min[2]))];
    const conns = connectorsFromSelection(app.doc, [...app.selection], origin);
    if (conns.length) type.mepConnectors = conns;
  }
  let added;
  app.commit(`Save selection as ${LABELS[target].toLowerCase()}`, () => (added = app.doc.add(type)));
  app.toast(`${added.name} saved as a GDL ${LABELS[target].toLowerCase()} (${g.triangles ? plural(g.triangles, 'face') : 'a 2D symbol'}). Find it in the library and in GDL Objects.`, { kind: 'success' });
  return added;
}

export function saveGdl(app) {
  let g;
  try {
    g = gdlFromMeshes(selectionMeshes(app));
  } catch (e) {
    return app.toast(e.message, { kind: 'error' });
  }
  if (!g) return app.toast('Select the 3D elements to save as GDL.', { kind: 'error' });
  download(new Blob([gdlText('Selection', g)], { type: 'text/plain' }), safeFileName(`${app.doc.project?.name || 'selection'}.gdl`));
}

export function placeAllObjects(app) {
  const lv = app.activeView?.levelId || app.doc.levels()[0]?.id;
  const pos = placeAllPositions(app.doc);
  if (!pos.length) return app.toast('There are no objects in the project library.', { kind: 'error' });
  app.commit('Place all objects', () => pos.forEach((p) => app.doc.add({ kind: 'component', typeId: p.typeId, levelId: lv, at: p.at, rotation: 0 })));
  app.zoomFit?.();
  app.toast(`Placed ${plural(pos.length, 'object')} in a grid.`, { kind: 'success' });
}

const table = (head, rows) => h('div', { style: { maxHeight: '55vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', ...head.map((x) => h('th', x)))), h('tbody', ...rows)));

export function testAllParts(app) {
  const res = testLibraryParts(app.doc);
  if (!res.length) return app.toast('There are no GDL parts in the project.', { kind: 'error' });
  const bad = res.filter((r) => !r.ok);
  const body = h('div', h('p', `${plural(res.length, 'part')} run: ${res.length - bad.length} draw, ${bad.length} with problems.`), table(['Part', 'Faces', 'Lines', 'Problem'], res.map((r) => h('tr', h('td', r.name), h('td', String(r.triangles)), h('td', String(r.lines)), h('td', r.error || (!r.ok ? 'Draws nothing' : r.unknown.length ? `Skipped: ${r.unknown.slice(0, 4).join(', ')}` : ''))))));
  return openDialog({ title: 'Test All Library Parts', body, size: 'lg', actions: [{ label: 'Close', value: null }] });
}

export async function searchCallersDialog(app) {
  const name = await promptDialog('Search Callers', 'Macro name');
  if (!name) return;
  const res = searchCallers(app.doc, name);
  const body = res.length ? table(['Part', 'Calls'], res.map((r) => h('tr', h('td', r.name), h('td', String(r.calls))))) : h('p', `No part in the project calls "${name}".`);
  return openDialog({ title: `Callers of ${name}`, body, actions: [{ label: 'Close', value: null }] });
}

export function missingAttributesDialog(app) {
  const res = missingAttributes(app.doc);
  const body = res.length ? table(['Part', 'Materials it names that the project lacks'], res.map((r) => h('tr', h('td', r.name), h('td', r.missing.join(', '))))) : h('p', 'Every material the GDL parts name is in the project.');
  return openDialog({ title: 'Check for Missing Attributes', body, size: 'lg', actions: [{ label: 'Close', value: null }] });
}

const save = (text, name) => download(new Blob([text], { type: 'application/xml' }), safeFileName(name));

export const exportLibraryXML = (app) => save(libraryXML(app.doc), `${app.doc.project?.name || 'library'} - library.xml`);
export const exportPlacedXML = (app) => save(placedXML(app.doc), `${app.doc.project?.name || 'project'} - objects.xml`);
export function exportViewXML(app) {
  const lv = app.activeView?.levelId;
  if (!lv) return app.toast('Open a floor plan first.', { kind: 'error' });
  save(placedXML(app.doc, { levelId: lv }), `${app.activeView.name} - objects.xml`);
}

function pickFile(accept, then) {
  const input = h('input', { type: 'file', accept });
  input.addEventListener('change', () => input.files?.[0] && then(input.files[0]));
  input.click();
}

export function importPlaceXML(app) {
  pickFile('.xml', async (file) => {
    const objs = readPlacedXML(await file.text());
    const lv = app.activeView?.levelId || app.doc.levels()[0]?.id;
    const { components, missing } = placeFromXML(app.doc, objs, lv);
    app.commit('Import and place objects', () => components.forEach((c) => app.doc.add(c)));
    app.toast(`Placed ${plural(components.length, 'object')}${missing.length ? `; not in this project: ${missing.slice(0, 3).join(', ')}${missing.length > 3 ? '…' : ''}` : ''}.`, { kind: components.length ? 'success' : 'error' });
  });
}

export function import3DS(app) {
  pickFile('.3ds', async (file) => {
    const unit = await new Promise((resolve) => {
      const sel = h('select.input', { 'aria-label': 'Units' }, ...[['1', 'Millimetres'], ['10', 'Centimetres'], ['1000', 'Metres'], ['25.4', 'Inches']].map(([v, l]) => h('option', { value: v, selected: v === '1000' }, l)));
      openDialog({ title: '3DS to GDL Conversion Options', body: h('label.field', h('span.field-label', 'The file is in'), sel), actions: [{ label: 'Cancel', value: null }, { label: 'Import', primary: true, value: 'ok' }] }).then((r) => resolve(r === 'ok' ? +sel.value : null));
    });
    if (!unit) return;
    let meshes;
    try {
      meshes = read3DS(await file.arrayBuffer(), { scale: unit });
    } catch (e) {
      return app.toast(`Could not read ${file.name}: ${e.message}`, { kind: 'error' });
    }
    let type;
    try {
      type = gdlFrom3DS(meshes, file.name.replace(/\.3ds$/i, ''));
    } catch (e) {
      return app.toast(e.message, { kind: 'error' });
    }
    if (!type) return app.toast('No meshes in that file.', { kind: 'error' });
    let added;
    app.commit('Import 3DS as GDL object', () => (added = app.doc.add(type)));
    app.placeType?.(added, 'component');
    app.toast(`${added.name}: ${meshes.length} mesh${meshes.length === 1 ? '' : 'es'} as a GDL object. Click to place it.`, { kind: 'success' });
  });
}

/**
 * A glTF model (.glb from Blender, SketchUp, ...) as a GDL object in the project library, its materials as project
 * materials (one per name and colour), then placed with a click.
 */
export function importGLTF(app, given) {
  const go = async (file) => {
    const { readGLTF } = await import('../io/gltf.js');
    let meshes;
    try {
      meshes = readGLTF(await file.arrayBuffer());
    } catch (e) {
      return app.toast(`Could not read ${file.name}: ${e.message}`, { kind: 'error' });
    }
    if (!meshes.length) return app.toast('No meshes in that file.', { kind: 'error' });
    let added;
    try {
      app.commit('Import glTF as GDL object', () => {
        const ids = new Map();
        const idOf = (m) => {
          const k = `${m.name}|${m.color}`;
          if (!ids.has(k)) {
            const r = materialForGLTF(app.doc, m);
            ids.set(k, r.id || app.doc.add(r.add).id);
          }
          return ids.get(k);
        };
        const type = gdlFromGLTF(meshes, file.name.replace(/\.(glb|gltf)$/i, ''), idOf);
        if (!type) throw new Error('No meshes in that file.');
        added = app.doc.add(type);
      });
    } catch (e) {
      return app.toast(e.message, { kind: 'error' });
    }
    const textured = meshes.some((m) => m.material.textured);
    app.placeType?.(added, 'component');
    app.toast(`${added.name}: ${meshes.length} mesh${meshes.length === 1 ? '' : 'es'} as a GDL object (${Math.round(added.width)} x ${Math.round(added.depth)} x ${Math.round(added.height)} mm)${textured ? '; image textures are taken as their base colour' : ''}. Click to place it.`, { kind: 'success' });
    return { name: added.name, typeId: added.id, meshes: meshes.length, size: [added.width, added.depth, added.height] };
  };
  if (given) return go(given);
  pickFile('.glb,.gltf', go);
}
