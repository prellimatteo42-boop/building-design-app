/**
 * Curtain wall commands: Copy Cell Pattern, Create Common Frames, Junction,
 * Join Wall(s) to Curtain Wall, Accessory and ArchiGlazing (the logic is in
 * core/curtainmore.js).
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { curtainGrid } from '../core/build3d.js';
import { wallAxis, verticalExtent } from '../core/model.js';
import { curtainOf, copyCellPattern, joinCurtainEnds, wallsToCurtain, CW_ACCESSORIES, glazedRoofFrom, GLAZING_DEFAULTS } from '../core/curtainmore.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const num = (value, label, extra = {}) => {
  const i = h('input.input', { type: 'number', value, 'aria-label': label, ...extra });
  i.addEventListener('keydown', (e) => e.stopPropagation());
  return i;
};
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const curtains = (app) => [...app.selection].map((id) => app.doc.get(id)).filter((w) => curtainOf(app.doc, w));

export function gridOf(doc, w) {
  const ax = wallAxis(doc, w);
  const { base, top } = verticalExtent(doc, w);
  return curtainGrid(ax.length, top - base, doc.get(w.typeId), w);
}

export function copyCellPatternDialog(app) {
  const [w] = curtains(app);
  if (!w) return app.toast('Select a curtain wall first.', { kind: 'error' });
  const { nu, nv } = gridOf(app.doc, w);
  const i0 = num(1, 'From column', { min: 1, max: nu });
  const i1 = num(1, 'To column', { min: 1, max: nu });
  const j0 = num(1, 'From row', { min: 1, max: nv });
  const j1 = num(nv, 'To row', { min: 1, max: nv });
  const along = h('input', { type: 'checkbox', checked: true });
  const up = h('input', { type: 'checkbox', checked: false });
  const body = h(
    'div',
    h('p.field-hint', `This curtain wall has ${nu} columns and ${nv} rows of cells (counted from the wall's start and from the bottom). The cells of the block are repeated with their panels and removed frames.`),
    h('div.row2', field('From column', i0), field('To column', i1)),
    h('div.row2', field('From row', j0), field('To row', j1)),
    h('div.inline', { style: { gap: '16px' } }, h('label.check', along, 'Repeat along the wall'), h('label.check', up, 'Repeat up the wall')),
  );
  return openDialog({ title: 'Copy Cell Pattern', body, actions: [{ label: 'Cancel', value: null }, { label: 'Copy', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const patch = copyCellPattern(w, nu, nv, { i0: +i0.value - 1, i1: +i1.value - 1, j0: +j0.value - 1, j1: +j1.value - 1 }, { alongU: along.checked, alongV: up.checked });
    app.commit('Copy cell pattern', () => app.doc.update(w.id, patch));
  });
}

export function commonFrames(app, junction = false) {
  const ws = curtains(app);
  if (ws.length < 2) return app.toast('Select two or more curtain walls that meet.', { kind: 'error' });
  let n = 0;
  app.commit(junction ? 'Curtain wall junction' : 'Create common frames', () => (n = joinCurtainEnds(app.doc, ws.map((w) => w.id), (w) => gridOf(app.doc, w), { junction })));
  app.toast(n ? `${plural(n, 'joint')} ${junction ? 'joined (corner posts where they meet at an angle)' : 'now share one frame'}.` : 'None of the selected curtain walls meet end to end.', { kind: n ? 'success' : 'error' });
}

export function joinWallsToCurtain(app) {
  const sel = [...app.selection].map((id) => app.doc.get(id)).filter((el) => el?.kind === 'wall');
  const cws = sel.filter((w) => curtainOf(app.doc, w));
  const walls = sel.filter((w) => !curtainOf(app.doc, w));
  if (!cws.length || !walls.length) return app.toast('Select the curtain wall and the walls that run into it.', { kind: 'error' });
  const patches = wallsToCurtain(app.doc, walls.map((w) => w.id), cws.map((w) => w.id));
  app.commit('Join walls to curtain wall', () => patches.forEach((p) => app.doc.update(p.id, p.patch)));
  app.toast(patches.length ? `${plural(patches.length, 'wall end')} now stop at the curtain wall.` : 'No selected wall runs into the curtain wall.', { kind: patches.length ? 'success' : 'error' });
}

export function accessoryDialog(app) {
  const ws = curtains(app);
  if (!ws.length) return app.toast('Select the curtain walls to put the accessory on.', { kind: 'error' });
  const cur = ws[0].cwAccessory || {};
  const kind = h('select.input', { 'aria-label': 'Accessory' }, h('option', { value: '' }, 'None'), ...CW_ACCESSORIES.map((a) => h('option', { value: a.value, selected: a.value === cur.kind }, a.label)));
  const info = () => CW_ACCESSORIES.find((a) => a.value === kind.value) || CW_ACCESSORIES[0];
  const depth = num(cur.depth || info().depth, 'Depth (mm)');
  const width = num(cur.width || info().width, 'Thickness (mm)');
  const spacing = num(cur.spacing || 250, 'Louvre spacing (mm)');
  kind.addEventListener('change', () => ((depth.value = info().depth), (width.value = info().width)));
  const body = h('div', field('Accessory', kind), h('div.row2', field('Depth out of the face (mm)', depth), field('Thickness (mm)', width)), field('Louvre spacing (mm)', spacing));
  return openDialog({ title: 'Curtain Wall Accessory', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const acc = kind.value ? { kind: kind.value, depth: +depth.value, width: +width.value, spacing: +spacing.value } : null;
    app.commit('Curtain wall accessory', () => ws.forEach((w) => app.doc.update(w.id, { cwAccessory: acc })));
  });
}

export function archiGlazing(app) {
  const roofs = [...app.selection].map((id) => app.doc.get(id)).filter((el) => el?.kind === 'roof');
  if (!roofs.length) return app.toast('Select the roofs to turn into glazed roofs.', { kind: 'error' });
  const sp = num(GLAZING_DEFAULTS.spacing, 'Rafter spacing (mm)');
  const tr = num(GLAZING_DEFAULTS.transoms, 'Transom spacing (mm, 0 for none)');
  const bw = num(GLAZING_DEFAULTS.barWidth, 'Bar width (mm)');
  const bd = num(GLAZING_DEFAULTS.barDepth, 'Bar depth (mm)');
  const body = h('div', h('div.row2', field('Rafter spacing (mm)', sp), field('Transom spacing (mm)', tr, '0 for none')), h('div.row2', field('Bar width (mm)', bw), field('Bar depth (mm)', bd)), h('p.field-hint', 'Each roof becomes glass with aluminium rafters up the slope, transoms across and a frame round the edge (Archicad\'s ArchiGlazing).'));
  return openDialog({ title: 'ArchiGlazing', body, actions: [{ label: 'Cancel', value: null }, { label: 'Create', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const ids = [];
    app.commit('ArchiGlazing', () => {
      for (const roof of roofs) {
        ids.push(app.doc.add(glazedRoofFrom(roof, { spacing: +sp.value || 900, transoms: +tr.value || 0, barWidth: +bw.value || 60, barDepth: +bd.value || 120 })).id);
        app.doc.remove(roof.id);
      }
    });
    app.select(ids);
    app.toast(`${plural(ids.length, 'glazed roof')} made.`, { kind: 'success' });
  });
}
