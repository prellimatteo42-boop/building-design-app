/**
 * MEP commands: Create Openings From Selection, duct and pipe accessories,
 * flexible segments, the Duct Size and Hydronics Optimizers, hydronic and
 * electrical settings, and Convert Selection to Equipment.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { formatLength, parseLength } from '../core/units.js';
import { MEP_KINDS } from '../core/mep.js';
import { createMepOpenings, removeMepOpenings } from '../core/mepopenings.js';
import { ACCESSORIES, flexBetween, ductSizes, pipeSizes, applySizes, settingsOf, HYDRONIC_DEFAULTS, DUCT_SIZING_DEFAULTS, ELECTRICAL_DEFAULTS, FLUIDS, EQUIPMENT_CATEGORIES, convertToEquipment } from '../core/mepparts.js';
import { runLength } from '../core/mepnet.js';

const stop = (i) => (i.addEventListener('keydown', (e) => e.stopPropagation()), i);
const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const num = (value, label, step = 1) => stop(h('input.input', { type: 'number', step, value, 'aria-label': label }));
const select = (items, cur, label) => h('select.input', { 'aria-label': label }, ...items.map((it) => h('option', { value: it.value, selected: it.value === cur }, it.label)));
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const selected = (app, kinds) => [...app.selection].map((id) => app.doc.get(id)).filter((el) => el && kinds.includes(el.kind));

export function createOpenings(app) {
  const runs = selected(app, MEP_KINDS);
  const u = app.doc.units;
  const o = app.toolOptions('mepOpenings', { clearance: 50 });
  const cl = stop(h('input.input', { type: 'text', value: formatLength(o.clearance, u), 'aria-label': 'Clearance' }));
  const body = h('div', field('Clearance all round', cl), h('p.field-hint', runs.length ? `Openings for the ${plural(runs.length, 'selected run')}.` : 'Nothing selected: openings for every duct, pipe, cable tray and conduit. Running it again replaces the openings it made.'));
  return openDialog({ title: 'Create Openings From Selection', body, actions: [{ label: 'Cancel', value: null }, { label: 'Create', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const c = parseLength(cl.value, u);
    o.clearance = Number.isFinite(c) && c >= 0 ? c : 50;
    let res;
    app.commit('Create openings from selection', () => (res = createMepOpenings(app.doc, runs.length ? runs.map((x) => x.id) : null, { clearance: o.clearance })));
    app.toast(res.walls + res.slabs ? `Openings: ${plural(res.walls, 'wall opening')}, ${plural(res.slabs, 'slab hole')}.` : 'No run passes through a wall or a slab.', { kind: res.walls + res.slabs ? 'success' : 'error' });
  });
}

export function removeOpenings(app) {
  const runs = selected(app, MEP_KINDS);
  let n = 0;
  app.commit('Remove MEP openings', () => (n = removeMepOpenings(app.doc, runs.length ? new Set(runs.map((x) => x.id)) : null)));
  app.toast(`Removed ${plural(n, 'MEP opening')}.`);
}

/** Duct / Pipe Accessory: one accessory on each selected run, at a distance from its start (default: the middle). */
export function addAccessory(app, family) {
  const kinds = family === 'pipe' ? ['pipe'] : ['duct'];
  const runs = selected(app, kinds);
  if (!runs.length) return app.toast(`Select the ${family}s to put the accessory on.`, { kind: 'error' });
  const o = app.toolOptions(`${family}Accessory`, { accessory: ACCESSORIES[family][0].value, at: 50 });
  const kind = select(ACCESSORIES[family], o.accessory, 'Accessory');
  const at = num(o.at, 'Position along the run (%)');
  const body = h('div', h('div.row2', field('Accessory', kind), field('Position along the run (%)', at)), h('p.field-hint', `On ${plural(runs.length, `selected ${family}`)}. It moves and goes with its run.`));
  return openDialog({ title: family === 'pipe' ? 'Pipe Accessory' : 'Duct Accessory', body, actions: [{ label: 'Cancel', value: null }, { label: 'Place', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    o.accessory = kind.value;
    o.at = Math.max(0, Math.min(100, +at.value || 50));
    const ids = [];
    app.commit(family === 'pipe' ? 'Pipe accessory' : 'Duct accessory', () => {
      for (const run of runs) ids.push(app.doc.add({ kind: 'mepAccessory', hostId: run.id, levelId: run.levelId, accessory: o.accessory, t: Math.round((runLength(app.doc, run) * o.at) / 100) }).id);
    });
    app.select(ids);
    app.toast(`Placed ${plural(ids.length, 'accessory')}.`, { kind: 'success' });
  });
}

/** Duct / Pipe Flexible Segment between the two selected elements (runs, or a run and a terminal). */
export function addFlexSegment(app, family) {
  const els = [...app.selection].map((id) => app.doc.get(id)).filter((el) => el && (MEP_KINDS.includes(el.kind) || el.kind === 'component'));
  if (els.length !== 2) return app.toast(`Select the two ${family === 'pipe' ? 'pipes' : 'ducts'} (or a run and a terminal) to join with a flexible segment.`, { kind: 'error' });
  const f = flexBetween(app.doc, els[0], els[1], family);
  if (!f) return app.toast('Those two already meet.', { kind: 'error' });
  let id;
  app.commit(family === 'pipe' ? 'Pipe flexible segment' : 'Duct flexible segment', () => (id = app.doc.add(f).id));
  app.select([id]);
}

function sizesTable(rows, cols) {
  return h(
    'div',
    { style: { maxHeight: '45vh', overflow: 'auto' } },
    h('table.vg-table', h('thead', h('tr', ...cols.map((c) => h('th', c[0])))), h('tbody', ...rows.map((r) => h('tr', ...cols.map((c) => h('td', c[1](r))))))),
  );
}

export function ductSizeOptimizer(app) {
  const ids = selected(app, ['duct']).map((d) => d.id);
  const o = settingsOf(app.doc.project, 'ductSizing', DUCT_SIZING_DEFAULTS);
  const v = num(o.maxVelocity, 'Maximum velocity (m/s)', 0.5);
  const q = num(o.terminalFlow, 'Flow per air terminal (m³/h)', 10);
  const step = num(o.step, 'Size step (mm)', 10);
  const round = h('input', { type: 'checkbox', checked: !!o.round });
  const out = h('div');
  let sizes = [];
  const calc = () => {
    const opts = { maxVelocity: +v.value || 5, terminalFlow: +q.value || 150, step: +step.value || 50, round: round.checked };
    sizes = ductSizes(app.doc, ids.length ? ids : null, opts);
    out.replaceChildren(
      sizes.length
        ? sizesTable(sizes, [
            ['Duct', (r) => app.doc.get(r.id)?.mark || r.id.slice(-5)],
            ['Flow m³/h', (r) => String(r.flow)],
            ['Size mm', (r) => (r.size.diameter ? `Ø ${r.size.diameter}` : `${r.size.width} × ${r.size.height}`)],
            ['m/s', (r) => String(r.velocity)],
            ['Pa/m', (r) => String(r.drop)],
          ])
        : h('p.field-hint', 'No duct network with air terminals (or no flow): connect diffusers to the ducts, or give the terminals a flow.'),
    );
    return opts;
  };
  for (const i of [v, q, step, round]) i.addEventListener('change', calc);
  calc();
  const body = h('div', h('div.row2', field('Maximum velocity (m/s)', v), field('Flow per air terminal (m³/h)', q, 'Used when a terminal has no flow of its own')), h('div.row2', field('Size step (mm)', step), h('label.check', { style: { alignSelf: 'end' } }, round, 'Round ducts')), out);
  return openDialog({ title: 'Duct Size Optimizer', body, size: 'lg', actions: [{ label: 'Cancel', value: null }, { label: 'Apply sizes', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const opts = calc();
    app.commit('Duct size optimizer', () => {
      app.doc.update('project', { ductSizing: opts });
      applySizes(app.doc, sizes);
    });
    app.toast(`Sized ${plural(sizes.length, 'duct')}.`, { kind: 'success' });
  });
}

export function hydronicsOptimizer(app) {
  const ids = selected(app, ['pipe']).map((d) => d.id);
  const s = settingsOf(app.doc.project, 'hydronics', HYDRONIC_DEFAULTS);
  const sizes = pipeSizes(app.doc, ids.length ? ids : null, s);
  const body = h(
    'div',
    h('p.field-hint', `${FLUIDS[s.fluid]?.label || 'Water'}, ${s.supply}/${s.return} °C, at most ${s.maxVelocity} m/s and ${s.maxDrop} Pa/m (Hydronic System Settings). Terminal outputs from their Power (W), else 1500 W.`),
    sizes.length
      ? sizesTable(sizes, [
          ['Pipe', (r) => app.doc.get(r.id)?.mark || r.id.slice(-5)],
          ['Flow l/h', (r) => String(r.flow)],
          ['Inside Ø mm', (r) => String(r.diameter)],
          ['m/s', (r) => String(r.velocity)],
          ['Pa/m', (r) => String(r.drop)],
        ])
      : h('p.field-hint', 'No hydronic pipe network with terminals: draw pipes on the Hydronic Supply system to radiators or fan coils, or select pipes.'),
  );
  return openDialog({ title: 'Hydronics Optimizer', body, size: 'lg', actions: [{ label: 'Cancel', value: null }, { label: 'Apply sizes', primary: true, value: 'ok', onClick: () => (sizes.length ? 'ok' : false) }] }).then((r) => {
    if (r !== 'ok') return;
    app.commit('Hydronics optimizer', () => applySizes(app.doc, sizes));
    app.toast(`Sized ${plural(sizes.length, 'pipe')}.`, { kind: 'success' });
  });
}

function settingsDialog(app, { title, key, defaults, fields, label }) {
  const s = settingsOf(app.doc.project, key, defaults);
  const inputs = fields.map((f) => [f, f.options ? select(f.options, s[f.key], f.label) : num(s[f.key], f.label, f.step || 1)]);
  const rows = [];
  for (let i = 0; i < inputs.length; i += 2) rows.push(h('div.row2', ...inputs.slice(i, i + 2).map(([f, i2]) => field(f.label, i2, f.hint))));
  return openDialog({ title, body: h('div', ...rows), actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const next = Object.fromEntries(inputs.map(([f, i]) => [f.key, f.options ? i.value : +i.value]));
    app.commit(label, () => app.doc.update('project', { [key]: { ...s, ...next } }));
  });
}

export const hydronicSettings = (app) =>
  settingsDialog(app, {
    title: 'Hydronic System Settings',
    key: 'hydronics',
    defaults: HYDRONIC_DEFAULTS,
    label: 'Hydronic settings',
    fields: [
      { key: 'fluid', label: 'Fluid', options: Object.entries(FLUIDS).filter(([k]) => k !== 'air').map(([value, f]) => ({ value, label: f.label })) },
      { key: 'maxVelocity', label: 'Maximum velocity (m/s)', step: 0.1 },
      { key: 'supply', label: 'Supply temperature (°C)' },
      { key: 'return', label: 'Return temperature (°C)' },
      { key: 'maxDrop', label: 'Maximum friction loss (Pa/m)', step: 10 },
    ],
  });

export const electricalSettings = (app) =>
  settingsDialog(app, {
    title: 'Electrical Project Settings',
    key: 'electrical',
    defaults: ELECTRICAL_DEFAULTS,
    label: 'Electrical settings',
    fields: [
      { key: 'voltage', label: 'Single-phase voltage (V)' },
      { key: 'threePhaseVoltage', label: 'Three-phase voltage (V)' },
      { key: 'frequency', label: 'Frequency (Hz)' },
      { key: 'phases', label: 'Default phases', options: [{ value: 1, label: 'Single phase' }, { value: 3, label: 'Three phase' }].map((o) => ({ ...o, value: String(o.value) })) },
      { key: 'powerFactor', label: 'Power factor', step: 0.01 },
      { key: 'maxDrop', label: 'Maximum voltage drop (%)', step: 0.5 },
    ],
  });

export function convertEquipment(app) {
  const comps = selected(app, ['component']);
  if (!comps.length) return app.toast('Select the objects to turn into MEP equipment.', { kind: 'error' });
  const cat = select(EQUIPMENT_CATEGORIES, 'mechanical', 'Equipment');
  const body = h('div', field('Equipment', cat, 'Runs of that kind connect to them; they show in the MEP System Browser.'));
  return openDialog({ title: 'Convert Selection to Equipment', body, actions: [{ label: 'Cancel', value: null }, { label: 'Convert', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    let n = 0;
    app.commit('Convert to equipment', () => (n = convertToEquipment(app.doc, comps.map((c) => c.id), cat.value)));
    app.toast(`${plural(n, 'object')} now MEP equipment.`, { kind: 'success' });
  });
}
