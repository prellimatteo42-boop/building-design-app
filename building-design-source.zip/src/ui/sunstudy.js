/**
 * Sun Study (Document menu), as Archicad's: the active 3D view with its
 * shadows at a series of times on a date, as frames and one contact sheet
 * with each frame's time and sun position, to save as pictures.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { renderViewImage } from '../views/snapshot.js';
import { sunStudyFrames, DEFAULT_SUN } from '../core/sun.js';
import { download } from '../io/storage.js';

export function sunStudyDialog(app) {
  const view = app.doc.get(app.activeViewId);
  if (view?.kind !== 'view3d') return toast('Open a 3D view to make a sun study of it.', { kind: 'error' });
  const project = app.doc.get('project') || {};
  const sun = { ...DEFAULT_SUN, ...(project.sun || {}) };
  const field = (label, type, value) => {
    const inp = h('input.input', { type, value, 'aria-label': label });
    inp.addEventListener('keydown', (e) => e.stopPropagation());
    return { inp, row: h('label.field', h('span', label), inp) };
  };
  const date = field('Date', 'date', sun.date);
  const from = field('From', 'time', '08:00');
  const to = field('To', 'time', '18:00');
  const every = field('Every (minutes)', 'number', '60');
  const out = h('div.sun-study');
  let frames = [];
  let sheet = null;

  const make = () => {
    const list = sunStudyFrames(project, { date: date.inp.value, from: from.inp.value, to: to.inp.value, every: +every.inp.value });
    if (!list.length) return toast('The sun is below the horizon at all those times.', { kind: 'error' });
    const cam = app.viewStates.get(view.id)?.cam || null;
    const W = 640;
    const H = 400;
    frames = list.map((f) => ({ ...f, canvas: renderViewImage(app, view, W, H, { fit: !cam, camera: cam, viewPatch: { shadows: true, sunAt: { date: f.date, time: f.time } } }).canvas }));
    sheet = contactSheet(frames, W, H, view.name || '3D View');
    out.replaceChildren(h('img.sun-study-sheet', { src: sheet.toDataURL('image/png'), alt: `Sun study, ${frames.length} frames` }));
  };

  const save = () => {
    if (!sheet) make();
    sheet?.toBlob((b) => b && download(b, `sun-study-${date.inp.value}.png`));
  };
  const saveFrames = () => {
    if (!frames.length) make();
    for (const f of frames) f.canvas.toBlob((b) => b && download(b, `sun-study-${f.date}-${f.time.replace(':', '')}.png`));
  };

  return openDialog({
    title: 'Sun Study',
    size: 'lg',
    body: h('div', h('p.field-hint', 'The active 3D view with its shadows at each time, from the project location (Sun Settings).'), h('div.inline', { style: { gap: '8px', flexWrap: 'wrap' } }, date.row, from.row, to.row, every.row, h('button.btn', { type: 'button', onClick: make }, 'Create')), out),
    actions: [
      { label: 'Close', value: null },
      { label: 'Save Frames', onClick: () => (saveFrames(), false) },
      { label: 'Save Sheet', primary: true, onClick: () => (save(), false) },
    ],
  });
}

/** The frames in a grid, each with its time and the sun's altitude and azimuth under it. */
export function contactSheet(frames, W, H, title) {
  const cols = Math.min(4, frames.length);
  const rows = Math.ceil(frames.length / cols);
  const scale = 0.5;
  const fw = W * scale;
  const fh = H * scale;
  const pad = 16;
  const label = 22;
  const c = document.createElement('canvas');
  c.width = pad + cols * (fw + pad);
  c.height = 40 + rows * (fh + label + pad) + pad;
  const g = c.getContext('2d');
  g.fillStyle = '#ffffff';
  g.fillRect(0, 0, c.width, c.height);
  g.fillStyle = '#111111';
  g.font = '600 16px system-ui, sans-serif';
  g.fillText(`${title} - Sun study ${frames[0]?.date || ''}`, pad, 26);
  g.font = '12px system-ui, sans-serif';
  frames.forEach((f, i) => {
    const x = pad + (i % cols) * (fw + pad);
    const y = 40 + Math.floor(i / cols) * (fh + label + pad);
    g.drawImage(f.canvas, x, y, fw, fh);
    g.strokeStyle = '#cccccc';
    g.strokeRect(x + 0.5, y + 0.5, fw - 1, fh - 1);
    g.fillStyle = '#111111';
    g.fillText(`${f.time}  altitude ${f.altitude.toFixed(0)}°  azimuth ${f.azimuth.toFixed(0)}°`, x, y + fh + 15);
  });
  return c;
}
