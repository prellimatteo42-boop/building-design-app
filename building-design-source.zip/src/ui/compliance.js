/**
 * Check Requirements (Document menu): the design against a building code's
 * requirements for dwellings (core/compliance.js), each finding with the
 * elements it is about, to select, and to keep as issues.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { checkCompliance, RULESETS } from '../core/compliance.js';
import { uuid } from '../core/issues.js';

export function complianceDialog(app) {
  const body = h('div');
  let findings = [];
  const ruleset = h('select.input', { 'aria-label': 'Requirements' }, Object.entries(RULESETS).map(([k, r]) => h('option', { value: k }, r.name)));
  const render = () => {
    clear(body);
    findings = checkCompliance(app.doc, app.scene, { ruleset: ruleset.value });
    const errors = findings.filter((f) => f.severity === 'error').length;
    body.append(
      h('label.field', h('span.field-label', 'Requirements'), ruleset),
      h('p.dialog-text', findings.length ? `${errors} not met, ${findings.length - errors} to look at.` : 'Every room, window and door meets these requirements.'),
    );
    const list = h('div.cc-list');
    for (const f of findings)
      list.append(h(`div.cc-item.${f.severity}`, h('span.cc-mark', f.severity === 'error' ? '✕' : '!'), h('span.cc-text', f.message), h('button.btn.sm', { type: 'button', onClick: () => app.select(f.ids.filter((id) => app.doc.get(id))) }, 'Select')));
    body.append(list);
  };
  ruleset.addEventListener('change', render);
  render();
  return openDialog({
    title: 'Check Requirements',
    size: 'lg',
    body,
    actions: [
      { label: 'Close', value: null },
      {
        label: 'Make Issues',
        onClick: () => {
          if (!findings.length) return false;
          const n = makeIssues(app, findings);
          toast(`${n} issues made. See them in the Issue Manager.`, { kind: 'success' });
          return false;
        },
      },
      { label: 'Check Again', primary: true, onClick: () => (render(), false) },
    ],
  });
}

/** Keep findings as issues with their elements selected in the plan of their level. Returns how many were made. */
export function makeIssues(app, findings) {
  const doc = app.doc;
  const now = new Date().toISOString();
  let n = 0;
  app.commit('Requirement issues', () => {
    for (const f of findings) {
      const first = doc.get(f.ids[0]);
      const levelId = first?.levelId ?? doc.get(first?.hostId)?.levelId;
      const plan = doc.all('plan').find((v) => v.levelId === levelId);
      doc.add({ kind: 'issue', guid: uuid(), title: f.message.split(':')[0], type: 'Issue', status: 'Open', priority: f.severity === 'error' ? 'High' : 'Normal', assignedTo: '', author: 'Requirements check', created: now, modified: null, description: f.message, comments: [], viewpoint: { viewId: plan?.id ?? null, camera: null, selection: f.ids } });
      n++;
    }
  });
  return n;
}
