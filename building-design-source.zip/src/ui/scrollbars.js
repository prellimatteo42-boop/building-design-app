/**
 * Show Scroll Bar (Archicad's): scroll bars along the bottom and right of plan-like views. The thumbs show which
 * part of the drawing (its extents, with a margin) is on screen; dragging one pans the view.
 */
import { h } from './dom.js';

export class ScrollBars {
  constructor(app) {
    this.app = app;
    this.on = false;
    const mk = (axis) => {
      const thumb = h('div.sb-thumb');
      const track = h(`div.vscroll.vscroll-${axis}`, { hidden: true, 'aria-hidden': 'true' }, thumb);
      let start = null;
      thumb.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        thumb.setPointerCapture(e.pointerId);
        start = { x: e.clientX, y: e.clientY, cam: { ...this.app.vc.cam } };
      });
      thumb.addEventListener('pointermove', (e) => {
        if (!start || !this.range) return;
        const c = this.app.vc;
        const r = this.range;
        if (axis === 'x') c.cam = { ...c.cam, cx: start.cam.cx + ((e.clientX - start.x) / track.clientWidth) * (r.x1 - r.x0) };
        else c.cam = { ...c.cam, cy: start.cam.cy - ((e.clientY - start.y) / track.clientHeight) * (r.y1 - r.y0) };
        this.app.requestRender();
        this.update();
      });
      thumb.addEventListener('pointerup', () => {
        start = null;
        this.app.vc?.noteCamera?.(true);
      });
      return { track, thumb };
    };
    this.x = mk('x');
    this.y = mk('y');
    app.shell.canvasWrap.append(this.x.track, this.y.track);
  }

  set(on) {
    this.on = on;
    clearInterval(this.timer);
    if (on) this.timer = setInterval(() => this.update(), 150);
    this.update();
  }

  update() {
    const c = this.app.vc;
    const show = this.on && c?.is2D && c.cam && typeof c.extents === 'function';
    this.x.track.hidden = this.y.track.hidden = !show;
    if (!show) return;
    const vp = this.app.viewport;
    const a = c.screenToModel(0, vp.height);
    const b = c.screenToModel(vp.width, 0);
    const vis = { x0: Math.min(a[0], b[0]), x1: Math.max(a[0], b[0]), y0: Math.min(a[1], b[1]), y1: Math.max(a[1], b[1]) };
    const e = c.extents() || vis;
    const mx = (vis.x1 - vis.x0) / 2;
    const my = (vis.y1 - vis.y0) / 2;
    const r = { x0: Math.min(e.x0 - mx, vis.x0), x1: Math.max(e.x1 + mx, vis.x1), y0: Math.min(e.y0 - my, vis.y0), y1: Math.max(e.y1 + my, vis.y1) };
    this.range = r;
    const fx = (v) => ((v - r.x0) / (r.x1 - r.x0)) * 100;
    const fy = (v) => ((r.y1 - v) / (r.y1 - r.y0)) * 100;
    Object.assign(this.x.thumb.style, { left: `${fx(vis.x0)}%`, width: `${Math.max(4, fx(vis.x1) - fx(vis.x0))}%` });
    Object.assign(this.y.thumb.style, { top: `${fy(vis.y1)}%`, height: `${Math.max(4, fy(vis.y0) - fy(vis.y1))}%` });
  }
}
