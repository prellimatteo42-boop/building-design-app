/**
 * Pet palette, as in Archicad: a small row of editing commands that opens
 * where a selected element, or one of its nodes, is clicked. Each command
 * starts from that point. Arrow keys move between commands, Enter runs one,
 * Escape or a click elsewhere closes it.
 */
import { h } from './dom.js';
import { icon } from './icons.js';

let open = null;

export function closePetPalette() {
  if (!open) return;
  open.el.remove();
  document.removeEventListener('pointerdown', open.outside, true);
  open = null;
}

export function petPaletteOpen() {
  return !!open;
}

/** items: [{ icon, label, action }] or { separator: true }; at: point in the canvas area, in pixels. */
export function showPetPalette(app, at, items, label = 'Pet palette') {
  closePetPalette();
  const wrap = app.shell.canvasWrap;
  const r = wrap.getBoundingClientRect();
  const buttons = [];
  const el = h('div.pet-palette', { role: 'toolbar', 'aria-label': label, 'aria-orientation': 'horizontal' });
  for (const it of items) {
    if (!it) continue;
    if (it.separator) {
      el.append(h('span.pet-sep', { 'aria-hidden': 'true' }));
      continue;
    }
    const b = h('button.pet-btn', {
      type: 'button',
      'aria-label': it.label,
      'data-tip': it.label,
      tabindex: buttons.length ? '-1' : '0',
      disabled: it.disabled || null,
      onClick: () => {
        closePetPalette();
        it.action();
      },
    }, icon(it.icon, 18));
    buttons.push(b);
    el.append(b);
  }
  el.addEventListener('keydown', (e) => {
    e.stopPropagation();
    const i = buttons.indexOf(document.activeElement);
    const step = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
    if (step) {
      e.preventDefault();
      const next = buttons[(i + step + buttons.length) % buttons.length];
      for (const b of buttons) b.tabIndex = -1;
      next.tabIndex = 0;
      next.focus();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      closePetPalette();
      app.viewport?.overlay?.focus({ preventScroll: true });
    }
  });
  document.body.append(el);
  // Just below and right of the click, kept on screen.
  const w = el.offsetWidth;
  const hgt = el.offsetHeight;
  const x = Math.max(4, Math.min(window.innerWidth - w - 4, r.left + at.x + 14));
  const y = Math.max(4, Math.min(window.innerHeight - hgt - 4, r.top + at.y + 14));
  el.style.left = `${x}px`;
  el.style.top = `${y}px`;
  const outside = (e) => {
    if (!el.contains(e.target)) closePetPalette();
  };
  document.addEventListener('pointerdown', outside, true);
  open = { el, outside };
  buttons[0]?.focus({ preventScroll: true });
  return el;
}
