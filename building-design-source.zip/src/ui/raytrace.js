/** Ray traced rendering of a 3D view (core/raytrace.js), spread over workers, the image improving as samples arrive. */
import { MODEL_KINDS } from '../core/scene.js';
import { hiddenInView } from '../core/plan.js';
import { sunDirection } from '../core/sun.js';
import { isLamp, lampSources, DAYLIGHT } from '../core/lamps.js';
import { autoExposure, denoise, toneMap } from '../core/raytrace.js';
import { loadImage } from '../assistant/images.js';

/** Every visible triangle of the view: { pos, col, uv, tid, images (the pictures, by number), glow, triangles }. */
export function gatherTriangles(app, view) {
  const { doc, scene } = app;
  const meshes = [];
  let total = 0;
  for (const kind of MODEL_KINDS)
    for (const el of doc.all(kind)) {
      if (hiddenInView(doc, view, el) || app.flagsOf?.(el.id) & 4) continue;
      const m = scene.mesh(el);
      if (!m) continue;
      const shines = isLamp(doc, el) && !doc.get(el.typeId)?.lightHigh && el.lightOn !== false;
      for (const part of [m, ...(m.tex || [])]) {
        const n = (part.pos?.length || 0) / 9;
        if (n) {
          meshes.push({ part, n, shines });
          total += n;
        }
      }
    }
  const pos = new Float32Array(total * 9);
  const col = new Uint8Array(total * 4);
  const nrm = new Int8Array(total * 9);
  const uv = new Float32Array(total * 6);
  const tid = new Int16Array(total).fill(-1);
  const glow = new Uint8Array(total);
  const images = [];
  const number = new Map();
  let at = 0;
  for (const { part, n, shines } of meshes) {
    pos.set(part.pos, at * 9);
    if (part.nrm) nrm.set(part.nrm, at * 9);
    if (part.uv && part.src) {
      if (!number.has(part.src)) {
        number.set(part.src, images.length);
        images.push(part.src);
      }
      uv.set(part.uv, at * 6);
      tid.fill(number.get(part.src), at, at + n);
    }
    if (shines) glow.fill(1, at, at + n);
    for (let t = 0; t < n; t++) {
      const c = at + t;
      // A surface drawn with a picture has no colour of its own here: a middle grey.
      if (part.col) for (let k = 0; k < 4; k++) col[4 * c + k] = part.col[t * 12 + k];
      else col.set([255, 255, 255, 255], 4 * c);
    }
    at += n;
  }
  return { pos, col, nrm, uv, tid, glow, images, triangles: total };
}

/** The pictures as pixels a worker can read: [{ w, h, data }], at most 1024 pixels across. */
async function readPictures(srcs) {
  const out = [];
  for (const src of srcs) {
    try {
      const img = await loadImage(src);
      const k = Math.min(1, 1024 / Math.max(img.naturalWidth, img.naturalHeight));
      const cv = document.createElement('canvas');
      cv.width = Math.max(1, Math.round(img.naturalWidth * k));
      cv.height = Math.max(1, Math.round(img.naturalHeight * k));
      const g = cv.getContext('2d', { willReadFrequently: true });
      g.drawImage(img, 0, 0, cv.width, cv.height);
      out.push({ w: cv.width, h: cv.height, data: g.getImageData(0, 0, cv.width, cv.height).data });
    } catch {
      out.push({ w: 1, h: 1, data: new Uint8ClampedArray([150, 150, 150, 255]) });
    }
  }
  return out;
}

/** The camera of a ModelController in the form tracePass takes. */
export function rayCamera(c) {
  const eye = c.eye();
  const { back, right, up } = c.basis();
  const fov = ((c.cam.fov || 45) * Math.PI) / 180;
  const tanH = Math.tan(fov / 2);
  return { eye, right, up, forward: back.map((v) => -v), tanH, persp: c.cam.persp !== false, halfH: c.cam.dist * tanH };
}

/**
 * Starts rendering. opts: { samples, sun, lamps, daylight, lampDimmer, exposure, depth, onUpdate(canvas, samples), onDone(canvas, samples) }.
 * Returns { stop() }.
 */
export function startRaytrace(app, view, controller, W, H, opts) {
  const { pos, col, nrm, uv, tid, glow, images, triangles } = gatherTriangles(app, view);
  const doc = app.doc;
  const dir = opts.sun ? sunDirection(doc.get('project')).dir : null;
  const day = DAYLIGHT.find((d) => d.value === opts.daylight)?.amount ?? 1;
  const lit = dir && dir[2] > 0.01;
  const lamps = opts.lamps ? lampSources(doc, (el) => app.scene.mesh(el)?.bounds, { eye: controller.eye(), hidden: (el) => hiddenInView(doc, view, el) }).map((l) => ({ at: l.at || l.pos, range: l.range, color: l.color.map((c) => c * (opts.lampDimmer ?? 1)) })) : [];
  const options = { sun: lit ? dir : [0, 0, 1], sunPower: lit ? 3 * day : 0, day, lamps, clip: controller.clipPlanes?.() || null, depth: opts.depth || 5 };
  const cam = rayCamera(controller);
  const count = Math.max(1, Math.min(16, (navigator.hardwareConcurrency || 4) - 1));
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  const image = ctx.createImageData(W, H);
  const sum = new Float32Array(W * H * 3);
  let samples = 0;
  let finished = 0;
  let last = 0;
  const workers = [];
  let guide = null;
  let exposure = null;
  const paint = (final = false) => {
    let light = sum;
    let count2 = samples;
    // The finished picture has its grain taken out; while it builds up it shows as it is, which is quicker.
    if (final && guide && opts.denoise !== false && samples) {
      const avg = new Float32Array(sum.length);
      for (let k = 0; k < sum.length; k++) avg[k] = sum[k] / samples;
      light = denoise(avg, guide, W, H);
      count2 = 1;
    }
    // Indoors far less light arrives than the sky gives: the exposure follows what the picture shows.
    if (opts.autoExposure !== false && samples && (exposure == null || samples < 16 || final)) {
      const avg = new Float32Array(sum.length);
      for (let k = 0; k < sum.length; k++) avg[k] = sum[k] / samples;
      exposure = autoExposure(avg);
    }
    toneMap(light, count2, image.data, (exposure ?? 1) * 2 ** (opts.exposure || 0));
    ctx.putImageData(image, 0, 0);
  };
  const stop = () => workers.splice(0).forEach((w) => w.terminate());
  const passes = Math.ceil(opts.samples / count);
  const begin = (textures) => {
  for (let i = 0; i < count; i++) {
    const w = new Worker(new URL('../render/raytrace.worker.js', import.meta.url), { type: 'module' });
    w.onmessage = (e) => {
      if (e.data.guide) {
        guide = e.data.guide;
        return;
      }
      if (e.data.done) {
        if (++finished === count) {
          paint(true);
          stop();
          opts.onDone?.(canvas, samples, triangles);
        }
        return;
      }
      const img = e.data.img;
      for (let k = 0; k < sum.length; k++) sum[k] += img[k];
      samples++;
      const now = performance.now();
      if (now - last > 500) {
        last = now;
        paint();
        opts.onUpdate?.(canvas, samples, triangles);
      }
    };
    w.onerror = (e) => opts.onError?.(e.message || 'The renderer stopped.');
    w.postMessage({ pos, col, nrm, uv, tid, glow, textures, cam, width: W, height: H, options, seed: (i + 1) * 104729, passes, guide: i === 0 });
    workers.push(w);
  }
  };
  readPictures(images).then(begin);
  return { stop, canvas, triangles };
}
