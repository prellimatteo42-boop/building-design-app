/** Ray traced rendering of a 3D view (core/raytrace.js), spread over workers, the image improving as samples arrive. */
import { MODEL_KINDS } from '../core/scene.js';
import { hiddenInView } from '../core/plan.js';
import { sunDirection } from '../core/sun.js';
import { lampSources, DAYLIGHT } from '../core/lamps.js';
import { toneMap } from '../core/raytrace.js';

/** Every visible triangle of the view: { pos, col, triangles }. */
export function gatherTriangles(app, view) {
  const { doc, scene } = app;
  const meshes = [];
  let total = 0;
  for (const kind of MODEL_KINDS)
    for (const el of doc.all(kind)) {
      if (hiddenInView(doc, view, el) || app.flagsOf?.(el.id) & 4) continue;
      const m = scene.mesh(el);
      if (!m) continue;
      for (const part of [m, ...(m.tex || [])]) {
        const n = (part.pos?.length || 0) / 9;
        if (n) {
          meshes.push({ part, n });
          total += n;
        }
      }
    }
  const pos = new Float32Array(total * 9);
  const col = new Uint8Array(total * 4);
  let at = 0;
  for (const { part, n } of meshes) {
    pos.set(part.pos, at * 9);
    for (let t = 0; t < n; t++) {
      const c = at + t;
      // A surface drawn with a picture has no colour of its own here: a middle grey.
      if (part.col) for (let k = 0; k < 4; k++) col[4 * c + k] = part.col[t * 12 + k];
      else col.set([150, 150, 150, 255], 4 * c);
    }
    at += n;
  }
  return { pos, col, triangles: total };
}

/** The camera of a ModelController in the form tracePass takes. */
export function rayCamera(c) {
  const eye = c.eye();
  const { back, right, up } = c.basis();
  const fov = ((c.cam.fov || 45) * Math.PI) / 180;
  const tanH = Math.tan(fov / 2);
  return { eye, right, up, forward: back.map((v) => -v), tanH, persp: c.cam.persp !== false, halfH: c.cam.dist * tanH };
}

/**
 * Starts rendering. opts: { samples, sun, lamps, daylight, lampDimmer, exposure, depth, onUpdate(canvas, samples), onDone(canvas, samples) }.
 * Returns { stop() }.
 */
export function startRaytrace(app, view, controller, W, H, opts) {
  const { pos, col, triangles } = gatherTriangles(app, view);
  const doc = app.doc;
  const dir = opts.sun ? sunDirection(doc.get('project')).dir : null;
  const day = DAYLIGHT.find((d) => d.value === opts.daylight)?.amount ?? 1;
  const lit = dir && dir[2] > 0.01;
  const lamps = opts.lamps ? lampSources(doc, (el) => app.scene.mesh(el)?.bounds, { eye: controller.eye(), hidden: (el) => hiddenInView(doc, view, el) }).map((l) => ({ at: l.at || l.pos, range: l.range, color: l.color.map((c) => c * (opts.lampDimmer ?? 1)) })) : [];
  const options = { sun: lit ? dir : [0, 0, 1], sunPower: lit ? 3 * day : 0, day, lamps, clip: controller.clipPlanes?.() || null, depth: opts.depth || 5 };
  const cam = rayCamera(controller);
  const count = Math.max(1, Math.min(16, (navigator.hardwareConcurrency || 4) - 1));
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  const image = ctx.createImageData(W, H);
  const sum = new Float32Array(W * H * 3);
  let samples = 0;
  let finished = 0;
  let last = 0;
  const workers = [];
  const paint = () => {
    toneMap(sum, samples, image.data, 2 ** (opts.exposure || 0));
    ctx.putImageData(image, 0, 0);
  };
  const stop = () => workers.splice(0).forEach((w) => w.terminate());
  const passes = Math.ceil(opts.samples / count);
  for (let i = 0; i < count; i++) {
    const w = new Worker(new URL('../render/raytrace.worker.js', import.meta.url), { type: 'module' });
    w.onmessage = (e) => {
      if (e.data.done) {
        if (++finished === count) {
          paint();
          stop();
          opts.onDone?.(canvas, samples, triangles);
        }
        return;
      }
      const img = e.data.img;
      for (let k = 0; k < sum.length; k++) sum[k] += img[k];
      samples++;
      const now = performance.now();
      if (now - last > 500) {
        last = now;
        paint();
        opts.onUpdate?.(canvas, samples, triangles);
      }
    };
    w.onerror = (e) => opts.onError?.(e.message || 'The renderer stopped.');
    w.postMessage({ pos, col, cam, width: W, height: H, options, seed: (i + 1) * 104729, passes });
    workers.push(w);
  }
  return { stop, canvas, triangles };
}
