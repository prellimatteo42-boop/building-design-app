/**
 * Object Library palette (Archicad's Object Settings): browse the built-in
 * and project component types by category and family, preview them in plan
 * and 3D, set their size and place them.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { icon } from './icons.js';
import { libraryTree, libraryPreview, ensureLibraryType } from '../core/library.js';
import { formatLength, parseLength } from '../core/units.js';

const rgba = (c) => `rgba(${Math.round(c[0])}, ${Math.round(c[1])}, ${Math.round(c[2])}, ${c[3] ?? 1})`;

function fit(c, bounds, pad = 14) {
  const w = bounds.x1 - bounds.x0 || 1;
  const hh = bounds.y1 - bounds.y0 || 1;
  const k = Math.min((c.width - pad * 2) / w, (c.height - pad * 2) / hh);
  const ox = (c.width - w * k) / 2;
  const oy = (c.height - hh * k) / 2;
  return (p) => [ox + (p[0] - bounds.x0) * k, c.height - oy - (p[1] - bounds.y0) * k];
}

function path(ctx, pts, P, closed) {
  ctx.beginPath();
  pts.forEach((q, i) => (i ? ctx.lineTo(...P(q)) : ctx.moveTo(...P(q))));
  if (closed) ctx.closePath();
}

/** Draw a type's plan symbol and axonometric into two canvases. */
export function drawLibraryPreview(type, materialOf, planCanvas, axoCanvas) {
  const plan = libraryPreview(type, materialOf, 'plan');
  const pc = planCanvas.getContext('2d');
  pc.clearRect(0, 0, planCanvas.width, planCanvas.height);
  const P = fit(planCanvas, plan.bounds);
  if (!plan.noFill) {
    path(pc, plan.outline, P, true);
    pc.fillStyle = plan.fillColor ? rgba([...plan.fillColor.slice(0, 3), plan.fillColor[3] / 255]) : '#ffffff';
    pc.fill();
  } else if (plan.fillColor) {
    path(pc, plan.outline, P, true);
    pc.fillStyle = rgba([...plan.fillColor.slice(0, 3), plan.fillColor[3] / 255]);
    pc.fill();
  }
  pc.strokeStyle = '#222';
  pc.lineWidth = 1;
  for (const l of plan.loops) {
    pc.setLineDash(l.dash ? [4, 3] : []);
    path(pc, l.pts, P, l.closed);
    pc.stroke();
  }
  pc.setLineDash([]);
  const axo = libraryPreview(type, materialOf, '3d');
  const ac = axoCanvas.getContext('2d');
  ac.clearRect(0, 0, axoCanvas.width, axoCanvas.height);
  const Q = fit(axoCanvas, axo.bounds);
  let waiting = false;
  for (const p of axo.polys) {
    if (p.src) {
      const img = pictureFor(p.src, () => !waiting || drawLibraryPreview(type, materialOf, planCanvas, axoCanvas));
      if (img) drawPictureTri(ac, img, p.pts.map(Q), p.uv);
      else waiting = true;
      continue;
    }
    path(ac, p.pts, Q, true);
    ac.fillStyle = rgba(p.color);
    ac.strokeStyle = rgba(p.color);
    ac.lineWidth = 0.6;
    ac.fill();
    ac.stroke();
  }
}

// Pictures for previews, loaded once; the callback redraws when one arrives.
const pictures = new Map();
function pictureFor(src, onLoad) {
  let p = pictures.get(src);
  if (!p) {
    const img = new Image();
    p = { img, ready: false, waiting: [] };
    pictures.set(src, p);
    img.onload = () => {
      p.ready = true;
      for (const f of p.waiting.splice(0)) f();
    };
    img.src = src;
  }
  if (p.ready) return p.img;
  p.waiting.push(onLoad);
  return null;
}

/** A picture on a screen triangle: the affine map taking its texture coordinates (v up) to the points. */
function drawPictureTri(ctx, img, [s0, s1, s2], uv) {
  const W = img.naturalWidth;
  const H = img.naturalHeight;
  const [t0, t1, t2] = uv.map(([u, v]) => [u * W, (1 - v) * H]);
  const d = (t1[0] - t0[0]) * (t2[1] - t0[1]) - (t2[0] - t0[0]) * (t1[1] - t0[1]);
  if (Math.abs(d) < 1e-9) return;
  const solve = (k) => {
    const a = ((s1[k] - s0[k]) * (t2[1] - t0[1]) - (s2[k] - s0[k]) * (t1[1] - t0[1])) / d;
    const b = ((s2[k] - s0[k]) * (t1[0] - t0[0]) - (s1[k] - s0[k]) * (t2[0] - t0[0])) / d;
    return [a, b, s0[k] - a * t0[0] - b * t0[1]];
  };
  const [a, c, e] = solve(0);
  const [b, dd, f] = solve(1);
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(s0[0], s0[1]);
  ctx.lineTo(s1[0], s1[1]);
  ctx.lineTo(s2[0], s2[1]);
  ctx.closePath();
  ctx.clip();
  ctx.transform(a, b, c, dd, e, f);
  ctx.drawImage(img, 0, 0);
  ctx.restore();
}

export function libraryDialog(app, { startPlacing } = {}) {
  const doc = app.doc;
  const units = doc.units;
  let query = '';
  let sel = doc.get(app.currentTypes.get('component'))?.id || libraryTree(doc)[0]?.families[0]?.items[0]?.type.id;
  const open = new Set();
  const list = h('div.lib-tree', { role: 'tree', 'aria-label': 'Library' });
  const detail = h('div.lib-detail');
  const search = h('input.input', { type: 'search', placeholder: 'Search the library', 'aria-label': 'Search the library' });
  search.addEventListener('input', () => {
    query = search.value;
    renderList();
  });
  const materialOf = (id) => doc.get(id);
  const dims = {};
  const find = () => libraryTree(doc).flatMap((c) => c.families.flatMap((f) => f.items)).find((i) => i.type.id === sel);

  const renderList = () => {
    clear(list);
    const tree = libraryTree(doc, query);
    if (!tree.length) list.append(h('p.field-hint', 'Nothing in the library matches.'));
    const cur = find();
    for (const c of tree) {
      const expanded = !!query || open.has(c.id) || cur?.type.category === c.id;
      const items = h('div.lib-cat-items', { role: 'group', hidden: !expanded });
      for (const f of c.families) {
        items.append(h('div.lib-family', f.name));
        for (const i of f.items)
          items.append(
            h(
              'button.file-item.lib-item',
              { type: 'button', role: 'treeitem', 'aria-selected': String(i.type.id === sel), onClick: () => ((sel = i.type.id), renderList(), renderDetail()) },
              h('span.file-name', i.type.name),
              i.loaded ? null : h('span.file-meta', 'Library'),
            ),
          );
      }
      const head = h('button.lib-cat', { type: 'button', 'aria-expanded': String(expanded), onClick: () => (open.has(c.id) ? open.delete(c.id) : open.add(c.id), renderList()) }, icon(expanded ? 'chevron-down' : 'chevron-right', 12), h('span', c.label), h('span.file-meta', String(c.families.reduce((s, f) => s + f.items.length, 0))));
      list.append(h('div.lib-cat-wrap', head, items));
    }
  };

  const renderDetail = () => {
    clear(detail);
    const item = find();
    if (!item) return;
    const t = item.type;
    for (const k of ['width', 'depth', 'height']) if (dims.typeId !== t.id) dims[k] = t[k];
    dims.typeId = t.id;
    const planC = h('canvas.lib-preview', { width: 260, height: 200, 'aria-label': `${t.name} in plan`, role: 'img' });
    const axoC = h('canvas.lib-preview', { width: 260, height: 200, 'aria-label': `${t.name} in 3D`, role: 'img' });
    const redraw = () => drawLibraryPreview({ ...t, width: dims.width, depth: dims.depth, height: dims.height }, materialOf, planC, axoC);
    const dimField = (key, label) => {
      const inp = h('input.input', { type: 'text', value: formatLength(dims[key], units), 'aria-label': label });
      inp.addEventListener('change', () => {
        const v = parseLength(inp.value, units);
        if (!(v > 0)) return toast(`${label}: enter a length.`, { kind: 'error' }), (inp.value = formatLength(dims[key], units));
        dims[key] = v;
        inp.value = formatLength(v, units);
        redraw();
      });
      return h('label.field', h('span.field-label', label), inp);
    };
    detail.append(
      h('div.lib-head', h('strong', t.name), h('span.file-meta', `${t.familyName || 'Custom'} · ${item.loaded ? 'In this project' : 'Built-in library'}`)),
      h('div.lib-previews', planC, axoC),
      h('div.lib-dims', dimField('width', 'Width'), dimField('depth', 'Depth'), dimField('height', 'Height')),
      h('p.field-hint', 'A size other than the type\'s makes a new type of this family when you place or load it.'),
    );
    requestAnimationFrame(redraw);
  };

  const resolve = (label) => {
    let type = null;
    app.commit(label, () => {
      type = ensureLibraryType(doc, sel, dims);
    });
    return type;
  };

  renderList();
  renderDetail();
  return openDialog({
    title: 'Object Library',
    size: 'lg',
    className: 'lib-dialog',
    body: h('div.lib-layout', h('div.lib-side', search, list), detail),
    initialFocus: 'input',
    actions: [
      {
        label: 'Load into Project',
        onClick: () => {
          const type = resolve('Load library part');
          if (!type) return false;
          toast(`${type.name} is in the project.`, { kind: 'success' });
          sel = type.id;
          renderList();
          renderDetail();
          return false;
        },
      },
      { label: 'Close', value: null },
      {
        label: 'Place',
        primary: true,
        onClick: () => {
          const type = resolve('Load library part');
          if (!type) return false;
          app.setCurrentType('component', type.id);
          return type.id;
        },
      },
    ],
  }).then((id) => {
    if (id) startPlacing?.(id);
    return id;
  });
}
