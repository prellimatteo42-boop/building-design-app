/**
 * Organizer (Window > Navigator Palettes > Organizer): two columns, the
 * project's views on the left and the Layout Book (layouts with their
 * drawings, masters) and the publisher sets on the right. Drag a view onto a
 * layout to place it as a drawing, onto a publisher set to add it; or pick
 * one on each side and use the buttons.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { isView, VIEW_LABEL } from '../core/doc.js';
import { layoutsInOrder } from '../core/windowcmds.js';
import { placeViewOnSheet } from './dialogs.js';

export function organizerDialog(app) {
  const doc = app.doc;
  let picked = null;
  let target = null;
  const left = h('ul.file-list.org-list', { 'aria-label': 'Views', style: { maxHeight: '52vh' } });
  const right = h('ul.file-list.org-list', { 'aria-label': 'Layouts and publisher sets', style: { maxHeight: '52vh' } });
  const status = h('p.field-hint', { 'aria-live': 'polite' });
  const placedOn = () => new Map(doc.all('viewport').map((v) => [v.placedId, doc.get(v.viewId)]));
  const place = (viewId, sheetId) => {
    const view = doc.get(viewId);
    const sh = doc.get(sheetId);
    if (!view || !sh) return;
    if (placedOn().has(view.id)) return (status.textContent = `${view.name} is already on a layout: a view goes on one layout.`);
    placeViewOnSheet(app, view, sh, { open: false });
    status.textContent = `${view.name} placed on ${sh.number || ''} ${sh.name}.`;
    render();
  };
  const addToSet = (viewId, setId) => {
    const set = doc.get(setId);
    if (!set || set.items?.includes(viewId)) return;
    app.commit('Add to publisher set', () => doc.update(setId, { items: [...(set.items || []), viewId] }));
    status.textContent = `${doc.get(viewId)?.name} added to ${set.name}.`;
    render();
  };
  const drop = (el, onDrop) => {
    el.addEventListener('dragover', (e) => (e.preventDefault(), el.classList.add('drop')));
    el.addEventListener('dragleave', () => el.classList.remove('drop'));
    el.addEventListener('drop', (e) => {
      e.preventDefault();
      el.classList.remove('drop');
      const id = e.dataTransfer.getData('text/x-bd-view');
      if (id) onDrop(id);
    });
  };
  const render = () => {
    const on = placedOn();
    const views = doc.filter((x) => isView(x) && !['sheet', 'schedule'].includes(x.kind));
    const byKind = new Map();
    for (const v of views) byKind.set(v.kind, [...(byKind.get(v.kind) || []), v]);
    left.replaceChildren();
    for (const [kind, list] of byKind) {
      left.append(h('li.org-group', VIEW_LABEL[kind] || kind));
      for (const v of list) {
        const sh = on.get(v.id);
        const item = h('button.file-item', { type: 'button', draggable: 'true', 'aria-pressed': String(picked === v.id), onClick: () => ((picked = v.id), render()) }, h('span.file-name', v.name), h('span.file-meta', sh ? `on ${sh.number || sh.name}` : ''));
        item.addEventListener('dragstart', (e) => e.dataTransfer.setData('text/x-bd-view', v.id));
        left.append(h('li', item));
      }
    }
    right.replaceChildren(h('li.org-group', 'Layout Book'));
    for (const sh of layoutsInOrder(doc)) {
      const drawings = doc.all('viewport').filter((x) => x.viewId === sh.id).map((x) => doc.get(x.placedId)?.name).filter(Boolean);
      const item = h('button.file-item', { type: 'button', 'aria-pressed': String(target === sh.id), onClick: () => ((target = sh.id), render()), onDblclick: () => app.openView(sh.id) }, h('span.file-name', `${sh.number ? `${sh.number} ` : ''}${sh.name}`), h('span.file-meta', drawings.length ? `${drawings.length} drawing${drawings.length > 1 ? 's' : ''}` : 'empty'));
      drop(item, (id) => place(id, sh.id));
      right.append(h('li', item));
      for (const d of drawings) right.append(h('li.org-sub', `↳ ${d}`));
    }
    const masters = doc.all('masterLayout');
    if (masters.length) {
      right.append(h('li.org-group', 'Masters'));
      for (const m of masters) right.append(h('li', h('button.file-item', { type: 'button', onClick: () => app.openView(m.id) }, h('span.file-name', m.name || 'Master'), h('span.file-meta', 'open'))));
    }
    const sets = doc.all('publisherSet');
    if (sets.length) {
      right.append(h('li.org-group', 'Publisher Sets'));
      for (const s of sets) {
        const item = h('button.file-item', { type: 'button', 'aria-pressed': String(target === s.id), onClick: () => ((target = s.id), render()) }, h('span.file-name', s.name), h('span.file-meta', `${(s.items || []).length} items`));
        drop(item, (id) => addToSet(id, s.id));
        right.append(h('li', item));
      }
    }
  };
  render();
  const go = () => {
    if (!picked || !target) return (status.textContent = 'Pick a view on the left and a layout or publisher set on the right.');
    const t = doc.get(target);
    if (t?.kind === 'sheet') place(picked, target);
    else if (t?.kind === 'publisherSet') addToSet(picked, target);
  };
  const body = h('div', h('div.organizer', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' } }, h('div', h('h3.dlg-sub', 'Project views'), left), h('div', h('h3.dlg-sub', 'Layouts and sets'), right)), h('div.row-actions', h('button.btn.sm.primary', { type: 'button', onClick: go }, 'Place / Add →')), status);
  if (!doc.count('sheet')) toast('There are no layouts yet: make one in the Layout Book to place views on it.');
  return openDialog({ title: 'Organizer', size: 'lg', body, actions: [{ label: 'Close', value: null }] });
}
