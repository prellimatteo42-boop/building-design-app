/**
 * Navigate, Layers and Trace menu commands: last view of a kind, the active
 * layer, undo and redo of layer changes, and the trace reference from a file
 * or a 3D view.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { newId } from '../core/doc.js';
import { lastViewOf, layerSnapshot } from '../core/navlast.js';
import { layerIdOf, layersInOrder } from '../core/layers.js';
import { traceReference } from '../core/trace.js';
import { pickFile } from '../io/files.js';
import { rebuildDocument3d } from '../core/doc3d.js';
import { MODEL_KINDS } from '../core/scene.js';

const LABEL = { section: 'section', elevation: 'elevation', interior: 'interior elevation', detail: 'detail', worksheet: 'worksheet', schedule: 'schedule', index: 'project index' };

export function goToLast(app, key) {
  const v = lastViewOf(app.doc, key, app.lastViewByKey?.[key]);
  if (!v) return toast(`The project has no ${LABEL[key]} yet.`);
  app.openView(v.id);
}

/** Active Layer: the layer new elements go on (or each kind's own). */
export function activeLayerDialog(app) {
  const doc = app.doc;
  const s = h('select.input', { 'aria-label': 'Active layer' }, h('option', { value: '' }, 'By element type'), layersInOrder(doc).map((l) => h('option', { value: l.id }, l.name)));
  s.value = doc.project.activeLayerId || '';
  return openDialog({
    title: 'Active Layer',
    body: h('label.field', h('span.field-label', 'New elements go on'), s),
    actions: [
      { label: 'Cancel', value: null },
      { label: 'OK', primary: true, onClick: () => (app.commit('Active layer', () => doc.update('project', { activeLayerId: s.value || null })), true) },
    ],
  });
}

function applyLayers(app, state) {
  const doc = app.doc;
  app.commit('Layer change', () => {
    for (const [id, hidden, locked, wireframe] of JSON.parse(state)) if (doc.has(id)) doc.update(id, { hidden, locked, wireframe });
  });
  app.quickLayers?.render?.();
  app.requestRender();
}

export function undoLayerChange(app) {
  const st = app.layerHistory.undo();
  if (!st) return toast('No layer change to undo.');
  applyLayers(app, st);
}

export function redoLayerChange(app) {
  const st = app.layerHistory.redo();
  if (!st) return toast('No layer change to redo.');
  applyLayers(app, st);
}

/** Unlock the layers of the selected elements. */
export function unlockSelectionLayers(app) {
  const doc = app.doc;
  const ids = new Set([...app.selection].map((id) => layerIdOf(doc, doc.get(id))).filter((id) => id && doc.get(id).locked));
  if (!ids.size) return toast('The layers of the selection are not locked.');
  app.commit('Unlock layers', () => ids.forEach((id) => doc.update(id, { locked: false })));
  toast(`${ids.size} layer${ids.size === 1 ? '' : 's'} unlocked.`);
}

/** Activate Reference: open the traced drawing; the active view keeps its trace. */
export function activateReference(app) {
  const v = app.activeView;
  const shown = traceReference(app.doc, v, app.traces.get(v?.id));
  if (!shown) return toast('There is no reference to activate here.');
  app.openView(shown.id);
}

/** Turn off Trace everywhere. */
export function traceOffEverywhere(app) {
  let n = 0;
  for (const [id, t] of app.traces)
    if (t.on) {
      app.traces.set(id, { ...t, on: false });
      n++;
    }
  app.tracePalette?.render();
  app.requestRender();
  toast(n ? `Trace turned off in ${n} view${n === 1 ? '' : 's'}.` : 'No view has a trace on.');
}

/** Back to where the reference was before being temporarily displaced. */
export function resetTemporaryReference(app) {
  const t = app.traces.get(app.activeViewId);
  if (!t?.tempFrom) return toast('The reference has not been displaced.');
  const { tempFrom, ...rest } = t;
  app.traces.set(app.activeViewId, { ...rest, offset: tempFrom });
  app.tracePalette?.render();
  app.requestRender();
}

function setReference(app, id) {
  const v = app.activeView;
  app.traces.set(v.id, { ...(app.traces.get(v.id) || { offset: [0, 0], rotation: 0 }), refId: id, on: true });
  app.tracePalette?.render();
  app.requestRender();
}

/** Browse for Trace Reference: a picture or PDF page in a drawing of its own, traced under the active view. */
export async function browseTraceReference(app) {
  const v = app.activeView;
  if (!app.vc?.is2D || !v || v.kind === 'sheet') return toast('Open a plan, drafting view or detail first.', { kind: 'error' });
  const f = await pickFile('image/png,image/jpeg,image/webp,application/pdf,.pdf');
  if (!f) return;
  let src;
  let w;
  let hh;
  const scale = +v.scale || 100;
  try {
    if (/\.pdf$/i.test(f.name) || f.type === 'application/pdf') {
      const { openPDF } = await import('../io/pdfread.js');
      const pdf = await openPDF(new Uint8Array(await f.arrayBuffer()));
      const page = await pdf.render(1, { dpi: 150, maxEdge: 4000 });
      src = page.canvas.toDataURL('image/jpeg', 0.85);
      w = page.widthMm * scale;
      hh = page.heightMm * scale;
    } else {
      src = await new Promise((ok, no) => {
        const r = new FileReader();
        r.onload = () => ok(String(r.result));
        r.onerror = no;
        r.readAsDataURL(f);
      });
      const img = await new Promise((ok, no) => {
        const i = new Image();
        i.onload = () => ok(i);
        i.onerror = no;
        i.src = src;
      });
      w = 20000;
      hh = (w * img.naturalHeight) / Math.max(1, img.naturalWidth);
    }
  } catch (err) {
    return toast(`${f.name} could not be read: ${err?.message || err}`, { kind: 'error' });
  }
  const id = newId('v');
  app.commit('Trace reference from file', () => {
    app.doc.add({ id, kind: 'drafting', name: `Reference - ${f.name}`, scale, detail: 'medium', hiddenCats: [], hiddenIds: [] });
    app.doc.add({ kind: 'image', viewId: id, at: [app.vc.cam.cx - w / 2, app.vc.cam.cy - hh / 2], w, h: hh, rotation: 0, opacity: 1, src, name: f.name });
  });
  setReference(app, id);
  toast(`${f.name} is the reference now. Calibrate it in its own drawing if its scale is not true.`);
}

/** Reference - Own Model: a 3D view as reference, through a 3D document of it. */
export function referenceOwnModel(app) {
  const doc = app.doc;
  const v = app.activeView;
  if (!app.vc?.is2D || !v || v.kind === 'sheet') return toast('Open a plan, drafting view or detail first.', { kind: 'error' });
  const views = doc.all('view3d');
  if (!views.length) return toast('The project has no 3D view.', { kind: 'error' });
  const s = h('select.input', { 'aria-label': '3D view' }, views.map((x) => h('option', { value: x.id }, x.name)));
  return openDialog({
    title: 'Reference - Own Model',
    body: h('div', h('label.field', h('span.field-label', '3D view'), s), h('p.field-hint', 'The view is drawn as a 3D document and traced under this drawing.')),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'Use as Reference',
        primary: true,
        onClick: () => {
          const src = doc.get(s.value);
          const id = newId('v');
          app.commit('Trace reference from 3D', () => {
            doc.add({ id, kind: 'drafting', name: `Reference - ${src.name}`, scale: +v.scale || 100, detail: 'fine', hiddenCats: [], hiddenIds: [], doc3d: { camera: app.controllers.get(src.id)?.cam || src.camera, sourceViewId: src.id, hiddenCats: [...(src.hiddenCats || [])], hiddenIds: [...(src.hiddenIds || [])], res: 20 } });
            rebuildDocument3d(doc, doc.get(id), (el) => app.scene.mesh(el), MODEL_KINDS);
          });
          setReference(app, id);
          return true;
        },
      },
    ],
  });
}

export { layerSnapshot };
