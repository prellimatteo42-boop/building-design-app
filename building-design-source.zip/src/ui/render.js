/**
 * Render: a presentation image of a 3D view (realistic materials, sun and
 * shadows, a sky), supersampled for smooth edges, at a chosen size.
 */
import { h } from './dom.js';
import { icon } from './icons.js';
import { openDialog, toast } from './dialog.js';
import { renderViewImage } from '../views/snapshot.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { DAYLIGHT, isLamp } from '../core/lamps.js';
import { RENDER_ENGINES, RENDER_DEFAULTS, adjustPixels } from '../core/doccmds.js';
import { startRaytrace } from './raytrace.js';

const SIZES = [
  { value: 'view', label: 'Same as the view' },
  { value: '1280x720', label: '1280 x 720' },
  { value: '1920x1080', label: '1920 x 1080 (Full HD)' },
  { value: '2560x1440', label: '2560 x 1440' },
  { value: '3840x2160', label: '3840 x 2160 (4K)' },
  { value: '2000x2000', label: '2000 x 2000 (square)' },
];

const QUALITY = [
  { value: 1, label: 'Draft' },
  { value: 2, label: 'Medium' },
  { value: 3, label: 'High' },
];

const BACKGROUNDS = [
  { value: 'sky', label: 'Sky' },
  { value: 'white', label: 'White' },
  { value: 'transparent', label: 'Transparent' },
];

function select(label, options, value) {
  const s = h('select.input', { 'aria-label': label }, options.map((o) => h('option', { value: String(o.value) }, o.label)));
  s.value = String(value);
  return { s, field: h('label.field', h('span.field-label', label), s) };
}

/** Largest supersampling that stays inside the GPU's limits. */
function maxScale(app, w, h, want) {
  const gl = app.viewport.gl;
  const lim = Math.min(gl.getParameter(gl.MAX_RENDERBUFFER_SIZE), gl.getParameter(gl.MAX_TEXTURE_SIZE), 8192);
  let k = want;
  while (k > 1 && (w * k > lim || h * k > lim)) k--;
  return k;
}

export function renderDialog(app, { region = null, crop = false } = {}) {
  const view = app.activeView;
  if (view?.kind !== 'view3d') return toast('Open a 3D view to render it.', { kind: 'error' });
  const size = select('Image size', SIZES, region ? 'view' : app.settings.renderSafeFrame || '1920x1080');
  const quality = select('Quality', QUALITY, 2);
  const bg = select('Background', BACKGROUNDS, 'sky');
  const sun = h('input', { type: 'checkbox', checked: true });
  const edges = h('input', { type: 'checkbox', checked: false });
  // Lamps: on when the model has any; the time of day decides how much sun and sky is left.
  const nLamps = app.doc.all('component').filter((el) => isLamp(app.doc, el) && el.lightOn !== false).length;
  const lamps = h('input', { type: 'checkbox', checked: nLamps > 0 || !!view.lampLight });
  const tod = select('Time of day', DAYLIGHT, view.daylight || 'day');
  // PhotoRendering Settings: engine, light and image, kept with the view; named scenes in the project.
  const saved = { ...RENDER_DEFAULTS, ...(view.renderSettings || {}) };
  const engine = select('Engine', RENDER_ENGINES, saved.engine);
  const slider = (label, key, min, max, step, show) => {
    const i = h('input', { type: 'range', min, max, step, value: saved[key], 'aria-label': label });
    const v = h('span.field-hint');
    const sync = () => (v.textContent = show(+i.value));
    i.addEventListener('input', sync);
    sync();
    return { i, field: h('label.field', h('span.field-label', label, ' ', v), i), set: (x) => ((i.value = x), sync()) };
  };
  const signed = (x) => `${x > 0 ? '+' : ''}${Math.round(x * 100)}%`;
  const sliders = {
    exposure: slider('Exposure', 'exposure', -2, 2, 0.1, (x) => `${x > 0 ? '+' : ''}${x.toFixed(1)} EV`),
    contrast: slider('Contrast', 'contrast', -0.5, 0.5, 0.05, signed),
    saturation: slider('Saturation', 'saturation', -1, 1, 0.05, signed),
    lampDimmer: slider('Lamp intensity', 'lampDimmer', 0, 3, 0.1, (x) => `${Math.round(x * 100)}%`),
  };
  const current = () => ({ engine: engine.s.value, ...Object.fromEntries(Object.entries(sliders).map(([k, s]) => [k, +s.i.value])) });
  const keep = () => app.commit('Rendering settings', () => app.doc.update(view.id, { renderSettings: current() }));
  const scenes = h('select.input', { 'aria-label': 'Scene' });
  const fillScenes = () => scenes.replaceChildren(h('option', { value: '' }, 'Custom'), ...(app.doc.get('project').renderScenes || []).map((s, i) => h('option', { value: String(i) }, s.name)));
  fillScenes();
  scenes.addEventListener('change', () => {
    const s = (app.doc.get('project').renderScenes || [])[+scenes.value];
    if (!scenes.value || !s) return;
    engine.s.value = s.engine;
    for (const [k, sl] of Object.entries(sliders)) sl.set(s[k] ?? RENDER_DEFAULTS[k]);
  });
  const saveScene = () => {
    const name = prompt('Name of the scene', 'My scene');
    if (!name) return;
    const list = (app.doc.get('project').renderScenes || []).filter((s) => s.name !== name);
    app.commit('Save rendering scene', () => app.doc.update('project', { renderScenes: [...list, { name, ...current() }] }));
    fillScenes();
    scenes.value = String(list.length);
  };
  const preview = h('div.render-preview', h('p.field-hint', 'The rendered image appears here.'));
  let last = null;
  // Ray tracing runs in workers and improves as it goes; Render again or close to stop it.
  let ray = null;
  const runRay = (w, hgt, st) => {
    ray?.stop();
    const samples = { 1: 32, 2: 96, 3: 256, 4: 512 }[+quality.s.value] || 96;
    const note = h('p.field-hint', 'Preparing the scene...');
    const finish = (canvas, done, tris) => {
      if (st.contrast || st.saturation) {
        const ctx = canvas.getContext('2d');
        const px = ctx.getImageData(0, 0, canvas.width, canvas.height);
        adjustPixels(px.data, { ...st, exposure: 0 });
        ctx.putImageData(px, 0, 0);
      }
      last = canvas;
      note.textContent = `${canvas.width} x ${canvas.height} pixels, ${done} samples per pixel, ${tris.toLocaleString()} triangles.`;
    };
    try {
      const controller = app.vc;
      ray = startRaytrace(app, view, controller, w, hgt, {
        samples,
        sun: sun.checked,
        lamps: lamps.checked,
        daylight: tod.s.value,
        lampDimmer: st.lampDimmer,
        exposure: st.exposure,
        onUpdate: (c, done) => {
          last = c;
          note.textContent = `Rendering: ${done} of ${samples} samples per pixel. Save takes the image as it is now.`;
        },
        onDone: finish,
        onError: (m) => (note.textContent = `Ray tracing stopped: ${m}`),
      });
    } catch (err) {
      console.error(err);
      return toast('The image could not be ray traced.', { kind: 'error' });
    }
    ray.canvas.style.cssText = 'max-width:100%;height:auto;display:block';
    last = ray.canvas;
    preview.replaceChildren(ray.canvas, note);
  };
  const run = () => {
    const vp = app.viewport;
    let [w, hgt] = size.s.value === 'view' ? [vp.width * vp.dpr, vp.height * vp.dpr] : size.s.value.split('x').map(Number);
    w = Math.round(w);
    hgt = Math.round(hgt);
    const k = maxScale(app, w, hgt, +quality.s.value);
    const st = current();
    if (JSON.stringify(st) !== JSON.stringify({ ...RENDER_DEFAULTS, ...(view.renderSettings || {}) })) keep();
    if (st.engine === 'raytrace') return runRay(w, hgt, st);
    const enginePatch = RENDER_ENGINES.find((e) => e.value === st.engine)?.patch || {};
    const cam = app.vc?.cam;
    let img;
    try {
      img = renderViewImage(app, view, w * k, hgt * k, {
        fit: false,
        camera: cam,
        transparent: bg.s.value !== 'white',
        viewPatch: { style: 'realistic', shadows: sun.checked, renderEdges: edges.checked, lampLight: lamps.checked, daylight: tod.s.value, lampDimmer: st.lampDimmer, ...enginePatch },
      }).canvas;
    } catch (err) {
      console.error(err);
      return toast('The image could not be rendered. Try a smaller size or lower quality.', { kind: 'error' });
    }
    // Downsample for smooth edges, over the chosen background.
    const out = document.createElement('canvas');
    out.width = w;
    out.height = hgt;
    const ctx = out.getContext('2d');
    if (bg.s.value === 'sky') {
      const g = ctx.createLinearGradient(0, 0, 0, hgt);
      const SKIES = { day: ['#7fa8d6', '#cfe0f0', '#eef2f4'], dusk: ['#2d3b63', '#b0707a', '#e9b98c'], night: ['#05070f', '#111a33', '#1f2a44'] };
      const [s0, s1, s2] = SKIES[lamps.checked ? tod.s.value : 'day'] || SKIES.day;
      g.addColorStop(0, s0);
      g.addColorStop(0.55, s1);
      g.addColorStop(1, s2);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, hgt);
    }
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, w, hgt);
    if (st.exposure || st.contrast || st.saturation) {
      const px = ctx.getImageData(0, 0, w, hgt);
      adjustPixels(px.data, st);
      ctx.putImageData(px, 0, 0);
    }
    last = out;
    // Render Marquee Region: only the region shows (cropped to it, or in the whole frame).
    if (region) {
      const rx = Math.round(region.x0 * w);
      const ry = Math.round(region.y0 * hgt);
      const rw = Math.max(1, Math.round((region.x1 - region.x0) * w));
      const rh = Math.max(1, Math.round((region.y1 - region.y0) * hgt));
      if (crop) {
        const c2 = document.createElement('canvas');
        c2.width = rw;
        c2.height = rh;
        c2.getContext('2d').drawImage(out, rx, ry, rw, rh, 0, 0, rw, rh);
        last = c2;
      } else {
        ctx.globalCompositeOperation = 'destination-in';
        ctx.fillRect(rx, ry, rw, rh);
        ctx.globalCompositeOperation = 'source-over';
      }
    }
    const shown = new Image();
    shown.alt = `Rendering of ${view.name}`;
    shown.src = last.toDataURL('image/png');
    preview.replaceChildren(shown, h('p.field-hint', `${last.width} x ${last.height} pixels${k > 1 ? `, ${k}x supersampled` : ''}${region ? (crop ? ', region cropped' : ', region only') : ''}`));
  };
  const save = () => {
    if (!last) run();
    last?.toBlob((blob) => blob && download(blob, `${safeFileName(`${app.doc.project.name || 'Project'} - ${view.name}`)}.png`), 'image/png');
  };
  return openDialog({
    title: region ? `Render Region of ${view.name}` : `Render ${view.name}`,
    size: 'lg',
    body: h(
      'div.render-layout',
      h('div.render-opts', h('label.field', h('span.field-label', 'Scene'), scenes), engine.field, size.field, quality.field, bg.field, h('label.check', sun, h('span', 'Sun and shadows', h('small.field-hint', ' (from Sun Settings)'))), h('label.check', edges, h('span', 'Outline edges')), h('label.check', lamps, h('span', 'Lamps', h('small.field-hint', ` (${nLamps} lit)`))), tod.field, ...Object.values(sliders).map((x) => x.field), h('button.btn.sm', { type: 'button', onClick: saveScene }, 'Save Scene...'), h('button.btn', { type: 'button', onClick: () => app.run('sunSettings') }, icon('sun-l', 16), 'Sun Settings...')),
      preview,
    ),
    actions: [
      { label: 'Close', value: null },
      { label: 'Save Image', onClick: () => (save(), false) },
      { label: 'Render', primary: true, onClick: () => (run(), false) },
    ],
  });
}
