/**
 * File > Interoperability > IFC: IFC Translators (export setups), IFC Project
 * Manager (the project tree and element attributes as they go out), Detect
 * IFC Model Changes (two versions of a file compared), Import/Export BIM
 * Content (classification and property XML).
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { pickFile } from '../io/files.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { writeIFC, ifcEntityOf } from '../io/ifc.js';
import { ifcGuidFor } from '../core/issues.js';
import { IFC_SCHEMAS, IFC_FILTERS, ifcTranslators, translatorFor } from '../core/ifctranslators.js';
import { compareIFC } from '../core/ifccompare.js';
import { parseBIMContent, applyBIMContent, writeBIMContent } from '../core/bimcontent.js';
import { MODEL_KINDS } from '../core/scene.js';
import { newId } from '../core/doc.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const stop = (i) => (i.addEventListener('keydown', (e) => e.stopPropagation()), i);

export function ifcTranslatorsDialog(app) {
  const doc = app.doc;
  let list = structuredClone(ifcTranslators(doc));
  let cur = doc.get('project')?.ifcTranslatorId && list.some((t) => t.id === doc.get('project').ifcTranslatorId) ? doc.get('project').ifcTranslatorId : list[0].id;
  const side = h('ul.file-list', { style: { maxHeight: '360px' } });
  const form = h('div');
  const save = () => app.commit('IFC translators', () => doc.update('project', { ifcTranslators: list, ifcTranslatorId: cur }));
  const render = () => {
    side.replaceChildren(
      ...list.map((t) => h('li', h('button.file-item', { type: 'button', 'aria-current': String(t.id === cur), onClick: () => ((cur = t.id), render()) }, h('span.file-name', t.name), h('span.file-meta', `${t.schema}${t.id === (doc.get('project')?.ifcTranslatorId || list[0].id) ? ' · default' : ''}`)))),
    );
    const t = list.find((x) => x.id === cur);
    const f = translatorFor(doc, t);
    const name = stop(h('input.input', { type: 'text', value: t.name, 'aria-label': 'Name' }));
    name.addEventListener('change', () => ((t.name = name.value || t.name), render()));
    const sel = (key, opts, label) => {
      const s = h('select.input', { 'aria-label': label }, opts.map((o) => h('option', { value: o.value }, o.label)));
      s.value = f[key];
      s.addEventListener('change', () => ((t[key] = s.value), render()));
      return field(label, s);
    };
    const chk = (key, label) => {
      const c = h('input', { type: 'checkbox', checked: !!f[key] });
      c.addEventListener('change', () => (t[key] = c.checked));
      return h('label.check', c, h('span', label));
    };
    const map = stop(h('textarea.input', { rows: 3, 'aria-label': 'Entity map', placeholder: 'column = IfcMember\nwall = IfcWallStandardCase' }, Object.entries(f.entityMap || {}).map(([k, v]) => `${k} = ${v}`).join('\n')));
    map.addEventListener('change', () => {
      const m = {};
      for (const line of map.value.split('\n')) {
        const [k, v] = line.split('=').map((x) => x?.trim());
        if (k && /^Ifc[A-Za-z]+$/.test(v || '')) m[k] = v;
      }
      t.entityMap = m;
    });
    form.replaceChildren(
      field('Name', name),
      h('div.row2', sel('schema', IFC_SCHEMAS, 'Schema'), sel('unit', [{ value: 'mm', label: 'Millimetres' }, { value: 'm', label: 'Metres' }], 'Length unit')),
      sel('filter', IFC_FILTERS, 'Elements'),
      h('div', chk('spaces', 'Zones as IfcSpace'), chk('properties', 'Property sets'), chk('classifications', 'Classification references')),
      field('IFC entity by element kind', map, 'One per line: kind = IfcEntity (empty: by classification and kind).'),
      h(
        'div.row-actions',
        h('button.btn.sm', { type: 'button', onClick: () => ((list = [...list, { ...structuredClone(t), id: newId('tr'), name: `${t.name} copy` }]), (cur = list.at(-1).id), render()) }, 'Duplicate'),
        h('button.btn.sm', { type: 'button', disabled: list.length < 2, onClick: () => ((list = list.filter((x) => x.id !== t.id)), (cur = list[0].id), render()) }, 'Delete'),
        h('button.btn.sm', { type: 'button', onClick: () => (save(), toast(`${t.name} is the default for IFC export.`)) }, 'Use for Export'),
        h('button.btn.sm', { type: 'button', onClick: () => download(new Blob([writeIFC(app, t)], { type: 'application/x-step' }), `${safeFileName(doc.project.name || 'Project')}.ifc`) }, 'Export IFC Now...'),
      ),
    );
  };
  render();
  return openDialog({
    title: 'IFC Translators',
    size: 'lg',
    body: h('div', { style: { display: 'grid', gridTemplateColumns: '220px 1fr', gap: '14px' } }, side, form),
    actions: [
      { label: 'Cancel', value: null },
      { label: 'OK', primary: true, onClick: () => (save(), true) },
    ],
  });
}

const ENTITY_KINDS = MODEL_KINDS.filter((k) => !['link', 'importedModel', 'pointCloud'].includes(k));

export function ifcProjectManagerDialog(app) {
  const doc = app.doc;
  const tree = { ...(doc.get('project')?.ifcProject || {}) };
  const attrs = new Map();
  const txt = (obj, key, label) => {
    const i = stop(h('input.input', { type: 'text', value: obj[key] || '', 'aria-label': label }));
    i.addEventListener('change', () => (obj[key] = i.value || undefined));
    return field(label, i);
  };
  // Elements by IFC entity.
  const groups = new Map();
  for (const k of ENTITY_KINDS)
    for (const el of doc.all(k)) {
      const e = ifcEntityOf(doc, el, translatorFor(doc).entityMap);
      if (!e) continue;
      if (!groups.has(e.entity)) groups.set(e.entity, []);
      groups.get(e.entity).push(el);
    }
  const elList = h('div', { style: { maxHeight: '300px', overflow: 'auto' } });
  const showGroup = (entity) => {
    const els = groups.get(entity) || [];
    elList.replaceChildren(
      h('h3.dlg-sub', `${entity} · ${els.length}`),
      h(
        'table.layers-table',
        h('thead', h('tr', ...['GlobalId', 'Name', 'Description', 'ObjectType', ''].map((x) => h('th', x)))),
        h(
          'tbody',
          els.slice(0, 300).map((el) => {
            const a = attrs.get(el.id) || { ...(el.ifcAttrs || {}) };
            attrs.set(el.id, a);
            const cell = (key) => {
              const i = stop(h('input.input.sm', { type: 'text', value: a[key] || '', 'aria-label': `${key} of ${el.id}` }));
              i.addEventListener('change', () => (a[key] = i.value || undefined));
              return h('td', i);
            };
            return h('tr', h('td', h('code', el.ifcGuid || ifcGuidFor(el.id))), cell('Name'), cell('Description'), cell('ObjectType'), h('td', h('button.btn.sm', { type: 'button', onClick: () => app.showElements([el.id]) }, 'Show')));
          }),
        ),
      ),
    );
  };
  const entities = [...groups.keys()].sort();
  const treeList = h(
    'ul.file-list',
    { style: { maxHeight: '300px' } },
    entities.map((e) => h('li', h('button.file-item', { type: 'button', onClick: () => showGroup(e) }, h('span.file-name', e), h('span.file-meta', String(groups.get(e).length))))),
  );
  if (entities.length) showGroup(entities[0]);
  const body = h(
    'div',
    h('h3.dlg-sub', 'IfcProject'),
    h('div.row2', txt(tree, 'projectName', 'Project name'), txt(tree, 'projectDescription', 'Project description'), txt(tree, 'phase', 'Phase')),
    h('h3.dlg-sub', 'IfcSite and IfcBuilding'),
    h('div.row2', txt(tree, 'siteName', 'Site name'), txt(tree, 'siteDescription', 'Site description'), txt(tree, 'buildingName', 'Building name'), txt(tree, 'buildingDescription', 'Building description')),
    h('h3.dlg-sub', 'IfcBuildingStorey'),
    h('p.field-hint', doc.levels().map((l) => `${l.name} (${Math.round(l.elevation)} mm)`).join(' · ') + ' — storeys take the names of the levels.'),
    h('h3.dlg-sub', 'Elements by IFC entity'),
    h('div', { style: { display: 'grid', gridTemplateColumns: '220px 1fr', gap: '12px' } }, treeList, elList),
  );
  return openDialog({
    title: 'IFC Project Manager',
    size: 'lg',
    body,
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'OK',
        primary: true,
        onClick: () => {
          app.commit('IFC project manager', () => {
            doc.update('project', { ifcProject: tree });
            for (const [id, a] of attrs) {
              const clean = Object.fromEntries(Object.entries(a).filter(([, v]) => v));
              const old = doc.get(id)?.ifcAttrs || {};
              if (JSON.stringify(clean) !== JSON.stringify(old)) doc.update(id, { ifcAttrs: Object.keys(clean).length ? clean : null });
            }
          });
          return true;
        },
      },
    ],
  });
}

export async function detectIfcChanges(app) {
  toast('Choose the earlier version of the IFC file.');
  const a = await pickFile('.ifc');
  if (!a) return;
  toast('Now the later version.');
  const b = await pickFile('.ifc');
  if (!b) return;
  let r;
  try {
    r = compareIFC(await a.text(), await b.text());
  } catch (err) {
    return toast(`The files could not be compared: ${err.message}`, { kind: 'error' });
  }
  const doc = app.doc;
  const byGuid = new Map();
  for (const k of ENTITY_KINDS) for (const el of doc.all(k)) byGuid.set(el.ifcGuid || ifcGuidFor(el.id), el.id);
  const row = (kind, x, what) => h('tr', h('td', kind), h('td', x.type), h('td', x.name), h('td', what), h('td', byGuid.has(x.guid) ? h('button.btn.sm', { type: 'button', onClick: () => app.showElements([byGuid.get(x.guid)]) }, 'Show') : ''));
  const rows = [...r.added.map((x) => row('New', x, '')), ...r.deleted.map((x) => row('Deleted', x, '')), ...r.modified.map((x) => row('Modified', x, x.changes.join('; ')))];
  return openDialog({
    title: 'IFC Model Changes',
    size: 'lg',
    body: h(
      'div',
      h('p', `${a.name} → ${b.name}: ${r.added.length} new, ${r.deleted.length} deleted, ${r.modified.length} modified, ${r.unchanged} unchanged.`),
      rows.length ? h('div', { style: { maxHeight: '55vh', overflow: 'auto' } }, h('table.layers-table', h('thead', h('tr', ...['Change', 'Entity', 'Name', 'What changed', ''].map((x) => h('th', x)))), h('tbody', rows))) : h('p.field-hint', 'No differences.'),
    ),
    actions: [{ label: 'Close', primary: true, value: null }],
  });
}

export async function importBimContent(app) {
  const f = await pickFile('.xml');
  if (!f) return;
  let c;
  try {
    c = parseBIMContent(await f.text());
  } catch (err) {
    return toast(`Not a BIM content file: ${err.message}`, { kind: 'error' });
  }
  if (!c.systems.length && !c.groups.length) return toast('No classification systems or property definitions in that file.', { kind: 'error' });
  let n;
  app.commit('Import BIM content', () => (n = applyBIMContent(app.doc, c)));
  toast(`Imported ${n.systems} classification system(s) with ${n.items} items and ${n.properties} properties in ${n.groups} group(s).`, { kind: 'success' });
}

export function exportBimContent(app) {
  download(new Blob([writeBIMContent(app.doc)], { type: 'application/xml' }), `${safeFileName(app.doc.project.name || 'Project')} BIM content.xml`);
}
