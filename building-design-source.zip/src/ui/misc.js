/**
 * Interface and miscellaneous commands: Enter Full Screen, Go to First /
 * Last Layout, Hide Tab Bar, Hide Quick Options Bar, Project Notes, the
 * all-layer commands (Hide All, Lock All, the two toggles), PolyCount and
 * Check Surfaces, and the MEP slopes and marker range on-screen options.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { MODEL_KINDS } from '../core/scene.js';
import { polyCount, checkSurfaces } from '../core/checks.js';

export function fullScreen(app) {
  if (document.fullscreenElement) document.exitFullscreen?.();
  else document.documentElement.requestFullscreen?.().catch(() => app.toast('Full screen is not allowed here.', { kind: 'error' }));
}

export function goToLayout(app, last = false) {
  const sheets = app.doc.all('sheet').sort((a, b) => String(a.number || '').localeCompare(String(b.number || ''), undefined, { numeric: true }) || String(a.name).localeCompare(String(b.name)));
  const s = last ? sheets.at(-1) : sheets[0];
  if (!s) return app.toast('There are no layouts yet.', { kind: 'error' });
  app.openView(s.id);
}

export function toggleBar(app, key) {
  const on = !app.settings[key];
  app.settingsStore.set(key, on);
  applyBars(app);
}

/** Show or hide the view tab bar and the quick options (view) bar from the settings. */
export function applyBars(app) {
  if (app.shell?.vtabs) app.shell.vtabs.hidden = !!app.settings.hideTabBar;
  if (app.shell?.viewbar) app.shell.viewbar.hidden = !!app.settings.hideQuickOptions;
  app.viewport?.resize?.();
}

export function projectNotes(app) {
  const ta = h('textarea.input', { rows: 14, style: { width: '100%' }, 'aria-label': 'Project notes' }, app.doc.project?.notes || '');
  ta.addEventListener('keydown', (e) => e.stopPropagation());
  return openDialog({ title: 'Project Notes', body: h('div', ta, h('p.field-hint', 'Free notes kept in the project file.')), size: 'lg', actions: [{ label: 'Cancel', value: null }, { label: 'Save', primary: true, value: 'ok' }] }).then((r) => {
    if (r === 'ok' && ta.value !== (app.doc.project?.notes || '')) app.commit('Project notes', () => app.doc.update('project', { notes: ta.value }));
  });
}

// Layers -----------------------------------------------------------------------------------------

const layers = (app) => app.doc.all('layer');

export function allLayers(app, key, value) {
  app.commit(`${value ? (key === 'hidden' ? 'Hide' : 'Lock') : key === 'hidden' ? 'Show' : 'Unlock'} all layers`, () => layers(app).forEach((l) => app.doc.update(l.id, { [key]: value })));
  app.flagsVersion++;
  app.requestRender();
}

/** Toggle between the layers' own state and all shown (or unlocked), remembering the state to go back to. */
export function layerToggle(app, key) {
  app.layerSaved = app.layerSaved || {};
  const saved = app.layerSaved[key];
  if (saved) {
    app.commit('Layers back', () => layers(app).forEach((l) => saved.has(l.id) && app.doc.update(l.id, { [key]: true })));
    app.layerSaved[key] = null;
  } else {
    const on = new Set(layers(app).filter((l) => l[key]).map((l) => l.id));
    if (!on.size) return app.toast(key === 'hidden' ? 'Every layer is already shown.' : 'Every layer is already unlocked.');
    app.commit(key === 'hidden' ? 'Show all layers' : 'Unlock all layers', () => on.forEach((id) => app.doc.update(id, { [key]: false })));
    app.layerSaved[key] = on;
  }
  app.flagsVersion++;
  app.requestRender();
}

// Checks ------------------------------------------------------------------------------------------

const table = (head, rows) => h('div', { style: { maxHeight: '45vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', ...head.map((x) => h('th', x)))), h('tbody', ...rows)));

export function polyCountDialog(app) {
  const ids = app.selection.size ? [...app.selection] : [...app.doc.items.values()].filter((el) => MODEL_KINDS.includes(el.kind)).map((el) => el.id);
  const r = polyCount(app.doc, ids, (el) => app.scene.mesh(el));
  const body = h(
    'div',
    h('p', `${r.total.toLocaleString()} triangles in ${r.rows.length} elements${app.selection.size ? ' (the selection)' : ''}.`),
    h('h3', 'By type'),
    table(['Type', 'Elements', 'Triangles'], r.types.slice(0, 50).map((t) => h('tr', h('td', t.name), h('td', String(t.count)), h('td', t.triangles.toLocaleString())))),
    h('h3', 'Heaviest elements'),
    table(['Element', 'Triangles', ''], r.rows.slice(0, 50).map((x) => h('tr', h('td', `${x.name} (${x.kind})`), h('td', x.triangles.toLocaleString()), h('td', h('button.btn.sm', { type: 'button', onClick: () => app.select([x.id]) }, 'Select'))))),
  );
  return openDialog({ title: 'PolyCount', body, size: 'lg', actions: [{ label: 'Close', value: null }] });
}

export function checkSurfacesDialog(app) {
  const r = checkSurfaces(app.doc);
  const body = h(
    'div',
    h('h3', `Materials named but missing (${r.missing.length})`),
    r.missing.length ? table(['Used by', 'Material'], r.missing.map((m) => h('tr', h('td', m.name), h('td', m.materialId)))) : h('p.field-hint', 'None.'),
    h('h3', `Materials nothing uses (${r.unused.length})`),
    r.unused.length ? h('p', r.unused.map((m) => m.name).join(', ')) : h('p.field-hint', 'None.'),
  );
  const actions = [{ label: 'Close', value: null }];
  if (r.unused.length) actions.unshift({ label: 'Delete unused', danger: true, value: 'del' });
  return openDialog({ title: 'Check Surfaces', body, size: 'lg', actions }).then((v) => {
    if (v === 'del') app.commit('Delete unused materials', () => r.unused.forEach((m) => app.doc.remove(m.id)));
  });
}

export function toggleSetting(app, key) {
  app.settingsStore.set(key, !app.settings[key]);
  app.requestRender();
}
