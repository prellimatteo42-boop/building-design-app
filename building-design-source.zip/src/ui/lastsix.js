/** Add-On Manager, Surfaces, Varying Members, Undock, and the trace of the whole model and of neighbouring elevations. */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { runScript } from '../core/scripting.js';
import { pickFile } from '../io/files.js';
import { newId } from '../core/doc.js';
import { renderViewImage } from '../views/snapshot.js';

const closeOnly = [{ label: 'Close', value: null }];

/** Add-On Manager: scripts added to the app, kept on this device. They run only when asked. */
export function addOnManager(app) {
  const box = h('div');
  const list = () => app.settings.addOns || [];
  const save = (l) => app.settingsStore.set('addOns', l);
  const out = h('pre.script-out', { 'aria-live': 'polite', style: { maxHeight: '120px', overflow: 'auto', fontSize: '12px', whiteSpace: 'pre-wrap' } });
  const render = () => {
    box.replaceChildren(
      list().length
        ? h('table.vg-table', h('thead', h('tr', h('th', 'Add-On'), h('th', 'On'), h('th', ''))), h('tbody', list().map((a, i) => {
            const on = h('input', { type: 'checkbox', checked: a.enabled !== false, 'aria-label': `${a.name} on` });
            on.addEventListener('change', () => save(list().map((x, k) => (k === i ? { ...x, enabled: on.checked } : x))));
            return h('tr', h('td', a.name), h('td', on), h('td', h('div.inline', { style: { gap: '4px' } },
              h('button.btn.sm', { type: 'button', onClick: async () => {
                if (a.enabled === false) return (out.textContent = `${a.name} is turned off.`);
                const r = await runScript(app, a.code);
                out.textContent = [...r.log, r.error ? `Error: ${r.error}` : r.result !== undefined ? JSON.stringify(r.result) : 'Done'].join('\n');
              } }, 'Run'),
              h('button.btn.sm', { type: 'button', onClick: () => (save(list().filter((_, k) => k !== i)), render()) }, 'Remove'))));
          })))
        : h('p.field-hint', 'No Add-Ons yet. An Add-On is a script for this app (.js), with the same access as the Script Console. Add only scripts you trust.'),
    );
  };
  render();
  const add = () => {
    pickFile('.js,text/javascript').then(async (f) => {
      if (!f) return;
      save([...list(), { id: newId('addon'), name: f.name.replace(/\.js$/i, ''), code: await f.text(), enabled: true }]);
      render();
    });
    return false;
  };
  return openDialog({ title: 'Add-On Manager', body: h('div', box, out), actions: [{ label: 'Close', value: null }, { label: 'Add...', onClick: add }] });
}

/** Surfaces: a texture and the look of each material. */
export function surfacesDialog(app) {
  const doc = app.doc;
  const mats = doc.all('material');
  const sel = h('select.input', { 'aria-label': 'Material' }, mats.map((m) => h('option', { value: m.id }, m.name)));
  const box = h('div');
  const set = (patch) => {
    const m = doc.get(sel.value);
    app.commit('Surface', () => doc.update(m.id, { surface: { w: 1000, h: 1000, angle: 0, shininess: 0.2, reflection: 0.2, ...(m.surface || {}), ...patch } }));
    app.requestRender();
    render();
  };
  const num = (label, key, def, step) => {
    const i = h('input.input', { type: 'number', step, value: doc.get(sel.value).surface?.[key] ?? def, 'aria-label': label });
    i.addEventListener('keydown', (e) => e.stopPropagation());
    i.addEventListener('change', () => set({ [key]: +i.value || 0 }));
    return h('label.field', h('span.field-label', label), i);
  };
  const render = () => {
    const m = doc.get(sel.value);
    box.replaceChildren(
      m.surface?.image ? h('img', { src: m.surface.image, alt: `Texture of ${m.name}`, style: { maxWidth: '160px', maxHeight: '120px', display: 'block', marginBottom: '6px' } }) : h('p.field-hint', 'No texture: faces show the colour of the material.'),
      h('div.inline', { style: { gap: '6px', marginBottom: '8px' } },
        h('button.btn.sm', { type: 'button', onClick: async () => {
          const f = await pickFile('image/png,image/jpeg,image/webp');
          if (!f) return;
          const src = await new Promise((ok) => {
            const r = new FileReader();
            r.onload = () => ok(String(r.result));
            r.readAsDataURL(f);
          });
          set({ image: src });
        } }, 'Choose Texture...'),
        h('button.btn.sm', { type: 'button', disabled: !m.surface?.image, onClick: () => set({ image: null }) }, 'Remove')),
      h('div.row3', num('Texture width (mm)', 'w', 1000, 10), num('Texture height (mm)', 'h', 1000, 10), num('Angle (degrees)', 'angle', 0, 1)),
      h('div.row2', num('Shininess (0-1)', 'shininess', 0.2, 0.05), num('Reflection (0-1)', 'reflection', 0.2, 0.05)),
      h('p.field-hint', 'The texture shows in 3D on faces of this material. Shininess and reflection go with the surface when it is saved as a library part; the 3D view does not render them.'),
    );
  };
  sel.addEventListener('change', render);
  render();
  return openDialog({ title: 'Surfaces', body: h('div', h('label.field', h('span.field-label', 'Material'), sel), box), actions: closeOnly });
}

/** Replacement Profiles of Varying Members: the section the analytical model takes for a tapered member. */
export function varyingProfiles(app) {
  const doc = app.doc;
  const cur = doc.project.analyticalRules?.varyingProfile || 'average';
  const s = h('select.input', { 'aria-label': 'Replacement profile' }, [['average', 'Average of the two ends'], ['start', 'Section at the start'], ['end', 'Section at the end'], ['max', 'The larger end']].map(([v, l]) => h('option', { value: v }, l)));
  s.value = cur;
  return openDialog({
    title: 'Replacement Profiles of Varying Members',
    body: h('div', h('label.field', h('span.field-label', 'A tapered beam is analysed with'), s), h('p.field-hint', 'A beam tapers with its End Width and End Depth properties.')),
    actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, onClick: () => (app.commit('Replacement profiles', () => doc.update('project', { analyticalRules: { ...(doc.project.analyticalRules || {}), varyingProfile: s.value } })), true) }],
  });
}

export function entireModelDisplay(app) {
  const v = app.activeView;
  if (!app.vc?.is2D || !v || v.kind === 'sheet') return toast('Open a plan first.', { kind: 'error' });
  const t = app.traces.get(v.id) || { offset: [0, 0], rotation: 0 };
  app.traces.set(v.id, t.refId === 'entire' && t.on ? { ...t, on: false } : { ...t, refId: 'entire', on: true });
  app.tracePalette?.render();
  app.requestRender();
}

export function referenceSiblings(app) {
  const v = app.activeView;
  if (!v?.interiorOf) return toast('Open an interior elevation first.', { kind: 'error' });
  const t = app.traces.get(v.id);
  app.traces.set(v.id, t?.refId === 'siblings' && t.on ? { ...t, on: false } : { refId: 'siblings', offset: [0, 0], rotation: 0, on: true });
  app.requestRender();
}

/** Undock: the open view in a window of its own, redrawn as the project changes. Dock brings it back as a tab. */
export function undockTab(app) {
  const view = app.activeView;
  if (!view || !app.controllerFor?.(view)?.graphical) return toast('Open a plan, section, elevation, 3D view or layout first.');
  const win = window.open('', `bd-${view.id}`, 'width=1100,height=800');
  if (!win) return toast('The browser stopped the new window. Allow pop-ups for this page and try again.', { kind: 'error' });
  win.document.title = view.name;
  win.document.body.style.cssText = 'margin:0;background:#fff;display:flex;align-items:center;justify-content:center;height:100vh';
  const img = win.document.createElement('img');
  img.alt = view.name;
  img.style.cssText = 'max-width:100%;max-height:100%';
  win.document.body.append(img);
  const draw = () => {
    if (win.closed) return;
    try {
      img.src = renderViewImage(app, app.doc.get(view.id), Math.max(600, win.innerWidth) * 2, Math.max(400, win.innerHeight) * 2, { fit: true }).canvas.toDataURL('image/png');
    } catch (err) {
      console.warn('Undocked window', err);
    }
  };
  let timer = 0;
  const off = app.doc.on((ev) => {
    if (ev.preview) return;
    clearTimeout(timer);
    timer = setTimeout(draw, 300);
  });
  draw();
  (app.undocked ||= new Map()).set(view.id, { win, off });
  win.addEventListener('beforeunload', () => {
    off?.();
    app.undocked?.delete(view.id);
  });
  app.closeView(view.id, true);
}

/** Dock Window: every undocked view back as a tab. */
export function dockWindows(app) {
  if (!app.undocked?.size) return toast('No view is in a window of its own.');
  for (const [id, u] of [...app.undocked]) {
    u.off?.();
    u.win.close();
    app.undocked.delete(id);
    if (app.doc.has(id)) app.openView(id);
  }
}
