/**
 * 3D Document commands: New 3D Document (from the 3D view's viewpoint),
 * 3D Document Settings (scale, source, precision, rebuild), Open 3D
 * Documents and Last 3D Document. The drawing is made in core/doc3d.js.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { MODEL_KINDS } from '../core/scene.js';
import { rebuildDocument3d, isDocument3d } from '../core/doc3d.js';
import { newId } from '../core/doc.js';
import { uniqueName } from '../core/ops.js';

const meshOf = (app) => (el) => app.scene.mesh(el);
const docs3d = (app) => app.doc.all('drafting').filter(isDocument3d);

/** The camera to start from: the active 3D view's live camera, else the first 3D view's. */
function sourceCamera(app) {
  const v = app.activeView;
  if (v?.kind === 'view3d') return { view: v, camera: structuredClone(app.vc?.cam || v.camera) };
  const first = app.doc.all('view3d')[0];
  return first ? { view: first, camera: structuredClone(app.viewStates?.get(first.id) || first.camera) } : null;
}

export function newDocument3d(app) {
  const src = sourceCamera(app);
  if (!src) return app.toast('Make a 3D view first.', { kind: 'error' });
  const doc = app.doc;
  const view = {
    id: newId('v'),
    kind: 'drafting',
    name: uniqueName(doc.all('drafting').map((d) => d.name), `${src.view.name} - 3D Document`),
    scale: 100,
    detail: 'fine',
    hiddenCats: [],
    hiddenIds: [],
    doc3d: { camera: src.camera, sourceViewId: src.view.id, hiddenCats: [...(src.view.hiddenCats || [])], hiddenIds: [...(src.view.hiddenIds || [])], res: 20 },
  };
  let n = 0;
  app.commit('New 3D document', () => {
    doc.add(view);
    n = rebuildDocument3d(doc, doc.get(view.id), meshOf(app), MODEL_KINDS);
  });
  app.openView(view.id);
  app.zoomFit?.();
  app.toast(`${view.name}: ${n} lines from the 3D viewpoint${src.camera.persp !== false ? ' (drawn as a parallel projection)' : ''}. Dimension and label it like any drawing; Rebuild after model changes.`, { kind: 'success' });
  return view;
}

export function rebuild3dDocument(app, id = app.activeView?.id) {
  const view = app.doc.get(id);
  if (!isDocument3d(view)) return app.toast('Open a 3D document first.', { kind: 'error' });
  let n = 0;
  app.commit('Rebuild 3D document', () => (n = rebuildDocument3d(app.doc, view, meshOf(app), MODEL_KINDS)));
  app.toast(`Rebuilt: ${n} lines. Your dimensions, texts and fills stay.`);
}

export function document3dSettings(app) {
  const view = app.activeView;
  if (!isDocument3d(view)) return app.toast('Open a 3D document first (Document > New 3D Document).', { kind: 'error' });
  const sources = app.doc.all('view3d');
  const src = h('select.input', { 'aria-label': 'Viewpoint' }, h('option', { value: '' }, 'Keep the current viewpoint'), ...sources.map((v) => h('option', { value: v.id }, `From ${v.name}`)));
  const scale = h('input.input', { type: 'number', min: 1, step: 1, value: +view.scale || 100, 'aria-label': 'Scale' });
  scale.addEventListener('keydown', (e) => e.stopPropagation());
  const res = h('select.input', { 'aria-label': 'Precision' }, ...[[10, 'Fine (10 mm)'], [20, 'Medium (20 mm)'], [40, 'Coarse (40 mm)']].map(([v, l]) => h('option', { value: v, selected: v === (+view.doc3d.res || 20) }, l)));
  const body = h(
    'div',
    h('label.field', h('span.field-label', 'Viewpoint'), src, h('span.field-hint', 'Take the current camera of a 3D view (open it and look first).')),
    h('div.row2', h('label.field', h('span.field-label', 'Scale 1:'), scale), h('label.field', h('span.field-label', 'Hidden-line precision'), res)),
  );
  return openDialog({ title: '3D Document Settings', body, actions: [{ label: 'Cancel', value: null }, { label: 'Rebuild', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const s = app.doc.get(src.value);
    const doc3d = { ...view.doc3d, res: +res.value || 20 };
    if (s) Object.assign(doc3d, { sourceViewId: s.id, camera: structuredClone(app.viewStates?.get(s.id) || s.camera), hiddenCats: [...(s.hiddenCats || [])], hiddenIds: [...(s.hiddenIds || [])] });
    app.commit('3D document settings', () => {
      app.doc.update(view.id, { scale: Math.max(1, +scale.value || 100), doc3d });
      rebuildDocument3d(app.doc, app.doc.get(view.id), meshOf(app), MODEL_KINDS);
    });
    app.requestRender();
  });
}

export function open3dDocuments(app) {
  const list = docs3d(app);
  if (!list.length) return app.toast('No 3D documents yet: Document > New 3D Document.', { kind: 'error' });
  const open = (e, id) => {
    e.currentTarget.closest('dialog')?.dispatchEvent(new Event('cancel'));
    app.openView(id);
  };
  const body = h('div.list', ...list.map((v) => h('button.btn', { type: 'button', style: { display: 'block', width: '100%', textAlign: 'left', marginBottom: '4px' }, onClick: (e) => open(e, v.id) }, `${v.name}  (1:${v.scale || 100})`)));
  return openDialog({ title: 'Open 3D Documents', body, actions: [{ label: 'Close', value: null }] });
}

export function last3dDocument(app) {
  const id = app.doc.get(app.lastDocument3dId) ? app.lastDocument3dId : docs3d(app).at(-1)?.id;
  if (!id) return app.toast('No 3D documents yet: Document > New 3D Document.', { kind: 'error' });
  app.openView(id);
}
