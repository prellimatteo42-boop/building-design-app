/**
 * Library Manager (File > Libraries and Objects): the libraries the project's
 * objects come from, duplicates, missing parts and macros, unused parts
 * (core/libmanager.js), with Add Library, Reload Libraries and Remove Unused.
 */
import { h } from './dom.js';
import { openDialog, toast, confirmDialog } from './dialog.js';
import { libraryReport } from '../core/libmanager.js';

export function libraryManagerDialog(app) {
  const doc = app.doc;
  const body = h('div');
  const table = (head, rows) => h('div', { style: { maxHeight: '22vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', ...head.map((x) => h('th', x)))), h('tbody', rows)));
  const show = (ids) => h('button.btn.sm', { type: 'button', onClick: () => app.showElements(ids) }, 'Show');
  const render = () => {
    const r = libraryReport(doc);
    body.replaceChildren(
      h('h3.dlg-sub', `Libraries · ${r.libraries.length}`),
      r.libraries.length ? table(['Library', 'Parts', 'Placed'], r.libraries.map((l) => h('tr', h('td', l.name), h('td.num', String(l.parts)), h('td.num', String(l.placed))))) : h('p.field-hint', 'No GDL objects in the project yet: add an Archicad library or save a selection as an object.'),
      h('h3.dlg-sub', `Duplicates · ${r.duplicates.length}`),
      r.duplicates.length ? table(['Name', 'In libraries'], r.duplicates.map((d) => h('tr', h('td', d.name), h('td', d.libraries.join(', '))))) : h('p.field-hint', 'No object name comes from two libraries.'),
      h('h3.dlg-sub', `Missing · ${r.missing.length + r.macros.length}`),
      r.missing.length || r.macros.length
        ? table(['Element or part', 'Problem', ''], [...r.missing.map((m) => h('tr', h('td', `${m.kind} ${m.id}`), h('td', m.problem), h('td', show([m.id])))), ...r.macros.map((m) => h('tr', h('td', m.name), h('td', `calls macros it lacks: ${m.missing.slice(0, 4).join(', ')}`), h('td', '')))])
        : h('p.field-hint', 'Every placed object has its part, and every part its macros.'),
      h('h3.dlg-sub', `Unused parts · ${r.unused.length}`),
      r.unused.length ? h('p.field-hint', r.unused.slice(0, 12).map((u) => u.name).join(', ') + (r.unused.length > 12 ? ` and ${r.unused.length - 12} more` : '')) : h('p.field-hint', 'Every part is placed.'),
      h(
        'div.row-actions',
        h('button.btn.sm', { type: 'button', onClick: () => (body.closest('dialog')?._close(null), app.run('archicadLibrary')) }, 'Add Library...'),
        h('button.btn.sm', { type: 'button', onClick: () => (body.closest('dialog')?._close(null), app.run('reloadLibraries')) }, 'Reload Libraries'),
        h(
          'button.btn.sm',
          {
            type: 'button',
            disabled: !r.unused.length,
            onClick: async () => {
              if (!(await confirmDialog('Remove unused parts?', `${r.unused.length} objects no element uses will be removed from the project library.`, { confirm: 'Remove', danger: true }))) return;
              app.commit('Remove unused library parts', () => r.unused.forEach((u) => doc.remove(u.id)));
              toast(`${r.unused.length} unused parts removed.`);
              render();
            },
          },
          'Remove Unused...',
        ),
      ),
    );
  };
  render();
  return openDialog({ title: 'Library Manager', size: 'lg', body, actions: [{ label: 'Close', value: null }] });
}
