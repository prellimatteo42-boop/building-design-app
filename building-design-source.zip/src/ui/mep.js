/**
 * MEP dialogs, as Archicad's MEP System Browser and MEP Model Quality: the
 * networks of the model with their runs, terminals, length and open
 * connections, and the list of problems, each with a button to show it.
 */
import { h, clear } from './dom.js';
import { openDialog } from './dialog.js';
import { mepNetworks, mepQuality, connectedMep } from '../core/mepnet.js';
import { KIND_LABEL } from '../core/catalog.js';

const show = (app, ids) => app.showElements(ids);

export function mepSystemBrowser(app) {
  const doc = app.doc;
  const body = h('div');
  const nets = mepNetworks(doc).sort((a, b) => a.kind.localeCompare(b.kind) || a.system.localeCompare(b.system) || b.length - a.length);
  if (!nets.length) body.append(h('p.props-empty', 'No ducts, pipes, cable trays or conduits yet.'));
  else {
    const tbody = h('tbody');
    nets.forEach((n, i) => {
      tbody.append(
        h(
          'tr',
          h('td', `${KIND_LABEL[n.kind] || n.kind} network ${i + 1}`),
          h('td', n.system),
          h('td.num', String(n.runs.length)),
          h('td.num', String(n.terminals.length)),
          h('td.num', `${(n.length / 1000).toFixed(2)} m`),
          h('td.num', n.openEnds.length ? h('b', String(n.openEnds.length)) : '0'),
          h('td', h('button.btn.sm', { type: 'button', onClick: () => show(app, [...n.runs, ...n.terminals]) }, 'Select')),
        ),
      );
    });
    body.append(h('table.vg-table', h('thead', h('tr', h('th', 'Network'), h('th', 'System'), h('th', 'Runs'), h('th', 'Terminals'), h('th', 'Length'), h('th', 'Open ends'), h('th', h('span.sr-only', 'Select')))), tbody));
    body.append(h('p.field-hint', 'Runs that meet end to end, or where one ends on another (a tee), form a network; terminals and equipment at a run end belong to it.'));
  }
  return openDialog({ title: 'MEP System Browser', body, size: 'lg', actions: [{ label: 'Model Quality...', value: 'q' }, { label: 'Close', primary: true, value: null }] }).then((r) => r === 'q' && mepQualityDialog(app));
}

export function mepQualityDialog(app) {
  const doc = app.doc;
  const body = h('div');
  const render = () => {
    clear(body);
    const issues = mepQuality(doc);
    if (!issues.length) {
      body.append(h('p.props-empty', 'No problems found: every run is connected and sizes and systems match at the joints.'));
      return;
    }
    const counts = {};
    for (const i of issues) counts[i.kind] = (counts[i.kind] || 0) + 1;
    const LABEL = { open: ['open connection', 'open connections'], size: ['size change', 'size changes'], system: ['system change', 'system changes'], zero: ['run of no length', 'runs of no length'], overlap: ['overlapping run', 'overlapping runs'], fall: ['sanitary pipe without fall', 'sanitary pipes without fall'] };
    body.append(h('p', Object.entries(counts).map(([k, n]) => `${n} ${LABEL[k][n === 1 ? 0 : 1]}`).join(', ') + '.'));
    const tbody = h('tbody');
    for (const i of issues.slice(0, 200)) tbody.append(h('tr', h('td', i.message), h('td', i.ids.map((id) => KIND_LABEL[doc.get(id)?.kind] || '').join(', ')), h('td', h('button.btn.sm', { type: 'button', onClick: () => show(app, i.ids) }, 'Show'))));
    body.append(h('table.vg-table', h('thead', h('tr', h('th', 'Problem'), h('th', 'Elements'), h('th', h('span.sr-only', 'Show')))), tbody));
  };
  render();
  return openDialog({ title: 'MEP Model Quality', body, size: 'lg', actions: [{ label: 'Close', primary: true, value: null }] });
}

/** Select Connected MEP Elements: the networks of the selected runs and terminals. */
/** The horizontal runs among a set of ids. */
export function horizontalRuns(doc, ids) {
  return [...ids].filter((id) => {
    const e = doc.get(id);
    return e?.a && e?.b && Math.hypot(e.b[0] - e.a[0], e.b[1] - e.a[1]) > 1 && Math.abs(+e.endOffset || 0) < 1;
  });
}

export function selectConnectedMep(app) {
  const ids = connectedMep(app.doc, [...app.selection]);
  if (!ids.size) return app.toast('Select a duct, pipe, cable tray, conduit or a terminal on one.', { kind: 'error' });
  app.select([...ids]);
  app.toast(`Selected ${ids.size} connected element${ids.size === 1 ? '' : 's'}.`);
}
