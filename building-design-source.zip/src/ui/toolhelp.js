/** What each Toolbox tool is for and how to use it, shown when the pointer rests on it (Italian; other languages use the command's description). */
const HELP = {
  modify: ['Seleziona gli elementi per vederli, modificarli o spostarli.', ['Clicca un elemento per selezionarlo', 'Trascina una maniglia per cambiarne la forma', 'Premi Esc per deselezionare']],
  marquee: ['Definisce un\'area di lavoro: quello che è dentro si può copiare, stampare o isolare in 3D.', ['Clicca il primo angolo', 'Clicca l\'angolo opposto']],
  wall: ['Disegna i muri dell\'edificio, dritti o curvi, a uno o più strati.\nSi uniscono da soli agli angoli.', ['Clicca il punto iniziale', 'Clicca i punti successivi', 'Premi Esc per finire']],
  floor: ['Crea solai e pavimenti seguendo un contorno, anche con fori.', ['Clicca i vertici del contorno', 'Premi Invio per chiudere']],
  column: ['Posiziona pilastri rettangolari o tondi.\nSi uniscono ai muri in cui stanno.', ['Scegli il tipo', 'Clicca dove posizionarlo']],
  beam: ['Disegna travi orizzontali o inclinate.\nSi fermano sulla faccia dei pilastri.', ['Clicca l\'inizio', 'Clicca la fine']],
  door: ['Inserisce porte nei muri: il foro si apre da solo.\nScegli il lato di apertura muovendo il mouse.', ['Scegli il tipo di porta', 'Clicca sul muro dove vuoi la porta']],
  window: ['Inserisce finestre nei muri, con davanzale e altezza.', ['Scegli il tipo', 'Clicca sul muro']],
  component: ['Inserisce arredi e oggetti di libreria: tavoli, letti, sanitari, cucine.', ['Scegli l\'oggetto', 'Clicca dove metterlo', 'Premi la barra per ruotarlo']],
  roof: ['Crea tetti a una o più falde su un contorno o sui muri.', ['Scegli il metodo: muri o contorno', 'Clicca i muri o i vertici', 'Premi Invio per finire']],
  shell: ['Crea coperture curve: volte, cupole e forme estruse.', ['Clicca i punti che ne definiscono la base']],
  stair: ['Disegna scale dritte, a L, a U o a chiocciola.\nAlzate e pedate si calcolano da sole.', ['Clicca la partenza', 'Clicca la direzione di salita']],
  railing: ['Disegna ringhiere e parapetti lungo un percorso.', ['Clicca i punti del percorso', 'Premi Invio per finire']],
  curtainWall: ['Progetta facciate continue con griglia, montanti e pannelli.', ['Clicca l\'inizio', 'Clicca la fine']],
  skylight: ['Inserisce un lucernario su un tetto.', ['Clicca su una falda del tetto']],
  cornerWindow: ['Crea una finestra che gira attorno all\'angolo di due muri.', ['Clicca vicino all\'angolo tra due muri']],
  opening: ['Apre un foro semplice in un muro.', ['Clicca sul muro', 'Imposta larghezza e altezza']],
  wallEnd: ['Dà ai muri selezionati una testata arrotondata o un pilastrino.', ['Seleziona il muro', 'Avvia lo strumento']],
  topo: ['Modella il terreno da punti con quota.', ['Clicca i punti del terreno', 'Premi Invio per finire']],
  morph: ['Crea forme libere da modellare come vuoi.', ['Clicca i vertici della base', 'Premi Invio', 'Trascina le maniglie']],
  room: ['Crea una zona in una stanza e ne calcola area e volume.', ['Clicca dentro la stanza']],
  section: ['Taglia il progetto con una linea e crea la vista in sezione.', ['Clicca l\'inizio della linea', 'Clicca la fine', 'Clicca da che parte guardare']],
  elevation: ['Crea un alzato dell\'edificio da un lato.', ['Clicca dove vuoi il punto di vista', 'Clicca verso cosa guardare']],
  interiorElevations: ['Crea gli alzati interni di una stanza, una vista per parete.', ['Clicca dentro la stanza']],
  callout: ['Ingrandisce una parte del disegno in una vista di dettaglio.', ['Clicca un angolo della zona', 'Clicca l\'angolo opposto']],
  draftingView: ['Apre un foglio di lavoro per disegnare a mano libera.', ['Dai un nome al foglio']],
  flythrough: ['Crea percorsi di camera per le animazioni.', ['Clicca i punti del percorso']],
  dimension: ['Quota distanze legate agli elementi: se muovi il muro, la quota si aggiorna.', ['Clicca i punti da quotare', 'Premi Invio', 'Clicca dove mettere la linea']],
  spotElevation: ['Indica la quota altimetrica di un punto.', ['Clicca il punto']],
  dimRadial: ['Quota il raggio di archi e cerchi.', ['Clicca l\'arco']],
  dimAngular: ['Quota l\'angolo tra due linee.', ['Clicca le due linee']],
  text: ['Scrive un testo nel disegno.', ['Clicca dove scrivere', 'Digita il testo']],
  tag: ['Etichetta un elemento con i suoi dati.', ['Clicca l\'elemento']],
  revisionCloud: ['Evidenzia una modifica con una nuvola di revisione.', ['Clicca i punti attorno alla modifica', 'Premi Invio']],
  detailLine: ['Disegna linee 2D di dettaglio.', ['Clicca l\'inizio', 'Clicca la fine']],
  detailArc: ['Disegna archi e cerchi 2D.', ['Clicca il centro', 'Clicca il raggio']],
  spline: ['Disegna curve morbide.', ['Clicca i punti', 'Premi Invio']],
  region: ['Campisce un\'area con un retino.', ['Clicca i vertici', 'Premi Invio']],
  hotspot: ['Crea un punto di aggancio.', ['Clicca il punto']],
  importImage: ['Inserisce un\'immagine nel disegno.', ['Scegli il file', 'Clicca dove metterla']],
  placeView: ['Mette una vista su un layout di stampa.', ['Scegli la vista', 'Scegli il layout']],
};

/** { text, steps } for a tool (text only in Italian), or null when it has no explanation. */
export function toolHelp(cmd, lang) {
  const h = HELP[cmd];
  if (!h) return null;
  return lang === 'it' ? { text: h[0], steps: h[1] } : { text: null, steps: [] };
}

export const TOOLS_WITH_HELP = Object.keys(HELP);
