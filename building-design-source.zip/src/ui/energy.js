/**
 * Energy Evaluation dialog, as Archicad's: the zones' design heat loss, the
 * annual balance month by month with its climate and systems, the Energy
 * Model Review (every envelope part with its area, U-value and facing) and
 * the energy source factors and costs.
 */
import { h, clear } from './dom.js';
import { openDialog } from './dialog.js';
import { ENERGY_DEFAULTS, energyReport } from '../core/energy.js';
import { annualEnergy, CLIMATES, HEATING_SYSTEMS, SOURCES, climateFor, energySettings, buildingSystems, thermalBlocks, VENTILATION, METHODS } from '../core/energysim.js';
import { parseEPW, climateFromEPW, PROFILES } from '../core/energyhourly.js';
import { newId } from '../core/doc.js';
import { toast } from './dialog.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const f1 = (v) => (Math.round(v * 10) / 10).toLocaleString();
const f0 = (v) => Math.round(v).toLocaleString();
const COMPASS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
const facing = (az) => (az == null ? '—' : `${COMPASS[Math.round(az / 45) % 8]} (${Math.round(az)}°)`);

export function energyDialog(app) {
  const doc = app.doc;
  const energy = () => ({ ...ENERGY_DEFAULTS, ...doc.get('project')?.energy });
  const save = (patch) => app.commit('Energy settings', () => doc.update('project', { energy: { ...energy(), ...patch } }));
  let tab = 'annual';
  const tabs = [
    { id: 'annual', label: 'Annual Balance' },
    { id: 'loss', label: 'Heat Loss' },
    { id: 'systems', label: 'Building Systems' },
    { id: 'blocks', label: 'Thermal Blocks' },
    { id: 'review', label: 'Energy Model Review' },
    { id: 'sources', label: 'Energy Sources' },
  ];
  const bar = h('div.tabs', { role: 'tablist' });
  const panel = h('div', { role: 'tabpanel', style: { minHeight: '320px' } });
  const num = (key, label, step, value, hint) => {
    const i = h('input.input', { type: 'number', step, value, 'aria-label': label });
    i.addEventListener('keydown', (e) => e.stopPropagation());
    i.addEventListener('change', () => Number.isFinite(+i.value) && (save({ [key]: +i.value }), render()));
    return field(label, i, hint);
  };
  const select = (key, label, options, value) => {
    const s = h('select.input', { 'aria-label': label }, options.map((o) => h('option', { value: o.value }, o.label)));
    s.value = value;
    s.addEventListener('change', () => (save({ [key]: s.value }), render()));
    return field(label, s);
  };

  const annual = () => {
    const r = annualEnergy(doc, app.scene);
    if (!r.report.rows.length) return h('p.field-hint', 'No enclosed rooms (zones) to evaluate. Place rooms first.');
    const s = r.settings;
    const climateSel = h('select.input', { 'aria-label': 'Climate' }, h('option', { value: '' }, `From the project location (${climateFor({ ...doc.get('project'), energy: {} }).name})`), CLIMATES.map((c) => h('option', { value: c.name }, c.name)));
    const ownClimate = doc.get('project')?.energy?.climate;
    if (ownClimate?.source === 'epw') climateSel.append(h('option', { value: '__epw' }, `${ownClimate.name} (weather file, hourly)`));
    climateSel.value = ownClimate?.source === 'epw' ? '__epw' : ownClimate?.name && CLIMATES.some((c) => c.name === ownClimate.name) ? ownClimate.name : '';
    climateSel.addEventListener('change', () => climateSel.value !== '__epw' && (save({ climate: CLIMATES.find((c) => c.name === climateSel.value) || null }), render()));
    const epwInput = h('input', { type: 'file', accept: '.epw', hidden: true, 'aria-label': 'Weather file' });
    epwInput.addEventListener('change', async () => {
      const f = epwInput.files?.[0];
      if (!f) return;
      try {
        const c = climateFromEPW(parseEPW(await f.text()));
        save({ climate: c });
        toast(`Climate from ${f.name}: ${c.name}, hourly data.`);
        render();
      } catch (err) {
        toast(err.message || 'The weather file could not be read.', { kind: 'error' });
      }
    });
    const importBtn = h('button.btn.sm', { type: 'button', onClick: () => epwInput.click() }, 'Import Weather File (EPW)...');
    const sys = HEATING_SYSTEMS.find((x) => x.value === s.heatingSystem);
    const settings = h(
      'div',
      h('div.row2', field('Climate', climateSel, h('span', importBtn, epwInput)), select('heatingSystem', 'Heating system', HEATING_SYSTEMS, s.heatingSystem)),
      h('div.row2', select('method', 'Calculation', METHODS, r.method), select('profile', 'Internal gains profile (hourly)', Object.entries(PROFILES).map(([value, x]) => ({ value, label: x.label })), s.profile)),
      h(
        'div.row2',
        num('heatingEfficiency', sys.source === 'electricity' && sys.efficiency > 1 ? 'Heating COP' : 'Heating efficiency', 0.05, s.heatingEfficiency),
        num('coolingEfficiency', 'Cooling EER', 0.1, s.coolingEfficiency),
      ),
      h('div.row2', num('inside', 'Heating set point (°C)', 0.5, s.inside), num('cooling', 'Cooling set point (°C)', 0.5, s.cooling)),
      h('div.row2', select('coolingOn', 'Cooling', [{ value: 'true', label: 'Cooled' }, { value: 'false', label: 'Not cooled (count overheating)' }], String(s.coolingOn)), num('setback', 'Night setback (°C, hourly; empty = none)', 0.5, s.setback ?? '')),
      h(
        'div.row2',
        num('internalGains', 'Internal gains (W/m²)', 0.5, s.internalGains),
        select('mass', 'Thermal mass', [{ value: 'light', label: 'Light (timber, drywall)' }, { value: 'medium', label: 'Medium' }, { value: 'heavy', label: 'Heavy (masonry, concrete)' }], s.mass),
      ),
    );
    // Monthly bars: heating below the axis in red, cooling above in blue.
    const W = 640;
    const H = 180;
    const max = Math.max(1, ...r.months.map((m) => Math.max(m.heating, m.cooling)));
    const bw = W / 12;
    const mid = H / 2;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${W} ${H + 18}`);
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', 'Monthly heating and cooling needs');
    svg.style.width = '100%';
    const el = (tag, attrs, text) => {
      const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
      for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
      if (text != null) e.textContent = text;
      svg.append(e);
      return e;
    };
    el('line', { x1: 0, x2: W, y1: mid, y2: mid, stroke: 'currentColor', 'stroke-opacity': 0.4 });
    r.months.forEach((m, i) => {
      const x = i * bw + bw * 0.18;
      const hh = (m.heating / max) * (mid - 4);
      const ch = (m.cooling / max) * (mid - 4);
      if (hh > 0.5) el('rect', { x, y: mid, width: bw * 0.64, height: hh, fill: '#d9534f', rx: 2 }).append(Object.assign(document.createElementNS('http://www.w3.org/2000/svg', 'title'), { textContent: `${m.month}: heating ${f0(m.heating)} kWh` }));
      if (ch > 0.5) el('rect', { x, y: mid - ch, width: bw * 0.64, height: ch, fill: '#3d7fc4', rx: 2 }).append(Object.assign(document.createElementNS('http://www.w3.org/2000/svg', 'title'), { textContent: `${m.month}: cooling ${f0(m.cooling)} kWh` }));
      el('text', { x: i * bw + bw / 2, y: H + 14, 'text-anchor': 'middle', 'font-size': 11, fill: 'currentColor' }, m.month);
    });
    el('text', { x: W - 4, y: 12, 'text-anchor': 'end', 'font-size': 11, fill: '#3d7fc4' }, '▲ Cooling');
    el('text', { x: W - 4, y: H - 4, 'text-anchor': 'end', 'font-size': 11, fill: '#d9534f' }, '▼ Heating');
    const a = r.annual;
    const tb = h('tbody');
    for (const m of r.months) tb.append(h('tr', h('td', m.month), h('td.num', f1(m.te)), h('td.num', f0(m.loss)), h('td.num', f0(m.solar)), h('td.num', f0(m.internal)), h('td.num', f0(m.heating)), h('td.num', f0(m.cooling))));
    const kv = (k, v) => h('tr', h('td', k), h('td.num', v));
    return h(
      'div',
      settings,
      svg,
      h(
        'div.row2',
        h(
          'table.layers-table.en-table',
          h(
            'tbody',
            kv('Heated floor area', `${f1(r.area)} m²`),
            kv('Heating need', `${f0(a.heating)} kWh/a · ${f1(a.heatingPerArea)} kWh/m²a`),
            kv('Cooling need', `${f0(a.cooling)} kWh/a · ${f1(a.coolingPerArea)} kWh/m²a`),
            a.peakHeating != null ? kv('Peak heating / cooling load', `${f0(a.peakHeating)} W / ${f0(a.peakCooling)} W`) : null,
            a.overheatingHours != null && !s.coolingOn ? kv('Hours over 26.5 °C', f0(a.overheatingHours)) : null,
            a.dhw ? kv('Hot water need', `${f0(a.dhw)} kWh/a${a.solarThermal ? ` (solar ${f0(a.solarThermal)})` : ''}`) : null,
            a.fans ? kv('Fans', `${f0(a.fans)} kWh/a`) : null,
            a.pv ? kv('Photovoltaics', `${f0(a.pv)} kWh/a (used ${f0(a.pvUsed)}, exported ${f0(a.pvExported)})`) : null,
            ...Object.entries(a.delivered).map(([k, v]) => kv(`Delivered: ${SOURCES[k]?.label ?? k}`, `${f0(v)} kWh/a`)),
            kv('Primary energy (non-renewable)', `${f0(a.primary)} kWh/a · ${f1(a.primaryPerArea)} kWh/m²a`),
            a.renewableShare ? kv('Renewable share', `${Math.round(a.renewableShare * 100)} %`) : null,
            kv('CO₂ emissions', `${f0(a.co2)} kg/a`),
            kv('Energy cost', `${f0(a.cost)} €/a`),
          ),
        ),
        h('div', { style: { maxHeight: '220px', overflow: 'auto' } }, h('table.layers-table.en-table', h('thead', h('tr', h('th', 'Month'), h('th', 'θe °C'), h('th', 'Losses kWh'), h('th', 'Solar kWh'), h('th', 'Internal kWh'), h('th', 'Heating kWh'), h('th', 'Cooling kWh'))), tb)),
      ),
      h(
        'p.field-hint',
        r.method === 'hourly'
          ? `Climate: ${r.climate.name}${r.climate.hourly ? ' (hourly weather file)' : ' (hours made up from the monthly means)'}. An hourly simulation: one thermal node per block with its mass, set points, night setback and gains profile, solar gains through the windows from the sun's position hour by hour.`
          : `Climate: ${r.climate.name}. A monthly balance (EN ISO 13790 method) from the zones' heat loss, solar gains through the windows by orientation and internal gains: a screening estimate to compare options.`,
      ),
    );
  };

  const loss = () => {
    const cur = energy();
    const out = h('div');
    const { rows, totals } = energyReport(doc, app.scene, cur);
    if (!rows.length) return h('p.field-hint', 'No enclosed rooms (zones) to evaluate. Place rooms first.');
    const tb = h('tbody');
    for (const r of rows.sort((a, b) => b.load - a.load))
      tb.append(h('tr', h('td', `${r.room.number ? `${r.room.number} ` : ''}${r.room.name || 'Room'}`, r.notes.length ? h('span.en-note', { 'data-tip': r.notes.join('\n'), 'aria-label': r.notes.join('. ') }, ' ⚠') : null), h('td.num', f1(r.area)), h('td.num', f1(r.volume)), h('td.num', f1(r.walls)), h('td.num', f1(r.windows)), h('td.num', f1(r.HT)), h('td.num', f1(r.HV)), h('td.num', f0(r.load)), h('td.num', f1(r.perArea))));
    tb.append(h('tr.en-total', h('td', 'Building'), h('td.num', f1(totals.area)), h('td.num', f1(totals.volume)), h('td'), h('td'), h('td.num', f1(totals.HT)), h('td.num', f1(totals.HV)), h('td.num', f0(totals.load)), h('td.num', f1(totals.perArea))));
    out.append(
      h('p.field-hint', 'Design heat loss of each zone through exterior walls, windows and doors, the roof of the top story and the floor of the lowest one, and by ventilation (EN 12831 spirit).'),
      h('div.row2', num('inside', 'Inside temperature (°C)', 0.5, cur.inside), num('outside', 'Outside design temperature (°C)', 0.5, cur.outside), num('ach', 'Air changes per hour', 0.1, cur.ach), num('groundFactor', 'Ground floor factor', 0.05, cur.groundFactor, 'U of the lowest floor is multiplied by it.')),
      h('div', { style: { maxHeight: '45vh', overflow: 'auto' } }, h('table.layers-table.en-table', h('thead', h('tr', h('th', 'Zone'), h('th', 'Area m²'), h('th', 'Volume m³'), h('th', 'Ext. walls m²'), h('th', 'Windows m²'), h('th', 'H_T W/K'), h('th', 'H_V W/K'), h('th', 'Load W'), h('th', 'W/m²'))), tb)),
    );
    return out;
  };

  const systems = () => {
    const sys = buildingSystems(doc.get('project'));
    const put = (key, patch) => (save({ [key]: { ...sys[key], ...patch } }), render());
    const n = (label, value, step, onSet, hint) => {
      const i = h('input.input', { type: 'number', step, value: value ?? '', 'aria-label': label });
      i.addEventListener('keydown', (e) => e.stopPropagation());
      i.addEventListener('change', () => Number.isFinite(+i.value) && onSet(+i.value));
      return field(label, i, hint);
    };
    const sel = (label, options, value, onSet) => {
      const x = h('select.input', { 'aria-label': label }, options.map((o) => h('option', { value: o.value }, o.label)));
      x.value = value;
      x.addEventListener('change', () => onSet(x.value));
      return field(label, x);
    };
    const v = sys.ventilation;
    return h(
      'div',
      h('h3.dlg-sub', 'Ventilation'),
      h(
        'div.row2',
        sel('Ventilation', VENTILATION, v.type, (x) => put('ventilation', { type: x })),
        n('Mechanical air changes (1/h)', v.ach, 0.05, (x) => put('ventilation', { ach: x })),
        n('Heat recovery efficiency', v.recovery, 0.05, (x) => put('ventilation', { recovery: x })),
        n('Specific fan power (W per m³/h)', v.sfp, 0.05, (x) => put('ventilation', { sfp: x })),
      ),
      h('h3.dlg-sub', 'Domestic Hot Water'),
      h(
        'div.row2',
        n('Hot water need (kWh/m²a; 0 = not counted)', sys.dhw.demand, 1, (x) => put('dhw', { demand: x }), 'Typical: 12–20 for homes.'),
        sel('Hot water system', [{ value: 'heating', label: 'Same as heating' }, ...HEATING_SYSTEMS], sys.dhw.system, (x) => put('dhw', { system: x })),
        n('Solar thermal collectors (m²)', sys.solarThermal, 0.5, (x) => (save({ solarThermal: x }), render())),
      ),
      h('h3.dlg-sub', 'Photovoltaics'),
      h(
        'div.row2',
        n('Peak power (kWp)', sys.pv.kwp, 0.1, (x) => put('pv', { kwp: x })),
        n('Tilt (degrees)', sys.pv.tilt, 1, (x) => put('pv', { tilt: x })),
        n('Facing (degrees from north, 180 = south)', sys.pv.azimuth, 5, (x) => put('pv', { azimuth: x })),
        n('Share used on site (0–1)', sys.pv.selfUse, 0.05, (x) => put('pv', { selfUse: x }), 'About 0.3–0.4 without a battery, 0.6–0.8 with one.'),
      ),
      h('p.field-hint', 'Solar thermal and photovoltaic yields come from the hourly irradiation of the climate on the collectors (30% of it reaches the hot water, at most 95% of each month\'s need; photovoltaics with a 0.8 performance ratio). The share of photovoltaic power used on site offsets the electricity bought; the rest is exported.'),
    );
  };

  const blocks = () => {
    const report = energyReport(doc, app.scene, energy());
    if (!report.rows.length) return h('p.field-hint', 'No enclosed rooms (zones) to evaluate. Place rooms first.');
    const defs = energy().blocks || [];
    const setBlocks = (list) => (save({ blocks: list }), render());
    const r = annualEnergy(doc, app.scene);
    const result = new Map(r.blocks.map((b) => [b.id, b]));
    const roomName = (room) => `${room.number ? `${room.number} ` : ''}${room.name || 'Room'}`;
    const out = h('div', h('p.field-hint', 'Thermal blocks group zones that are used and conditioned alike. Each block has its own set points, internal gains, air changes and gains profile; zones in no block use the settings of the Annual Balance.'));
    const s = energySettings(doc.get('project'));
    const blockRow = (b, k) => {
      const upd = (patch) => setBlocks(defs.map((x, i) => (i === k ? { ...x, ...patch } : x)));
      const numIn = (key, label, step) => {
        const i = h('input.input.sm', { type: 'number', step, value: b[key] ?? '', placeholder: String(key === 'ach' ? report.settings.ach : s[key] ?? ''), 'aria-label': `${b.name} ${label}`, style: { width: '72px' } });
        i.addEventListener('keydown', (e) => e.stopPropagation());
        i.addEventListener('change', () => upd({ [key]: i.value === '' ? undefined : +i.value }));
        return h('td', i);
      };
      const name = h('input.input.sm', { type: 'text', value: b.name, 'aria-label': 'Block name', style: { width: '130px' } });
      name.addEventListener('keydown', (e) => e.stopPropagation());
      name.addEventListener('change', () => upd({ name: name.value || b.name }));
      const prof = h('select.input.sm', { 'aria-label': `${b.name} profile` }, h('option', { value: '' }, 'As building'), Object.entries(PROFILES).map(([value, x]) => h('option', { value }, x.label)));
      prof.value = b.profile || '';
      prof.addEventListener('change', () => upd({ profile: prof.value || undefined }));
      const res = result.get(b.id)?.result;
      return h(
        'tr',
        h('td', name),
        numIn('inside', 'heating set point', 0.5),
        numIn('cooling', 'cooling set point', 0.5),
        numIn('internalGains', 'internal gains', 0.5),
        numIn('ach', 'air changes', 0.1),
        h('td', prof),
        h('td.num', res ? f0(res.heating) : '—'),
        h('td.num', res ? f0(res.cooling) : '—'),
        h('td', h('button.btn.sm', { type: 'button', onClick: () => setBlocks(defs.filter((_, i) => i !== k)) }, 'Delete')),
      );
    };
    const tb = h('tbody', defs.map(blockRow));
    const def = result.get('default');
    if (def) tb.append(h('tr.en-total', h('td', def.name), h('td', { colspan: 5 }, 'Annual Balance settings'), h('td.num', f0(def.result.heating)), h('td.num', f0(def.result.cooling)), h('td')));
    out.append(h('table.layers-table.en-table', h('thead', h('tr', h('th', 'Block'), h('th', 'Heat °C'), h('th', 'Cool °C'), h('th', 'Gains W/m²'), h('th', 'ACH'), h('th', 'Profile'), h('th', 'Heating kWh'), h('th', 'Cooling kWh'), h('th', h('span.sr-only', 'Delete')))), tb));
    out.append(h('div', { style: { marginTop: '6px' } }, h('button.btn.sm', { type: 'button', onClick: () => setBlocks([...defs, { id: newId('tb'), name: `Block ${defs.length + 1}`, roomIds: [] }]) }, 'New Block')));
    // Zones and their block.
    if (defs.length) {
      const zt = h('tbody');
      const owner = (room) => defs.find((b) => b.roomIds?.includes(room.id))?.id || '';
      for (const row of report.rows) {
        const sel = h('select.input.sm', { 'aria-label': `Block of ${roomName(row.room)}` }, h('option', { value: '' }, 'Other zones'), defs.map((b) => h('option', { value: b.id }, b.name)));
        sel.value = owner(row.room);
        sel.addEventListener('change', () => setBlocks(defs.map((b) => ({ ...b, roomIds: (b.roomIds || []).filter((id) => id !== row.room.id).concat(b.id === sel.value ? [row.room.id] : []) }))));
        zt.append(h('tr', h('td', roomName(row.room)), h('td.num', f1(row.area)), h('td', sel)));
      }
      out.append(h('h3.dlg-sub', 'Zones'), h('div', { style: { maxHeight: '30vh', overflow: 'auto' } }, h('table.layers-table.en-table', h('thead', h('tr', h('th', 'Zone'), h('th', 'Area m²'), h('th', 'Block'))), zt)));
    }
    void thermalBlocks;
    return out;
  };

  const review = () => {
    const { rows } = energyReport(doc, app.scene, energy());
    if (!rows.length) return h('p.field-hint', 'No enclosed rooms (zones) to evaluate. Place rooms first.');
    const tb = h('tbody');
    const KIND = { wall: 'Wall', window: 'Window', door: 'Door', roof: 'Roof', floor: 'Floor on ground' };
    const own = energy().uOverrides || {};
    // U-values can be set by hand per element (empty: back to the value from the materials).
    const uCell = (f) => {
      const i = h('input.input.sm', { type: 'number', step: 0.01, value: (Math.round(f.u * 100) / 100).toFixed(2), 'aria-label': `U of ${f.name}`, style: { width: '68px', fontWeight: own[f.id] != null ? '600' : '' } });
      i.addEventListener('keydown', (e) => e.stopPropagation());
      i.addEventListener('change', () => {
        const next = { ...own };
        if (i.value === '') delete next[f.id];
        else if (Number.isFinite(+i.value) && +i.value > 0) next[f.id] = +i.value;
        save({ uOverrides: next });
        render();
      });
      return h('td.num', i);
    };
    for (const r of rows)
      for (const f of r.faces || [])
        tb.append(h('tr', h('td', `${r.room.number ? `${r.room.number} ` : ''}${r.room.name || 'Room'}`), h('td', KIND[f.kind] || f.kind), h('td', f.name), h('td', facing(f.azimuth)), h('td.num', f1(f.area)), uCell(f), h('td.num', f.g ? f.g.toFixed(2) : ''), h('td', h('button.btn.sm', { type: 'button', onClick: () => app.showElements([f.id]) }, 'Show'))));
    return h(
      'div',
      h('p.field-hint', 'Every part of the thermal envelope of each zone, with its area, U-value (W/m²K) and the way it faces; windows with their solar factor g. U-values come from the building materials of the structures; type a value to set it for that element (bold), clear it to go back.'),
      h('div', { style: { maxHeight: '50vh', overflow: 'auto' } }, h('table.layers-table.en-table', h('thead', h('tr', h('th', 'Zone'), h('th', 'Part'), h('th', 'Structure'), h('th', 'Faces'), h('th', 'Area m²'), h('th', 'U'), h('th', 'g'), h('th', h('span.sr-only', 'Show')))), tb)),
    );
  };

  const sources = () => {
    const s = energySettings(doc.get('project'));
    const tb = h('tbody');
    for (const [k, v] of Object.entries(s.sources)) {
      const cell = (key, step) => {
        const i = h('input.input.sm', { type: 'number', step, value: v[key], 'aria-label': `${v.label} ${key}` });
        i.addEventListener('keydown', (e) => e.stopPropagation());
        i.addEventListener('change', () => {
          if (!Number.isFinite(+i.value)) return;
          const own = { ...(doc.get('project')?.energy?.sources || {}) };
          own[k] = { ...(own[k] || {}), [key]: +i.value };
          save({ sources: own });
        });
        return h('td', i);
      };
      tb.append(h('tr', h('td', v.label), cell('primary', 0.01), cell('co2', 0.01), cell('price', 0.01)));
    }
    return h('div', h('p.field-hint', 'Energy source factors (Archicad: Energy Source Factors and Energy Costs): non-renewable primary energy per kWh delivered, CO₂ emitted per kWh and price per kWh. Defaults are typical European values; set your own.'), h('table.layers-table.en-table', h('thead', h('tr', h('th', 'Source'), h('th', 'Primary energy factor'), h('th', 'kg CO₂ / kWh'), h('th', 'Price € / kWh'))), tb));
  };

  const render = () => {
    clear(bar);
    for (const t of tabs) bar.append(h('button.tab', { type: 'button', role: 'tab', 'aria-selected': String(t.id === tab), onClick: () => ((tab = t.id), render()) }, t.label));
    clear(panel);
    panel.append({ annual, loss, systems, blocks, review, sources }[tab]());
  };
  render();
  return openDialog({ title: 'Energy Evaluation', body: h('div', bar, panel), size: 'lg', actions: [{ label: 'Close', primary: true, value: null }] });
}
