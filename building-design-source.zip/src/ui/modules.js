/**
 * Modules and linked drawings: Save Selection as Module, Break Hotlink,
 * Save Hotlink as File, Link Drawing to..., Check Markers, Highlight Source
 * Markers, and the transmittal sets of the Layout Book.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { encodeProject, safeFileName, NATIVE_EXT } from '../io/native.js';
import { download } from '../io/storage.js';
import { moduleDoc, embedLink } from '../core/modules.js';
import { isView } from '../core/doc.js';
import * as T from '../core/transmittals.js';

const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const field = (label, control) => h('label.field', h('span.field-label', label), control);
const text = (value, label) => {
  const i = h('input.input', { type: 'text', value, 'aria-label': label });
  i.addEventListener('keydown', (e) => e.stopPropagation());
  return i;
};

export async function saveSelectionAsModule(app) {
  const ids = [...app.selection];
  if (!ids.length) return app.toast('Select the elements to save as a module.', { kind: 'error' });
  const mod = moduleDoc(app.doc, ids);
  const name = `${app.doc.project?.name || 'Module'} - module${NATIVE_EXT}`;
  download(await encodeProject(mod), safeFileName(name));
  app.toast(`Saved ${plural(ids.length, 'element')} as a module. Link it into other projects with Link Project.`, { kind: 'success' });
}

const selectedLink = (app) => [...app.selection].map((id) => app.doc.get(id)).find((el) => el?.kind === 'link');

export function breakHotlink(app, id = selectedLink(app)?.id) {
  const el = app.doc.get(id);
  if (el?.kind !== 'link') return app.toast('Select a linked project (module) first.', { kind: 'error' });
  const linked = app.scene.link(el)?.doc;
  if (!linked) return app.toast('The link could not be read.', { kind: 'error' });
  let res;
  app.commit('Break hotlink', () => (res = embedLink(app.doc, el, linked)));
  app.select(res.added);
  app.toast(`${el.name}: ${plural(res.added.length, 'element')} now belong to this project${res.levels.length ? `, ${plural(res.levels.length, 'new level')}` : ''}.`, { kind: 'success' });
  return res;
}

export async function saveHotlinkAsFile(app, id = selectedLink(app)?.id) {
  const el = app.doc.get(id);
  if (el?.kind !== 'link') return app.toast('Select a linked project (module) first.', { kind: 'error' });
  const linked = app.scene.link(el)?.doc;
  if (!linked) return app.toast('The link could not be read.', { kind: 'error' });
  download(await encodeProject(linked), safeFileName(`${el.name}${NATIVE_EXT}`));
}

/** Link Drawing to...: the selected drawing on a layout shows another view. */
export function linkDrawingTo(app) {
  const vp = [...app.selection].map((id) => app.doc.get(id)).find((el) => el?.kind === 'viewport');
  if (!vp) return app.toast('Select a drawing on a layout first.', { kind: 'error' });
  const views = app.doc.filter((v) => isView(v) && v.kind !== 'sheet' && v.kind !== 'schedule');
  const sel = h('select.input', { 'aria-label': 'View' }, ...views.map((v) => h('option', { value: v.id, selected: v.id === vp.placedId }, `${v.name} (${v.kind})`)));
  return openDialog({ title: 'Link Drawing to', body: h('div', field('Show this view', sel)), actions: [{ label: 'Cancel', value: null }, { label: 'Link', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok' || sel.value === vp.placedId) return;
    app.commit('Link drawing', () => app.doc.update(vp.id, { placedId: sel.value }));
    app.requestRender();
  });
}

/** Markers and drawings that point at nothing: [{ id, message }]. */
export function markerProblems(doc) {
  const out = [];
  for (const el of doc.all('viewRef')) if (!doc.get(el.targetId)) out.push({ id: el.id, message: 'A view marker points to a view that no longer exists.' });
  for (const el of doc.all('viewport')) if (!doc.get(el.placedId)) out.push({ id: el.id, message: 'A drawing on a layout shows a view that no longer exists.' });
  for (const v of doc.filter((x) => x.calloutOf)) if (!doc.get(v.calloutOf)) out.push({ id: v.id, message: `Detail ${v.name} belongs to a view that no longer exists.` });
  for (const el of doc.all('tag')) if (el.targetId && !doc.get(el.targetId)) out.push({ id: el.id, message: 'A tag labels an element that no longer exists.' });
  return out;
}

export function checkMarkers(app) {
  const list = markerProblems(app.doc);
  const body = list.length
    ? h('table.vg-table', h('tbody', ...list.map((p) => h('tr', h('td', p.message), h('td', h('button.btn.sm', { type: 'button', onClick: () => app.select([p.id]) }, 'Select'))))))
    : h('p', 'Every marker, drawing and tag points to something that exists.');
  const actions = [{ label: 'Close', value: null }];
  if (list.length) actions.unshift({ label: 'Delete them all', danger: true, value: 'del' });
  return openDialog({ title: 'Check Markers', body, actions }).then((r) => {
    if (r !== 'del') return;
    app.commit('Delete broken markers', () => list.forEach((p) => app.doc.has(p.id) && app.doc.get(p.id).kind !== 'plan' && app.doc.remove(p.id)));
  });
}

export function toggleSourceMarkers(app) {
  app.settingsStore.set('highlightSourceMarkers', !app.settings.highlightSourceMarkers);
  app.requestRender();
}

// Transmittal sets -----------------------------------------------------------------------------

const project = (app) => app.doc.project;
const apply = (app, label, patch) => (patch ? (app.commit(label, () => app.doc.update('project', patch)), true) : false);
const selectedSheets = (app) => {
  const ids = [...app.selection].filter((id) => app.doc.get(id)?.kind === 'sheet');
  if (ids.length) return ids;
  return app.activeView?.kind === 'sheet' ? [app.activeView.id] : [];
};

function setFields(t = {}) {
  const f = { name: text(t.name || '', 'Name'), date: text(t.date || new Date().toISOString().slice(0, 10), 'Date'), issuedTo: text(t.issuedTo || '', 'Issued to'), issuedBy: text(t.issuedBy || '', 'Issued by'), description: text(t.description || '', 'Description') };
  const body = h('div', h('div.row2', field('Name', f.name), field('Date', f.date)), h('div.row2', field('Issued to', f.issuedTo), field('Issued by', f.issuedBy)), field('Description', f.description));
  const values = () => Object.fromEntries(Object.entries(f).map(([k, i]) => [k, i.value.trim()]));
  return { body, values };
}

export function newTransmittalSet(app) {
  const { body, values } = setFields({ name: `Transmittal ${T.transmittalsOf(project(app)).length + 1}` });
  return openDialog({ title: 'Create New Transmittal Set', body, actions: [{ label: 'Cancel', value: null }, { label: 'Create', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    apply(app, 'New transmittal set', T.createSet(project(app), values()));
    const sheets = selectedSheets(app);
    if (sheets.length) apply(app, 'Add to transmittal set', T.addToCurrent(project(app), sheets));
    app.toast(`Transmittal set open${sheets.length ? ` with ${plural(sheets.length, 'layout')}` : ''}. Add layouts to it, then close it to send.`, { kind: 'success' });
  });
}

export function addToTransmittal(app, remove = false) {
  const sheets = selectedSheets(app);
  if (!sheets.length) return app.toast('Select layouts (or open one) first.', { kind: 'error' });
  if (!T.currentSet(project(app))) return app.toast('No transmittal set is open: create one first.', { kind: 'error' });
  apply(app, remove ? 'Remove from transmittal set' : 'Add to transmittal set', remove ? T.removeFromCurrent(project(app), sheets) : T.addToCurrent(project(app), sheets));
  app.toast(`${plural(sheets.length, 'layout')} ${remove ? 'taken out of' : 'added to'} ${T.currentSet(project(app)).name}.`);
}

export function closeTransmittal(app) {
  if (!apply(app, 'Close transmittal set', T.closeCurrent(project(app)))) return app.toast('No transmittal set is open.', { kind: 'error' });
}

export function reopenTransmittal(app) {
  if (!apply(app, 'Reopen transmittal set', T.reopenLast(project(app)))) return app.toast('A set is already open, or none has been made.', { kind: 'error' });
}

export function deleteTransmittal(app) {
  if (!apply(app, 'Delete transmittal set', T.deleteCurrent(project(app)))) return app.toast('No transmittal set is open.', { kind: 'error' });
}

export function transmittalDetails(app) {
  const cur = T.currentSet(project(app)) || T.transmittalsOf(project(app)).at(-1);
  if (!cur) return app.toast('No transmittal set yet.', { kind: 'error' });
  const { body, values } = setFields(cur);
  body.append(h('p.field-hint', `${cur.closed ? 'Closed' : 'Open'}. Layouts: ${cur.sheets.map((id) => app.doc.get(id)?.name || '?').join(', ') || 'none'}.`));
  return openDialog({ title: 'Transmittal Set Details', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r === 'ok') apply(app, 'Transmittal set details', T.updateSet(project(app), cur.id, values()));
  });
}

export function transmittalHistory(app) {
  const sheets = app.doc.all('sheet');
  const rows = sheets.map((s) => h('tr', h('td', `${s.number || ''} ${s.name}`), h('td', T.sheetHistory(project(app), s.id).map((t) => `${t.name} (${t.date}${t.issuedTo ? `, to ${t.issuedTo}` : ''})`).join('; ') || '—')));
  return openDialog({ title: 'Transmittal History', body: h('table.vg-table', h('thead', h('tr', h('th', 'Layout'), h('th', 'Sent in'))), h('tbody', ...rows)), size: 'lg', actions: [{ label: 'Close', value: null }] });
}
