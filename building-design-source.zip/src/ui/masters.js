/**
 * Master Layouts dialog: the masters sheets follow, with their paper size,
 * margin, title block position and autotext rows, and a preview.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { icon } from './icons.js';
import { SHEET_SIZES } from '../core/props.js';
import { SHEET_FIELDS } from '../core/masters.js';
import { titleBlock, sheetSize } from '../core/sheet.js';
import { uniqueName } from '../core/ops.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);

const STRIPS = [
  { value: 'right', label: 'Title strip on the right' },
  { value: 'bottom', label: 'Title bar at the bottom' },
  { value: 'none', label: 'No title block' },
];

/** Draw a master's title block for a sample sheet into a canvas. */
function drawPreview(doc, master, canvas) {
  const sheet = { id: 'preview', kind: 'sheet', name: 'Ground Floor Plan', number: 'A101', size: master.size, masterId: master.id, drawnBy: doc.project?.author || '' };
  const { w, h: H } = sheetSize(sheet);
  const { builder } = titleBlock(doc, sheet);
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const k = Math.min((canvas.width - 10) / w, (canvas.height - 10) / H);
  const ox = (canvas.width - w * k) / 2;
  const oy = (canvas.height - H * k) / 2;
  const P = (p) => [ox + p[0] * k, canvas.height - oy - p[1] * k];
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(ox, oy, w * k, H * k);
  ctx.strokeStyle = '#222';
  for (const l of builder.lines) {
    ctx.lineWidth = Math.max(0.5, (l.w || 0.25) * k * 0.8);
    ctx.beginPath();
    ctx.moveTo(...P(l.a));
    ctx.lineTo(...P(l.b));
    ctx.stroke();
  }
  ctx.fillStyle = '#222';
  for (const t of builder.texts) {
    const px = Math.max(5, t.size * k * 1.1);
    if (px < 5.5 && t.size < 2) continue;
    ctx.font = `${t.bold ? '600 ' : ''}${px}px sans-serif`;
    ctx.textAlign = t.align || 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(t.text, ...P(t.at));
  }
}

export function masterLayoutsDialog(app) {
  const doc = app.doc;
  let sel = (app.activeView?.kind === 'sheet' && app.activeView.masterId) || doc.all('masterLayout')[0]?.id;
  const list = h('ul.file-list.mat-list');
  const detail = h('div.mat-detail');
  const set = (patch, label = 'Master layout') => {
    app.commit(label, () => {
      doc.update(sel, patch);
      // Sheets follow their master's paper size.
      if (patch.size) for (const s of doc.all('sheet')) if (s.masterId === sel && s.size !== patch.size) doc.update(s.id, { size: patch.size });
    });
    renderList();
    renderDetail();
  };
  const renderDetail = () => {
    clear(detail);
    const m = doc.get(sel);
    if (!m) return;
    const name = h('input.input', { type: 'text', value: m.name, 'aria-label': 'Master name' });
    name.addEventListener('change', () => name.value.trim() && set({ name: name.value.trim() }));
    const size = h('select.input', { 'aria-label': 'Paper size' }, SHEET_SIZES.map((s) => h('option', { value: s.id, selected: s.id === m.size }, s.label)));
    size.addEventListener('change', () => set({ size: size.value }));
    const strip = h('select.input', { 'aria-label': 'Title block' }, STRIPS.map((s) => h('option', { value: s.value, selected: s.value === (m.strip || 'right') }, s.label)));
    strip.addEventListener('change', () => set({ strip: strip.value }));
    const margin = h('input.input', { type: 'number', min: 0, max: 40, step: 1, value: m.margin ?? 10, 'aria-label': 'Margin' });
    margin.addEventListener('change', () => set({ margin: Math.max(0, +margin.value || 0) }));
    const rows = h('div.ml-rows');
    (m.rows || []).forEach((r, i) => {
      const upd = (patch) => set({ rows: m.rows.map((x, j) => (j === i ? { ...x, ...patch } : x)) });
      const lab = h('input.input', { type: 'text', value: r.label || '', 'aria-label': `Row ${i + 1} label` });
      lab.addEventListener('change', () => upd({ label: lab.value }));
      const txt = h('input.input', { type: 'text', value: r.text || '', 'aria-label': `Row ${i + 1} text` });
      txt.addEventListener('change', () => upd({ text: txt.value }));
      const sz = h('select.input', { 'aria-label': `Row ${i + 1} text size` }, [1.8, 2.2, 2.6, 3, 3.5, 4.2, 5].map((v) => h('option', { value: v, selected: +r.size === v }, `${v} mm`)));
      sz.addEventListener('change', () => upd({ size: +sz.value }));
      const del = h('button.icon-btn.sm', { type: 'button', 'aria-label': `Remove row ${i + 1}`, onClick: () => set({ rows: m.rows.filter((_, j) => j !== i) }) }, icon('trash', 14));
      rows.append(h('div.ml-row', lab, txt, sz, del));
    });
    const used = doc.all('sheet').filter((s) => s.masterId === m.id).length;
    const canvas = h('canvas.ml-preview', { width: 420, height: 300, role: 'img', 'aria-label': `Preview of ${m.name}` });
    detail.append(
      h('div.row2', field('Name', name), field('Paper size', size)),
      h('div.row2', field('Title block', strip), field('Margin (mm)', margin)),
      canvas,
      m.strip === 'none' ? null : h('div', h('div.ml-row.ml-head', h('span', 'Label'), h('span', 'Text'), h('span', 'Size'), h('span')), rows),
      m.strip === 'none' ? null : h('button.btn.sm', { type: 'button', onClick: () => set({ rows: [...(m.rows || []), { label: 'FIELD', text: '{Project Name}', size: 2.6 }] }) }, icon('plus', 14), 'Add Row'),
      h('p.field-hint', `Fields in braces: ${SHEET_FIELDS.map((f) => `{${f}}`).join(' ')}`),
      h('p.field-hint', used ? `${used} sheet${used === 1 ? '' : 's'} follow${used === 1 ? 's' : ''} this master.` : 'No sheet follows this master yet: choose it as the Master Layout of a sheet.'),
    );
    requestAnimationFrame(() => drawPreview(doc, m, canvas));
  };
  const renderList = () => {
    clear(list);
    for (const m of doc.all('masterLayout'))
      list.append(h('li', h('button.file-item', { type: 'button', 'aria-pressed': String(m.id === sel), onClick: () => ((sel = m.id), renderList(), renderDetail()) }, icon('sheet', 14), h('span.file-name', m.name), h('span.file-meta', m.size))));
  };
  const add = (base) => {
    let id;
    app.commit('New master layout', () => {
      const { id: _id, ...rest } = base;
      id = doc.add({ ...JSON.parse(JSON.stringify(rest)), kind: 'masterLayout', name: uniqueName(doc.all('masterLayout').map((x) => x.name), `${base.name} 2`) }).id;
    });
    sel = id;
    renderList();
    renderDetail();
  };
  const remove = () => {
    if (doc.all('sheet').some((s) => s.masterId === sel)) return toast('Sheets follow this master: give them another one first.', { kind: 'error' });
    app.commit('Delete master layout', () => doc.remove(sel));
    sel = doc.all('masterLayout')[0]?.id;
    renderList();
    renderDetail();
  };
  renderList();
  renderDetail();
  return openDialog({
    title: 'Master Layouts',
    size: 'lg',
    body: h(
      'div.mat-layout',
      h(
        'div.mat-side',
        list,
        h(
          'div.inline',
          { style: { marginTop: '8px', gap: '6px' } },
          h('button.btn.sm', { type: 'button', onClick: () => add({ name: 'Master', size: 'A1', margin: 10, strip: 'right', rows: [{ label: 'PROJECT', text: '{Project Name}', size: 4.2 }] }) }, icon('plus', 14), 'New'),
          h('button.btn.sm', { type: 'button', disabled: !sel, onClick: () => add(doc.get(sel)) }, 'Duplicate'),
          h('button.btn.sm', { type: 'button', disabled: !sel, onClick: remove }, icon('trash', 14), 'Delete'),
        ),
      ),
      detail,
    ),
    actions: [{ label: 'Close', primary: true, value: null }],
  });
}
