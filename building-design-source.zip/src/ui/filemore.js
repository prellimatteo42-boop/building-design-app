/**
 * File menu: Close Project, New & Reset All, Export Property Values from
 * Schedule (with element ids, to edit in Excel and bring back), SAF
 * Translators (what the SAF export writes) and Import SAF.
 */
import { h } from './dom.js';
import { openDialog, toast, confirmDialog } from './dialog.js';
import * as files from '../io/files.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { writeXLSX, readXLSXSheets } from '../io/xlsx.js';
import { scheduleTable } from '../core/schedule.js';
import { createProject } from '../core/template.js';
import { safTranslator, safToModel, SAF_DEFAULTS } from '../core/safimport.js';

/** Close Project: after offering to save, the project closes and the start screen shows. */
export async function closeProject(app) {
  if (!(await files.confirmDiscard(app))) return;
  app.setDoc(createProject({ system: app.settings.units === 'imperial' ? 'imperial' : 'metric' }), null);
  app.doc.modified = false;
  app.showHome();
}

/** New & Reset All: every preference back to its default, then a new project. */
export async function newResetAll(app) {
  const ok = await confirmDialog('New & Reset All', 'Set every preference (work environment, tool settings, snaps, palettes) back to its default and start a new project?', { confirm: 'Reset and Start', danger: true });
  if (!ok) return;
  if (!(await files.confirmDiscard(app))) return;
  app.settingsStore.reset(['theme']);
  app.newProject(app.settings.units === 'imperial' ? 'imperial' : 'metric');
  app.workspace?.rebuild?.();
  toast('Preferences reset to their defaults.', { kind: 'success' });
}

/** Export Property Values from Schedule: the schedule as a workbook with each row's element ids. */
export function exportScheduleValues(app, id = app.activeView?.kind === 'schedule' ? app.activeView.id : null) {
  const views = id ? [app.doc.get(id)] : app.doc.all('schedule');
  if (!views.length || !views[0]) return toast('Open a schedule first (or make one).', { kind: 'error' });
  const bytes = writeXLSX(views.map((v) => scheduleTable(app, v, { ids: true })));
  download(new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), `${safeFileName(id ? views[0].name : `${app.doc.project?.name || 'Project'} - Property Values`)}.xlsx`);
  toast('Edit the values in Excel and bring them back with Import Property Values into Elements (rows are found by Element ID).');
}

export function safTranslatorsDialog(app) {
  const doc = app.doc;
  const t = safTranslator(doc);
  const LABELS = { members: 'Members (columns, beams, braces)', surfaces: 'Surfaces (slabs, walls)', supports: 'Supports', loads: 'Loads', combinations: 'Load combinations' };
  const boxes = Object.keys(SAF_DEFAULTS).map((k) => {
    const c = h('input', { type: 'checkbox', checked: !!t[k] });
    return { k, c, el: h('label.check', c, h('span', LABELS[k])) };
  });
  return openDialog({
    title: 'SAF Translators',
    size: 'sm',
    body: h('div', h('p.field-hint', 'What the Structural Analysis Format (SAF) export writes. The analytical model itself follows the Analytical Model Generation Rules.'), ...boxes.map((b) => b.el), h('div.row-actions', h('button.btn.sm', { type: 'button', onClick: () => importSAF(app) }, 'Import SAF...'))),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'Save and Export...',
        onClick: () => {
          app.commit('SAF translator', () => doc.update('project', { safTranslator: Object.fromEntries(boxes.map((b) => [b.k, b.c.checked])) }));
          app.exportSAF();
          return true;
        },
      },
      { label: 'OK', primary: true, onClick: () => (app.commit('SAF translator', () => doc.update('project', { safTranslator: Object.fromEntries(boxes.map((b) => [b.k, b.c.checked])) })), true) },
    ],
  });
}

/** Import SAF: the members and surfaces of a SAF workbook become columns, beams, braces, slabs and walls. */
export async function importSAF(app) {
  const f = await files.pickFile('.xlsx');
  if (!f) return;
  let sheets;
  try {
    sheets = await readXLSXSheets(new Uint8Array(await f.arrayBuffer()));
  } catch (err) {
    return toast(`That file could not be read: ${err.message || err}`, { kind: 'error' });
  }
  if (!sheets.has('StructuralPointConnection')) return toast('Not a SAF workbook (no StructuralPointConnection sheet).', { kind: 'error' });
  let n;
  app.commit('Import SAF', () => (n = safToModel(app.doc, sheets)));
  toast(`Imported ${n.columns} columns, ${n.beams} beams, ${n.braces} braces, ${n.slabs} slabs and ${n.walls} walls${n.skipped ? ` (${n.skipped} items skipped)` : ''}.`, { kind: 'success' });
}
