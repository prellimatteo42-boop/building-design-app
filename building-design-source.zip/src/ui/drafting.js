/**
 * Precise drafting commands (Archicad's): Grids & Background, grid snap,
 * orthogonal / rotated grid, Set Rotated Grid and Set User Origin by
 * clicking, the parallel and bisector cursor constraints, Previous / Next
 * Zoom, Home Zoom and Actual Size. The logic is in core/drafting.js.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { Tool } from '../editor/tool.js';
import { draftingOf, draftingPatch, bisectorDirection } from '../core/drafting.js';
export { REF_LINE_KINDS, referenceLines } from '../core/drafting.js';
import { formatLength, parseLength } from '../core/units.js';
import { dist, closestOnSegment } from '../core/geom.js';
import { drawSnapMarker, strokeModel } from '../views/overlay.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);

const setGrid = (app, grid, label = 'Grid') => app.commit(label, () => app.doc.update('project', draftingPatch(app.doc.project, { grid })));

/** Grids & Background: spacing, rotation and origin of the construction grid, shown or not, snapping or not. */
export function gridDialog(app) {
  const u = app.doc.units;
  const g = { ...draftingOf(app.doc.project).grid };
  const len = (v, label) => {
    const i = h('input.input', { type: 'text', value: formatLength(v, u), 'aria-label': label });
    i.addEventListener('keydown', (e) => e.stopPropagation());
    return i;
  };
  const sx = len(g.spacing[0], 'Spacing across');
  const sy = len(g.spacing[1], 'Spacing up');
  const ang = h('input.input', { type: 'number', step: 0.5, value: g.rotatedAngle, 'aria-label': 'Rotation angle' });
  ang.addEventListener('keydown', (e) => e.stopPropagation());
  const ox = len(draftingOf(app.doc.project).grid.rotated ? g.origin[0] : app.doc.project?.drafting?.grid?.origin?.[0] || 0, 'Origin X');
  const oy = len(draftingOf(app.doc.project).grid.rotated ? g.origin[1] : app.doc.project?.drafting?.grid?.origin?.[1] || 0, 'Origin Y');
  const check = (on, label) => {
    const cb = h('input', { type: 'checkbox', checked: !!on });
    return [cb, h('label.check', cb, label)];
  };
  const [show, showRow] = check(g.show, 'Show the grid');
  const [snap, snapRow] = check(g.snap, 'Snap to the grid nodes');
  const [rot, rotRow] = check(g.rotated, 'Rotated grid (else orthogonal)');
  const stored = app.doc.project?.drafting || {};
  const snapOn = h('input', { type: 'checkbox', checked: !!stored.snapGrid?.on });
  const snapX = len(stored.snapGrid?.spacing?.[0] ?? 100, 'Snap grid X');
  const snapY = len(stored.snapGrid?.spacing?.[1] ?? 100, 'Snap grid Y');
  const bgOn = h('input', { type: 'checkbox', checked: !!stored.background });
  const bgCol = h('input', { type: 'color', value: stored.background || '#ffffff', 'aria-label': 'Background colour' });
  const bgRow = h('div.inline', { style: { gap: '8px', alignItems: 'center' } }, h('label.check', bgOn, h('span', 'Own colour')), bgCol);
  const body = h(
    'div',
    h('div.row2', field('Spacing across', sx), field('Spacing up', sy)),
    h('div.inline', { style: { gap: '16px', margin: '6px 0' } }, showRow, snapRow),
    rotRow,
    h('div.row2', field('Rotation (degrees)', ang), field('Origin X', ox)),
    h('div.row2', h('span'), field('Origin Y', oy)),
    h('h3.dlg-sub', 'Snap grid (its own spacing, not drawn)'),
    h('div.row3', h('label.check', snapOn, h('span', 'Snap to the snap grid')), h('label.field', h('span.field-label', 'X'), snapX), h('label.field', h('span.field-label', 'Y'), snapY)),
    h('label.field', h('span.field-label', 'Background colour of the drawing window'), bgRow),
    h('p.field-hint', 'The rotated grid turns about its origin; Set Rotated Grid sets both with two clicks. Object snaps win over the grid when the cursor is near an element; hold Alt to place freely.'),
  );
  return openDialog({ title: 'Grids & Background', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const p = (i, d) => {
      const v = parseLength(i.value, u);
      return Number.isFinite(v) ? v : d;
    };
    setGrid(app, { spacing: [Math.max(1, p(sx, 1000)), Math.max(1, p(sy, 1000))], angle: +ang.value || 0, origin: [p(ox, 0), p(oy, 0)], show: show.checked, snap: snap.checked && !snapOn.checked, rotated: rot.checked }, 'Grids & Background');
    app.commit('Grids & Background', () => app.doc.update('project', { drafting: { ...app.doc.project.drafting, snapGrid: { on: snapOn.checked, spacing: [Math.max(1, p(snapX, 100)), Math.max(1, p(snapY, 100))] }, background: bgOn.checked ? bgCol.value : null } }));
    app.requestRender();
  });
}

export function toggleGrid(app, key) {
  const cur = draftingOf(app.doc.project).grid;
  const on = !cur[key];
  // Snapping to a grid you cannot see is confusing: turning snap on shows the grid.
  setGrid(app, key === 'snap' && on ? { snap: true, show: true } : { [key]: on }, key === 'snap' ? 'Grid snap' : 'Show grid');
  app.toast(key === 'snap' ? `Grid snap ${on ? 'on' : 'off'}.` : `Grid ${on ? 'shown' : 'hidden'}.`);
  app.requestRender();
}

export function setRotated(app, on) {
  setGrid(app, { rotated: on }, on ? 'Rotated grid' : 'Orthogonal grid');
  app.requestRender();
}

/** A tool that collects n clicked points (snapped) and hands them over. */
export class PickPointsTool extends Tool {
  constructor(app, { n = 1, title, prompts, done }) {
    super(app);
    this.n = n;
    this.titleText = title;
    this.prompts = prompts;
    this.done = done;
    this.points = [];
  }

  get title() {
    return this.titleText;
  }

  get prompt() {
    return this.prompts[this.points.length] || '';
  }

  move(ev) {
    this.cursor = this.snap(ev, this.points.at(-1) || null);
    this.app.requestRender();
  }

  down(ev) {
    this.points.push(this.snap(ev, this.points.at(-1) || null));
    if (this.points.length >= this.n) {
      const pts = this.points;
      this.app.cancelTool();
      this.done(pts);
    } else this.app.setPrompt(this.prompt);
  }

  drawOverlay(ctx, vc, vp) {
    if (this.points.length && this.cursor) strokeModel(ctx, [this.points[0], this.cursor], (p) => vc.modelToScreen(p), vp.theme.snap, 1.5, [6, 4]);
    for (const p of this.points) drawSnapMarker(ctx, vc.modelToScreen(p), 'endpoint', vp.theme.snap, '');
    super.drawOverlay(ctx, vc, vp);
  }
}

export function setUserOriginTool(app) {
  return new PickPointsTool(app, {
    title: 'Set User Origin',
    prompts: ['Click the point coordinates are read from'],
    done: ([p]) => {
      app.commit('User origin', () => app.doc.update('project', draftingPatch(app.doc.project, { userOrigin: p })));
      app.toast('User origin set: coordinates and the Tracker read from it.');
    },
  });
}

export function setRotatedGridTool(app) {
  return new PickPointsTool(app, {
    n: 2,
    title: 'Set Rotated Grid',
    prompts: ['Click the origin of the rotated grid', 'Click a point along its first axis'],
    done: ([a, b]) => {
      const angle = (Math.atan2(b[1] - a[1], b[0] - a[0]) * 180) / Math.PI;
      setGrid(app, { origin: a, angle: Math.round(angle * 1000) / 1000, rotated: true, show: true }, 'Set rotated grid');
      app.toast(`Rotated grid at ${Math.round(angle * 10) / 10}°.`);
      app.requestRender();
    },
  });
}

/** Lines (element edges, axes) near the last pointer position, nearest first. */
export function linesNearPointer(app) {
  const vc = app.vc;
  const p = app.lastPointer?.p;
  if (!vc?.is2D || !p) return [];
  const tol = 14 * vc.mmPerPx();
  const out = [];
  for (const f of vc.snapFeaturesNear(p, tol * 3, null))
    for (const l of f.lines) {
      const c = closestOnSegment(p, l.a, l.b);
      const d = dist(p, c.point);
      if (d <= tol * 2 && dist(l.a, l.b) > 1) out.push({ l, d });
    }
  return out.sort((a, b) => a.d - b.d).map((x) => x.l);
}

/**
 * Parallel or bisector constraint (Archicad's cursor constraints): the next points move along the direction of the
 * edge under the cursor, or along the bisector of the corner under it. Run again (or Escape) to release.
 */
export function constraint(app, kind) {
  if (app.constraint?.kind === kind) {
    app.constraint = null;
    app.toast('Constraint released.');
    return app.requestRender();
  }
  const lines = linesNearPointer(app);
  if (!lines.length) return app.toast(kind === 'bisector' ? 'Point at a corner of two edges, then run Bisector again.' : `Point at an edge, then run ${kind === 'parallel' ? 'Parallel' : 'Perpendicular'} again.`, { kind: 'error' });
  let dir;
  if (kind === 'parallel') dir = [lines[0].b[0] - lines[0].a[0], lines[0].b[1] - lines[0].a[1]];
  else if (kind === 'perpendicular') dir = [-(lines[0].b[1] - lines[0].a[1]), lines[0].b[0] - lines[0].a[0]];
  else {
    const a = lines[0];
    const b = lines.find((l) => {
      const c = Math.abs((a.b[0] - a.a[0]) * (l.b[1] - l.a[1]) - (a.b[1] - a.a[1]) * (l.b[0] - l.a[0]));
      return c > 1e-3 * dist(a.a, a.b) * dist(l.a, l.b);
    });
    if (!b) return app.toast('Point at a corner where two edges meet.', { kind: 'error' });
    dir = bisectorDirection(a, b);
  }
  app.constraint = { kind, dir, label: { parallel: 'Parallel', perpendicular: 'Perpendicular', bisector: 'Bisector' }[kind] };
  app.toast(`${app.constraint.label} constraint: the next points follow it. Run it again or press Escape to release.`);
  app.requestRender();
}

export function stepZoom(app, dir) {
  if (!app.vc?.stepZoom) return;
  if (!app.vc.stepZoom(dir)) app.toast(dir < 0 ? 'No earlier zoom.' : 'No later zoom.');
}

export function setHomeZoom(app) {
  const v = app.activeView;
  const cam = app.vc?.cam;
  if (!v || !cam || !app.vc.is2D) return app.toast('Open a plan, section or sheet first.', { kind: 'error' });
  app.commit('Home zoom', () => app.doc.update(v.id, { homeZoom: { cx: cam.cx, cy: cam.cy, zoom: cam.zoom } }));
  app.toast('This zoom is now the view’s home zoom.');
}

export function homeZoom(app) {
  const v = app.activeView;
  const c = app.vc;
  if (!c?.is2D) return app.zoomFit?.();
  if (v?.homeZoom) {
    c.cam = { ...v.homeZoom };
    c.noteCamera?.(true);
    app.requestRender();
  } else app.zoomFit?.();
}

/** Rotate Orientation: two clicks along a direction that then reads horizontal on screen. */
export function rotateOrientationTool(app) {
  return new PickPointsTool(app, {
    n: 2,
    title: 'Rotate Orientation',
    prompts: ['Click the start of a direction that should read horizontal', 'Click its end'],
    done: ([a, b]) => {
      const ang = Math.atan2(b[1] - a[1], b[0] - a[0]);
      app.vc?.setOrientation?.(-ang);
      app.toast(`View turned ${Math.round((-ang * 1800) / Math.PI) / 10}°. Reset Orientation turns it back.`);
    },
  });
}

/** Centre a plan view on a model point, at a zoom that shows about 20 m around it. */
export function zoomToPoint(app, p) {
  const c = app.vc;
  if (!p || !c?.zoomToBox) return app.toast('Open a plan view first.', { kind: 'error' });
  c.zoomToBox({ x0: p[0] - 10000, y0: p[1] - 10000, x1: p[0] + 10000, y1: p[1] + 10000 });
}

// Display order (Archicad's Bring to Front / Forward, Send Backward / to Back, Reset Default Order) -------------

import { KIND_Z } from '../render/renderer2d.js';

const Z_MAX = 12;

/** Change the 2D draw layer of the selected elements: 'front', 'forward', 'backward', 'back' or 'reset'. */
export function displayOrder(app, how) {
  const doc = app.doc;
  const els = [...app.selection].map((id) => doc.get(id)).filter(Boolean);
  if (!els.length) return app.toast('Select the elements to move up or down first.', { kind: 'error' });
  app.commit(`Display order: ${how}`, () => {
    for (const el of els) {
      const cur = el.drawZ ?? KIND_Z[el.kind] ?? 6;
      const z = how === 'front' ? Z_MAX : how === 'back' ? 0 : how === 'forward' ? Math.min(Z_MAX, cur + 1) : how === 'backward' ? Math.max(0, cur - 1) : null;
      doc.update(el.id, { drawZ: z });
    }
  });
  app.requestRender();
}

// Reference lines on screen (Archicad's View > On-Screen View Options) -------------------------------------------

export function toggleRefLines(app, id) {
  const cur = { ...(app.settings.refLines || {}) };
  cur[id] = !cur[id];
  app.settingsStore.set('refLines', cur);
  app.requestRender();
}
