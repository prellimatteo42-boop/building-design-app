/**
 * Enter System Edit Mode (Design menu), as Archicad offers for stairs,
 * railings and curtain walls: the selected system's segments edited one by
 * one. Stairs: where the flight turns (risers in the first flight), the
 * landing's depth, the turn; railings: each segment's infill, height and top
 * rail, and its nodes' heights; curtain walls: frames and panels.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { curtainEditDialog } from './curtainedit.js';
import { formatLength, parseLength } from '../core/units.js';
import { stairFlights, flightOutline, STAIR_SHAPES } from '../core/stairs.js';

const SVG = 'http://www.w3.org/2000/svg';
const svg = (tag, attrs = {}) => {
  const el = document.createElementNS(SVG, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  return el;
};
const field = (label, control) => h('label.field', h('span.field-label', label), control);

export function systemEditMode(app) {
  const el = app.doc.get([...app.selection][0]);
  if (!el) return toast('Select a stair, railing or curtain wall first.', { kind: 'error' });
  if (el.kind === 'stair') return stairEdit(app, el);
  if (el.kind === 'railing') return railingEdit(app, el);
  if (el.kind === 'wall' && app.doc.get(el.typeId)?.curtain) return curtainEditDialog(app, el.id);
  return toast('System Edit Mode works on stairs, railings and curtain walls.', { kind: 'error' });
}

function stairEdit(app, el) {
  const doc = app.doc;
  const draft = { shape: el.shape || 'straight', turn: el.turn || 'left', splitRisers: el.splitRisers ?? null, landingDepth: el.landingDepth ?? null };
  const units = doc.units;
  const root = svg('svg', { class: 'stair-svg', role: 'img', 'aria-label': 'Stair plan' });
  root.style.width = '100%';
  root.style.height = '300px';
  const info = h('p.field-hint');
  const shape = h('select.input', { 'aria-label': 'Shape' }, STAIR_SHAPES.filter((x) => x.value !== 'spiral').map((x) => h('option', { value: x.value }, x.label)));
  shape.value = draft.shape === 'spiral' ? 'straight' : draft.shape;
  const turn = h('select.input', { 'aria-label': 'Turn' }, h('option', { value: 'left' }, 'Left'), h('option', { value: 'right' }, 'Right'));
  turn.value = draft.turn;
  const split = h('input.input', { type: 'range', min: 2, max: 2, step: 1, 'aria-label': 'Risers in the first flight' });
  const splitLabel = h('span.field-hint');
  const depth = h('input.input', { type: 'text', value: draft.landingDepth ? formatLength(draft.landingDepth, units) : '', placeholder: 'Stair width', 'aria-label': 'Landing depth' });
  depth.addEventListener('keydown', (e) => e.stopPropagation());
  const draw = () => {
    const g = stairFlights(doc, { ...el, ...draft });
    const W = g.width;
    const polys = [...g.flights.map((f) => flightOutline(f, W)), ...g.landings.map((l) => l.poly)];
    const pts = polys.flat();
    const x0 = Math.min(...pts.map((p) => p[0]));
    const y0 = Math.min(...pts.map((p) => p[1]));
    const x1 = Math.max(...pts.map((p) => p[0]));
    const y1 = Math.max(...pts.map((p) => p[1]));
    const pad = 300;
    root.setAttribute('viewBox', `${x0 - pad} ${-y1 - pad} ${x1 - x0 + 2 * pad} ${y1 - y0 + 2 * pad}`);
    root.replaceChildren();
    const P = (p) => `${p[0]},${-p[1]}`;
    g.flights.forEach((f, i) => {
      root.append(svg('polygon', { points: flightOutline(f, W).map(P).join(' '), fill: i ? 'rgba(61,127,196,0.18)' : 'rgba(217,83,79,0.18)', stroke: '#2c3e50', 'stroke-width': 20 }));
      // Tread lines.
      for (let k = 1; k < f.risers - 1; k++) {
        const s = (k * f.run) / (f.risers - 1);
        const a = [f.start[0] + f.dir[0] * s + f.side[0] * (-W / 2), f.start[1] + f.dir[1] * s + f.side[1] * (-W / 2)];
        const b = [a[0] + f.side[0] * W, a[1] + f.side[1] * W];
        root.append(svg('line', { x1: a[0], y1: -a[1], x2: b[0], y2: -b[1], stroke: '#2c3e50', 'stroke-width': 8 }));
      }
    });
    for (const l of g.landings) root.append(svg('polygon', { points: l.poly.map(P).join(' '), fill: 'rgba(120,120,120,0.15)', stroke: '#2c3e50', 'stroke-width': 20 }));
    const R = g.risers;
    split.max = String(Math.max(2, R - 2));
    split.disabled = draft.shape === 'straight' || R < 4;
    const r1 = g.flights[0]?.risers ?? R;
    split.value = String(r1);
    splitLabel.textContent = draft.shape === 'straight' ? 'One flight' : `${r1} + ${R - r1} risers`;
    depth.disabled = draft.shape === 'straight';
    info.textContent = `${R} risers of ${formatLength(g.riserHeight, units)}, treads ${formatLength(g.tread, units)}.`;
  };
  shape.addEventListener('change', () => ((draft.shape = shape.value), draw()));
  turn.addEventListener('change', () => ((draft.turn = turn.value), draw()));
  split.addEventListener('input', () => ((draft.splitRisers = +split.value), draw()));
  depth.addEventListener('change', () => {
    const v = parseLength(depth.value, units);
    draft.landingDepth = depth.value.trim() === '' ? null : Number.isFinite(v) && v > 0 ? v : draft.landingDepth;
    draw();
  });
  draw();
  return openDialog({
    title: 'System Edit Mode: Stair',
    size: 'md',
    body: h('div', root, h('div.row2', field('Shape', shape), field('Turn', turn)), h('div.row2', field('Risers in the first flight', h('div', split, splitLabel)), field('Landing depth', depth)), info),
    actions: [
      { label: 'Cancel', value: null },
      { label: 'OK', primary: true, onClick: () => (app.commit('Edit stair segments', () => doc.update(el.id, { shape: draft.shape, turn: draft.turn, splitRisers: draft.splitRisers, landingDepth: draft.landingDepth })), true) },
    ],
  });
}

const INFILLS = [
  { value: '', label: 'As the type' },
  { value: 'balusters', label: 'Balusters' },
  { value: 'glass', label: 'Glass panel' },
  { value: 'open', label: 'Open (end posts only)' },
  { value: 'none', label: 'No railing here' },
];

function railingEdit(app, el) {
  const doc = app.doc;
  const units = doc.units;
  const n = el.path.length - 1;
  const segs = Array.from({ length: n }, (_, i) => ({ ...(el.segments?.[i] || {}) }));
  const pathZ = el.path.map((_, i) => +el.pathZ?.[i] || 0);
  const H0 = +doc.get(el.typeId)?.height || 1100;
  let sel = 0;
  const lens = el.path.slice(1).map((p, i) => Math.hypot(p[0] - el.path[i][0], p[1] - el.path[i][1]));
  const total = lens.reduce((a, b) => a + b, 0) || 1;
  const root = svg('svg', { class: 'rail-svg', role: 'img', 'aria-label': 'Railing unrolled' });
  root.style.width = '100%';
  const side = h('div.truss-side');
  const draw = () => {
    const top = Math.max(...pathZ) + Math.max(H0, ...segs.map((s) => +s.height || 0)) + 200;
    root.setAttribute('viewBox', `-200 ${-top} ${total + 400} ${top + 300}`);
    root.replaceChildren();
    let s0 = 0;
    segs.forEach((sg, i) => {
      const L = lens[i];
      const za = pathZ[i];
      const zb = pathZ[i + 1];
      const H = +sg.height || H0;
      const off = sg.infill === 'none';
      const fill = off ? 'transparent' : sg.infill === 'glass' ? 'rgba(120,170,220,0.45)' : sg.infill === 'open' ? 'rgba(0,0,0,0.03)' : 'rgba(80,80,80,0.12)';
      const poly = svg('polygon', { points: `${s0},${-za} ${s0 + L},${-zb} ${s0 + L},${-(zb + H)} ${s0},${-(za + H)}`, fill, stroke: i === sel ? '#d35400' : '#2c3e50', 'stroke-width': i === sel ? 40 : 15, 'stroke-dasharray': off ? '60 40' : '', tabindex: '0', 'data-seg': i, style: 'cursor:pointer' });
      const pick = () => ((sel = i), draw());
      poly.addEventListener('click', pick);
      poly.addEventListener('keydown', (e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), pick()));
      root.append(poly);
      if (!off && sg.rail !== false) root.append(svg('line', { x1: s0, y1: -(za + H), x2: s0 + L, y2: -(zb + H), stroke: '#2c3e50', 'stroke-width': 50 }));
      s0 += L;
    });
    renderSide();
  };
  const renderSide = () => {
    const sg = segs[sel];
    const infill = h('select.input', { 'aria-label': 'Infill' }, INFILLS.map((x) => h('option', { value: x.value }, x.label)));
    infill.value = sg.infill || '';
    infill.addEventListener('change', () => ((sg.infill = infill.value || undefined), draw()));
    const height = h('input.input', { type: 'text', value: sg.height ? formatLength(sg.height, units) : '', placeholder: formatLength(H0, units), 'aria-label': 'Segment height' });
    height.addEventListener('keydown', (e) => e.stopPropagation());
    height.addEventListener('change', () => {
      const v = parseLength(height.value, units);
      if (height.value.trim() === '') delete sg.height;
      else if (Number.isFinite(v) && v > 0) sg.height = v;
      draw();
    });
    const rail = h('input', { type: 'checkbox', checked: sg.rail !== false, 'aria-label': 'Top rail' });
    rail.addEventListener('change', () => ((sg.rail = rail.checked ? undefined : false), draw()));
    const zIn = (i, label) => {
      const x = h('input.input', { type: 'text', value: formatLength(pathZ[i], units), 'aria-label': label });
      x.addEventListener('keydown', (e) => e.stopPropagation());
      x.addEventListener('change', () => {
        const v = parseLength(x.value, units);
        if (Number.isFinite(v)) pathZ[i] = v;
        draw();
      });
      return x;
    };
    side.replaceChildren(
      h('p', h('strong', `Segment ${sel + 1} of ${n}`), ` · ${formatLength(lens[sel], units)}`),
      field('Infill', infill),
      field('Height', height),
      h('label.check', rail, h('span', 'Top rail')),
      h('div.row2', field('Start height', zIn(sel, 'Start height')), field('End height', zIn(sel + 1, 'End height'))),
    );
  };
  draw();
  return openDialog({
    title: 'System Edit Mode: Railing',
    size: 'lg',
    body: h('div.truss-edit', root, side, h('p.field-hint', 'Click a segment of the unrolled railing to change it. Heights are above the railing\'s level and offset.')),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'OK',
        primary: true,
        onClick: () => {
          const clean = segs.map((s) => Object.fromEntries(Object.entries(s).filter(([, v]) => v !== undefined)));
          app.commit('Edit railing segments', () => doc.update(el.id, { segments: clean.some((s) => Object.keys(s).length) ? clean : null, pathZ: pathZ.some((z) => z) ? pathZ : null }));
          return true;
        },
      },
    ],
  });
}
