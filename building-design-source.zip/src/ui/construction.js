/**
 * Construction Simulation commands: Show Task List (tasks from the
 * selection, dates, action), Open / Save / Save As Project (the schedule's
 * own file), and Create Animation (the 3D view through the schedule, shown
 * date by date with a slider and recorded as a video).
 */
import { h, clear } from './dom.js';
import { openDialog } from './dialog.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { ACTIONS, scheduleOf, scheduleSpan, tasksByElement, simState, frameDates, scheduleFile, readScheduleFile, isoDay } from '../core/construction.js';

const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

/** Show the model at a date (null: stop the simulation). */
export function setSimDate(app, date) {
  if (!date) app.sim4d = null;
  else {
    const by = tasksByElement(app.doc.project);
    app.sim4d = { date, state: (el) => simState(by, el.id, date, el.hostId) };
  }
  app.flagsVersion++;
  app.requestRender();
}

const save = (app, schedule) => app.commit('Construction schedule', () => app.doc.update('project', { construction: schedule }));

export function taskListDialog(app) {
  const body = h('div');
  const render = () => {
    clear(body);
    const s = scheduleOf(app.doc.project);
    const sel = [...app.selection];
    const rows = s.tasks.map((t, i) => {
      const inp = (key, type = 'text') => {
        const el = h('input.input', { type, value: t[key] || '', 'aria-label': key, style: { minWidth: type === 'date' ? '9em' : '10em' } });
        el.addEventListener('keydown', (e) => e.stopPropagation());
        el.addEventListener('change', () => save(app, { ...s, tasks: s.tasks.map((x, j) => (j === i ? { ...x, [key]: el.value } : x)) }));
        return el;
      };
      const act = h('select.input', { 'aria-label': 'Action' }, ...ACTIONS.map((a) => h('option', { value: a.value, selected: a.value === (t.action || 'build') }, a.label)));
      act.addEventListener('change', () => save(app, { ...s, tasks: s.tasks.map((x, j) => (j === i ? { ...x, action: act.value } : x)) }));
      return h(
        'tr',
        h('td', inp('name')),
        h('td', inp('start', 'date')),
        h('td', inp('end', 'date')),
        h('td', act),
        h('td', h('button.btn.sm', { type: 'button', title: 'Select its elements', onClick: () => app.select(t.ids.filter((id) => app.doc.has(id))) }, String(t.ids.length))),
        h('td', h('button.btn.sm', { type: 'button', disabled: !sel.length, onClick: () => (save(app, { ...s, tasks: s.tasks.map((x, j) => (j === i ? { ...x, ids: [...new Set([...x.ids, ...sel])] } : x)) }), render()) }, '+ selection')),
        h('td', h('button.btn.sm', { type: 'button', onClick: () => (save(app, { ...s, tasks: s.tasks.filter((_, j) => j !== i) }), render()) }, 'Remove')),
      );
    });
    const add = () => {
      const last = s.tasks.at(-1);
      const start = last?.end || isoDay(Date.now());
      const end = isoDay(Date.parse(`${start}T00:00:00Z`) + 14 * 86400000);
      save(app, { ...s, tasks: [...s.tasks, { id: `task${Date.now().toString(36)}`, name: `Task ${s.tasks.length + 1}`, start, end, action: 'build', ids: sel }] });
      render();
    };
    body.append(
      h('p.field-hint', sel.length ? `${plural(sel.length, 'element')} selected: a new task takes them.` : 'Select elements, then add a task for them (or add them to a task).'),
      s.tasks.length ? h('div', { style: { maxHeight: '50vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', h('th', 'Task'), h('th', 'Start'), h('th', 'End'), h('th', 'Action'), h('th', 'Elements'), h('th', ''), h('th', ''))), h('tbody', ...rows))) : h('p', 'No tasks yet.'),
      h('button.btn', { type: 'button', onClick: add }, 'Add task'),
    );
  };
  render();
  return openDialog({ title: 'Construction Simulation: Task List', body, size: 'lg', actions: [{ label: 'Close', value: null }] });
}

export function saveSchedule(app, as = false) {
  const s = scheduleOf(app.doc.project);
  if (!s.tasks.length) return app.toast('The schedule has no tasks yet.', { kind: 'error' });
  const name = as ? `${s.name} copy` : s.name;
  download(new Blob([scheduleFile(app.doc)], { type: 'application/json' }), safeFileName(`${name}.bdsim.json`));
}

export function openSchedule(app) {
  const input = h('input', { type: 'file', accept: '.json' });
  input.addEventListener('change', async () => {
    const f = input.files?.[0];
    if (!f) return;
    try {
      const { schedule, missing } = readScheduleFile(app.doc, await f.text());
      save(app, schedule);
      app.toast(`Opened ${schedule.name}: ${plural(schedule.tasks.length, 'task')}${missing ? `, ${plural(missing, 'element')} not in this model` : ''}.`, { kind: 'success' });
    } catch (e) {
      app.toast(e.message, { kind: 'error' });
    }
  });
  input.click();
}

/** Create Animation: a date slider over the 3D view, and a recording of the whole schedule as a WebM video. */
export function animationDialog(app) {
  const span = scheduleSpan(app.doc.project);
  if (!span) return app.toast('Add tasks with dates first (Show Task List).', { kind: 'error' });
  if (app.activeView?.kind !== 'view3d') {
    const v = app.doc.all('view3d')[0];
    if (v) app.openView(v.id);
  }
  const a = Date.parse(`${span.start}T00:00:00Z`);
  const b = Date.parse(`${span.end}T00:00:00Z`);
  const days = Math.max(1, Math.round((b - a) / 86400000));
  const label = h('strong', span.start);
  const slider = h('input', { type: 'range', min: 0, max: days, value: 0, 'aria-label': 'Date', style: { width: '100%' } });
  const show = () => {
    const d = isoDay(a + +slider.value * 86400000);
    label.textContent = d;
    setSimDate(app, d);
  };
  slider.addEventListener('input', show);
  show();
  const frames = h('input.input', { type: 'number', min: 5, max: 300, value: 40, 'aria-label': 'Frames' });
  frames.addEventListener('keydown', (e) => e.stopPropagation());
  const record = async () => {
    const canvas = app.viewport.canvas;
    if (!canvas?.captureStream || typeof MediaRecorder === 'undefined') return app.toast('This browser cannot record video.', { kind: 'error' });
    const stream = canvas.captureStream(0);
    const track = stream.getVideoTracks()[0];
    const rec = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ? 'video/webm;codecs=vp9' : 'video/webm' });
    const chunks = [];
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    const done = new Promise((r) => (rec.onstop = r));
    rec.start();
    for (const d of frameDates(app.doc.project, Math.max(5, +frames.value || 40))) {
      setSimDate(app, d);
      label.textContent = d;
      app.viewport.render?.();
      await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 120)));
      track.requestFrame?.();
    }
    rec.stop();
    await done;
    download(new Blob(chunks, { type: 'video/webm' }), safeFileName(`${scheduleOf(app.doc.project).name}.webm`));
  };
  const body = h('div', h('p', 'Simulation date: ', label), slider, h('p.field-hint', 'Not yet built: hidden. Being built: green. Being demolished: red. Temporary: yellow.'), h('label.field', h('span.field-label', 'Frames in the video'), frames));
  return openDialog({ title: 'Construction Simulation', body, actions: [{ label: 'Record video', onClick: () => (record(), false) }, { label: 'Close', primary: true, value: null }], onClose: () => setSimDate(app, null) });
}
