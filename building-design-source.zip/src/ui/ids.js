/**
 * Import IDS File (Archicad's): pick an .ids file, check the model against
 * it (core/ids.js) and show each specification with the elements that fail
 * and why, to select or show them; the result can be saved as CSV.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { parseIDS, checkIDS } from '../core/ids.js';
import { download } from '../io/storage.js';

export function importIDS(app) {
  const input = h('input', { type: 'file', accept: '.ids,.xml,application/xml', hidden: true });
  input.addEventListener('change', async () => {
    const f = input.files?.[0];
    input.remove();
    if (!f) return;
    let ids;
    try {
      ids = parseIDS(await f.text());
    } catch (err) {
      return toast(err.message || 'This file is not an IDS.', { kind: 'error' });
    }
    app.lastIDS = { name: f.name, ids };
    idsDialog(app);
  });
  document.body.append(input);
  input.click();
}

export function idsDialog(app) {
  if (!app.lastIDS) return importIDS(app);
  const { name, ids } = app.lastIDS;
  const body = h('div');
  const render = () => {
    clear(body);
    const r = checkIDS(app.doc, ids);
    const failedIds = r.specifications.flatMap((s) => [...s.failed.map((f) => f.id), ...s.prohibited]);
    body.append(h('p', h('b', r.ok ? 'The model meets every specification.' : `${r.specifications.filter((s) => !s.ok).length} of ${r.specifications.length} specifications are not met.`), ` ${ids.title} (${name}).`));
    const tbody = h('tbody');
    for (const s of r.specifications) {
      tbody.append(
        h(
          'tr',
          h('td', s.ok ? '✓' : '✗'),
          h('td', s.name, s.note ? h('div.field-hint', s.note) : null),
          h('td', s.use),
          h('td.num', String(s.applicable)),
          h('td.num', String(s.passed)),
          h('td.num', String(s.failed.length + s.prohibited.length)),
          h('td', s.failed.length || s.prohibited.length ? h('button.btn.sm', { type: 'button', onClick: () => app.showElements([...s.failed.map((f) => f.id), ...s.prohibited]) }, 'Show') : ''),
        ),
      );
      for (const f of s.failed.slice(0, 30)) tbody.append(h('tr.ids-fail', h('td'), h('td', { colspan: 5 }, h('span.file-meta', `${f.entity} ${f.name}: `), f.reasons.join('; ')), h('td', h('button.btn.sm', { type: 'button', onClick: () => app.showElements([f.id]) }, 'Show'))));
      if (s.failed.length > 30) tbody.append(h('tr', h('td'), h('td.field-hint', { colspan: 6 }, `…and ${s.failed.length - 30} more.`)));
    }
    body.append(
      h('div', { style: { maxHeight: '55vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', h('th', ''), h('th', 'Specification'), h('th', 'Use'), h('th', 'Applies to'), h('th', 'Pass'), h('th', 'Fail'), h('th', h('span.sr-only', 'Show')))), tbody)),
      h(
        'div.inline',
        { style: { gap: '8px', marginTop: '8px' } },
        h('button.btn.sm', { type: 'button', disabled: !failedIds.length, onClick: () => app.select(failedIds) }, `Select failing elements (${failedIds.length})`),
        h('button.btn.sm', { type: 'button', onClick: () => render() }, 'Check again'),
        h('button.btn.sm', { type: 'button', onClick: () => download(new Blob([idsCSV(r)], { type: 'text/csv' }), `${name.replace(/\.[^.]+$/, '')} check.csv`) }, 'Save as CSV...'),
      ),
      h('p.field-hint', 'The model is checked as it exports to IFC: entities, attributes (Name is the type, Tag the mark), property sets (IFC and custom properties by group), classifications, materials and storeys.'),
    );
  };
  render();
  return openDialog({ title: 'IDS Check', body, size: 'lg', actions: [{ label: 'Another IDS...', value: 'other' }, { label: 'Close', primary: true, value: null }] }).then((v) => v === 'other' && importIDS(app));
}

function idsCSV(r) {
  const q = (s) => `"${String(s ?? '').replace(/"/g, '""')}"`;
  const rows = [['Specification', 'Use', 'Result', 'Element', 'Entity', 'Name', 'Reasons'].map(q).join(',')];
  for (const s of r.specifications) {
    rows.push([s.name, s.use, s.ok ? 'pass' : 'fail', '', '', '', s.note].map(q).join(','));
    for (const f of s.failed) rows.push([s.name, s.use, 'fail', f.id, f.entity, f.name, f.reasons.join('; ')].map(q).join(','));
  }
  return rows.join('\n');
}
