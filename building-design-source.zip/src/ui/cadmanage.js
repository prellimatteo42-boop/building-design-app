/**
 * DWG/DXF commands: Import Blocks from DXF/DWG (blocks as objects) and the Xref Manager (the drawings brought in,
 * by file: reload from a newer file, detach, or bind them into the project).
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { pickFile } from '../io/files.js';
import { blocksAsObjects } from '../core/cadblocks.js';
import { flattenCAD, INSUNITS_MM } from '../core/cadflatten.js';
import { cadMiddle } from '../io/cadplace.js';

export async function importBlocks(app) {
  const view = app.activeView;
  if (!view?.levelId) return app.toast('Open a floor plan to place the blocks in.', { kind: 'error' });
  const f = await pickFile('.dwg,.DWG,.dxf,.DXF');
  if (!f) return;
  let cad;
  try {
    const { readCAD } = await import('../io/dwgread.js');
    cad = await readCAD(new Uint8Array(await f.arrayBuffer()), { dxf: /\.dxf$/i.test(f.name) });
  } catch (err) {
    return app.toast(`That drawing could not be read: ${err.message || err}`, { kind: 'error' });
  }
  const unitMm = INSUNITS_MM[cad.units] ?? 1;
  // The same centring as a plain import of the drawing, so the objects land on its lines.
  const [mx, my] = cadMiddle(flattenCAD(cad));
  const { types, placed } = blocksAsObjects(cad, { unitMm, T: (p) => [Math.round((p[0] - mx) * unitMm), Math.round((p[1] - my) * unitMm)] });
  if (!types.length) return app.toast('That drawing inserts no named blocks.', { kind: 'error' });
  let n = 0;
  app.commit('Import blocks', () => {
    const byName = new Map();
    for (const t of types) {
      const old = app.doc.all('componentType').find((x) => x.familyName === 'DWG Block' && x.name === t.name);
      byName.set(t.name, old ? (app.doc.update(old.id, t), old.id) : app.doc.add(t).id);
    }
    for (const p of placed) (app.doc.add({ kind: 'component', typeId: byName.get(p.name), levelId: view.levelId, at: p.at, rotation: p.rotation, cadSource: f.name, ...(p.mirrored ? { mirrored: true } : {}) }), n++);
  });
  app.toast(`${types.length} block${types.length === 1 ? '' : 's'} as objects, ${n} placed.`, { kind: 'success' });
}

/** The drawings brought in, by file: { source, count, views }. */
export function cadImports(doc) {
  const m = new Map();
  for (const el of doc.items.values()) {
    if (!el.cadSource) continue;
    const r = m.get(el.cadSource) || { source: el.cadSource, count: 0, views: new Set() };
    r.count++;
    if (el.viewId) r.views.add(el.viewId);
    m.set(el.cadSource, r);
  }
  return [...m.values()];
}

export function xrefManager(app) {
  const list = cadImports(app.doc);
  if (!list.length) return app.toast('No DWG or DXF drawing has been brought in.', { kind: 'error' });
  const body = h(
    'table.vg-table',
    h('thead', h('tr', h('th', 'Drawing'), h('th', 'Elements'), h('th', ''))),
    h(
      'tbody',
      ...list.map((r) =>
        h(
          'tr',
          h('td', r.source),
          h('td', String(r.count)),
          h(
            'td',
            h('span.inline', { style: { gap: '4px' } },
              h('button.btn.sm', { type: 'button', 'data-tip': 'Pick the newer file: the earlier import is replaced (Smart Merge)', onClick: (e) => (e.currentTarget.closest('dialog')?.dispatchEvent(new Event('cancel')), app.importDWG()) }, 'Reload...'),
              h('button.btn.sm', { type: 'button', 'data-tip': 'Remove everything this drawing brought in', onClick: (e) => (app.commit('Detach drawing', () => [...app.doc.items.values()].filter((el) => el.cadSource === r.source).forEach((el) => app.doc.remove(el.id))), e.currentTarget.closest('tr').remove()) }, 'Detach'),
              h('button.btn.sm', { type: 'button', 'data-tip': 'Keep the elements as the project\'s own: they no longer follow the file', onClick: (e) => (app.commit('Bind drawing', () => [...app.doc.items.values()].filter((el) => el.cadSource === r.source).forEach((el) => app.doc.update(el.id, { cadSource: undefined }))), e.currentTarget.closest('tr').remove()) }, 'Bind'),
            ),
          ),
        ),
      ),
    ),
  );
  return openDialog({ title: 'Xref Manager', body, size: 'lg', actions: [{ label: 'Close', value: null }] });
}
