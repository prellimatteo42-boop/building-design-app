/**
 * 3D Cutting Planes dialog for the active 3D view: up to two planes,
 * horizontal at a height (with a shortcut per story) or vertical through
 * a point at an angle, each on or off and flippable.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { MAX_CUT_PLANES } from '../core/cutplanes.js';
import { formatLength, parseLength } from '../core/units.js';

export function cutPlanesDialog(app) {
  const view = app.activeView;
  if (view?.kind !== 'view3d') return toast('Open a 3D view to cut it.', { kind: 'error' });
  const doc = app.doc;
  const units = doc.units;
  const body = h('div');
  const planes = () => doc.get(view.id).cutPlanes || [];
  const save = (list, label = '3D cutting planes') => {
    app.commit(label, () => doc.update(view.id, { cutPlanes: list }));
    app.requestRender();
    render();
  };
  const lengthField = (label, value, onSet) => {
    const el = h('input.input.sm', { type: 'text', value: formatLength(value || 0, units), 'aria-label': label });
    el.addEventListener('keydown', (e) => e.stopPropagation());
    el.addEventListener('change', () => {
      const v = parseLength(el.value, units);
      if (Number.isFinite(v)) onSet(v);
      else el.value = formatLength(value || 0, units);
    });
    return h('label.field', h('span.field-label', label), el);
  };
  const render = () => {
    clear(body);
    const list = planes();
    list.forEach((c, i) => {
      const upd = (patch) => save(planes().map((x, j) => (j === i ? { ...x, ...patch } : x)));
      const on = h('input', { type: 'checkbox', checked: c.on !== false });
      on.addEventListener('change', () => upd({ on: on.checked }));
      const flip = h('input', { type: 'checkbox', checked: !!c.flip });
      flip.addEventListener('change', () => upd({ flip: flip.checked }));
      const type = h('select.input.sm', { 'aria-label': `Plane ${i + 1} type` }, h('option', { value: 'horizontal' }, 'Horizontal'), h('option', { value: 'vertical' }, 'Vertical'), h('option', { value: 'custom' }, 'Custom (tilted)'));
      type.value = c.type || 'horizontal';
      type.addEventListener('change', () => upd({ type: type.value }));
      const fields =
        c.type === 'custom'
          ? [
              h('div.row3.cp-row', lengthField('Through X', c.at?.[0], (v) => upd({ at: [v, c.at?.[1] || 0] })), lengthField('Through Y', c.at?.[1], (v) => upd({ at: [c.at?.[0] || 0, v] })), lengthField('Through Z', c.z, (v) => upd({ z: v }))),
              h('div.row2', ...[['Facing (degrees)', 'angle'], ['Tilt up (degrees)', 'tilt']].map(([label, k]) => {
                const a = h('input.input.sm', { type: 'number', step: 5, value: c[k] || 0, 'aria-label': label });
                a.addEventListener('keydown', (e) => e.stopPropagation());
                a.addEventListener('change', () => upd({ [k]: +a.value || 0 }));
                return h('label.field', h('span.field-label', label), a);
              })),
            ]
          : (c.type || 'horizontal') === 'horizontal'
          ? [
              lengthField('Height', c.z, (v) => upd({ z: v })),
              h('div.inline', { style: { gap: '4px', flexWrap: 'wrap' } }, doc.levels().map((l) => h('button.btn.sm', { type: 'button', 'data-tip': `Cut 1.2 m above ${l.name}, as its plan does`, onClick: () => upd({ z: l.elevation + 1200, flip: false }) }, l.name))),
            ]
          : [
              h('div.row3.cp-row', lengthField('Through X', c.at?.[0], (v) => upd({ at: [v, c.at?.[1] || 0] })), lengthField('Through Y', c.at?.[1], (v) => upd({ at: [c.at?.[0] || 0, v] })), (() => {
                const a = h('input.input.sm', { type: 'number', step: 5, value: c.angle || 0, 'aria-label': 'Facing angle' });
                a.addEventListener('keydown', (e) => e.stopPropagation());
                a.addEventListener('change', () => upd({ angle: +a.value || 0 }));
                return h('label.field', h('span.field-label', 'Facing (degrees)'), a);
              })()),
            ];
      body.append(
        h('fieldset.cp-plane',
          h('legend', `Plane ${i + 1}`),
          h('div.inline', { style: { gap: '12px', alignItems: 'center' } }, h('label.check', on, h('span', 'On')), type, h('label.check', flip, h('span', 'Keep the other side')), h('button.btn.sm', { type: 'button', onClick: () => save(planes().filter((_, j) => j !== i), 'Remove cutting plane') }, 'Remove')),
          ...fields,
        ),
      );
    });
    if (list.length < MAX_CUT_PLANES)
      body.append(
        h('button.btn.sm', { type: 'button', onClick: () => {
          const lv = doc.levels()[0];
          save([...planes(), { type: 'horizontal', z: (lv?.elevation ?? 0) + 1200, at: [0, 0], angle: 0, flip: false, on: true }], 'Add cutting plane');
        } }, 'Add Cutting Plane'),
      );
    body.append(h('p.field-hint', 'A horizontal plane cuts away what is above its height; a vertical one what lies on the side it faces. They work with the section box.'));
  };
  render();
  return openDialog({ title: '3D Cutting Planes', size: 'md', body, actions: [{ label: 'Close', primary: true, value: null }] });
}
