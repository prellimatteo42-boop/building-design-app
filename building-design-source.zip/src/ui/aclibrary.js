/**
 * Archicad Library (File menu): open your own Archicad library files
 * (.libpack, .lcf or .gsm), browse their objects with a preview, and bring
 * them into the project as GDL objects, with the macros they use.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { drawLibraryPreview } from './library.js';
import { ArchicadLibrary, partType } from '../core/aclib.js';
import { partPreview } from '../io/gsm.js';
import { runGdlType } from '../core/gdlobject.js';

/** Pick library files from this computer. */
function pickFiles() {
  return new Promise((resolve) => {
    const input = h('input', { type: 'file', accept: '.libpack,.lcf,.gsm', multiple: true, hidden: true });
    input.addEventListener('change', () => {
      resolve([...(input.files || [])]);
      input.remove();
    });
    document.body.append(input);
    input.click();
  });
}

// Catalogue previews as object URLs, per library and part, made on first sight.
const previews = new WeakMap();
function previewUrl(lib, e) {
  let m = previews.get(lib);
  if (!m) previews.set(lib, (m = new Map()));
  if (!m.has(e.path)) {
    const pic = partPreview(e.bytes);
    m.set(e.path, pic ? URL.createObjectURL(new Blob([pic.bytes], { type: pic.mime })) : null);
  }
  return m.get(e.path);
}

export function archicadLibraryDialog(app, { find = '' } = {}) {
  const lib = (app.acLibrary ||= new ArchicadLibrary());
  let sel = null;
  let query = String(find).toLowerCase();
  const info = h('p.field-hint');
  const list = h('div.ac-list');
  const detail = h('div.ac-detail');
  const search = h('input.input', { type: 'search', placeholder: 'Search objects', 'aria-label': 'Search objects', value: find });
  search.addEventListener('keydown', (e) => e.stopPropagation());
  search.addEventListener('input', () => ((query = search.value.trim().toLowerCase()), renderList()));

  const add = async () => {
    const files = await pickFiles();
    for (const f of files) {
      try {
        const n = lib.add(f.name, new Uint8Array(await f.arrayBuffer()));
        toast(`${f.name}: ${n} library parts.`, { kind: 'success' });
      } catch (err) {
        toast(`${f.name}: ${err.message || err}`, { kind: 'error' });
      }
    }
    renderList();
  };

  const renderList = () => {
    clear(list);
    const objs = lib.objects();
    info.textContent = lib.files.length
      ? `${objs.length} objects in ${lib.files.map((f) => f.name).join(', ')}. Add the libraries that hold their macros too (Object Macros, Furniture Macros, Essential Library, and BuiltInLibraryParts.libpack from Archicad's own folder for stair and railing components).`
      : 'Add library files from your Archicad installation: .libpack packages, .lcf containers or single .gsm parts.';
    const shown = objs.filter((e) => !query || e.path.toLowerCase().includes(query)).slice(0, 400);
    let folder = null;
    for (const e of shown) {
      const f = e.path.split('/').slice(0, -1).join(' / ');
      if (f !== folder) list.append(h('div.ac-folder', (folder = f)));
      const url = previewUrl(lib, e);
      list.append(h(`button.ac-item${sel === e.name ? '.on' : ''}`, { type: 'button', onClick: () => ((sel = e.name), renderList(), renderDetail()) }, url ? h('img.ac-thumb', { src: url, alt: '', loading: 'lazy' }) : h('span.ac-thumb'), h('span', e.name)));
    }
  };

  const renderDetail = () => {
    clear(detail);
    const e = sel && lib.get(sel);
    if (!e) return;
    let type;
    try {
      type = partType(lib, e);
    } catch (err) {
      detail.append(h('p.dialog-text', `${e.name} could not be read: ${err.message || err}`));
      return;
    }
    const r = runGdlType(type);
    const planC = h('canvas', { width: 240, height: 180, 'aria-label': 'Plan preview' });
    const axoC = h('canvas', { width: 240, height: 180, 'aria-label': '3D preview' });
    const url = previewUrl(lib, e);
    detail.append(
      h('div.ac-head', url ? h('img.ac-preview', { src: url, alt: `${e.name} preview` }) : null, h('h3.ac-title', e.name)),
      h('p.field-hint', `${e.path} · ${Math.round(type.width)} x ${Math.round(type.depth)} x ${Math.round(type.height)} mm · ${type.gdl.params.length} parameters · ${Object.keys(type.gdl.macros).length} macros`),
      h('div.gdl-preview', planC, axoC),
      h('p.field-hint', r.error ? `Stopped: ${r.error}` : `${r.tris.length} triangles.${r.unknown ? ` Left out: ${Object.entries(r.unknown).sort((x, y) => y[1] - x[1]).slice(0, 6).map(([k]) => k).join(', ')}.` : ''}`),
    );
    drawLibraryPreview(type, (id) => app.doc.get(id), planC, axoC);
  };

  const importSel = () => {
    const e = sel && lib.get(sel);
    if (!e) return null;
    const existing = app.doc.all('componentType', 'doorType', 'windowType').find((t) => t.family === 'gdl' && t.gdl?.source === e.path);
    if (existing) return existing.id;
    let t;
    app.commit('Import Archicad object', () => (t = app.doc.add(partType(lib, e))));
    toast(`${e.name} is in the project as a GDL ${t.kind === 'doorType' ? 'door' : t.kind === 'windowType' ? 'window' : 'object'}.`, { kind: 'success' });
    return t.id;
  };

  renderList();
  return openDialog({
    title: 'Archicad Library',
    size: 'lg',
    className: 'ac-dialog',
    body: h('div', h('div.inline', { style: { gap: '8px', marginBottom: '8px' } }, h('button.btn', { type: 'button', onClick: add }, 'Add Library Files...'), search), info, h('div.ac-browser', list, detail)),
    actions: [
      { label: 'Close', value: null },
      { label: 'Import', onClick: () => (importSel(), false) },
      {
        label: 'Place',
        primary: true,
        onClick: () => {
          const id = importSel();
          if (!id) return false;
          const tool = { doorType: 'door', windowType: 'window' }[app.doc.get(id).kind] || 'component';
          app.setCurrentType(tool, id);
          return { id, tool };
        },
      },
    ],
  }).then((res) => {
    if (res?.tool) app.run(res.tool);
    return res?.id ?? null;
  });
}
