/**
 * Rich hover tooltips for any element with data-tip (title text) and
 * optional data-tip-desc and data-tip-keys. One shared element, shown after
 * a short delay on hover or keyboard focus, hidden on press or Escape.
 */
import { h } from './dom.js';

let tip = null;
let timer = 0;
let current = null;
let mode = 'full';

/** 'full' (with descriptions), 'short' (names and keys only) or 'off'. */
export function setTooltipMode(m) {
  mode = m || 'full';
}

function ensure() {
  if (!tip) {
    tip = h('div.tooltip', { role: 'tooltip', id: 'app-tooltip' });
    // The tooltip stays while the pointer moves onto it.
    tip.addEventListener('pointerenter', () => clearTimeout(timer));
    tip.addEventListener('pointerleave', (e) => {
      if (!current?.contains(e.relatedTarget)) hideTooltip();
    });
    document.body.append(tip);
  }
  return tip;
}

function show(el) {
  const t = ensure();
  if (mode === 'off') return;
  t.replaceChildren(h('div.tooltip-title', el.dataset.tip, el.dataset.tipKeys ? h('kbd', el.dataset.tipKeys) : null));
  if (el.dataset.tipDesc && mode !== 'short') t.append(h('div.tooltip-desc', el.dataset.tipDesc));
  // A tool's explanation: what it does, a way to learn it and a short film of it.
  t.classList.toggle('rich', !!el.dataset.tipMedia);
  if (el.dataset.tipMedia && mode !== 'short') {
    const cmd = el.dataset.tipCmd;
    t.append(
      h('button.tooltip-how', { type: 'button', onClick: () => { hideTooltip(); window.dispatchEvent(new CustomEvent('bd-show-how', { detail: { cmd, media: el.dataset.tipMedia, title: el.dataset.tip, text: el.dataset.tipDesc } })); } }, el.dataset.tipHow || 'Show me how'),
      h('img.tooltip-media', { src: el.dataset.tipMedia, alt: '', width: 200, height: 150, onError: (e) => e.target.remove() }),
    );
  }
  t.classList.add('show');
  const r = el.getBoundingClientRect();
  const w = t.offsetWidth,
    ht = t.offsetHeight;
  let x = r.left + r.width / 2 - w / 2;
  let y = r.bottom + 6;
  if (y + ht > innerHeight - 6) y = r.top - ht - 6;
  // A tool's explanation stands beside the Toolbox, where it covers none of the other tools.
  const side = el.dataset.tipMedia ? el.closest('.ac-toolbox')?.getBoundingClientRect() : null;
  if (side) {
    x = side.right + 2;
    y = Math.max(6, Math.min(r.top - 8, innerHeight - ht - 6));
  }
  x = Math.max(6, Math.min(x, innerWidth - w - 6));
  t.style.left = `${x}px`;
  t.style.top = `${y}px`;
  current = el;
}

export function hideTooltip() {
  clearTimeout(timer);
  current = null;
  tip?.classList.remove('show');
}

export function installTooltips(root = document) {
  root.addEventListener('pointerover', (e) => {
    if (e.pointerType === 'touch') return;
    const el = e.target.closest?.('[data-tip]');
    if (!el || el === current) return;
    clearTimeout(timer);
    // Slower from an explanation one can click, so the pointer can cross other tools on its way there.
    timer = setTimeout(() => show(el), current ? (current.dataset.tipMedia ? 260 : 80) : 550);
  });
  root.addEventListener('pointerout', (e) => {
    const el = e.target.closest?.('[data-tip]');
    if (!el || el.contains(e.relatedTarget) || tip?.contains(e.relatedTarget)) return;
    if (el !== current || !el.dataset.tipMedia) return hideTooltip();
    clearTimeout(timer);
    timer = setTimeout(hideTooltip, 320);
  });
  root.addEventListener('focusin', (e) => {
    const el = e.target.closest?.('[data-tip]');
    if (el && el.matches(':focus-visible')) {
      clearTimeout(timer);
      timer = setTimeout(() => show(el), 400);
    }
  });
  root.addEventListener('focusout', (e) => {
    if (!tip?.contains(e.relatedTarget)) hideTooltip();
  });
  root.addEventListener('pointerdown', (e) => {
    if (!tip?.contains(e.target)) hideTooltip();
  }, true);
  root.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') hideTooltip();
  });
}
