/**
 * Floating palettes (Window > Palettes): the Control Box (relative
 * construction: parallel, perpendicular, bisector; snaps and the Tracker),
 * the Coordinates palette (type X/Y, dX/dY or distance and angle and place
 * the point) and the Script Console (Archicad's Python palette, here
 * JavaScript run against the app's API, with scripts kept in the project).
 */
import { h } from './dom.js';
import { icon } from './icons.js';
import { draftingOf, trackerPoint } from '../core/drafting.js';
import { formatLength, parseLength, parseAngleDegrees } from '../core/units.js';
import { runScript, SCRIPT_EXAMPLES } from '../core/scripting.js';
import { newId } from '../core/doc.js';

const open = new Map();

/** A palette floating over the drawing, draggable by its title, one of each kind. */
function floating(app, key, title, body, { width = 260, at = null } = {}) {
  const old = open.get(key);
  if (old) {
    old.remove();
    open.delete(key);
    return null;
  }
  const wrap = app.shell.canvasWrap;
  const head = h('header.float-head', h('span', title), h('button.icon-btn.sm', { type: 'button', 'aria-label': `Close ${title}`, onClick: () => (el.remove(), open.delete(key)) }, icon('x', 14)));
  const el = h('section.float-palette', { role: 'dialog', 'aria-label': title, style: { width: `${width}px`, left: `${at?.[0] ?? 16}px`, top: `${at?.[1] ?? 16}px` } }, head, body);
  let drag = null;
  head.addEventListener('pointerdown', (e) => {
    if (e.target.closest('button')) return;
    drag = { x: e.clientX - el.offsetLeft, y: e.clientY - el.offsetTop };
    head.setPointerCapture(e.pointerId);
  });
  head.addEventListener('pointermove', (e) => {
    if (!drag) return;
    el.style.left = `${Math.max(0, Math.min(wrap.clientWidth - 60, e.clientX - drag.x))}px`;
    el.style.top = `${Math.max(0, Math.min(wrap.clientHeight - 30, e.clientY - drag.y))}px`;
  });
  head.addEventListener('pointerup', () => (drag = null));
  el.addEventListener('keydown', (e) => e.stopPropagation());
  wrap.append(el);
  open.set(key, el);
  return el;
}

export const paletteOpen = (key) => open.has(key);

/** Control Box: relative construction methods and the input aids, as toggle buttons. */
export function controlBox(app) {
  const btn = (label, tip, cmd, on) => {
    const b = h('button.btn.sm', { type: 'button', 'data-tip': tip, 'aria-pressed': String(!!on()), onClick: () => (app.run(cmd), sync()) }, label);
    b._on = on;
    return b;
  };
  const buttons = [
    btn('∥ Parallel', 'Point at an edge: the next points move parallel to it (PA)', 'parallelConstraint', () => app.constraint?.kind === 'parallel'),
    btn('⊥ Perpendicular', 'Point at an edge: the next points move square to it', 'perpendicularConstraint', () => app.constraint?.kind === 'perpendicular'),
    btn('∠ Bisector', 'Point at a corner: the next points move along its bisector (BI)', 'bisectorConstraint', () => app.constraint?.kind === 'bisector'),
    btn('Snaps', 'Snap to points and edges', 'snapsOnOff', () => app.settings.snaps?.enabled !== false),
    btn('Tracker', 'The coordinates box by the cursor', 'tracker', () => app.settings.tracker !== false),
    btn('Grid Snap', 'Snap to the construction grid (GS)', 'gridSnap', () => !!draftingOf(app.doc?.project).grid.snap),
  ];
  const sync = () => buttons.forEach((b) => b.setAttribute('aria-pressed', String(!!b._on())));
  const body = h('div.float-body', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px' } }, buttons);
  const el = floating(app, 'controlBox', 'Control Box', body, { width: 250 });
  if (el) el.addEventListener('pointerenter', sync);
}

/** Coordinates: type a point (absolute from the user origin, or from the last point) and place it. */
export function coordinatesPalette(app) {
  const units = app.doc.units;
  let mode = app.settings.coordsMode || 'polar';
  const fields = { absolute: [['x', 'X'], ['y', 'Y']], xy: [['dx', 'ΔX'], ['dy', 'ΔY']], polar: [['r', 'Distance'], ['angle', 'Angle °']] };
  const body = h('div.float-body');
  const info = h('p.field-hint');
  const render = () => {
    const inputs = fields[mode].map(([k, label]) => ({ k, i: h('input.input.sm', { type: 'text', 'aria-label': label, placeholder: label, spellcheck: 'false' }) }));
    const place = () => {
      const t = app.tool;
      if (!t || t === app.selectTool) return (info.textContent = 'Start a drawing tool first.');
      const from = t.lastFrom || null;
      const v = { kind: from ? mode : 'absolute' };
      for (const { k, i } of inputs) {
        const raw = i.value.trim();
        if (!raw) continue;
        v[k] = k === 'angle' ? parseAngleDegrees(raw, units) : parseLength(raw, units);
      }
      if (!from && mode !== 'absolute') {
        // The first point is always absolute: read the two fields as X and Y.
        v.x = v.dx ?? v.r ?? 0;
        v.y = v.dy ?? v.angle ?? 0;
      }
      const p = trackerPoint(v, { from, origin: draftingOf(app.doc.project).userOrigin });
      app.tracker.place_point(p);
      info.textContent = `Placed at ${formatLength(p[0], units)}, ${formatLength(p[1], units)}.`;
      inputs[0].i.focus();
      inputs.forEach((x) => (x.i.value = ''));
    };
    for (const { i } of inputs) i.addEventListener('keydown', (e) => e.key === 'Enter' && (e.preventDefault(), place()));
    const seg = h(
      'div.seg',
      { role: 'radiogroup', 'aria-label': 'Coordinates' },
      [['absolute', 'X Y'], ['xy', 'ΔX ΔY'], ['polar', 'r a']].map(([v, l]) => h('button.seg-btn', { type: 'button', role: 'radio', 'aria-checked': String(v === mode), onClick: () => ((mode = v), app.settingsStore.set('coordsMode', v), render()) }, l)),
    );
    body.replaceChildren(seg, h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px', margin: '6px 0' } }, inputs.map((x) => x.i)), h('button.btn.sm.primary', { type: 'button', onClick: place }, 'Place Point'), info);
    info.textContent = 'The first point is from the user origin, the next ones from the last point. Enter places it.';
  };
  render();
  floating(app, 'coordinates', 'Coordinates', body, { width: 250, at: [16, 140] });
}

/** Script Console: JavaScript against the app's API, scripts kept in the project. */
export function scriptConsole(app) {
  const doc = app.doc;
  const code = h('textarea.input', { rows: 9, spellcheck: 'false', 'aria-label': 'Script', style: { fontFamily: 'var(--mono, monospace)', fontSize: '12px', width: '100%' } }, SCRIPT_EXAMPLES[0].code);
  const out = h('pre.script-out', { 'aria-live': 'polite', style: { maxHeight: '160px', overflow: 'auto', fontSize: '12px', margin: '6px 0 0', whiteSpace: 'pre-wrap' } });
  const saved = h('select.input.sm', { 'aria-label': 'Saved scripts' });
  const fill = () => {
    const list = doc.get('project')?.scripts || [];
    saved.replaceChildren(h('option', { value: '' }, 'Examples and saved scripts'), ...SCRIPT_EXAMPLES.map((x, i) => h('option', { value: `ex:${i}` }, `Example: ${x.name}`)), ...list.map((x) => h('option', { value: x.id }, x.name)));
  };
  fill();
  saved.addEventListener('change', () => {
    const v = saved.value;
    if (v.startsWith('ex:')) code.value = SCRIPT_EXAMPLES[+v.slice(3)].code;
    else if (v) code.value = (doc.get('project')?.scripts || []).find((x) => x.id === v)?.code || code.value;
  });
  const run = async () => {
    out.textContent = 'Running...';
    const r = await runScript(app, code.value);
    out.textContent = [...r.log, r.error ? `Error: ${r.error}` : r.result !== undefined ? `→ ${typeof r.result === 'string' ? r.result : JSON.stringify(r.result, null, 1)}` : '✓ Done'].join('\n');
  };
  const save = () => {
    const name = prompt('Name of the script', 'My script');
    if (!name) return;
    const list = [...(doc.get('project')?.scripts || [])];
    const i = list.findIndex((x) => x.name === name);
    const item = { id: i >= 0 ? list[i].id : newId('sc'), name, code: code.value };
    if (i >= 0) list[i] = item;
    else list.push(item);
    app.commit('Save script', () => doc.update('project', { scripts: list }));
    fill();
  };
  code.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') (e.preventDefault(), run());
  });
  const body = h('div.float-body', saved, code, h('div.inline', { style: { gap: '6px', marginTop: '6px' } }, h('button.btn.sm.primary', { type: 'button', onClick: run }, 'Run (Ctrl+Enter)'), h('button.btn.sm', { type: 'button', onClick: save }, 'Save...')), out);
  floating(app, 'scripts', 'Script Console', body, { width: 420, at: [16, 60] });
}
