/**
 * Fill Types dialog: vector hatches made of families of parallel lines,
 * with a live preview, used by Fill elements and building materials.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { icon } from './icons.js';
import { hatchSegments, dashText, parseDashes } from '../core/filltypes.js';
import { uniqueName } from '../core/ops.js';

const field = (label, control) => h('label.field', h('span.field-label', label), control);

function drawPreview(ft, canvas) {
  const ctx = canvas.getContext('2d');
  const W = canvas.width;
  const H = canvas.height;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);
  // Model fill types over 2.4 m; paper ones as on a 60 mm square of paper.
  const span = ft.scale === 'paper' ? 60 : 2400;
  const k = W / span;
  const poly = [[0, 0], [span, 0], [span, (span * H) / W], [0, (span * H) / W]];
  ctx.strokeStyle = '#222';
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (const [a, b] of hatchSegments(poly, [], ft, 1)) {
    ctx.moveTo(a[0] * k, H - a[1] * k);
    ctx.lineTo(b[0] * k, H - b[1] * k);
  }
  ctx.stroke();
}

export function fillTypesDialog(app) {
  const doc = app.doc;
  let sel = doc.all('fillType')[0]?.id;
  const list = h('ul.file-list.mat-list');
  const detail = h('div.mat-detail');
  const set = (patch) => {
    app.commit('Fill type', () => doc.update(sel, patch));
    renderList();
    renderDetail();
  };
  const uses = (id) => doc.filter((e) => (e.kind === 'region' && e.pattern === id) || (e.kind === 'material' && e.fillTypeId === id)).length;
  const renderDetail = () => {
    clear(detail);
    const ft = doc.get(sel);
    if (!ft) return detail.append(h('p.props-empty', 'No fill types. Add one.'));
    const name = h('input.input', { type: 'text', value: ft.name, 'aria-label': 'Name' });
    name.addEventListener('change', () => name.value.trim() && set({ name: name.value.trim() }));
    const scale = h('select.input', { 'aria-label': 'Scale' }, h('option', { value: 'model' }, 'Scaled to the model (mm on site)'), h('option', { value: 'paper' }, 'Fixed on paper (mm on the printed sheet)'));
    scale.value = ft.scale || 'model';
    scale.addEventListener('change', () => set({ scale: scale.value }));
    const orient = h('select.input', { 'aria-label': 'Orientation' }, h('option', { value: 'element' }, 'Follows the element (along walls)'), h('option', { value: 'project' }, 'Project axes'));
    orient.value = ft.orientation || 'element';
    orient.addEventListener('change', () => set({ orientation: orient.value }));
    const rows = h('div.ft-rows');
    ft.families.forEach((f, i) => {
      const upd = (patch) => set({ families: doc.get(sel).families.map((x, j) => (j === i ? { ...x, ...patch } : x)) });
      const num = (key, label, value, step = 1) => {
        const el = h('input.input.sm', { type: 'number', step, value, 'aria-label': `${label} of line set ${i + 1}` });
        el.addEventListener('change', () => upd({ [key]: +el.value || 0 }));
        return el;
      };
      const ox = h('input.input.sm', { type: 'number', value: f.origin?.[0] || 0, 'aria-label': `Origin X of line set ${i + 1}` });
      const oy = h('input.input.sm', { type: 'number', value: f.origin?.[1] || 0, 'aria-label': `Origin Y of line set ${i + 1}` });
      const setO = () => upd({ origin: [+ox.value || 0, +oy.value || 0] });
      ox.addEventListener('change', setO);
      oy.addEventListener('change', setO);
      const dashes = h('input.input.sm', { type: 'text', value: dashText(f.dashes), placeholder: 'solid', 'aria-label': `Dashes of line set ${i + 1}` });
      dashes.addEventListener('change', () => upd({ dashes: parseDashes(dashes.value) }));
      const del = h('button.icon-btn.sm', { type: 'button', 'aria-label': `Remove line set ${i + 1}`, disabled: ft.families.length <= 1, onClick: () => set({ families: doc.get(sel).families.filter((_, j) => j !== i) }) }, icon('trash', 13));
      rows.append(h('div.ft-row', num('angle', 'Angle', f.angle || 0), num('spacing', 'Spacing', f.spacing || 0, 0.1), num('shift', 'Shift', f.shift || 0, 0.1), ox, oy, dashes, del));
    });
    const canvas = h('canvas.ft-preview', { width: 360, height: 200, role: 'img', 'aria-label': `Preview of ${ft.name}` });
    const n = uses(ft.id);
    detail.append(
      h('div.row2', field('Name', name), field('Scale', scale)),
      field('Orientation in walls', orient),
      canvas,
      h('div.ft-row.ft-head', h('span', 'Angle °'), h('span', 'Spacing'), h('span', 'Shift'), h('span', 'Origin X'), h('span', 'Origin Y'), h('span', 'Dashes'), h('span')),
      rows,
      h('button.btn.sm', { type: 'button', onClick: () => set({ families: [...ft.families, { angle: 0, origin: [0, 0], shift: 0, spacing: ft.scale === 'paper' ? 2 : 100, dashes: [] }] }) }, icon('plus', 14), 'Add Line Set'),
      h('p.field-hint', 'Each line set draws parallel lines at an angle, a spacing apart; each next line moves along by the shift. Dashes alternate drawn (positive) and gap (negative) lengths, as in "75 -75". Lengths are millimetres on site, or on paper for paper fill types.'),
      h('p.field-hint', n ? `Used by ${n} fill${n === 1 ? '' : 's'} and materials.` : 'Not used yet: choose it as a Fill\'s pattern or a material\'s vector fill type.'),
    );
    requestAnimationFrame(() => drawPreview(ft, canvas));
  };
  const renderList = () => {
    clear(list);
    for (const f of doc.all('fillType')) list.append(h('li', h('button.file-item', { type: 'button', 'aria-pressed': String(f.id === sel), onClick: () => ((sel = f.id), renderList(), renderDetail()) }, icon('boundary', 14), h('span.file-name', f.name), h('span.file-meta', f.scale === 'paper' ? 'paper' : 'model'))));
  };
  const add = (base) => {
    let id;
    const { id: _id, ...rest } = base;
    app.commit('New fill type', () => (id = doc.add({ ...JSON.parse(JSON.stringify(rest)), kind: 'fillType', name: uniqueName(doc.all('fillType').map((x) => x.name), `${base.name} 2`) }).id));
    sel = id;
    renderList();
    renderDetail();
  };
  renderList();
  renderDetail();
  return openDialog({
    title: 'Fill Types',
    size: 'lg',
    body: h(
      'div.mat-layout',
      h(
        'div.mat-side',
        list,
        h(
          'div.inline',
          { style: { marginTop: '8px', gap: '6px' } },
          h('button.btn.sm', { type: 'button', onClick: () => add({ name: 'Fill', scale: 'model', families: [{ angle: 45, origin: [0, 0], shift: 0, spacing: 100, dashes: [] }] }) }, icon('plus', 14), 'New'),
          h('button.btn.sm', { type: 'button', disabled: !sel, onClick: () => add(doc.get(sel)) }, 'Duplicate'),
          h('button.btn.sm', { type: 'button', disabled: !sel, onClick: () => {
            if (uses(sel)) return toast('Fills or materials use this fill type: change them first.', { kind: 'error' });
            app.commit('Delete fill type', () => doc.remove(sel));
            sel = doc.all('fillType')[0]?.id;
            renderList();
            renderDetail();
          } }, icon('trash', 14), 'Delete'),
        ),
      ),
      detail,
    ),
    actions: [{ label: 'Close', primary: true, value: null }],
  });
}
