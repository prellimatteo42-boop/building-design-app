/**
 * Curtain wall type settings for schemes, frame classes and panel classes
 * (core/cwscheme.js), shown under the curtain grid in the type dialog.
 */
import { h } from './dom.js';
import { icon } from './icons.js';
import { formatLength, parseLength } from '../core/units.js';
import { newId } from '../core/doc.js';
import { FIT_MODES, FRAME_KINDS, PANEL_KINDS, frameRoles, panelClasses, parsePattern } from '../core/cwscheme.js';

const field = (label, control) => h('label.field', h('span.field-label', label), control);

export function curtainSchemeEditor(app, t) {
  const doc = app.doc;
  const wrap = h('div.cw-scheme', { style: { marginTop: '12px' } });
  const cur = () => doc.get(t.id)?.curtain || {};
  const set = (patch, name = 'Curtain wall scheme') => {
    app.commit(name, () => doc.update(t.id, { curtain: { ...cur(), ...patch } }));
    render();
  };
  const len = (v, label, onSet) => {
    const i = h('input.input', { type: 'text', value: formatLength(+v || 0, doc.units), 'aria-label': label, spellcheck: 'false', style: { width: '90px' } });
    i.addEventListener('change', () => {
      const x = parseLength(i.value, doc.units);
      if (Number.isFinite(x) && x > 0) onSet(x);
    });
    return i;
  };
  const sel = (opts, v, label, onSet) => {
    const s = h('select.input', { 'aria-label': label }, opts.map((o) => h('option', { value: o.value, selected: o.value === v }, o.label)));
    s.addEventListener('change', () => onSet(s.value));
    return s;
  };
  const text = (v, label, onSet, width = '140px') => {
    const i = h('input.input', { type: 'text', value: v ?? '', 'aria-label': label, style: { width } });
    i.addEventListener('change', () => onSet(i.value));
    return i;
  };
  const materials = () => [{ value: '', label: 'By type' }, ...doc.all('material').map((m) => ({ value: m.id, label: m.name }))];

  const render = () => {
    const c = cur();
    wrap.replaceChildren();
    // Schemes.
    const scheme = (axis, label) => {
      const s = c[axis] || {};
      const pat = text((s.pattern || []).map((x) => formatLength(x, doc.units)).join(', '), `${label} module pattern`, (v) => {
        const sizes = String(v)
          .split(/[,;]+/)
          .map((x) => parseLength(x.trim(), doc.units))
          .filter((x) => Number.isFinite(x) && x > 0);
        set({ [axis]: sizes.length ? { ...s, pattern: sizes, fit: s.fit || 'repeat' } : null });
      }, '220px');
      const fit = sel(FIT_MODES, s.fit || 'repeat', `${label} fit`, (v) => set({ [axis]: { ...s, fit: v } }));
      return h('div.row2', field(`${label}: module pattern (empty = equal panels)`, pat), field('Distribution', fit));
    };
    wrap.append(h('h3.dlg-sub', 'Scheme'), scheme('uScheme', 'Along the wall'), scheme('vScheme', 'Up the wall'));
    const n = parsePattern(c.uScheme?.pattern).length;
    if (n) wrap.append(h('p.field-hint', `${n} modules repeated along the wall. Grid lines placed on a wall by hand still win.`));

    // Frames.
    const roles = frameRoles(c);
    const frames = h('table.cw-classes', h('thead', h('tr', ...['Frame class', 'Profile', 'Width', 'Depth', 'Material', ''].map((x) => h('th', x)))));
    const tbody = h('tbody');
    for (const r of ['boundary', 'mullion', 'transom']) {
      const f = roles[r];
      const put = (patch) => set({ frames: { ...(c.frames || {}), [r]: { ...(c.frames?.[r] || {}), ...patch } } }, 'Curtain wall frames');
      tbody.append(
        h('tr', h('td', f.name), h('td', sel(FRAME_KINDS, f.kind, `${f.name} profile`, (v) => put({ kind: v }))), h('td', len(f.width, `${f.name} width`, (v) => put({ width: v }))), h('td', len(f.depth, `${f.name} depth`, (v) => put({ depth: v }))), h('td', sel(materials(), f.materialId || '', `${f.name} material`, (v) => put({ materialId: v || null }))), h('td')),
      );
    }
    const own = c.frameClasses || [];
    own.forEach((f, k) => {
      const put = (patch) => set({ frameClasses: own.map((x, i) => (i === k ? { ...x, ...patch } : x)) }, 'Curtain wall frames');
      tbody.append(
        h(
          'tr',
          h('td', text(f.name, 'Frame class name', (v) => put({ name: v || f.name }), '110px')),
          h('td', sel(FRAME_KINDS, f.kind || 'rect', `${f.name} profile`, (v) => put({ kind: v }))),
          h('td', len(f.width ?? roles.mullion.width, `${f.name} width`, (v) => put({ width: v }))),
          h('td', len(f.depth ?? roles.mullion.depth, `${f.name} depth`, (v) => put({ depth: v }))),
          h('td', sel(materials(), f.materialId || '', `${f.name} material`, (v) => put({ materialId: v || null }))),
          h('td', h('button.icon-btn.sm', { type: 'button', 'aria-label': `Delete ${f.name}`, onClick: () => set({ frameClasses: own.filter((_, i) => i !== k) }, 'Delete frame class') }, icon('trash', 14))),
        ),
      );
    });
    frames.append(tbody);
    const addFrame = h('button.btn.sm', { type: 'button', onClick: () => set({ frameClasses: [...own, { id: newId('fc'), name: `Frame ${own.length + 1}`, kind: 'rect', width: roles.mullion.width, depth: roles.mullion.depth * 2 }] }, 'Add frame class') }, icon('plus', 14), 'Add Frame Class');
    wrap.append(h('h3.dlg-sub', 'Frames'), frames, h('div', { style: { marginTop: '6px' } }, addFrame));

    // Panels.
    const all = panelClasses(c);
    const main = sel(all.filter((p) => p.kind !== 'empty').map((p) => ({ value: p.id, label: p.name })), c.mainPanel || 'glass', 'Main panel', (v) => set({ mainPanel: v === 'glass' ? null : v }, 'Curtain wall panels'));
    const glassT = len(c.panelThickness || 12, 'Glass thickness', (v) => set({ panelThickness: v }, 'Curtain wall panels'));
    wrap.append(h('h3.dlg-sub', 'Panels'), h('div.row2', field('Main panel', main), field('Glass thickness', glassT)));
    const ownP = c.panelClasses || [];
    if (ownP.length) {
      const table = h('table.cw-classes', h('thead', h('tr', ...['Panel class', 'Kind', 'Thickness', 'Material', ''].map((x) => h('th', x)))));
      const body = h('tbody');
      ownP.forEach((p, k) => {
        const put = (patch) => set({ panelClasses: ownP.map((x, i) => (i === k ? { ...x, ...patch } : x)) }, 'Curtain wall panels');
        body.append(
          h(
            'tr',
            h('td', text(p.name, 'Panel class name', (v) => put({ name: v || p.name }), '110px')),
            h('td', sel(PANEL_KINDS.filter((x) => x.value !== 'empty'), p.kind || 'glass', `${p.name} kind`, (v) => put({ kind: v }))),
            h('td', len(p.thickness || 12, `${p.name} thickness`, (v) => put({ thickness: v }))),
            h('td', sel(materials(), p.materialId || '', `${p.name} material`, (v) => put({ materialId: v || null }))),
            h('td', h('button.icon-btn.sm', { type: 'button', 'aria-label': `Delete ${p.name}`, onClick: () => set({ panelClasses: ownP.filter((_, i) => i !== k), mainPanel: c.mainPanel === p.id ? null : c.mainPanel }, 'Delete panel class') }, icon('trash', 14))),
          ),
        );
      });
      table.append(body);
      wrap.append(table);
    }
    wrap.append(h('div', { style: { marginTop: '6px' } }, h('button.btn.sm', { type: 'button', onClick: () => set({ panelClasses: [...ownP, { id: newId('pc'), name: `Panel ${ownP.length + 1}`, kind: 'solid', thickness: 40 }] }, 'Add panel class') }, icon('plus', 14), 'Add Panel Class')));
    wrap.append(h('p.field-hint', 'Assign frame and panel classes to single segments and cells with Mullions and Panels.'));
  };
  render();
  return wrap;
}
