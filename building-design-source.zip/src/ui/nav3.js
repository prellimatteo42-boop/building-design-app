/**
 * More navigation and input aids: forced axes and offset constraints, quick
 * rotation of the selection, 3D projection by numbers, animation controls,
 * guide eraser, filter and cut in 3D.
 */
import { h } from './dom.js';
import { openDialog, toast, promptDialog } from './dialog.js';
import { rotation, transformElements } from '../core/ops.js';
import { cameraEye, cameraLooking } from '../core/flythrough.js';
import { CATEGORIES, categoryOf } from '../core/catalog.js';
import { horizontalRuns } from './mep.js';
import { connectedMep } from '../core/mepnet.js';
import { linesNearPointer } from './drafting.js';
import { formatLength, parseLength } from '../core/units.js';

export function axisConstraint(app, kind) {
  if (app.constraint?.kind === kind) {
    app.constraint = null;
    return app.requestRender();
  }
  app.constraint = kind === 'horizontal' ? { kind, dir: [1, 0], label: 'Horizontal' } : { kind, dir: [0, 1], label: 'Vertical' };
  app.requestRender();
}

/** Offset, Multiple Offset and Snap Point constraints: point at an edge, then give the distance or the parts. */
export async function edgeConstraint(app, kind) {
  if (app.constraint?.kind === kind) {
    app.constraint = null;
    app.toast('Constraint released.');
    return app.requestRender();
  }
  const [l] = linesNearPointer(app);
  if (!l) return app.toast('Point at an edge, then run the constraint again.');
  const units = app.doc.units;
  if (kind === 'snapPoints') {
    const v = await promptDialog('Snap Point Constraint', 'Divide the edge into how many parts?', '4');
    if (v == null) return;
    app.constraint = { kind, a: l.a, b: l.b, n: Math.max(1, Math.round(+v) || 1), label: 'Snap Points' };
  } else {
    const v = await promptDialog(kind === 'offset' ? 'Offset Constraint' : 'Multiple Offset Constraint', 'Distance from the edge', formatLength(1000, units));
    if (v == null) return;
    const distance = parseLength(v, units);
    if (!(distance > 0)) return app.toast('That is not a distance.', { kind: 'error' });
    app.constraint = { kind, a: l.a, b: l.b, distance, label: kind === 'offset' ? 'Offset' : 'Multiple Offset' };
  }
  app.toast(`${app.constraint.label} constraint on. Run it again or press Escape to release.`);
  app.requestRender();
}

/** Quick Rotate: the selection a quarter turn about its centre. */
export function quickRotate(app, clockwise) {
  const c = app.vc;
  if (!c?.is2D || !app.selection.size) return toast('Select something in a plan first.');
  c.sync?.();
  const b = c.extents?.(new Set(app.selection));
  if (!b) return;
  const center = [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2];
  app.commit('Quick rotate', () => transformElements(app.doc, [...app.selection], rotation(center, ((clockwise ? -1 : 1) * Math.PI) / 2)));
}

/** 3D Projection Settings: the camera by numbers. */
export function projectionSettings(app) {
  const c = app.vc;
  if (app.activeView?.kind !== 'view3d' || !c?.cam?.target) return toast('Open a 3D view first.', { kind: 'error' });
  const eye = cameraEye(c.cam);
  const num = (label, v, step = 10) => {
    const i = h('input.input', { type: 'number', step, value: Math.round(v * 100) / 100, 'aria-label': label });
    i.addEventListener('keydown', (e) => e.stopPropagation());
    return [i, h('label.field', h('span.field-label', label), i)];
  };
  const [ex, f1] = num('Camera X (mm)', eye[0]);
  const [ey, f2] = num('Camera Y (mm)', eye[1]);
  const [ez, f3] = num('Camera Z (mm)', eye[2]);
  const [tx, f4] = num('Target X (mm)', c.cam.target[0]);
  const [ty, f5] = num('Target Y (mm)', c.cam.target[1]);
  const [tz, f6] = num('Target Z (mm)', c.cam.target[2]);
  const [fov, f7] = num('View cone (degrees)', +c.cam.fov || 45, 1);
  const persp = h('input', { type: 'checkbox', checked: c.cam.persp !== false });
  return openDialog({
    title: '3D Projection Settings',
    body: h('div', h('div.row3', f1, f2, f3), h('div.row3', f4, f5, f6), f7, h('label.check', persp, h('span', 'Perspective (off: parallel)'))),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'OK',
        primary: true,
        onClick: () => {
          const next = cameraLooking([+ex.value, +ey.value, +ez.value], [+tx.value, +ty.value, +tz.value], { fov: Math.max(1, Math.min(150, +fov.value || 45)) });
          app.vc.cam = { ...app.vc.cam, ...next, persp: persp.checked, fov: Math.max(1, Math.min(150, +fov.value || 45)) };
          app.vc.userMoved = true;
          app.requestRender();
          return true;
        },
      },
    ],
  });
}

/** Animation Controls: play, pause and step the fly-through a frame at a time. */
export function animationControls(app) {
  const fly = app.flyPalette;
  if (fly.cams().length < 2) return toast('The fly-through needs two cameras first.', { kind: 'error' });
  const pos = h('input', { type: 'range', min: 0, max: 1, step: 0.001, value: fly.u || 0, 'aria-label': 'Position', style: { width: '100%' } });
  pos.addEventListener('input', () => fly.seek(+pos.value));
  const sync = () => (pos.value = fly.u || 0);
  const btn = (label, f) => h('button.btn.sm', { type: 'button', onClick: () => (f(), sync()) }, label);
  const timer = setInterval(sync, 200);
  const done = openDialog({ title: 'Animation Controls', body: h('div', pos, h('div.inline', { style: { gap: '6px', marginTop: '8px' } }, btn('Start', () => fly.seek(0)), btn('Step Back', () => fly.stepFrame(-1)), btn('Play', () => fly.play()), btn('Pause', () => fly.pause()), btn('Step', () => fly.stepFrame(1)))), actions: [{ label: 'Close', value: null }] });
  done?.finally?.(() => (clearInterval(timer), fly.pause()));
  return done;
}

/** Select Connected Horizontal Routes: the horizontal runs of the selection's network. */
export function selectHorizontalRoutes(app) {
  const ids = horizontalRuns(app.doc, connectedMep(app.doc, [...app.selection]));
  if (!ids.length) return toast('Select a duct, pipe, cable tray or conduit on a horizontal route.', { kind: 'error' });
  app.select(ids);
  toast(`${ids.length} horizontal run${ids.length === 1 ? '' : 's'} selected.`);
}

export function deleteAllCuttingPlanes(app) {
  const v = app.activeView;
  if (v?.kind !== 'view3d') return toast('Open a 3D view first.', { kind: 'error' });
  if (!v.cutPlanes?.length) return toast('This view has no cutting planes.');
  app.commit('Delete cutting planes', () => app.doc.update(v.id, { cutPlanes: [] }));
  app.requestRender();
}

/** Filter and Cut Elements in 3D: which kinds of element show, the stories, the cutting planes. */
export function filterAndCut(app) {
  const doc = app.doc;
  const view = app.activeView;
  if (view?.kind !== 'view3d') return toast('Open a 3D view first.', { kind: 'error' });
  const used = new Set();
  for (const el of doc.items.values()) if (el.kind && !el.viewId) used.add(categoryOf(el, doc));
  const rows = CATEGORIES.filter((c) => used.has(c.id)).map((c) => {
    const cb = h('input', { type: 'checkbox', checked: !(view.hiddenCats || []).includes(c.id) });
    cb.addEventListener('change', () => {
      const hidden = new Set(doc.get(view.id).hiddenCats || []);
      if (cb.checked) hidden.delete(c.id);
      else hidden.add(c.id);
      app.commit('Filter 3D by type', () => doc.update(view.id, { hiddenCats: [...hidden] }));
      app.flagsVersion++;
      app.requestRender();
    });
    return h('label.check', cb, h('span', c.label));
  });
  return openDialog({
    title: 'Filter and Cut Elements in 3D',
    body: h('div', h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2px 12px', maxHeight: '45vh', overflow: 'auto' } }, rows), h('div.inline', { style: { gap: '6px', marginTop: '10px' } }, h('button.btn.sm', { type: 'button', onClick: () => app.run('filter3d') }, 'Stories...'), h('button.btn.sm', { type: 'button', onClick: () => app.run('cutPlanes') }, 'Cutting Planes...'), h('button.btn.sm', { type: 'button', onClick: () => deleteAllCuttingPlanes(app) }, 'Delete All Planes'))),
    actions: [{ label: 'Close', value: null }],
  });
}
