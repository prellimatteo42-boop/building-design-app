/**
 * IFC Local Preferences (what an IFC import keeps, how storeys meet the
 * project's levels) and Extract a Container (the files of an Archicad
 * .lcf/.libpack container in a ZIP, with their folders).
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { download } from '../io/storage.js';
import { makeZip } from '../io/zip.js';
import { readContainer } from '../io/gsm.js';
import { IFC_LOCAL_DEFAULTS } from '../io/ifcmodel.js';

export function ifcLocalPreferences(app) {
  const cur = { ...IFC_LOCAL_DEFAULTS, ...(app.settings.ifcLocal || {}) };
  const check = (key, label) => {
    const inp = h('input', { type: 'checkbox', checked: !!cur[key] });
    inp.addEventListener('change', () => (cur[key] = inp.checked));
    return h('label', { style: 'display:flex;gap:8px;align-items:center;margin:4px 0' }, [inp, label]);
  };
  const tol = h('input.input', { type: 'number', min: 1, step: 1, value: cur.levelTolerance, style: 'width:7em' });
  tol.addEventListener('input', () => (cur.levelTolerance = Math.max(1, +tol.value || 20)));
  const body = h('div', {}, [
    h('p.field-hint', {}, 'These preferences belong to this computer, not to the project. They apply to the next IFC file opened or merged.'),
    check('keepGuids', 'Keep the IFC GlobalIds of imported elements (needed for Update with IFC and to export them again with the same ids)'),
    check('keepNames', 'Keep the IFC names of imported elements'),
    check('keepProps', 'Keep the IFC property sets of imported elements'),
    check('matchLevels', 'Put IFC storeys on existing levels at the same elevation'),
    h('label', { style: 'display:flex;gap:8px;align-items:center;margin:4px 0 0 24px' }, ['Elevation tolerance (mm)', tol]),
  ]);
  return openDialog({ title: 'IFC Local Preferences', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    app.settingsStore.set('ifcLocal', cur);
    toast('IFC preferences saved.', { kind: 'success' });
  });
}

/** Every file of a container (and of the containers inside it) with its path. */
export function containerFiles(bytes) {
  const out = [];
  const walk = (b, prefix) => {
    for (const f of readContainer(b)) {
      if (/\.lcf$/i.test(f.path) && String.fromCharCode(...f.bytes.subarray(0, 4)) === 'GLCF') walk(f.bytes, `${prefix}${f.path.replace(/\.lcf$/i, '')}/`);
      else out.push({ name: `${prefix}${f.path}`, data: f.bytes });
    }
  };
  walk(bytes, '');
  return out;
}

export function extractContainer(app) {
  const input = h('input', { type: 'file', accept: '.lcf,.libpack', hidden: true });
  input.addEventListener('change', async () => {
    const f = input.files?.[0];
    input.remove();
    if (!f) return;
    try {
      const files = containerFiles(new Uint8Array(await f.arrayBuffer()));
      if (!files.length) return toast(`${f.name} holds no files.`, { kind: 'error' });
      download(new Blob([makeZip(files)], { type: 'application/zip' }), `${f.name.replace(/\.(lcf|libpack)$/i, '')}.zip`);
      toast(`${files.length} files extracted from ${f.name}.`, { kind: 'success' });
    } catch (err) {
      toast(`${f.name} is not a library container: ${err.message || err}`, { kind: 'error' });
    }
  });
  document.body.append(input);
  input.click();
}
