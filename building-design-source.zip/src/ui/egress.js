/**
 * Escape Check (Codice di prevenzione incendi, S.4): the active level's zones with their occupants, longest way out and
 * dead end against the profile's limits, the exits with the occupants they take and the width they need; the routes
 * drawn on the plan and the results kept on the zones (for a room schedule).
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { checkLevel, applyEgress, RVITA } from '../core/egressmodel.js';
import { withComma } from '../core/units.js';

const PROFILE_HINT = {
  A: 'awake, familiar with the building', B: 'awake, not familiar', Cii: 'asleep, long stays (residential)', Ciii: 'asleep, short stays (hotels, hostels)', D: 'receiving care', E: 'in transit',
};

export async function egressDialog(app) {
  const doc = app.doc;
  const levelId = app.activeLevelId();
  const plan = doc.all('plan').find((v) => v.levelId === levelId);
  const saved = doc.project.egressProfile || 'Ciii2';
  const prof = h('select.input', { 'aria-label': 'Rvita profile' }, Object.keys(RVITA).map((k) => h('option', { value: k, selected: k === saved }, `${k} - ${PROFILE_HINT[k.replace(/\d$/, '')] || ''}`)));
  const out = h('div', { style: 'max-height:55vh;overflow:auto' });
  const m = (v) => (Number.isFinite(v) ? `${withComma(v.toFixed(1), doc.units)} m` : 'no way out');
  let res = null;
  const run = () => {
    res = checkLevel(doc, app.scene, levelId, prof.value);
    const lim = res.limits;
    const bad = res.rooms.filter((r) => !r.ok);
    out.replaceChildren(
      h('p', `${prof.value}: longest way out ≤ ${lim.les} m, dead end ≤ ${lim.lcc} m, ${String(lim.unit).replace('.', ',')} mm per person. ${res.rooms.length} zones, ${res.exits.length} exits${res.lowest ? '' : ' (doors marked as exits or onto an external stair)'}: ${bad.length ? `${bad.length} not compliant` : 'all compliant'}.`),
      h('table.vg-table', [
        h('thead', h('tr', h('th', 'Zone'), h('th', 'Occupants'), h('th', 'Longest way out'), h('th', 'Dead end'), h('th', ''))),
        h('tbody', ...res.rooms.sort((a, b) => a.ok - b.ok || b.les - a.les).map((r) => h('tr', h('td', r.name), h('td', String(r.occupants)), h('td', m(r.les)), h('td', m(r.lcc)), h('td', { style: `color:${r.ok ? '#1f9d55' : '#d03030'}` }, r.ok ? 'OK' : 'Not compliant')))),
      ]),
      h('h4', 'Exits'),
      h('table.vg-table', [
        h('thead', h('tr', h('th', 'Exit'), h('th', 'Occupants'), h('th', 'Width'), h('th', 'Needed'), h('th', ''))),
        h('tbody', ...res.exits.map((e) => h('tr', h('td', e.name), h('td', String(e.occupants)), h('td', `${e.width} mm`), h('td', `${e.required} mm`), h('td', { style: `color:${e.ok ? '#1f9d55' : '#d03030'}` }, e.ok ? 'OK' : 'Too narrow')))),
      ]),
    );
  };
  prof.addEventListener('change', run);
  run();
  return openDialog({
    title: 'Escape Check (fire code S.4)',
    size: 'lg',
    body: h('div', h('label.field', h('span', 'Risk profile (Rvita)'), prof), out),
    actions: [
      {
        label: 'Draw Routes on Plan',
        onClick: () => {
          app.commit('Escape check', () => {
            doc.update('project', { egressProfile: prof.value });
            const n = applyEgress(doc, res, plan);
            app.toast(`${n} escape routes drawn on ${plan?.name || 'the plan'}; results kept on the zones.`, { kind: 'success' });
          });
          return false;
        },
      },
      { label: 'Close', primary: true, value: null },
    ],
  });
}
