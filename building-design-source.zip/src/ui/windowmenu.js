/**
 * Window menu: Go to Next/Previous Layout (Layout Book order), Hide Palettes
 * and Toolbars, Show Main Palettes Only, Show Windows Overview (thumbnails of
 * the open views), the Load Case palette and the Library Loading Report.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { adjacentLayout, libraryLoadingReport } from '../core/windowcmds.js';
import { loadCases, loadSummary } from '../core/structural.js';
import { renderViewImage } from '../views/snapshot.js';
import { applyPalettes } from './acextras.js';
import { VIEW_LABEL } from '../core/doc.js';

export function goToLayout(app, step) {
  const cur = app.activeView?.kind === 'sheet' ? app.activeView.id : null;
  const next = adjacentLayout(app.doc, cur, step);
  if (!next) return toast('There are no layouts yet.', { kind: 'error' });
  app.openView(next.id);
}

const PALETTE_KEYS = ['hideToolbox', 'hideInfoBox', 'hideStatusbar', 'hideCoordinates'];

/** Hide Palettes and Toolbars: everything around the drawing goes; the same command brings it back. */
export function hidePalettes(app) {
  const main = app.shell?.main;
  if (app.palettesSaved) {
    const s = app.palettesSaved;
    app.palettesSaved = null;
    for (const k of PALETTE_KEYS) app.settingsStore.set(k, s[k]);
    main?.classList.toggle('dock-hidden', !!s.dock);
  } else {
    app.palettesSaved = { ...Object.fromEntries(PALETTE_KEYS.map((k) => [k, !!app.settings[k]])), dock: !!main?.classList.contains('dock-hidden') };
    for (const k of PALETTE_KEYS) app.settingsStore.set(k, true);
    main?.classList.add('dock-hidden');
  }
  applyPalettes(app);
  app.viewport?.resize?.();
  app.requestRender();
}

/** Show Main Palettes Only: Toolbox, Info Box, Navigator and Properties back; the Coordinates palette away. */
export function showMainPalettes(app) {
  app.palettesSaved = null;
  for (const [k, v] of [['hideToolbox', false], ['hideInfoBox', false], ['hideStatusbar', false], ['hideCoordinates', true]]) app.settingsStore.set(k, v);
  const main = app.shell?.main;
  const dock = app.shell?.dock;
  main?.classList.remove('dock-hidden');
  dock?.classList.remove('props-hidden', 'browser-hidden');
  applyPalettes(app);
  app.viewport?.resize?.();
  app.requestRender();
}

/** Show Windows Overview: a thumbnail of every open view; click one to go there. */
export function windowsOverview(app) {
  const ids = (app.openViews || []).filter((id) => app.doc.has(id));
  if (!ids.length) return toast('No views are open.', { kind: 'error' });
  const grid = h('div.win-overview', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '12px' } });
  for (const id of ids) {
    const v = app.doc.get(id);
    let src = null;
    if (v.kind !== 'schedule')
      try {
        const st = app.viewStates?.get(id);
        src = renderViewImage(app, v, 440, 300, { fit: !st?.cam, camera: st?.cam || null }).canvas.toDataURL('image/png');
      } catch {
        src = null;
      }
    grid.append(
      h(
        'button.btn.win-thumb',
        { type: 'button', style: { display: 'flex', flexDirection: 'column', gap: '6px', padding: '6px', height: 'auto' }, 'aria-current': String(id === app.activeViewId), onClick: (e) => (e.currentTarget.closest('dialog')?._close(null), app.openView(id)) },
        src ? h('img', { src, alt: `Preview of ${v.name}`, style: { width: '100%', aspectRatio: '22 / 15', objectFit: 'contain', background: 'var(--surface-2, #f4f4f2)', borderRadius: '4px' } }) : h('div', { style: { width: '100%', aspectRatio: '22 / 15', display: 'grid', placeItems: 'center' } }, 'Schedule'),
        h('span', h('strong', v.name), ` · ${VIEW_LABEL[v.kind] || v.kind}`),
      ),
    );
  }
  return openDialog({ title: 'Windows Overview', size: 'lg', body: grid, actions: [{ label: 'Close', value: null }] });
}

/** Load Case palette: show or hide each case's loads, choose the case new loads go in, totals. */
export function loadCasePalette(app) {
  const body = h('div');
  const render = () => {
    const hidden = new Set(app.settings.hiddenLoadCases || []);
    const active = app.settings.activeLoadCase || 'live';
    const sum = loadSummary(app.doc);
    body.replaceChildren(
      h(
        'table.layers-table',
        h('thead', h('tr', h('th', 'Shown'), h('th', 'Active'), h('th', 'Load case'), h('th', 'Loads'), h('th', 'Total kN'))),
        h(
          'tbody',
          loadCases(app.doc.get('project')).map((c) => {
            const shown = h('input', { type: 'checkbox', checked: !hidden.has(c.value), 'aria-label': `Show ${c.label}` });
            shown.addEventListener('change', () => {
              const next = new Set(app.settings.hiddenLoadCases || []);
              if (shown.checked) next.delete(c.value);
              else next.add(c.value);
              app.settingsStore.set('hiddenLoadCases', [...next]);
              app.flagsVersion++;
              app.requestRender();
            });
            const act = h('input', { type: 'radio', name: 'active-case', checked: c.value === active, 'aria-label': `New loads in ${c.label}` });
            act.addEventListener('change', () => (app.settingsStore.set('activeLoadCase', c.value), render()));
            const n = app.doc.all('structuralLoad').filter((l) => (l.loadCase || 'dead') === c.value).length;
            return h('tr', h('td', shown), h('td', act), h('td', c.label), h('td.num', String(n)), h('td.num', (Math.round((sum[c.value] || 0) * 10) / 10).toLocaleString()));
          }),
        ),
      ),
      h('p.field-hint', 'Hidden cases do not show in any view. New point, line and surface loads go in the active case.'),
    );
  };
  render();
  return openDialog({ title: 'Load Cases', size: 'md', body, actions: [{ label: 'Close', value: null }] });
}

export function libraryLoadingReportDialog(app) {
  const libs = libraryLoadingReport(app.doc);
  if (!libs.length) return toast('No GDL library parts are loaded in this project.', { kind: 'info' });
  const body = h(
    'div',
    ...libs.map((l) =>
      h(
        'section',
        h('h3.dlg-sub', `${l.library}: ${l.parts} parts, ${l.ok} run, ${l.empty} draw nothing, ${l.failed} fail`),
        l.skipped.length ? h('p.field-hint', `Commands skipped: ${l.skipped.slice(0, 10).map(([c, n]) => `${c} (${n})`).join(', ')}`) : null,
        l.problems.length ? h('ul.find-list', l.problems.slice(0, 10).map((p) => h('li', p))) : null,
      ),
    ),
  );
  return openDialog({ title: 'Library Loading Report', size: 'lg', body, actions: [{ label: 'Close', value: null }] });
}
