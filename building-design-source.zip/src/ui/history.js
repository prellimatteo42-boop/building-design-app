/**
 * Undo History palette: the steps that can be undone, newest at the top,
 * and those that can be redone; clicking a step goes back (or forward) to
 * just after it.
 */
import { h, clear } from './dom.js';
import { icon } from './icons.js';

export class HistoryPalette {
  constructor(app) {
    this.app = app;
    this.el = null;
  }

  toggle() {
    if (this.el) return this.close();
    this.el = h('section.quick-layers.history-palette', { role: 'dialog', 'aria-label': 'Undo History' });
    document.body.append(this.el);
    this.render();
  }

  close() {
    this.el?.remove();
    this.el = null;
  }

  /** Undo (n < 0) or redo (n > 0) |n| steps. */
  step(n) {
    for (let i = 0; i < Math.abs(n); i++) n < 0 ? this.app.undo() : this.app.redo();
    this.render();
  }

  render() {
    const el = this.el;
    if (!el) return;
    clear(el);
    const doc = this.app.doc;
    el.append(h('div.ql-head', h('span.ql-title', icon('undo', 15), 'Undo History'), h('button.icon-btn.sm', { type: 'button', 'aria-label': 'Close Undo History', onClick: () => this.close() }, icon('x', 14))));
    if (!doc) return;
    const undo = doc.undoStack;
    const redo = doc.redoStack;
    const list = h('ol.ql-list.hist-list');
    // Redo steps, the next one nearest the current state.
    redo.forEach((s, i) => list.append(h('li', h('button.file-item.hist-item.hist-redo', { type: 'button', 'data-tip': 'Redo up to here', onClick: () => this.step(redo.length - i) }, icon('redo', 13), h('span.file-name', s.label)))));
    list.append(h('li.hist-now', h('span', 'Now')));
    for (let i = undo.length - 1; i >= 0; i--) list.append(h('li', h('button.file-item.hist-item', { type: 'button', 'data-tip': 'Undo back to before this', onClick: () => this.step(-(undo.length - i)) }, icon('undo', 13), h('span.file-name', undo[i].label))));
    el.append(list, h('p.field-hint', `${undo.length} step${undo.length === 1 ? '' : 's'} to undo${redo.length ? `, ${redo.length} to redo` : ''}.`));
  }
}
