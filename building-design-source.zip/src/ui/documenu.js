/**
 * Document menu commands: Area List, the component list and the components
 * listed on types, cameras placed in plan, Label Components, polylines from
 * and to lines, and the commands on a drawing placed on a layout.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { formatLength, scaleLabel } from '../core/units.js';
import { areaListRows, pieceFormula, layerComponents, listedComponents, toCSV } from '../core/doccmds.js';
import { camerasInOrder, orbitOfCamera, cameraFromOrbit } from '../core/cameras.js';
import { explodePolyline, chainToPolyline } from '../core/polyline.js';
import { addTag } from '../editor/draw.js';

const table = (head, rows) => h('table.vg-table', h('thead', h('tr', head.map((c) => h('th', c)))), h('tbody', rows.map((r) => h('tr', r.map((c) => h('td', String(c)))))));
const scroll = (el) => h('div', { style: { maxHeight: '55vh', overflow: 'auto' } }, el);
const saveCSV = (app, rows, name) => download(new Blob([toCSV(rows)], { type: 'text/csv' }), `${safeFileName(`${app.doc.project.name || 'Project'} - ${name}`)}.csv`);

/** Area List: every zone worked out from rectangles and triangles. */
export function areaListDialog(app) {
  const list = areaListRows(app.doc, app.scene.rooms);
  if (!list.length) return toast('There are no enclosed zones in the project.');
  const rows = [];
  for (const z of list) {
    z.pieces.forEach((p, i) => rows.push([i ? '' : z.number, i ? '' : z.name, i ? '' : z.level, pieceFormula(p)]));
    rows.push(['', '', 'Total', `${(z.area / 1e6).toFixed(2)} m²`]);
  }
  const total = list.reduce((t, z) => t + z.area, 0);
  rows.push(['', '', 'Project total', `${(total / 1e6).toFixed(2)} m²`]);
  const head = ['No.', 'Zone', 'Story', 'Calculation (m)'];
  return openDialog({ title: 'Area List', size: 'lg', body: scroll(table(head, rows)), actions: [{ label: 'Close', value: null }, { label: 'Export CSV', onClick: () => (saveCSV(app, [head, ...rows], 'Area List'), false) }] });
}

/** Component list: layers by material, then the components listed on types. */
export function componentListDialog(app) {
  const doc = app.doc;
  const layers = layerComponents(doc).map((r) => [r.material, r.fn, formatLength(r.thickness, doc.units), r.count, (r.area / 1e6).toFixed(2), (r.volume / 1e9).toFixed(3)]);
  const listed = listedComponents(doc).map((r) => [r.code, r.name, r.count, r.quantity.toFixed(2), r.unit]);
  const h1 = ['Material', 'Function', 'Thickness', 'Elements', 'Area (m²)', 'Volume (m³)'];
  const h2 = ['Code', 'Component', 'Elements', 'Quantity', 'Unit'];
  if (!layers.length && !listed.length) return toast('No element has layers or listed components.');
  const body = scroll(h('div', h('h3.dlg-sub', 'Layers'), layers.length ? table(h1, layers) : h('p.field-hint', 'No layered elements.'), h('h3.dlg-sub', 'Listed components'), listed.length ? table(h2, listed) : h('p.field-hint', 'None yet: add them to a type with Property Components.')));
  return openDialog({ title: 'Component List', size: 'lg', body, actions: [{ label: 'Close', value: null }, { label: 'Export CSV', onClick: () => (saveCSV(app, [h1, ...layers, [], h2, ...listed], 'Component List'), false) }] });
}

const PER = [
  ['piece', 'per piece'],
  ['length', 'per m'],
  ['area', 'per m²'],
  ['volume', 'per m³'],
];

/** The components listed on the type of the selected element. */
export function propertyComponentsDialog(app) {
  const doc = app.doc;
  const el = [...app.selection].map((id) => doc.get(id)).find((e) => e?.typeId);
  if (!el) return toast('Select an element that has a type.');
  const type = doc.get(el.typeId);
  let list = structuredClone(type.listing || []);
  const box = h('div');
  const input = (item, k, props = {}) => {
    const i = h('input.input.sm', { value: item[k] ?? '', 'aria-label': k, ...props });
    i.addEventListener('keydown', (e) => e.stopPropagation());
    i.addEventListener('change', () => (item[k] = props.type === 'number' ? +i.value : i.value));
    return i;
  };
  const render = () => {
    box.replaceChildren(
      ...list.map((item, n) => {
        const per = h('select.input.sm', { 'aria-label': 'Quantity is' }, PER.map(([v, l]) => h('option', { value: v }, l)));
        per.value = item.per || 'piece';
        per.addEventListener('change', () => (item.per = per.value));
        return h('div.inline', { style: { gap: '6px', marginBottom: '4px' } }, input(item, 'code', { placeholder: 'Code', style: { width: '80px' } }), input(item, 'name', { placeholder: 'Component' }), input(item, 'qty', { type: 'number', step: 'any', placeholder: 'Qty', style: { width: '70px' } }), input(item, 'unit', { placeholder: 'Unit', style: { width: '60px' } }), per, h('button.btn.sm', { type: 'button', onClick: () => (list.splice(n, 1), render()) }, 'Remove'));
      }),
      h('button.btn.sm', { type: 'button', onClick: () => (list.push({ code: '', name: '', qty: 1, unit: 'pcs', per: 'piece' }), render()) }, 'Add Component'),
    );
  };
  render();
  return openDialog({
    title: `Property Components: ${type.name}`,
    size: 'lg',
    body: box,
    actions: [
      { label: 'Cancel', value: null },
      { label: 'OK', primary: true, onClick: () => (app.commit('Property components', () => doc.update(type.id, { listing: list })), true) },
    ],
  });
}

/** Stand a 3D view at a camera. */
export function goToCamera(app, el) {
  const v3 = app.activeView?.kind === 'view3d' ? app.activeView : app.doc.all('view3d')[0];
  if (!v3) return toast('The project has no 3D view.', { kind: 'error' });
  app.openView(v3.id);
  app.vc.cam = orbitOfCamera(app.doc, el);
  app.vc.userMoved = true;
  app.requestRender();
}

/** Cameras: go to one, set one from the 3D view, reorder, make the fly-through path. */
export function camerasDialog(app) {
  const doc = app.doc;
  const box = h('div');
  const status = h('p.field-hint', { 'aria-live': 'polite' });
  const render = () => {
    const list = camerasInOrder(doc);
    if (!list.length) return box.replaceChildren(h('p.field-hint', 'No cameras yet: use the Camera tool in a floor plan (click where you stand, then what you look at).'));
    const swap = (i, j) => {
      app.commit('Reorder cameras', () => {
        const [a, c] = [list[i], list[j]];
        const [oa, oc] = [+a.order || i, +c.order || j];
        doc.update(a.id, { order: oc });
        doc.update(c.id, { order: oa });
      });
      render();
    };
    box.replaceChildren(
      ...list.map((c, i) =>
        h(
          'div.inline',
          { style: { gap: '6px', marginBottom: '4px', alignItems: 'center' } },
          h('span', { style: { flex: 1 } }, c.name),
          h('button.btn.sm', { type: 'button', onClick: () => goToCamera(app, c) }, 'Go To'),
          h('button.btn.sm', {
            type: 'button',
            onClick: () => {
              if (app.vc?.is2D) return (status.textContent = 'Open a 3D view first.');
              app.commit('Set camera from view', () => doc.update(c.id, cameraFromOrbit(doc, app.vc.cam, c.levelId)));
              status.textContent = `${c.name} now stands where the 3D view does.`;
            },
          }, 'Set From 3D'),
          h('button.btn.sm', { type: 'button', disabled: i === 0, 'aria-label': `Move ${c.name} up`, onClick: () => swap(i, i - 1) }, '↑'),
          h('button.btn.sm', { type: 'button', disabled: i === list.length - 1, 'aria-label': `Move ${c.name} down`, onClick: () => swap(i, i + 1) }, '↓'),
        ),
      ),
    );
  };
  render();
  const usePath = () => {
    const list = camerasInOrder(doc);
    const v3 = app.activeView?.kind === 'view3d' ? app.activeView : doc.all('view3d')[0];
    if (list.length < 2 || !v3) return (status.textContent = 'A path needs two cameras and a 3D view.'), false;
    app.commit('Cameras to fly-through', () => doc.update(v3.id, { flyCameras: list.map((c) => orbitOfCamera(doc, c)) }));
    status.textContent = `${list.length} cameras are now the fly-through path of ${v3.name}.`;
    return false;
  };
  return openDialog({ title: 'Cameras', body: h('div', box, status), actions: [{ label: 'Close', value: null }, { label: 'Use as Fly-through Path', onClick: usePath }] });
}

/** Label Components: a tag listing all the layers of each selected element. */
export function labelComponents(app) {
  const doc = app.doc;
  const view = app.activeView;
  const els = [...app.selection].map((id) => doc.get(id)).filter((e) => doc.get(e?.typeId)?.layers?.length);
  if (!els.length) return toast('Select walls, floors, roofs or ceilings with layers.');
  const s = +view.scale || 100;
  app.commit('Label components', () => els.forEach((e, i) => addTag(app, e, view, { show: 'layers', leader: true, at: labelPlace(app, e, s, i) })));
  toast(`${els.length} element${els.length === 1 ? '' : 's'} labelled with their layers.`);
}

function labelPlace(app, e, s, i) {
  const p = e.a && e.b ? [(e.a[0] + e.b[0]) / 2, (e.a[1] + e.b[1]) / 2] : e.boundary?.[0] || [0, 0];
  return [p[0] + 8 * s, p[1] + (8 + 2 * i) * s];
}

/** Selected polylines become separate lines and arcs. */
export function explodePolylines(app) {
  const doc = app.doc;
  const list = [...app.selection].map((id) => doc.get(id)).filter((e) => e?.kind === 'polyline');
  if (!list.length) return toast('Select a polyline.');
  const ids = [];
  app.commit('Explode polyline', () => {
    for (const p of list) {
      for (const it of explodePolyline(p)) ids.push(doc.add(it).id);
      doc.remove(p.id);
    }
  });
  app.select(ids);
}

/** Selected lines and arcs joined end to end become one polyline. */
export function joinToPolyline(app) {
  const doc = app.doc;
  const list = [...app.selection].map((id) => doc.get(id)).filter((e) => e?.kind === 'detailLine' || e?.kind === 'detailArc');
  if (list.length < 2) return toast('Select two or more lines or arcs that meet end to end.');
  const chain = chainToPolyline(list);
  if (!chain) return toast('These lines do not make one chain.', { kind: 'error' });
  let id;
  app.commit('Join to polyline', () => {
    id = doc.add({ kind: 'polyline', viewId: list[0].viewId, style: list[0].style, ...chain }).id;
    list.forEach((e) => doc.remove(e.id));
  });
  app.select([id]);
}

/** The drawing selected on a layout, with its source view. */
function pickedDrawing(app) {
  const doc = app.doc;
  const vp = [...app.selection].map((id) => doc.get(id)).find((e) => e?.kind === 'viewport');
  if (!vp) {
    toast('Select a drawing on a layout.');
    return null;
  }
  return { vp, view: doc.get(vp.placedId), sheet: doc.get(vp.viewId) };
}

/** Open source View: the view the selected drawing shows. */
export function openSourceView(app) {
  const d = pickedDrawing(app);
  if (d?.view) app.openView(d.view.id);
}

/** Modify source View Settings: name, scale and the view's own settings, from the layout. */
export function sourceViewSettings(app) {
  const d = pickedDrawing(app);
  if (!d?.view) return;
  const { view } = d;
  const name = h('input.input', { value: view.name || '', 'aria-label': 'Name' });
  const scale = h('input.input', { type: 'number', min: 1, value: +view.scale || 100, 'aria-label': 'Scale' });
  const detail = h('select.input', { 'aria-label': 'Detail level' }, ['coarse', 'medium', 'fine'].map((v) => h('option', { value: v }, v[0].toUpperCase() + v.slice(1))));
  detail.value = view.detail || 'medium';
  const cut = h('input.input', { type: 'number', value: +view.cutHeight || 1200, 'aria-label': 'Cut plane height' });
  const isPlan = view.kind === 'plan' || view.kind === 'ceilingPlan';
  for (const i of [name, scale, cut]) i.addEventListener('keydown', (e) => e.stopPropagation());
  return openDialog({
    title: `View Settings: ${view.name}`,
    body: h('div', h('label.field', h('span.field-label', 'Name'), name), view.kind !== 'view3d' ? h('label.field', h('span.field-label', `Scale 1:n (now ${scaleLabel(+view.scale || 100, app.doc.units)})`), scale) : null, view.kind !== 'view3d' ? h('label.field', h('span.field-label', 'Detail level'), detail) : null, isPlan ? h('label.field', h('span.field-label', 'Cut plane height (mm)'), cut) : null),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'OK',
        primary: true,
        onClick: () => {
          const patch = { name: name.value.trim() || view.name };
          if (view.kind !== 'view3d') Object.assign(patch, { scale: Math.max(1, +scale.value || 100), detail: detail.value });
          if (isPlan) patch.cutHeight = +cut.value || 1200;
          app.commit('View settings', () => app.doc.update(view.id, patch));
          return true;
        },
      },
    ],
  });
}

/** Set as Autotext Reference: the layout's {Scales}, {Drawing Name} and {Drawing Scale} read this drawing. */
export function setAutotextReference(app) {
  const d = pickedDrawing(app);
  if (!d?.sheet) return;
  const on = d.sheet.autotextRef === d.vp.id;
  app.commit('Autotext reference', () => app.doc.update(d.sheet.id, { autotextRef: on ? null : d.vp.id }));
  toast(on ? 'The layout reads all its drawings again.' : `The layout's autotext now reads ${d.view?.name}.`);
}
