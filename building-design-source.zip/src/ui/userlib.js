/** My Library: the objects kept between projects, to place, remove, or write out for Archicad. */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { download } from '../io/storage.js';
import { UserLibrary, typeFromEntry, archicadFiles } from '../core/userlib.js';
import { keepInLibrary } from '../assistant/interiortools.js';
import { writeContainer, ancestryOf } from '../io/gsm.js';

async function library(app) {
  app.userLibrary ||= new UserLibrary();
  await app.userLibrary.ready();
  return app.userLibrary;
}

/** Keeps the selected object in My Library. */
export async function addSelectionToLibrary(app) {
  const el = [...app.selection].map((id) => app.doc.get(id)).find((e) => e?.kind === 'component');
  const type = el && app.doc.get(el.typeId);
  if (!type?.gdl) return toast('Select an object made here, such as furniture to measure.', { kind: 'error' });
  if (type.gdl.lenient) return toast('That object already comes from a library.', { kind: 'error' });
  const e = await keepInLibrary(app, type, { name: type.name });
  toast(`${e.name} is now in My Library.`, { kind: 'success' });
}

/** What says that these are objects, taken from the user's own Archicad library. */
function objectAncestry(app) {
  const lib = app.acLibrary;
  if (!lib) return null;
  const sample = lib.get('Bed 01') || lib.get('Nightstand 01') || lib.objects().map((e) => lib.get(e.name)).find(Boolean);
  return sample?.bytes ? ancestryOf(sample.bytes) : null;
}

/** The whole library as a container Archicad can load (Library Manager, add a library). */
export async function exportForArchicad(app) {
  const lib = await library(app);
  const entries = lib.all();
  if (!entries.length) return toast('My Library is empty.', { kind: 'error' });
  const ancestry = objectAncestry(app);
  if (!ancestry) return toast('Load an Archicad library first (File > Libraries): it says what kind of part these are.', { kind: 'error' });
  const data = writeContainer(archicadFiles(entries, ancestry), 'My Library');
  download(new Blob([data], { type: 'application/octet-stream' }), 'My Library.lcf');
  toast(`${entries.length} objects written as an Archicad library.`, { kind: 'success' });
}

export async function myLibraryDialog(app) {
  const lib = await library(app);
  const grid = h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fill,minmax(132px,1fr));gap:10px;max-height:60vh;overflow:auto' });
  const fill = () => {
    grid.replaceChildren(...lib.all().map((e) => h('div', { style: 'border:1px solid var(--line,#ccc);border-radius:6px;padding:6px;display:flex;flex-direction:column;gap:4px' },
      e.thumb ? h('img', { src: e.thumb, alt: '', style: 'width:100%' }) : null,
      h('div', { style: 'font-size:12px' }, e.name),
      h('div', { style: 'display:flex;gap:4px' },
        h('button.btn.sm', { type: 'button', onClick: (ev) => place(e, ev) }, 'Place'),
        h('button.btn.sm', { type: 'button', onClick: async () => (await lib.remove(e.name), fill()) }, 'Remove')))));
    if (!lib.all().length) grid.append(h('div', 'Nothing yet. Objects the assistant makes come here, and so does what you add with the button below.'));
  };
  const place = (e, ev) => {
    let t = app.doc.all('componentType').find((x) => x.name === e.name && x.familyName === 'My Library');
    if (!t) app.commit('Add object from My Library', () => (t = app.doc.add(typeFromEntry(e))));
    const dlg = ev.target.closest('dialog');
    dlg?.close();
    dlg?.remove();
    app.placeType(t, 'component');
  };
  fill();
  return openDialog({
    title: 'My Library',
    size: 'lg',
    actions: [{ label: 'Close', value: null }],
    body: h('div', { style: 'display:flex;flex-direction:column;gap:10px;width:min(640px,86vw)' },
      h('div', 'Objects that the Archicad libraries do not have. They stay in this browser from one project to the next.'),
      grid,
      h('div', { style: 'display:flex;gap:6px' },
        h('button.btn', { type: 'button', onClick: async () => (await addSelectionToLibrary(app), fill()) }, 'Add Selected Object'),
        h('button.btn', { type: 'button', onClick: () => exportForArchicad(app) }, 'Export for Archicad...'))),
  });
}
