/**
 * Options menu: Import Standard Steel Profile, element intersections, Check
 * Project Integrity, Load Manager, Load Mapping, Find & Replace Library Parts
 * and their parameters, Publisher preferences, the Info Tag, and the display
 * preferences kept in the settings.
 */
import { gdlMessages } from '../core/gdl.js';
import { h } from './dom.js';
import { openDialog, confirmDialog, toast } from './dialog.js';
import { STEEL_SERIES, steelProfile } from '../core/steelprofiles.js';
import { checkIntegrity, repairIntegrity } from '../core/integrity.js';
import { typesInUse, typeParams, PLACED_KINDS, replaceParts, findByParam, setParam } from '../core/libreplace.js';
import { loadCases, LOAD_CASES } from '../core/structural.js';
import { LOAD_CATEGORIES, safCases } from '../core/structcombos.js';
import { setUndoLimit } from '../core/doc.js';
import { categoryOf, KIND_LABEL } from '../core/catalog.js';
import { newId } from '../core/doc.js';

const stop = (i) => (i.addEventListener('keydown', (e) => e.stopPropagation()), i);
const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const text = (value, label, attrs = {}) => stop(h('input.input.sm', { type: 'text', value: value ?? '', 'aria-label': label, ...attrs }));
const select = (list, cur, label) => {
  const s = h('select.input', { 'aria-label': label }, list.map((x) => h('option', { value: x.value }, x.label)));
  if (cur != null) s.value = cur;
  return s;
};

/** Apply the display preferences kept in the settings (at start and after Options). */
export function applyUiPrefs(app) {
  gdlMessages.on = !!app.settings.gdlMessages;
  const s = app.settings;
  const root = document.documentElement.style;
  root.setProperty('--bd-dialog-zoom', String(+s.dialogScale || 1));
  root.setProperty('--bd-palette-opacity', String(+s.paletteOpacity || 1));
  for (const [key, css] of [['selColor', '--sel'], ['hoverColor', '--hover'], ['guideColor', '--snap']]) {
    if (s[key]) root.setProperty(css, s[key]);
    else root.removeProperty(css);
  }
  setUndoLimit(+s.undoLimit || 300);
  app.viewport?.readTheme?.();
  app.flagsVersion++;
  app.requestRender?.();
}

/** Import Standard Steel Profile: the chosen sizes of a series become complex profiles. */
export function importSteelProfile(app) {
  const doc = app.doc;
  const series = select(STEEL_SERIES, 'IPE', 'Series');
  const use = select([{ value: 'beam', label: 'Beams' }, { value: 'column', label: 'Columns' }], 'beam', 'Use on');
  const list = h('div.snap-grid', { style: { maxHeight: '40vh', overflow: 'auto' } });
  const render = () => list.replaceChildren(...STEEL_SERIES.find((s) => s.value === series.value).rows.map((r) => h('label.check', h('input', { type: 'checkbox', value: r.size }), r.size)));
  series.addEventListener('change', render);
  render();
  const body = h('div', h('div.row2', field('Series', series), field('Use on', use)), list, h('p.field-hint', 'European sections in steel, as complex profiles you can then edit.'));
  return openDialog({ title: 'Import Standard Steel Profile', size: 'md', body, actions: [{ label: 'Cancel', value: null }, { label: 'Import', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const sizes = [...list.querySelectorAll('input:checked')].map((i) => i.value);
    if (!sizes.length) return toast('Tick the sizes to import.', { kind: 'error' });
    const material = doc.has('mat-steel') ? 'mat-steel' : doc.all('material')[0]?.id;
    let added = 0;
    app.commit('Import steel profiles', () => {
      for (const size of sizes) {
        const p = steelProfile(series.value, size, use.value, material);
        if (doc.all('profile').some((x) => x.name === p.name && x.use === p.use)) continue;
        doc.add(p);
        added++;
      }
    });
    toast(`${added} profile${added === 1 ? '' : 's'} imported${added < sizes.length ? `, ${sizes.length - added} already in the project` : ''}.`, { kind: 'success' });
  });
}

export function toggleProjectFlag(app, key, label) {
  const on = app.doc.get('project')?.[key] !== false;
  app.commit(label, () => app.doc.update('project', { [key]: !on }));
  app.requestRender();
}

/** Check Project Integrity: list what is broken and offer the repair. */
export function integrityDialog(app) {
  const problems = checkIntegrity(app.doc);
  if (!problems.length) return toast('The project is sound: every reference leads somewhere and every point is valid.', { kind: 'success' });
  const can = problems.filter((p) => p.repair);
  const body = h('div', h('p.dialog-text', `${problems.length} problem${problems.length === 1 ? '' : 's'} found.`), h('ul.find-list', problems.slice(0, 60).map((p) => h('li', `${KIND_LABEL[p.kind] || p.kind} ${p.id}: ${p.problem}${p.repair === 'remove' ? ' (the repair removes it)' : p.repair === 'clear' ? ' (the repair clears it)' : ' (no automatic repair)'}`))));
  return openDialog({ title: 'Project Integrity', size: 'md', body, actions: [{ label: 'Close', value: null }, ...(can.length ? [{ label: 'Repair', primary: true, value: 'ok' }] : [])] }).then((r) => {
    if (r !== 'ok') return;
    let n = 0;
    app.commit('Repair project', () => (n = repairIntegrity(app.doc, can)));
    toast(`${n} element${n === 1 ? '' : 's'} repaired.`, { kind: 'success' });
  });
}

/** Load Manager: the standard load cases and your own, with their kind and combination category. */
export function loadManager(app) {
  const doc = app.doc;
  const project = doc.get('project');
  let custom = structuredClone(project.customLoadCases || []);
  const labels = { ...(project.loadCaseLabels || {}) };
  const table = h('tbody');
  const inUse = (v) => doc.all('structuralLoad').some((l) => l.loadCase === v);
  const render = () => {
    table.replaceChildren(
      ...LOAD_CASES.map((c) => {
        const name = text(labels[c.value] ?? c.label, `Name of ${c.label}`);
        name.addEventListener('change', () => (labels[c.value] = name.value.trim() || c.label));
        return h('tr', h('td', name), h('td', c.value === 'dead' ? 'Permanent' : 'Variable'), h('td', '—'), h('td'));
      }),
      ...custom.map((c, i) => {
        const name = text(c.label, 'Name of the load case');
        name.addEventListener('change', () => (c.label = name.value.trim() || c.label));
        const action = select([{ value: 'variable', label: 'Variable' }, { value: 'permanent', label: 'Permanent' }], c.action, 'Action');
        action.addEventListener('change', () => (c.action = action.value));
        const cat = select(LOAD_CATEGORIES, c.category, 'Category');
        cat.addEventListener('change', () => (c.category = cat.value));
        return h('tr', h('td', name), h('td', action), h('td', cat), h('td', h('button.btn.sm', { type: 'button', disabled: inUse(c.value), 'data-tip': inUse(c.value) ? 'Loads use this case' : null, onClick: () => ((custom = custom.filter((_, j) => j !== i)), render()) }, 'Remove')));
      }),
    );
  };
  render();
  const add = h('button.btn.sm', { type: 'button', onClick: () => (custom.push({ value: newId('lc'), label: `Load case ${custom.length + 1}`, action: 'variable', category: LOAD_CATEGORIES[0].value }), render()) }, 'New Load Case');
  const body = h('div', h('table.layers-table', h('thead', h('tr', h('th', 'Load case'), h('th', 'Action'), h('th', 'Combination category'), h('th'))), table), h('div.row-actions', add), h('p.field-hint', 'Variable cases enter the combinations with the ψ values of their category. New loads go in the case made active in the Load Case palette.'));
  return openDialog({ title: 'Load Manager', size: 'lg', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r === 'ok') app.commit('Load manager', () => doc.update('project', { customLoadCases: custom, loadCaseLabels: labels }));
  });
}

/** Load Mapping: what each load case is called in the SAF file sent to the analysis program. */
export function loadMapping(app) {
  const doc = app.doc;
  const project = doc.get('project');
  const cases = safCases(project);
  const list = loadCases(project);
  const rows = list.map((c) => {
    const s = cases[c.value];
    return { c, name: text(s.name, `SAF name of ${c.label}`), desc: text(s.desc, `Description of ${c.label}`), group: text(s.group, `Load group of ${c.label}`), type: text(s.type, `Type of ${c.label}`) };
  });
  const body = h('div', h('table.layers-table', h('thead', h('tr', h('th', 'Load case'), h('th', 'Name in the file'), h('th', 'Description'), h('th', 'Load group'), h('th', 'Type'))), h('tbody', rows.map((r) => h('tr', h('td', r.c.label), h('td', r.name), h('td', r.desc), h('td', r.group), h('td', r.type))))), h('p.field-hint', 'Combinations follow these names. Self weight stays G1.'));
  return openDialog({ title: 'Load Mapping', size: 'lg', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const names = rows.map((x) => x.name.value.trim());
    if (new Set(names).size !== names.length || names.includes('G1') || names.some((n) => !n)) return toast('Each load case needs its own name, and G1 is self weight.', { kind: 'error' });
    app.commit('Load mapping', () => doc.update('project', { loadMapping: Object.fromEntries(rows.map((x) => [x.c.value, { name: x.name.value.trim(), desc: x.desc.value.trim(), group: x.group.value.trim(), type: x.type.value.trim() }])) }));
  });
}

const instancesOf = (app, typeId, selectionOnly) => {
  const ids = [];
  for (const k of PLACED_KINDS) for (const el of app.doc.all(k)) if (el.typeId === typeId && (!selectionOnly || app.selection.has(el.id))) ids.push(el.id);
  return ids;
};

/** Find & Replace Library Parts: instances of one type move to another of the same kind. */
export function replaceLibraryParts(app) {
  const doc = app.doc;
  const used = typesInUse(doc);
  if (!used.length) return toast('No objects, doors or windows are placed yet.', { kind: 'error' });
  const from = select(used.map((x) => ({ value: x.type.id, label: `${x.type.name} (${x.count})` })), used[0].type.id, 'Find');
  const to = h('select.input', { 'aria-label': 'Replace with' });
  const fill = () => {
    const k = doc.get(from.value).kind;
    to.replaceChildren(...doc.all(k).filter((t) => t.id !== from.value).map((t) => h('option', { value: t.id }, t.name)));
  };
  from.addEventListener('change', fill);
  fill();
  const onlySel = h('input', { type: 'checkbox', disabled: !app.selection.size });
  const transfer = h('input', { type: 'checkbox', checked: true });
  const body = h('div', field('Find', from), field('Replace with', to), h('label.check', onlySel, h('span', 'Only in the selection')), h('label.check', transfer, h('span', 'Keep the parameters both have')));
  return openDialog({ title: 'Find & Replace Library Parts', size: 'sm', body, actions: [{ label: 'Cancel', value: null }, { label: 'Replace', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok' || !to.value) return;
    let res;
    app.commit('Replace library parts', () => (res = replaceParts(doc, instancesOf(app, from.value, onlySel.checked), to.value, { transfer: transfer.checked })));
    toast(`${res.moved} replaced; ${res.kept} parameter values kept, ${res.dropped} not on the new part.`, { kind: 'success' });
  });
}

/** Find & Replace Parameters of placed library parts. */
export function replaceLibraryParams(app) {
  const doc = app.doc;
  const used = typesInUse(doc).filter((x) => typeParams(x.type).length);
  if (!used.length) return toast('No library parts with parameters are placed yet.', { kind: 'error' });
  const type = select(used.map((x) => ({ value: x.type.id, label: `${x.type.name} (${x.count})` })), used[0].type.id, 'Library part');
  const param = h('select.input', { 'aria-label': 'Parameter' });
  const fill = () => param.replaceChildren(...typeParams(doc.get(type.value)).map((p) => h('option', { value: p.name }, p.label || p.name)));
  type.addEventListener('change', fill);
  fill();
  const find = text('', 'Find value', { placeholder: 'Any value' });
  const replace = text('', 'Replace with');
  const status = h('p.field-hint', { 'aria-live': 'polite' });
  const found = () => findByParam(doc, type.value, param.value, find.value.trim());
  const body = h('div', field('Library part', type), field('Parameter', param), h('div.row2', field('Value to find', find), field('Replace with', replace)), h('div.row-actions', h('button.btn.sm', { type: 'button', onClick: () => { const ids = found(); app.select(ids); status.textContent = `${ids.length} instance${ids.length === 1 ? '' : 's'} found and selected.`; } }, 'Find and Select')), status);
  return openDialog({ title: 'Library Part Parameters', size: 'sm', body, actions: [{ label: 'Close', value: null }, { label: 'Replace All', primary: true, onClick: () => {
    if (replace.value === '') return (status.textContent = 'Type the new value.'), false;
    const ids = found();
    app.commit('Replace parameters', () => setParam(doc, ids, param.value, replace.value.trim()));
    status.textContent = `${ids.length} instance${ids.length === 1 ? '' : 's'} changed.`;
    return false;
  } }] });
}

export const PUBLISHER_DEFAULTS = { pages: 'merged', naming: 'set', prefix: '' };
export const publisherPrefs = (project) => ({ ...PUBLISHER_DEFAULTS, ...(project?.publisherPrefs || {}) });

/** Publisher preferences: one PDF or one per item, and how files are named. */
export function publisherDialog(app) {
  const doc = app.doc;
  const p = publisherPrefs(doc.get('project'));
  const pages = select([{ value: 'merged', label: 'One PDF with a page per item' }, { value: 'separate', label: 'One PDF per item' }], p.pages, 'Output');
  const naming = select([{ value: 'set', label: 'Name of the set or item' }, { value: 'date', label: 'Name and today’s date' }], p.naming, 'File names');
  const prefix = text(p.prefix, 'File name prefix');
  const body = h('div', field('Output', pages), field('File names', naming), field('Prefix', prefix));
  return openDialog({ title: 'Publisher', size: 'sm', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r === 'ok') app.commit('Publisher preferences', () => doc.update('project', { publisherPrefs: { pages: pages.value, naming: naming.value, prefix: prefix.value.trim() } }));
  });
}

// Info Tag ------------------------------------------------------------------------------------------

let tag = null;
let timer = null;

export function hideInfoTag() {
  clearTimeout(timer);
  timer = null;
  tag?.remove();
  tag = null;
}

/** The lines of an element's Info Tag. */
export function infoTagLines(doc, el) {
  const type = doc.get(el.typeId);
  const level = doc.get(el.levelId);
  const layer = doc.get(el.layerId);
  return [el.mark ? `${KIND_LABEL[el.kind] || el.kind} ${el.mark}` : KIND_LABEL[el.kind] || el.kind, type?.name, level ? `Story: ${level.name}` : null, layer ? `Layer: ${layer.name}` : null, el.kind === 'component' ? categoryOf(el, doc) : null].filter(Boolean);
}

/** Show the Info Tag of the element under the cursor after the delay; null hides it. */
export function updateInfoTag(app, id, x, y) {
  if (!app.settings.infoTag || !id) return hideInfoTag();
  if (tag?.dataset.id === id) return;
  hideInfoTag();
  timer = setTimeout(() => {
    const el = app.doc.get(id);
    if (!el) return;
    tag = h('div.info-tag', { role: 'status', dataset: { id }, style: { left: `${x + 14}px`, top: `${y + 14}px` } }, infoTagLines(app.doc, el).map((l, i) => h(i ? 'div' : 'strong', l)));
    app.shell.canvasWrap.append(tag);
  }, Math.max(0, +app.settings.infoTagDelay || 600));
}

export { confirmDialog };
