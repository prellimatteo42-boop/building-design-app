/**
 * Clean-up commands (core/merge.js): Merge Walls, Beams and Columns of the
 * selection (or all of them), and Linework Consolidation in the active view.
 */
import { mergeWalls as mergeWallsFn, mergeBeams as mergeBeamsFn, mergeColumns as mergeColumnsFn, consolidateLines as consolidateLinesFn } from '../core/merge.js';

export function mergeCommand(app, what) {
  const doc = app.doc;
  const sel = [...app.selection];
  const ids = sel.length ? sel : null;
  let n = 0;
  app.commit(`Merge ${what}`, () => (n = what === 'walls' ? mergeWallsFn(doc, ids) : what === 'beams' ? mergeBeamsFn(doc, ids) : mergeColumnsFn(doc, ids)));
  app.toast(n ? `Merged: ${n} ${what} fewer.` : `No ${what} to merge${ids ? ' in the selection' : ''} (they must be in line, touching, with the same settings).`);
}

export function consolidateCommand(app) {
  const view = app.activeView;
  if (!view) return;
  const sel = [...app.selection].filter((id) => app.doc.get(id)?.kind === 'detailLine');
  let r;
  app.commit('Linework consolidation', () => (r = consolidateLinesFn(app.doc, { viewId: view.id, ids: sel.length ? sel : null })));
  app.toast(r.removed || r.merged ? `Linework: ${r.removed} doubled or empty lines removed, ${r.merged} pieces joined.` : 'The lines are already clean.');
}
