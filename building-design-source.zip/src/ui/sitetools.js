/**
 * Site and roof commands: Create Roof Level Lines, Split into Single-plane
 * Roofs, Current Site Report, Gravitate, Wall End and Environment Settings.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { formatLength, parseLength } from '../core/units.js';
import { roofLevelLines, splitRoof, siteReport, gravitate, WALL_END_SHAPES } from '../core/sitetools.js';

const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const sel = (app, kinds) => [...app.selection].map((id) => app.doc.get(id)).filter((el) => el && kinds.includes(el.kind));

export function roofLevelLinesDialog(app) {
  const roofs = sel(app, ['roof']);
  const view = app.activeView;
  if (!roofs.length) return app.toast('Select the roofs to draw level lines for.', { kind: 'error' });
  if (!view?.levelId) return app.toast('Open a floor plan first.', { kind: 'error' });
  const u = app.doc.units;
  const iv = h('input.input', { type: 'text', value: formatLength(500, u), 'aria-label': 'Interval' });
  iv.addEventListener('keydown', (e) => e.stopPropagation());
  return openDialog({ title: 'Create Roof Level Lines', body: h('div', field('Height between lines', iv)), actions: [{ label: 'Cancel', value: null }, { label: 'Create', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const step = parseLength(iv.value, u);
    if (!(step > 0)) return app.toast('Give a positive interval.', { kind: 'error' });
    let n = 0;
    app.commit('Roof level lines', () => {
      for (const roof of roofs) for (const l of roofLevelLines(app.doc, roof, step)) (app.doc.add({ kind: 'detailLine', viewId: view.id, a: l.a, b: l.b, style: 'thin', roofLevel: l.z }), n++);
    });
    app.toast(`Drew ${plural(n, 'level line')}.`, { kind: 'success' });
  });
}

export function splitRoofs(app) {
  const roofs = sel(app, ['roof']);
  if (!roofs.length) return app.toast('Select the multi-plane roofs to split.', { kind: 'error' });
  const ids = [];
  app.commit('Split into single-plane roofs', () => {
    for (const roof of roofs) {
      const parts = splitRoof(app.doc, roof);
      if (parts.length < 2) continue;
      for (const p of parts) ids.push(app.doc.add(p).id);
      app.doc.remove(roof.id);
    }
  });
  if (!ids.length) return app.toast('Those roofs already have a single plane.', { kind: 'error' });
  app.select(ids);
  app.toast(`Split into ${plural(ids.length, 'single-plane roof')}.`, { kind: 'success' });
}

export function siteReportDialog(app) {
  const rep = siteReport(app.doc);
  if (!rep.length) return app.toast('There is no terrain (mesh) in the project.', { kind: 'error' });
  const n2 = (v) => v.toFixed(2);
  const u = app.doc.units;
  const row = (...cells) => h('tr', ...cells.map((c) => h('td', c)));
  const terrain = (t) => {
    const facts = h('table.vg-table', h('tbody', row('Plan area', `${n2(t.planArea)} m²`), row('Surface area', `${n2(t.surfaceArea)} m²`), row('Volume over its lowest point', `${n2(t.volume)} m³`), row('Lowest / highest point', `${formatLength(t.low, u)} / ${formatLength(t.high, u)}`)));
    if (!t.pads.length) return h('div', h('h3', t.name), facts, h('p.field-hint', 'No slab sits on this terrain.'));
    const cut = t.pads.reduce((a, p) => a + p.cut, 0);
    const fill = t.pads.reduce((a, p) => a + p.fill, 0);
    const pads = t.pads.map((p) => row(h('button.btn.sm', { type: 'button', onClick: () => app.select([p.id]) }, 'Slab'), n2(p.cut), n2(p.fill)));
    const table = h('table.vg-table', h('thead', h('tr', h('th', 'Building pad'), h('th', 'Cut m³'), h('th', 'Fill m³'))), h('tbody', ...pads, row(h('strong', 'Total'), h('strong', n2(cut)), h('strong', n2(fill)))));
    return h('div', h('h3', t.name), facts, table);
  };
  return openDialog({ title: 'Current Site Report', body: h('div', ...rep.map(terrain)), size: 'lg', actions: [{ label: 'Close', value: null }] });
}

export function gravitateSelection(app, kinds) {
  const ids = sel(app, ['component', 'column']).map((x) => x.id);
  if (!ids.length) return app.toast('Select the objects or columns to set on the surface.', { kind: 'error' });
  let n = 0;
  app.commit('Gravitate', () => (n = gravitate(app.doc, ids, (el) => app.scene.mesh(el), kinds)));
  app.toast(n ? `${plural(n, 'element')} now stand on the surface.` : 'No surface under the selection.', { kind: n ? 'success' : 'error' });
}

export function wallEndDialog(app) {
  const walls = sel(app, ['wall']).filter((w) => !app.doc.get(w.typeId)?.curtain);
  if (!walls.length) return app.toast('Select the walls to finish.', { kind: 'error' });
  const shape = h('select.input', { 'aria-label': 'Shape' }, ...WALL_END_SHAPES.map((s) => h('option', { value: s.value }, s.label)));
  const end = h('select.input', { 'aria-label': 'End' }, h('option', { value: 'b' }, 'At the end'), h('option', { value: 'a' }, 'At the start'), h('option', { value: 'both' }, 'At both ends'));
  return openDialog({ title: 'Wall End', body: h('div', h('div.row2', field('Shape', shape), field('Where', end))), actions: [{ label: 'Cancel', value: null }, { label: 'Add', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const ends = end.value === 'both' ? [0, 1] : end.value === 'a' ? [0] : [1];
    app.commit('Wall end', () => {
      for (const w of walls)
        for (const e of ends) {
          for (const old of app.doc.all('wallEnd')) if (old.wallId === w.id && old.end === e) app.doc.remove(old.id);
          app.doc.add({ kind: 'wallEnd', wallId: w.id, end: e, shape: shape.value });
        }
    });
  });
}

export function environmentDialog(app) {
  const e = app.doc.project?.energyEnvironment || {};
  const wind = h('select.input', { 'aria-label': 'Wind exposure' }, ...[['sheltered', 'Sheltered (dense city)'], ['normal', 'Normal (suburban)'], ['exposed', 'Exposed (open country, coast, hill)']].map(([v, l]) => h('option', { value: v, selected: v === (e.wind || 'normal') }, l)));
  const ground = h('select.input', { 'aria-label': 'Ground' }, ...[['clay', 'Clay or silt'], ['sand', 'Sand or gravel'], ['rock', 'Homogeneous rock']].map(([v, l]) => h('option', { value: v, selected: v === (e.ground || 'clay') }, l)));
  const horizon = h('input.input', { type: 'number', min: 0, max: 60, value: e.horizon || 0, 'aria-label': 'Horizon' });
  horizon.addEventListener('keydown', (ev) => ev.stopPropagation());
  const body = h('div', h('div.row2', field('Wind exposure', wind, 'Scales the ventilation losses'), field('Ground', ground)), field('Horizon shading (degrees above the horizon)', horizon, 'Hills and buildings around: less sun through the windows'));
  return openDialog({ title: 'Environment Settings', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    app.commit('Environment settings', () => app.doc.update('project', { energyEnvironment: { wind: wind.value, ground: ground.value, horizon: Math.max(0, Math.min(60, +horizon.value || 0)) } }));
  });
}
