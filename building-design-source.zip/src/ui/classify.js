/**
 * Classification Manager: classification systems, their items (code, name,
 * IFC entity) as a tree, how many elements each item has, and systems read
 * from CSV.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { icon } from './icons.js';
import { classTree, classOf, classifiable, parseClassCSV } from '../core/classify.js';
import { uniqueName } from '../core/ops.js';

const IFC_ENTITIES = ['IfcWall', 'IfcCurtainWall', 'IfcSlab', 'IfcRoof', 'IfcColumn', 'IfcBeam', 'IfcFooting', 'IfcStair', 'IfcRamp', 'IfcRailing', 'IfcDoor', 'IfcWindow', 'IfcOpeningElement', 'IfcCovering', 'IfcFurniture', 'IfcSanitaryTerminal', 'IfcElectricAppliance', 'IfcLightFixture', 'IfcGeographicElement', 'IfcDuctSegment', 'IfcPipeSegment', 'IfcCableCarrierSegment', 'IfcAirTerminal', 'IfcFireSuppressionTerminal', 'IfcUnitaryEquipment', 'IfcElectricDistributionBoard', 'IfcOutlet', 'IfcSpace', 'IfcBuildingElementProxy'];

export function classificationDialog(app) {
  const doc = app.doc;
  let sel = doc.all('classSystem')[0]?.id;
  const list = h('ul.file-list.mat-list');
  const detail = h('div.mat-detail.cm-detail');
  const counts = () => {
    const sys = doc.get(sel);
    const out = new Map();
    if (!sys) return out;
    for (const el of doc.items.values()) {
      if (!el.kind || !classifiable(doc, el)) continue;
      const item = classOf(doc, el, sys);
      if (item) out.set(item.code, (out.get(item.code) || 0) + 1);
    }
    return out;
  };
  const setItems = (items, label = 'Classification') => {
    app.commit(label, () => doc.update(sel, { items }));
    renderDetail();
  };
  const renderDetail = () => {
    clear(detail);
    const sys = doc.get(sel);
    if (!sys) return detail.append(h('p.props-empty', 'No classification system. Add one or import one from CSV.'));
    const name = h('input.input', { type: 'text', value: sys.name, 'aria-label': 'System name' });
    name.addEventListener('change', () => name.value.trim() && (app.commit('Classification', () => doc.update(sel, { name: name.value.trim() })), renderList()));
    const edition = h('input.input', { type: 'text', value: sys.edition || '', 'aria-label': 'Edition' });
    edition.addEventListener('change', () => app.commit('Classification', () => doc.update(sel, { edition: edition.value.trim() })));
    const n = counts();
    const rows = h('div.cm-rows', { role: 'list' });
    for (const { item, depth } of classTree(sys)) {
      const at = () => sys.items.indexOf(item);
      const upd = (patch) => setItems(doc.get(sel).items.map((x, j) => (j === at() ? { ...x, ...patch } : x)));
      const code = h('input.input.sm', { type: 'text', value: item.code, 'aria-label': `Code of ${item.name}` });
      code.addEventListener('change', () => {
        const v = code.value.trim();
        if (!v || sys.items.some((x) => x !== item && x.code === v)) return toast('Codes must be unique and not empty.', { kind: 'error' }), (code.value = item.code);
        // Children and elements follow the new code.
        app.commit('Classification', () => {
          doc.update(sel, { items: doc.get(sel).items.map((x) => (x === item ? { ...x, code: v } : x.parent === item.code ? { ...x, parent: v } : x)) });
          for (const el of doc.items.values()) if (el.classes?.[sel] === item.code) doc.update(el.id, { classes: { ...el.classes, [sel]: v } });
        });
        renderDetail();
      });
      const nm = h('input.input.sm', { type: 'text', value: item.name, 'aria-label': `Name of ${item.code}` });
      nm.addEventListener('change', () => upd({ name: nm.value.trim() || item.name }));
      const ifc = h('select.input.sm', { 'aria-label': `IFC entity of ${item.code}` }, [h('option', { value: '' }, '(none)'), ...IFC_ENTITIES.map((e) => h('option', { value: e }, e))]);
      ifc.value = item.ifc || '';
      ifc.addEventListener('change', () => upd({ ifc: ifc.value || null }));
      const child = h('button.icon-btn.sm', { type: 'button', 'aria-label': `Add an item under ${item.code}`, 'data-tip': 'Add an item under this one', onClick: () => {
        const codes = new Set(sys.items.map((x) => x.code));
        let k = 10;
        while (codes.has(`${item.code}.${k}`)) k += 10;
        setItems([...doc.get(sel).items, { code: `${item.code}.${k}`, name: 'New Item', parent: item.code, ifc: item.ifc, kinds: [], cats: [] }]);
      } }, icon('plus', 13));
      const del = h('button.icon-btn.sm', { type: 'button', 'aria-label': `Delete ${item.code}`, onClick: () => {
        const gone = new Set([item.code]);
        let grew = true;
        while (grew) {
          grew = false;
          for (const x of sys.items) if (x.parent && gone.has(x.parent) && !gone.has(x.code)) gone.add(x.code), (grew = true);
        }
        app.commit('Delete classification item', () => {
          doc.update(sel, { items: doc.get(sel).items.filter((x) => !gone.has(x.code)) });
          for (const el of doc.items.values()) if (gone.has(el.classes?.[sel])) {
            const { [sel]: _x, ...rest } = el.classes;
            doc.update(el.id, { classes: rest });
          }
        });
        renderDetail();
      } }, icon('trash', 13));
      rows.append(h('div.cm-row', { role: 'listitem', style: { paddingLeft: `${depth * 16}px` } }, code, nm, ifc, h('span.file-meta.cm-count', n.get(item.code) ? String(n.get(item.code)) : ''), child, del));
    }
    detail.append(
      h('div.row2', h('label.field', h('span.field-label', 'Name'), name), h('label.field', h('span.field-label', 'Edition'), edition)),
      h('div.cm-row.cm-head', h('span', 'Code'), h('span', 'Name'), h('span', 'IFC entity'), h('span', 'Elements'), h('span'), h('span')),
      rows,
      h('button.btn.sm', { type: 'button', onClick: () => setItems([...doc.get(sel).items, { code: uniqueName(sys.items.map((x) => x.code), '100'), name: 'New Item', parent: null, ifc: null, kinds: [], cats: [] }]) }, icon('plus', 14), 'Add Item'),
      h('p.field-hint', 'Elements take the item that fits their kind unless you choose one in Properties > Classification. Exported IFC uses the first system\'s IFC entity and lists every system\'s items.'),
    );
  };
  const renderList = () => {
    clear(list);
    for (const s of doc.all('classSystem'))
      list.append(h('li', h('button.file-item', { type: 'button', 'aria-pressed': String(s.id === sel), onClick: () => ((sel = s.id), renderList(), renderDetail()) }, icon('types', 14), h('span.file-name', s.name), h('span.file-meta', `${s.items.length}`))));
  };
  const addSystem = (name, items) => {
    let id;
    app.commit('New classification system', () => (id = doc.add({ kind: 'classSystem', name: uniqueName(doc.all('classSystem').map((x) => x.name), name), edition: '', items }).id));
    sel = id;
    renderList();
    renderDetail();
  };
  const importCSV = () => {
    const input = h('input', { type: 'file', accept: '.csv,.txt,text/csv,text/plain', hidden: true });
    input.addEventListener('change', async () => {
      const f = input.files?.[0];
      input.remove();
      if (!f) return;
      const items = parseClassCSV(await f.text());
      if (!items.length) return toast('No items found. Use one line per item: code, name, parent code, IFC entity.', { kind: 'error' });
      addSystem(f.name.replace(/\.[^.]+$/, ''), items);
      toast(`Imported ${items.length} items.`, { kind: 'success' });
    });
    document.body.append(input);
    input.click();
  };
  renderList();
  renderDetail();
  return openDialog({
    title: 'Classification Manager',
    size: 'lg',
    body: h(
      'div.mat-layout',
      h(
        'div.mat-side',
        list,
        h(
          'div.inline',
          { style: { marginTop: '8px', gap: '6px', flexWrap: 'wrap' } },
          h('button.btn.sm', { type: 'button', onClick: () => addSystem('Classification', []) }, icon('plus', 14), 'New'),
          h('button.btn.sm', { type: 'button', onClick: importCSV }, 'Import CSV...'),
          h('button.btn.sm', { type: 'button', disabled: !sel, onClick: () => {
            app.commit('Delete classification system', () => {
              for (const el of doc.items.values()) if (el.classes && sel in el.classes) {
                const { [sel]: _x, ...rest } = el.classes;
                doc.update(el.id, { classes: rest });
              }
              doc.remove(sel);
            });
            sel = doc.all('classSystem')[0]?.id;
            renderList();
            renderDetail();
          } }, icon('trash', 14), 'Delete'),
        ),
      ),
      detail,
    ),
    actions: [{ label: 'Close', primary: true, value: null }],
  });
}
