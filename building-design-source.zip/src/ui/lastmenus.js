/**
 * The last commands of the menus: Edit (selection set, consolidation, Unify),
 * Layout Book settings, renovation filters, 3D styles, page setup, Model View
 * Options, attributes, change details, MEP connections, GDL subtypes.
 */
import { h } from './dom.js';
import { openDialog, toast, confirmDialog } from './dialog.js';
import { KIND_LABEL } from '../core/catalog.js';
import { findHatches } from '../core/editmore.js';
import { consolidateLines } from '../core/merge.js';
import { bookSettings, renumberPatches } from '../core/bookset.js';
import { revisionsOnSheet } from '../core/revisions.js';
import { layoutsInOrder } from '../core/windowcmds.js';
import { phasesInOrder, phased, PHASE_LOOKS, filterRules, resetPhasePatch } from '../core/phases.js';
import { changeDetails } from '../core/compare.js';
import { resolveConnections } from '../core/mepnet.js';
import { addGdlType } from './gdleditor.js';
import { GDL_TEMPLATES } from '../core/gdltemplates.js';
import { newId, isView } from '../core/doc.js';
import { joinToPolyline } from './documenu.js';
import { writeContainer, writeLibraryPackage } from '../io/gsm.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { toCSV } from '../core/doccmds.js';

const closeOnly = [{ label: 'Close', value: null }];
const table = (head, rows) => h('div', { style: { maxHeight: '55vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', head.map((c) => h('th', c)))), h('tbody', rows)));
const stop = (el) => (el.addEventListener('keydown', (e) => e.stopPropagation()), el);
const input = (props) => stop(h('input.input', props));
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

// Edit ----------------------------------------------------------------------------------------

/** Edit Selection Set: which kind of the selected elements to edit. */
export function editSelectionSet(app) {
  const doc = app.doc;
  const by = new Map();
  for (const id of app.selection) {
    const k = doc.get(id)?.kind;
    if (k) by.set(k, [...(by.get(k) || []), id]);
  }
  if (by.size < 2) return toast('The selection has one kind of element: its properties are in the Properties panel.');
  const rows = [...by].map(([k, ids]) => h('tr', h('td', KIND_LABEL[k] || k), h('td', String(ids.length)), h('td', h('button.btn.sm', { type: 'button', onClick: () => (app.select(ids), document.querySelector('dialog[open]')?._close?.(null)) }, 'Edit These'))));
  return openDialog({ title: 'Edit Selection Set', body: table(['Kind', 'Elements', ''], rows), actions: closeOnly });
}

const viewLines = (app) => {
  const v = app.activeView;
  const sel = app.selection.size ? app.selection : null;
  return app.doc.all('detailLine').filter((l) => l.viewId === v?.id && (!sel || sel.has(l.id)));
};

/** Linework Consolidation: clean lines, and take out the lines of exploded hatches. */
export async function lineworkConsolidation(app) {
  const hatches = findHatches(viewLines(app));
  let dropHatches = false;
  if (hatches.length) dropHatches = await confirmDialog('Hatches found', `${plural(hatches.length, 'hatch')} made of separate lines (${hatches.reduce((t, x) => t + x.ids.length, 0)} lines). Remove these lines as well?`, { confirm: 'Remove them' });
  let res;
  app.commit('Linework consolidation', () => {
    if (dropHatches) hatches.forEach((x) => x.ids.forEach((id) => app.doc.remove(id)));
    res = consolidateLines(app.doc, { viewId: app.activeView.id, ids: app.selection.size ? [...app.selection].filter((id) => app.doc.has(id)) : null });
  });
  toast(`${res.removed + res.merged} lines cleaned${dropHatches ? `, ${plural(hatches.length, 'hatch')} removed` : ''}.`);
}

/** Fill Consolidation: exploded hatches become fills, then fills of one pattern that touch are joined. */
export function fillConsolidation(app) {
  const doc = app.doc;
  const v = app.activeView;
  const hatches = findHatches(viewLines(app));
  const ids = [];
  app.commit('Fill consolidation', () => {
    for (const x of hatches) {
      if (x.outline.length < 3) continue;
      x.ids.forEach((id) => doc.remove(id));
      ids.push(doc.add({ kind: 'region', viewId: v.id, boundary: x.outline, holes: [], pattern: 'diag', hatchAngle: x.angle, hatchSpacing: x.spacing }).id);
    }
  });
  const byPattern = new Map();
  for (const r of doc.all('region')) if (r.viewId === v.id) byPattern.set(r.pattern, [...(byPattern.get(r.pattern) || []), r.id]);
  let merged = 0;
  for (const list of byPattern.values()) {
    if (list.length < 2) continue;
    app.select(list);
    const before = doc.all('region').length;
    app.polygonOp('union');
    merged += before - doc.all('region').length;
  }
  app.select([]);
  toast(`${plural(ids.length, 'hatch')} turned into fills, ${merged} fills joined.`);
}

/** Unify: lines and arcs into one polyline; polygons into one. */
export function unify(app) {
  const doc = app.doc;
  const els = [...app.selection].map((id) => doc.get(id)).filter(Boolean);
  if (els.length < 2) return toast('Select two or more elements.');
  if (els.every((e) => e.kind === 'detailLine' || e.kind === 'detailArc')) return joinToPolyline(app);
  app.polygonOp('union');
}

// Layout Book ---------------------------------------------------------------------------------

export function bookSettingsDialog(app) {
  const doc = app.doc;
  const s = bookSettings(doc.project);
  const prefix = input({ value: s.prefix, 'aria-label': 'Prefix' });
  const start = input({ type: 'number', min: 0, value: s.start, 'aria-label': 'First number' });
  const digits = input({ type: 'number', min: 1, max: 6, value: s.digits, 'aria-label': 'Digits' });
  const subs = structuredClone(s.subsets);
  const subBox = h('div');
  const sheets = layoutsInOrder(doc);
  const choice = new Map(sheets.map((x) => [x.id, x.subset || '']));
  const render = () => {
    subBox.replaceChildren(
      ...subs.map((x, i) => {
        const n = input({ value: x.name, 'aria-label': 'Subset name' });
        n.addEventListener('change', () => (x.name = n.value.trim() || x.name));
        const p = input({ value: x.prefix || '', 'aria-label': 'Subset prefix', placeholder: 'Own prefix', style: { width: '90px' } });
        p.addEventListener('change', () => (x.prefix = p.value.trim()));
        return h('div.inline', { style: { gap: '6px', marginBottom: '4px' } }, n, p, h('button.btn.sm', { type: 'button', onClick: () => (subs.splice(i, 1), render()) }, 'Remove'));
      }),
      h('button.btn.sm', { type: 'button', onClick: () => (subs.push({ name: `Subset ${subs.length + 1}`, prefix: '' }), render()) }, 'Add Subset'),
      sheets.length
        ? table(['Layout', 'Subset'], sheets.map((x) => {
            const sel = h('select.input.sm', { 'aria-label': `Subset of ${x.name}` }, h('option', { value: '' }, 'None'), subs.map((y) => h('option', { value: y.name }, y.name)));
            sel.value = choice.get(x.id);
            sel.addEventListener('change', () => choice.set(x.id, sel.value));
            return h('tr', h('td', `${x.number || ''} ${x.name}`), h('td', sel));
          }))
        : '',
    );
  };
  render();
  const renumber = h('input', { type: 'checkbox' });
  return openDialog({
    title: 'Book Settings',
    size: 'lg',
    body: h('div', h('div.row3', h('label.field', h('span.field-label', 'Prefix'), prefix), h('label.field', h('span.field-label', 'First number'), start), h('label.field', h('span.field-label', 'Digits'), digits)), h('label.check', renumber, h('span', 'Renumber the layouts now')), h('h3.dlg-sub', 'Subsets'), subBox),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'OK',
        primary: true,
        onClick: () => {
          const next = { prefix: prefix.value, start: +start.value || 0, digits: Math.max(1, +digits.value || 1), subsets: subs };
          app.commit('Book settings', () => {
            doc.update('project', { bookSettings: next });
            for (const x of sheets) doc.update(x.id, { subset: choice.get(x.id) || null });
            if (renumber.checked) for (const p of renumberPatches(layoutsInOrder(doc), next)) doc.update(p.id, { number: p.number });
          });
          return true;
        },
      },
    ],
  });
}

export function layoutRevisionHistory(app) {
  const sh = app.activeView;
  if (sh?.kind !== 'sheet') return toast('Open a layout first.');
  const revs = revisionsOnSheet(app.doc, sh);
  return openDialog({ title: `Revision History: ${sh.number || ''} ${sh.name}`, body: revs.length ? table(['No.', 'Date', 'Description', 'By'], revs.map((r) => h('tr', h('td', String(r.number ?? r.seq ?? '')), h('td', r.date || ''), h('td', r.description || r.name || ''), h('td', r.by || r.issuedBy || '')))) : h('p.field-hint', 'No revisions on this layout yet.'), actions: closeOnly });
}

export function openAssignedMaster(app) {
  const sh = app.activeView;
  const m = sh?.kind === 'sheet' && sh.masterId ? app.doc.get(sh.masterId) : null;
  if (!m) return toast('Open a layout that has a master layout.');
  app.openView(m.id);
}

// Renovation ----------------------------------------------------------------------------------

export function renovationFilters(app) {
  const doc = app.doc;
  const list = structuredClone(doc.get('project').phaseFiltersCustom || []);
  const box = h('div');
  const render = () => {
    box.replaceChildren(
      list.length
        ? table(['Filter', 'Existing', 'Demolished', 'New', ''], list.map((f, i) => {
            const nm = input({ value: f.label, 'aria-label': 'Filter name' });
            nm.addEventListener('change', () => (f.label = nm.value.trim() || f.label));
            const look = (k) => {
              const s = h('select.input.sm', { 'aria-label': `${f.label} ${k}` }, PHASE_LOOKS.map((v) => h('option', { value: v }, v[0].toUpperCase() + v.slice(1))));
              s.value = f[k];
              s.addEventListener('change', () => (f[k] = s.value));
              return s;
            };
            return h('tr', h('td', nm), h('td', look('existing')), h('td', look('demolished')), h('td', look('new')), h('td', h('button.btn.sm', { type: 'button', onClick: () => (list.splice(i, 1), render()) }, 'Remove')));
          }))
        : h('p.field-hint', 'No filters of your own yet.'),
      h('button.btn.sm', { type: 'button', onClick: () => (list.push({ value: newId('pf'), label: `Filter ${list.length + 1}`, ...filterRules('all') }), render()) }, 'New Filter'),
    );
  };
  render();
  return openDialog({ title: 'Renovation Filter Options', size: 'lg', body: box, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, onClick: () => (app.commit('Renovation filters', () => doc.update('project', { phaseFiltersCustom: list })), true) }] });
}

export function resetRenovationStatus(app) {
  const doc = app.doc;
  const phases = phasesInOrder(doc);
  if (!phases.length) return toast('The project has no phases.');
  const s = h('select.input', { 'aria-label': 'Phase' }, phases.map((p) => h('option', { value: p.id }, p.name)));
  s.value = phases.at(-1).id;
  const onlySel = h('input', { type: 'checkbox', checked: app.selection.size > 0 });
  return openDialog({
    title: 'Reset Renovation Status',
    body: h('div', h('label.field', h('span.field-label', 'Put the elements in'), s), h('label.check', onlySel, h('span', 'Only the selection (otherwise the whole project)'))),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'Reset',
        primary: true,
        onClick: () => {
          const ids = onlySel.checked ? [...app.selection] : [...doc.items.values()].filter((e) => e.kind && phased(e)).map((e) => e.id);
          app.commit('Reset renovation status', () => ids.forEach((id) => phased(doc.get(id)) && doc.update(id, resetPhasePatch(s.value))));
          toast(`${plural(ids.length, 'element')} reset.`);
          return true;
        },
      },
    ],
  });
}

// 3D styles -----------------------------------------------------------------------------------

const STYLE_KEYS = ['style', 'shadows', 'renderEdges'];

export function styles3dDialog(app) {
  const doc = app.doc;
  const view = app.activeView;
  if (view?.kind !== 'view3d') return toast('Open a 3D view first.', { kind: 'error' });
  const box = h('div');
  const list = () => doc.get('project').styles3d || [];
  const save = (l) => app.commit('3D styles', () => doc.update('project', { styles3d: l }));
  const render = () => {
    box.replaceChildren(
      list().length
        ? table(['Style', 'Look', 'Shadows', 'Edges', ''], list().map((s, i) => h('tr', h('td', s.name), h('td', s.style), h('td', s.shadows ? 'Yes' : 'No'), h('td', s.renderEdges ? 'Yes' : 'No'), h('td', h('div.inline', { style: { gap: '4px' } }, h('button.btn.sm', { type: 'button', onClick: () => (app.commit('Apply 3D style', () => doc.update(view.id, Object.fromEntries(STYLE_KEYS.map((k) => [k, s[k]])))), app.requestRender()) }, 'Apply'), h('button.btn.sm', { type: 'button', onClick: () => (save(list().filter((_, k) => k !== i)), render()) }, 'Delete'))))))
        : h('p.field-hint', 'No styles of your own yet: save the look of this view as one.'),
    );
  };
  render();
  const name = input({ placeholder: 'Name of the style', 'aria-label': 'Style name' });
  const add = () => {
    const n = name.value.trim();
    if (!n) return false;
    const v = doc.get(view.id);
    save([...list().filter((s) => s.name !== n), { name: n, ...Object.fromEntries(STYLE_KEYS.map((k) => [k, v[k] ?? (k === 'style' ? 'shaded' : false)])) }]);
    name.value = '';
    render();
    return false;
  };
  return openDialog({ title: '3D Styles', size: 'lg', body: h('div', box, h('div.inline', { style: { gap: '6px', marginTop: '8px' } }, name, h('button.btn.sm', { type: 'button', onClick: add }, 'Save This View'))), actions: closeOnly });
}

// Page setup and Model View Options -----------------------------------------------------------

export function pageSetup(app) {
  const doc = app.doc;
  const cur = { size: 'auto', orientation: 'landscape', margin: 15, ...(doc.project.pageSetup || {}) };
  const sz = h('select.input', { 'aria-label': 'Paper size' }, ['auto', 'A4', 'A3', 'A2', 'A1', 'A0'].map((v) => h('option', { value: v }, v === 'auto' ? 'Fit the drawing' : v)));
  sz.value = cur.size;
  const or = h('select.input', { 'aria-label': 'Orientation' }, h('option', { value: 'landscape' }, 'Landscape'), h('option', { value: 'portrait' }, 'Portrait'));
  or.value = cur.orientation;
  const mg = input({ type: 'number', min: 0, value: cur.margin, 'aria-label': 'Margin' });
  return openDialog({
    title: 'Page Setup',
    body: h('div', h('label.field', h('span.field-label', 'Paper'), sz), h('label.field', h('span.field-label', 'Orientation'), or), h('label.field', h('span.field-label', 'Margin (mm)'), mg), h('p.field-hint', 'For printing views. Layouts print at their own size.')),
    actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, onClick: () => (app.commit('Page setup', () => doc.update('project', { pageSetup: { size: sz.value, orientation: or.value, margin: +mg.value || 0 } })), true) }],
  });
}

export function modelViewOptions(app) {
  const doc = app.doc;
  const view = app.activeView;
  if (!view || !isView(view)) return toast('Open a view first.');
  const mvo = { doorSwing: true, doorHead: true, windowSill: true, stairWalkLine: true, zoneStamps: true, ...(view.mvo || {}) };
  const opts = [['doorSwing', 'Door leaves and swings'], ['doorHead', 'Door heads above the cut'], ['windowSill', 'Window sills'], ['stairWalkLine', 'Stair walking lines and UP/DN'], ['zoneStamps', 'Zone stamps']];
  const checks = opts.map(([k, l]) => {
    const c = h('input', { type: 'checkbox', checked: mvo[k] });
    c.addEventListener('change', () => (mvo[k] = c.checked));
    return h('label.check', c, h('span', l));
  });
  // Doors and windows in 3D, at the detail Archicad's Model View Options offer.
  const level = h('select.input', { 'aria-label': 'Doors and windows in 3D' }, [['detailed', 'Full'], ['simplified', 'Simplified'], ['schematic', 'Schematic']].map(([v, l]) => h('option', { value: v, selected: (mvo.opening3D || 'detailed') === v }, l)));
  level.addEventListener('change', () => (mvo.opening3D = level.value));
  checks.push(h('label.field', h('span.field-label', 'Doors and windows in 3D'), level));
  return openDialog({ title: `Model View Options: ${view.name}`, body: h('div', ...checks), actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, onClick: () => (app.commit('Model view options', () => doc.update(view.id, { mvo })), true) }] });
}

// Bars ----------------------------------------------------------------------------------------

export function detailedChanges(app) {
  const p = app.comparePalette;
  if (!p.base || !p.diff) return toast('Run Model Compare first.');
  const rows = changeDetails(p.diff, p.base, app.doc);
  const csv = () => (download(new Blob([toCSV([['Group', 'Element', 'Parameter', 'From', 'To'], ...rows.map((r) => [r.group, r.label, r.field, r.from, r.to])])], { type: 'text/csv' }), 'Changes.csv'), false);
  return openDialog({ title: 'Detailed Changes', size: 'lg', body: rows.length ? table(['Element', 'Parameter', 'From', 'To'], rows.slice(0, 2000).map((r) => h('tr', h('td', r.label), h('td', r.field), h('td', r.from), h('td', r.to)))) : h('p.field-hint', 'Nothing has changed.'), actions: [{ label: 'Close', value: null }, { label: 'Export CSV', onClick: csv }] });
}

export function resolveMepConnections(app) {
  const doc = app.doc;
  const fix = resolveConnections(doc);
  if (!fix.length) return toast('No open ends close enough to connect.');
  app.commit('Resolve MEP connections', () => fix.forEach((x) => doc.update(x.id, x.patch)));
  toast(`${plural(fix.length, 'run')} reconnected.`);
}

const SUBTYPES = [
  { label: 'Furniture', category: 'furniture', template: 0 },
  { label: 'Casework', category: 'casework', template: 1 },
  { label: 'Lighting', category: 'lighting', template: 2 },
  { label: 'Plumbing Fixture', category: 'plumbing', template: 0 },
  { label: 'Equipment', category: 'equipment', template: 0 },
  { label: 'Generic Model', category: 'genericModels', template: 0 },
];

export function openObjectBySubtype(app) {
  const doc = app.doc;
  const s = h('select.input', { 'aria-label': 'Subtype' }, SUBTYPES.map((x, i) => h('option', { value: String(i) }, x.label)));
  return openDialog({
    title: 'New Object by Subtype',
    body: h('label.field', h('span.field-label', 'Subtype'), s),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'Create',
        primary: true,
        onClick: () => {
          const st = SUBTYPES[+s.value];
          const tpl = GDL_TEMPLATES[st.template] || GDL_TEMPLATES[0];
          let t;
          app.commit('New GDL object', () => (t = addGdlType(doc, { ...tpl, name: `${st.label} Object`, category: st.category })));
          setTimeout(() => app.gdlObjectsDialog({ select: t.id }), 0);
          return true;
        },
      },
    ],
  });
}

// Containers ----------------------------------------------------------------------------------

function pickFolder() {
  return new Promise((resolve) => {
    const i = h('input', { type: 'file', webkitdirectory: true, multiple: true, hidden: true });
    i.addEventListener('change', () => (resolve([...(i.files || [])]), i.remove()));
    document.body.append(i);
    i.click();
  });
}

async function folderFiles(list) {
  return Promise.all(list.map(async (f) => ({ path: (f.webkitRelativePath || f.name).split('/').slice(1).join('/') || f.name, data: new Uint8Array(await f.arrayBuffer()) })));
}

/** Create Container: a folder of library parts in one .lcf. */
export async function createContainer(app) {
  const list = await pickFolder();
  if (!list.length) return;
  const root = list[0].webkitRelativePath.split('/')[0] || 'Library';
  download(new Blob([writeContainer(await folderFiles(list), root)], { type: 'application/octet-stream' }), `${safeFileName(root)}.lcf`);
  toast(`${plural(list.length, 'file')} in ${root}.lcf.`, { kind: 'success' });
}

/** Create Library Package: a folder of library parts in one .libpack. */
export async function createLibraryPackage(app) {
  const list = await pickFolder();
  if (!list.length) return;
  const root = list[0].webkitRelativePath.split('/')[0] || 'Library';
  const id = crypto.randomUUID().toUpperCase();
  download(new Blob([writeLibraryPackage(await folderFiles(list), { name: root, id })], { type: 'application/octet-stream' }), `${safeFileName(root)}.libpack`);
  toast(`${plural(list.length, 'file')} in ${root}.libpack.`, { kind: 'success' });
}
