/**
 * Structural Analytical Model Generation Rules: how the analytical model is
 * made from the physical one (core/analytical.js), kept in the project.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { ANALYTICAL_RULES, analyticalModel } from '../core/analytical.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);

export function analyticalRulesDialog(app) {
  const doc = app.doc;
  const r = { ...ANALYTICAL_RULES, ...doc.get('project')?.analyticalRules };
  const tol = h('input.input', { type: 'number', min: 1, max: 500, step: 1, value: r.tol });
  tol.addEventListener('keydown', (e) => e.stopPropagation());
  const bearing = h('select.input', {}, [
    h('option', { value: 'auto' }, 'Marked Structural (all when none is marked)'),
    h('option', { value: 'marked' }, 'Only those marked Structural'),
    h('option', { value: 'all' }, 'All walls and slabs'),
  ]);
  bearing.value = r.bearing;
  const check = (on, label) => {
    const cb = h('input', { type: 'checkbox', checked: !!on });
    return [cb, h('label.check', cb, label)];
  };
  const [meet, meetRow] = check(r.meetSlabs, 'Walls and columns end on the mid-plane of the slab they reach');
  const [cols, colsRow] = check(r.beamsToColumns, 'Beam ends near a column land on the column axis');
  const summary = h('p.field-hint');
  const show = () => {
    const am = analyticalModel(doc, { tol: +tol.value || 20, bearing: bearing.value, meetSlabs: meet.checked, beamsToColumns: cols.checked });
    summary.textContent = `With these rules: ${am.members.length} members, ${am.surfaces.length} surfaces, ${am.nodes.length} nodes, ${am.supports.length + am.edgeSupports.length} supports, ${am.loads.length} loads.`;
  };
  for (const c of [tol, bearing, meet, cols]) c.addEventListener('change', show);
  show();
  const body = h('div', field('Load-bearing walls and slabs', bearing), field('Node tolerance (mm)', tol, 'Member ends closer than this share one node.'), meetRow, colsRow, summary);
  return openDialog({ title: 'Analytical Model Generation Rules', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((v) => {
    if (v !== 'ok') return;
    app.commit('Analytical model rules', () => doc.update('project', { analyticalRules: { tol: Math.max(1, +tol.value || 20), bearing: bearing.value, meetSlabs: meet.checked, beamsToColumns: cols.checked } }));
    app.requestRender?.();
  });
}
