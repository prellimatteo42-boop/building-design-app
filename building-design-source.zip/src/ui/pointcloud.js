/**
 * Import Point Clouds: XYZ / PTS / TXT / CSV and LAS files shown in the 3D
 * view as a reference, and a small manager to hide or remove them.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { readTextCloud, readLAS, cloudElement } from '../core/pointcloud.js';

export function importPointCloud(app) {
  const input = h('input', { type: 'file', accept: '.xyz,.pts,.txt,.csv,.las' });
  input.addEventListener('change', async () => {
    const f = input.files?.[0];
    if (!f) return;
    const unit = h('select.input', { 'aria-label': 'Units' }, ...[['1000', 'Metres'], ['10', 'Centimetres'], ['1', 'Millimetres'], ['304.8', 'Feet']].map(([v, l]) => h('option', { value: v }, l)));
    const move = h('input', { type: 'checkbox', checked: true });
    const r = await openDialog({ title: `Import ${f.name}`, body: h('div', h('label.field', h('span.field-label', 'Coordinates in'), unit), h('label.check', move, 'Bring its lowest corner to the project origin (survey coordinates are far away)')), actions: [{ label: 'Cancel', value: null }, { label: 'Import', primary: true, value: 'ok' }] });
    if (r !== 'ok') return;
    app.setPrompt(`Reading ${f.name}...`);
    let cloud;
    try {
      cloud = /\.las$/i.test(f.name) ? readLAS(await f.arrayBuffer(), { scale: +unit.value }) : readTextCloud(await f.text(), { scale: +unit.value });
    } catch (e) {
      return app.toast(`Could not read ${f.name}: ${e.message}`, { kind: 'error' });
    }
    if (!cloud.count) return app.toast('No points found in that file.', { kind: 'error' });
    const lv = app.activeLevelId();
    const el = cloudElement(f.name, cloud, lv, { relativeTo: move.checked ? cloud.origin : null });
    app.commit('Import point cloud', () => app.doc.add(el));
    app.toast(`${f.name}: ${cloud.count.toLocaleString()} points. They show in 3D views.`, { kind: 'success' });
    app.setPrompt('');
  });
  input.click();
}

export function managePointClouds(app) {
  const list = app.doc.all('pointCloud');
  if (!list.length) return app.toast('No point clouds in the project.', { kind: 'error' });
  const body = h('table.vg-table', h('tbody', ...list.map((c) => h('tr', h('td', c.name), h('td', `${(c.count || 0).toLocaleString()} points`), h('td', h('button.btn.sm', { type: 'button', onClick: (e) => (app.commit('Remove point cloud', () => app.doc.remove(c.id)), e.currentTarget.closest('tr').remove()) }, 'Remove'))))));
  return openDialog({ title: 'Point Clouds', body, actions: [{ label: 'Close', value: null }] });
}
