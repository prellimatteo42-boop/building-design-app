/**
 * Library Developer commands: Import / Redefine All Surfaces from Catalog,
 * Save All Surfaces as GSM (surface scripts, one per material, in a ZIP),
 * Run Parameter Script on Placed Library Parts, and the GDL debugger.
 */
import { writeLibraryPart, ancestryOf } from '../io/gsm.js';
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { download } from '../io/storage.js';
import { makeZip } from '../io/zip.js';
import { ArchicadLibrary } from '../core/aclib.js';
import { catalogSurfaces, importSurfaces, surfaceScript } from '../core/surfaces.js';
import { runParamScripts } from '../core/paramscript.js';
import { debugRun, debugSteps, nextBreak, SCRIPTS } from '../core/gdldebug.js';

const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

function pickLibrary() {
  return new Promise((resolve) => {
    const input = h('input', { type: 'file', accept: '.libpack,.lcf,.gsm', multiple: true, hidden: true });
    input.addEventListener('change', () => (resolve([...(input.files || [])]), input.remove()));
    document.body.append(input);
    input.click();
  });
}

/** The loaded Archicad library with a surface catalog in it, asking for Surface Catalog.libpack when there is none. */
async function catalogLibrary(app) {
  const lib = (app.acLibrary ||= new ArchicadLibrary());
  if ([...lib.parts.values()].some((e) => /surface catalog/i.test(e.path))) return lib;
  toast('Choose the Surface Catalog library (Surface Catalog.libpack in Archicad’s library packages).');
  for (const f of await pickLibrary()) lib.add(f.name, new Uint8Array(await f.arrayBuffer()));
  return lib.parts.size ? lib : null;
}

export async function importCatalogSurfaces(app, { redefine = false } = {}) {
  const lib = await catalogLibrary(app);
  if (!lib) return;
  const surfaces = catalogSurfaces(lib);
  if (!surfaces.length) return toast('No surfaces found: the catalog parts define none.', { kind: 'error' });
  let res;
  app.commit(redefine ? 'Redefine surfaces from catalog' : 'Import surfaces from catalog', () => (res = importSurfaces(app.doc, surfaces, { redefine })));
  toast(redefine ? `${plural(res.redefined, 'material')} redefined from the catalog.` : `${plural(res.added, 'surface')} added as materials (${surfaces.length - res.added} already in the project).`, { kind: 'success' });
}

export async function saveSurfacesGsm(app) {
  const mats = app.doc.all('material');
  if (!mats.length) return toast('The project has no materials.', { kind: 'error' });
  // What makes a part a surface for Archicad comes from a surface of the user's own catalog.
  const lib = await catalogLibrary(app);
  if (!lib) return;
  const sample = [...lib.parts.values()].find((e) => /surface catalog/i.test(e.path) && !/\/fills\//i.test(e.path) && lib.get(e.name)?.lp?.preview);
  const ancestry = sample ? ancestryOf(sample.bytes) : null;
  const used = new Set();
  const files = mats.map((m) => {
    let base = String(m.name || m.id).replace(/[\\/:*?"<>|]+/g, '_');
    while (used.has(base.toLowerCase())) base += '_';
    used.add(base.toLowerCase());
    return { name: `${base}.gsm`, data: writeLibraryPart({ name: base, master: surfaceScript(m), ancestry }) };
  });
  download(new Blob([makeZip(files)], { type: 'application/zip' }), 'Surfaces.zip');
  toast(`${plural(files.length, 'surface')} saved as library parts (.gsm).`, { kind: 'success' });
}

export function runParameterScripts(app) {
  const ids = app.selection.size ? [...app.selection] : null;
  let n = 0;
  app.commit('Run parameter script', () => (n = runParamScripts(app.doc, ids)));
  toast(n ? `${plural(n, 'placed part')} updated by ${n === 1 ? 'its' : 'their'} parameter script.` : 'No placed part changed: their parameter scripts leave the values as they are.', { kind: n ? 'success' : 'info' });
}

/** The GDL debugger: pick a GDL type (the selected object's first), a script and a breakpoint, run, read the trace. */
/** Step through a finished run: the script with the current line, back and forward, breakpoints on the line numbers. */
function stepper(type, mode, run) {
  const steps = debugSteps(run.events);
  if (!steps.length) return '';
  const g = type.gdl || {};
  const text = { master: (g.master || '').split('\n'), main: (g[SCRIPTS[mode]] || '').split('\n') };
  let i = 0;
  const breaks = new Set();
  const code = h('div', { style: 'max-height:22vh;overflow:auto;border:1px solid var(--border,#ddd);white-space:pre' });
  const state = h('div', { style: 'margin:6px 0' });
  const vars = h('div', { style: 'max-height:16vh;overflow:auto' });
  const render = () => {
    const s = steps[i];
    const which = s.at?.script || 'main';
    state.textContent = `Step ${i + 1} of ${steps.length}: ${s.name} ${JSON.stringify(s.args).slice(1, -1).slice(0, 200)}`;
    let cur = null;
    code.replaceChildren(
      ...text[which].map((t, n) => {
        const key = `${which}:${n + 1}`;
        const on = s.at?.line === n + 1;
        const mark = h('button', { type: 'button', 'aria-label': `Breakpoint at line ${n + 1}`, 'aria-pressed': String(breaks.has(key)), style: `border:0;background:none;cursor:pointer;width:4.5em;text-align:right;color:${breaks.has(key) ? 'var(--danger,#c33)' : 'var(--muted,#888)'}`, onClick: () => (breaks.has(key) ? breaks.delete(key) : breaks.add(key), render()) }, `${breaks.has(key) ? '● ' : ''}${n + 1}`);
        const row = h('div', { style: on ? 'background:var(--accent-soft,#ffe9a8)' : '' }, mark, ` ${t}`);
        if (on) cur = row;
        return row;
      }),
    );
    if (cur) cur.scrollIntoView({ block: 'nearest' });
    vars.replaceChildren(h('table', {}, Object.entries(s.vars).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => h('tr', { style: s.changed.includes(k) ? 'font-weight:600' : '' }, h('td', { style: 'padding-right:1em' }, k), h('td', {}, JSON.stringify(v))))));
  };
  const go = (n) => ((i = Math.max(0, Math.min(steps.length - 1, n))), render());
  const btn = (label, f) => h('button.btn.sm', { type: 'button', onClick: f }, label);
  const cont = () => {
    const n = nextBreak(steps, breaks, i + 1);
    go(n >= 0 ? n : steps.length - 1);
  };
  const box = h('details', { open: true }, h('summary', {}, 'Step through'), h('div', { style: 'display:flex;gap:6px;margin:6px 0' }, btn('First', () => go(0)), btn('Step Back', () => go(i - 1)), btn('Step', () => go(i + 1)), btn('Continue', cont)), state, code, vars);
  render();
  return box;
}

export function gdlDebugger(app) {
  const types = app.doc.all('componentType', 'doorType', 'windowType').filter((t) => t.gdl);
  if (!types.length) return toast('No GDL objects in the project: place one from a library or the GDL editor first.', { kind: 'error' });
  const selected = [...app.selection].map((id) => app.doc.get(id)).find((el) => el && types.some((t) => t.id === el.typeId));
  const typeSel = h('select.input', { style: 'width:auto' }, types.map((t) => h('option', { value: t.id, selected: selected?.typeId === t.id }, t.name || t.id)));
  const modeSel = h('select.input', { style: 'width:auto' }, [['3d', '3D script'], ['2d', '2D script'], ['params', 'Parameter script']].map(([v, l]) => h('option', { value: v }, l)));
  const scriptSel = h('select.input', { style: 'width:auto' }, [['main', 'that script'], ['master', 'master script']].map(([v, l]) => h('option', { value: v }, l)));
  const lineIn = h('input.input', { type: 'number', min: 1, placeholder: 'none', style: 'width:6em' });
  const out = h('div', { style: 'max-height:50vh;overflow:auto;font:12px/1.4 ui-monospace,monospace' });
  const run = () => {
    const type = app.doc.get(typeSel.value);
    const own = selected?.typeId === type.id ? selected.gdlValues || {} : {};
    const line = +lineIn.value;
    const r = debugRun(type, own, { mode: modeSel.value, breakAt: line > 0 ? { script: scriptSel.value, line } : null, stepVars: true });
    const at = (w) => (w ? `${w.script === 'master' ? 'master' : modeSel.value} ${w.line}` : '');
    const status = r.error ? `Error at ${at(r.error.at)}: ${r.error.message}` : r.stoppedAt ? `Stopped at ${at(r.stoppedAt)}` : 'Ran to the end';
    const unknown = Object.keys(r.unknown);
    out.replaceChildren(
      h('p', { style: `font-weight:600;color:${r.error ? 'var(--danger, #c33)' : 'inherit'}` }, `${status}. ${plural(r.events.filter((e) => e.kind === 'cmd').length, 'command')}${r.truncated ? ' (trace cut)' : ''}.`),
      unknown.length ? h('p', {}, `Not supported here: ${unknown.join(', ')}`) : '',
      stepper(type, modeSel.value, r),
      h('details', { open: true }, [h('summary', {}, 'Variables'), h('table', {}, Object.entries(r.vars).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => h('tr', {}, [h('td', { style: 'padding-right:1em' }, k), h('td', {}, JSON.stringify(v))])))]),
      h('details', { open: true }, [
        h('summary', {}, 'Trace'),
        h('div', {}, r.events.map((e) => h('div', { style: `padding-left:${e.depth * 1.2}em` }, e.kind === 'cmd' ? `${at(e.at).padEnd(10)} ${e.name} ${JSON.stringify(e.args).slice(1, -1).slice(0, 160)}` : `${e.kind === 'call' ? '→ CALL' : '← return'} ${e.name}`))),
      ]),
    );
  };
  const body = h('div', {}, [
    h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:8px' }, [typeSel, modeSel, h('span', {}, 'Break at line'), lineIn, h('span', {}, 'of'), scriptSel, h('button.btn.primary', { type: 'button', onClick: run }, 'Run')]),
    out,
  ]);
  openDialog({ title: 'GDL Debugger', body, size: 'lg', actions: [{ label: 'Close', value: null }] });
  run();
}
