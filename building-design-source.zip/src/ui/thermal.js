/**
 * Thermal Bridge Simulation dialog: the junction of the selected walls (and
 * columns) solved in plan (core/thermalbridge.js), with its heat flow, ψ,
 * fRsi and a picture of the temperatures with isotherms.
 */
import { h, clear } from './dom.js';
import { openDialog } from './dialog.js';
import { simulateJunction, junctionBox, simulateSection, sectionJunctionBox, heatColor, TB_DEFAULTS } from '../core/thermalbridge.js';
import { download } from '../io/storage.js';

const field = (label, control) => h('label.field', h('span.field-label', label), control);
const r3 = (v) => (v == null ? '—' : (Math.round(v * 1000) / 1000).toFixed(3));

/** The temperature field as a canvas, north up, with isotherms every 2 °C. */
function heatCanvas(res, scale = 2) {
  const { nx, ny, T, kind } = res.grid;
  const { inside, outside } = res.settings;
  const cv = document.createElement('canvas');
  cv.width = nx * scale;
  cv.height = ny * scale;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(nx, ny);
  for (let j = 0; j < ny; j++)
    for (let i = 0; i < nx; i++) {
      const k = j * nx + i;
      const o = ((ny - 1 - j) * nx + i) * 4;
      const [r, g, b] = kind[k] === 0 ? heatColor(T[k], outside, inside) : kind[k] === 1 ? [246, 246, 246] : [222, 232, 240];
      img.data.set([r, g, b, 255], o);
    }
  const tmp = document.createElement('canvas');
  tmp.width = nx;
  tmp.height = ny;
  tmp.getContext('2d').putImageData(img, 0, 0);
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(tmp, 0, 0, cv.width, cv.height);
  // Isotherms: where a step of 2 °C falls between two solid neighbours.
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  const step = 2;
  for (let j = 0; j < ny; j++)
    for (let i = 0; i < nx - 1; i++) {
      const a = j * nx + i;
      const b = a + 1;
      const c = a + nx;
      if (kind[a] !== 0) continue;
      const cross = (x, y) => kind[x] === 0 && Math.floor(T[x] / step) !== Math.floor(T[y] / step);
      if (cross(b, a) || (j < ny - 1 && cross(c, a))) ctx.fillRect(i * scale, (ny - 1 - j) * scale, scale, scale);
    }
  return cv;
}

export function thermalBridgeDialog(app) {
  const doc = app.doc;
  const view = app.activeView;
  const inSection = view?.kind === 'section';
  const ids = [...app.selection].filter((id) => (inSection ? ['wall', 'column', 'floor'] : ['wall', 'column']).includes(doc.get(id)?.kind));
  if (!ids.length) return app.toast('Select the walls (and columns, or in a section the slabs) that meet at the junction.', { kind: 'error' });
  const box = inSection ? sectionJunctionBox(doc, app.scene, view, ids) : junctionBox(doc, app.scene, ids);
  if (!box) return app.toast(inSection ? 'The selected elements are not cut by this section.' : 'Select the walls of the junction.', { kind: 'error' });
  const o = { ...TB_DEFAULTS, ...doc.get('project')?.thermalBridge };
  const body = h('div');
  const out = h('div');
  const num = (key, label, step) => {
    const i = h('input.input', { type: 'number', step, value: o[key], 'aria-label': label });
    i.addEventListener('keydown', (e) => e.stopPropagation());
    i.addEventListener('change', () => Number.isFinite(+i.value) && ((o[key] = +i.value), app.commit('Thermal bridge settings', () => doc.update('project', { thermalBridge: { ...o } })), run()));
    return field(label, i);
  };
  const run = () => {
    clear(out);
    const t0 = performance.now();
    const res = inSection ? simulateSection(doc, app.scene, view, box, o) : simulateJunction(doc, app.scene, box.levelId, box, o);
    if (res.error) return out.append(h('p.field-hint', res.error));
    const cv = heatCanvas(res, Math.max(1, Math.floor(420 / Math.max(res.grid.nx, res.grid.ny))));
    cv.style.width = '100%';
    cv.style.maxWidth = '420px';
    cv.style.imageRendering = 'pixelated';
    cv.setAttribute('role', 'img');
    cv.setAttribute('aria-label', 'Temperatures in the junction');
    const kv = (k, v) => h('tr', h('td', k), h('td.num', v));
    const legend = h('div.inline', { style: { gap: '6px', alignItems: 'center', fontSize: '12px' } }, `${o.outside} °C`, h('span', { style: { display: 'inline-block', width: '160px', height: '10px', background: `linear-gradient(90deg, ${[0, 0.25, 0.5, 0.65, 0.8, 1].map((s) => `rgb(${heatColor(o.outside + s * (o.inside - o.outside), o.outside, o.inside).join(',')})`).join(',')})` } }), `${o.inside} °C`);
    out.append(
      h(
        'div.row2',
        h('div', cv, legend, h('p.field-hint', inSection ? `Section ${view.name}; lines every 2 °C.` : 'Plan view, north up; lines every 2 °C.')),
        h(
          'div',
          h(
            'table.layers-table.en-table',
            h(
              'tbody',
              kv('Heat flow Q', `${(Math.round(res.Q * 100) / 100).toFixed(2)} W/m`),
              kv('Coupling coefficient L2D', `${r3(res.L2D)} W/mK`),
              kv('ψ, interior dimensions', `${r3(res.psiI)} W/mK`),
              kv('ψ, exterior dimensions', `${r3(res.psiE)} W/mK`),
              kv('Lowest interior surface temperature', res.thetaSiMin == null ? '—' : `${res.thetaSiMin.toFixed(2)} °C`),
              kv('Temperature factor fRsi', res.fRsi == null ? '—' : `${res.fRsi.toFixed(3)}${res.fRsi < 0.75 ? ' (below 0.75: mould risk)' : ''}`),
            ),
          ),
          h('h3.dlg-sub', 'Flanking elements'),
          h('table.layers-table.en-table', h('thead', h('tr', h('th', 'Wall'), h('th', 'U W/m²K'), h('th', 'l inside m'), h('th', 'l outside m'))), h('tbody', res.flanking.map((f) => h('tr', h('td', f.name), h('td.num', r3(f.u)), h('td.num', r3(f.lIn)), h('td.num', r3(f.lOut)))))),
          ...res.notes.map((n) => h('p.field-hint', n)),
          h('p.field-hint', `${res.grid.nx} × ${res.grid.ny} cells of ${res.grid.cell} mm, solved in ${Math.round(performance.now() - t0)} ms. EN ISO 10211 method: cut edges adiabatic, about 1 m past the junction.`),
          h('button.btn.sm', { type: 'button', onClick: () => heatCanvas(res, 4).toBlob((b) => b && download(b, 'Thermal bridge.png')) }, 'Save picture...'),
        ),
      ),
    );
  };
  body.append(h('div.row2', num('inside', 'Inside θi (°C)', 0.5), num('outside', 'Outside θe (°C)', 0.5)), h('div.row2', num('rsi', 'Rsi (m²K/W)', 0.01), num('rse', 'Rse (m²K/W)', 0.01)), num('cell', 'Cell size (mm)', 1), out);
  run();
  return openDialog({ title: 'Thermal Bridge Simulation', body, size: 'lg', actions: [{ label: 'Close', primary: true, value: null }] });
}
