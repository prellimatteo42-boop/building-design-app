/**
 * TrussMaker (Design > TrussMaker): Create Truss makes a truss from lines
 * drawn as its elevation; Edit Truss changes its members one by one on an
 * elevation (role, size, profile, delete, add between two nodes).
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { PickPointsTool } from './drafting.js';
import { formatLength, parseLength } from '../core/units.js';
import { trussGeometry, membersFromLines, memberList, trussMembers } from '../core/truss.js';

const SVG = 'http://www.w3.org/2000/svg';
const svg = (tag, attrs = {}) => {
  const el = document.createElementNS(SVG, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  return el;
};
const LINE_KINDS = new Set(['line', 'detailLine', 'modelLine', 'roomSeparator']);
const field = (label, control) => h('label.field', h('span.field-label', label), control);

/** Create Truss: the selected lines are the truss's elevation; two clicks place it in plan. */
export function createTrussFromLines(app) {
  const doc = app.doc;
  const lines = [...app.selection].map((id) => doc.get(id)).filter((el) => el && LINE_KINDS.has(el.kind) && el.a && el.b);
  if (lines.length < 3) return toast('Draw the truss as lines (its elevation: along and up), select them, then Create Truss.', { kind: 'error' });
  const made = membersFromLines(lines);
  if (!made) return toast('Those lines do not make a truss.', { kind: 'error' });
  const type = app.currentType?.('truss') || doc.all('trussType')[0];
  toast(`Truss of ${made.members.length} members, ${formatLength(made.length, doc.units)} long: click its start and the direction it runs in plan.`);
  app.setTool(
    new PickPointsTool(app, {
      n: 2,
      title: 'Create Truss',
      prompts: ['Click where the truss starts', 'Click the direction it runs'],
      done: ([a, d]) => {
        const v = [d[0] - a[0], d[1] - a[1]];
        const l = Math.hypot(v[0], v[1]) || 1;
        const b = [a[0] + (v[0] / l) * made.length, a[1] + (v[1] / l) * made.length];
        const levelId = app.activeView?.levelId || doc.levels()[0]?.id;
        let id;
        app.commit('Create truss', () => (id = doc.add({ kind: 'truss', levelId, typeId: type?.id, a, b, offset: 0, height: made.height, members: made.members }).id));
        app.select([id]);
      },
    }),
  );
}

/** Edit Truss: the selected truss's members on its elevation. */
export function editTrussDialog(app, id = [...app.selection][0]) {
  const doc = app.doc;
  const el = doc.get(id);
  if (el?.kind !== 'truss') return toast('Select a truss first.', { kind: 'error' });
  const g = trussGeometry(doc, el);
  if (!g) return toast('The truss is too short to edit.', { kind: 'error' });
  let members = g.own.map((m) => ({ ...m, a: [...m.a], b: [...m.b] }));
  let sel = -1;
  let adding = null; // first node when adding a member
  const units = doc.units;
  const beamProfiles = doc.all('profile').filter((p) => p.use === 'beam');
  const W0 = 660;
  const span = Math.max(...members.flatMap((m) => [m.a[0], m.b[0]]), g.L);
  const top = Math.max(...members.flatMap((m) => [m.a[1], m.b[1]]), 100);
  const sc = Math.min(W0 / span, 260 / top);
  const pad = 16;
  const X = (s) => pad + s * sc;
  const Y = (z) => pad + (top - z) * sc;
  const root = svg('svg', { viewBox: `0 0 ${span * sc + pad * 2} ${top * sc + pad * 2}`, class: 'truss-svg', role: 'img', 'aria-label': 'Truss elevation' });
  root.style.width = '100%';
  const nodes = () => [...new Map(members.flatMap((m) => [m.a, m.b]).map((p) => [`${Math.round(p[0])},${Math.round(p[1])}`, p])).values()];
  const side = h('div.truss-side');
  const draw = () => {
    root.replaceChildren();
    members.forEach((m, i) => {
      const chord = m.role === 'chord';
      const line = svg('line', { x1: X(m.a[0]), y1: Y(m.a[1]), x2: X(m.b[0]), y2: Y(m.b[1]), stroke: i === sel ? '#d35400' : chord ? '#2c3e50' : '#7f8c8d', 'stroke-width': i === sel ? 6 : chord ? 5 : 3, 'stroke-linecap': 'round', tabindex: '0', 'data-member': i });
      const hit = svg('line', { x1: X(m.a[0]), y1: Y(m.a[1]), x2: X(m.b[0]), y2: Y(m.b[1]), stroke: 'transparent', 'stroke-width': 14, 'data-hit': i });
      const pick = () => ((sel = i), (adding = null), draw());
      hit.addEventListener('click', pick);
      line.addEventListener('click', pick);
      line.addEventListener('keydown', (e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), pick()));
      const t = svg('title');
      t.textContent = `${chord ? 'Chord' : 'Web'} member ${i + 1}`;
      line.append(t);
      root.append(line, hit);
    });
    for (const p of nodes()) {
      const c = svg('circle', { cx: X(p[0]), cy: Y(p[1]), r: adding && adding === p ? 7 : 5, fill: adding === p ? '#d35400' : '#fff', stroke: '#2c3e50', 'stroke-width': 1.5, class: 'truss-node', 'data-node': `${Math.round(p[0])},${Math.round(p[1])}` });
      c.addEventListener('click', () => {
        if (!adding) {
          adding = p;
        } else if (adding !== p) {
          members.push({ a: [...adding], b: [...p], role: 'web' });
          sel = members.length - 1;
          adding = null;
        }
        draw();
      });
      root.append(c);
    }
    renderSide();
  };
  const renderSide = () => {
    side.replaceChildren();
    if (sel < 0 || !members[sel]) {
      side.append(h('p.field-hint', adding ? 'Click the second node of the new member.' : 'Click a member to change or delete it. Click two nodes to add a member between them.'));
      return;
    }
    const m = members[sel];
    const role = h('select.input', { 'aria-label': 'Role' }, h('option', { value: 'chord' }, 'Chord'), h('option', { value: 'web' }, 'Web'));
    role.value = m.role;
    role.addEventListener('change', () => ((m.role = role.value), draw()));
    const size = h('input.input', { type: 'text', value: m.size ? formatLength(m.size, units) : '', placeholder: 'By type', 'aria-label': 'Member size' });
    size.addEventListener('keydown', (e) => e.stopPropagation());
    size.addEventListener('change', () => {
      const v = parseLength(size.value, units);
      if (size.value.trim() === '') delete m.size;
      else if (Number.isFinite(v) && v > 0) m.size = v;
    });
    const prof = h('select.input', { 'aria-label': 'Member profile' }, h('option', { value: '' }, 'By type (square bar or type profile)'), beamProfiles.map((p) => h('option', { value: p.id }, p.name)));
    prof.value = m.profileId || '';
    prof.addEventListener('change', () => (prof.value ? (m.profileId = prof.value) : delete m.profileId));
    const len = Math.hypot(m.b[0] - m.a[0], m.b[1] - m.a[1]);
    side.append(
      h('p', h('strong', `Member ${sel + 1}`), ` · ${formatLength(len, units)}`),
      field('Role', role),
      field('Size', size),
      field('Profile', prof),
      h('button.btn.sm', { type: 'button', onClick: () => (members.splice(sel, 1), (sel = -1), draw()) }, 'Delete Member'),
    );
  };
  draw();
  const reset = () => {
    const t = doc.get(el.typeId) || {};
    members = memberList(trussMembers(t.pattern || 'pratt', g.L, +el.height || +t.height || 1500, +t.panels || Math.max(2, Math.round(g.L / 1500))));
    sel = -1;
    draw();
  };
  return openDialog({
    title: 'Edit Truss',
    size: 'lg',
    body: h('div.truss-edit', root, side, h('div', h('button.btn.sm', { type: 'button', onClick: reset }, 'Reset to Pattern'))),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'OK',
        primary: true,
        onClick: () => {
          app.commit('Edit truss', () => doc.update(el.id, { members: members.length ? members : null }));
          return true;
        },
      },
    ],
  });
}
