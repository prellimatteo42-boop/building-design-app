/**
 * Physical Model Quality dialog: the checks of core/modelquality.js by
 * kind, each problem with a button that shows its elements.
 */
import { h, clear } from './dom.js';
import { openDialog } from './dialog.js';
import { physicalQuality, QUALITY_CHECKS } from '../core/modelquality.js';

export function physicalQualityDialog(app) {
  const doc = app.doc;
  const on = new Set(QUALITY_CHECKS.map((c) => c.id));
  const body = h('div');
  const list = h('div');
  const render = () => {
    clear(list);
    const all = physicalQuality(doc, app.scene).filter((x) => on.has(x.check));
    if (!all.length) return list.append(h('p.props-empty', 'No problems found by the checks you chose.'));
    const tbody = h('tbody');
    for (const x of all.slice(0, 300)) tbody.append(h('tr', h('td', QUALITY_CHECKS.find((c) => c.id === x.check)?.label), h('td', x.message), h('td', h('button.btn.sm', { type: 'button', onClick: () => app.showElements(x.ids) }, 'Show'))));
    list.append(h('p', `${all.length} problem${all.length === 1 ? '' : 's'}.`), h('div', { style: { maxHeight: '50vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', h('th', 'Check'), h('th', 'Problem'), h('th', h('span.sr-only', 'Show')))), tbody)));
  };
  const checks = h('div.snap-grid');
  for (const c of QUALITY_CHECKS) {
    const cb = h('input', { type: 'checkbox', checked: true });
    cb.addEventListener('change', () => (cb.checked ? on.add(c.id) : on.delete(c.id), render()));
    checks.append(h('label.check', cb, c.label));
  }
  body.append(checks, list);
  render();
  return openDialog({ title: 'Physical Model Quality', body, size: 'lg', actions: [{ label: 'Close', primary: true, value: null }] });
}
