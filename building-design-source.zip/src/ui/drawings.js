/**
 * Drawings on layouts (sheets), as Archicad's Crop Drawing(s) to Frame and
 * Uncrop Drawing(s): a plan-type drawing keeps a frame (its size on paper)
 * and, cropped, shows only what lies inside it (core/sheet.js).
 */
import { isFlatView } from '../core/doc.js';
import { planContext } from '../core/plan.js';
import { planViewportGraphics } from '../core/sheet.js';

function selectedDrawings(app) {
  return [...app.selection].map((id) => app.doc.get(id)).filter((el) => el?.kind === 'viewport');
}

/** Crop (on) or uncrop the selected drawings; a drawing without a frame gets one as large as it is now. */
export function cropDrawings(app, on) {
  const doc = app.doc;
  const vps = selectedDrawings(app);
  if (!vps.length) return app.toast('Select drawings on a sheet first.', { kind: 'error' });
  let n = 0;
  app.commit(on ? 'Crop drawings to frame' : 'Uncrop drawings', () => {
    for (const vp of vps) {
      const view = doc.get(vp.placedId);
      if (!view || !isFlatView(view)) continue;
      const patch = { cropped: on };
      if (on && !vp.frame) {
        const r = planViewportGraphics(app.scene, view, { ...vp, cropped: false }, planContext(doc, view, app.scene.walls, app.scene.rooms));
        patch.frame = r.natural.map((v) => Math.round(v * 10) / 10);
      }
      doc.update(vp.id, patch);
      n++;
    }
  });
  app.toast(n ? `${on ? 'Cropped' : 'Uncropped'} ${n} drawing${n === 1 ? '' : 's'}.${on ? ' Set the frame size in Properties.' : ''}` : '3D views, sections and elevations on sheets are already framed by their size.');
}
