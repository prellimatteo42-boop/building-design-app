/**
 * Navigator Preview (Archicad's): the whole active plan small, with the part the window shows framed. Click or
 * drag in it to move the view there. It follows the model and the view while open.
 */
import { h } from './dom.js';
import { icon } from './icons.js';
import { renderViewImage } from '../views/snapshot.js';

const W = 260;
const H = 180;

export class NavPreview {
  constructor(app) {
    this.app = app;
    this.el = null;
  }

  get open() {
    return !!this.el;
  }

  toggle() {
    if (this.el) return this.close();
    this.canvas = h('canvas', { width: W, height: H, style: { width: `${W}px`, height: `${H}px`, display: 'block', cursor: 'crosshair', background: 'var(--bg-canvas)' }, 'aria-label': 'Navigator preview' });
    const head = h('div.ql-head', h('strong', 'Navigator Preview'), h('button.icon-btn.sm', { type: 'button', 'aria-label': 'Close', onClick: () => this.close() }, icon('x', 14)));
    this.el = h('section.quick-layers.nav-preview', { role: 'dialog', 'aria-label': 'Navigator Preview' }, head, this.canvas);
    document.body.append(this.el);
    const go = (e) => {
      const r = this.canvas.getBoundingClientRect();
      const p = this.thumb?.screenToModel(e.clientX - r.left, e.clientY - r.top);
      const c = this.app.vc;
      if (!p || !c?.cam || !c.is2D) return;
      c.cam = { ...c.cam, cx: p[0], cy: p[1] };
      c.noteCamera?.(true);
      this.app.requestRender();
    };
    let down = false;
    this.canvas.addEventListener('pointerdown', (e) => ((down = true), go(e)));
    this.canvas.addEventListener('pointermove', (e) => down && go(e));
    window.addEventListener('pointerup', (this.up = () => (down = false)));
    this.timer = setInterval(() => this.refresh(), 700);
    this.refresh(true);
  }

  close() {
    clearInterval(this.timer);
    window.removeEventListener('pointerup', this.up);
    this.el?.remove();
    this.el = null;
  }

  /** Redraw: the picture again when the model or the view changed, the frame every time. */
  refresh(force = false) {
    const app = this.app;
    const view = app.activeView;
    if (!this.el || !view || !app.vc?.is2D || view.kind === 'sheet') return;
    const key = `${view.id}|${app.scene?.version}`;
    if (force || key !== this.key) {
      this.key = key;
      try {
        const r = renderViewImage(app, view, W, H, { fit: true });
        this.image = r.canvas;
        this.thumb = r.controller;
      } catch {
        return;
      }
    }
    const ctx = this.canvas.getContext('2d');
    ctx.clearRect(0, 0, W, H);
    if (this.image) ctx.drawImage(this.image, 0, 0);
    // The window's view, framed.
    const c = app.vc;
    const vp = app.viewport;
    const corners = [[0, 0], [vp.width, 0], [vp.width, vp.height], [0, vp.height]].map(([x, y]) => c.screenToModel(x, y)).map((p) => this.thumb.modelToScreen(p));
    ctx.strokeStyle = '#d63a3a';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    corners.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
    ctx.closePath();
    ctx.stroke();
  }
}
