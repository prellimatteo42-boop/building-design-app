/**
 * Create Patch (Archicad's): a rectangle of a section or elevation copied as editable 2D lines and fills, laid
 * over the live drawing on a white cover fill, so a detail can be touched up there without breaking the model.
 * The pieces share a patchId (select one, Select Similar finds the rest).
 */
import { PickPointsTool } from './drafting.js';
import { independentDrawing } from '../core/hiddenline.js';
import { MODEL_KINDS } from '../core/scene.js';
import { clipSegment, clipToRect } from '../core/sheet.js';
import { newId } from '../core/doc.js';

/** The pieces of a patch (not added) from a view's drawing parts, clipped to the rectangle r. */
export function patchPieces(parts, r, viewId) {
  const patchId = newId('patch');
  const box = [[r.x0, r.y0], [r.x1, r.y0], [r.x1, r.y1], [r.x0, r.y1]];
  const out = [{ kind: 'region', viewId, boundary: box, holes: [], pattern: 'solid', color: '#ffffff', cover: true, outline: true, patchId }];
  for (const f of parts.fills || []) {
    const poly = clipToRect(f.boundary, r);
    if (poly.length >= 3) out.push({ kind: 'region', viewId, boundary: poly, holes: [], pattern: f.pattern, outline: false, patchId });
  }
  for (const l of parts.lines || []) {
    const c = clipSegment(l.a, l.b, r);
    if (c && Math.hypot(c[1][0] - c[0][0], c[1][1] - c[0][1]) > 0.5) out.push({ kind: 'detailLine', viewId, a: c[0], b: c[1], style: l.style, patchId });
  }
  return out;
}

export function createPatchTool(app) {
  const view = app.activeView;
  const tool = new PickPointsTool(app, {
    n: 2,
    title: 'Create Patch',
    prompts: ['Click a corner of the area to patch', 'Click the opposite corner'],
    done: ([a, b]) => {
      const r = { x0: Math.min(a[0], b[0]), y0: Math.min(a[1], b[1]), x1: Math.max(a[0], b[0]), y1: Math.max(a[1], b[1]) };
      if (r.x1 - r.x0 < 10 || r.y1 - r.y0 < 10) return;
      const parts = independentDrawing(app.doc, view, (el) => app.scene.mesh(el), MODEL_KINDS);
      const pieces = patchPieces(parts, r, view.id);
      const ids = [];
      app.commit('Create patch', () => pieces.forEach((p) => ids.push(app.doc.add(p).id)));
      app.select(ids);
      app.toast(`Patch of ${ids.length - 1} pieces over the drawing; edit them freely.`, { kind: 'success' });
    },
  });
  Object.defineProperty(tool, 'viewKinds', { get: () => ['section', 'elevation'] });
  return tool;
}
