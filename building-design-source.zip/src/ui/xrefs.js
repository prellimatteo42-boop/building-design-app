/**
 * File > External Content: Attach Xref, Xref Manager (status, reload, relink,
 * detach, bind), DXF-DWG Translation Setup, Place External Drawing on a
 * layout and Update External Drawing (core/xrefs.js, io/filelinks.js).
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { newId } from '../core/doc.js';
import { pickLinkedFile, saveHandle, linkedFile, dropHandle, linksSupported } from '../io/filelinks.js';
import { linkState, LINK_LABEL, externalPlacement, xrefElements } from '../core/xrefs.js';
import { dwgTranslators, DWG_UNITS } from '../core/dwgtranslators.js';
import { sheetSize } from '../core/sheet.js';
import { cadImports } from './cadmanage.js';

const field = (label, control) => h('label.field', h('span.field-label', label), control);

/** Attach Xref: a DWG/DXF imported into the active view and kept linked to its file. */
export async function attachXref(app) {
  const view = app.activeView;
  if (!app.vc?.is2D || view?.kind === 'sheet') return toast('Open a plan, section, elevation, drafting view or detail to attach a drawing to.', { kind: 'error' });
  const picked = await pickLinkedFile('.dwg,.dxf', 'CAD drawing');
  if (!picked) return;
  const id = newId('xr');
  const old = app.doc.all('xref').find((x) => x.name === picked.file.name && x.viewId === view.id);
  const r = await app.importDWG(picked.file, {
    label: 'Attach Xref',
    settings: old?.settings,
    inside: (settings) => {
      if (old) app.doc.remove(old.id);
      app.doc.add({ kind: 'xref', id, name: picked.file.name, viewId: view.id, settings, lastModified: picked.file.lastModified, size: picked.file.size, linked: !!picked.handle });
    },
  });
  if (!r) return;
  await saveHandle(id, picked.handle);
  if (old) await dropHandle(old.id);
  toast(picked.handle ? `${picked.file.name} attached: it stays linked to the file (Xref Manager reloads it when it changes).` : `${picked.file.name} attached as a copy: this browser cannot keep a live link (pick the file again to update it).`);
}

/** Reload an xref from its file (asking for permission when needed), with the settings it was attached with. */
async function reloadXref(app, x, file = null) {
  let f = file;
  if (!f) {
    const read = await linkedFile(x.id, { ask: true });
    if (!read.file) {
      toast(read.state === 'permission' ? 'The browser did not allow reading the file.' : `${x.name} was not found: use Relink.`, { kind: 'error' });
      return false;
    }
    f = read.file;
  }
  if (app.activeView?.id !== x.viewId) app.openView(x.viewId);
  const r = await app.importDWG(f, {
    silent: true,
    label: 'Reload xref',
    settings: x.settings,
    inside: (settings) => app.doc.update(x.id, { settings, lastModified: f.lastModified, size: f.size, name: f.name }),
  });
  if (r) toast(`${f.name} reloaded.`, { kind: 'success' });
  return !!r;
}

export async function xrefManager(app) {
  const doc = app.doc;
  const body = h('div');
  const render = async () => {
    const xs = doc.all('xref');
    const legacy = cadImports(doc).filter((c) => !xs.some((x) => x.name === c.source));
    const rows = [];
    for (const x of xs) {
      const read = x.linked ? await linkedFile(x.id) : null;
      const state = linkState(x, read);
      const btn = (label, tip, fn) => h('button.btn.sm', { type: 'button', 'data-tip': tip, onClick: async () => (await fn(), render()) }, label);
      rows.push(
        h(
          'tr',
          h('td', x.name),
          h('td', doc.get(x.viewId)?.name || '—'),
          h('td', String(xrefElements(doc, x).length)),
          h('td', h('span', { class: `xref-state ${state}` }, LINK_LABEL[state])),
          h(
            'td',
            h(
              'span.inline',
              { style: { gap: '4px' } },
              btn('Reload', 'Read the file again and replace what it brought in', () => reloadXref(app, x)),
              btn('Relink...', 'Point the link at another file', async () => {
                const p = await pickLinkedFile('.dwg,.dxf', 'CAD drawing');
                if (!p) return;
                await saveHandle(x.id, p.handle);
                app.commit('Relink xref', () => doc.update(x.id, { linked: !!p.handle }));
                await reloadXref(app, doc.get(x.id), p.file);
              }),
              btn('Detach', 'Remove the drawing and its link', async () => {
                app.commit('Detach xref', () => {
                  for (const el of xrefElements(doc, x)) doc.remove(el.id);
                  doc.remove(x.id);
                });
                await dropHandle(x.id);
              }),
              btn('Bind', 'Keep the elements as the project\'s own, without the link', async () => {
                app.commit('Bind xref', () => {
                  for (const el of xrefElements(doc, x)) doc.update(el.id, { cadSource: undefined });
                  doc.remove(x.id);
                });
                await dropHandle(x.id);
              }),
            ),
          ),
        ),
      );
    }
    for (const c of legacy)
      rows.push(
        h(
          'tr',
          h('td', c.source),
          h('td', [...c.views].map((v) => doc.get(v)?.name).filter(Boolean).join(', ') || '—'),
          h('td', String(c.count)),
          h('td', 'Imported (not linked)'),
          h(
            'td',
            h(
              'span.inline',
              { style: { gap: '4px' } },
              h('button.btn.sm', { type: 'button', onClick: () => (body.closest('dialog')?._close(null), app.importDWG()) }, 'Reload...'),
              h('button.btn.sm', { type: 'button', onClick: () => (app.commit('Detach drawing', () => [...doc.items.values()].filter((el) => el.cadSource === c.source).forEach((el) => doc.remove(el.id))), render()) }, 'Detach'),
              h('button.btn.sm', { type: 'button', onClick: () => (app.commit('Bind drawing', () => [...doc.items.values()].filter((el) => el.cadSource === c.source).forEach((el) => doc.update(el.id, { cadSource: undefined }))), render()) }, 'Bind'),
            ),
          ),
        ),
      );
    body.replaceChildren(
      ...[
      rows.length ? h('table.vg-table', h('thead', h('tr', ...['Drawing', 'View', 'Elements', 'Status', ''].map((x) => h('th', x)))), h('tbody', rows)) : h('p.field-hint', 'No DWG or DXF drawing is attached or imported.'),
      h('div.row-actions', { style: { marginTop: '8px' } }, h('button.btn.sm', { type: 'button', onClick: () => (body.closest('dialog')?._close(null), attachXref(app)) }, 'Attach Xref...')),
      linksSupported() ? null : h('p.field-hint', 'This browser cannot keep links to files: attached drawings are copies, updated by picking the file again.'),
      ].filter(Boolean),
    );
  };
  await render();
  return openDialog({ title: 'Xref Manager', body, size: 'lg', actions: [{ label: 'Close', value: null }] });
}

export function dwgTranslatorsDialog(app) {
  const doc = app.doc;
  let list = structuredClone(dwgTranslators(doc));
  let cur = doc.get('project')?.dwgTranslatorId && list.some((t) => t.id === doc.get('project').dwgTranslatorId) ? doc.get('project').dwgTranslatorId : list[0].id;
  const side = h('ul.file-list', { style: { maxHeight: '300px' } });
  const form = h('div');
  const render = () => {
    side.replaceChildren(...list.map((t) => h('li', h('button.file-item', { type: 'button', 'aria-current': String(t.id === cur), onClick: () => ((cur = t.id), render()) }, h('span.file-name', t.name), h('span.file-meta', t.id === cur ? 'current' : '')))));
    const t = list.find((x) => x.id === cur);
    const name = h('input.input', { type: 'text', value: t.name, 'aria-label': 'Name' });
    name.addEventListener('keydown', (e) => e.stopPropagation());
    name.addEventListener('change', () => ((t.name = name.value || t.name), render()));
    const sel = (key, opts, label) => {
      const s = h('select.input', { 'aria-label': label }, opts.map((o) => h('option', { value: o.value }, o.label)));
      s.value = t[key] ?? '';
      s.addEventListener('change', () => (t[key] = s.value || null));
      return field(label, s);
    };
    const chk = (key, label) => {
      const c = h('input', { type: 'checkbox', checked: t[key] !== false });
      c.addEventListener('change', () => (t[key] = c.checked));
      return h('label.check', c, h('span', label));
    };
    const roles = Object.entries(t.roles || {});
    form.replaceChildren(
      field('Name', name),
      h('div.row2', sel('unit', DWG_UNITS, 'Drawing unit'), sel('mode', [{ value: '', label: 'By the drawing (model when it has wall layers)' }, { value: 'smart', label: 'Model from layers, the rest as drafting' }, { value: 'model', label: 'Model only' }, { value: 'drafting', label: 'Drafting only' }], 'Import as')),
      h('div', chk('centre', 'Move the drawing\'s middle to the origin'), chk('fills', 'Solid fills as filled regions')),
      h('p.field-hint', `${roles.length} layer roles and ${(t.skip || []).length} layers left out, saved from an import (Import DWG > Save as Translator).`),
      roles.length ? h('div', { style: { maxHeight: '140px', overflow: 'auto' } }, h('table.layers-table', h('tbody', roles.map(([k, v]) => h('tr', h('td', k || '(no layer)'), h('td', v)))))) : null,
      h('div.row-actions', h('button.btn.sm', { type: 'button', onClick: () => ((list = [...list, { ...structuredClone(t), id: newId('dwg'), name: `${t.name} copy` }]), (cur = list.at(-1).id), render()) }, 'Duplicate'), h('button.btn.sm', { type: 'button', disabled: list.length < 2, onClick: () => ((list = list.filter((x) => x.id !== t.id)), (cur = list[0].id), render()) }, 'Delete')),
    );
  };
  render();
  return openDialog({
    title: 'DXF-DWG Translation Setup',
    size: 'lg',
    body: h('div', { style: { display: 'grid', gridTemplateColumns: '220px 1fr', gap: '14px' } }, side, form),
    actions: [
      { label: 'Cancel', value: null },
      { label: 'OK', primary: true, onClick: () => (app.commit('DXF-DWG translators', () => doc.update('project', { dwgTranslators: list, dwgTranslatorId: cur })), true) },
    ],
  });
}

/** A PDF's first page or a picture as an image: { src, px, pageMm }. */
async function drawingImage(file) {
  if (/\.pdf$/i.test(file.name)) {
    const { openPDF } = await import('../io/pdfread.js');
    const pdf = await openPDF(new Uint8Array(await file.arrayBuffer()));
    const r = await pdf.render(1, { dpi: 150 });
    pdf.close();
    return { src: r.canvas.toDataURL('image/png'), px: [r.canvas.width, r.canvas.height], pageMm: [r.widthMm, r.heightMm] };
  }
  const src = await new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(new Error('The picture could not be read'));
    fr.readAsDataURL(file);
  });
  const px = await new Promise((resolve) => {
    const im = new Image();
    im.onload = () => resolve([im.naturalWidth, im.naturalHeight]);
    im.onerror = () => resolve([1, 1]);
    im.src = src;
  });
  return { src, px, pageMm: null };
}

/** Place External Drawing: a PDF or a picture on the open layout, linked to its file. */
export async function placeExternalDrawing(app) {
  const sheet = app.activeView;
  if (sheet?.kind !== 'sheet') return toast('Open a layout (sheet) to place an external drawing on.', { kind: 'error' });
  const picked = await pickLinkedFile('.pdf,.png,.jpg,.jpeg,.webp', 'Drawing');
  if (!picked) return;
  let img;
  try {
    img = await drawingImage(picked.file);
  } catch (err) {
    return toast(`That file could not be read: ${err.message || err}`, { kind: 'error' });
  }
  const { at, w, h: hh } = externalPlacement(sheetSize(sheet), img);
  const id = newId('xd');
  app.commit('Place external drawing', () => app.doc.add({ kind: 'image', viewId: sheet.id, at, w, h: hh, rotation: 0, opacity: 1, src: img.src, px: img.px, name: picked.file.name, extLink: id, lastModified: picked.file.lastModified, size: picked.file.size, linked: !!picked.handle }));
  await saveHandle(id, picked.handle);
  app.select([...app.doc.items.values()].filter((el) => el.extLink === id).map((el) => el.id));
}

/** Update External Drawing: the selected external drawings read again from their files (same place and width). */
export async function updateExternalDrawings(app, ids = [...app.selection]) {
  const els = ids.map((id) => app.doc.get(id)).filter((el) => el?.extLink);
  const all = els.length ? els : app.doc.all('image').filter((el) => el.extLink);
  if (!all.length) return toast('There are no external drawings to update.', { kind: 'error' });
  let n = 0;
  for (const el of all) {
    const read = await linkedFile(el.extLink, { ask: true });
    if (!read.file) continue;
    if (linkState(el, read) !== 'changed' && els.length === 0) continue;
    const img = await drawingImage(read.file);
    const hh = (el.w * img.px[1]) / Math.max(1, img.px[0]);
    app.commit('Update external drawing', () => app.doc.update(el.id, { src: img.src, px: img.px, h: hh, lastModified: read.file.lastModified, size: read.file.size }));
    n++;
  }
  toast(n ? `${n} external drawing${n === 1 ? '' : 's'} updated.` : 'The external drawings are up to date (or their files could not be read).');
}

/** When the window comes back: say which linked files changed (once per change). */
export function watchLinks(app) {
  const told = new Set();
  let last = 0;
  window.addEventListener('focus', async () => {
    if (Date.now() - last < 5000 || !app.doc) return;
    last = Date.now();
    const items = [...app.doc.all('xref'), ...app.doc.all('image').filter((el) => el.extLink)];
    for (const it of items) {
      if (!it.linked) continue;
      const read = await linkedFile(it.extLink || it.id);
      const key = `${it.id}:${read.file?.lastModified}`;
      if (linkState(it, read) === 'changed' && !told.has(key)) {
        told.add(key);
        toast(`${it.name} changed on disk: ${it.kind === 'xref' ? 'reload it in the Xref Manager' : 'use Update External Drawing'}.`);
      }
    }
  });
}
