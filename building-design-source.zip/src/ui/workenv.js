/**
 * Options > Work Environment: customise the Toolbox, the menus, the
 * toolbars, the Info Box panels and the Tool Settings dialogs, and keep
 * them as named profiles (saved here, or exported and imported as files).
 * The data and how it applies are in core/workenv.js.
 */
import { h, clear } from './dom.js';
import { openDialog, promptDialog, toast } from './dialog.js';
import { download } from '../io/storage.js';
import { COMMANDS } from '../commands.js';
import { AC_MENUBAR, AC_STANDARD_TOOLBAR, AC_TOOLBOX, AC_INFOBOX } from './acmenus.js';
import { TYPE_PARAMS } from '../core/props.js';
import { normCustom, EMPTY_CUSTOM, toolKey, toggled, profileFile, readProfileFile } from '../core/workenv.js';

const PAGES = [
  ['toolbox', 'Toolbox'],
  ['menus', 'Menus'],
  ['toolbars', 'Toolbars'],
  ['infobox', 'Info Box'],
  ['toolSettings', 'Tool Settings Dialog Boxes'],
  ['profiles', 'Profiles'],
];

const TYPE_LABELS = { wallType: 'Wall', floorType: 'Slab', roofType: 'Roof', ceilingType: 'Ceiling', columnType: 'Column', beamType: 'Beam', doorType: 'Door', windowType: 'Window', stairType: 'Stair', railingType: 'Railing', componentType: 'Object', roomType: 'Zone' };

const cmdLabel = (cmd) => COMMANDS[cmd]?.label || cmd;
const commandNames = () => Object.keys(COMMANDS).filter((n) => COMMANDS[n].run && COMMANDS[n].label && !/^[a-z]+-/.test(n)).sort((a, b) => cmdLabel(a).localeCompare(cmdLabel(b)));

const check = (label, on, change) => {
  const inp = h('input', { type: 'checkbox', checked: !!on });
  inp.addEventListener('change', () => change(inp.checked));
  return h('label', { style: 'display:flex;gap:6px;align-items:center;margin:2px 0;font-size:var(--fs-sm)' }, inp, label);
};

/** An editable list of commands (null = separator): reorder, remove, add from every command of the app. */
function commandList(list, onChange, { separators = true } = {}) {
  const box = h('div');
  const render = () => {
    clear(box);
    const rows = h('div', { style: 'max-height:180px;overflow:auto;border:1px solid var(--border);border-radius:4px;padding:4px;margin:4px 0' });
    if (!list.length) rows.append(h('p.field-hint', {}, 'No commands yet.'));
    list.forEach((cmd, i) => {
      const move = (d) => {
        const j = i + d;
        if (j < 0 || j >= list.length) return;
        [list[i], list[j]] = [list[j], list[i]];
        onChange(list);
        render();
      };
      rows.append(
        h('div', { style: 'display:flex;gap:4px;align-items:center;font-size:var(--fs-sm)' }, [
          h('span', { style: 'flex:1' }, cmd ? cmdLabel(cmd) : '— separator —'),
          h('button.btn.sm', { type: 'button', 'aria-label': 'Up', onClick: () => move(-1) }, '↑'),
          h('button.btn.sm', { type: 'button', 'aria-label': 'Down', onClick: () => move(1) }, '↓'),
          h('button.btn.sm', { type: 'button', 'aria-label': 'Remove', onClick: () => (list.splice(i, 1), onChange(list), render()) }, '×'),
        ]),
      );
    });
    const id = `cmds-${Math.random().toString(36).slice(2)}`;
    const names = commandNames();
    const input = h('input.input.sm', { list: id, placeholder: 'Add a command…', 'aria-label': 'Add a command', style: 'flex:1' });
    input.addEventListener('keydown', (e) => e.stopPropagation());
    const add = () => {
      const v = input.value.trim().toLowerCase();
      const cmd = names.find((n) => cmdLabel(n).toLowerCase() === v || n.toLowerCase() === v);
      if (!cmd) return toast('Choose a command from the list.', { kind: 'error' });
      list.push(cmd);
      onChange(list);
      render();
    };
    box.append(
      rows,
      h('div', { style: 'display:flex;gap:4px' }, [
        input,
        h('datalist', { id }, names.map((n) => h('option', { value: cmdLabel(n) }))),
        h('button.btn.sm', { type: 'button', onClick: add }, 'Add'),
        separators ? h('button.btn.sm', { type: 'button', onClick: () => (list.push(null), onChange(list), render()) }, 'Separator') : '',
      ]),
    );
  };
  render();
  return box;
}

export function workEnvironmentDialog(app, page = 'toolbox') {
  let c = normCustom(structuredClone(app.settings.acCustom || {}));
  const profiles = { ...(app.settings.acProfiles || {}) };
  const tabs = h('div', { role: 'tablist', style: 'display:flex;gap:4px;flex-wrap:wrap;margin-bottom:10px' });
  const body = h('div', { style: 'min-height:320px;max-height:60vh;overflow:auto' });
  const pages = {
    toolbox: () => {
      const out = [h('p.field-hint', {}, 'Tools shown in the Toolbox, and commands of your own added in a User section at its foot.')];
      for (const s of AC_TOOLBOX) {
        out.push(h('h4', { style: 'margin:8px 0 2px' }, s.title));
        for (const t of s.tools) out.push(check(t.label, !c.toolbox.hidden.includes(toolKey(s.title, t.label)), (on) => (c.toolbox.hidden = toggled(c.toolbox.hidden, toolKey(s.title, t.label), !on))));
      }
      out.push(h('h4', { style: 'margin:10px 0 2px' }, 'User'), commandList(c.toolbox.extra, (l) => (c.toolbox.extra = l), { separators: false }));
      return out;
    },
    menus: () => {
      const out = [h('p.field-hint', {}, 'Menus shown in the menu bar, and a menu of your own before Help.')];
      for (const m of AC_MENUBAR) out.push(check(m.label, !c.menus.hidden.includes(m.label), (on) => (c.menus.hidden = toggled(c.menus.hidden, m.label, !on))));
      const custom = (c.menus.custom ||= { label: 'My Menu', cmds: [] });
      const name = h('input.input.sm', { value: custom.label, 'aria-label': 'Menu name', style: 'width:14em' });
      name.addEventListener('input', () => (custom.label = name.value.trim()));
      name.addEventListener('keydown', (e) => e.stopPropagation());
      out.push(h('h4', { style: 'margin:10px 0 2px' }, 'Custom menu'), h('label', { style: 'display:flex;gap:6px;align-items:center' }, 'Name', name), commandList(custom.cmds, (l) => (custom.cmds = l)));
      return out;
    },
    toolbars: () => {
      const out = [check('Show the Standard toolbar', c.toolbars.standard !== false, (on) => (c.toolbars.standard = on)), h('h4', { style: 'margin:8px 0 2px' }, 'Standard toolbar buttons')];
      for (const it of AC_STANDARD_TOOLBAR) if (it) out.push(check(it.label, !c.toolbars.hidden.includes(it.label), (on) => (c.toolbars.hidden = toggled(c.toolbars.hidden, it.label, !on))));
      const users = h('div');
      const renderUsers = () => {
        clear(users);
        c.toolbars.user.forEach((bar, i) => {
          const name = h('input.input.sm', { value: bar.name, 'aria-label': 'Toolbar name', style: 'width:14em' });
          name.addEventListener('input', () => (bar.name = name.value.trim() || 'Toolbar'));
          name.addEventListener('keydown', (e) => e.stopPropagation());
          users.append(h('div', { style: 'margin:8px 0;padding:6px;border:1px solid var(--border);border-radius:4px' }, [
            h('div', { style: 'display:flex;gap:6px;align-items:center' }, ['Name', name, h('button.btn.sm', { type: 'button', onClick: () => (c.toolbars.user.splice(i, 1), renderUsers()) }, 'Delete toolbar')]),
            commandList(bar.cmds, (l) => (bar.cmds = l)),
          ]));
        });
        users.append(h('button.btn.sm', { type: 'button', onClick: () => (c.toolbars.user.push({ name: `Toolbar ${c.toolbars.user.length + 1}`, cmds: [] }), renderUsers()) }, 'New toolbar'));
      };
      renderUsers();
      out.push(h('h4', { style: 'margin:10px 0 2px' }, 'Your toolbars'), users);
      return out;
    },
    infobox: () => {
      const tools = Object.keys(AC_INFOBOX).filter((k) => COMMANDS[k]).sort((a, b) => cmdLabel(a).localeCompare(cmdLabel(b)));
      const sel = h('select.input.sm', { 'aria-label': 'Tool', style: 'width:auto' }, tools.map((k) => h('option', { value: k }, cmdLabel(k))));
      const list = h('div');
      const render = () => {
        clear(list);
        const cmd = sel.value;
        for (const p of AC_INFOBOX[cmd] || []) {
          if (p === 'Main') continue;
          list.append(check(p, !(c.infobox[cmd] || []).includes(p), (on) => (c.infobox[cmd] = toggled(c.infobox[cmd], p, !on))));
        }
      };
      sel.addEventListener('change', render);
      render();
      return [h('p.field-hint', {}, 'Panels each tool shows in the Info Box (Main always shows).'), h('label', { style: 'display:flex;gap:6px;align-items:center' }, 'Tool', sel), list];
    },
    toolSettings: () => {
      const kinds = Object.keys(TYPE_PARAMS);
      const sel = h('select.input.sm', { 'aria-label': 'Tool', style: 'width:auto' }, kinds.map((k) => h('option', { value: k }, TYPE_LABELS[k] || k)));
      const list = h('div');
      const render = () => {
        clear(list);
        const k = sel.value;
        const groups = new Map();
        for (const p of TYPE_PARAMS[k] || []) {
          if (!p.key || p.type === 'button') continue;
          (groups.get(p.group || 'Other') || groups.set(p.group || 'Other', []).get(p.group || 'Other')).push(p);
        }
        for (const [g, ps] of groups) {
          list.append(h('h4', { style: 'margin:8px 0 2px' }, g));
          for (const p of ps) list.append(check(p.label, !(c.toolSettings[k] || []).includes(p.key), (on) => (c.toolSettings[k] = toggled(c.toolSettings[k], p.key, !on))));
        }
      };
      sel.addEventListener('change', render);
      render();
      return [h('p.field-hint', {}, 'Fields each tool’s settings dialog shows.'), h('label', { style: 'display:flex;gap:6px;align-items:center' }, 'Tool', sel), list];
    },
    profiles: () => {
      const list = h('div');
      const render = () => {
        clear(list);
        const names = Object.keys(profiles).sort();
        if (!names.length) list.append(h('p.field-hint', {}, 'No profiles yet.'));
        for (const n of names)
          list.append(h('div', { style: 'display:flex;gap:6px;align-items:center;margin:3px 0' }, [
            h('span', { style: 'flex:1' }, n),
            h('button.btn.sm', { type: 'button', onClick: () => ((c = normCustom(structuredClone(profiles[n]))), toast(`Profile ${n} applied: press OK to keep it.`)) }, 'Apply'),
            h('button.btn.sm', { type: 'button', onClick: () => download(new Blob([profileFile(n, profiles[n])], { type: 'application/json' }), `${n}.bdwe.json`) }, 'Export'),
            h('button.btn.sm', { type: 'button', onClick: () => (delete profiles[n], render()) }, 'Delete'),
          ]));
      };
      render();
      const save = async () => {
        const name = await promptDialog('Store Profile', 'Name', 'My profile');
        if (!name) return;
        profiles[name] = structuredClone(c);
        render();
      };
      const importFile = () => {
        const input = h('input', { type: 'file', accept: '.json', hidden: true });
        input.addEventListener('change', async () => {
          const f = input.files?.[0];
          input.remove();
          if (!f) return;
          try {
            const p = readProfileFile(await f.text());
            profiles[p.name] = p.custom;
            render();
          } catch (err) {
            toast(err.message || String(err), { kind: 'error' });
          }
        });
        document.body.append(input);
        input.click();
      };
      return [
        h('p.field-hint', {}, 'A profile keeps the whole work environment: Toolbox, menus, toolbars, Info Box and Tool Settings.'),
        list,
        h('div', { style: 'display:flex;gap:6px;margin-top:8px;flex-wrap:wrap' }, [
          h('button.btn.sm', { type: 'button', onClick: save }, 'Store current as profile…'),
          h('button.btn.sm', { type: 'button', onClick: importFile }, 'Import profile…'),
          h('button.btn.sm', { type: 'button', onClick: () => ((c = EMPTY_CUSTOM()), toast('Archicad’s standard work environment: press OK to apply.')) }, 'Reset to standard'),
        ]),
      ];
    },
  };
  const show = (p) => {
    page = p;
    clear(tabs);
    for (const [id, label] of PAGES) tabs.append(h(`button.btn.sm${id === page ? '.primary' : ''}`, { type: 'button', role: 'tab', 'aria-selected': String(id === page), onClick: () => show(id) }, label));
    clear(body);
    body.append(...pages[page]());
  };
  show(PAGES.some(([id]) => id === page) ? page : 'toolbox');
  return openDialog({ title: 'Work Environment', size: 'lg', body: h('div', {}, tabs, body), actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    app.settingsStore.set('acCustom', normCustom(c));
    app.settingsStore.set('acProfiles', profiles);
    applyWorkEnvironment(app);
    toast('Work environment saved.', { kind: 'success' });
  });
}

/** Rebuild menus, toolbars, Toolbox and Info Box after a change. */
export function applyWorkEnvironment(app) {
  app.workspace?.rebuild?.();
  app.renderOptions?.();
}
