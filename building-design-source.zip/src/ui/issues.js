/**
 * Issue Manager: issues with a status, priority, assignee and comments,
 * each with a viewpoint (view, camera, selection) and a snapshot, shown
 * again with one click, and exchanged with other software as BCF.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { icon } from './icons.js';
import { ISSUE_TYPES, ISSUE_STATUSES, ISSUE_PRIORITIES, issuesInOrder, uuid } from '../core/issues.js';
import { writeBCF, readBCF } from '../io/bcf.js';
import { renderViewImage } from '../views/snapshot.js';
import { download } from '../io/storage.js';
import { isFlatView } from '../core/doc.js';

const now = () => new Date().toISOString().replace(/\.\d+Z$/, 'Z');

/** The active view's viewpoint and a snapshot of it, or null for views without one. */
function capture(app) {
  const view = app.activeView;
  const c = app.vc;
  if (!view || !c?.cam || !c.graphical) return { viewpoint: { viewId: view?.id ?? null, camera: null, selection: [...app.selection] }, snapshot: null };
  let snapshot = null;
  try {
    const { canvas } = renderViewImage(app, view, 480, 300, { fit: false, camera: c.cam });
    snapshot = canvas.toDataURL('image/png');
  } catch {
    // Some views cannot be rendered off screen; the issue keeps its viewpoint.
  }
  return { viewpoint: { viewId: view.id, camera: structuredClone(c.cam), selection: [...app.selection] }, snapshot };
}

/** A 3D orbit camera for an issue's viewpoint (plans look straight down), for BCF. */
function camera3D(app, issue) {
  const vp = issue.viewpoint || {};
  const view = app.doc.get(vp.viewId);
  if (vp.camera?.target) return vp.camera;
  if (view && isFlatView(view) && vp.camera?.cx != null) {
    const z = app.doc.get(view.levelId)?.elevation ?? 0;
    return { target: [vp.camera.cx, vp.camera.cy, z], dist: Math.max(5000, (app.viewport.height || 800) / (vp.camera.zoom || 0.05)), yaw: -Math.PI / 2, pitch: Math.PI / 2 - 1e-3, persp: false, fov: 45 };
  }
  return null;
}

/** Go back to an issue's viewpoint: its view (or the 3D view), camera and selection. */
export function showIssue(app, issue) {
  const vp = issue.viewpoint || {};
  if (vp.viewId && app.doc.has(vp.viewId)) app.openView(vp.viewId);
  else if (vp.camera?.target) app.open3D();
  const c = app.vc;
  if (c && vp.camera && ((vp.camera.target && c.is3D) || (vp.camera.cx != null && !c.is3D))) {
    c.cam = structuredClone(vp.camera);
    app.requestRender();
  }
  const live = (vp.selection || []).filter((id) => app.doc.has(id));
  if (live.length) app.select(live);
}

export function issuesDialog(app) {
  const doc = app.doc;
  let filter = '';
  let sel = issuesInOrder(doc)[0]?.id ?? null;
  const list = h('ul.file-list.mat-list.is-list');
  const detail = h('div.mat-detail.is-detail');
  const me = () => doc.project?.author || 'Me';
  const update = (patch, label = 'Edit issue') => {
    app.commit(label, () => doc.update(sel, { ...patch, modified: now() }));
    renderList();
  };
  const renderDetail = () => {
    clear(detail);
    const is = doc.get(sel);
    if (!is) return detail.append(h('p.props-empty', 'No issue selected. New Issue records the active view, its camera and selection, with a picture.'));
    const input = (key, label) => {
      const el = h('input.input', { type: 'text', value: is[key] || '', 'aria-label': label });
      el.addEventListener('change', () => update({ [key]: el.value.trim() }));
      return h('label.field', h('span.field-label', label), el);
    };
    const select = (key, label, options) => {
      const el = h('select.input', { 'aria-label': label }, options.map((o) => h('option', { value: o, selected: o === is[key] }, o)));
      el.addEventListener('change', () => (update({ [key]: el.value }), renderDetail()));
      return h('label.field', h('span.field-label', label), el);
    };
    const desc = h('textarea.input', { rows: 3, 'aria-label': 'Description' });
    desc.value = is.description || '';
    desc.addEventListener('keydown', (e) => e.stopPropagation());
    desc.addEventListener('change', () => update({ description: desc.value }));
    const comment = h('textarea.input', { rows: 2, placeholder: 'Add a comment', 'aria-label': 'New comment' });
    comment.addEventListener('keydown', (e) => e.stopPropagation());
    const addComment = () => {
      const text = comment.value.trim();
      if (!text) return;
      update({ comments: [...(is.comments || []), { guid: uuid(), author: me(), date: now(), text }] }, 'Comment on issue');
      renderDetail();
    };
    detail.append(
      input('title', 'Title'),
      h('div.is-row3', select('type', 'Type', ISSUE_TYPES), select('status', 'Status', ISSUE_STATUSES), select('priority', 'Priority', ISSUE_PRIORITIES)),
      input('assignedTo', 'Assigned to'),
      h('label.field', h('span.field-label', 'Description'), desc),
      is.snapshot ? h('img.is-snap', { src: is.snapshot, alt: `Viewpoint of ${is.title}` }) : null,
      h(
        'div.inline',
        { style: { gap: '6px', flexWrap: 'wrap' } },
        h('button.btn.sm', { type: 'button', onClick: () => showIssue(app, is) }, icon('eye', 14), 'Show Viewpoint'),
        h('button.btn.sm', { type: 'button', onClick: () => (update(capture(app), 'Update issue viewpoint'), renderDetail()) }, 'Update from Active View'),
        h('button.btn.sm', { type: 'button', onClick: () => {
          app.commit('Delete issue', () => doc.remove(sel));
          sel = issuesInOrder(doc, filter || null)[0]?.id ?? null;
          renderList();
          renderDetail();
        } }, icon('trash', 14), 'Delete'),
      ),
      h('p.file-meta', `${is.author || 'Unknown'} · ${String(is.created || '').slice(0, 16).replace('T', ' ')}${is.viewpoint?.selection?.length ? ` · ${is.viewpoint.selection.length} element${is.viewpoint.selection.length === 1 ? '' : 's'}` : ''}`),
      h('h3.dlg-sub', 'Comments'),
      h('div.is-comments', (is.comments || []).length ? is.comments.map((c) => h('div.is-comment', h('div.file-meta', `${c.author} · ${String(c.date).slice(0, 16).replace('T', ' ')}`), h('div', c.text))) : h('p.field-hint', 'No comments yet.')),
      comment,
      h('button.btn.sm', { type: 'button', onClick: addComment }, 'Add Comment'),
    );
  };
  const renderList = () => {
    clear(list);
    const items = issuesInOrder(doc, filter || null);
    if (!items.length) list.append(h('li', h('p.field-hint', 'No issues.')));
    for (const is of items)
      list.append(
        h('li', h('button.file-item.is-item', { type: 'button', 'aria-pressed': String(is.id === sel), onClick: () => ((sel = is.id), renderList(), renderDetail()) }, h('span.is-dot', { 'data-status': is.status }), h('span.file-name', is.title), h('span.file-meta', is.status))),
      );
  };
  const newIssue = () => {
    const shot = capture(app);
    const n = doc.all('issue').length + 1;
    let id;
    app.commit('New issue', () => (id = doc.add({ kind: 'issue', guid: uuid(), title: `Issue ${n}`, type: 'Issue', status: 'Open', priority: 'Normal', assignedTo: '', author: me(), created: now(), modified: null, description: '', comments: [], ...shot }).id));
    sel = id;
    filter = '';
    statusSel.value = '';
    renderList();
    renderDetail();
  };
  const exportBCF = () => {
    const items = issuesInOrder(doc, filter || null);
    if (!items.length) return toast('No issues to export.', { kind: 'error' });
    const bytes = writeBCF(doc, items, (i) => camera3D(app, i));
    download(new Blob([bytes], { type: 'application/octet-stream' }), `${doc.project?.name || 'Issues'}.bcfzip`);
  };
  const importBCF = () => {
    const input = h('input', { type: 'file', accept: '.bcf,.bcfzip,application/zip', hidden: true });
    input.addEventListener('change', async () => {
      const f = input.files?.[0];
      input.remove();
      if (!f) return;
      try {
        const got = await readBCF(doc, new Uint8Array(await f.arrayBuffer()));
        const known = new Map(doc.all('issue').map((i) => [i.guid, i.id]));
        app.commit('Import BCF', () => {
          for (const is of got) {
            if (known.has(is.guid)) doc.update(known.get(is.guid), is);
            else doc.add({ kind: 'issue', ...is });
          }
        });
        toast(`Imported ${got.length} issue${got.length === 1 ? '' : 's'}.`, { kind: 'success' });
        sel = issuesInOrder(doc)[0]?.id ?? null;
        renderList();
        renderDetail();
      } catch (err) {
        toast(`That BCF file could not be read: ${err.message}`, { kind: 'error' });
      }
    });
    document.body.append(input);
    input.click();
  };
  const statusSel = h('select.input.sm', { 'aria-label': 'Show issues' }, [h('option', { value: '' }, 'All issues'), ...ISSUE_STATUSES.map((s) => h('option', { value: s }, s))]);
  statusSel.addEventListener('change', () => ((filter = statusSel.value), renderList()));
  renderList();
  renderDetail();
  return openDialog({
    title: 'Issue Manager',
    size: 'lg',
    body: h(
      'div.mat-layout',
      h(
        'div.mat-side',
        statusSel,
        list,
        h(
          'div.inline',
          { style: { marginTop: '8px', gap: '6px', flexWrap: 'wrap' } },
          h('button.btn.sm', { type: 'button', onClick: newIssue }, icon('plus', 14), 'New Issue'),
          h('button.btn.sm', { type: 'button', onClick: exportBCF }, 'Export BCF'),
          h('button.btn.sm', { type: 'button', onClick: importBCF }, 'Import BCF...'),
        ),
      ),
      detail,
    ),
    actions: [{ label: 'Close', primary: true, value: null }],
  });
}
