/**
 * openBIM commands: Update with IFC Model (core/ifcupdate.js) with a preview
 * of what changes, and property values out to Excel and back
 * (core/propimport.js).
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { updateFromIFC } from '../core/ifcupdate.js';
import { propertyTable, applyPropertyTable, parseCSV } from '../core/propimport.js';
import { writeXLSX, readXLSX } from '../io/xlsx.js';
import { download } from '../io/storage.js';
import { pickFile } from '../io/files.js';

export async function updateWithIFC(app) {
  const f = await pickFile('.ifc,.IFC');
  if (!f) return;
  let text;
  let pre;
  try {
    text = await f.text();
    pre = updateFromIFC(app.doc, text, { name: f.name });
  } catch (err) {
    return toast(`That IFC file could not be read: ${err.message || err}`, { kind: 'error' });
  }
  if (!app.doc.filter((el) => el.ifcGuid).length) toast('No element of this project came from IFC: everything in the file will be added.', { kind: 'info' });
  const remove = h('input', { type: 'checkbox' });
  const body = h(
    'div',
    h('p', `${f.name} against this project, element by element (IFC GlobalId):`),
    h('table.layers-table.en-table', h('tbody', h('tr', h('td', 'Changed in the file, to update'), h('td.num', String(pre.updated.length))), h('tr', h('td', 'New in the file, to add'), h('td.num', String(pre.added.length))), h('tr', h('td', 'Unchanged'), h('td.num', String(pre.unchanged))), h('tr', h('td', 'No longer in the file'), h('td.num', String(pre.gone.length))))),
    pre.gone.length ? h('label.check', remove, `Remove the ${pre.gone.length} elements no longer in the file`) : null,
    h('p.field-hint', 'Updated elements take the new geometry and IFC properties; their classifications, custom properties, marks and graphics stay yours.'),
  );
  const r = await openDialog({ title: 'Update with IFC Model', body, actions: [{ label: 'Cancel', value: null }, { label: 'Update', primary: true, value: 'ok' }] });
  if (r !== 'ok') return;
  let out;
  app.commit('Update with IFC model', () => (out = updateFromIFC(app.doc, text, { apply: true, removeGone: remove.checked, name: f.name })));
  toast(`Updated ${out.updated.length}, added ${out.added.length}${remove.checked ? `, removed ${out.gone.length}` : ''}.`, { kind: 'success' });
  if (out.gone.length && !remove.checked) app.select(out.gone);
}

export function exportPropertyValues(app) {
  const rows = propertyTable(app.doc);
  if (rows.length < 2) return toast('No elements with properties to export.', { kind: 'error' });
  const bytes = writeXLSX([{ name: 'Property Values', rows: rows.map((cells, i) => ({ cells, bold: i === 0 })), widths: rows[0].map((h) => Math.max(12, String(h).length + 2)) }]);
  download(new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), `${app.doc.project?.name || 'Project'} property values.xlsx`);
  toast(`Exported the values of ${rows.length - 1} elements. Edit them and bring them back with Import Property Values.`, { kind: 'success' });
}

export async function importPropertyValues(app) {
  const f = await pickFile('.xlsx,.csv');
  if (!f) return;
  let rows;
  try {
    rows = /\.csv$/i.test(f.name) ? parseCSV(await f.text()) : await readXLSX(new Uint8Array(await f.arrayBuffer()));
  } catch (err) {
    return toast(`That file could not be read: ${err.message || err}`, { kind: 'error' });
  }
  let out;
  app.commit('Import property values', () => (out = applyPropertyTable(app.doc, rows)));
  const extra = [out.unknownRows ? `${out.unknownRows} rows matched no element` : '', out.unknownColumns.length ? `columns not known: ${out.unknownColumns.join(', ')}` : '', out.errors.length ? `${out.errors.length} values not valid (first: row ${out.errors[0].row}, ${out.errors[0].column}: ${out.errors[0].message})` : ''].filter(Boolean);
  toast(`Updated ${out.updated} elements.${extra.length ? ` ${extra.join('; ')}.` : ''}`, { kind: out.errors.length ? 'info' : 'success' });
}
