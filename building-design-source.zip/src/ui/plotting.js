/**
 * File menu: Plot Setup and Plot (HP-GL/2 plot files for roll plotters,
 * core/hpgl.js), the Drawing Manager (every drawing on the layouts and its
 * state) and the Action Center (warnings, model quality, libraries,
 * performance, file and links in one place).
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { plotDrawing } from '../io/exporters.js';
import { writeHPGL, PLOT_DEFAULTS, ROLLS, plotRotated } from '../core/hpgl.js';
import { drawingsList, performance, libraryIssues } from '../core/diagnostics.js';
import { modelWarnings } from '../core/warnings.js';
import { physicalQuality } from '../core/modelquality.js';
import { linkedFile } from '../io/filelinks.js';
import { linkState, LINK_LABEL } from '../core/xrefs.js';
import { VIEW_LABEL } from '../core/doc.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const plotSetup = (app) => ({ ...PLOT_DEFAULTS, ...(app.settings.plot || {}) });

export function plotSetupDialog(app, then = null) {
  const s = plotSetup(app);
  const roll = h('select.input', { 'aria-label': 'Roll width' }, ROLLS.map((r) => h('option', { value: r.value }, r.label)));
  roll.value = String(s.roll);
  const rotate = h('select.input', { 'aria-label': 'Rotate' }, [['auto', 'To fit the roll'], ['never', 'Never'], ['always', 'Always']].map(([v, l]) => h('option', { value: v }, l)));
  rotate.value = s.rotate;
  const margin = h('input.input', { type: 'number', value: s.margin, min: 0, step: 1, 'aria-label': 'Margin' });
  const copies = h('input.input', { type: 'number', value: s.copies, min: 1, step: 1, 'aria-label': 'Copies' });
  const penIns = s.pens.map((p) => {
    const i = h('input.input.sm', { type: 'number', step: 0.01, value: p.upTo >= 99 ? '' : p.upTo, placeholder: 'thicker', 'aria-label': `Pen ${p.pen} up to`, style: { width: '80px' } });
    return { pen: p.pen, i };
  });
  for (const x of [margin, copies, ...penIns.map((p) => p.i)]) x.addEventListener('keydown', (e) => e.stopPropagation());
  const read = () => ({ roll: +roll.value, rotate: rotate.value, margin: Math.max(0, +margin.value || 0), copies: Math.max(1, +copies.value || 1), pens: penIns.map((p) => ({ pen: p.pen, upTo: p.i.value === '' ? 99 : +p.i.value })) });
  return openDialog({
    title: 'Plot Setup',
    size: 'md',
    body: h(
      'div',
      h('div.row2', field('Paper roll', roll), field('Rotate', rotate), field('Margin (mm)', margin), field('Copies', copies)),
      h('h3.dlg-sub', 'Pens by line width'),
      h('table.layers-table', h('tbody', penIns.map((p) => h('tr', h('td', `Pen ${p.pen}`), h('td', 'lines up to'), h('td', p.i), h('td', 'mm'))))),
      h('p.field-hint', 'Plot writes an HP-GL/2 file (.plt) that roll plotters take directly (or through their print queue).'),
    ),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: then ? 'Plot' : 'OK',
        primary: true,
        onClick: () => {
          app.settingsStore.set('plot', read());
          if (then) then();
          return true;
        },
      },
    ],
  });
}

/** Plot: the open view or layout as an HP-GL/2 file. */
export function plot(app) {
  const d = plotDrawing(app);
  if (!d) return toast('Open a layout, plan, section or elevation to plot it.', { kind: 'error' });
  const s = plotSetup(app);
  const r = writeHPGL(d, s);
  const across = r.width;
  if (across > s.roll + 0.5) toast(`The sheet is ${Math.round(across)} mm across: wider than the ${s.roll} mm roll.`, { kind: 'info' });
  const name = app.activeView?.name || app.doc.project.name || 'Plot';
  download(new Blob([r.text], { type: 'application/vnd.hp-HPGL' }), `${safeFileName(name)}.plt`);
  toast(`Plot file for a ${s.roll} mm roll: ${Math.round(r.length)} mm long${r.rotated ? ', turned a quarter' : ''}.`, { kind: 'success' });
}

export function plotDialog(app) {
  const d = plotDrawing(app);
  if (!d) return toast('Open a layout, plan, section or elevation to plot it.', { kind: 'error' });
  const s = plotSetup(app);
  toast(`${Math.round(d.w)} × ${Math.round(d.h)} mm on the ${s.roll} mm roll${plotRotated(s, d.w, d.h) ? ' (turned)' : ''}.`);
  return plotSetupDialog(app, () => plot(app));
}

export async function drawingManagerDialog(app) {
  const doc = app.doc;
  const body = h('div');
  const render = async () => {
    const list = drawingsList(doc);
    const rows = [];
    for (const d of list) {
      let status = d.status === 'auto' ? 'Updates by itself' : d.status === 'missing' ? 'Source view deleted' : '';
      if (d.kind === 'external') {
        const el = doc.get(d.id);
        status = LINK_LABEL[linkState(el, el.linked ? await linkedFile(el.extLink) : null)];
      }
      rows.push(
        h(
          'tr',
          h('td', d.number ? `${d.number} ` : '', d.name),
          h('td', d.kind === 'external' ? 'External drawing' : VIEW_LABEL[d.sourceKind] || d.sourceKind || '—'),
          h('td', d.source),
          h('td', d.layout),
          h('td', d.scale),
          h('td', { class: d.status === 'missing' ? 'warn' : '' }, status),
          h(
            'td',
            h(
              'span.inline',
              { style: { gap: '4px' } },
              d.sourceId ? h('button.btn.sm', { type: 'button', onClick: () => (body.closest('dialog')?._close(null), app.openView(d.sourceId)) }, 'Open Source') : null,
              d.layoutId ? h('button.btn.sm', { type: 'button', onClick: () => (body.closest('dialog')?._close(null), app.openView(d.layoutId), app.select([d.id])) }, 'Go to Layout') : null,
              d.kind === 'external' ? h('button.btn.sm', { type: 'button', onClick: async () => (await app.run('updateExternalDrawings', null), app.select([d.id]), render()) }, 'Update') : null,
            ),
          ),
        ),
      );
    }
    body.replaceChildren(
      rows.length ? h('div', { style: { maxHeight: '60vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', ...['Drawing', 'Type', 'Source', 'Layout', 'Scale', 'Status', ''].map((x) => h('th', x)))), h('tbody', rows))) : h('p.field-hint', 'No drawings are placed on layouts yet.'),
      h('p.field-hint', 'Drawings of views follow their views as they change; external drawings are read again from their files with Update.'),
    );
  };
  await render();
  return openDialog({ title: 'Drawing Manager', size: 'lg', body, actions: [{ label: 'Close', value: null }] });
}

export async function actionCenterDialog(app) {
  const doc = app.doc;
  const ws = modelWarnings(doc, app.scene);
  let quality = [];
  try {
    quality = physicalQuality(doc, app.scene);
  } catch {
    quality = [];
  }
  const libs = libraryIssues(doc);
  const perf = performance(doc, app.scene);
  const links = [];
  for (const x of [...doc.all('xref'), ...doc.all('image').filter((i) => i.extLink)]) {
    const st = linkState(x, x.linked ? await linkedFile(x.extLink || x.id) : null);
    if (st !== 'current') links.push(`${x.name}: ${LINK_LABEL[st]}`);
  }
  for (const l of doc.all('link')) if (!l.embedded && !l.doc) links.push(`${l.name || 'Hotlink'}: not loaded`);
  const kb = (n) => `${Math.round(n / 1024).toLocaleString()} KB`;
  const sec = (title, n, lines, action) =>
    h(
      'section.ac-section',
      h('h3.dlg-sub', `${title} `, h('span.badge', { class: n ? 'warn' : 'ok' }, n ? String(n) : '✓')),
      lines.length ? h('ul.find-list', lines.slice(0, 8).map((t) => h('li', t))) : h('p.field-hint', 'Nothing to report.'),
      action || null,
    );
  const open = (label, cmd) => h('button.btn.sm', { type: 'button', onClick: (e) => (e.currentTarget.closest('dialog')?._close(null), app.run(cmd)) }, label);
  const fileLines = [
    doc.modified ? 'There are unsaved changes.' : 'All changes are saved.',
    app.file?.name ? `File: ${app.file.name} (${app.file.source || 'this browser'})` : 'Not saved to a file yet: the project lives in this browser\'s recovery store.',
  ];
  const body = h(
    'div',
    sec('Warnings', ws.length, ws.map((w) => w.message), open('Show All Warnings', 'warnings')),
    sec('Physical model quality', quality.length, quality.map((q) => q.message), open('Open Model Quality', 'physicalQuality')),
    sec('Libraries', libs.length, libs.map((l) => `${l.name}: ${l.problem}`), open('Library Manager', 'objectLibrary')),
    sec('Links and external content', links.length, links, open('Xref Manager', 'xrefManager')),
    sec(
      'Performance',
      perf.triangles > 2e6 ? 1 : 0,
      [`${perf.elements.toLocaleString()} elements, ${Math.round(perf.triangles).toLocaleString()} triangles in 3D, ${kb(perf.pictures)} of pictures in the project.`, ...perf.heaviest.slice(0, 5).map((x) => `${x.kind} ${x.id}: ${x.triangles.toLocaleString()} triangles`)],
      perf.heaviest.length ? h('button.btn.sm', { type: 'button', onClick: () => app.showElements(perf.heaviest.slice(0, 5).map((x) => x.id)) }, 'Show the Heaviest') : null,
    ),
    sec('File', doc.modified ? 1 : 0, fileLines, doc.modified ? open('Save', 'save') : null),
  );
  return openDialog({ title: 'Action Center', size: 'lg', body, actions: [{ label: 'Close', value: null }] });
}
