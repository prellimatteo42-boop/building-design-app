/**
 * Fire Safety Report (Codice di prevenzione incendi): the activity classified from the model, the performance levels
 * of S.1 to S.10 (and V.5 for accommodation), the checks the model allows, downloaded as Markdown or HTML (to print).
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { fireReport, fireReportMarkdown, fireReportHTML } from '../core/firereport.js';
import { RVITA } from '../core/egress.js';
import { download } from '../io/storage.js';

const STATUS = { ok: ['Compliant', '#1f9d55'], ko: ['Not compliant', '#d03030'], check: ['To check', '#a16207'] };

export async function fireReportDialog(app) {
  const doc = app.doc;
  const prof = h('select.input', { 'aria-label': 'Rvita profile' }, Object.keys(RVITA).map((k) => h('option', { value: k, selected: k === (doc.project.egressProfile || 'Ciii2') }, k)));
  const rbeni = h('select.input', { 'aria-label': 'Rbeni' }, [1, 2, 3, 4].map((k) => h('option', { value: k }, String(k))));
  const act = h('select.input', { 'aria-label': 'Activity' }, [['auto', 'From the beds in the model'], ['V.5', 'Accommodation (V.5)'], ['RTO', 'Horizontal rule only']].map(([v, l]) => h('option', { value: v }, l)));
  const out = h('div', { style: 'max-height:56vh;overflow:auto' });
  let rep = null;
  const run = () => {
    rep = fireReport(doc, app.scene, { profile: prof.value, rbeni: +rbeni.value, activity: act.value });
    const d = rep.data;
    const n = (s) => rep.checks.filter((c) => c.status === s).length;
    out.replaceChildren(
      h('p', `${d.activity}. ${d.beds} beds (${d.P}), highest floor ${d.hMax.toFixed(2)} m (${d.H}), ${d.occTot} occupants. Checks: ${n('ok')} compliant, ${n('ko')} not compliant, ${n('check')} to check.`),
      h('table.vg-table', [
        h('thead', h('tr', h('th', 'Measure'), h('th', 'Performance Level'), h('th', 'Model Check'), h('th', 'Result'))),
        h('tbody', ...rep.measures.flatMap((m) => (m.checks.length ? m.checks : [{ text: '', status: '' }]).map((c, i) => h('tr',
          h('td', i ? '' : `${m.code} ${m.title}`), h('td', i ? '' : m.level), h('td', { title: c.detail || '' }, c.text),
          h('td', { style: `color:${STATUS[c.status]?.[1] || 'inherit'};white-space:nowrap` }, STATUS[c.status]?.[0] || ''))))),
      ]),
      ...(n('ko') ? [h('h4', 'Not compliant'), h('ul', ...rep.checks.filter((c) => c.status === 'ko').map((c) => h('li', `${c.code} ${c.text}: ${c.detail}`)))] : []),
    );
  };
  for (const s of [prof, rbeni, act]) s.addEventListener('change', run);
  run();
  const base = (doc.project.name || 'progetto').replace(/[^\w\- ]+/g, '').trim() || 'progetto';
  return openDialog({
    title: 'Fire Safety Report (fire code)',
    size: 'lg',
    body: h('div', h('div', { style: 'display:flex;gap:12px;flex-wrap:wrap' }, h('label.field', h('span', 'Reference Rvita'), prof), h('label.field', h('span', 'Rbeni'), rbeni), h('label.field', h('span', 'Activity'), act)), out),
    actions: [
      { label: 'Download Markdown', onClick: () => (download(new Blob([fireReportMarkdown(rep)], { type: 'text/markdown' }), `${base} - relazione antincendio.md`), false) },
      { label: 'Download HTML (print to PDF)', onClick: () => (download(new Blob([fireReportHTML(rep)], { type: 'text/html' }), `${base} - relazione antincendio.html`), false) },
      { label: 'Close', primary: true, value: null },
    ],
  });
}
