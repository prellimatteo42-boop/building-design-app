/**
 * Commands behind Archicad menu items the app could already do in part: closing the view tab, Go to Story,
 * showing and hiding the palettes (Toolbox, Info Box, Status bar, Coordinates), Autogroup and Magic Wand Settings.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { WAND } from '../core/convert.js';
import { Tool } from '../editor/tool.js';

export function closeTab(app) {
  const id = app.activeViewId;
  if (!id) return app.toast('No view is open.', { kind: 'error' });
  app.closeView(id);
}

export function goToStory(app) {
  const levels = app.doc.levels().slice().reverse();
  const body = h(
    'div.list',
    ...levels.map((l) =>
      h('button.btn', {
        type: 'button',
        style: { display: 'block', width: '100%', textAlign: 'left', marginBottom: '4px' },
        onClick: (e) => {
          e.currentTarget.closest('dialog')?.dispatchEvent(new Event('cancel'));
          const plan = app.doc.all('plan').find((p) => p.levelId === l.id);
          if (plan) app.openView(plan.id);
        },
      }, `${l.name}  (${Math.round(l.elevation)} mm)`),
    ),
  );
  return openDialog({ title: 'Go to Story', body, actions: [{ label: 'Close', value: null }] });
}

/** The palettes of Archicad's Window > Palettes that the workspace has, by setting key. */
const PALETTES = {
  hideToolbox: (app) => app.workspace?.toolbox,
  hideInfoBox: (app) => app.workspace?.infobox,
  hideStatusbar: (app) => app.shell?.root?.querySelector('.statusbar'),
  hideCoordinates: (app) => app.shell?.coords,
};

export function applyPalettes(app) {
  if (!app.workspace?.on) return;
  for (const [key, get] of Object.entries(PALETTES)) {
    const el = get(app);
    if (el) el.hidden = !!app.settings[key];
  }
  app.shell?.root?.classList.toggle('ac-no-toolbox', !!app.settings.hideToolbox);
  app.viewport?.resize?.();
}

export function togglePalette(app, key) {
  app.settingsStore.set(key, !app.settings[key]);
  applyPalettes(app);
}

export const paletteShown = (app, key) => !app.settings[key];

export function toggleAutogroup(app) {
  app.settingsStore.set('autogroup', !app.settings.autogroup);
  app.toast(app.settings.autogroup ? 'Autogroup on: elements made in one go (Multiply) are grouped.' : 'Autogroup off.');
}

export function magicWandSettings(app) {
  const s = { ...WAND, ...(app.settings.magicWand || {}) };
  const arc = h('input.input', { type: 'number', min: 1, max: 45, step: 1, value: s.arcStep, 'aria-label': 'Degrees per piece' });
  const spl = h('input.input', { type: 'number', min: 2, max: 32, step: 1, value: s.splineSteps, 'aria-label': 'Pieces per spline span' });
  for (const i of [arc, spl]) i.addEventListener('keydown', (e) => e.stopPropagation());
  const body = h(
    'div',
    h('label.field', h('span.field-label', 'Arcs and circles: degrees of arc per straight piece'), arc),
    h('label.field', h('span.field-label', 'Splines: straight pieces per span'), spl),
    h('p.field-hint', 'The Magic Wand (Space and click with a polygon tool) follows curves with straight pieces this fine.'),
  );
  return openDialog({ title: 'Magic Wand Settings', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const next = { arcStep: Math.max(1, Math.min(45, +arc.value || 10)), splineSteps: Math.max(2, Math.min(32, Math.round(+spl.value) || 8)) };
    app.settingsStore.set('magicWand', next);
    Object.assign(WAND, next);
  });
}

/** Settings that take effect when the app starts. */
export function applyExtrasAtStart(app) {
  Object.assign(WAND, app.settings.magicWand || {});
  applyPalettes(app);
}

/** Show/Hide Splitter: the traced reference shows only on one side of a line you move across the view. */
class SplitTool extends Tool {
  get title() {
    return 'Trace Splitter';
  }

  get prompt() {
    return 'Move the splitter across the view, click to leave it there';
  }

  move(ev) {
    const w = this.app.viewport?.width || 1;
    this.app.tracePalette.set({ split: Math.max(0, Math.min(1, ev.x / w)) });
    this.app.flagsVersion++;
  }

  down() {
    this.app.cancelTool();
  }
}

export function toggleSplitter(app) {
  const t = app.traces?.get(app.activeViewId);
  if (t?.split != null) {
    app.tracePalette.set({ split: null });
    app.flagsVersion++;
    return;
  }
  if (!t?.on) app.tracePalette.set({ on: true });
  app.tracePalette.set({ split: 0.5 });
  app.flagsVersion++;
  app.setTool(new SplitTool(app));
}
