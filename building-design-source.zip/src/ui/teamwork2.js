/** Teamwork menu: change tracking, review of the selection, messages, compare around a sync, reservations. */
import { h } from './dom.js';
import { openDialog, toast, confirmDialog } from './dialog.js';
import { newId } from '../core/doc.js';
import { syncLog } from '../io/sync.js';

const closeOnly = [{ label: 'Close', value: null }];
const table = (head, rows) => h('div', { style: { maxHeight: '50vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', head.map((c) => h('th', c)))), h('tbody', rows)));
const time = (t) => new Date(t).toLocaleString();
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

function changeRows(app, ids) {
  return app.changeLog.list(ids).slice(0, 1000).map((e) =>
    h('tr', h('td', time(e.at)), h('td', e.who), h('td', e.action), h('td', e.name || e.kind), h('td', app.doc.has(e.id) ? h('button.btn.sm', { type: 'button', onClick: () => app.select([e.id]) }, 'Select') : '')),
  );
}

const HEAD = ['When', 'Who', 'Change', 'Element', ''];

/** Change Tracking: everything changed since the project was opened. */
export function changeTracking(app) {
  const rows = changeRows(app, null);
  return openDialog({ title: 'Change Tracking', size: 'lg', body: rows.length ? table(HEAD, rows) : h('p.field-hint', 'Nothing has changed since this project was opened.'), actions: [{ label: 'Close', value: null }, { label: 'Clear', onClick: () => (app.changeLog.clear(), toast('Change list cleared.'), true) }] });
}

/** Review Selected Elements: the changes to the selection. */
export function reviewSelected(app) {
  if (!app.selection.size) return toast('Select the elements to review.');
  const rows = changeRows(app, [...app.selection]);
  return openDialog({ title: `Changes to ${plural(app.selection.size, 'element')}`, size: 'lg', body: rows.length ? table(HEAD, rows) : h('p.field-hint', 'No changes to these elements since the project was opened.'), actions: closeOnly });
}

/** Messages: notes between the people on a project, kept in it. */
export function messagesDialog(app) {
  const doc = app.doc;
  const me = app.user?.username || 'Me';
  const list = h('div', { style: { maxHeight: '45vh', overflow: 'auto', minHeight: '100px' } });
  const render = () => {
    const all = doc.all('message').sort((a, b) => a.at - b.at);
    list.replaceChildren(...(all.length ? all.map((m) => h('p', h('strong', m.by), ` ${time(m.at)}${m.to ? ` to ${m.to}` : ''}: ${m.text}`)) : [h('p.field-hint', 'No messages yet.')]));
  };
  render();
  const to = h('input.input', { placeholder: 'To (everyone if empty)', 'aria-label': 'To', style: { maxWidth: '200px' } });
  const text = h('input.input', { placeholder: 'Message', 'aria-label': 'Message' });
  for (const i of [to, text]) i.addEventListener('keydown', (e) => e.stopPropagation());
  const send = () => {
    const t = text.value.trim();
    if (!t) return false;
    const m = { id: newId('msg'), kind: 'message', by: me, at: Date.now(), text: t, to: to.value.trim() || null };
    // Outside the undo history, and its own item so that messages never conflict.
    doc.applyRemote([[m.id, m]], 'Message');
    text.value = '';
    render();
    return false;
  };
  return openDialog({ title: 'Messages', body: h('div', list, h('div.inline', { style: { gap: '6px', marginTop: '8px' } }, to, text)), actions: [{ label: 'Close', value: null }, { label: 'Send', primary: true, onClick: send }] });
}

/** Sync, comparing with the project as it stood just before. */
export async function syncThenCompare(app) {
  if (!(await app.requireShared())) return;
  const c = app.comparePalette;
  c.baseline();
  await app.sync.sync();
  if (!c.el) c.toggle();
  c.run();
}

/** Receive then Compare: bring in others' changes only, and compare. */
export async function receiveThenCompare(app) {
  if (!(await app.requireShared())) return;
  const c = app.comparePalette;
  c.baseline();
  await app.sync.pull();
  if (!c.el) c.toggle();
  c.run();
}

/** Leave Teamwork Project: stop working on the shared copy; what is open stays as a local one. */
export async function leaveProject(app) {
  if (!app.sync.active) return toast('This project is not shared.');
  if (!(await confirmDialog('Leave the shared project?', 'What you have open stays, as your own copy. It no longer exchanges changes with the others.', { confirm: 'Leave' }))) return;
  app.sync.detach();
  toast('You have left the shared project.');
}

/** Teamwork palette: who is on the project and what is reserved. */
export function teamworkPalette(app) {
  const doc = app.doc;
  const me = app.userTag();
  const box = h('div');
  const render = () => {
    const users = [...new Set([me, ...syncLog(doc).map((e) => e.by)])];
    const reserved = [...doc.items.values()].filter((e) => e.reservedBy);
    box.replaceChildren(
      h('p', app.sync.active ? `Shared project. State: ${app.sync.state}.` : 'This project is not shared.'),
      table(['Person', 'Reserved'], users.map((u) => h('tr', h('td', u === me ? `${u} (you)` : u), h('td', String(reserved.filter((e) => e.reservedBy === u).length))))),
      h('div.inline', { style: { gap: '6px', marginTop: '8px' } },
        h('button.btn.sm', { type: 'button', onClick: () => (setReserved(app, [...app.selection], me), render()) }, 'Reserve Selection'),
        h('button.btn.sm', { type: 'button', onClick: () => (setReserved(app, [...app.selection], null), render()) }, 'Release Selection'),
        h('button.btn.sm', { type: 'button', onClick: () => (setReserved(app, reserved.filter((e) => e.reservedBy === me).map((e) => e.id), null), render()) }, 'Release All Mine'),
      ),
    );
  };
  render();
  return openDialog({ title: 'Teamwork', body: box, actions: closeOnly });
}

function setReserved(app, ids, who) {
  const doc = app.doc;
  const mine = ids.filter((id) => doc.has(id) && (!doc.get(id).reservedBy || doc.get(id).reservedBy === app.userTag()));
  if (!mine.length) return toast('Select elements that nobody else has reserved.');
  app.commit(who ? 'Reserve' : 'Release', () => mine.forEach((id) => doc.update(id, { reservedBy: who })));
  toast(`${plural(mine.length, 'element')} ${who ? 'reserved' : 'released'}.`);
}
