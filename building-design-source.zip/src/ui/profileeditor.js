/**
 * Profile Editor window (Archicad's, reimplemented): a complex profile drawn
 * on a grid. Tools: Edit (drag a vertex; click an edge to put a vertex on it;
 * Alt+click a vertex to remove it), Shape (click the corners, click the first
 * again or double-click to close), Hole (the same, inside the chosen shape).
 * The chosen shape takes a building material. Save writes the profile.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { snapTo, vertexAt, edgeAt, moveVertex, insertVertex, removeVertex, signedArea } from '../core/profileedit.js';

const SVG = 'http://www.w3.org/2000/svg';
const svg = (tag, attrs = {}) => {
  const el = document.createElementNS(SVG, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  return el;
};

export function profileEditorWindow(app, id = null) {
  const doc = app.doc;
  const prof = doc.get(id) || doc.all('profile')[0];
  if (!prof) return toast('There are no complex profiles yet: make one in the Profile Manager.', { kind: 'error' });
  let shapes = structuredClone(prof.shapes || []);
  let tool = 'edit';
  let chosen = 0;
  let drawing = null; // points of the outline being drawn
  let drag = null;
  let step = 10;
  const W = 720;
  const H = 460;
  // View box in mm round the profile.
  const fit = () => {
    const pts = shapes.flatMap((s) => [...s.poly, ...(s.holes || []).flat()]);
    const xs = pts.map((p) => p[0]);
    const ys = pts.map((p) => p[1]);
    const x0 = pts.length ? Math.min(...xs) : 0;
    const x1 = pts.length ? Math.max(...xs) : 500;
    const y0 = pts.length ? Math.min(...ys) : 0;
    const y1 = pts.length ? Math.max(...ys) : 500;
    const pad = Math.max(50, (x1 - x0 + y1 - y0) * 0.15);
    const w = Math.max(x1 - x0 + 2 * pad, ((y1 - y0 + 2 * pad) * W) / H);
    const hh = (w * H) / W;
    return { x: (x0 + x1) / 2 - w / 2, y: (y0 + y1) / 2 - hh / 2, w, h: hh };
  };
  let box = fit();
  const root = svg('svg', { width: '100%', viewBox: `0 0 ${W} ${H}`, class: 'pe-svg', role: 'img', 'aria-label': 'Profile drawing', style: 'background: var(--surface-2, #f7f7f5); border-radius: 6px; touch-action: none; cursor: crosshair' });
  const toPx = (p) => [((p[0] - box.x) / box.w) * W, H - ((p[1] - box.y) / box.h) * H];
  const toMm = (e) => {
    const r = root.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * W;
    const py = ((e.clientY - r.top) / r.height) * H;
    return [box.x + (px / W) * box.w, box.y + ((H - py) / H) * box.h];
  };
  const tol = () => (box.w / W) * 8;
  const coords = h('span.field-hint');
  const draw = () => {
    root.replaceChildren();
    // Grid every `step` (thinned when dense), axes at 0.
    const g = step > 0 && box.w / step < 160 ? step : step * Math.ceil(box.w / step / 160);
    if (g > 0)
      for (let x = Math.ceil(box.x / g) * g; x < box.x + box.w; x += g) {
        const [px] = toPx([x, 0]);
        root.append(svg('line', { x1: px, y1: 0, x2: px, y2: H, stroke: x === 0 ? '#c66' : '#e3e3df', 'stroke-width': x === 0 ? 1.2 : 0.6 }));
      }
    if (g > 0)
      for (let y = Math.ceil(box.y / g) * g; y < box.y + box.h; y += g) {
        const [, py] = toPx([0, y]);
        root.append(svg('line', { x1: 0, y1: py, x2: W, y2: py, stroke: y === 0 ? '#c66' : '#e3e3df', 'stroke-width': y === 0 ? 1.2 : 0.6 }));
      }
    shapes.forEach((s, si) => {
      const d = [s.poly, ...(s.holes || [])].map((loop) => `M${loop.map((p) => toPx(p).join(',')).join('L')}Z`).join('');
      root.append(svg('path', { d, fill: doc.get(s.materialId)?.color || '#bbb', 'fill-opacity': 0.75, 'fill-rule': 'evenodd', stroke: si === chosen ? '#d35400' : '#333', 'stroke-width': si === chosen ? 2 : 1 }));
      for (const loop of [s.poly, ...(s.holes || [])]) for (const p of loop) root.append(svg('circle', { cx: toPx(p)[0], cy: toPx(p)[1], r: 3.5, fill: '#fff', stroke: '#333' }));
    });
    if (drawing?.length) {
      root.append(svg('polyline', { points: drawing.map((p) => toPx(p).join(',')).join(' '), fill: 'none', stroke: '#3d7fc4', 'stroke-width': 2, 'stroke-dasharray': '4 3' }));
      for (const p of drawing) root.append(svg('circle', { cx: toPx(p)[0], cy: toPx(p)[1], r: 3.5, fill: '#3d7fc4' }));
    }
    renderSide();
  };
  const close = () => {
    if (!drawing || drawing.length < 3) return;
    const loop = drawing.slice();
    drawing = null;
    if (tool === 'hole' && shapes[chosen]) {
      // Holes run clockwise.
      const hole = signedArea(loop) > 0 ? loop.reverse() : loop;
      shapes = shapes.map((s, i) => (i === chosen ? { ...s, holes: [...(s.holes || []), hole] } : s));
    } else {
      shapes = [...shapes, { poly: signedArea(loop) < 0 ? loop.reverse() : loop, holes: [], materialId: shapes[chosen]?.materialId || 'mat-concrete' }];
      chosen = shapes.length - 1;
    }
    draw();
  };
  root.addEventListener('pointerdown', (e) => {
    const p = toMm(e);
    if (tool === 'edit') {
      const v = vertexAt(shapes, p, tol());
      if (v && e.altKey) {
        shapes = removeVertex(shapes, v);
        return draw();
      }
      if (v) {
        chosen = v.shape;
        drag = v;
        root.setPointerCapture(e.pointerId);
        return draw();
      }
      const ed = edgeAt(shapes, p, tol());
      if (ed) {
        shapes = insertVertex(shapes, ed, snapTo(ed.at, step));
        chosen = ed.shape;
        drag = { shape: ed.shape, loop: ed.loop, index: ed.index + 1 };
        root.setPointerCapture(e.pointerId);
        return draw();
      }
      // Click inside a shape chooses it.
      const hit = shapes.findIndex((s) => inside(p, s.poly));
      if (hit >= 0) (chosen = hit), draw();
      return;
    }
    const q = snapTo(p, step);
    if (drawing?.length >= 3 && Math.hypot(q[0] - drawing[0][0], q[1] - drawing[0][1]) <= tol()) return close();
    drawing = [...(drawing || []), q];
    draw();
  });
  root.addEventListener('dblclick', () => close());
  root.addEventListener('pointermove', (e) => {
    const p = snapTo(toMm(e), step);
    coords.textContent = `x ${Math.round(p[0])}  y ${Math.round(p[1])} mm`;
    if (drag) {
      shapes = moveVertex(shapes, drag, p);
      draw();
    }
  });
  root.addEventListener('pointerup', () => (drag = null));
  const side = h('div.pe-side');
  const renderSide = () => {
    const s = shapes[chosen];
    const mat = h('select.input', { 'aria-label': 'Material of the chosen shape' }, doc.all('material').map((m) => h('option', { value: m.id }, m.name)));
    if (s) mat.value = s.materialId;
    mat.addEventListener('change', () => ((shapes = shapes.map((x, i) => (i === chosen ? { ...x, materialId: mat.value } : x))), draw()));
    const toolBtn = (v, label) => h('button.seg-btn', { type: 'button', role: 'radio', 'aria-checked': String(tool === v), onClick: () => ((tool = v), (drawing = null), draw()) }, label);
    const stepIn = h('input.input', { type: 'number', min: 0, step: 1, value: step, 'aria-label': 'Grid step', style: { width: '80px' } });
    stepIn.addEventListener('keydown', (e) => e.stopPropagation());
    stepIn.addEventListener('change', () => ((step = Math.max(0, +stepIn.value || 0)), draw()));
    side.replaceChildren(
      h('div.seg', { role: 'radiogroup', 'aria-label': 'Tool' }, toolBtn('edit', 'Edit'), toolBtn('shape', 'Shape'), toolBtn('hole', 'Hole')),
      h('p.field-hint', tool === 'edit' ? 'Drag a corner; click an edge to add a corner; Alt+click a corner to remove it; click a shape to choose it.' : 'Click the corners; click the first one again or double-click to close.'),
      h('label.field', h('span.field-label', s ? `Shape ${chosen + 1} material` : 'Material'), mat),
      h('label.field', h('span.field-label', 'Grid step (mm)'), stepIn),
      h('div.inline', { style: { gap: '6px' } }, h('button.btn.sm', { type: 'button', onClick: () => ((box = fit()), draw()) }, 'Fit'), h('button.btn.sm', { type: 'button', disabled: !s || shapes.length < 2, onClick: () => ((shapes = shapes.filter((_, i) => i !== chosen)), (chosen = 0), draw()) }, 'Delete Shape')),
      coords,
    );
  };
  draw();
  return openDialog({
    title: `Profile Editor: ${prof.name}`,
    size: 'lg',
    body: h('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 210px', gap: '12px' } }, root, side),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'Save',
        primary: true,
        onClick: () => {
          if (!shapes.length) {
            toast('A profile needs at least one shape.', { kind: 'error' });
            return false;
          }
          app.commit('Edit profile', () => doc.update(prof.id, { shapes }));
          return true;
        },
      },
    ],
  });
}

function inside(p, poly) {
  let r = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const c = poly[j];
    if (a[1] > p[1] !== c[1] > p[1] && p[0] < ((c[0] - a[0]) * (p[1] - a[1])) / (c[1] - a[1]) + a[0]) r = !r;
  }
  return r;
}
