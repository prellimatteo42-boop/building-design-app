/**
 * The assistant: a side panel where you ask about the project or ask for
 * changes in plain words. It answers through Claude (assistant/claude.js):
 * with an API key it runs the functions in assistant/tools.js itself; with
 * Claude Code, Claude Code runs them through the MCP bridge and their steps
 * show up here. Every change is an ordinary undo step.
 */
import { uiLanguage } from './aclang.js';
import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { toolSchemas, runTool, resultContent, placeUnderlay } from '../assistant/tools.js';
import { imageForClaude, loadImage } from '../assistant/images.js';
import { askClaude, askClaudeCode, aiBackend, setBrowserKey, messageText } from '../assistant/claude.js';

const SUGGESTIONS = ['What can you do for me?', 'Check the model for problems', 'Make an oak wardrobe with 3 doors, 240 x 60 x 230', 'Furnish a bedroom from the libraries', 'Make a door schedule sorted by level'];
const SUGGESTIONS_IT = ['Cosa puoi fare per me?', 'Controlla se nel modello ci sono problemi', 'Disegna un armadio in rovere a 3 ante, 240 x 60 x 230', 'Arreda una camera con gli oggetti delle librerie', 'Fai un abaco delle porte per piano'];
const MAX_ROUNDS = 24;

const SYSTEM = `You are the assistant inside Building Design, a browser BIM app. The user models buildings with walls, doors, windows, floors, roofs, rooms, levels, views, schedules and sheets.
Use the functions to look at the project before answering questions about it, and to make the changes the user asks for. Lengths are millimetres in function calls; in your answers use the project's units.
Be brief and concrete. Say what you changed. If a request is unclear or would delete or replace a lot, ask first. Almost every app command (tools, dialogs, display, Archicad features such as Roof Framing, Sun Study, Magic Wand tools) can be found with search_commands and run with run_command; selection with get_selection and select_elements; classification, favorites, layers and layer combinations, a plan's cut plane and a view's phase have their own functions. Properties: property_groups and property_definitions manage custom properties, get_property_values and set_property_values read and write them, find_by_criteria finds elements by their values and can store them as a named element list (element_lists) for later calls; graphic_overrides, classifications, keynotes, views (navigator, view settings, view templates) and attribute_search cover the matching Archicad managers. When you cannot do something with your functions, say which tool in the app does it (for example "Architecture tab > Roof").
Answer in the language the user writes in.
Furniture and interiors: the Archicad object libraries come first. Call library_load once, then library_search for each piece (bed, nightstand, wardrobe, carpet, curtain, desk lamp...), library_preview to choose the closest one by looking at them, object_parameters for its materials, and place_objects with the whole list in one call, each with its ref, its size and its materials in values (a piece next_to another, chairs around a table). Search in English too, under more than one word: a rug is Carpet, curtains are Curtain, a table lamp is Desk Lamp or Nightstand Lamp, a bedside table Nightstand, a closet Wardrobe. Objects come plain: switch on in values what you see, such as pillows on a bed. A placement warning about size means the object takes it from its own options: set them. Compare what you wrote with the library preview. A bed on legs is not one on a solid base, a table on a drum is not one on four legs, a unit with two handleless drawers and a gap between them is not a plain box, an open lit closet is not one with doors. If no library has the piece, or the closest one differs like that, make it with make_furniture and keep it in the user's library (keep: true with words in Italian and English in place_objects, or add_to_library), so that next time it is found like the others; never say the libraries lack something you did not search for; never ask for details you can choose sensibly. In your answer, say which pieces come from the libraries and which you made. After placing, read each warning, check once with look_at_view giving room, and move what overlaps. A room you build gets a floor, and no ceiling unless asked. Leave nothing selected when you finish.
A photo of a room (not a plan): 1) look at it with view_image, read the pixels of the far wall's corners and of something of known size (a double bed is 1.6 x 2.0 m, a door 0.8 m wide and 2.1 m high, a chair seat 0.45 m high), and call measure_photo: use its numbers for the room and the camera rather than guessing. Call north the wall you face in the photo, so that it is at the top of the plan. 2) Build walls, doors and windows where you see them, the floor, and a ceiling at the height you see. 3) set_finish with the colours you read from the photo, as #rrggbb: the walls, the ceiling, the floor (pattern planks for boards, in the direction you see them run). 4) Before choosing any piece, zoom on it with view_image and write down what makes it that piece: what it stands on (four tapered legs, a solid base, one stem, a drum), its front (how many drawers, shadow gaps, handles or none, doors, glass, open shelves), what is inside and whether it is lit, what each part is made of. Then furnish from the libraries as said above, in one place_objects call, each piece at the size you see and with the colours of the photo in its material parameters. A painting is always made here, with make_furniture kind picture and from_image, so that it is that painting. Then the small things that make the room: books, a tray, a vase, shoes, clothes, sockets and switches (wall_plate), recessed spots and strips of light in the ceiling (cove_light), each where you see it, set with on when it stands on something. Put each piece where it is in the photo, not just somewhere along its wall. 5) set_camera where the photo was taken from and compare the picture you get with the photo: proportions, positions, colours, and each piece against what you wrote about it. Fix what differs and look again, twice at most. 6) Delete the photo from the plan with remove_elements. The camera view stays open: it is what the user sees. In your answer, say which sizes you estimated and what you could not reproduce. Report only what a function confirmed: a field it lists as ignored had no effect.
Any element the other functions do not cover: add_elements.
To model a floor plan from a picture or PDF (attached files are placed as underlays): 1) look at it with view_image, zooming into regions to read dimensions and room names; if it is a photo taken at an angle, straighten_image first; 2) calibrate_image: for a PDF page that states its scale (1:N), with scale N; otherwise with the two ends of the longest dimension you can read (or a door of known width); 3) model_from_image, which makes the walls, doors, windows and zones from the picture by itself; 4) compare with the picture (view_image, room_areas, and look_at_view to see the plan and the 3D you made): name and number each zone from what you read (set_parameters), and add or fix what it missed with trace_floor_plan (walls as centre lines from corner to corner with their thickness, doors and windows on their walls with their widths, rooms at a point inside with their names); 5) check model_warnings. Use full-image pixel coordinates throughout. For a file on this computer (DWG, DXF, IFC, PDF or picture), model_from_file does all of it in one step.`;

export class Assistant {
  constructor(app, root) {
    this.app = app;
    this.root = root;
    this.messages = [];
    this.busy = false;
    this.render();
  }

  render() {
    clear(this.root);
    this.log = h('div.as-log', { role: 'log', 'aria-live': 'polite' });
    this.input = h('textarea.input.as-input', { rows: 2, placeholder: 'Ask about the project, or ask for a change', 'aria-label': 'Message to the assistant' });
    this.input.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.send();
      }
    });
    const sendBtn = h('button.icon-btn.as-send', { type: 'button', 'aria-label': 'Send', 'data-tip': 'Send (Enter)', onClick: () => this.send() }, icon('send', 16));
    const file = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp,image/gif,application/pdf,.pdf', hidden: true });
    file.addEventListener('change', () => {
      for (const f of file.files || []) this.attach(f);
      file.value = '';
    });
    const attachBtn = h('button.icon-btn.as-attach', { type: 'button', 'aria-label': 'Attach a floor plan image or PDF', 'data-tip': 'Attach an image or PDF (or paste an image)', onClick: () => file.click() }, icon('imageImport', 16));
    this.input.addEventListener('paste', (e) => {
      const imgs = [...(e.clipboardData?.files || [])].filter((f) => f.type.startsWith('image/'));
      if (!imgs.length) return;
      e.preventDefault();
      imgs.forEach((f) => this.attach(f));
    });
    this.attachments = [];
    this.chips = h('div.as-attachments');
    this.root.append(
      h('div.pane-head', h('h2.pane-title', { id: 'assist-title' }, icon('sparkles', 15), ' Assistant'), h('span.grow'), h('button.icon-btn.sm', { type: 'button', 'aria-label': 'New conversation', 'data-tip': 'New conversation', onClick: () => this.reset() }, icon('plus', 15)), h('button.icon-btn.sm', { type: 'button', 'aria-label': 'Hide the assistant', 'data-tip': 'Hide', onClick: () => this.app.toggleAssistant(false) }, icon('x', 15))),
      this.log,
      this.chips,
      h('div.as-compose', attachBtn, this.input, sendBtn, file),
      h('p.as-note', 'Answers come from an AI model and can be wrong. Its changes can be undone.'),
    );
    this.welcome();
  }

  welcome() {
    const it = uiLanguage(this.app.settings) === 'it';
    this.log.append(
      h('div.as-msg.as-bot', it ? 'Posso rispondere sul progetto e lavorarci: modellare da PDF, DWG, immagini e foto, disegnare mobili su misura, arredare con le librerie, fare abachi, tavole e controlli.' : 'I can answer questions about this project and work on it: model from PDFs, DWGs, pictures and photos, make furniture to measure, furnish from the libraries, make schedules and sheets, and check the model.'),
      h('div.as-suggest', (it ? SUGGESTIONS_IT : SUGGESTIONS).map((s) => h('button.as-chip', { type: 'button', onClick: () => this.send(s) }, icon('corner-down-right', 13), s))),
    );
  }

  reset() {
    this.messages = [];
    this.session = null;
    clear(this.log);
    this.welcome();
  }

  /** A step taken on the project, shown before the "thinking" dots if a turn is under way. */
  logStep(text, failed = false) {
    const step = h('div.as-step', icon(failed ? 'warning' : 'check', 13), text);
    this.log.insertBefore(step, this.log.querySelector('.as-wait'));
    this.log.scrollTop = this.log.scrollHeight;
  }

  add(cls, ...children) {
    const el = h(`div.as-msg.${cls}`, ...children);
    this.log.append(el);
    this.log.scrollTop = this.log.scrollHeight;
    return el;
  }

  /** Add an image file to the next message. */
  attach(f) {
    if (f.type === 'application/pdf' || /\.pdf$/i.test(f.name)) return this.attachPDF(f);
    if (!f.type.startsWith('image/')) return;
    if (f.size > 12e6) return this.app.toast('That image is larger than 12 MB. Please use a smaller one.', { kind: 'error' });
    const reader = new FileReader();
    reader.onload = async () => {
      const src = String(reader.result);
      try {
        const pic = await loadImage(src);
        this.attachments.push({ name: f.name, src, px: [pic.naturalWidth, pic.naturalHeight] });
        this.renderChips();
      } catch {
        this.app.toast('That file could not be read as an image.', { kind: 'error' });
      }
    };
    reader.readAsDataURL(f);
  }

  /** A PDF: its first pages, each as a picture with its paper size. */
  async attachPDF(f) {
    if (f.size > 40e6) return this.app.toast('That PDF is larger than 40 MB.', { kind: 'error' });
    try {
      const { pdfPagePictures } = await import('../assistant/pdfpages.js');
      const pages = await pdfPagePictures(new Uint8Array(await f.arrayBuffer()));
      for (const p of pages) this.attachments.push({ name: `${f.name} - page ${p.page}`, src: p.src, px: p.px, pageMm: p.pageMm });
      this.renderChips();
    } catch (err) {
      this.app.toast(`That PDF could not be read: ${err.message || err}`, { kind: 'error' });
    }
  }

  renderChips() {
    clear(this.chips);
    this.attachments.forEach((a, i) =>
      this.chips.append(h('span.as-chip-file', h('img', { src: a.src, alt: '' }), h('span', a.name), h('button.icon-btn.sm', { type: 'button', 'aria-label': `Remove ${a.name}`, onClick: () => (this.attachments.splice(i, 1), this.renderChips()) }, icon('x', 12)))),
    );
  }

  /**
   * Place the attached pictures as underlays and say so: content blocks for
   * the API (the pictures themselves) and a note for the text.
   */
  async takeAttachments() {
    const list = this.attachments.splice(0);
    this.renderChips();
    const blocks = [];
    const notes = [];
    for (const a of list) {
      const el = placeUnderlay(this.app, { src: a.src, name: a.name, px: a.px, pageMm: a.pageMm, at: [blocks.length * 25000, 0] });
      const pic = await imageForClaude(a.src);
      blocks.push({ type: 'image', source: { type: 'base64', media_type: pic.media_type, data: pic.data } });
      const paper = a.pageMm ? ` A PDF page of ${Math.round(a.pageMm[0])} x ${Math.round(a.pageMm[1])} mm: if it states its scale 1:N, calibrate_image with scale N.` : '';
      notes.push(el ? `[Attached "${a.name}": placed as image ${el.id} in ${this.app.doc.get(el.viewId)?.name}, ${a.px[0]} x ${a.px[1]} px, not calibrated.${paper} Shown here at ${pic.width} x ${pic.height}: multiply by ${Math.round(pic.factor * 1000) / 1000} for full-image pixels.]` : `[Attached "${a.name}": no plan view to place it in.]`);
    }
    return { blocks, note: notes.join('\n'), shown: list };
  }

  /** No AI is reachable: in the packaged app the user can give their own Claude API key here. */
  askForKey() {
    const key = h('input.input', { type: 'password', autocomplete: 'off', placeholder: 'Your API key', 'aria-label': 'Claude API key' });
    const status = h('div.as-note');
    const save = h('button.btn.primary', {
      type: 'button',
      onClick: async () => {
        let res = null;
        try {
          res = await fetch('./api/app-key', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: key.value }) });
        } catch {
          res = null;
        }
        // On a plain website there is no server to keep it: this browser keeps it.
        if (!res || res.status === 404 || res.status === 405 || !/json/.test(res.headers.get('content-type') || '')) {
          if (!/^sk-[a-z]+-[\w-]{8,}$/.test(key.value.trim())) {
            status.textContent = 'That does not look like a Claude API key.';
            return;
          }
          setBrowserKey(key.value.trim());
        } else {
          const out = await res.json().catch(() => ({}));
          if (!res.ok) {
            status.textContent = out.error || 'The key was not saved.';
            return;
          }
        }
        this.backend = 'api';
        key.value = '';
        status.textContent = 'Saved on this computer only. Ask again.';
      },
    }, 'Save');
    this.add('as-bot', h('div', 'The assistant needs a Claude API key of your own, from console.anthropic.com. It stays on this computer.'), h('div.row2', key, save), status);
  }

  async send(text = this.input.value) {
    const q = String(text || '').trim() || (this.attachments.length ? 'Model this floor plan.' : '');
    if (!q || this.busy) return;
    this.input.value = '';
    this.log.querySelector('.as-suggest')?.remove();
    const att = this.attachments.length ? await this.takeAttachments() : null;
    this.add('as-user', q, ...(att?.shown || []).map((a) => h('img.as-thumb', { src: a.src, alt: a.name })));
    this.busy = true;
    const thinking = this.add('as-bot.as-wait', h('span.as-dots', h('span'), h('span'), h('span')));
    this.backend ??= await aiBackend();
    if (this.backend === 'none') {
      thinking.remove();
      this.busy = false;
      this.askForKey();
      return;
    }
    if (this.backend === 'claude-code') {
      try {
        const message = att ? `${q}\n${att.note.replace(/Shown here[^\]]*/g, 'Call view_image to see it.')}` : q;
        const res = await askClaudeCode({ system: SYSTEM, message, session: this.session });
        this.session = res.session;
        thinking.remove();
        this.add('as-bot', ...formatAnswer(res.text || 'Done.'));
      } catch (err) {
        thinking.remove();
        this.add('as-bot.as-err', `Something went wrong: ${err?.message || err}`);
      } finally {
        this.busy = false;
        this.input.focus();
      }
      return;
    }
    this.messages.push({ role: 'user', content: att ? [...att.blocks, { type: 'text', text: `${q}\n${att.note}` }] : q });
    try {
      for (let round = 0; round < MAX_ROUNDS; round++) {
        const res = await askClaude({ system: SYSTEM, messages: this.messages, tools: toolSchemas() });
        if (res.stop_reason === 'refusal') {
          thinking.remove();
          this.add('as-bot.as-err', 'The AI declined this request. Try asking in a different way.');
          break;
        }
        // The whole reply goes back next round, thinking included, as the API expects.
        this.messages.push({ role: 'assistant', content: res.content });
        const calls = res.content.filter((b) => b.type === 'tool_use');
        const cut = res.stop_reason === 'max_tokens';
        if (!calls.length || cut) {
          // A call cut off mid-way is not run, but still needs its answer.
          if (calls.length) this.messages.push({ role: 'user', content: calls.map((c) => ({ type: 'tool_result', tool_use_id: c.id, content: 'Not run: the reply was cut off.', is_error: true })) });
          thinking.remove();
          this.add('as-bot', ...formatAnswer(messageText(res) || (cut ? 'The answer was too long and got cut off.' : 'Done.')));
          break;
        }
        // All of this round's results go back together in one message.
        const results = [];
        for (const c of calls) {
          const result = await runTool(this.app, c.name, c.input);
          this.log.insertBefore(h('div.as-step', icon(result?.error ? 'warning' : 'check', 13), describeStep(c.name, c.input, result)), thinking);
          results.push({ type: 'tool_result', tool_use_id: c.id, content: resultContent(result), ...(result?.error ? { is_error: true } : {}) });
        }
        this.messages.push({ role: 'user', content: results });
      }
    } catch (err) {
      thinking.remove();
      this.add('as-bot.as-err', `Something went wrong: ${err?.message || err?.error?.message || err}`);
    } finally {
      thinking.remove();
      this.busy = false;
      this.input.focus();
      this.settleCamera();
    }
  }

  /** The view the assistant stood a camera in is what the user is left looking at, from that camera. */
  settleCamera() {
    const app = this.app;
    const id = app.cameraViewId;
    app.cameraViewId = null;
    const view = id && app.doc.get(id);
    if (!view?.camera) return;
    app.openView(id);
    if (!app.vc) return;
    app.vc.cam = structuredClone(view.camera);
    app.vc.userMoved = true;
    app.requestRender();
  }
}

export function describeStep(name, input, result) {
  const label = {
    project_summary: 'Looked at the project',
    find_elements: `Searched ${input.kind || 'elements'}${input.level ? ` on ${input.level}` : ''}`,
    room_areas: 'Measured rooms',
    get_element: 'Read an element',
    set_parameters: `Changed ${result?.changed ?? 0} element${result?.changed === 1 ? '' : 's'}`,
    select_elements: `Selected ${result?.selected ?? 0} element${result?.selected === 1 ? '' : 's'}`,
    open_view: `Opened ${result?.opened || input.name}`,
    create_schedule: `Created ${result?.created || 'a schedule'}`,
    create_level: `Created ${result?.created || 'a level'}`,
    create_walls: `Drew ${result?.created ?? 0} wall${result?.created === 1 ? '' : 's'}`,
    model_warnings: 'Checked the model',
    list_images: 'Listed the images',
    view_image: `Looked at the image${input.region ? ' (detail)' : ''}`,
    calibrate_image: `Calibrated the image${result?.mmPerPixel ? ` (${result.mmPerPixel} mm per pixel)` : ''}`,
    trace_floor_plan: `Traced ${result?.walls ?? 0} walls, ${result?.doors ?? 0} doors, ${result?.windows ?? 0} windows, ${result?.rooms?.length ?? 0} rooms`,
    import_floor_plan_image: result?.lines != null ? `Imported ${result.lines} lines from the PDF` : 'Placed the floor plan image',
    convert_lines: `Made ${result?.made ?? 0} elements from lines`,
    run_command: `Ran ${result?.ran || input.command}`,
    search_commands: `Looked up commands for "${input.query}"`,
    get_selection: `Read the selection (${result?.count ?? 0})`,
    classify_elements: result?.classified != null ? `Classified ${result.classified} element${result.classified === 1 ? '' : 's'}` : 'Looked up classifications',
    favorites: input.action === 'apply' ? `Applied favorite ${input.name}` : input.action === 'save' ? `Saved favorite ${input.name}` : 'Listed the favorites',
    layers: input.action === 'list' ? 'Listed the layers' : input.action === 'apply_combination' ? `Applied layer combination ${input.combination}` : input.action === 'store_combination' ? `Stored layer combination ${input.combination}` : `Changed layer ${input.layer}`,
    set_view_range: 'Set the view range',
    set_view_phase: 'Set the view phase',
  }[name] || name;
  return result?.error ? `${label}: ${result.error}` : label;
}

const plain = (t) => t.replace(/\*\*(.+?)\*\*/g, '$1');

/** Plain text with paragraphs, simple bullet lists and pipe tables. */
export function formatAnswer(text) {
  const out = [];
  let list = null;
  let table = null;
  for (const line of String(text).split('\n')) {
    if (/^\s*\|.*\|\s*$/.test(line)) {
      list = null;
      const cells = line.trim().slice(1, -1).split('|').map((c) => plain(c.trim()));
      if (cells.every((c) => /^:?-{2,}:?$/.test(c))) continue;
      if (!table) {
        out.push(h('table.as-table', h('thead', h('tr', cells.map((c) => h('th', c))))));
        table = h('tbody');
        out.at(-1).append(table);
      } else table.append(h('tr', cells.map((c) => h('td', c))));
      continue;
    }
    table = null;
    const m = /^\s*(?:[-*•]|\d+[.)])\s+(.*)$/.exec(line);
    if (m) {
      if (!list) out.push((list = h('ul.as-list')));
      list.append(h('li', plain(m[1])));
    } else {
      list = null;
      if (line.trim()) out.push(h('p', plain(line)));
    }
  }
  return out;
}
