/**
 * Fly-through palette: cameras of the 3D view's path (recorded from the
 * view, or walked along a path selected in plan), played back smoothly and
 * recorded as a WebM video of the 3D window.
 */
import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { toast } from './dialog.js';
import { cameraAt, pathCameras } from '../core/flythrough.js';
import { download } from '../io/storage.js';

export class FlyPalette {
  constructor(app) {
    this.app = app;
    this.el = null;
    this.seconds = 10;
    this.playing = null;
  }

  toggle() {
    if (this.el) return this.close();
    this.el = h('section.quick-layers.fly-palette', { role: 'dialog', 'aria-label': 'Fly-through' });
    document.body.append(this.el);
    this.render();
  }

  close() {
    this.stop();
    this.el?.remove();
    this.el = null;
  }

  /** The 3D view the path belongs to: the active one, or the first. */
  view3d() {
    const v = this.app.activeView;
    return v?.kind === 'view3d' ? v : this.app.doc.all('view3d')[0] || null;
  }

  cams() {
    return this.view3d()?.flyCameras || [];
  }

  setCams(list, label) {
    const v = this.view3d();
    if (!v) return;
    this.app.commit(label, () => this.app.doc.update(v.id, { flyCameras: list }));
    this.render();
  }

  addCurrent() {
    const c = this.app.vc;
    if (this.app.activeView?.kind !== 'view3d' || !c?.cam?.target) return toast('Open the 3D view and frame the shot to add a camera.', { kind: 'error' });
    this.setCams([...this.cams(), structuredClone(c.cam)], 'Add fly-through camera');
  }

  fromPath() {
    const doc = this.app.doc;
    const el = [...this.app.selection].map((id) => doc.get(id)).find((e) => e && (e.kind === 'spline' || e.kind === 'detailLine' || e.kind === 'modelLine'));
    if (!el) return toast('Select a spline or line drawn in a plan as the path to walk.', { kind: 'error' });
    const pts = el.kind === 'spline' ? el.path : [el.a, el.b];
    const levelId = el.levelId || doc.get(el.viewId)?.levelId;
    const z = (doc.get(levelId)?.elevation ?? 0) + 1600;
    const cams = pathCameras(pts, z, { closed: !!el.closed });
    if (!cams.length) return toast('That path is too short.', { kind: 'error' });
    if (!this.view3d()) this.app.open3D();
    this.setCams(cams, 'Fly-through from path');
    toast(`${cams.length} cameras along the path, at eye height.`, { kind: 'success' });
  }

  /** Play the path in the 3D view; resolves when done. */
  play() {
    const cams = this.cams();
    if (cams.length < 2) return Promise.resolve(toast('Add at least two cameras.', { kind: 'error' }));
    const v = this.view3d();
    this.app.openView(v.id);
    this.stop();
    const ms = Math.max(1, this.seconds) * 1000;
    if ((this.u || 0) >= 1) this.u = 0;
    const start = performance.now() - (this.u || 0) * ms;
    // A timer rather than animation frames, so playback keeps time even when the window is not painting.
    return new Promise((resolve) => {
      const step = () => {
        const u = (performance.now() - start) / ms;
        this.u = Math.min(1, u);
        const c = this.app.vc;
        if (c?.is3D) {
          c.cam = { ...c.cam, ...cameraAt(cams, Math.min(1, u)) };
          this.app.viewport.render();
        }
        if (u < 1 && this.playing) this.playing = setTimeout(step, 1000 / 30);
        else {
          this.playing = null;
          this.render();
          resolve();
        }
      };
      this.playing = setTimeout(step, 0);
      this.render();
    });
  }

  /** Stop where it is; Play carries on from there. */
  pause() {
    if (this.playing) clearTimeout(this.playing);
    this.playing = null;
    this.render();
  }

  /** Stand the 3D view at a place on the path, 0 to 1. */
  seek(u) {
    this.pause();
    this.u = Math.max(0, Math.min(1, u));
    const cams = this.cams();
    const v = this.view3d();
    if (cams.length < 2 || !v) return;
    if (this.app.activeView?.id !== v.id) this.app.openView(v.id);
    const c = this.app.vc;
    if (c?.is3D) {
      c.cam = { ...c.cam, ...cameraAt(cams, this.u) };
      this.app.viewport.render();
    }
  }

  /** One frame on or back (30 frames a second). */
  stepFrame(n) {
    this.seek((this.u || 0) + n / (Math.max(1, this.seconds) * 30));
  }

  stop() {
    if (this.playing) clearTimeout(this.playing);
    this.playing = null;
    this.recorder?.state === 'recording' && this.recorder.stop();
  }

  async record() {
    const canvas = this.app.viewport.canvas;
    if (!canvas.captureStream || typeof MediaRecorder === 'undefined') return toast('This browser cannot record video.', { kind: 'error' });
    if (this.cams().length < 2) return toast('Add at least two cameras.', { kind: 'error' });
    const stream = canvas.captureStream(30);
    const type = ['video/webm;codecs=vp9', 'video/webm'].find((t) => MediaRecorder.isTypeSupported(t)) || '';
    const rec = new MediaRecorder(stream, type ? { mimeType: type, videoBitsPerSecond: 8e6 } : {});
    this.recorder = rec;
    const chunks = [];
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    const done = new Promise((r) => (rec.onstop = r));
    rec.start();
    await this.play();
    if (rec.state === 'recording') rec.stop();
    await done;
    this.recorder = null;
    download(new Blob(chunks, { type: 'video/webm' }), `${this.app.doc.project?.name || 'Fly-through'}.webm`);
    toast('Video saved.', { kind: 'success' });
  }

  render() {
    const el = this.el;
    if (!el) return;
    clear(el);
    const n = this.cams().length;
    el.append(h('div.ql-head', h('span.ql-title', icon('view3d', 15), 'Fly-through'), h('button.icon-btn.sm', { type: 'button', 'aria-label': 'Close Fly-through', onClick: () => this.close() }, icon('x', 14))));
    const secs = h('input.input.sm', { type: 'number', min: 2, max: 600, step: 1, value: this.seconds, 'aria-label': 'Duration in seconds' });
    secs.addEventListener('keydown', (e) => e.stopPropagation());
    secs.addEventListener('change', () => (this.seconds = Math.max(2, +secs.value || 10)));
    const btn = (label, ic, fn, disabled = false) => h('button.btn.sm', { type: 'button', disabled, onClick: fn }, icon(ic, 14), h('span', label));
    el.append(
      h('p.field-hint', n ? `${n} camera${n === 1 ? '' : 's'} in ${this.view3d()?.name}.` : 'No cameras yet. Frame a shot in 3D and add it, or select a path drawn in a plan.'),
      h('div.ql-actions', btn('Add Current View', 'plus', () => this.addCurrent()), btn('From Selected Path', 'arc', () => this.fromPath()), btn('Remove Last', 'trash', () => this.setCams(this.cams().slice(0, -1), 'Remove fly-through camera'), !n), btn('Clear', 'x', () => this.setCams([], 'Clear fly-through'), !n)),
      h('label.field', h('span.field-label', 'Duration (seconds)'), secs),
      h('div.ql-actions', this.playing ? btn('Stop', 'x', () => this.stop()) : btn('Play', 'eye', () => this.play(), n < 2), btn('Record Video', 'download', () => this.record(), n < 2 || !!this.playing)),
    );
  }
}
