/**
 * Commands for Parapet Dimensions, Secondary Dimensions and Reference
 * Levels (the logic is in core/dimextras.js and core/coords.js).
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { formatLength, parseLength } from '../core/units.js';
import { parapetOptions, placeParapetDims, removeParapetDims, SECONDARY_UNITS, convertDimensions, refreshConverted, removeConverted, referenceLevels, shownReference } from '../core/dimextras.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const stop = (i) => (i.addEventListener('keydown', (e) => e.stopPropagation()), i);
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

function planView(app) {
  const v = app.activeView;
  if (v?.kind !== 'plan') {
    app.toast('Open a floor plan first.', { kind: 'error' });
    return null;
  }
  return v;
}

const selectedIds = (app) => (app.selection.size ? [...app.selection] : null);

/** Parapet Dimensions > Create: options, then a text with the sill height by each window (and door) of the story. */
export function createParapetDims(app) {
  const v = planView(app);
  if (!v) return;
  const o = parapetOptions(app.doc.project);
  const prefix = stop(h('input.input', { type: 'text', value: o.prefix, 'aria-label': 'Prefix' }));
  const sel = (items, cur, label) => h('select.input', { 'aria-label': label }, ...items.map(([value, text]) => h('option', { value, selected: value === cur }, text)));
  const from = sel([['story', 'The story (floor level)'], ['wall', 'The wall base']], o.from, 'Measured from');
  const side = sel([['interior', 'Room side'], ['exterior', 'Outside']], o.side, 'Side');
  const doors = h('input', { type: 'checkbox', checked: !!o.doors });
  const n = selectedIds(app)?.filter((id) => ['window', 'door'].includes(app.doc.get(id)?.kind)).length || 0;
  const body = h(
    'div',
    h('div.row2', field('Prefix', prefix), field('Measured from', from)),
    h('div.row2', field('Placed on', side), h('label.check', { style: { alignSelf: 'end' } }, doors, 'Doors too')),
    h('p.field-hint', n ? `For the ${plural(n, 'selected opening')}.` : 'For every window of this story. Select openings first to dimension only those. Refresh rewrites them after the model changes.'),
  );
  return openDialog({ title: 'Parapet Dimensions', body, actions: [{ label: 'Cancel', value: null }, { label: 'Create', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const opts = { prefix: prefix.value.trim(), from: from.value, side: side.value, doors: doors.checked };
    let res;
    app.commit('Parapet dimensions', () => {
      app.doc.update('project', { parapetDims: opts });
      res = placeParapetDims(app.doc, v, app.doc.units, { ids: n ? selectedIds(app) : null, opts });
    });
    app.toast(res.added + res.updated ? `Parapet dimensions: ${res.added} placed, ${res.updated} updated.` : 'No windows on this story.', { kind: res.added + res.updated ? 'success' : 'error' });
  });
}

export function refreshParapetDims(app) {
  const v = planView(app);
  if (!v) return;
  let res;
  app.commit('Refresh parapet dimensions', () => (res = placeParapetDims(app.doc, v, app.doc.units, { opts: parapetOptions(app.doc.project), refresh: true })));
  app.toast(`Parapet dimensions: ${res.updated} refreshed${res.removed ? `, ${res.removed} removed (their openings are gone)` : ''}.`);
}

export function removeParapets(app) {
  const v = planView(app);
  if (!v) return;
  let n = 0;
  app.commit('Remove parapet dimensions', () => (n = removeParapetDims(app.doc, v, selectedIds(app))));
  app.toast(`Removed ${plural(n, 'parapet dimension')}.`);
}

/** Secondary Dimensions > Convert: the unit and decimals, then a second value under each dimension segment. */
export function convertDims(app) {
  const v = app.activeView;
  if (!v) return;
  const o = app.toolOptions('secondaryDims', { unit: app.doc.units?.system === 'imperial' ? 'm' : 'ftin', decimals: 2 });
  const unit = h('select.input', { 'aria-label': 'Unit' }, ...SECONDARY_UNITS.map((u) => h('option', { value: u.value, selected: u.value === o.unit }, u.label)));
  const dec = stop(h('input.input', { type: 'number', min: 0, max: 64, step: 1, value: o.decimals, 'aria-label': 'Decimals' }));
  const ids = selectedIds(app)?.filter((id) => app.doc.get(id)?.kind === 'dimension');
  const body = h(
    'div',
    h('div.row2', field('Unit', unit), field('Decimals', dec, 'For feet & inches: the inch fraction (8 = 1/8")')),
    h('p.field-hint', ids?.length ? `For the ${plural(ids.length, 'selected dimension')}.` : 'For every dimension in this view. The values are text blocks: Refresh Converted Dimensions updates them after changes.'),
  );
  return openDialog({ title: 'Convert Dimensions', body, actions: [{ label: 'Cancel', value: null }, { label: 'Convert', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    o.unit = unit.value;
    o.decimals = +dec.value || 0;
    let n = 0;
    app.commit('Convert dimensions', () => (n = convertDimensions(app.doc, v, { ids: ids?.length ? ids : null, unit: o.unit, decimals: o.decimals })));
    app.toast(n ? `Placed ${plural(n, 'converted value')}.` : 'No dimensions to convert in this view.', { kind: n ? 'success' : 'error' });
  });
}

export function refreshConvertedDims(app) {
  const v = app.activeView;
  if (!v) return;
  let n = 0;
  app.commit('Refresh converted dimensions', () => (n = refreshConverted(app.doc, v, selectedIds(app))));
  app.toast(`Refreshed ${plural(n, 'converted value')}.`);
}

export function removeConvertedDims(app) {
  const v = app.activeView;
  if (!v) return;
  let n = 0;
  app.commit('Remove converted dimensions', () => (n = removeConverted(app.doc, v, selectedIds(app))));
  app.toast(`Removed ${plural(n, 'converted value')}.`);
}

/** Project Preferences > Reference Levels: names and heights of the two reference levels. */
export function referenceLevelsDialog(app) {
  const u = app.doc.units;
  const refs = referenceLevels(app.doc.project);
  const rows = refs.map((r, i) => ({
    name: stop(h('input.input', { type: 'text', value: r.name, 'aria-label': `Name ${i + 1}` })),
    z: stop(h('input.input', { type: 'text', value: formatLength(r.elevation, u), 'aria-label': `Height ${i + 1}` })),
  }));
  const body = h(
    'div',
    ...rows.map((r, i) => h('div.row2', field(`${i === 0 ? '1st' : '2nd'} reference level`, r.name), field('Height from project zero', r.z))),
    h('p.field-hint', 'Spot elevations can read from these, and the element settings show bottom and top elevations to the one chosen with 1st / 2nd Reference Level.'),
  );
  return openDialog({ title: 'Reference Levels', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const next = rows.map((row, i) => {
      const z = parseLength(row.z.value, u);
      return { name: row.name.value.trim() || refs[i].name, elevation: Number.isFinite(z) ? z : refs[i].elevation };
    });
    app.commit('Reference levels', () => app.doc.update('project', { referenceLevels: next }));
    app.requestRender();
  });
}

export function setShownReference(app, which) {
  app.commit(`${which === 2 ? '2nd' : '1st'} reference level`, () => app.doc.update('project', { shownReference: which }));
  app.toast(`Elevations in the element settings now read from ${referenceLevels(app.doc.project)[which - 1].name}.`);
  app.requestRender();
}

export const isShownReference = (app, which) => shownReference(app.doc.project) === which;
