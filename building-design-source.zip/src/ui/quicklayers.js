/**
 * Quick Layers, as in Archicad: a small floating palette with every layer's
 * visibility, lock and 3D mode (solid or wireframe) as seen in the active view, and one-click commands for
 * the layers of the selection. Touching a layer in a view that follows a
 * layer combination makes the view custom (core/layers.js setLayerState).
 */
import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { layersInOrder, layerState, layerIdOf, setLayerState } from '../core/layers.js';

export class QuickLayers {
  constructor(app) {
    this.app = app;
    this.el = null;
    this.query = '';
  }

  get open() {
    return !!this.el;
  }

  toggle() {
    if (this.el) return this.close();
    this.el = h('section.quick-layers', { role: 'dialog', 'aria-label': 'Quick Layers' });
    document.body.append(this.el);
    this.render();
  }

  close() {
    this.el?.remove();
    this.el = null;
    this.app.ribbon?.refresh();
  }

  /** Layers of the selected elements. */
  selectionLayers() {
    const doc = this.app.doc;
    return [...new Set([...this.app.selection].map((id) => layerIdOf(doc, doc.get(id))).filter(Boolean))];
  }

  set(layerId, patch, label) {
    const app = this.app;
    app.commit(label, () => setLayerState(app.doc, app.activeView, layerId, patch));
  }

  setMany(ids, patch, label) {
    const app = this.app;
    if (!ids.length) return;
    app.commit(label, () => ids.forEach((id) => setLayerState(app.doc, app.doc.get(app.activeViewId), id, patch)));
    if (patch.hidden || patch.locked) app.select([]);
  }

  render() {
    const el = this.el;
    const app = this.app;
    if (!el) return;
    const doc = app.doc;
    clear(el);
    const head = h('div.ql-head', h('span.ql-title', icon('worksets', 15), 'Quick Layers'), h('button.icon-btn.sm', { type: 'button', 'aria-label': 'Close Quick Layers', onClick: () => this.close() }, icon('x', 14)));
    el.append(head);
    if (!doc) return;
    const view = app.activeView;
    const combo = view?.layerComboId ? doc.get(view.layerComboId) : null;
    el.append(h('div.ql-combo', combo ? `Combination: ${combo.name}` : 'Custom layer settings'));
    const search = h('input.input.sm', { type: 'search', placeholder: 'Find layer', value: this.query, 'aria-label': 'Find layer' });
    search.addEventListener('input', () => {
      this.query = search.value.trim().toLowerCase();
      this.renderList(list);
    });
    search.addEventListener('keydown', (e) => e.stopPropagation());
    const list = h('ul.ql-list');
    el.append(search, list);
    this.renderList(list);
    const sel = this.selectionLayers();
    const all = doc.all('layer').map((l) => l.id);
    const btn = (label, tip, ic, onClick, disabled = false) => h('button.btn.sm', { type: 'button', disabled, 'data-tip': tip, onClick }, icon(ic, 14), h('span', label));
    el.append(
      h('div.ql-actions',
        btn('Hide selected', 'Hide the layers of the selected elements', 'eye-off', () => this.setMany(sel, { hidden: true }, 'Hide layer'), !sel.length),
        btn('Lock selected', 'Lock the layers of the selected elements', 'lock', () => this.setMany(sel, { locked: true }, 'Lock layer'), !sel.length),
        btn('Show all', 'Show every layer', 'eye', () => this.setMany(all.filter((id) => layerState(doc, view, id).hidden), { hidden: false }, 'Show all layers')),
        btn('Unlock all', 'Unlock every layer', 'unlock', () => this.setMany(all.filter((id) => layerState(doc, view, id).locked), { locked: false }, 'Unlock all layers')),
      ),
    );
  }

  renderList(list) {
    const app = this.app;
    const doc = app.doc;
    const view = app.activeView;
    const sel = new Set(this.selectionLayers());
    clear(list);
    for (const l of layersInOrder(doc)) {
      if (this.query && !l.name.toLowerCase().includes(this.query)) continue;
      const st = layerState(doc, view, l.id);
      list.append(
        h(`li.ql-row${sel.has(l.id) ? '.ql-sel' : ''}`,
          h('button.icon-btn.sm', { type: 'button', 'aria-pressed': String(!st.hidden), 'aria-label': `${st.hidden ? 'Show' : 'Hide'} ${l.name}`, onClick: () => this.set(l.id, { hidden: !st.hidden }, st.hidden ? 'Show layer' : 'Hide layer') }, icon(st.hidden ? 'eye-off' : 'eye', 14)),
          h('button.icon-btn.sm', { type: 'button', 'aria-pressed': String(st.locked), 'aria-label': `${st.locked ? 'Unlock' : 'Lock'} ${l.name}`, onClick: () => this.set(l.id, { locked: !st.locked }, st.locked ? 'Unlock layer' : 'Lock layer') }, icon(st.locked ? 'lock' : 'unlock', 14)),
          h('button.icon-btn.sm', { type: 'button', 'aria-pressed': String(st.wireframe), 'aria-label': `${l.name} as ${st.wireframe ? 'solid' : 'wireframe'} in 3D`, 'data-tip': st.wireframe ? '3D: wireframe' : '3D: solid', onClick: () => this.set(l.id, { wireframe: !st.wireframe }, 'Layer 3D mode') }, icon(st.wireframe ? 'styleWire' : 'styleShaded', 14)),
          h(`span.ql-name${st.hidden ? '.ql-off' : ''}`, l.name),
        ),
      );
    }
  }
}
