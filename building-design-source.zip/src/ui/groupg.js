/**
 * Reload Libraries, Set as Source Marker, Reference - As last shown in
 * Active Content, and the Textbox Handles and Stair Landing Calculation
 * Guidelines switches.
 */
import { toast } from './dialog.js';
import { reloadLibraryTypes, setAsSourceMarker } from '../core/libreload.js';

export function reloadLibraries(app) {
  const lib = app.acLibrary;
  if (!lib?.parts?.size) return toast('No Archicad library is loaded: add one in the Library Manager first.', { kind: 'error' });
  // Parts are read again from the loaded files' bytes (the cached readings are dropped).
  for (const e of lib.parts.values()) e.lp = null;
  let res;
  app.commit('Reload libraries', () => (res = reloadLibraryTypes(app.doc, lib)));
  app.scene?.invalidate?.();
  app.requestRender();
  toast(`${res.updated} object type${res.updated === 1 ? '' : 's'} updated from the library${res.missing.length ? `; not found: ${res.missing.slice(0, 5).join(', ')}${res.missing.length > 5 ? '…' : ''}` : ''}.`, { kind: res.missing.length ? 'info' : 'success' });
}

export function sourceMarker(app) {
  const id = [...app.selection].find((x) => app.doc.get(x)?.kind === 'viewRef');
  if (!id) return toast('Select a linked view marker.', { kind: 'error' });
  try {
    let msg;
    app.commit('Set as source marker', () => (msg = setAsSourceMarker(app.doc, id)));
    toast(msg, { kind: 'success' });
  } catch (err) {
    toast(err.message || String(err), { kind: 'error' });
  }
}

export function referenceLastShown(app) {
  const id = app.lastFlatViewId;
  if (!id || !app.doc.get(id) || id === app.activeViewId) return toast('No other drawing was shown before this one.', { kind: 'error' });
  app.tracePalette.set({ refId: id, on: true });
  toast(`Reference: ${app.doc.get(id).name}.`);
}

export function toggle(app, key) {
  app.settingsStore.set(key, !app.settings[key]);
  app.requestRender();
}
