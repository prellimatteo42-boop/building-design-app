/** The Archicad workspace in Italian: menus, Toolbox, Info Box and Navigator, under the names Italian Archicad users know. */
import IT from './ac-labels-it.json';
import UI from './ui-labels-it.json';

const EXTRA = {
  Select: 'Selezione',
  Viewpoint: 'Punto di Vista',
  Document: 'Documento',
  Design: 'Disegno',
  Layer: 'Lucido',
  'Reference Line Location': 'Posizione Linea di Riferimento',
  'Geometry Method': 'Metodo Geometrico',
  'Bottom and Top': 'Base e Cima',
  Structure: 'Struttura',
  'Sill or Header Height': 'Altezza Davanzale o Architrave',
  'Wall Thickness': 'Spessore Muro',
  'Thickness': 'Spessore',
  'Dimensions': 'Dimensioni',
  'Anchor Point': 'Punto di Ancoraggio',
  Stories: 'Piani',
  Sections: 'Sezioni',
  Elevations: 'Alzati',
  'Interior Elevations': 'Alzati Interni',
  Worksheets: 'Fogli di Lavoro',
  Details: 'Dettagli',
  '3D Documents': 'Documenti 3D',
  Schedules: 'Abachi',
  Legends: 'Legende',
  'Reflected Ceiling Plans': 'Piante Controsoffitti',
  'Zone Plans': 'Piante Zone',
  'Project Map': 'Mappa Progetto',
  'View Map': 'Mappa Viste',
  'Layout Book': 'Book di Layout',
  'Publisher Sets': 'Set di Publisher',
  Selected: 'Selezionati',
  'Select elements, or choose a tool in the Toolbox.': 'Seleziona gli elementi o scegli uno strumento.',
  'Settings...': 'Impostazioni...',
  Favorites: 'Preferiti',
  'Main:': 'Principale:',
  Guides: 'Guide',
  Grids: 'Griglie',
  'Trace & Reference': 'Sottolucido',
  Measure: 'Misura',
  Groups: 'Gruppi',
  '3D Cutaway - Toolbar': 'Sezione 3D',
  Move: 'Muovi',
  Rotate: 'Ruota',
  Mirror: 'Specchia',
  'Multiply...': 'Moltiplica...',
  '3D View': 'Prospettiva Generica',
  'Project Indexes': 'Indici Progetto',
  Lists: 'Liste',
  Information: 'Informazioni',
  Help: 'Aiuto',
  'Project Notes': 'Note di Progetto',
  Guide: 'Guida',
  'Search Project Map': 'Ricerca Mappa Progetto',
  'Show me how': 'Mostrami come',
  Properties: 'Propriet\u00e0',
  'Settings': 'Impostazioni...',
  Tool: 'Strumento',
  '3D Cutaway of Room': 'Sezione 3D della Stanza',
  'Furnish with the Assistant...': "Arreda con l'Assistente...",
  'Ask the Assistant about This...': "Chiedi all'Assistente...",
  'Ask the Assistant': "Chiedi all'Assistente",
  'This looks like a photo of a room. If it is a plan, import it from the File menu.': 'Sembra la foto di una stanza. Se è una pianta, importala dal menu Archivio.',
  'Select a room with walls round it first.': 'Seleziona prima una stanza con i muri attorno.',
  Assistant: 'Assistente',
  'Ask each time': 'Chiedi ogni volta',
  'My Library': 'La Mia Libreria',
  'My Library...': 'La Mia Libreria...',
  'Add to My Library': 'Aggiungi alla Mia Libreria',
  'Add Selected Object': 'Aggiungi Oggetto Selezionato',
  'Export for Archicad...': 'Esporta per Archicad...',
  Place: 'Posiziona',
  'Objects that the Archicad libraries do not have. They stay in this browser from one project to the next.': 'Oggetti che le librerie di Archicad non hanno. Restano in questo browser da un progetto all\'altro.',
  'Nothing yet. Objects the assistant makes come here, and so does what you add with the button below.': 'Ancora niente. Qui arrivano gli oggetti che crea l\'assistente e quelli che aggiungi con il pulsante qui sotto.',
  'Doors and Windows': 'Porte e Finestre',
  'Furniture and Fittings': 'Arredi e Accessori',
  'Grids and References': 'Griglie e Riferimenti',
  'Site and Landscape': 'Sito e Paesaggio',
  'Slabs and Ceilings': 'Solai e Controsoffitti',
  'Stairs and Railings': 'Scale e Ringhiere',
  'Text and Labels': 'Testi ed Etichette',
  'Zones and Areas': 'Zone e Aree',
  'New Wall': 'Nuovo Muro',
  Custom: 'Personalizzato',
  'Show All': 'Mostra Tutto',
  'Entire Model': 'Modello Intero',
  'Rooms by Name': 'Stanze per Nome',
  'Core of Load-Bearing Elements Only': 'Solo Nucleo degli Elementi Portanti',
  'Black and White': 'Bianco e Nero',
  'Custom (layer settings)': 'Personalizzato (impostazioni lucidi)',
  'View Name': 'Nome Vista',
  'New Construction': 'Nuova Costruzione',
  'Show Complete': 'Mostra Completo',
  'Show New': 'Mostra Nuovo',
  'Show Previous + New': 'Mostra Precedente + Nuovo',
  'Show Previous + Demo': 'Mostra Precedente + Demolizione',
  'Zoom to Fit': 'Adatta alla Finestra',
  Snaps: 'Agganci',
  Color: 'Colore',
  'Model buildings with walls, doors, windows, floors, roofs and more': 'Modella edifici con muri, porte, finestre, solai, tetti e altro',
};

/** 'it' or 'en': the user's choice, else the browser's language. */
export function uiLanguage(settings) {
  const own = settings?.uiLang;
  if (own === 'it' || own === 'en') return own;
  return typeof navigator !== 'undefined' && /^it\b/i.test(navigator.language || '') ? 'it' : 'en';
}

/** A label in the given language; what has no translation stays as it is. */
export function translateLabel(label, lang) {
  if (lang !== 'it' || typeof label !== 'string') return label;
  return EXTRA[label] ?? IT[label] ?? UI[label] ?? label;
}

/** An interface string in Italian, also when it ends in a colon or dots; null when there is no translation. */
export function italianFor(text) {
  const t = EXTRA[text] ?? IT[text] ?? UI[text];
  if (t != null) return t;
  const m = /^(.*?)(:|\.\.\.|\u2026)$/.exec(text);
  if (!m) return null;
  const base = EXTRA[m[1]] ?? IT[m[1]] ?? UI[m[1]];
  return base != null ? base + m[2] : null;
}

// What is the user's or the model's own text, and must stay as written.
const OWN_TEXT = 'canvas, input, textarea, pre, code, [contenteditable], .as-msg, .as-log, .gdl-editor, [data-no-translate]';

function translateText(node) {
  const raw = node.nodeValue;
  const text = raw?.trim();
  if (!text || text.length > 520 || !/[A-Za-z]/.test(text)) return;
  const owner = node.parentElement;
  if (!owner || owner.closest(OWN_TEXT)) return;
  const it = italianFor(text);
  if (it == null || it === text) return;
  // An option with no value of its own has its text as value: the code still has to read the English one.
  if (owner.tagName === 'OPTION' && !owner.hasAttribute('value')) owner.setAttribute('value', text);
  node.nodeValue = raw.replace(text, it);
}

function translateAttributes(el) {
  for (const a of ['title', 'placeholder', 'aria-label', 'data-tip']) {
    const v = el.getAttribute?.(a);
    if (!v) continue;
    const it = italianFor(v.trim());
    if (it != null && it !== v) el.setAttribute(a, it);
  }
}

function translateTree(root) {
  if (root.nodeType === 3) return translateText(root);
  if (root.nodeType !== 1 || root.closest(OWN_TEXT)) return;
  translateAttributes(root);
  const walk = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  for (let n = walk.nextNode(); n; n = walk.nextNode()) {
    if (n.nodeType === 3) translateText(n);
    else translateAttributes(n);
  }
}

/**
 * Keeps everything the program shows in Italian, dialogs included, whatever wrote it. The source stays in English;
 * going back to English takes a reload, as the page has lost its original words by then.
 */
export function translateInterface(isItalian) {
  const run = (list) => {
    if (!isItalian()) return;
    for (const m of list) {
      if (m.type === 'childList') m.addedNodes.forEach(translateTree);
      else if (m.type === 'characterData') translateText(m.target);
      else translateAttributes(m.target);
    }
  };
  new MutationObserver(run).observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['title', 'placeholder', 'aria-label', 'data-tip'] });
  if (isItalian()) translateTree(document.body);
}
