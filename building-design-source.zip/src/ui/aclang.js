/** The Archicad workspace in Italian: menus, Toolbox, Info Box and Navigator, under the names Italian Archicad users know. */
import IT from './ac-labels-it.json';

const EXTRA = {
  Select: 'Selezione',
  Viewpoint: 'Punto di Vista',
  Document: 'Documento',
  Design: 'Disegno',
  Layer: 'Lucido',
  'Reference Line Location': 'Posizione Linea di Riferimento',
  'Geometry Method': 'Metodo Geometrico',
  'Bottom and Top': 'Base e Cima',
  Structure: 'Struttura',
  'Sill or Header Height': 'Altezza Davanzale o Architrave',
  'Wall Thickness': 'Spessore Muro',
  'Thickness': 'Spessore',
  'Dimensions': 'Dimensioni',
  'Anchor Point': 'Punto di Ancoraggio',
  Stories: 'Piani',
  Sections: 'Sezioni',
  Elevations: 'Alzati',
  'Interior Elevations': 'Alzati Interni',
  Worksheets: 'Fogli di Lavoro',
  Details: 'Dettagli',
  '3D Documents': 'Documenti 3D',
  Schedules: 'Abachi',
  Legends: 'Legende',
  'Reflected Ceiling Plans': 'Piante Controsoffitti',
  'Zone Plans': 'Piante Zone',
  'Project Map': 'Mappa Progetto',
  'View Map': 'Mappa Viste',
  'Layout Book': 'Book di Layout',
  'Publisher Sets': 'Set di Publisher',
  Selected: 'Selezionati',
  'Select elements, or choose a tool in the Toolbox.': 'Seleziona gli elementi o scegli uno strumento.',
  'Settings...': 'Impostazioni...',
  Favorites: 'Preferiti',
};

/** 'it' or 'en': the user's choice, else the browser's language. */
export function uiLanguage(settings) {
  const own = settings?.uiLang;
  if (own === 'it' || own === 'en') return own;
  return typeof navigator !== 'undefined' && /^it\b/i.test(navigator.language || '') ? 'it' : 'en';
}

/** A label in the given language; what has no translation stays as it is. */
export function translateLabel(label, lang) {
  if (lang !== 'it' || typeof label !== 'string') return label;
  return EXTRA[label] ?? IT[label] ?? label;
}
