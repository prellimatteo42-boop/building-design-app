/**
 * Solid Element Operations palette, as in Archicad: pick target elements
 * and operator elements from the selection, choose the operation, execute.
 * Targets keep their operations (core/seo.js) until they are removed.
 */
import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { SEO_OPS } from '../core/seo.js';
import { MODEL_KINDS } from '../core/scene.js';
import { expandGroups } from '../core/ops.js';

export class SeoPalette {
  constructor(app) {
    this.app = app;
    this.el = null;
    this.targets = [];
    this.operators = [];
    this.op = 'subtract';
  }

  get open() {
    return !!this.el;
  }

  toggle() {
    if (this.el) return this.close();
    this.el = h('section.quick-layers.seo-palette', { role: 'dialog', 'aria-label': 'Solid Element Operations' });
    document.body.append(this.el);
    this.render();
  }

  close() {
    this.el?.remove();
    this.el = null;
  }

  /** Model elements in the selection (group members included). */
  picked() {
    const doc = this.app.doc;
    return [...expandGroups(doc, this.app.selection)].filter((id) => MODEL_KINDS.includes(doc.get(id)?.kind));
  }

  render() {
    const el = this.el;
    if (!el) return;
    const app = this.app;
    const doc = app.doc;
    clear(el);
    this.targets = this.targets.filter((id) => doc?.has(id));
    this.operators = this.operators.filter((id) => doc?.has(id));
    const row = (label, list, set) =>
      h('div.seo-row',
        h('button.btn.sm', { type: 'button', onClick: () => (set(this.picked()), this.render()) }, label),
        h('span.seo-count', `${list.length} element${list.length === 1 ? '' : 's'}`),
        h('button.icon-btn.sm', { type: 'button', 'aria-label': `Select the ${label.replace('Get ', '').toLowerCase()}`, disabled: !list.length, onClick: () => app.select(list) }, icon('pointer', 14)),
      );
    const op = h('select.input.sm', { 'aria-label': 'Operation' }, SEO_OPS.map((o) => h('option', { value: o.value, selected: o.value === this.op }, o.label)));
    op.addEventListener('change', () => (this.op = op.value));
    op.addEventListener('keydown', (e) => e.stopPropagation());
    const sel = this.picked().filter((id) => doc.get(id)?.seo?.length);
    el.append(
      h('div.ql-head', h('span.ql-title', icon('mass', 15), 'Solid Element Operations'), h('button.icon-btn.sm', { type: 'button', 'aria-label': 'Close', onClick: () => this.close() }, icon('x', 14))),
      row('Get Targets', this.targets, (v) => (this.targets = v)),
      row('Get Operators', this.operators, (v) => (this.operators = v)),
      op,
      h('div.ql-actions',
        h('button.btn.sm.primary', { type: 'button', disabled: !this.targets.length || !this.operators.length, onClick: () => this.execute() }, h('span', 'Execute')),
        h('button.btn.sm', { type: 'button', disabled: !sel.length, 'data-tip': 'Remove every operation from the selected targets', onClick: () => app.commit('Remove solid operations', () => sel.forEach((id) => doc.update(id, { seo: [] }))) }, h('span', 'Remove Operations')),
      ),
    );
  }

  execute() {
    const app = this.app;
    const doc = app.doc;
    const ops = new Set(this.operators);
    const targets = this.targets.filter((id) => !ops.has(id));
    if (!targets.length) return app.toast('An element cannot operate on itself: pick different targets and operators.', { kind: 'error' });
    app.commit('Solid element operation', () => {
      for (const id of targets) {
        const t = doc.get(id);
        const kept = (t.seo || []).filter((x) => !ops.has(x.id));
        doc.update(id, { seo: [...kept, ...this.operators.map((o) => ({ id: o, op: this.op }))] });
      }
    });
    app.toast(`${SEO_OPS.find((o) => o.value === this.op).label}: ${targets.length} target${targets.length === 1 ? '' : 's'}, ${this.operators.length} operator${this.operators.length === 1 ? '' : 's'}. It shows in 3D and in sections.`, { kind: 'success' });
  }
}
