/**
 * Manage-tab dialogs: phases, object styles, project parameters, saved
 * selections, selection inquiry (IDs) and warnings.
 */
import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { openDialog, toast, promptDialog, confirmDialog } from './dialog.js';
import { CATEGORIES } from '../core/catalog.js';
import { phasesInOrder } from '../core/phases.js';
import { PARAM_TYPES, RESULT_TYPES, projectParams, propertyGroups, coerceParamValue, paramsForElement, expressionText } from '../core/params.js';
import { classTree, classLabel } from '../core/classify.js';
import { keynotes, keynoteTree, editKeynotes, parseKeynoteFile, keynoteFileText } from '../core/keynotes.js';
import { download } from '../io/storage.js';
import { assignIds, idField, idLabel, ID_ORDERS, LEVEL_CODES } from '../core/idmanager.js';
import { KIND_LABEL } from '../core/catalog.js';
import { EXPRESSION_FUNCTIONS } from '../core/expressions.js';
import { autotextFields } from '../core/autotext.js';
import { uniqueName } from '../core/ops.js';
import { modelWarnings } from '../core/warnings.js';
import { isView } from '../core/doc.js';
import { formatLength, parseLength } from '../core/units.js';
import { decodeProject } from '../io/native.js';
import { STANDARD_GROUPS, standardCounts, transferStandards } from '../core/transfer.js';

function field(label, control) {
  return h('label.field', h('span.field-label', label), control);
}

// Phases ------------------------------------------------------------------------------------------

export function phasesDialog(app) {
  const doc = app.doc;
  const body = h('div');
  const render = () => {
    clear(body);
    const phases = phasesInOrder(doc);
    const list = h('ol.phase-list');
    phases.forEach((p, i) => {
      const name = h('input.input.sm', { type: 'text', value: p.name, 'aria-label': `Name of phase ${i + 1}` });
      name.addEventListener('change', () => name.value.trim() && app.commit('Rename phase', () => doc.update(p.id, { name: name.value.trim() })));
      const swap = (j) => {
        const q = phases[j];
        app.commit('Reorder phases', () => {
          doc.update(p.id, { order: q.order });
          doc.update(q.id, { order: p.order });
        });
        render();
      };
      const used = doc.filter((el) => el.phaseId === p.id || el.demolishedId === p.id).length;
      list.append(
        h(
          'li.inline',
          h('span.phase-num', String(i + 1)),
          name,
          h('span.file-meta', used ? `${used} element${used === 1 ? '' : 's'}` : ''),
          h('button.icon-btn.sm', { type: 'button', 'aria-label': `Move ${p.name} earlier`, disabled: i === 0, onClick: () => swap(i - 1) }, icon('chevron-up', 14)),
          h('button.icon-btn.sm', { type: 'button', 'aria-label': `Move ${p.name} later`, disabled: i === phases.length - 1, onClick: () => swap(i + 1) }, icon('chevron-down', 14)),
          h(
            'button.icon-btn.sm',
            {
              type: 'button',
              'aria-label': `Delete ${p.name}`,
              disabled: phases.length <= 1,
              onClick: async () => {
                const next = phases[i + 1] || phases[i - 1];
                if (used && !(await confirmDialog('Delete phase', `Elements of "${p.name}" move to "${next.name}".`, { confirm: 'Delete', danger: true }))) return;
                app.commit('Delete phase', () => {
                  for (const el of doc.items.values()) {
                    if (el.phaseId === p.id) doc.update(el.id, { phaseId: next.id });
                    if (el.demolishedId === p.id) doc.update(el.id, { demolishedId: null });
                  }
                  doc.remove(p.id);
                });
                render();
              },
            },
            icon('trash', 14),
          ),
        ),
      );
    });
    body.append(
      h('p.field-hint', 'Phases run from first to last. Elements are created in a phase and can be demolished in a later one; each view shows the model as of its phase.'),
      list,
      h(
        'button.btn.sm',
        {
          type: 'button',
          onClick: () => {
            const names = phases.map((p) => p.name);
            const order = (phases.at(-1)?.order || 0) + 1;
            app.commit('Add phase', () => doc.add({ kind: 'phase', name: uniqueName(names, `Phase ${phases.length + 1}`), order }));
            render();
          },
        },
        icon('plus', 14),
        'Add phase',
      ),
    );
  };
  render();
  return openDialog({ title: 'Phases', body, size: 'md', actions: [{ label: 'Close', primary: true, value: null }] });
}

// Object styles -----------------------------------------------------------------------------------

const WEIGHTS = [
  { value: '', label: 'Default' },
  { value: '1', label: '1 Fine' },
  { value: '2', label: '2 Light' },
  { value: '3', label: '3 Medium' },
  { value: '4', label: '4 Cut' },
  { value: '5', label: '5 Heavy' },
];

export function objectStylesDialog(app) {
  const doc = app.doc;
  const styles = structuredClone(doc.get('project')?.objectStyles || {});
  const tbody = h('tbody');
  for (const c of CATEGORIES) {
    const s = styles[c.id] || (styles[c.id] = {});
    const color = h('input.ov-color', { type: 'color', value: s.color || '#000000', 'aria-label': `${c.label} line color` });
    const wrap = h('div.ov-colorcell', { class: s.color ? 'set' : '' }, color);
    const reset = h('button.icon-btn.sm', { type: 'button', 'aria-label': `Reset ${c.label} color`, hidden: !s.color }, icon('x', 12));
    wrap.append(reset);
    color.addEventListener('input', () => {
      s.color = color.value;
      wrap.classList.add('set');
      reset.hidden = false;
    });
    reset.addEventListener('click', () => {
      s.color = null;
      wrap.classList.remove('set');
      reset.hidden = true;
    });
    const weight = h('select.input.sm', { 'aria-label': `${c.label} line weight` }, WEIGHTS.map((w) => h('option', { value: w.value }, w.label)));
    weight.value = s.weight ? String(s.weight) : '';
    weight.addEventListener('change', () => (s.weight = weight.value ? +weight.value : null));
    tbody.append(h('tr', h('td', c.label), h('td', c.model ? 'Model' : 'Annotation'), h('td', wrap), h('td', weight)));
  }
  return openDialog({
    title: 'Object Styles',
    body: h('div', h('p.field-hint', 'The default line color and weight of each category in every view. Views can override them in Visibility/Graphics.'), h('div.vg-panel', h('table.vg-table', h('thead', h('tr', h('th', 'Category'), h('th', 'Kind'), h('th', 'Line color'), h('th', 'Line weight'))), tbody))),
    size: 'lg',
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'OK',
        primary: true,
        onClick: () => {
          const out = {};
          for (const [k, v] of Object.entries(styles)) if (v.color || v.weight) out[k] = { ...(v.color ? { color: v.color } : {}), ...(v.weight ? { weight: v.weight } : {}) };
          doc.setInfo({ objectStyles: Object.keys(out).length ? out : null });
        },
      },
    ],
  });
}

// Project parameters ------------------------------------------------------------------------------

export function projectParamsDialog(app) {
  const doc = app.doc;
  let current = projectParams(doc)[0]?.id ?? null;
  const side = h('div.style-side');
  const main = h('div.style-main');
  const render = () => {
    clear(side);
    clear(main);
    const list = h('ul.style-list', { role: 'listbox', 'aria-label': 'Project parameters' });
    for (const p of projectParams(doc)) list.append(h('li.style-item', { role: 'option', 'aria-selected': String(p.id === current), tabindex: '0', onClick: () => ((current = p.id), render()), onKeydown: (e) => e.key === 'Enter' && ((current = p.id), render()) }, p.name));
    side.append(
      list,
      h(
        'div.inline',
        h(
          'button.btn.sm',
          {
            type: 'button',
            onClick: async () => {
              const names = projectParams(doc).map((p) => p.name);
              const name = await promptDialog('New Project Parameter', 'Name', uniqueName(names, 'Fire Rating'), { okLabel: 'Add', validate: (v) => (!v ? 'Enter a name.' : names.includes(v) ? 'A parameter with this name exists.' : null) });
              if (!name) return;
              let p;
              app.commit('Add project parameter', () => (p = doc.add({ kind: 'projectParam', name, type: 'text', categories: ['walls', 'doors'], group: 'Identity Data' })));
              current = p.id;
              render();
            },
          },
          icon('plus', 14),
          'New',
        ),
        current
          ? h(
              'button.btn.sm',
              {
                type: 'button',
                onClick: () => {
                  app.commit('Delete project parameter', () => {
                    for (const el of doc.items.values())
                      if (el.params && current in el.params) {
                        const { [current]: _drop, ...rest } = el.params;
                        void _drop;
                        doc.update(el.id, { params: rest });
                      }
                    doc.remove(current);
                  });
                  current = projectParams(doc)[0]?.id ?? null;
                  render();
                },
              },
              icon('trash', 14),
              'Delete',
            )
          : null,
      ),
    );
    const p = doc.get(current);
    if (!p) {
      main.append(h('p.props-empty', 'Add your own parameters to categories of elements, such as a fire rating for walls and doors. They show in the properties palette, in schedules and in filters.'));
      return;
    }
    const save = (patch) => app.commit('Edit project parameter', () => doc.update(p.id, patch));
    const name = h('input.input', { type: 'text', value: p.name });
    name.addEventListener('change', () => name.value.trim() && (save({ name: name.value.trim() }), render()));
    const type = h('select.input', {}, PARAM_TYPES.map((t) => h('option', { value: t.value }, t.label)));
    type.value = p.type;
    type.addEventListener('change', () => (save({ type: type.value, ...(type.value === 'expression' && !p.expression ? { expression: '', result: 'number' } : {}) }), render()));
    const group = h('select.input', {}, [...propertyGroups(doc).map((g) => h('option', { value: g.name }, g.userDefined ? g.name : `${g.name} (built-in)`)), h('option', { value: '+new' }, 'New group…')]);
    group.value = p.group || 'Identity Data';
    group.addEventListener('change', async () => {
      if (group.value !== '+new') return save({ group: group.value });
      const names = propertyGroups(doc).map((g) => g.name.toLowerCase());
      const gname = await promptDialog('New Property Group', 'Name', 'My Properties', { okLabel: 'Add', validate: (v) => (!v ? 'Enter a name.' : names.includes(v.toLowerCase()) ? 'A group with this name exists.' : null) });
      if (gname) app.commit('Add property group', () => (doc.add({ kind: 'propertyGroup', name: gname, description: '' }), doc.update(p.id, { group: gname })));
      render();
    });
    const desc = h('input.input', { type: 'text', value: p.description || '', placeholder: 'What the property is for' });
    desc.addEventListener('change', () => save({ description: desc.value.trim() }));
    const optionsBox = h('textarea.input', { rows: 4, placeholder: 'One option per line' });
    optionsBox.value = (p.options || []).join('\n');
    optionsBox.addEventListener('keydown', (e) => e.stopPropagation());
    optionsBox.addEventListener('change', () => (save({ options: [...new Set(optionsBox.value.split('\n').map((x) => x.trim()).filter(Boolean))] }), render()));
    const def = h('input.input', { type: 'text', value: Array.isArray(p.default) ? p.default.join('; ') : p.default ?? '', placeholder: 'None' });
    def.addEventListener('change', () => {
      const raw = def.value.trim();
      const v = raw === '' ? null : p.type === 'length' ? parseLength(raw, doc.units) : coerceParamValue(p, raw);
      if (v instanceof Error || (p.type === 'length' && !Number.isFinite(v))) {
        def.setAttribute('aria-invalid', 'true');
        toast(v instanceof Error ? v.message : `"${raw}" is not a valid length.`, { kind: 'error' });
        return;
      }
      def.removeAttribute('aria-invalid');
      save({ default: v });
    });
    const cats = h('div.snap-grid');
    for (const c of CATEGORIES.filter((x) => x.model || ['rooms', 'areas'].includes(x.id))) {
      const cb = h('input', { type: 'checkbox', checked: p.categories?.includes(c.id) });
      cb.addEventListener('change', () => {
        const set = new Set(doc.get(p.id).categories || []);
        if (cb.checked) set.add(c.id);
        else set.delete(c.id);
        save({ categories: [...set] });
      });
      cats.append(h('label.check', cb, c.label));
    }
    main.append(h('div.row2', field('Name', name), field('Type', type)), h('div.row2', field('Group', group), field('Description', desc)));
    if (p.type === 'expression') main.append(expressionEditor(app, p, save));
    else {
      if (p.type === 'choice' || p.type === 'multi') main.append(field('Options', optionsBox));
      main.append(field(p.type === 'list' || p.type === 'multi' ? 'Default value (separate with ;)' : 'Default value', def));
    }
    main.append(h('h3.dlg-sub', 'Available for categories'), cats);
    // Availability by classification, as Archicad ties properties to classification items.
    const systems = doc.all('classSystem');
    if (systems.length) {
      const classes = h('div.snap-grid');
      for (const sys of systems)
        for (const { item, depth } of classTree(sys)) {
          const on = (p.classes || []).some((c) => c.system === sys.id && c.code === item.code);
          const cb = h('input', { type: 'checkbox', checked: on });
          cb.addEventListener('change', () => {
            const cur = (doc.get(p.id).classes || []).filter((c) => !(c.system === sys.id && c.code === item.code));
            save({ classes: cb.checked ? [...cur, { system: sys.id, code: item.code }] : cur });
          });
          classes.append(h('label.check', { style: `padding-left:${depth * 12}px` }, cb, classLabel(item)));
        }
      main.append(h('h3.dlg-sub', 'Available for classifications (and the items under them)'), classes);
    }
  };
  render();
  return openDialog({ title: 'Project Parameters', body: h('div.style-dlg', side, main), size: 'lg', actions: [{ label: 'Close', primary: true, value: null }] });
}

/**
 * The expression of an expression parameter, with its result type, a check
 * on a selected element (or the first element of its categories) and the
 * fields and functions it can use.
 */
function expressionEditor(app, p, save) {
  const doc = app.doc;
  const sample = () => {
    const applies = (el) => el && paramsForElement(doc, el).some((x) => x.id === p.id);
    return [...app.selection].map((id) => doc.get(id)).find(applies) || [...doc.items.values()].find(applies) || null;
  };
  const expr = h('textarea.input.ep-expr', { rows: 3, spellcheck: 'false', 'aria-label': 'Expression', placeholder: 'For example: {Area} * 1.1' });
  expr.value = p.expression || '';
  const result = h('select.input', { 'aria-label': 'Result' }, RESULT_TYPES.map((t) => h('option', { value: t.value }, t.label)));
  result.value = p.result || 'number';
  const out = h('p.ep-out', { role: 'status' });
  const check = () => {
    const el = sample();
    if (!el) return (out.textContent = 'No element of these categories yet to try it on.');
    const text = expressionText({ doc, scene: app.scene }, el, { ...doc.get(p.id), expression: expr.value, result: result.value });
    out.textContent = `${app.describe ? app.describe(el) : el.kind}: ${text}`;
    out.classList.toggle('ep-err', text.startsWith('Error:'));
  };
  expr.addEventListener('keydown', (e) => e.stopPropagation());
  expr.addEventListener('input', check);
  expr.addEventListener('change', () => save({ expression: expr.value }));
  result.addEventListener('change', () => (save({ result: result.value }), check()));
  const el = sample();
  const names = el ? [...autotextFields(el, doc).map((f) => f.label)].filter((n) => n !== p.name) : [];
  const insert = (text) => {
    const at = expr.selectionStart ?? expr.value.length;
    expr.value = expr.value.slice(0, at) + text + expr.value.slice(expr.selectionEnd ?? at);
    expr.focus();
    expr.selectionStart = expr.selectionEnd = at + text.length;
    check();
    save({ expression: expr.value });
  };
  requestAnimationFrame(check);
  return h(
    'div.ep',
    h('div.row2', field('Expression', expr), field('Result', result)),
    out,
    h('p.field-hint', 'Lengths are in metres, areas in m² and volumes in m³. Text goes in quotes; & joins text.'),
    names.length ? h('div.ep-chips', h('span.field-label', 'Fields'), names.map((n) => h('button.as-chip', { type: 'button', onClick: () => insert(`{${n}}`) }, n))) : null,
    h('div.ep-chips', h('span.field-label', 'Functions'), EXPRESSION_FUNCTIONS.map((f) => h('button.as-chip', { type: 'button', onClick: () => insert(`${f}(`) }, f))),
  );
}

// Selections --------------------------------------------------------------------------------------

export async function saveSelection(app) {
  const ids = [...app.selection];
  if (!ids.length) return toast('Select elements first.', { kind: 'error' });
  const names = app.doc.all('selectionSet').map((s) => s.name);
  const name = await promptDialog('Save Selection', 'Name', uniqueName(names, 'Selection 1'), { okLabel: 'Save', validate: (v) => (!v ? 'Enter a name.' : null) });
  if (!name) return;
  const existing = app.doc.all('selectionSet').find((s) => s.name === name);
  app.commit('Save selection', () => (existing ? app.doc.update(existing.id, { ids }) : app.doc.add({ kind: 'selectionSet', name, ids })));
  toast(`Saved ${ids.length} element${ids.length === 1 ? '' : 's'} as "${name}".`, { kind: 'success' });
}

export function loadSelection(app) {
  const doc = app.doc;
  const sets = doc.all('selectionSet');
  if (!sets.length) return toast('No saved selections. Select elements and use Save.', { kind: 'error' });
  const body = h('div');
  const render = () => {
    clear(body);
    const list = h('ul.find-list');
    for (const s of doc.all('selectionSet')) {
      const live = s.ids.filter((id) => doc.has(id));
      list.append(
        h(
          'li.inline',
          h(
            'button.find-item',
            {
              type: 'button',
              onClick: () => {
                app.select(live);
                body.closest('dialog')?._close?.(null);
              },
            },
            h('span.find-text', s.name),
            h('span.find-view', `${live.length} element${live.length === 1 ? '' : 's'}`),
          ),
          h('button.btn.sm', { type: 'button', disabled: !app.selection.size, 'data-tip': 'Add the current selection', onClick: () => (app.commit('Edit selection', () => doc.update(s.id, { ids: [...new Set([...s.ids, ...app.selection])] })), render()) }, 'Add'),
          h('button.btn.sm', { type: 'button', disabled: !app.selection.size, 'data-tip': 'Remove the current selection', onClick: () => (app.commit('Edit selection', () => doc.update(s.id, { ids: s.ids.filter((id) => !app.selection.has(id)) })), render()) }, 'Remove'),
          h('button.icon-btn.sm', { type: 'button', 'aria-label': `Delete ${s.name}`, onClick: () => (app.commit('Delete selection', () => doc.remove(s.id)), render()) }, icon('trash', 14)),
        ),
      );
    }
    body.append(list);
  };
  render();
  return openDialog({ title: 'Saved Selections', body, size: 'md', actions: [{ label: 'Close', primary: true, value: null }] });
}

export function idsOfSelection(app) {
  const ids = [...app.selection];
  if (!ids.length) return toast('Select elements first.', { kind: 'error' });
  const ta = h('textarea.input', { rows: 6, readonly: true, 'aria-label': 'IDs of the selection' });
  ta.value = ids.join('\n');
  return openDialog({
    title: 'IDs of Selection',
    body: h('div', ta),
    size: 'sm',
    actions: [
      { label: 'Copy', onClick: () => (navigator.clipboard?.writeText(ta.value), toast('Copied.'), false) },
      { label: 'Close', primary: true, value: null },
    ],
  });
}

export async function selectById(app) {
  const text = await promptDialog('Select by ID', 'IDs (separated by commas or spaces)', '', { okLabel: 'Select' });
  if (!text) return;
  const ids = text.split(/[\s,;]+/).filter(Boolean);
  const found = ids.filter((id) => app.doc.has(id) && !isView(app.doc.get(id)));
  app.select(found);
  if (found.length) app.vc?.zoomExtents?.(true, new Set(found));
  toast(found.length === ids.length ? `Selected ${found.length}.` : `Found ${found.length} of ${ids.length}.`, { kind: found.length ? 'success' : 'error' });
}

// Line styles ------------------------------------------------------------------------------------------

const DASHES = [
  { value: 0, label: 'Solid' },
  { value: 1, label: 'Dash' },
  { value: 2, label: 'Hidden (short dash)' },
  { value: 3, label: 'Center (dash dot)' },
];

/** The project's own line styles for detail lines, model lines and arcs. */
export function lineStylesDialog(app) {
  const doc = app.doc;
  const body = h('div');
  const render = () => {
    clear(body);
    const styles = doc.all('lineStyle');
    const uses = new Map();
    for (const el of doc.filter((x) => x.style && doc.get(x.style)?.kind === 'lineStyle')) uses.set(el.style, (uses.get(el.style) || 0) + 1);
    const tbody = h('tbody');
    for (const st of styles) {
      const name = h('input.input.sm', { type: 'text', value: st.name, 'aria-label': 'Name' });
      name.addEventListener('change', () => name.value.trim() && app.commit('Rename line style', () => doc.update(st.id, { name: name.value.trim() })));
      const weight = h('select.input.sm', { 'aria-label': `${st.name} weight` }, [1, 2, 3, 4, 5].map((w) => h('option', { value: String(w) }, ['', 'Fine', 'Light', 'Medium', 'Cut', 'Heavy'][w])));
      weight.value = String(st.weight || 1);
      weight.addEventListener('change', () => app.commit('Line style weight', () => doc.update(st.id, { weight: +weight.value })));
      const color = h('input.ov-color', { type: 'color', value: st.color || '#000000', 'aria-label': `${st.name} colour` });
      color.addEventListener('change', () => app.commit('Line style colour', () => doc.update(st.id, { color: color.value })));
      const dash = h('select.input.sm', { 'aria-label': `${st.name} pattern` }, DASHES.map((d) => h('option', { value: String(d.value) }, d.label)));
      dash.value = String(st.dash || 0);
      dash.addEventListener('change', () => app.commit('Line style pattern', () => doc.update(st.id, { dash: +dash.value })));
      const del = h('button.icon-btn.sm', { type: 'button', 'aria-label': `Delete ${st.name}`, onClick: () => {
        app.commit('Delete line style', () => {
          for (const el of doc.filter((x) => x.style === st.id)) doc.update(el.id, { style: 'thin' });
          doc.remove(st.id);
        });
        render();
      } }, icon('trash', 14));
      tbody.append(h('tr', h('td', name), h('td', weight), h('td', color), h('td', dash), h('td.num', String(uses.get(st.id) || 0)), h('td', del)));
    }
    body.append(
      styles.length
        ? h('table.vg-table', h('thead', h('tr', h('th', 'Name'), h('th', 'Weight'), h('th', 'Colour'), h('th', 'Pattern'), h('th.num', 'Used by'), h('th', h('span.sr-only', 'Delete')))), tbody)
        : h('p.dialog-text', 'Besides Thin, Medium, Wide, Dashed, Hidden and Center, add your own line styles (for example a red demolition line or a property boundary) to use for detail lines, model lines and arcs.'),
      h('div', { style: { marginTop: '10px' } }, h('button.btn', { type: 'button', onClick: () => {
        app.commit('New line style', () => doc.add({ kind: 'lineStyle', name: uniqueName(styles.map((x) => x.name), 'Line Style 1'), weight: 2, dash: 0, color: '#d03030' }));
        render();
      } }, icon('plus', 14), 'New Line Style')),
    );
  };
  render();
  return openDialog({ title: 'Line Styles', body, size: 'md', actions: [{ label: 'Close', primary: true, value: true }] });
}

// Transfer project standards ------------------------------------------------------------------------

/** Pick a project file, then choose what to copy from it. */
export function transferStandardsDialog(app) {
  const input = h('input', { type: 'file', accept: '.bdp,application/json', hidden: true });
  input.addEventListener('change', async () => {
    const file = input.files?.[0];
    input.remove();
    if (!file) return;
    let src;
    try {
      src = await decodeProject(await file.arrayBuffer());
    } catch (err) {
      return toast(err.message || 'That file could not be read.', { kind: 'error' });
    }
    const counts = standardCounts(src);
    const checks = STANDARD_GROUPS.map((g) => ({ g, cb: h('input', { type: 'checkbox', checked: counts[g.id] > 0 && g.id !== 'objectStyles', disabled: !counts[g.id] }) }));
    const ok = await openDialog({
      title: `Transfer Project Standards from ${file.name}`,
      body: h(
        'div',
        h('div.filter-sel', checks.map(({ g, cb }) => h('label.check', cb, h('span.grow', g.label), h('span.file-meta', String(counts[g.id]))))),
        h('p.field-hint', 'Items that already exist unchanged are skipped. Items whose name is taken by something different come in as copies marked "(transferred)".'),
      ),
      size: 'md',
      actions: [
        { label: 'Cancel', value: null },
        { label: 'Transfer', primary: true, value: true },
      ],
    });
    if (!ok) return;
    let r;
    app.commit('Transfer project standards', () => (r = transferStandards(src, app.doc, checks.filter((c) => c.cb.checked).map((c) => c.g.id))));
    if (r) toast(`Transferred ${r.added} item${r.added === 1 ? '' : 's'}${r.skipped ? `; ${r.skipped} were already here` : ''}.`, { kind: 'success' });
  });
  document.body.append(input);
  input.click();
}

// Topography points --------------------------------------------------------------------------------

export function topoPointsDialog(app, id) {
  const doc = app.doc;
  const topo = doc.get(id || [...app.selection].find((x) => doc.get(x)?.kind === 'topo'));
  if (!topo) return toast('Select a toposurface first.', { kind: 'error' });
  const pts = topo.points.map((p) => p.slice());
  const units = doc.units;
  const tbody = h('tbody');
  const fmt = (v) => formatLength(v, units);
  const render = () => {
    clear(tbody);
    pts.forEach((p, i) => {
      const cell = (k) => {
        const inp = h('input.input.sm', { type: 'text', value: fmt(p[k]), 'aria-label': `${'XYZ'[k]} of point ${i + 1}` });
        inp.addEventListener('change', () => {
          const v = parseLength(inp.value, units);
          if (Number.isFinite(v)) p[k] = v;
          inp.value = fmt(p[k]);
        });
        return h('td', inp);
      };
      tbody.append(h('tr', h('td', String(i + 1)), cell(0), cell(1), cell(2), h('td', h('button.icon-btn.sm', { type: 'button', 'aria-label': `Delete point ${i + 1}`, disabled: pts.length <= 3, onClick: () => (pts.splice(i, 1), render()) }, icon('trash', 14)))));
    });
  };
  render();
  return openDialog({
    title: 'Toposurface Points',
    body: h('div.vg-panel', h('table.vg-table', h('thead', h('tr', h('th', '#'), h('th', 'X'), h('th', 'Y'), h('th', 'Elevation'), h('th', h('span.sr-only', 'Delete')))), tbody)),
    size: 'md',
    actions: [
      { label: 'Cancel', value: null },
      { label: 'OK', primary: true, onClick: () => app.commit('Edit toposurface', () => doc.update(topo.id, { points: pts })) },
    ],
  });
}

// Warnings ----------------------------------------------------------------------------------------

export function warningsDialog(app) {
  const ws = modelWarnings(app.doc, app.scene);
  const body = h('div');
  if (!ws.length) body.append(h('p.props-empty', 'No warnings. The model has no overlapping walls, unenclosed rooms or duplicate marks.'));
  else {
    const list = h('ul.find-list.warn-list');
    for (const w of ws.slice(0, 500))
      list.append(
        h(
          'li',
          h(
            'button.find-item',
            {
              type: 'button',
              onClick: () => {
                const live = w.ids.filter((id) => app.doc.has(id));
                const first = app.doc.get(live[0]);
                const plan = first?.levelId && app.doc.all('plan').find((p) => p.levelId === first.levelId && !p.calloutOf);
                if (plan && app.activeView?.levelId !== first.levelId) app.openView(plan.id);
                app.select(live);
                app.vc?.zoomExtents?.(true, new Set(live));
              },
            },
            icon('warning', 14),
            h('span.find-text', w.message),
            h('span.find-view', `${w.ids.length} element${w.ids.length === 1 ? '' : 's'}`),
          ),
        ),
      );
    body.append(h('p.field-hint', `${ws.length} warning${ws.length === 1 ? '' : 's'}. Click one to select and show its elements.`), list);
  }
  return openDialog({ title: 'Warnings', body, size: 'md', actions: [{ label: 'Close', primary: true, value: null }] });
}

// Keynote Manager ---------------------------------------------------------------------------------

/** The keynote catalogue: folders and keynotes in a tree, imported from and saved to keynote files. */
export function keynoteManagerDialog(app) {
  const doc = app.doc;
  let sel = null; // { key, folder }
  const side = h('div.style-side');
  const main = h('div.style-main');
  const same = (k) => sel && k.key === sel.key && !!k.folder === !!sel.folder;
  const apply = (ops, label = 'Edit keynotes') => {
    try {
      const next = editKeynotes(keynotes(doc), ops);
      app.commit(label, () => doc.update('project', { keynotes: next }));
      return true;
    } catch (err) {
      toast(err.message, { kind: 'error' });
      return false;
    }
  };
  const add = async (folder) => {
    const cur = keynotes(doc).find(same);
    const parent = cur ? (cur.folder ? cur.key : cur.parent) : null;
    const key = await promptDialog(folder ? 'New Folder' : 'New Keynote', 'Key', '', { okLabel: 'Add', validate: (v) => (!v ? 'Enter a key.' : null) });
    if (!key) return;
    if (apply([{ op: 'add', key, title: '', parent, folder }], folder ? 'Add keynote folder' : 'Add keynote')) sel = { key, folder };
    render();
  };
  const render = () => {
    clear(side);
    clear(main);
    const list = h('ul.style-list', { role: 'tree', 'aria-label': 'Keynotes' });
    for (const { item, depth } of keynoteTree(keynotes(doc))) {
      const pick = () => ((sel = { key: item.key, folder: !!item.folder }), render());
      list.append(
        h(
          'li.style-item.kn-item',
          { role: 'treeitem', 'aria-selected': String(same(item)), tabindex: '0', style: `padding-left:${8 + depth * 14}px`, onClick: pick, onKeydown: (e) => e.key === 'Enter' && pick() },
          icon(item.folder ? 'folder' : 'keynote', 13),
          h('span.kn-text', h('b', item.key), item.title ? ` ${item.title}` : ''),
        ),
      );
    }
    const importFile = () => {
      const input = h('input', { type: 'file', accept: '.txt,text/plain', hidden: true });
      input.addEventListener('change', async () => {
        const f = input.files?.[0];
        input.remove();
        if (!f) return;
        const rows = parseKeynoteFile(await f.text());
        if (!rows.length) return toast('No keynotes found. Use one line per entry: key, text and parent key separated by tabs.', { kind: 'error' });
        // Entries with the same key are replaced by the file's.
        const keep = keynotes(doc).filter((k) => !rows.some((r) => r.key === k.key && !!r.folder === !!k.folder));
        app.commit('Import keynotes', () => doc.update('project', { keynotes: [...keep, ...rows] }));
        toast(`Imported ${rows.length} entries.`, { kind: 'success' });
        render();
      });
      document.body.append(input);
      input.click();
    };
    side.append(
      list,
      h(
        'div.inline',
        h('button.btn.sm', { type: 'button', onClick: () => add(true) }, icon('plus', 14), 'Folder'),
        h('button.btn.sm', { type: 'button', onClick: () => add(false) }, icon('plus', 14), 'Keynote'),
        sel
          ? h('button.btn.sm', { type: 'button', 'aria-label': 'Delete', onClick: () => apply([{ op: 'delete', key: sel.key, folder: sel.folder }], 'Delete keynote') && ((sel = null), render()) }, icon('trash', 14))
          : null,
      ),
      h('div.inline', h('button.btn.sm', { type: 'button', onClick: importFile }, 'Import…'), h('button.btn.sm', { type: 'button', disabled: !keynotes(doc).length, onClick: () => download(new Blob([keynoteFileText(keynotes(doc))], { type: 'text/plain' }), 'Keynotes.txt') }, 'Save as file…')),
    );
    const k = keynotes(doc).find(same);
    if (!k) {
      main.append(h('p.props-empty', 'Keynotes are short keys for construction notes, such as 04.20 for a brick wall. Organise them in folders, give elements or their types a key in the properties palette (Keynote) and tag them with the Keynote tool; the catalogue gives each key its title and description.'));
      return;
    }
    const key = h('input.input', { type: 'text', value: k.key });
    key.addEventListener('change', () => key.value.trim() && apply([{ op: 'modify', key: k.key, folder: k.folder, new_key: key.value.trim() }]) && ((sel = { key: key.value.trim(), folder: !!k.folder }), render()));
    const title = h('input.input', { type: 'text', value: k.title || '' });
    title.addEventListener('change', () => apply([{ op: 'modify', key: k.key, folder: k.folder, title: title.value.trim() }]) && render());
    const desc = h('textarea.input', { rows: 4 });
    desc.value = k.description || '';
    desc.addEventListener('keydown', (e) => e.stopPropagation());
    desc.addEventListener('change', () => apply([{ op: 'modify', key: k.key, folder: k.folder, description: desc.value }]));
    const parent = h('select.input', {}, h('option', { value: '' }, '(top level)'), keynotes(doc).filter((x) => x.folder && !(k.folder && x.key === k.key)).map((x) => h('option', { value: x.key }, `${x.key} ${x.title}`)));
    parent.value = k.parent || '';
    parent.addEventListener('change', () => apply([{ op: 'modify', key: k.key, folder: k.folder, parent: parent.value || null }]) && render());
    main.append(h('div.row2', field('Key', key), field('Title', title)), field('Folder', parent), field('Description', desc));
    if (!k.folder) {
      const users = [...doc.items.values()].filter((el) => el.keynote === k.key);
      main.append(h('p.field-hint', users.length ? `Used by ${users.length} element${users.length === 1 ? '' : 's'} or types.` : 'Not used yet.'));
    }
  };
  render();
  return openDialog({ title: 'Keynote Manager', body: h('div.style-dlg', side, main), size: 'lg', actions: [{ label: 'Close', primary: true, value: null }] });
}

// Element ID Manager -----------------------------------------------------------------------------

/** New IDs for the selection (or every element of a kind), by level and place, with a preview. */
export function elementIdManagerDialog(app) {
  const doc = app.doc;
  const sel = [...app.selection].map((id) => doc.get(id)).filter((el) => el && (el.levelId || el.hostId) && !isView(el));
  const kinds = [...new Set(sel.map((el) => el.kind))];
  const o = app.toolOptions('idManager', { prefix: '', suffix: '', levelCode: 'none', separator: '.', start: 1, step: 1, digits: 2, order: 'rows', restartPerLevel: true, perKind: true, scope: sel.length ? 'selection' : 'door' });
  const body = h('div');
  const preview = h('div');
  const scopeOptions = [...(sel.length ? [{ value: 'selection', label: `Selection (${sel.length}: ${kinds.map((k) => KIND_LABEL[k] || k).join(', ')})` }] : []), ...['door', 'window', 'room', 'column', 'component', 'wall', 'beam', 'stair'].map((k) => ({ value: k, label: `All ${(KIND_LABEL[k] || k).toLowerCase()}s` }))];
  if (!scopeOptions.some((s) => s.value === o.scope)) o.scope = scopeOptions[0].value;
  const targets = () => (o.scope === 'selection' ? sel : doc.all(o.scope).filter((el) => el.levelId || el.hostId));
  const input = (key, label, type = 'text') => {
    const el = h('input.input', { type, value: o[key] ?? '' });
    el.addEventListener('keydown', (e) => e.stopPropagation());
    el.addEventListener('input', () => ((o[key] = type === 'number' ? +el.value : el.value), show()));
    return field(label, el);
  };
  const select = (key, label, options) => {
    const el = h('select.input', {}, options.map((x) => h('option', { value: x.value }, x.label)));
    el.value = o[key];
    el.addEventListener('change', () => ((o[key] = el.value), show()));
    return field(label, el);
  };
  const check = (key, label) => {
    const cb = h('input', { type: 'checkbox', checked: !!o[key] });
    cb.addEventListener('change', () => ((o[key] = cb.checked), show()));
    return h('label.check', cb, label);
  };
  let ids = new Map();
  const show = () => {
    clear(preview);
    const els = targets();
    ids = assignIds(doc, els, o);
    const rows = els.filter((el) => ids.has(el.id)).sort((a, b) => [...ids.keys()].indexOf(a.id) - [...ids.keys()].indexOf(b.id));
    const tbody = h('tbody');
    for (const el of rows.slice(0, 60)) tbody.append(h('tr', h('td', idLabel(doc, el)), h('td', doc.get(el.levelId || doc.get(el.hostId)?.levelId)?.name ?? ''), h('td', String(el[idField(el)] ?? '')), h('td', h('b', ids.get(el.id)))));
    preview.append(rows.length ? h('table.vg-table', h('thead', h('tr', h('th', 'Element'), h('th', 'Level'), h('th', 'Current ID'), h('th', 'New ID'))), tbody) : h('p.props-empty', 'No elements to number.'));
    if (rows.length > 60) preview.append(h('p.field-hint', `…and ${rows.length - 60} more.`));
  };
  body.append(
    select('scope', 'Elements', scopeOptions),
    h('div.row2', input('prefix', 'Prefix'), input('suffix', 'Suffix')),
    h('div.row2', select('levelCode', 'Level code', LEVEL_CODES), input('separator', 'Separator after level code')),
    h('div.row2', input('start', 'Start at', 'number'), input('step', 'Step', 'number')),
    h('div.row2', input('digits', 'Digits (leading zeros)', 'number'), select('order', 'Order', ID_ORDERS)),
    h('div.inline', { style: { gap: '16px', margin: '6px 0 10px' } }, check('restartPerLevel', 'Start again on each level'), check('perKind', 'Count each kind of element apart')),
    h('h3.dlg-sub', 'Preview'),
    preview,
  );
  show();
  return openDialog({ title: 'Element ID Manager', body, size: 'lg', actions: [{ label: 'Cancel', value: null }, { label: 'Assign IDs', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok' || !ids.size) return;
    app.commit('Assign IDs', () => {
      for (const [id, value] of ids) doc.update(id, { [idField(doc.get(id))]: value });
    });
    toast(`Assigned ${ids.size} IDs.`, { kind: 'success' });
  });
}
