/**
 * GDL Objects (Design menu): library parts written in GDL, as in
 * Archicad's library part editor: the object's size, its parameters, its
 * 3D and 2D scripts, checked as you type with a preview in plan and 3D.
 */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { drawLibraryPreview } from './library.js';
import { runGdlType } from '../core/gdlobject.js';
import { GDL_TEMPLATES } from '../core/gdltemplates.js';
import { uniqueName } from '../core/ops.js';
import { commentLines, uncommentLines, lineRange, findNext, replaceNext, partGuid } from '../core/gdltext.js';

const KINDS = [
  ['length', 'Length'],
  ['number', 'Number'],
  ['integer', 'Integer'],
  ['angle', 'Angle'],
  ['boolean', 'On/Off'],
  ['material', 'Material'],
  ['string', 'Text'],
];

/** Make a GDL component type from a template (inside a transaction). */
export function addGdlType(doc, tpl) {
  const names = doc.all('componentType').map((t) => t.name);
  return doc.add({ kind: 'componentType', family: 'gdl', category: tpl.category || 'genericModels', familyName: 'GDL Object', name: uniqueName(names, tpl.name), width: tpl.width, depth: tpl.depth, height: tpl.height, gdl: JSON.parse(JSON.stringify(tpl.gdl)) });
}

export function gdlObjectsDialog(app, { select = null } = {}) {
  const doc = app.doc;
  let sel = select || doc.all('componentType').find((t) => t.family === 'gdl')?.id || null;
  const list = h('div.gdl-list');
  const detail = h('div.gdl-detail');
  const update = (patch, label = 'Edit GDL object') => app.commit(label, () => doc.update(sel, patch));
  const stop = (el) => (el.addEventListener('keydown', (e) => e.stopPropagation()), el);

  const renderList = () => {
    clear(list);
    for (const t of doc.all('componentType').filter((x) => x.family === 'gdl'))
      list.append(h(`button.gdl-item${t.id === sel ? '.on' : ''}`, { type: 'button', onClick: () => ((sel = t.id), renderList(), renderDetail()) }, t.name));
    const add = h('select.input.sm', { 'aria-label': 'New GDL object from' }, h('option', { value: '' }, 'New object from...'), ...GDL_TEMPLATES.map((tpl, i) => h('option', { value: i }, tpl.name.replace(/^GDL /, ''))));
    add.addEventListener('change', () => {
      if (add.value === '') return;
      let t;
      app.commit('New GDL object', () => (t = addGdlType(doc, GDL_TEMPLATES[+add.value])));
      sel = t.id;
      renderList();
      renderDetail();
    });
    list.append(add);
  };

  const renderDetail = () => {
    clear(detail);
    const t = doc.get(sel);
    if (!t) return detail.append(h('p.dialog-text', 'Make a new object from one of the starting points.'));
    const status = h('p.field-hint.gdl-status');
    const planC = h('canvas', { width: 220, height: 160, 'aria-label': 'Plan preview' });
    const axoC = h('canvas', { width: 220, height: 160, 'aria-label': '3D preview' });
    const check = () => {
      const cur = doc.get(sel);
      const r = runGdlType(cur);
      status.textContent = r.error ? r.error : `${r.tris.length} triangles, ${r.lines.length + r.polys.length} plan lines.`;
      status.classList.toggle('error', !!r.error);
      drawLibraryPreview(cur, (id) => doc.get(id), planC, axoC);
    };
    const name = stop(h('input.input', { type: 'text', value: t.name, 'aria-label': 'Name' }));
    name.addEventListener('change', () => name.value.trim() && (update({ name: name.value.trim() }), renderList()));
    const size = ['width', 'depth', 'height'].map((k) => {
      const inp = stop(h('input.input.sm', { type: 'number', min: 1, value: t[k], 'aria-label': k[0].toUpperCase() + k.slice(1) }));
      inp.addEventListener('change', () => +inp.value > 0 && (update({ [k]: +inp.value }), check()));
      return h('label.field', h('span.field-label', { width: 'A (width)', depth: 'B (depth)', height: 'ZZYZX (height)' }[k]), inp);
    });
    const params = h('tbody');
    const setParams = (fn) => {
      const cur = doc.get(sel);
      const ps = JSON.parse(JSON.stringify(cur.gdl?.params || []));
      fn(ps);
      update({ gdl: { ...cur.gdl, params: ps } });
      renderParams();
      check();
    };
    const renderParams = () => {
      clear(params);
      (doc.get(sel).gdl?.params || []).forEach((p, i) => {
        const nm = stop(h('input.input.sm', { type: 'text', value: p.name, 'aria-label': `Parameter ${i + 1} name` }));
        nm.addEventListener('change', () => /^[A-Za-z_][A-Za-z0-9_]*$/.test(nm.value) ? setParams((ps) => (ps[i].name = nm.value)) : toast('A parameter name is letters, digits and _ , starting with a letter.', { kind: 'error' }));
        const kind = h('select.input.sm', { 'aria-label': `Parameter ${i + 1} kind` }, KINDS.map(([v, l]) => h('option', { value: v, selected: p.kind === v }, l)));
        kind.addEventListener('change', () => setParams((ps) => (ps[i].kind = kind.value)));
        let val;
        if (p.kind === 'boolean') {
          val = h('input', { type: 'checkbox', checked: !!p.value, 'aria-label': `Parameter ${i + 1} value` });
          val.addEventListener('change', () => setParams((ps) => (ps[i].value = val.checked)));
        } else if (p.kind === 'material') {
          val = h('select.input.sm', { 'aria-label': `Parameter ${i + 1} value` }, doc.all('material').map((m) => h('option', { value: m.id, selected: m.id === p.value }, m.name)));
          val.addEventListener('change', () => setParams((ps) => (ps[i].value = val.value)));
        } else {
          val = stop(h('input.input.sm', { type: p.kind === 'string' ? 'text' : 'number', value: p.value ?? '', 'aria-label': `Parameter ${i + 1} value` }));
          val.addEventListener('change', () => setParams((ps) => (ps[i].value = p.kind === 'string' ? val.value : +val.value)));
        }
        const del = h('button.btn.sm', { type: 'button', 'aria-label': `Remove parameter ${p.name}`, onClick: () => setParams((ps) => ps.splice(i, 1)) }, '×');
        params.append(h('tr', h('td', nm), h('td', kind), h('td', val), h('td', del)));
      });
    };
    renderParams();
    const script = (key, label) => {
      const ta = stop(h('textarea.input.gdl-script', { rows: 10, spellcheck: 'false', 'aria-label': label }, doc.get(sel).gdl?.[key] || ''));
      let timer = 0;
      ta.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(() => {
          const cur = doc.get(sel);
          update({ gdl: { ...cur.gdl, [key]: ta.value } }, 'Edit GDL script');
          check();
        }, 500);
      });
      // Editor commands (Archicad's GDL editor): comment, go to line, find and replace, the part's own GUID.
      const apply = (r) => {
        if (!r) return;
        ta.value = r.text;
        ta.setSelectionRange(r.start, r.end);
        ta.focus();
        ta.dispatchEvent(new Event('input'));
      };
      const select = (rng) => rng && (ta.focus(), ta.setSelectionRange(rng[0], rng[1]));
      const st = { find: '', repl: '' };
      const ask = (q, v) => window.prompt(q, v);
      const tb = h(
        'div.inline.gdl-tools',
        { style: { gap: '4px', flexWrap: 'wrap' } },
        h('button.btn.sm', { type: 'button', title: 'Comment the selected lines', onClick: () => apply(commentLines(ta.value, ta.selectionStart, ta.selectionEnd)) }, 'Comment'),
        h('button.btn.sm', { type: 'button', title: 'Uncomment the selected lines', onClick: () => apply(uncommentLines(ta.value, ta.selectionStart, ta.selectionEnd)) }, 'Uncomment'),
        h('button.btn.sm', { type: 'button', onClick: () => { const n = ask('Go to line', '1'); if (n) select(lineRange(ta.value, +n)); } }, 'Go to Line'),
        h('button.btn.sm', { type: 'button', onClick: () => { const q = ask('Find', st.find); if (q) (st.find = q), select(findNext(ta.value, q, ta.selectionEnd)); } }, 'Find'),
        h('button.btn.sm', { type: 'button', title: 'Find Again', onClick: () => select(findNext(ta.value, st.find, ta.selectionEnd)) }, 'Find Again'),
        h('button.btn.sm', { type: 'button', title: 'Find the selected text', onClick: () => { const q = ta.value.slice(ta.selectionStart, ta.selectionEnd); if (q) (st.find = q), select(findNext(ta.value, q, ta.selectionEnd)); } }, 'Find Selection'),
        h('button.btn.sm', { type: 'button', title: 'Replace Again', onClick: () => { if (!st.find) st.find = ask('Find', '') || ''; if (!st.repl) st.repl = ask('Replace with', '') ?? ''; apply(replaceNext(ta.value, st.find, st.repl, ta.selectionStart, ta.selectionEnd)); } }, 'Replace Again'),
        h('button.btn.sm', { type: 'button', title: "Insert this part's own GUID", onClick: () => { const cur = doc.get(sel); const g = cur.guid || partGuid(); if (!cur.guid) update({ guid: g }, 'Part GUID'); const s0 = ta.selectionStart; apply({ text: ta.value.slice(0, s0) + `"${g}"` + ta.value.slice(ta.selectionEnd), start: s0, end: s0 + g.length + 2 }); } }, 'Insert Own GUID'),
      );
      return h('label.field', h('span.field-label', label), tb, ta);
    };
    detail.append(
      h('div.row2', h('label.field', h('span.field-label', 'Name'), name), h('div.inline', { style: { gap: '6px' } }, ...size)),
      h('div.gdl-params', h('table.layers-table', h('thead', h('tr', h('th', 'Parameter'), h('th', 'Kind'), h('th', 'Value'), h('th', ''))), params),
        h('button.btn.sm', { type: 'button', onClick: () => setParams((ps) => ps.push({ name: `p${ps.length + 1}`, kind: 'length', value: 100 })) }, 'Add Parameter')),
      h('div.gdl-scripts', script('script3d', '3D Script'), script('script2d', '2D Script')),
      h('div.gdl-preview', planC, axoC),
      status,
      h('p.field-hint', 'Lengths are metres in the scripts, as in Archicad: A, B and ZZYZX are the width, depth and height. MATERIAL takes a material parameter, a material id or a colour such as "#8b5a2b". The assistant can write these scripts for you.'),
    );
    check();
  };
  renderList();
  renderDetail();
  return openDialog({
    title: 'GDL Objects',
    size: 'lg',
    className: 'gdl-dialog',
    body: h('div.gdl-editor', list, detail),
    actions: [
      { label: 'Close', value: null },
      { label: 'Place', primary: true, onClick: () => (sel ? (app.setCurrentType('component', sel), sel) : false) },
    ],
  }).then((id) => {
    if (id) app.run('component');
    return id;
  });
}
