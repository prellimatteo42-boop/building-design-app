/**
 * Structural commands: Load Categories, Load Combinations, Structural Link
 * (tool) and Create Structural Links, Structural Analytical Model Quality,
 * and the analytical display options (transparency, local axes).
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { analyticalModel, analyticalQuality, linksBetween } from '../core/analytical.js';
import { LOAD_CATEGORIES, STANDARDS, categoriesOf, combinationSettings, loadCombinations, caseNames } from '../core/structcombos.js';
import { levelElevation } from '../core/model.js';
import { PickPointsTool } from './drafting.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const select = (items, cur, label) => h('select.input', { 'aria-label': label }, ...items.map((it) => h('option', { value: it.value, selected: it.value === cur }, it.label)));
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

export function loadCategoriesDialog(app) {
  const cur = categoriesOf(app.doc.project);
  const rows = [
    ['live', 'Imposed loads (Q)'],
    ['snow', 'Snow (S)'],
    ['wind', 'Wind (W)'],
  ].map(([k, label]) => [k, label, select(LOAD_CATEGORIES.map((c) => ({ value: c.value, label: `${c.label}  (ψ ${c.psi.join(' / ')})` })), cur[k], label)]);
  const body = h('div', ...rows.map(([, label, s]) => field(label, s)), h('p.field-hint', 'Combination factors ψ0 / ψ1 / ψ2 from EN 1990 Table A1.1 (the same as NTC 2018). Permanent loads (G1 self weight, G2) have none.'));
  return openDialog({ title: 'Load Categories', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    app.commit('Load categories', () => app.doc.update('project', { loadCategories: Object.fromEntries(rows.map(([k, , s]) => [k, s.value])) }));
  });
}

export function loadCombinationsDialog(app) {
  const s = combinationSettings(app.doc.project);
  const used = [...new Set(analyticalModel(app.doc).loads.map((l) => l.loadCase))];
  const std = select(Object.entries(STANDARDS).map(([value, x]) => ({ value, label: `${x.label}: γG ${x.gG1}${x.gG2 !== x.gG1 ? ` / ${x.gG2}` : ''}, γQ ${x.gQ}` })), s.standard, 'Standard');
  const uls = h('input', { type: 'checkbox', checked: s.uls });
  const sls = h('input', { type: 'checkbox', checked: s.sls });
  const list = h('div');
  const settings = () => ({ ...s, standard: std.value, uls: uls.checked, sls: sls.checked });
  const show = () => {
    const combos = loadCombinations({ ...app.doc.project, loadCombinations: settings() }, used);
    const cases = ['G1', 'G2', 'Q', 'S', 'W'].filter((c) => combos.some((x) => c in x.factors));
    list.replaceChildren(
      h(
        'div',
        { style: { maxHeight: '40vh', overflow: 'auto' } },
        h('table.vg-table', h('thead', h('tr', h('th', 'Combination'), h('th', 'Kind'), ...cases.map((c) => h('th', c)))), h('tbody', ...combos.map((c) => h('tr', h('td', c.name), h('td', c.description), ...cases.map((k) => h('td', c.factors[k] != null ? String(c.factors[k]) : '')))))),
      ),
    );
  };
  for (const i of [std, uls, sls]) i.addEventListener('change', show);
  show();
  const names = Object.entries(caseNames(app.doc.get('project'))).filter(([k]) => k === 'self' || used.includes(k)).map(([, n]) => n).join(', ');
  const body = h('div', field('Partial factors', std), h('div.inline', { style: { gap: '16px', margin: '6px 0' } }, h('label.check', uls, 'Ultimate (ULS, STR set B)'), h('label.check', sls, 'Serviceability (characteristic, frequent, quasi-permanent)')), h('p.field-hint', `From the load cases in the model: ${names}. Exported with the analytical model in SAF.`), list);
  return openDialog({ title: 'Load Combinations', body, size: 'lg', actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    app.commit('Load combinations', () => app.doc.update('project', { loadCombinations: settings() }));
  });
}

/** Create Structural Links between the nearest analytical nodes of the selected structural elements. */
export function createStructuralLinks(app) {
  const ids = [...app.selection];
  if (ids.length < 2) return app.toast('Select two or more structural elements to link.', { kind: 'error' });
  const model = analyticalModel(app.doc);
  const links = linksBetween(model, ids);
  if (!links.length) return app.toast('No pair of the selected elements is apart and close enough to link (within 1.5 m), or they already share a node.', { kind: 'error' });
  const level = app.doc.get(ids.find((id) => app.doc.get(id)?.levelId))?.levelId || app.doc.levels()[0]?.id;
  app.commit('Create structural links', () => links.forEach((l) => app.doc.add({ ...l, levelId: level })));
  app.toast(`Created ${plural(links.length, 'structural link')}.`, { kind: 'success' });
}

/** Structural Link tool: two clicks in plan, each taken to the nearest analytical node on the story. */
export function structuralLinkTool(app) {
  return new PickPointsTool(app, {
    n: 2,
    title: 'Structural Link',
    prompts: ['Click near the first node', 'Click near the second node'],
    done: ([p, q]) => {
      const lv = app.activeView?.levelId;
      if (!lv) return app.toast('Draw links in a floor plan.', { kind: 'error' });
      const z0 = levelElevation(app.doc, lv) - 100;
      const above = app.doc.levelAbove?.(lv);
      const z1 = (above ? levelElevation(app.doc, above.id) : z0 + 100000) + 100;
      const nodes = analyticalModel(app.doc).nodes.filter((n) => n.p[2] >= z0 && n.p[2] <= z1);
      const nearest = (pt) => nodes.reduce((b, n) => {
        const d = Math.hypot(n.p[0] - pt[0], n.p[1] - pt[1]) - n.p[2] * 1e-6;
        return !b || d < b.d ? { d, n } : b;
      }, null);
      const a = nearest(p);
      const b = nearest(q);
      if (!a || !b || a.n === b.n || a.d > 1000 || b.d > 1000) return app.toast('Click near two different analytical nodes on this story.', { kind: 'error' });
      app.commit('Structural link', () => app.doc.add({ kind: 'structuralLink', levelId: lv, a: a.n.p, b: b.n.p, hinge: 'none' }));
    },
  });
}

export function analyticalQualityDialog(app) {
  const model = analyticalModel(app.doc);
  const problems = analyticalQuality(model);
  const body = problems.length
    ? h(
        'div',
        h('p', `${plural(problems.length, 'problem')} in the analytical model (${plural(model.members.length, 'member')}, ${plural(model.surfaces.length, 'surface')}, ${plural(model.nodes.length, 'node')}).`),
        h(
          'div',
          { style: { maxHeight: '50vh', overflow: 'auto' } },
          h('table.vg-table', h('tbody', ...problems.map((p) => h('tr', h('td', p.message), h('td', p.ids.length ? h('button.btn.sm', { type: 'button', onClick: () => app.select(p.ids) }, 'Select') : ''))))),
        ),
      )
    : h('p', 'No problems found: every member is connected, long enough and has a section, and the model has supports.');
  return openDialog({ title: 'Structural Analytical Model Quality', body, actions: [{ label: 'Close', value: null }] });
}

export const DISPLAY_DEFAULTS = { physical: true, members2d: true, symbols: false, axes: false, nodes: true, releases: true, profiles: false };

export function toggleDisplay(app, key) {
  const cur = { ...DISPLAY_DEFAULTS, ...(app.settings.analyticalDisplay || {}) };
  cur[key] = !cur[key];
  app.settingsStore.set('analyticalDisplay', cur);
  app.requestRender();
}

export const displayOn = (app, key) => !!{ ...DISPLAY_DEFAULTS, ...(app.settings.analyticalDisplay || {}) }[key];
