/** Teamwork through a team server: connect, share the open project or join one, see who is on it. */
import { h, clear } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { TeamSession } from '../io/teamclient.js';

const KEY = 'bd-team';
const remembered = () => {
  try {
    return JSON.parse(localStorage.getItem(KEY) || '{}');
  } catch {
    return {};
  }
};
const remember = (v) => {
  try {
    localStorage.setItem(KEY, JSON.stringify(v));
  } catch {
    // Only a convenience: the fields start empty next time.
  }
};
const here = () => (/^(localhost|127\.)/.test(location.hostname) || location.protocol === 'https:' ? '' : location.origin);

/** Offers the machine this app runs on as the team's server. Only the packaged app can do it. */
async function hostHere(result) {
  try {
    const res = await fetch('./api/team-host', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    if (!res.ok) throw new Error('unavailable');
    const out = await res.json();
    clear(result);
    result.append(h('p.dialog-text', 'Others on your network open one of these addresses in their browser and enter the team code:'), ...out.urls.map((u) => h('div', h('code', u))), h('div', h('strong', `Team code: ${out.code}`)));
    return out;
  } catch {
    clear(result);
    result.append(h('p.field-hint', 'This copy cannot be a server: it needs the Building Design application, or the command npm run teamwork.'));
    return null;
  }
}

export function teamServerDialog(app) {
  const saved = remembered();
  const input = (label, value, type = 'text') => {
    const el = h('input.input', { type, value: value || '', 'aria-label': label });
    return { el, row: h('label.field', h('span.field-label', label), el) };
  };
  const server = input('Server address', saved.server || here() || 'http://');
  const code = input('Team code', saved.code || '', 'password');
  const user = input('Your name', saved.user || app.user?.username || '');
  const list = h('div');
  const hostResult = h('div');
  const connect = () => {
    if (!server.el.value.trim() || !code.el.value.trim() || !user.el.value.trim()) {
      toast('Fill in the server address, the team code and your name.', { kind: 'error' });
      return null;
    }
    remember({ server: server.el.value.trim(), code: code.el.value.trim(), user: user.el.value.trim() });
    return new TeamSession(app, { server: server.el.value.trim(), code: code.el.value.trim(), user: user.el.value.trim() });
  };
  const close = (ev) => {
    const d = ev.target.closest('dialog');
    d?.close();
    d?.remove();
  };
  const go = async (session, fn, ev, message) => {
    app.team?.leave();
    try {
      await fn(session);
      toast(message, { kind: 'success' });
      close(ev);
    } catch (err) {
      toast(err.message || 'The team server did not answer.', { kind: 'error' });
    }
  };
  const refresh = async () => {
    const session = connect();
    if (!session) return;
    clear(list);
    try {
      const all = await session.projects();
      if (!all.length) list.append(h('p.field-hint', 'No shared projects yet.'));
      for (const p of all) {
        list.append(h('div', { style: 'display:flex;gap:8px;align-items:center;padding:3px 0' }, h('span', { style: 'flex:1' }, `${p.name} (${p.elements} elements${p.people.length ? `, ${p.people.join(', ')}` : ''})`), h('button.btn.sm', { type: 'button', onClick: (ev) => go(connect(), (s) => s.join(p.id), ev, `Joined ${p.name}.`) }, 'Join')));
      }
    } catch (err) {
      list.append(h('p.field-hint', err.message));
    }
  };
  const share = (ev) => {
    const s = connect();
    if (s) go(s, (x) => x.publish(app.projectName?.() || app.file?.name || 'Project'), ev, 'The project is shared. Others can join it now.');
  };
  return openDialog({
    title: 'Team Server',
    body: h('div', { style: 'display:flex;flex-direction:column;gap:8px;min-width:min(460px,86vw)' },
      server.row, code.row, user.row,
      h('div', { style: 'display:flex;gap:6px' }, h('button.btn', { type: 'button', onClick: refresh }, 'Show Projects'), h('button.btn', { type: 'button', onClick: share }, 'Share This Project')),
      list,
      h('hr'),
      h('button.btn', { type: 'button', onClick: () => hostHere(hostResult) }, 'Make This Computer the Server'),
      hostResult),
    actions: [{ label: 'Close', value: null }],
  });
}

/** Who is on the project, and leaving it. */
export function teamPeopleDialog(app) {
  const t = app.team;
  if (!t?.active) return teamServerDialog(app);
  const body = h('div', h('p.dialog-text', `Project: ${t.project.name}. You are ${t.user}.`), h('ul', t.people.map((p) => h('li', p))));
  return openDialog({ title: 'On This Project', body, actions: [{ label: 'Leave Project', value: 'leave' }, { label: 'Close', value: null }] }).then((v) => {
    if (v === 'leave') t.leave();
  });
}
