/**
 * Design menu dialogs: Trim Elements to Roof/Shell (which parts go) and
 * Crop to Single-plane Roof, Cut Additional Element with Opening
 * (core/rooftrim.js).
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { TRIM_MODES, cutWithOpenings } from '../core/rooftrim.js';

const field = (label, control) => h('label.field', h('span.field-label', label), control);
const ok = [{ label: 'Cancel', value: null }, { label: 'Trim', primary: true, value: 'ok' }];

export function trimToRoof(app) {
  const sel = h('select.input', {}, TRIM_MODES.map((m) => h('option', { value: m.value }, m.label)));
  const note = h('p.muted', 'Select the elements with the roofs or shells to trim them to; with none selected, the roof above each element is used. Walls and columns under a roof follow its underside.');
  return openDialog({ title: 'Trim Elements to Roof/Shell', body: h('div', [field('Trim', sel), note]), actions: ok }).then((r) => {
    if (r === 'ok') app.attachTop(true, sel.value);
  });
}

export function cropToRoofPlane(app) {
  return app.attachTop(true, 'plane');
}

/**
 * The openings (holes) of the selected slab, roof or ceiling also cut the
 * other selected elements.
 */
export function cutAdditional(app) {
  const sel = [...app.selection].map((id) => app.doc.get(id)).filter(Boolean);
  const host = sel.find((el) => ['floor', 'ceiling', 'roof'].includes(el.kind) && el.holes?.length);
  if (!host) return toast('Select a slab, roof or ceiling with openings, and the elements they should cut.', { kind: 'error' });
  const others = sel.filter((el) => el !== host).map((el) => el.id);
  if (!others.length) return toast('Select the elements to cut together with the element that has the openings.', { kind: 'error' });
  let n = 0;
  app.commit('Cut additional elements with opening', () => (n = cutWithOpenings(app.doc, host.id, others)));
  toast(n ? `The openings now cut ${n} more element${n === 1 ? '' : 's'}.` : 'None of the selected elements can be cut.', { kind: n ? 'success' : 'error' });
}
