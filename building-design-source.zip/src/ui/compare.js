/**
 * Model Compare palette: compare the open project with a saved project
 * file or with a baseline taken earlier in this session; list what is new,
 * deleted and modified, show an element, and colour the changes in the
 * views (new green, modified orange).
 */
import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { toast } from './dialog.js';
import { Doc } from '../core/doc.js';
import { compareDocs, compareSummary } from '../core/compare.js';
import { decodeProject } from '../io/native.js';
import { pickFile } from '../io/files.js';

export class ComparePalette {
  constructor(app) {
    this.app = app;
    this.el = null;
    this.base = null;
    this.baseName = '';
    this.diff = null;
    this.tab = 'modified';
  }

  get open() {
    return !!this.el;
  }

  toggle() {
    if (this.el) return this.close();
    this.el = h('section.quick-layers.compare-palette', { role: 'dialog', 'aria-label': 'Model Compare' });
    document.body.append(this.el);
    this.render();
  }

  close() {
    this.el?.remove();
    this.el = null;
    this.setHighlight(null);
  }

  /** Changes coloured in the views: { added: Set, modified: Set } or null. */
  setHighlight(diff) {
    const app = this.app;
    app.compareHighlight = diff ? { added: new Set(diff.added.map((d) => d.id)), modified: new Set(diff.modified.map((d) => d.id)) } : null;
    app.flagsVersion++;
    app.requestRender();
  }

  baseline() {
    this.base = Doc.fromJSON(JSON.parse(JSON.stringify(this.app.doc.toJSON())));
    this.baseName = `Baseline at ${new Date().toTimeString().slice(0, 5)}`;
    this.diff = null;
    this.setHighlight(null);
    toast('Baseline taken. Work on, then Compare.', { kind: 'success' });
    this.render();
  }

  async fromFile() {
    const f = await pickFile('.bdp,.json,application/json,application/octet-stream');
    if (!f) return;
    try {
      this.base = await decodeProject(await f.arrayBuffer());
      this.baseName = f.name;
      this.run();
    } catch (err) {
      toast(err.message || 'That file could not be read.', { kind: 'error' });
    }
  }

  run() {
    if (!this.base) return;
    this.diff = compareDocs(this.base, this.app.doc);
    this.setHighlight(this.diff);
    this.tab = this.diff.modified.length ? 'modified' : this.diff.added.length ? 'added' : 'removed';
    this.render();
  }

  render() {
    const el = this.el;
    if (!el) return;
    clear(el);
    el.append(h('div.ql-head', h('span.ql-title', icon('layers', 15), 'Model Compare'), h('button.icon-btn.sm', { type: 'button', 'aria-label': 'Close Model Compare', onClick: () => this.close() }, icon('x', 14))));
    el.append(
      h(
        'div.ql-actions',
        h('button.btn.sm', { type: 'button', onClick: () => this.fromFile() }, icon('folder', 14), h('span', 'Compare with File...')),
        h('button.btn.sm', { type: 'button', onClick: () => this.baseline() }, icon('plus', 14), h('span', 'Take Baseline')),
        h('button.btn.sm', { type: 'button', disabled: !this.base, onClick: () => this.run() }, icon('refresh', 14), h('span', 'Compare')),
      ),
    );
    if (!this.base) return el.append(h('p.field-hint', 'Compare this project with a saved project file, or take a baseline now and compare after you work.'));
    el.append(h('p.field-hint', `Against: ${this.baseName}`));
    const d = this.diff;
    if (!d) return;
    const total = d.added.length + d.removed.length + d.modified.length;
    if (!total) return el.append(h('p.field-hint', 'No differences.'));
    const tabs = h('div.cmp-tabs', { role: 'tablist' });
    for (const [k, label] of [['modified', 'Modified'], ['added', 'New'], ['removed', 'Deleted']])
      tabs.append(h('button.cmp-tab', { type: 'button', role: 'tab', 'aria-selected': String(this.tab === k), 'data-kind': k, onClick: () => ((this.tab = k), this.render()) }, `${label} ${d[k].length}`));
    const list = h('ul.ql-list.cmp-list');
    let group = null;
    for (const it of d[this.tab]) {
      if (it.group !== group) {
        group = it.group;
        list.append(h('li.cmp-group', group));
      }
      const what = it.classes ? [...it.classes].join(', ') : '';
      list.append(
        h(
          'li',
          h(
            'button.file-item.cmp-item',
            { type: 'button', disabled: this.tab === 'removed', 'data-tip': it.fields ? `Changed: ${it.fields.join(', ')}` : null, onClick: () => this.app.showElements([it.id]) },
            h('span.file-name', it.label),
            what ? h('span.file-meta', what) : null,
          ),
        ),
      );
    }
    const summary = compareSummary(d)
      .map((s) => `${s.group}: ${[s.added && `+${s.added}`, s.removed && `-${s.removed}`, s.modified && `~${s.modified}`].filter(Boolean).join(' ')}`)
      .join(' · ');
    el.append(tabs, list, h('p.field-hint', summary));
  }
}
