/**
 * Edit menu commands: Invert Wall Direction, Modify Wall Reference Line,
 * Relink Home Story, Unlock All, Suspend Groups, Select Duplicates, Adjust
 * Elements to Slabs and Edit Elements by Stories (core/editextras*.js).
 */
import { h } from './dom.js';
import { isView } from '../core/doc.js';
import { openDialog, toast } from './dialog.js';
import { invertWallDirection, modifyReferenceLine, relinkHomeStory, unlockAll, REFERENCE_LINES } from '../core/editextras.js';
import { adjustToSlabs, deleteOnStories, duplicateIds, ADJUST_TO } from '../core/editextras2.js';

const field = (label, control) => h('label.field', h('span.field-label', label), control);
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const selected = (app, kinds) => [...app.selection].map((id) => app.doc.get(id)).filter((el) => el && (!kinds || kinds.includes(el.kind)));
const ok = [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }];

export function invertWalls(app) {
  const walls = selected(app, ['wall']);
  if (!walls.length) return toast('Select walls first.', { kind: 'error' });
  app.commit('Invert wall direction', () => walls.forEach((w) => invertWallDirection(app.doc, w.id)));
  toast(`${plural(walls.length, 'wall')} inverted; the reference lines stay in place.`, { kind: 'success' });
}

export function wallReferenceLine(app) {
  const walls = selected(app, ['wall']);
  if (!walls.length) return toast('Select walls first.', { kind: 'error' });
  const sel = h('select.input', {}, REFERENCE_LINES.map((r) => h('option', { value: r.value, selected: r.value === (walls[0].locationLine || 'center') }, r.label)));
  return openDialog({ title: 'Modify Wall Reference Line', body: h('div', h('p.field-hint', {}, 'The reference line moves; the walls stay where they are.'), field('Reference line', sel)), actions: ok }).then((r) => {
    if (r !== 'ok') return;
    let n = 0;
    app.commit('Modify wall reference line', () => walls.forEach((w) => modifyReferenceLine(app.doc, w.id, sel.value) && n++));
    toast(`${plural(n, 'wall')} changed.`, { kind: 'success' });
  });
}

export function relinkStory(app) {
  const els = selected(app).filter((el) => el.levelId && !el.hostId);
  if (!els.length) return toast('Select elements on a story first.', { kind: 'error' });
  const sel = h('select.input', {}, app.doc.levels().map((l) => h('option', { value: l.id, selected: l.id === els[0].levelId }, `${l.name} (${Math.round(l.elevation)} mm)`)));
  return openDialog({ title: 'Relink Home Story', body: h('div', h('p.field-hint', {}, 'The elements belong to the chosen story and keep their height.'), field('Home story', sel)), actions: ok }).then((r) => {
    if (r !== 'ok') return;
    let n = 0;
    app.commit('Relink home story', () => els.forEach((el) => relinkHomeStory(app.doc, el.id, sel.value) && n++));
    toast(`${plural(n, 'element')} relinked.`, { kind: 'success' });
  });
}

export function unlockEverything(app) {
  let n = 0;
  app.commit('Unlock all', () => (n = unlockAll(app.doc)));
  toast(n ? `${plural(n, 'element')} unlocked.` : 'Nothing was locked.', { kind: n ? 'success' : 'info' });
}

export function toggleSuspendGroups(app) {
  app.settingsStore.set('suspendGroups', !app.settings.suspendGroups);
  toast(app.settings.suspendGroups ? 'Groups suspended: clicks pick single elements.' : 'Groups active again.');
  app.requestRender();
}

export function selectDuplicates(app) {
  const ids = duplicateIds(app.doc, app.scene);
  if (!ids.length) return toast('No duplicated elements.', { kind: 'success' });
  app.select(ids);
  toast(`${plural(ids.length, 'duplicate')} selected (the first of each stays): Delete removes them.`);
}

export function adjustElementsToSlabs(app) {
  const els = selected(app, ['wall', 'column']);
  if (!els.length) return toast('Select walls or columns first.', { kind: 'error' });
  const sel = h('select.input', {}, ADJUST_TO.map((a) => h('option', { value: a.value }, a.label)));
  return openDialog({ title: 'Adjust Elements to Slabs', body: h('div', field('Adjust', sel)), actions: ok }).then((r) => {
    if (r !== 'ok') return;
    let n = 0;
    app.commit('Adjust elements to slabs', () => (n = adjustToSlabs(app.doc, els.map((e) => e.id), sel.value)));
    toast(n ? `${plural(n, 'element')} adjusted.` : 'No slab found on that side of the selected elements.', { kind: n ? 'success' : 'error' });
  });
}

export function editByStories(app) {
  const doc = app.doc;
  const levels = doc.levels();
  const kinds = [...new Set(doc.filter((x) => x.levelId && !String(x.kind).endsWith('Type') && !isView(x) && x.kind !== 'level').map((x) => x.kind))].sort();
  const lv = levels.map((l) => ({ l, cb: h('input', { type: 'checkbox' }) }));
  const ks = kinds.map((k) => ({ k, cb: h('input', { type: 'checkbox' }) }));
  const op = h('select.input', {}, [h('option', { value: 'copy' }, 'Copy the copied elements to these stories'), h('option', { value: 'delete' }, 'Delete elements of these kinds on these stories')]);
  const list = (items, label) => h('div', { style: 'max-height:200px;overflow:auto' }, items.map((x) => h('label', { style: 'display:flex;gap:6px;align-items:center' }, x.cb, label(x))));
  const body = h('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:12px' }, [
    h('div', [h('strong', 'Stories'), list(lv, (x) => x.l.name)]),
    h('div', [h('strong', 'Kinds (for Delete)'), list(ks, (x) => x.k)]),
    h('div', { style: 'grid-column:1/3' }, field('Operation', op)),
  ]);
  return openDialog({ title: 'Edit Elements by Stories', body, actions: ok }).then((r) => {
    if (r !== 'ok') return;
    const ids = lv.filter((x) => x.cb.checked).map((x) => x.l.id);
    if (!ids.length) return toast('Choose stories.', { kind: 'error' });
    if (op.value === 'copy') return app.pasteToLevels(ids);
    const chosen = ks.filter((x) => x.cb.checked).map((x) => x.k);
    if (!chosen.length) return toast('Choose the kinds to delete.', { kind: 'error' });
    let n = 0;
    app.commit('Delete by stories', () => (n = deleteOnStories(doc, ids, chosen)));
    toast(`${plural(n, 'element')} deleted.`, { kind: 'success' });
  });
}

export function deleteDuplicates(app) {
  const ids = duplicateIds(app.doc, app.scene);
  if (!ids.length) return toast('No duplicated elements.', { kind: 'success' });
  app.commit('Delete duplicates', () => ids.forEach((id) => app.doc.has(id) && app.doc.remove(id)));
  app.select([]);
  toast(`${plural(ids.length, 'duplicate')} deleted (the first of each stays).`, { kind: 'success' });
}
