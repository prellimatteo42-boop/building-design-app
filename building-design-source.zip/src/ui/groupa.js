/**
 * Small Archicad commands: Element Transfer Settings, True Fill Appearance, Distance Guide Options, Show Z in
 * Tracker, Show in Library Manager and Import RAL Colors (a colour table file as materials).
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { TRANSFER_DEFAULTS } from '../editor/modify.js';
import { FILL_LOOK } from '../core/plan.js';
import { GUIDES } from '../editor/tempdims.js';
import { archicadLibraryDialog } from './aclibrary.js';

export function transferSettings(app) {
  const s = { ...TRANSFER_DEFAULTS, ...(app.settings.transfer || {}) };
  const rows = [['type', 'Type (structure, family)'], ['layer', 'Layer'], ['heights', 'Heights, offsets and sizes'], ['parameters', 'Parameters and options (GDL values, location line, structural)'], ['surfaces', 'Surfaces (paint and material)']].map(([k, l]) => [k, h('input', { type: 'checkbox', checked: !!s[k] }), l]);
  const body = h('div', h('p.field-hint', 'What Pick Up and Inject Parameters (Match Type) carry from the source element. Geometry and position never move.'), ...rows.map(([, cb, l]) => h('label.check', cb, l)));
  return openDialog({ title: 'Element Transfer Settings', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r === 'ok') app.settingsStore.set('transfer', Object.fromEntries(rows.map(([k, cb]) => [k, cb.checked])));
  });
}

export function toggleTrueFills(app) {
  app.settingsStore.set('simplifiedFills', !app.settings.simplifiedFills);
  applyGroupA(app);
  app.scene?.plans?.clear();
  app.requestRender();
}

export function toggleGuide(app, key) {
  const g = { ...(app.settings.distGuides || {}) };
  g[key] = !g[key];
  app.settingsStore.set('distGuides', g);
  applyGroupA(app);
  app.requestRender();
}

export function applyGroupA(app) {
  FILL_LOOK.simplified = !!app.settings.simplifiedFills;
  Object.assign(GUIDES, { refLines: false, center: false }, app.settings.distGuides || {});
}

export function showInLibrary(app) {
  const el = [...app.selection].map((id) => app.doc.get(id)).find((x) => x?.typeId);
  const type = el && app.doc.get(el.typeId);
  if (!type?.gdl?.source) return app.toast('Select an object placed from an Archicad library.', { kind: 'error' });
  archicadLibraryDialog(app, { find: type.name });
  app.toast(`${type.name} comes from ${type.gdl.source}.`);
}

/** Read a colour table: lines "RAL 3020 Traffic red #CC0605" or "RAL 3020;Traffic red;204;6;5" (CSV or text). */
export function readColorTable(text) {
  const out = [];
  for (const raw of String(text).split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#') && !/#[0-9a-f]{6}/i.test(line.slice(1))) continue;
    const hex = /#([0-9a-f]{6})\b/i.exec(line);
    let rgb = null;
    let name = line;
    if (hex) {
      const n = parseInt(hex[1], 16);
      rgb = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
      name = line.replace(hex[0], '');
    } else {
      const parts = line.split(/[;,\t]/).map((x) => x.trim());
      const nums = parts.filter((x) => /^\d{1,3}$/.test(x)).map(Number);
      if (nums.length < 3 || nums.slice(-3).some((v) => v > 255)) continue;
      rgb = nums.slice(-3);
      name = parts.filter((x) => !/^\d{1,3}$/.test(x)).join(' ');
    }
    name = name.replace(/[;,\t]+/g, ' ').replace(/\s+/g, ' ').trim();
    if (name) out.push({ name, color: `#${rgb.map((v) => v.toString(16).padStart(2, '0')).join('')}` });
  }
  return out;
}

export function importColors(app) {
  const input = h('input', { type: 'file', accept: '.csv,.txt,.tsv' });
  input.addEventListener('change', async () => {
    const f = input.files?.[0];
    if (!f) return;
    const colors = readColorTable(await f.text());
    if (!colors.length) return app.toast('No colours found: lines need a name and #RRGGBB or R;G;B.', { kind: 'error' });
    const have = new Set(app.doc.all('material').map((m) => m.name));
    let n = 0;
    app.commit('Import colours', () => {
      for (const c of colors) {
        if (have.has(c.name)) continue;
        app.doc.add({ kind: 'material', name: c.name, color: c.color, cut: 'none', opacity: 1 });
        n++;
      }
    });
    app.toast(`${n} colour${n === 1 ? '' : 's'} added as materials${colors.length - n ? ` (${colors.length - n} already there)` : ''}.`, { kind: 'success' });
  });
  input.click();
}
