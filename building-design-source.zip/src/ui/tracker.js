/**
 * The Tracker (Archicad's): a small box by the cursor while a drawing tool
 * is active in a plan, with the cursor's coordinates — X and Y from the user
 * origin before the first point, then the distance and angle (or dX and dY)
 * from the last point. Typing a number (or Tab) edits them: Tab moves to the
 * next field, Enter places the point exactly there, as a click would.
 */
import { h, clear } from './dom.js';
import { trackerValues, trackerPoint, draftingOf } from '../core/drafting.js';
import { formatLength, parseLength, formatAngle, parseAngleDegrees } from '../core/units.js';

const FIELDS = {
  absolute: [
    ['x', 'X'],
    ['y', 'Y'],
  ],
  xy: [
    ['dx', 'ΔX'],
    ['dy', 'ΔY'],
  ],
  polar: [
    ['r', 'r'],
    ['angle', 'a'],
  ],
};

export class Tracker {
  constructor(app) {
    this.app = app;
    this.el = h('div.tracker', { role: 'group', 'aria-label': 'Tracker', hidden: true });
    app.shell.canvasWrap.append(this.el);
    this.editing = false;
  }

  get enabled() {
    return this.app.settings.tracker !== false && this.app.settings.drawingAids !== false;
  }

  /** The tool that is drawing in a plan, or null. */
  drawingTool() {
    const t = this.app.tool;
    if (!t || t === this.app.selectTool || !this.app.vc?.is2D || this.app.activeView?.kind === 'sheet') return null;
    return t;
  }

  context() {
    const t = this.drawingTool();
    const origin = this.app.settings.trackerProjectZero ? [0, 0] : draftingOf(this.app.doc.project).userOrigin;
    const mode = this.app.settings.trackerMode || 'polar';
    return { t, from: t?.lastFrom || null, origin, mode };
  }

  /** Follow the cursor (called on every pointer move). */
  update(ev) {
    if (this.editing) return;
    const { t, from, origin, mode } = this.context();
    if (!this.enabled || !t || !ev?.p) {
      this.el.hidden = true;
      return;
    }
    const p = t.snapRes?.point || ev.p;
    this.last = { x: ev.x, y: ev.y };
    const v = trackerValues(p, { from, origin, mode });
    this.render(v, false);
    this.place(ev.x, ev.y);
  }

  hide() {
    if (!this.editing) this.el.hidden = true;
  }

  place(x, y) {
    const wrap = this.app.shell.canvasWrap;
    this.el.style.left = `${Math.min(x + 18, wrap.clientWidth - 190)}px`;
    this.el.style.top = `${Math.min(y + 18, wrap.clientHeight - 70)}px`;
    this.el.hidden = false;
  }

  fmt(key, value) {
    if (key === 'angle') return formatAngle((value * Math.PI) / 180, 2, this.app.doc.units);
    return formatLength(value, this.app.doc.units);
  }

  render(v, edit) {
    clear(this.el);
    this.inputs = [];
    for (const [key, label] of FIELDS[v.kind]) {
      if (edit) {
        const inp = h('input.input.sm', { type: 'text', value: '', placeholder: this.fmt(key, v[key]), 'aria-label': label, spellcheck: 'false', autocomplete: 'off' });
        inp.dataset.key = key;
        this.inputs.push(inp);
        this.el.append(h('label.tracker-row', h('span.tracker-k', label), inp));
      } else this.el.append(h('div.tracker-row', h('span.tracker-k', label), h('span.tracker-v', this.fmt(key, v[key]))));
    }
    // Show Z in Tracker: the height the point lands at (the editing plane in 3D, the story in plans).
    if (this.app.settings.trackerZ && !edit) {
      const c = this.app.vc;
      const z = c?.planeZ ? c.planeZ() : this.app.doc.get(this.app.activeLevelId())?.elevation ?? 0;
      this.el.append(h('div.tracker-row', h('span.tracker-k', 'Z'), h('span.tracker-v', this.fmt('z', z))));
    }
    this.values = v;
  }

  /** Start typing coordinates; first is the key that opened it (a digit, '-', '.') or null for Tab. */
  edit(first) {
    const { t, from, origin, mode } = this.context();
    if (!this.enabled || !t) return false;
    const p = t.snapRes?.point || this.app.lastPointer?.p || [0, 0];
    const v = trackerValues(p, { from, origin, mode });
    this.editing = true;
    this.render(v, true);
    const at = this.last || { x: 40, y: 40 };
    this.place(at.x, at.y);
    const [a, b] = this.inputs;
    for (const inp of this.inputs)
      inp.addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Escape') {
          e.preventDefault();
          this.stop();
        } else if (e.key === 'Tab') {
          e.preventDefault();
          (inp === a ? b : a).focus();
        } else if (e.key === 'Enter') {
          e.preventDefault();
          this.submit(from, origin);
        }
      });
    a.focus();
    if (first) a.value = first;
    return true;
  }

  stop() {
    this.editing = false;
    this.el.hidden = true;
    this.app.viewport.overlay.focus({ preventScroll: true });
  }

  /** Read the fields (an empty one keeps the cursor's value), place the point. */
  submit(from, origin) {
    const v = { ...this.values };
    for (const inp of this.inputs) {
      const raw = inp.value.trim();
      if (!raw) continue;
      const key = inp.dataset.key;
      const n = key === 'angle' ? parseAngleDegrees(raw, this.app.doc.units) : parseLength(raw, this.app.doc.units);
      if (!Number.isFinite(n)) {
        inp.setAttribute('aria-invalid', 'true');
        return;
      }
      v[key] = n;
    }
    const p = trackerPoint(v, { from, origin });
    this.stop();
    this.place_point(p);
  }

  /** Give the tool the point as a click there, without snapping. */
  place_point(p) {
    const s = this.app.vc.modelToScreen(p);
    const ev = { p, x: s.x, y: s.y, exact: true, shift: false, alt: false, ctrl: false, button: 0 };
    this.app.toolEvent('move', ev);
    this.app.toolEvent('down', ev);
    this.app.toolEvent('up', ev);
    // A move after the click: the tool now measures from this point (the next typed point is relative to it).
    this.app.toolEvent('move', ev);
    this.update(ev);
  }
}
