/**
 * View control bar (bottom of the view): scale, detail level, visual style,
 * thin lines, section box, perspective, temporary hide/isolate and reveal
 * hidden elements, depending on the kind of view.
 */
import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { showMenu } from './menu.js';
import { scaleOptions, scaleLabel } from '../core/units.js';
import { isPlanView } from '../core/doc.js';
import { TEMPLATE_KEYS } from '../core/graphics.js';
import { phaseFilters } from '../core/phases.js';
import { STRUCTURE_DISPLAY } from '../core/layerjoins.js';
import { PEN_SETS } from '../core/props.js';

const STYLES = [
  ['wireframe', 'Wireframe', 'styleWire'],
  ['hidden', 'Hidden Line', 'styleHidden'],
  ['shaded', 'Shaded', 'styleShaded'],
  ['consistent', 'Consistent Colors', 'styleConsistent'],
  ['realistic', 'Realistic', 'styleRealistic'],
];

const DETAILS = [
  ['coarse', 'Coarse', 'detailCoarse'],
  ['medium', 'Medium', 'detailMedium'],
  ['fine', 'Fine', 'detailFine'],
];

export function renderViewbar(app) {
  const bar = app.shell.viewbar;
  clear(bar);
  const view = app.activeView;
  if (!view || !app.doc) return;
  const set = (patch, label) => {
    const tpl = view.templateId && app.doc.get(view.templateId);
    if (tpl && Object.keys(patch).some((k) => TEMPLATE_KEYS.includes(k))) return app.toast(`The view template "${tpl.name}" controls this setting. Change the template, or remove it in the view's properties.`, { kind: 'error' });
    app.commit(label, () => app.doc.update(view.id, patch));
  };
  const btn = (content, label, onClick, pressed = null, extra = {}) =>
    h('button.vb-btn', { type: 'button', 'aria-label': label, 'data-tip': label, 'aria-pressed': pressed == null ? null : String(pressed), 'aria-haspopup': extra.menu ? 'menu' : null, onClick, ...extra.attrs }, content);
  const sep = () => h('span.vb-sep');
  const graphical = !['schedule', 'sheet'].includes(view.kind);
  if (view.scale && view.kind !== 'view3d') {
    bar.append(
      btn(
        [h('span', scaleLabel(view.scale, app.doc.units)), icon('chevron-up', 12)],
        `View scale ${scaleLabel(view.scale, app.doc.units)}`,
        (e) => showMenu(e.currentTarget, scaleOptions(app.doc.units).map((o) => ({ label: o.label, checked: o.value === view.scale, radio: true, action: () => set({ scale: o.value }, 'View scale') })), { label: 'View scale' }),
        null,
        { menu: true },
      ),
    );
  }
  if (graphical) {
    const d = DETAILS.find((x) => x[0] === (view.detail || 'medium')) || DETAILS[1];
    bar.append(
      btn(icon(d[2], 16), `Detail level: ${d[1]}`, (e) => showMenu(e.currentTarget, DETAILS.map(([v, l, ic]) => ({ label: l, icon: ic, checked: view.detail === v, radio: true, action: () => set({ detail: v }, 'Detail level') })), { label: 'Detail level' }), null, { menu: true }),
    );
    // The view's layer combination (core/layers.js).
    const combo = view.layerComboId ? app.doc.get(view.layerComboId) : null;
    const pickCombo = (id) => {
      set({ layerComboId: id }, 'Layer combination');
      renderViewbar(app);
    };
    bar.append(
      btn(
        [icon('worksets', 16), h('span', combo ? combo.name : 'Custom')],
        `Layer combination: ${combo ? combo.name : 'Custom'}`,
        (e) =>
          showMenu(
            e.currentTarget,
            [
              { label: 'Custom (layer settings)', checked: !combo, radio: true, action: () => pickCombo(null) },
              ...app.doc.all('layerCombo').map((c) => ({ label: c.name, checked: combo?.id === c.id, radio: true, action: () => pickCombo(c.id) })),
              { separator: true },
              { label: 'Layer Settings...', icon: 'worksets', action: () => app.run('layerSettings') },
              { label: 'Quick Layers', icon: 'worksets', action: () => app.run('quickLayers') },
              { label: 'Trace & Reference', icon: 'layers', action: () => app.run('traceReference') },
            ],
            { label: 'Layer combination' },
          ),
        null,
        { menu: true },
      ),
    );
    // Pen set of 2D views (Archicad's Quick Options; renderer2d.js).
    if (app.workspace?.on && view.kind !== 'view3d') {
      const ps = PEN_SETS.find((x) => x.value === (view.penSet || 'color')) || PEN_SETS[0];
      bar.append(
        btn(
          [icon('palette', 16), h('span', ps.label)],
          `Pen set: ${ps.label}`,
          (e) => showMenu(e.currentTarget, PEN_SETS.map((x) => ({ label: x.label, checked: x.value === ps.value, radio: true, action: () => { set({ penSet: x.value }, 'Pen set'); renderViewbar(app); } })), { label: 'Pen set' }),
          null,
          { menu: true },
        ),
      );
    }
        // Archicad's Quick Options: partial structure display (plans and model views) and renovation filter (the view's phase filter).
    if (app.workspace?.on && ['plan', 'section', 'elevation', 'view3d'].includes(view.kind)) {
      const sd = STRUCTURE_DISPLAY.find((x) => x.value === (view.structureDisplay || 'entire')) || STRUCTURE_DISPLAY[0];
      bar.append(
        btn(
          [icon('wallStructural', 16), h('span', sd.label)],
          `Partial structure display: ${sd.label}`,
          (e) => showMenu(e.currentTarget, STRUCTURE_DISPLAY.map((x) => ({ label: x.label, checked: x.value === sd.value, radio: true, action: () => { set({ structureDisplay: x.value }, 'Partial structure display'); renderViewbar(app); } })), { label: 'Partial structure display' }),
          null,
          { menu: true },
        ),
      );
    }
    if (app.workspace?.on && app.doc.count('phase') > 1) {
      const filters = phaseFilters(app.doc);
      const f = filters.find((x) => x.value === (view.phaseFilter || 'all')) || filters[0];
      bar.append(
        btn(
          [icon('phases', 16), h('span', f.label)],
          `Renovation filter: ${f.label}`,
          (e) => showMenu(e.currentTarget, filters.map((x) => ({ label: x.label, checked: x.value === f.value, radio: true, action: () => { set({ phaseFilter: x.value }, 'Renovation filter'); renderViewbar(app); } })), { label: 'Renovation filter' }),
          null,
          { menu: true },
        ),
      );
    }
    if (view.kind === 'view3d' || view.kind === 'elevation' || view.kind === 'section') {
      const s = STYLES.find((x) => x[0] === (view.style || 'shaded')) || STYLES[2];
      bar.append(btn(icon(s[2], 16), `Visual style: ${s[1]}`, (e) => showMenu(e.currentTarget, STYLES.map(([v, l, ic]) => ({ label: l, icon: ic, checked: view.style === v, radio: true, action: () => set({ style: v }, 'Visual style') })), { label: 'Visual style' }), null, { menu: true }));
    }
    bar.append(btn(icon('thinLines', 16), 'Thin lines', () => app.toggleSetting('thinLines'), !!app.settings.thinLines));
    if (view.kind === 'view3d' || view.kind === 'elevation' || view.kind === 'section')
      bar.append(btn(icon('shadows', 16), view.shadows ? 'Shadows: on' : 'Shadows: off', () => app.run('shadows'), !!view.shadows), btn(icon('sun-l', 16), 'Sun settings', () => app.run('sunSettings')));
    if (view.kind === 'view3d') {
      const persp = app.vc?.cam?.persp !== false;
      bar.append(
        btn(icon('view3d', 16), persp ? 'Perspective (click for orthographic)' : 'Orthographic (click for perspective)', () => {
          const c = app.vc;
          if (!c?.cam) return;
          c.cam.persp = !persp;
          app.viewChanged();
          renderViewbar(app);
          app.requestRender();
        }, persp),
        btn(icon('sectionBox', 16), 'Section box', () => app.toggleSectionBox(), !!view.sectionBox),
      );
    }
    if (view.kind === 'plan') bar.append(btn(icon('palette', 16), 'Room color fill', () => app.toggleViewProp('roomFill'), !!view.roomFill));
    if (isPlanView(view)) bar.append(btn(icon('cropView', 16), view.cropOn ? 'Crop view: on' : 'Crop view: off', () => app.toggleCrop('cropOn'), !!view.cropOn), btn(icon('cropShow', 16), view.cropShow ? 'Hide crop region' : 'Show crop region', () => app.toggleCrop('cropShow'), !!view.cropShow));
    bar.append(sep());
    const t = app.temp.get(view.id);
    bar.append(
      btn(icon('isolate', 16), 'Temporary hide/isolate', (e) =>
        showMenu(
          e.currentTarget,
          [
            { label: 'Isolate Element', icon: 'isolate', disabled: !app.selection.size, action: () => app.temporary('isolate') },
            { label: 'Hide Element', icon: 'hideEl', disabled: !app.selection.size, action: () => app.temporary('hide') },
            { separator: true },
            { label: 'Reset Temporary Hide/Isolate', icon: 'refresh', disabled: !t, action: () => app.temporary('reset') },
            { label: 'Hide Selected in View', icon: 'hideEl', disabled: !app.selection.size, action: () => app.hideInView('element') },
          ],
          { label: 'Temporary hide/isolate' },
        ),
      !!t, { menu: true }),
      btn(icon('reveal', 16), 'Reveal hidden elements', () => app.toggleReveal(), app.reveal.has(view.id)),
    );
    if (view.hiddenCats?.length || view.hiddenIds?.length) bar.append(h('span.vb-label', `${(view.hiddenIds?.length || 0) + (view.hiddenCats?.length || 0)} hidden`));
  }
  // Archicad's Quick Options order: scale, layer combination, pen set, model view options, graphic overrides,
  // renovation filter, partial structure display, then the rest.
  if (app.workspace?.on) {
    const ORDER = ['view scale', 'layer', 'pen set', 'detail level', 'override', 'renovation', 'partial structure'];
    const rank = (el) => {
      const t = String(el.getAttribute?.('data-tip') || '').toLowerCase();
      const i = ORDER.findIndex((k) => t.startsWith(k) || t.includes(k));
      return i < 0 ? ORDER.length : i;
    };
    const items = [...bar.children].filter((el) => !el.classList.contains('vb-sep'));
    items.sort((a, b) => rank(a) - rank(b)).forEach((el) => bar.append(el));
    // Zoom at the left, then how much and at what angle the view is turned, as Archicad's bar.
    const zoomOf = () => {
      const c = app.vc?.cam;
      if (!c || c.yaw != null || !(c.zoom > 0)) return null;
      return Math.round(((c.zoom * (+view.scale || 100)) / (96 / 25.4)) * 100);
    };
    const pct = h('span.vb-readout', '');
    const angle = h('span.vb-readout', `${(((app.vc?.cam?.rot || 0) * 180) / Math.PI).toFixed(2).replace('.', ',')}\u00b0`);
    const tools = [['prevZoom', 'undo'], ['nextZoom', 'redo'], ['zoomRegion', 'zoom-in'], ['zoomFit', 'zoomFit']].filter(([c]) => app.commandDef(c)).map(([c, ic]) => btn(icon(ic, 15), app.commandDef(c).label, () => app.run(c)));
    bar.prepend(...tools, pct, angle);
    clearInterval(renderViewbar.timer);
    renderViewbar.timer = setInterval(() => {
      const z = zoomOf();
      pct.textContent = z == null ? '' : `${z}%`;
    }, 300);
  }
}
