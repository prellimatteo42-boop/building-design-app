/**
 * Trace & Reference palette, as in Archicad: show another drawing faded
 * under the active plan, choose it, move it (two clicks), rotate it,
 * reset it, or swap it with the active view.
 */
import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { isFlatView, VIEW_LABEL } from '../core/doc.js';
import { traceReference } from '../core/trace.js';

export class TracePalette {
  constructor(app) {
    this.app = app;
    this.el = null;
  }

  get open() {
    return !!this.el;
  }

  toggle() {
    if (this.el) return this.close();
    this.el = h('section.quick-layers.trace-palette', { role: 'dialog', 'aria-label': 'Trace & Reference' });
    document.body.append(this.el);
    // Opening it turns the trace on, with the story below by default.
    const v = this.app.activeView;
    if (v && !this.app.traces.get(v.id)) this.set({ refId: 'below', offset: [0, 0], rotation: 0, on: true });
    this.render();
  }

  close() {
    this.el?.remove();
    this.el = null;
  }

  get trace() {
    return this.app.traces.get(this.app.activeViewId) || null;
  }

  /** Change the active view's trace (a new object, so plans redraw). */
  set(patch) {
    const id = this.app.activeViewId;
    if (!id) return;
    const cur = this.app.traces.get(id) || { refId: 'below', offset: [0, 0], rotation: 0, on: true };
    this.app.traces.set(id, { ...cur, ...patch });
    this.app.requestRender();
    this.render();
  }

  render() {
    const el = this.el;
    if (!el) return;
    const app = this.app;
    const doc = app.doc;
    clear(el);
    el.append(h('div.ql-head', h('span.ql-title', icon('layers', 15), 'Trace & Reference'), h('button.icon-btn.sm', { type: 'button', 'aria-label': 'Close Trace & Reference', onClick: () => this.close() }, icon('x', 14))));
    const view = app.activeView;
    if (!view || !isFlatView(view) || view.kind === 'sheet') return el.append(h('p.field-hint', 'Open a plan, ceiling plan, drafting view or detail to trace another drawing under it.'));
    const t = this.trace || { refId: 'below', offset: [0, 0], rotation: 0, on: false };
    const on = h('input', { type: 'checkbox', checked: !!t.on });
    on.addEventListener('change', () => this.set({ on: on.checked }));
    const ref = h('select.input.sm', { 'aria-label': 'Reference' }, [
      h('option', { value: 'below' }, 'Story below'),
      h('option', { value: 'above' }, 'Story above'),
      ...doc
        .filter((v) => isFlatView(v) && v.kind !== 'sheet' && v.id !== view.id)
        .map((v) => h('option', { value: v.id }, `${v.name} (${VIEW_LABEL[v.kind] || v.kind})`)),
    ]);
    ref.value = t.refId;
    ref.addEventListener('change', () => this.set({ refId: ref.value, on: true }));
    ref.addEventListener('keydown', (e) => e.stopPropagation());
    const rot = h('input.input.sm', { type: 'number', step: 1, value: Math.round((+t.rotation || 0) * 100) / 100, 'aria-label': 'Rotation in degrees' });
    rot.addEventListener('keydown', (e) => e.stopPropagation());
    rot.addEventListener('change', () => this.set({ rotation: +rot.value || 0 }));
    const shown = traceReference(doc, view, t);
    const btn = (label, ic, onClick, disabled = false) => h('button.btn.sm', { type: 'button', disabled, onClick }, icon(ic, 14), h('span', label));
    el.append(
      h('label.check', on, h('span', 'Show Reference')),
      h('label.field', h('span.field-label', 'Reference'), ref),
      h('p.field-hint', shown ? `Showing ${shown.name}${t.offset?.[0] || t.offset?.[1] || t.rotation ? ', moved' : ''}.` : t.on ? 'There is no such drawing to show.' : 'The reference is hidden.'),
      h('label.field', h('span.field-label', 'Rotation (degrees)'), rot),
      h(
        'div.ql-actions',
        btn('Move Reference', 'move', () => app.run('moveReference'), !shown),
        btn('Reset', 'rotate', () => this.set({ offset: [0, 0], rotation: 0 }), !shown),
        btn('Swap with Active', 'refresh', () => {
          const target = shown;
          const from = view.id;
          app.openView(target.id);
          app.traces.set(target.id, { refId: from, offset: [0, 0], rotation: 0, on: true });
          this.render();
          app.requestRender();
        }, !shown),
      ),
    );
  }
}
