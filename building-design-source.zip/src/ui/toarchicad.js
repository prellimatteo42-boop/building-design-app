/**
 * Export to Archicad (.pln): the project built in the Archicad open on this computer (with the Tapir add-on) and
 * saved there, by io/toarchicad.js through this app's server; and Open in Archicad 30 to convert an older .pln.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { exportToArchicad } from '../io/toarchicad.js';
import { safeFileName } from '../io/native.js';

export async function archicadCall(command, parameters = {}) {
  const r = await fetch('/api/archicad', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ command, parameters }) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `Archicad: ${r.status}`);
  return data;
}

/** The triangles (mm) of an element's 3D, for the elements that go across as morphs. */
export function meshTriangles(app, el) {
  const mesh = app.scene.mesh(el);
  return mesh?.pos?.length ? mesh.pos : null;
}

export async function exportArchicadDialog(app) {
  let version = '';
  try {
    const info = await archicadCall('GetProductVersionInfo');
    const v = info?.result?.addOnCommandResponse || info?.result || {};
    version = v.version ? `Archicad ${v.version}` : '';
  } catch (e) {
    return app.toast(`No Archicad to export to: ${e.message}`, { kind: 'error' });
  }
  const name = safeFileName(app.doc.project.name || 'Project');
  const path = h('input.input', { value: `~/Documents/Building Design/${name}.pln`, 'aria-label': 'Save as' });
  const ok = await openDialog({
    title: 'Export to Archicad',
    body: h('div', h('p', `${version || 'Archicad'} will build this project in a new, empty project of its own and save it as a .pln. Walls, slabs, zones, columns, beams, doors and windows go as Archicad elements; everything else as morphs with its 3D.`), h('label.field', h('span.field-label', 'Save as'), path)),
    actions: [{ label: 'Cancel', value: null }, { label: 'Export', primary: true, value: 'ok' }],
  });
  if (ok !== 'ok') return;
  app.toast('Building the project in Archicad…', { kind: 'info' });
  try {
    const res = await exportToArchicad(app.doc, archicadCall, { path: path.value.trim(), meshOf: (el) => meshTriangles(app, el) });
    const parts = Object.entries(res.counts).map(([k, n]) => `${n} ${k}`).join(', ');
    app.toast(`Saved in Archicad: ${parts}${res.failed.length ? `; ${res.failed.length} not made (${res.failed.slice(0, 2).map((f) => `${f.kind}: ${f.error}`).join('; ')})` : ''}.`, { kind: res.failed.length ? 'info' : 'success' });
    return res;
  } catch (e) {
    app.toast(`Export to Archicad stopped: ${e.message}`, { kind: 'error' });
  }
}

/**
 * Open an older Archicad project (Archicad 25 to 29) here: the Archicad 30 on this computer opens it and saves a copy
 * as Archicad 30, which this app then reads. `path` is the file's full path on this computer.
 */
export async function openOldPln(app, path, copyPath) {
  const target = copyPath || path.replace(/\.pln$/i, ' (Archicad 30).pln');
  await archicadCall('OpenProject', { projectFilePath: path });
  await archicadCall('SaveProject', { projectPath: target });
  return target;
}
