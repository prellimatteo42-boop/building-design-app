/** Attributes menu: one dialog over the kinds, the Attribute Manager, MEP systems, operation profiles and pens. */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { ATTRIBUTE_KINDS, attributeRows, exportAttributes, importAttributes, applyMepSystems, applyOperationProfiles, penTable, isOwnProfile } from '../core/attrs.js';
import { SYSTEMS } from '../core/mep.js';
import { PROFILES } from '../core/energyhourly.js';
import { WEIGHT_CLASSES } from '../core/pens.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { pickFile } from '../io/files.js';
import { newId } from '../core/doc.js';

const closeOnly = [{ label: 'Close', value: null }];
const table = (head, rows) => h('div', { style: { maxHeight: '55vh', overflow: 'auto' } }, h('table.vg-table', h('thead', h('tr', head.map((c) => h('th', c)))), h('tbody', rows)));
const stop = (el) => (el.addEventListener('keydown', (e) => e.stopPropagation()), el);

/** Attributes: every kind with its count, and the way into its settings. */
export function attributesDialog(app) {
  const doc = app.doc;
  const rows = ATTRIBUTE_KINDS.map((a) => h('tr', h('td', a.label), h('td', String(doc.all(a.kind).length)), h('td', h('button.btn.sm', { type: 'button', onClick: () => app.run(a.cmd) }, 'Open'))));
  const extra = [['Pens', 'pens'], ['MEP Systems', 'mepSystems'], ['Operation Profiles', 'operationProfiles'], ['Attribute Manager', 'attributeManager']].map(([l, c]) => h('button.btn.sm', { type: 'button', onClick: () => app.run(c) }, l));
  return openDialog({ title: 'Attributes', body: h('div', table(['Attribute', 'In project', ''], rows), h('div.inline', { style: { gap: '6px', marginTop: '10px', flexWrap: 'wrap' } }, extra)), actions: closeOnly });
}

/** Attribute Manager: all attributes with their use, delete the unused, carry them to another project. */
export function attributeManager(app) {
  const doc = app.doc;
  const box = h('div');
  const picked = new Set();
  const render = () => {
    const rows = attributeRows(doc);
    box.replaceChildren(table(['', 'Kind', 'Name', 'Used by'], rows.map((r) => {
      const c = h('input', { type: 'checkbox', checked: picked.has(r.id), 'aria-label': `Pick ${r.name}` });
      c.addEventListener('change', () => (c.checked ? picked.add(r.id) : picked.delete(r.id)));
      return h('tr', h('td', c), h('td', r.label), h('td', r.name), h('td', String(r.uses)));
    })));
  };
  render();
  const delUnused = () => {
    const unused = attributeRows(doc).filter((r) => r.uses === 0 && picked.has(r.id));
    if (!unused.length) return toast('Pick attributes that nothing uses.'), false;
    app.commit('Delete attributes', () => unused.forEach((r) => doc.remove(r.id)));
    unused.forEach((r) => picked.delete(r.id));
    render();
    return false;
  };
  const exp = () => (download(new Blob([JSON.stringify(exportAttributes(doc, picked.size ? [...picked] : null))], { type: 'application/json' }), `${safeFileName(doc.project.name || 'Project')} - attributes.bdattr.json`), false);
  const imp = () => {
    pickFile('.json').then(async (f) => {
      if (!f) return;
      let res;
      try {
        const data = JSON.parse(await f.text());
        app.commit('Import attributes', () => (res = importAttributes(doc, data)));
        toast(`${res.added} attributes added.`);
        render();
      } catch {
        toast('That is not an attribute file.', { kind: 'error' });
      }
    });
    return false;
  };
  return openDialog({ title: 'Attribute Manager', size: 'lg', body: box, actions: [{ label: 'Close', value: null }, { label: 'Delete Unused', onClick: delUnused }, { label: 'Export', onClick: exp }, { label: 'Import', onClick: imp }] });
}

/** MEP Systems: the systems of each kind of run, with their colours. */
export function mepSystemsDialog(app) {
  const doc = app.doc;
  const list = structuredClone(Object.fromEntries(Object.entries(SYSTEMS)));
  const box = h('div');
  const render = () => {
    box.replaceChildren(
      ...Object.entries(list).map(([kind, items]) =>
        h('fieldset.cp-plane', h('legend', kind),
          ...items.map((s, i) => {
            const n = stop(h('input.input.sm', { value: s.label, 'aria-label': 'System name' }));
            n.addEventListener('change', () => (s.label = n.value.trim() || s.label));
            const c = h('input', { type: 'color', value: s.color, 'aria-label': `${s.label} colour` });
            c.addEventListener('change', () => (s.color = c.value));
            return h('div.inline', { style: { gap: '6px', marginBottom: '4px' } }, n, c, h('button.btn.sm', { type: 'button', disabled: items.length < 2, onClick: () => (items.splice(i, 1), render()) }, 'Remove'));
          }),
          h('button.btn.sm', { type: 'button', onClick: () => (items.push({ value: newId('sys'), label: `System ${items.length + 1}`, color: '#6b7684' }), render()) }, 'Add System'),
        ),
      ),
    );
  };
  render();
  return openDialog({ title: 'MEP Systems', body: h('div', { style: { maxHeight: '60vh', overflow: 'auto' } }, box), actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, onClick: () => (app.commit('MEP systems', () => doc.update('project', { mepSystems: list })), applyMepSystems(doc.project), app.requestRender(), true) }] });
}

/** Operation Profiles: how a building is used, hour by hour, weekday and weekend. */
export function operationProfilesDialog(app) {
  const doc = app.doc;
  const own = structuredClone(doc.project.operationProfiles || {});
  const box = h('div');
  const row = (arr) => h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: '2px' } }, arr.map((v, i) => {
    const n = stop(h('input.input.sm', { type: 'number', step: 0.1, min: 0, value: v, 'aria-label': `Hour ${i}` }));
    n.addEventListener('change', () => (arr[i] = Math.max(0, +n.value || 0)));
    return n;
  }));
  const render = () => {
    box.replaceChildren(
      h('p.field-hint', `Built in: ${Object.entries(PROFILES).filter(([k]) => !isOwnProfile(k)).map(([, p]) => p.label).join(', ')}. Factors multiply the internal gains, hour by hour from midnight.`),
      ...Object.entries(own).map(([k, p]) => {
        const n = stop(h('input.input', { value: p.label, 'aria-label': 'Profile name' }));
        n.addEventListener('change', () => (p.label = n.value.trim() || p.label));
        return h('fieldset.cp-plane', h('legend', p.label), h('div.inline', { style: { gap: '6px', marginBottom: '6px' } }, n, h('button.btn.sm', { type: 'button', onClick: () => (delete own[k], render()) }, 'Remove')), h('span.field-label', 'Weekday'), row(p.weekday), h('span.field-label', 'Weekend'), row(p.weekend));
      }),
      h('button.btn.sm', { type: 'button', onClick: () => ((own[newId('prof')] = { label: `Profile ${Object.keys(own).length + 1}`, weekday: Array(24).fill(1), weekend: Array(24).fill(1) }), render()) }, 'New Profile'),
    );
  };
  render();
  return openDialog({ title: 'Operation Profiles', size: 'lg', body: h('div', { style: { maxHeight: '60vh', overflow: 'auto' } }, box), actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, onClick: () => (app.commit('Operation profiles', () => doc.update('project', { operationProfiles: own })), applyOperationProfiles(doc.project), true) }] });
}

/** Pens: a table of 255 pens, and which pen each line weight class draws with. */
export function pensDialog(app) {
  const doc = app.doc;
  const pens = structuredClone(penTable(doc.project));
  const classes = { ...(doc.project.penClasses || {}) };
  const colors = h('input', { type: 'checkbox', checked: !!doc.project.penColors });
  const assign = WEIGHT_CLASSES.map((c) => {
    const n = stop(h('input.input.sm', { type: 'number', min: 0, max: 255, value: classes[c.i] || 0, 'aria-label': `Pen of ${c.name}`, style: { width: '70px' } }));
    n.addEventListener('change', () => (classes[c.i] = Math.max(0, Math.min(255, Math.round(+n.value) || 0))));
    return h('tr', h('td', c.name), h('td', c.use), h('td', n));
  });
  const rows = pens.map((p, i) => {
    const c = h('input', { type: 'color', value: p.color, 'aria-label': `Pen ${i + 1} colour` });
    c.addEventListener('change', () => (p.color = c.value));
    const m = stop(h('input.input.sm', { type: 'number', step: 0.01, min: 0.01, value: p.mm, 'aria-label': `Pen ${i + 1} width`, style: { width: '80px' } }));
    m.addEventListener('change', () => (p.mm = Math.max(0.01, +m.value || 0.13)));
    return h('tr', h('td', String(i + 1)), h('td', c), h('td', m));
  });
  return openDialog({
    title: 'Pens',
    size: 'lg',
    body: h('div', h('h3.dlg-sub', 'Pen of each line class (0: as the Line Weights)'), table(['Class', 'Used for', 'Pen'], assign), h('label.check', colors, h('span', 'Show the pen colours on screen')), h('h3.dlg-sub', 'Pen table'), table(['Pen', 'Colour', 'Width (mm)'], rows)),
    actions: [
      { label: 'Cancel', value: null },
      { label: 'OK', primary: true, onClick: () => (app.commit('Pens', () => doc.update('project', { penTable: pens, penClasses: classes, penColors: colors.checked })), app.requestRender(), true) },
    ],
  });
}
