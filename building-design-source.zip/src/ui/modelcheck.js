/** Model Check Report dialog: every check in one list, select the elements, export CSV or Markdown. */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { modelCheckReport, reportCSV, reportMarkdown } from '../core/modelcheck.js';

export function modelCheckDialog(app) {
  const r = modelCheckReport(app.doc, app.scene);
  const name = app.doc.project.name || 'Project';
  const body = h('div', { style: 'max-height:60vh;overflow:auto' }, [
    h('p', `${r.total} problem${r.total === 1 ? '' : 's'} in ${r.sections.length} checks.`),
    ...r.sections.map((s) =>
      h('details', { open: s.items.length > 0 && s.items.length < 40 }, [
        h('summary', `${s.name} (${s.items.length})`),
        s.items.length
          ? h('table.vg-table', h('tbody', ...s.items.map((it) => h('tr', h('td', it.check), h('td', it.message), h('td', it.ids.length ? h('button.btn.sm', { type: 'button', onClick: () => app.select(it.ids.filter((id) => app.doc.has(id))) }, 'Select') : '')))))
          : h('p.field-hint', 'No problems.'),
      ]),
    ),
  ]);
  return openDialog({
    title: 'Model Check Report',
    size: 'lg',
    body,
    actions: [
      { label: 'Export CSV', onClick: () => (download(new Blob([reportCSV(r)], { type: 'text/csv' }), `${safeFileName(name)} - Model Check.csv`), false) },
      { label: 'Export Markdown', onClick: () => (download(new Blob([reportMarkdown(r, name)], { type: 'text/markdown' }), `${safeFileName(name)} - Model Check.md`), false) },
      { label: 'Close', primary: true, value: null },
    ],
  });
}
