/**
 * Editing one curtain wall's mullions and panels on its elevation: click a
 * mullion segment to remove or restore it, click a panel to change it.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { curtainGrid } from '../core/build3d.js';
import { wallAxis, verticalExtent } from '../core/model.js';
import { panelClasses, frameClasses, frameFor } from '../core/cwscheme.js';

const SVG = 'http://www.w3.org/2000/svg';
const svg = (tag, attrs = {}) => {
  const el = document.createElementNS(SVG, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  return el;
};

const KIND_FILL = {
  glass: 'rgba(120, 170, 220, 0.45)',
  solid: 'rgba(200, 200, 195, 0.95)',
  spandrel: 'rgba(110, 120, 130, 0.9)',
  louvre: 'rgba(170, 175, 180, 0.8)',
  door: 'rgba(120, 170, 220, 0.45)',
  empty: 'transparent',
};
const CLASS_COLORS = ['#c0392b', '#8e44ad', '#16a085', '#d35400', '#2c3e50'];

export function curtainEditDialog(app, id = [...app.selection][0]) {
  const doc = app.doc;
  const w = doc.get(id);
  const type = w && doc.get(w.typeId);
  if (!type?.curtain) return toast('Select a curtain wall first.', { kind: 'error' });
  const ax = wallAxis(doc, w);
  const { base, top } = verticalExtent(doc, w);
  const L = ax.length;
  const H = top - base;
  const { us, vs, nu, nv } = curtainGrid(L, H, type, w);
  const c = type.curtain;
  const off = new Set(w.mullionsOff || []);
  const panels = { ...(w.panels || {}) };
  const fclass = { ...(w.frameClass || {}) };
  const PANEL_KINDS = panelClasses(c).map((p) => ({ value: p.id, label: p.name, fill: KIND_FILL[p.kind] || KIND_FILL.solid, kind: p.kind }));
  const FRAMES = frameClasses(c);
  const ownFrames = FRAMES.slice(3);
  const mainPanel = c.mainPanel || 'glass';
  let brush = PANEL_KINDS.find((p) => p.value !== mainPanel)?.value || 'solid';
  let frameBrush = 'toggle';
  const W0 = 640;
  const s = Math.min(W0 / L, 380 / H);
  const pad = 14;
  const X = (u) => pad + u * s;
  const Y = (z) => pad + (H - z) * s;
  const root = svg('svg', { viewBox: `0 0 ${L * s + pad * 2} ${H * s + pad * 2}`, class: 'cw-svg', role: 'img', 'aria-label': 'Curtain wall elevation' });
  const draw = () => {
    root.replaceChildren();
    for (let i = 0; i < nu; i++)
      for (let j = 0; j < nv; j++) {
        const kind = panels[`${i}:${j}`] || mainPanel;
        const k = PANEL_KINDS.find((p) => p.value === kind) || PANEL_KINDS[0];
        const r = svg('rect', { x: X(us[i]) + 2, y: Y(vs[j + 1]) + 2, width: Math.max(1, (us[i + 1] - us[i]) * s - 4), height: Math.max(1, (vs[j + 1] - vs[j]) * s - 4), fill: k.fill, class: `cw-panel ${k.kind}`, tabindex: '0', 'data-cell': `${i}:${j}` });
        r.append(svg('title'));
        r.firstChild.textContent = `${k.label} panel (click to make it ${(PANEL_KINDS.find((p) => p.value === brush) || k).label.toLowerCase()})`;
        const set = () => {
          if (brush === mainPanel) delete panels[`${i}:${j}`];
          else panels[`${i}:${j}`] = brush;
          draw();
        };
        r.addEventListener('click', set);
        r.addEventListener('keydown', (e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), set()));
        root.append(r);
        if (k.kind === 'door') root.append(svg('line', { x1: X(us[i + 1]) - 10, y1: Y((vs[j] + vs[j + 1]) / 2) - 8, x2: X(us[i + 1]) - 10, y2: Y((vs[j] + vs[j + 1]) / 2) + 8, class: 'cw-handle' }));
        if (k.kind === 'louvre') for (let z = vs[j] + 150; z < vs[j + 1] - 50; z += 150) root.append(svg('line', { x1: X(us[i]) + 4, y1: Y(z), x2: X(us[i + 1]) - 4, y2: Y(z), class: 'cw-handle' }));
      }
    const seg = (key, x1, y1, x2, y2) => {
      const on = !off.has(key);
      const f = frameFor(c, { frameClass: fclass }, key, nu, nv);
      const ci = ownFrames.findIndex((x) => x.id === f.id);
      const g = svg('g', { class: `cw-mullion${on ? '' : ' off'}`, tabindex: '0', 'data-seg': key });
      const vis = svg('line', { x1, y1, x2, y2, class: 'vis' });
      if (on && ci >= 0) vis.setAttribute('style', `stroke: ${CLASS_COLORS[ci % CLASS_COLORS.length]}; stroke-width: ${Math.max(3, Math.min(10, (+f.width || 50) * s))}px`);
      g.append(svg('line', { x1, y1, x2, y2, class: 'hit' }), vis, svg('title'));
      g.lastChild.textContent = on ? `${f.name} (click to ${frameBrush === 'toggle' ? 'remove' : 'set the class'})` : 'No frame (click to add)';
      const flip = () => {
        if (frameBrush === 'toggle' || !on) {
          if (on) off.add(key);
          else off.delete(key);
        } else if (frameBrush === 'default') delete fclass[key];
        else fclass[key] = frameBrush;
        draw();
      };
      g.addEventListener('click', flip);
      g.addEventListener('keydown', (e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), flip()));
      root.append(g);
    };
    for (let i = 0; i <= nu; i++) for (let j = 0; j < nv; j++) seg(`v:${i}:${j}`, X(us[i]), Y(vs[j]), X(us[i]), Y(vs[j + 1]));
    for (let j = 0; j <= nv; j++) for (let i = 0; i < nu; i++) seg(`h:${j}:${i}`, X(us[i]), Y(vs[j]), X(us[i + 1]), Y(vs[j]));
  };
  draw();
  const brushes = h('div.seg', { role: 'radiogroup', 'aria-label': 'Panel type to apply' });
  const renderBrushes = () => {
    brushes.replaceChildren(...PANEL_KINDS.map((p) => h('button.seg-btn', { type: 'button', role: 'radio', 'aria-checked': String(p.value === brush), onClick: () => ((brush = p.value), renderBrushes(), draw()) }, h('span.cw-swatch', { style: { background: p.fill } }), p.label)));
  };
  renderBrushes();
  const frameOpts = [
    { value: 'toggle', label: 'Remove or restore' },
    { value: 'default', label: 'Back to boundary/mullion/transom' },
    ...FRAMES.map((f) => ({ value: f.id, label: `Set class: ${f.name}` })),
  ];
  const frameSel = h('select.input', { 'aria-label': 'Clicking a frame segment' }, frameOpts.map((o) => h('option', { value: o.value }, o.label)));
  frameSel.addEventListener('change', () => ((frameBrush = frameSel.value), draw()));
  return openDialog({
    title: `Mullions and Panels: ${type.name}`,
    size: 'lg',
    body: h('div.cw-edit', h('div.cw-tools', h('span.field-label', 'Click panels to make them'), brushes, h('button.btn.sm', { type: 'button', onClick: () => (off.clear(), Object.keys(panels).forEach((k) => delete panels[k]), Object.keys(fclass).forEach((k) => delete fclass[k]), draw()) }, 'Reset all')), h('div.cw-tools', h('span.field-label', 'Click frames to'), frameSel), root, h('p.field-hint', 'Frame and panel classes are defined in the curtain wall type. Grid lines themselves are moved with the Curtain Grid tool.')),
    actions: [
      { label: 'Cancel', value: null },
      {
        label: 'OK',
        primary: true,
        onClick: () => {
          app.commit('Edit mullions and panels', () => doc.update(w.id, { mullionsOff: off.size ? [...off] : null, panels: Object.keys(panels).length ? panels : null, frameClass: Object.keys(fclass).length ? fclass : null }));
          return true;
        },
      },
    ],
  });
}
