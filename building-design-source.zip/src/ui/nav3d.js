/**
 * 3D navigation and input, as Archicad's: Walk, Turn and Camera Mode,
 * Look To (a clicked point), Look to Perpendicular (of the editing plane or
 * of a clicked surface), Horizontal View, Two-Point Perspective, and the
 * editing plane commands (Pick Plane, Next Plane, Return to Last Editing
 * Plane, Snap to Story, Editing Plane Display, Surface Snap). The camera
 * and plane logic is in views/model.js.
 */
import { PROJECTIONS } from '../core/editplane.js';
import { Tool } from '../editor/tool.js';

const view3d = (app) => {
  const c = app.vc;
  if (!c?.is3D) {
    app.toast('Open a 3D view first.', { kind: 'error' });
    return null;
  }
  return c;
};

export function setNavMode(app, mode) {
  const cur = app.settings.navMode || 'orbit';
  const next = cur === mode ? 'orbit' : mode;
  app.settingsStore.set('navMode', next);
  const tips = { walk: 'Walk: W A S D or the arrows move, Q and E go down and up, dragging turns the camera.', turn: 'Turn: dragging turns the camera where it stands.', camera: 'Camera mode: dragging turns the view around the camera.', orbit: 'Orbit: dragging turns the view around the model.' };
  app.toast(tips[next]);
}

/** Point the camera at p, keeping the eye where it is. */
function lookAtPoint(c, p) {
  const eye = c.eye();
  const d = [eye[0] - p[0], eye[1] - p[1], eye[2] - p[2]];
  const dist = Math.hypot(d[0], d[1], d[2]);
  if (dist < 1) return;
  c.cam.target = p;
  c.cam.dist = dist;
  c.cam.yaw = Math.atan2(d[1], d[0]);
  c.cam.pitch = Math.asin(Math.max(-1, Math.min(1, d[2] / dist)));
  c.userMoved = true;
}

/** Look along -n at p from the same distance. */
function lookAlong(c, p, n) {
  const dist = c.cam.dist;
  c.cam.target = p;
  c.cam.yaw = Math.atan2(n[1], n[0]);
  c.cam.pitch = Math.asin(Math.max(-1, Math.min(1, n[2])));
  if (Math.abs(n[2]) > 0.9999) c.cam.pitch = Math.sign(n[2]) * 1.5607;
  c.cam.dist = dist;
  c.userMoved = true;
}

/** A tool that takes one click on the 3D model and hands over the surface hit. */
class PickSurfaceTool extends Tool {
  constructor(app, { title, prompt, done }) {
    super(app);
    this.titleText = title;
    this.promptText = prompt;
    this.done = done;
  }

  get title() {
    return this.titleText;
  }

  get prompt() {
    return this.promptText;
  }

  get viewKinds() {
    return ['view3d'];
  }

  down(ev) {
    const c = this.app.vc;
    const hit = c?.raycast?.(ev.x, ev.y);
    if (!hit) return this.app.toast('Click on the model.', { kind: 'error' });
    this.app.cancelTool();
    this.done(hit, c);
    this.app.requestRender();
  }
}

export const lookToTool = (app) => new PickSurfaceTool(app, { title: 'Look To', prompt: 'Click the point to look at', done: (hit, c) => lookAtPoint(c, hit.p) });
export const lookToSurfaceTool = (app) => new PickSurfaceTool(app, { title: 'Look to Perpendicular of Clicked Surface', prompt: 'Click a surface to look straight at it', done: (hit, c) => lookAlong(c, hit.p, hit.n) });
export const pickPlaneTool = (app) =>
  new PickSurfaceTool(app, {
    title: 'Pick Plane',
    prompt: 'Click a surface: 3D input goes on its plane (horizontal, sloped or vertical)',
    done: (hit, c) => {
      c.setSurfacePlane(hit);
      app.toast(c.editPlane?.o ? 'Editing plane on the clicked surface.' : `Editing plane at ${Math.round(hit.p[2])} mm.`);
    },
  });

export function lookPerpendicular(app) {
  const c = view3d(app);
  if (!c) return;
  lookAlong(c, [c.cam.target[0], c.cam.target[1], c.planeZ()], [0, 0, 1]);
  app.requestRender();
}

export function horizontalView(app) {
  const c = view3d(app);
  if (!c) return;
  const eye = c.eye();
  c.cam.pitch = 0;
  c.cam.target = [eye[0] - Math.cos(c.cam.yaw) * c.cam.dist, eye[1] - Math.sin(c.cam.yaw) * c.cam.dist, eye[2]];
  c.userMoved = true;
  app.requestRender();
}

export function twoPointPerspective(app) {
  const c = view3d(app);
  if (!c) return;
  c.cam.twoPoint = !c.cam.twoPoint;
  if (c.cam.twoPoint) c.cam.persp = true;
  app.requestRender();
}

export function nextPlane(app) {
  const c = view3d(app);
  if (!c) return;
  const z = c.planeZ();
  const above = app.doc.levels().find((l) => l.elevation > z + 1);
  const to = above ?? app.doc.levels()[0];
  c.setPlane(to.elevation);
  app.toast(`Editing plane on ${to.name}.`);
}

export function returnPlane(app) {
  const c = view3d(app);
  if (!c) return;
  const prev = c.planeHistory?.pop();
  if (prev == null) return app.toast('No earlier editing plane.');
  c.editPlane = { z: prev };
  app.requestRender();
}

export function snapToStory(app) {
  const c = view3d(app);
  if (!c) return;
  const lv = app.doc.get(app.activeLevelId());
  c.setPlane(lv?.elevation ?? 0);
  c.editPlane = null;
  app.toast(`Editing plane on ${lv?.name || 'the story'}.`);
}

export function toggleSetting(app, key) {
  app.settingsStore.set(key, !app.settings[key]);
  app.requestRender();
}

/** Input projection (core/editplane.js): how the points after the first are constrained in 3D. */
export function setProjection(app, mode) {
  const cur = app.settings.inputProjection || 'free';
  const next = cur === mode ? 'free' : mode;
  app.settingsStore.set('inputProjection', next);
  app.toast(next === 'free' ? 'Input on the editing plane.' : `Input projection: ${PROJECTIONS.find((p) => p.value === next).label}.`);
  app.requestRender();
}
