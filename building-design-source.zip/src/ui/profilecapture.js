/** Capture Profile of Selection: the selected fills as a complex profile (core/profiles.js). */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { captureProfile } from '../core/profiles.js';
import { uniqueName } from '../core/ops.js';

export function captureProfileDialog(app) {
  const regions = [...app.selection].map((id) => app.doc.get(id)).filter((el) => el?.kind === 'region');
  if (!regions.length) return app.toast('Select the fills that draw the cross-section.', { kind: 'error' });
  const name = h('input.input', { type: 'text', value: uniqueName(app.doc.all('profile').map((p) => p.name), 'Captured Profile'), 'aria-label': 'Name' });
  name.addEventListener('keydown', (e) => e.stopPropagation());
  const use = h('select.input', { 'aria-label': 'Use with' }, ...[['wall', 'Walls'], ['beam', 'Beams'], ['column', 'Columns']].map(([v, l]) => h('option', { value: v }, l)));
  const body = h('div', h('label.field', h('span.field-label', 'Name'), name), h('label.field', h('span.field-label', 'Use with'), use), h('p.field-hint', 'Walls and beams: across from the middle of the drawing, up from its bottom. Columns: around its centre. The fills\' patterns give the materials.'));
  return openDialog({ title: 'Capture Profile of Selection', body, actions: [{ label: 'Cancel', value: null }, { label: 'Capture', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    const pr = captureProfile(regions, { use: use.value, name: name.value.trim() || 'Captured Profile' });
    let added;
    app.commit('Capture profile', () => (added = app.doc.add(pr)));
    app.toast(`${added.name}: ${pr.shapes.length} shape${pr.shapes.length === 1 ? '' : 's'}. Choose it as the profile of ${use.value}s.`, { kind: 'success' });
  });
}

import { SLAB_REF_PLANES } from '../core/slabref.js';

/** Modify Slab Reference Plane: the selected slabs measure their elevation at another plane, without moving. */
export function slabReferenceDialog(app) {
  const slabs = [...app.selection].map((id) => app.doc.get(id)).filter((el) => el?.kind === 'floor');
  if (!slabs.length) return app.toast('Select the slabs first.', { kind: 'error' });
  const sel = h('select.input', { 'aria-label': 'Reference plane' }, ...SLAB_REF_PLANES.map((p) => h('option', { value: p.value, selected: p.value === (slabs[0].refPlane || 'top') }, p.label)));
  const body = h('div', h('label.field', h('span.field-label', 'Reference plane'), sel), h('p.field-hint', 'The slabs stay where they are; their elevation is read and set at this plane from now on.'));
  return openDialog({ title: 'Modify Slab Reference Plane', body, actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    app.commit('Slab reference plane', () => slabs.forEach((s) => app.doc.update(s.id, { refPlane: sel.value })));
  });
}

import { roofsFromMesh } from '../core/roofsfrommesh.js';

export function createRoofsFromMesh(app) {
  const meshes = [...app.selection].map((id) => app.doc.get(id)).filter((el) => el?.kind === 'topo');
  if (!meshes.length) return app.toast('Select the mesh to turn into roofs.', { kind: 'error' });
  const typeId = app.currentType('roof')?.id || app.doc.all('roofType')[0]?.id;
  const ids = [];
  app.commit('Create roofs from mesh', () => meshes.forEach((m) => roofsFromMesh(app.doc, m, typeId).forEach((r) => ids.push(app.doc.add(r).id))));
  app.select(ids);
  app.toast(ids.length ? `${ids.length} roof${ids.length === 1 ? '' : 's'} on the faces of the mesh.` : 'No faces found on that mesh.', { kind: ids.length ? 'success' : 'error' });
}
