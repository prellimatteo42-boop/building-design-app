/**
 * The Archicad-style workspace: the same commands, arranged the way Archicad
 * users expect them.
 *
 *   - A menu bar (File, Edit, View, Design, Document, Options, Teamwork,
 *     Window, Help) in place of the ribbon.
 *   - The Toolbox down the left: Design and Document tools under Archicad's
 *     names (Slab, Zone, Object, Mesh, Level Dimension, Label, Fill,
 *     Worksheet...), plus the rest under More.
 *   - The Info Box under the menus: the selection's type, its Settings and
 *     the commands for it; with a tool running, the tool's options.
 *   - The Project Browser on the right as the Navigator, with Properties.
 *
 * It is switched on in View > Archicad-Style Workspace (or Options) and kept
 * in the settings; the ribbon workspace stays the default. Icons and names
 * of things are the app's own where Archicad's are not plain words.
 */
import { uiLanguage, translateLabel } from './aclang.js';
import { toolHelp } from './toolhelp.js';
import { openDialog } from './dialog.js';
import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { showMenu } from './menu.js';
import { contextualPanels } from './ribbon-def.js';
import { pluralLabel } from './properties.js';
import { KIND_LABEL } from '../core/catalog.js';
import { VIEW_LABEL } from '../core/doc.js';
import { layered, layerIdOf, layersInOrder } from '../core/layers.js';
import { applyPalettes } from './acextras.js';
import { AC_MENUBAR, AC_STANDARD_TOOLBAR, AC_TOOLBOX, AC_KEYMAP, AC_INFOBOX } from './acmenus.js';
import { normCustom, customToolbox, customMenubar, customStandard, customPanels } from '../core/workenv.js';

/** Archicad's words for the app's commands, used in the Toolbox and the menus. */
export const AC_TERMS = {
  modify: 'Arrow',
  floor: 'Slab',
  room: 'Zone',
  roomSeparator: 'Zone Boundary',
  component: 'Object',
  topo: 'Mesh',
  spotElevation: 'Level Dimension',
  tag: 'Label',
  tagAll: 'Label All',
  region: 'Fill',
  detailLine: 'Line',
  detailArc: 'Arc/Circle',
  callout: 'Detail',
  draftingView: 'Worksheet',
  grid: 'Grid Element',
  level: 'Story',
  levels: 'Story Settings',
  view3d: '3D Window',
  planViews: 'Floor Plan',
  sheet: 'Layout',
  editType: 'Settings...',
  dimension: 'Dimension',
  visibility: 'Model View Options',
  objectStyles: 'Graphic Overrides',
  materials: 'Building Materials',
  move: 'Drag',
  copy: 'Drag a Copy',
  array: 'Multiply',
  mirrorDraw: 'Mirror',
};

const TOOLBOX = [
  { title: 'Select', cmds: ['modify', 'marquee'] },
  { title: 'Design', cmds: ['wall', 'column', 'beam', 'floor', 'stair', 'railing', 'roof', 'shell', 'morph', 'ceiling', 'door', 'window', 'cornerWindow', 'skylight', 'opening', 'component', 'room', 'topo', 'mass'] },
  { title: 'Document', cmds: ['dimension', 'spotElevation', 'text', 'tag', 'region', 'detailLine', 'detailArc', 'spline', 'section', 'elevation', 'interiorElevations', 'callout', 'draftingView', 'grid', 'gridSystem'] },
  { title: 'More', more: true, cmds: ['guideLine', 'level', 'ramp', 'shaft', 'curtainGrid', 'wallSweep', 'beamSystem', 'footing', 'wallFooting', 'slabFoundation', 'modelLine', 'refPlane', 'dimAngular', 'dimRadial', 'spotSlope', 'keynote', 'insulation', 'revisionCloud', 'northArrow', 'scaleBar'] },
];

/**
 * Archicad's default shortcuts, active in its workspace: Ctrl (Cmd on a
 * Mac) with a key, Shift for the copying variants. Keys are
 * `${shift ? 'Shift+' : ''}${key}` with key lower-cased.
 */
export const AC_SHORTCUTS = {
  d: 'move',
  'Shift+d': 'copy',
  e: 'rotate',
  m: 'mirrorDraw',
  u: 'array',
  9: 'elevate',
  t: 'editType',
  l: 'layerSettings',
  g: 'groupCreate',
  'Shift+g': 'ungroup',
  7: 'levels',
  arrowup: 'storyUp',
  arrowdown: 'storyDown',
};

/** The shortcut of a command in Archicad's scheme, for menus ("Ctrl+D", "⌘D"). */
export function acShortcut(cmd) {
  const key = Object.keys(AC_SHORTCUTS).find((k) => AC_SHORTCUTS[k] === cmd);
  if (!key) return null;
  const mac = typeof navigator !== 'undefined' && /Mac/.test(navigator.platform || navigator.userAgent || '');
  const shift = key.startsWith('Shift+');
  const k = key.replace('Shift+', '');
  const name = { arrowup: '↑', arrowdown: '↓' }[k] || k.toUpperCase();
  return mac ? `${shift ? '⇧' : ''}⌘${name}` : `Ctrl+${shift ? 'Shift+' : ''}${name}`;
}

/** "Mod+Alt+d" as Archicad shows it: ⌘⌥D on a Mac, Ctrl+Alt+D elsewhere. */
export function keyLabel(keys) {
  if (!keys) return '';
  const mac = /Mac|iPhone|iPad/.test(globalThis.navigator?.platform || '');
  const parts = keys.split('+');
  const k = parts.pop();
  const name = k.length === 1 ? k.toUpperCase() : k;
  if (mac) return parts.map((p) => ({ Mod: '⌘', Alt: '⌥', Shift: '⇧' })[p]).join('') + name;
  return [...parts.map((p) => ({ Mod: 'Ctrl', Alt: 'Alt', Shift: 'Shift' })[p]), name].join('+');
}

/** The app command for a key press in Archicad's scheme (Mod: Cmd on a Mac, Ctrl elsewhere), or null. */
export function acKeyCommand(e) {
  const mac = /Mac|iPhone|iPad/.test(globalThis.navigator?.platform || '');
  const mod = mac ? e.metaKey : e.ctrlKey;
  const k = (e.key || '').length === 1 ? e.key.toLowerCase() : e.key;
  const combo = [mod ? 'Mod' : null, e.altKey ? 'Alt' : null, e.shiftKey ? 'Shift' : null, k].filter(Boolean).join('+');
  return AC_KEYMAP[combo] || null;
}

const S = null; // a separator in a menu
const MENUS = [
  ['File', ['new', 'open', 'sample', 'save', 'saveAs', 'projectVersions', S, 'objectLibrary', 'archicadLibrary', 'saveAsObject', 'saveAsDoor', 'saveAsWindow', 'saveAsStairTread', 'saveAsStairRiser', 'saveAsRailingPost', 'saveAsRailingPanel', 'saveAsLabel', 'saveAsDrawingTitle', 'saveAsMepPart', 'saveGdl', 'import3DS', 'importGLTF', 'importGLTFModel', 'exportArchicad', S, 'importDwg', 'importDxf', 'openIFC', 'linkIFC', 'importPointCloud', 'pointClouds', 'linkProject', 'manageLinks', 'saveAsModule', 'breakHotlink', 'saveHotlinkAsFile', 'updateWithIFC', 'importIDS', 'idsCheck', 'exportPropertyValues', 'importPropertyValues', 'linkProject', 'importPdf', 'importImage', 'straightenImage', 'calibrateImage', 'modelFromImage', 'importSurvey', S, 'export', 'print', 'publish', 'share', S, 'home']],
  ['Edit', ['undo', 'redo', 'undoHistory', S, 'cutClip', 'copyClip', 'paste', 'pasteLevels', S, 'selectAll', 'findSelect', 'selectionFilter', 'selectSimilar', 'selectById', S, 'move', 'copy', 'rotate', 'mirrorPick', 'mirrorDraw', 'array', 'elevate', 'align', 'alignDistribute', 'offset', 'trim', 'extend', 'split', 'filletChamfer', 'explode', 'convertSelection', 'polyUnion', 'polySubtract', 'polyIntersect', 'scaleEl', S, 'matchType', 'pin', 'unpin', S, 'findReplace', 'renumber', 'elementIdManager', S, 'mergeWalls', 'mergeBeams', 'mergeColumns', 'consolidateLines', S, 'bringToFront', 'bringForward', 'sendBackward', 'sendToBack', 'resetDisplayOrder']],
  ['View', ['zoomFit', 'zoomIn', 'zoomOut', 'zoomRegion', 'prevZoom', 'nextZoom', 'homeZoom', 'setHomeZoom', 'actualSize', 'zoomSelection', 'zoomSurveyPoint', S, 'navWalk', 'navTurn', 'cameraMode', 'lookTo', 'lookPerpendicular', 'lookToSurface', 'horizontalView', 'twoPointPerspective', S, 'pickPlane', 'nextPlane', 'returnPlane', 'snapToStory', 'editPlaneDisplay', 'surfaceSnap', S, 'gridSettings', 'showGrid', 'gridSnap', 'orthogonalGrid', 'rotatedGrid', 'setRotatedGrid', S, 'tracker', 'trackerXY', 'setUserOrigin', 'resetUserOrigin', 'parallelConstraint', 'bisectorConstraint', 'rulers', 'rotateOrientation', 'resetOrientation', S, 'drawingAids', 'mepSlopesDisplay', 'markerRange', 'refLinesWall', 'refLinesRailing', 'refLinesMep', 'roofPivotLines', 'stairBaselines', S, 'guideLine', 'removeGuides', S, 'show3d', 'cloneFolder', 'visibility', 'filters', 'viewTemplates', 'thinLines', S, 'sectionBox', 'cutPlanes', 'filter3d', 'cropView', 'cropShow', S, 'tempHide', 'tempIsolate', 'tempReset', 'revealHidden', S, 'tileViews', 'tabViews', 'closeInactive', 'nextView', 'storyUp', 'storyDown', S, 'toggleProps', 'toggleBrowser', 'workspace']],
  ['Design', ['wall', 'column', 'beam', 'floor', 'roof', 'ceiling', 'stair', 'railing', 'railingOn', 'ramp', 'shell', 'morph', S, 'door', 'window', 'cornerWindow', 'skylight', 'opening', 'shaft', 'openingFace', 'curtainGrid', 'editCurtain', 'copyCellPattern', 'commonFrames', 'cwJunction', 'joinWallsToCurtain', 'cwAccessory', 'archiGlazing', S, 'component', 'objectLibrary', 'gdlObjects', 'placeAllObjects', 'testAllParts', 'searchCallers', 'missingAttributes', 'exportLibraryXML', 'exportPlacedXML', 'exportViewXML', 'importPlaceXML', 'room', 'roomSeparator', 'mass', 'topo', S, 'editType', 'editBoundary', 'wallAccessories', 'slabAccessories', 'roofAccessories', 'createRoomAccessories', 'updateRoomAccessories', 'updateZones', 'cropZone', 'uncropZones', 'flipRailing', 'attachTop', 'detachTop', 'trimToRoofShell', 'cropToRoofPlane', 'cutAdditional', 'roofWizard', 'roofFraming', 'collarBeams', 'tieBeams', 'structuralSupports', 'structuralLoads', 'analyticalModel', 'analyticalRules', 'analyticalQuality', 'transparentPhysical', 'transparent2dMembers', 'transparentSymbols', 'analyticalAxes', 'structuralLink', 'createStructuralLinks', 'loadCategories', 'loadCombinations', 'exportSAF', 'roofLevelLines', 'splitRoof', 'siteReport', 'gravitate', 'gravitateShell', 'wallEnd', 'environmentSettings', 'mepFittings', 'mepFittingsRemove', 'mepOpenings', 'mepOpeningsRemove', 'ductAccessory', 'pipeAccessory', 'ductFlex', 'pipeFlex', 'ductSizeOptimizer', 'hydronicsOptimizer', 'convertToEquipment', 'mepSystemBrowser', 'mepQuality', 'selectConnectedMep', 'pointLoad', 'lineLoad', 'surfaceLoad', 'flip', 'fixStair', 'wallJoins', 'paint', 'removePaint', S, 'groupCreate', 'groupEdit', 'ungroup', S, 'seo', 'convertToMorph', 'morphSolidity', 'morphCover', 'morphCurve', 'morphSegments', 'morphSmooth', 'morphIntersect', 'mergeElements', 'collisions', 'physicalQuality', 'energy', 'thermalBridge', S, 'designOptions', 'phases', 'demolish']],
  ['Document', ['dimension', 'revertDimTexts', 'autoDimExterior', 'interiorDim', 'autoLevelDims', 'dimLinear', 'dimAngular', 'dimRadial', 'spotElevation', 'spotSlope', 'hotspot', S, 'parapetDims', 'parapetRefresh', 'parapetRemove', 'convertDims', 'refreshConvertedDims', 'removeConvertedDims', S, 'text', 'tag', 'tagAll', 'tagSelected', 'keynote', 'keynoteManager', 'elementIdManager', S, 'region', 'detailLine', 'detailArc', 'spline', 'detailItem', 'insulation', 'revisionCloud', S, 'section', 'elevation', 'interiorElevations', 'callout', 'draftingView', 'saveWorksheet', 'independentDrawing', 'newDocument3d', 'document3dSettings', 'rebuild3dDocument', 'open3dDocuments', 'last3dDocument', 'legend', S, 'schedule', 'sheet', 'masterLayouts', 'placeView', 'linkDrawingTo', 'cropDrawings', 'uncropDrawings', 'checkMarkers', 'highlightSourceMarkers', 'revisions', 'newTransmittal', 'addToTransmittal', 'removeFromTransmittal', 'closeTransmittal', 'reopenTransmittal', 'deleteTransmittal', 'transmittalDetails', 'transmittalHistory', 'changeManager', S, 'sunStudy', 'simTaskList', 'simAnimation', 'simOpen', 'simSave', 'simSaveAs', 'renderRegion', 'renderRegionCrop', 'renderSafeFrame', 'alignView', 'textureOrigin', 'textureDirection', 'textureReset', 'checkSpelling']],
  ['Options', ['layerSettings', S, 'projectInfo', 'projectNotes', 'checkSurfaces', 'units', 'materials', 'fillTypes', 'profiles', 'classifications', 'zoneCategories', 'areaRules', 'lineStyles', 'lineWeights', 'textStyles', 'objectStyles', S, 'levels', 'hydronicSettings', 'electricalSettings', 'referenceLevels', 'refLevel1', 'refLevel2', 'types', 'projectParams', 'keynoteManager', 'globalParams', S, 'snaps', 'shortcuts', 'options', 'theme']],
  ['Teamwork', ['share', 'syncComment', 'syncHistory', 'worksets', 'viewWorksets', 'sharedWithMe', S, 'issues', 'modelCompare']],
  ['Window', ['view3d', 'newView3d', 'planViews', S, 'fullScreen', 'firstLayout', 'lastLayout', 'hideTabBar', 'hideQuickOptions', 'polyCount', S, 'hideAllLayers', 'lockAllLayers', 'showHideLayersToggle', 'lockUnlockLayersToggle', S, 'quickLayers', 'traceReference', 'traceToggle', 'modelCompare', 'undoHistory', 'render', 'flythrough', 'sunSettings', S, 'warnings', 'checkRequirements', 'checkSystems', 'loads', S, 'assistant', 'search']],
  ['Help', ['help', 'shortcuts', 'about']],
];

/** Commands of a selection's contextual panels that the Info Box offers (the rest are in the menus). */
const INFO_COMMANDS = new Set(['roofWizard', 'pointLoad', 'lineLoad', 'surfaceLoad', 'morphIntersect', 'cropZone', 'flipRailing', 'morphSegments', 'mergeElements', 'collarBeams', 'tieBeams', 'wallAccessories', 'slabAccessories', 'roofAccessories', 'morphCurve', 'cornerWindow', 'railingOn', 'fixStair', 'flip', 'attachTop', 'detachTop', 'roofFraming', 'editCurtain', 'editBoundary', 'groupEdit', 'ungroup']);

// Icons of the Standard toolbar's menus.
const MENU_ICONS = { Guides: 'refPlane', Grids: 'grid', 'Trace & Reference': 'linkProject', Groups: 'group', '3D Cutaway - Toolbar': 'sectionBox', Layers: 'worksets', 'Arrange': 'align' };

export class Workspace {
  constructor(app) {
    this.app = app;
    this.on = false;
    const shell = app.shell;
    this.menubar = h('nav.ac-menubar', { role: 'menubar', 'aria-label': 'Menus', hidden: true });
    // Archicad's Standard toolbar under the menus, then the user's own toolbars.
    this.standard = h('div.ac-standard', { role: 'toolbar', 'aria-label': 'Standard', hidden: true });
    this.userBars = h('div.ac-user-bars', { hidden: true });
    this.selBox = h('div.ac-info-sel', { role: 'group', 'aria-label': 'Selection' });
    this.infobox = h('div.ac-infobox', { role: 'region', 'aria-label': 'Info Box', hidden: true }, this.selBox);
    this.toolbox = h('aside.ac-toolbox', { 'aria-label': 'Toolbox', hidden: true });
    this.editBar = h('div.ac-standard.ac-edit-bar', { role: 'toolbar', 'aria-label': 'Edit' });
    window.addEventListener('bd-show-how', (e) => this.showHow(e.detail));
    this.build();
    shell.titlebar.after(this.menubar);
    this.menubar.after(this.standard);
    this.standard.after(this.userBars);
    // The Info Box runs across the window under the Standard toolbar, as in Archicad.
    this.userBars.after(this.infobox);
    shell.main.prepend(this.toolbox);
  }

  /** The work environment's customisation (core/workenv.js). */
  get custom() {
    return normCustom(this.app.settings.acCustom);
  }

  /** A toolbar button for a command. */
  barButton(cmd, label) {
    const app = this.app;
    const d = cmd && app.commandDef(cmd);
    return h('button.ac-std-btn', { type: 'button', disabled: !d, 'data-tip': label, 'aria-label': label, onClick: () => d && app.run(cmd) }, icon(d?.icon || 'circle', 16));
  }

  /** Menus, toolbars and Toolbox from Archicad's layout with the user's customisation; again after it changes. */
  build() {
    const app = this.app;
    const c = this.custom;
    const labelOf = (cmd) => this.label(cmd);
    clear(this.menubar);
    for (const m of customMenubar(AC_MENUBAR, c, labelOf)) {
      const btn = h('button.ac-menu-btn', { type: 'button', role: 'menuitem', 'aria-haspopup': 'menu' }, m.label === 'Window' && this.tr('Window') !== 'Window' ? 'Finestre' : this.tr(m.label));
      btn.addEventListener('click', () => showMenu(btn, this.treeItems(m.label === 'Help' && !m.custom ? [...m.items, null, { label: 'Building Design', items: this.extraNodes() }] : m.items), { label: m.label }));
      this.menubar.append(btn);
    }
    if (this.on && this.menuTitle) this.menubar.append(this.menuTitle, this.menuRight);
    clear(this.standard);
    this.standard.classList.toggle('ac-off', c.toolbars.standard === false);
    for (const it of customStandard(AC_STANDARD_TOOLBAR, c)) {
      if (!it) {
        this.standard.append(h('span.ac-std-sep', { role: 'separator' }));
        continue;
      }
      if (it.items) {
        const b = h('button.ac-std-btn.ac-std-menu', { type: 'button', 'aria-haspopup': 'menu', 'aria-label': this.tr(it.label), 'data-tip': this.tr(it.label) }, icon(MENU_ICONS[it.label] || 'tile', 16), h('span', this.tr(it.label)), icon('chevron-down', 9));
        b.addEventListener('click', () => showMenu(b, this.treeItems(it.items), { label: it.label }));
        this.standard.append(b);
        continue;
      }
      const bb = this.barButton(it.cmd, this.tr(it.label));
      if (it.cmd === 'measure') bb.append(h('span.ac-std-text', this.tr('Measure')));
      this.standard.append(bb);
    }
    // Archicad's second row: the edits of the selection, with their names.
    clear(this.editBar);
    for (const [cmd, label] of [['move', 'Move'], ['rotate', 'Rotate'], ['mirrorPick', 'Mirror'], ['array', 'Multiply...']]) {
      const d = app.commandDef(cmd);
      if (!d) continue;
      const b = h('button.ac-std-btn.ac-std-menu', { type: 'button', 'data-tip': this.tr(label), 'data-cmd': cmd, onClick: () => app.run(cmd) }, icon(d.icon, 16), h('span', this.tr(label)));
      this.editBar.append(b);
    }
    clear(this.userBars);
    for (const bar of c.toolbars.user || []) {
      if (!bar?.cmds?.length) continue;
      this.userBars.append(h('div.ac-standard.ac-user-bar', { role: 'toolbar', 'aria-label': bar.name }, h('span.ac-user-bar-name', bar.name), ...bar.cmds.map((cmd) => (cmd ? this.barButton(cmd, labelOf(cmd)) : h('span.ac-std-sep', { role: 'separator' })))));
    }
    this.userBars.prepend(this.editBar);
    clear(this.toolbox);
    this.buttons = new Map();
    // Archicad's Toolbox: Select, Design, Viewpoint and Document, its tools in its order.
    for (const sec of customToolbox(AC_TOOLBOX, c, labelOf)) {
      const list = h('div.ac-tb-list', { role: 'toolbar', 'aria-label': this.tr(sec.title), 'aria-orientation': 'vertical' });
      for (const t of sec.tools) {
        const d = t.cmd && app.commandDef(t.cmd);
        const b = h('button.ac-tool', { type: 'button', disabled: !d, 'aria-pressed': 'false', 'data-tip': this.tr(t.label), 'data-tip-desc': (t.cmd && toolHelp(t.cmd, this.lang)?.text) || (d ? d.desc : 'Not available yet'), 'data-tip-media': t.cmd && toolHelp(t.cmd, this.lang) ? `./tips/${t.cmd}.webp` : undefined, 'data-tip-cmd': t.cmd, 'data-tip-how': this.tr('Show me how'), onClick: () => d && app.run(t.cmd) }, icon(d?.icon || 'circle', 17), h('span', this.tr(t.label)));
        if (d && !this.buttons.has(t.cmd)) this.buttons.set(t.cmd, b);
        list.append(b);
      }
      if (sec.title === 'Select') {
        this.toolbox.append(list);
        continue;
      }
      // Each section folds under its heading, as in Archicad.
      const key = `bd.toolbox.${sec.title}`;
      const folded = () => localStorage.getItem(key) === '1';
      const arrow = icon('chevron-down', 11);
      const head = h('div.ac-tb-head', { role: 'button', tabindex: '0', 'aria-expanded': String(!folded()) }, arrow, sec.title === 'Design' ? 'Design' : this.tr(sec.title));
      const paint = () => {
        list.hidden = folded();
        head.setAttribute('aria-expanded', String(!folded()));
        arrow.style.transform = folded() ? 'rotate(-90deg)' : '';
      };
      head.addEventListener('click', () => {
        localStorage.setItem(key, folded() ? '0' : '1');
        paint();
      });
      paint();
      this.toolbox.append(head, list);
    }
  }

  /** Apply a changed customisation. */
  rebuild() {
    this.build();
    this.apply(this.on);
  }

  get lang() {
    return uiLanguage(this.app.settings);
  }

  /** The film of a tool, its steps, and a way to try it. */
  showHow({ cmd, media, title, text }) {
    const app = this.app;
    const steps = toolHelp(cmd, this.lang)?.steps || [];
    const body = h('div', { style: { maxWidth: '520px' } }, h('p', { style: { whiteSpace: 'pre-line', margin: '0 0 10px' } }, text || ''), h('img', { src: media, alt: '', style: { display: 'block', width: '100%', borderRadius: '6px', background: '#eee' } }), steps.length ? h('ol', { style: { margin: '10px 0 0', paddingLeft: '20px' } }, ...steps.map((x) => h('li', x))) : null);
    return openDialog({ title, body, actions: [{ label: this.lang === 'it' ? 'Chiudi' : 'Close', value: null }, { label: this.lang === 'it' ? 'Prova ora' : 'Try it', primary: true, onClick: () => app.run(cmd) }] });
  }

  /** A label in the interface's language. */
  tr(label) {
    return translateLabel(label, uiLanguage(this.app.settings));
  }

  label(cmd) {
    return this.tr(AC_TERMS[cmd] || this.app.commandDef(cmd)?.label || cmd);
  }

  menuItems(cmds) {
    const app = this.app;
    const out = [];
    for (const cmd of cmds) {
      if (cmd === S) {
        if (out.length && !out.at(-1).separator) out.push({ separator: true });
        continue;
      }
      const d = app.commandDef(cmd);
      if (!d) continue;
      const active = app.isCommandActive(cmd);
      out.push({
        label: this.label(cmd),
        icon: d.icon,
        shortcut: (cmd === 'view3d' ? 'F3' : cmd === 'show3d' ? 'F5' : acShortcut(cmd) || d.accel || d.keys) || undefined,
        disabled: !!(d.enabled && !d.enabled(app)),
        checked: d.toggle || cmd === 'thinLines' || cmd === 'sectionBox' || cmd === 'workspace' ? !!active : undefined,
        action: () => app.run(cmd),
      });
    }
    if (out.at(-1)?.separator) out.pop();
    return out;
  }

  /** Menu items for a part of Archicad's menu tree: its commands, greyed where the app has none yet. */
  treeItems(nodes) {
    const app = this.app;
    const out = [];
    for (const n of nodes) {
      if (!n) {
        if (out.length && !out.at(-1).separator) out.push({ separator: true });
        continue;
      }
      if (n.items) {
        out.push({ label: this.tr(n.label), submenu: this.treeItems(n.items) });
        continue;
      }
      const d = n.cmd && app.commandDef(n.cmd);
      if (!d) {
        out.push({ label: this.tr(n.label), disabled: true, title: n.na ? 'Not part of this app (Archicad servers, licences or third-party add-ons)' : 'Not available yet' });
        continue;
      }
      const active = app.isCommandActive(n.cmd);
      out.push({
        label: this.tr(n.label),
        icon: d.icon,
        shortcut: keyLabel(n.keys) || undefined,
        disabled: !!(d.enabled && !d.enabled(app)),
        checked: d.toggle ? !!active : undefined,
        title: d.desc,
        action: () => app.run(n.cmd),
      });
    }
    while (out.at(-1)?.separator) out.pop();
    return out;
  }

  /** The app's own commands that Archicad's menus and Toolbox do not reach, under Help > Building Design. */
  extraNodes() {
    if (this.extras) return this.extras;
    const reached = new Set();
    const walk = (nodes) => nodes.forEach((n) => n && (n.items ? walk(n.items) : n.cmd && reached.add(n.cmd)));
    AC_MENUBAR.forEach((m) => walk(m.items));
    walk(AC_STANDARD_TOOLBAR);
    AC_TOOLBOX.forEach((g) => g.tools.forEach((t) => t.cmd && reached.add(t.cmd)));
    const rest = MENUS.flatMap(([title, cmds]) => cmds.filter((c) => c && !reached.has(c) && this.app.commandDef(c)).map((c) => ({ title, cmd: c })));
    const groups = new Map();
    for (const r of rest) (groups.get(r.title) || groups.set(r.title, []).get(r.title)).push({ label: this.label(r.cmd), cmd: r.cmd });
    this.extras = [...groups].map(([title, items]) => ({ label: title, items: [...new Map(items.map((i) => [i.cmd, i])).values()] }));
    return this.extras;
  }

  /**
   * Arrange the running tool's options as Archicad's Info Box: its panels in its order, each with its caption.
   * The tool's own controls go under the panel they belong to; Layer and Structure (the type) are added here.
   */
  arrangeInfo(bar) {
    const app = this.app;
    const t = app.tool;
    const cmd = t?.commandName;
    const panels = cmd && AC_INFOBOX[cmd] && customPanels(AC_INFOBOX[cmd], this.custom, cmd);
    if (!this.on || !panels || !bar.childElementCount) return;
    const kind = t.placingKind || t.kind;
    const byPanel = new Map();
    const rest = [];
    const put = (panel, el) => (byPanel.get(panel) || byPanel.set(panel, []).get(panel)).push(el);
    const pick = (cands) => cands.find((c) => panels.includes(c));
    for (const el of [...bar.children]) {
      if (el.classList.contains('ob-title') || el.classList.contains('ob-sep')) {
        el.remove();
        continue;
      }
      if (el.classList.contains('fav-btn')) {
        put('Main', el);
        continue;
      }
      const name = (el.classList.contains('seg') ? el.getAttribute('aria-label') : el.querySelector('select[aria-label="Gravity"]') ? 'Gravity' : el.firstElementChild?.textContent || el.textContent || '').trim().toLowerCase();
      const panel =
        el.classList.contains('seg') ? pick(['Geometry Method', 'Dimension Type', 'Input Method', 'Turning Type'])
        : name.startsWith('top') ? pick(['Bottom and Top', 'Height', 'Elevation'])
        : name.startsWith('offset') ? pick(['Bottom and Top', 'Elevation'])
        : name.startsWith('location line') ? pick(['Reference Line Location', 'Reference Plane Location', 'Reference Axis and Offset'])
        : name.startsWith('sill') ? pick(['Sill or Header Height', 'Sill / Header Height'])
        : name.startsWith('slope') ? pick(['Roof Pivot Height and Pitch'])
        : name.startsWith('overhang') ? pick(['Eaves Overhang'])
        : name.startsWith('width') ? pick(['Width', 'Size', 'Dimensions'])
        : name.startsWith('style') ? pick(['Line Type'])
        : name.startsWith('pattern') ? pick(['Fill Type'])
        : name.startsWith('size on paper') ? pick(['Font Size and Rotation', 'Font Size'])
        : name.startsWith('name') ? pick(['Zone Name And Number'])
        : name === 'gravity' ? 'Main'
        : null;
      if (panel) put(panel, el);
      else rest.push(el);
    }
    // Layer: where the new elements go (core/layers.js).
    const doc = app.doc;
    if (panels.includes('Layer') && kind && doc.count('layer')) {
      const o = app.toolOptions(kind, {});
      const def = layerIdOf(doc, { kind, typeId: app.currentType?.(kind)?.id });
      const sel = h('select.input.sm', { 'aria-label': 'Layer' }, ...layersInOrder(doc).map((l) => h('option', { value: l.id, selected: l.id === (o.layerId || def) }, l.name)));
      sel.addEventListener('change', () => (o.layerId = sel.value));
      sel.addEventListener('keydown', (e) => e.stopPropagation());
      put('Layer', sel);
    }
    // Structure (or the element's type): the type the tool places.
    const typePanel = pick(['Structure', 'Element', 'Structure & Finish', 'Zone Category', 'Wall Thickness', 'Cross-Section Size', 'Thickness']);
    const type = kind && app.currentType?.(kind);
    if (typePanel && type) {
      const sel = h('select.input.sm.ac-info-type', { 'aria-label': typePanel }, ...doc.all(type.kind).map((x) => h('option', { value: x.id, selected: x.id === type.id }, x.name)));
      sel.addEventListener('change', () => {
        app.setCurrentType(kind, sel.value);
        app.renderOptions();
      });
      sel.addEventListener('keydown', (e) => e.stopPropagation());
      put(typePanel, sel);
    }
    clear(bar);
    for (const p of ['Main', ...panels.filter((x) => x !== 'Main'), 'Gravity']) {
      const els = byPanel.get(p);
      if (!els?.length) continue;
      bar.append(h('div.ac-panel', h('span.ac-panel-cap', p === 'Main' ? this.tr('Main:') : this.tr(p)), h('div.ac-panel-body', ...els)));
      byPanel.delete(p);
    }
    for (const els of byPanel.values()) bar.append(h('div.ac-panel', h('div.ac-panel-body', ...els)));
    if (rest.length) bar.append(h('div.ac-panel', h('div.ac-panel-body', ...rest)));
  }

  /** Switch the workspace on or off. */
  apply(on) {
    const { shell } = this.app;
    this.on = !!on;
    shell.root.classList.toggle('ws-ac', this.on);
    this.menubar.hidden = !this.on;
    // One band for the menus, the project's name and the search, as the Archicad window has.
    const right = shell.titlebar.querySelector('.tb-right') || this.menuRight;
    if (right) this.menuRight = right;
    // On a phone the menus give way to the title band, which keeps these.
    if (this.on && !window.matchMedia?.('(max-width: 720px)').matches) {
      this.menuTitle ||= h('div.ac-menu-title');
      this.menuTitle.replaceChildren(shell.title);
      if (right) this.menubar.append(this.menuTitle, right);
    } else {
      shell.titlebar.insertBefore(shell.title, this.menuRight || null);
      if (this.menuRight) shell.titlebar.append(this.menuRight);
    }
    this.standard.hidden = !this.on || this.custom.toolbars.standard === false;
    this.userBars.hidden = !this.on;
    this.editBar.hidden = !this.on;
    // Archicad's right side is the Navigator; element settings are in the Info Box and the Settings dialog
    // (Window > Palettes > Element Information shows the Properties panel again).
    if (this.on && !this.app.settings.acShowProps) shell.dock.classList.add('props-hidden');
    if (this.on) applyPalettes(this.app);
    this.infobox.hidden = !this.on;
    this.toolbox.hidden = !this.on;
    // The tool options sit in the Info Box while the workspace is on.
    if (this.on) this.infobox.append(shell.optionsbar);
    else this.infobox.after(shell.optionsbar);
    this.app.renderBrowser?.();
    this.app.renderViewbar?.();
    this.update();
    this.app.viewport?.resize?.();
  }

  /** Follow the running tool and the selection. */
  update() {
    if (!this.on) return;
    const app = this.app;
    for (const [cmd, b] of this.buttons) b.setAttribute('aria-pressed', String(!!app.isCommandActive(cmd)));
    for (const b of this.editBar.children) b.disabled = !app.selection.size;
    const toolOn = !app.isCommandActive('modify');
    clear(this.selBox);
    if (toolOn) {
      // Archicad's Main panel of a tool: its name, its default Settings and its Favorites; the tool's options follow.
      const cmd = app.tool?.commandName;
      const kind = app.tool?.placingKind || app.tool?.kind;
      const d = cmd && app.commandDef(cmd);
      this.selBox.hidden = !d;
      if (!d) return;
      this.selBox.append(icon(d.icon, 16), h('span.ac-info-what', this.label(cmd)));
      const type = kind && app.currentType?.(kind);
      if (type) {
        this.selBox.append(h('button.btn.sm', { type: 'button', 'data-tip': `${this.label(cmd)} default settings`, onClick: () => app.showTypeProperties(type, kind) }, icon('types', 14), this.tr('Settings...')));
      }
      return;
    }
    this.selBox.hidden = false;
    const doc = app.doc;
    const sel = [...app.selection].map((id) => doc?.get(id)).filter(Boolean);
    if (!sel.length) {
      // The Arrow tool's own panels: how many elements are selected, and how to begin.
      this.selBox.append(icon('modify', 16), h('span.ac-info-what', this.label('modify')), h('div.ac-panel', h('span.ac-panel-cap', this.tr('Selected')), h('div.ac-panel-body', '0')), h('span.ac-info-hint', this.tr('Select elements, or choose a tool in the Toolbox.')));
      return;
    }
    const kinds = [...new Set(sel.map((e) => e.kind))];
    const what = kinds.length > 1 ? `${sel.length} elements` : sel.length === 1 ? KIND_LABEL[kinds[0]] || VIEW_LABEL[kinds[0]] || kinds[0] : `${sel.length} ${pluralLabel(kinds[0])}`;
    this.selBox.append(h('span.ac-info-what', what));
    // The type of a selection of one kind, changed for all at once.
    const typeIds = [...new Set(sel.map((e) => e.typeId).filter(Boolean))];
    const typeKind = typeIds.length ? doc.get(typeIds[0])?.kind : null;
    if (kinds.length === 1 && typeKind) {
      const select = h('select.input.ac-info-type', { 'aria-label': 'Type' });
      if (typeIds.length > 1) select.append(h('option', { value: '', selected: true, disabled: true }, 'Varies'));
      for (const t of doc.all(typeKind)) select.append(h('option', { value: t.id, selected: typeIds.length === 1 && t.id === typeIds[0] }, t.name));
      select.addEventListener('change', () => app.commit('Change type', () => sel.forEach((e) => doc.update(e.id, { typeId: select.value }))));
      this.selBox.append(select);
    }
    const settings = h('button.btn.sm', { type: 'button', 'data-tip': 'Type settings of the selection', onClick: () => app.run('editType') }, icon('types', 14), this.tr('Settings...'));
    this.selBox.append(settings);
    // Favorites of the selection's tool: apply one, or save the selection's settings.
    if (kinds.length === 1 && (typeKind || kinds[0] === 'room')) this.selBox.append(app.favoritesButton(kinds[0]));
    // The layer of the selection, changed for all at once (core/layers.js).
    const layerIds = [...new Set(sel.map((e) => layerIdOf(doc, e)).filter(Boolean))];
    if (layerIds.length) {
      const select = h('select.input.ac-info-layer', { 'aria-label': 'Layer', 'data-tip': 'Layer' });
      if (layerIds.length > 1) select.append(h('option', { value: '', selected: true, disabled: true }, 'Layers vary'));
      for (const l of layersInOrder(doc)) select.append(h('option', { value: l.id, selected: layerIds.length === 1 && l.id === layerIds[0] }, l.name));
      select.addEventListener('change', () => app.commit('Change layer', () => sel.forEach((e) => layered(doc, e) && doc.update(e.id, { layerId: select.value }))));
      this.selBox.append(icon('worksets', 15), select);
    }
    for (const p of contextualPanels(kinds))
      for (const it of p.items) {
        if (!INFO_COMMANDS.has(it.cmd)) continue;
        const d = app.commandDef(it.cmd);
        if (d) this.selBox.append(h('button.btn.sm', { type: 'button', onClick: () => app.run(it.cmd) }, icon(d.icon, 14), this.label(it.cmd)));
      }
  }
}
