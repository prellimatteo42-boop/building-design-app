/**
 * SiteMaker (Design > SiteMaker): Create New Site from a survey file with its
 * options, and Mesh from Outline (a contour with corner heights and ridges).
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import * as files from '../io/files.js';
import { formatLength, parseLength } from '../core/units.js';
import { parseSurveyPoints, centrePoints, SURVEY_ORDERS } from '../core/topo.js';
import { newSite, meshFromOutline, PRECISIONS, OUTLINES } from '../core/sitemaker.js';
import { levelElevation } from '../core/model.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const sel = (label, options, value) => {
  const s = h('select.input', { 'aria-label': label }, options.map((o) => h('option', { value: o.value }, o.label)));
  s.value = value;
  return s;
};
const lenIn = (app, v, label) => {
  const i = h('input.input', { type: 'text', value: formatLength(v, app.doc.units), 'aria-label': label, spellcheck: 'false' });
  i.addEventListener('keydown', (e) => e.stopPropagation());
  i.read = () => parseLength(i.value, app.doc.units);
  return i;
};

/** The plan outline of a selected element: a slab, fill, morph, mass or room. */
function selectedOutline(app) {
  for (const id of app.selection) {
    const el = app.doc.get(id);
    if (!el) continue;
    if (Array.isArray(el.boundary) && el.boundary.length >= 3) return el.boundary;
    if (el.kind === 'room') {
      const r = app.scene.rooms.room(el);
      if (r?.outer?.length >= 3) return r.outer;
    }
  }
  return null;
}

export async function createSiteDialog(app) {
  const f = await files.pickFile('.csv,.txt,.xyz,.pts,text/plain,text/csv');
  if (!f) return;
  const text = await f.text();
  const imp = app.doc.units.system === 'imperial';
  const lot = selectedOutline(app);
  const order = sel('Columns', SURVEY_ORDERS, 'auto');
  const unit = sel('Unit', ['m', 'mm', 'cm', 'ft'].map((u) => ({ value: u, label: u })), 'm');
  const precision = sel('Precision', PRECISIONS, 'fine');
  const outline = sel('Outline', OUTLINES.filter((o) => o.value !== 'lot' || lot), 'hull');
  const margin = lenIn(app, imp ? 3048 : 3000, 'Margin');
  const thick = lenIn(app, imp ? 914.4 : 1000, 'Ground thickness');
  const contour = lenIn(app, imp ? 304.8 : 500, 'Contour interval');
  const centre = h('input', { type: 'checkbox', checked: !lot });
  const info = h('p.field-hint');
  const update = () => {
    const pts = parseSurveyPoints(text, { order: order.value, unit: unit.value });
    const site = pts.length >= 3 ? newSite(pts, { precision: precision.value, outline: 'hull' }) : null;
    info.textContent = pts.length ? `${pts.length} points in the file${site ? `, ${site.points.length} kept at this precision` : ''}.` : 'No points found: each line needs three numbers (or an ID and three numbers).';
  };
  for (const c of [order, unit, precision]) c.addEventListener('change', update);
  update();
  const ok = await openDialog({
    title: 'Create New Site',
    size: 'sm',
    body: h(
      'div',
      h('p.dialog-text', f.name),
      h('div.row2', field('Columns', order), field('Unit', unit)),
      h('div.row2', field('Precision', precision), field('Outline', outline)),
      h('div.row2', field('Margin (rectangle)', margin), field('Ground thickness', thick)),
      field('Contour interval', contour),
      h('label.check', centre, h('span', 'Move the points so their middle is at the project origin')),
      info,
    ),
    actions: [
      { label: 'Cancel', value: null },
      { label: 'Create Site', primary: true, value: true },
    ],
  });
  if (!ok) return;
  let pts = parseSurveyPoints(text, { order: order.value, unit: unit.value });
  if (pts.length < 3) return toast('A site needs at least three points.', { kind: 'error' });
  if (centre.checked) pts = centrePoints(pts);
  const site = newSite(pts, { precision: precision.value, outline: outline.value, margin: margin.read(), lot, thickness: thick.read(), contour: contour.read() });
  if (!site) return toast('Too few points left at that precision.', { kind: 'error' });
  let el;
  app.commit('Create new site', () => (el = app.doc.add(site)));
  app.select([el.id]);
  toast(`Site made from ${site.points.length} points.`, { kind: 'success' });
}

/** Mesh from Outline: the selected outline (slab, fill, room) with corner heights and the selected lines as ridges. */
export async function meshOutlineDialog(app) {
  const doc = app.doc;
  const outline = selectedOutline(app);
  if (!outline) return toast('Select a slab, fill, morph or room whose outline the mesh takes (and lines for its ridges).', { kind: 'error' });
  const lines = [...app.selection].map((id) => doc.get(id)).filter((el) => el?.a && el?.b && ['line', 'detailLine', 'modelLine', 'roomSeparator'].includes(el.kind));
  const levelId = app.activeView?.levelId || doc.levels()[0]?.id;
  const z0 = levelElevation(doc, levelId);
  const base = lenIn(app, 0, 'Height of the corners');
  const corners = outline.map((p, i) => lenIn(app, 0, `Corner ${i + 1} height`));
  const ridgeIns = lines.map((l, i) => [lenIn(app, 0, `Ridge ${i + 1} start height`), lenIn(app, 0, `Ridge ${i + 1} end height`)]);
  const thick = lenIn(app, 500, 'Thickness');
  const body = h(
    'div',
    h('p.field-hint', 'Heights above the story. Leave a corner at 0 to take the common height.'),
    h('div.row2', field('Common height', base), field('Thickness', thick)),
    h('h3.dlg-sub', 'Corners'),
    h('div.row2', corners.map((c, i) => field(`Corner ${i + 1}`, c))),
    lines.length ? h('h3.dlg-sub', 'Ridges') : null,
    ...ridgeIns.map(([a, b], i) => h('div.row2', field(`Ridge ${i + 1}: start`, a), field('end', b))),
  );
  const ok = await openDialog({ title: 'Mesh from Outline', size: 'md', body, actions: [{ label: 'Cancel', value: null }, { label: 'Make Mesh', primary: true, value: true }] });
  if (!ok) return;
  const common = base.read() || 0;
  const heights = corners.map((c) => {
    const v = c.read();
    return z0 + (v ? v : common);
  });
  const ridges = lines.map((l, i) => [[l.a[0], l.a[1], z0 + (ridgeIns[i][0].read() || common)], [l.b[0], l.b[1], z0 + (ridgeIns[i][1].read() || common)]]);
  const mesh = meshFromOutline(outline, { z: z0 + common, heights, ridges, thickness: thick.read() || 500 });
  let el;
  app.commit('Mesh from outline', () => (el = doc.add({ ...mesh, levelId })));
  app.select([el.id]);
}
