/**
 * Create MEP Fittings: elbows, tees, crosses and transitions where runs meet
 * (core/mepfittings.js); fittings made before are replaced, so running it
 * again after editing the runs brings them up to date.
 */
import { fittingsFor } from '../core/mepfittings.js';

export function createFittings(app) {
  const doc = app.doc;
  const made = fittingsFor(doc);
  const old = doc.all('mepFitting').filter((f) => f.auto);
  app.commit('Create MEP fittings', () => {
    for (const f of old) doc.remove(f.id);
    for (const f of made) doc.add(f);
  });
  const by = {};
  for (const f of made) by[f.fittingType] = (by[f.fittingType] || 0) + 1;
  app.toast(made.length ? `MEP fittings: ${Object.entries(by).map(([k, n]) => `${n} ${k}${n === 1 ? '' : 's'}`).join(', ')}.` : 'No joints between runs need a fitting.');
  return made;
}

/** Remove the fittings made automatically; the runs meet again end to end. */
export function removeFittings(app) {
  const old = app.doc.all('mepFitting');
  app.commit('Remove MEP fittings', () => old.forEach((f) => app.doc.remove(f.id)));
  app.toast(`Removed ${old.length} fitting${old.length === 1 ? '' : 's'}.`);
}
