/**
 * Library Developer menu: GDL messages, the check of library scripts, the
 * parts a selected element uses, model data and IFC content checks, and the
 * classification mapping by category.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { download } from '../io/storage.js';
import { safeFileName } from '../io/native.js';
import { makeZip } from '../io/zip.js';
import { writeIFC } from '../io/ifc.js';
import { gdlMessages } from '../core/gdl.js';
import { libraryIssues, partIssues, partsOfType, typeScripts } from '../core/gdlcheck.js';
import { missingBimData, checkIfcText } from '../core/bimcheck.js';
import { classifiable, classTree, classLabel } from '../core/classify.js';
import { categoryOf, CATEGORIES } from '../core/catalog.js';

const scrollBox = (...c) => h('div', { style: { maxHeight: '55vh', overflow: 'auto' } }, ...c);
const table = (head, rows) => h('table.vg-table', h('thead', h('tr', head.map((c) => h('th', c)))), h('tbody', rows));
const closeOnly = [{ label: 'Close', value: null }];
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

/** Always Send GDL Messages: PRINT and the errors of running scripts go to the messages window. */
export function toggleGdlMessages(app) {
  gdlMessages.on = !gdlMessages.on;
  app.settingsStore.set('gdlMessages', gdlMessages.on);
  toast(gdlMessages.on ? 'GDL messages are collected now.' : 'GDL messages are off.');
}

/** The window of GDL messages. */
export function gdlMessagesWindow(app) {
  const list = h('div', { style: { maxHeight: '55vh', overflow: 'auto', font: '12px/1.4 ui-monospace, monospace', minHeight: '120px' } });
  const render = () => list.replaceChildren(...(gdlMessages.list.length ? gdlMessages.list.map((m) => h('div', `${m.line ? `line ${m.line}: ` : ''}${m.text}`)) : [h('p.field-hint', gdlMessages.on ? 'No messages yet: PRINT in a script, or its errors, appear here.' : 'Turn on Always Send GDL Messages to collect them.')]));
  render();
  const off = gdlMessages.subscribe(render);
  return openDialog({
    title: 'GDL Messages',
    size: 'lg',
    body: list,
    actions: [
      { label: 'Clear', onClick: () => (gdlMessages.clear(), render(), false) },
      { label: 'Close', value: null },
    ],
  }).finally?.(off);
}

const issueRows = (name, list) => list.map((it) => h('tr', h('td', name), h('td', it.script || ''), h('td', String(it.line)), h('td', { style: { color: it.level === 'error' ? 'var(--danger, #c33)' : 'inherit' } }, it.level === 'error' ? 'Error' : 'Warning'), h('td', it.message)));

/** Check Library Part Scripts for Warnings: every part of the project and the loaded libraries. */
export function checkLibraryScripts(app) {
  const doc = app.doc;
  const lib = app.acLibrary;
  const types = doc.all('componentType', 'doorType', 'windowType').filter((t) => t.gdl);
  const parts = [];
  const seen = new Set();
  const inType = (t) => (n) => !!t.gdl.macros?.[n.toLowerCase()] || !!lib?.parts.has(n.toLowerCase());
  const found = [];
  for (const t of types) {
    seen.add((t.name || '').toLowerCase());
    const issues = partIssues(typeScripts(t), { hasMacro: inType(t) });
    if (issues.length) found.push({ name: t.name, issues });
    parts.push(t.name);
  }
  let count = types.length;
  if (lib) {
    const list = [...lib.parts.keys()].filter((k) => !seen.has(k)).map((k) => lib.get(k)).filter((e) => e?.lp?.scripts);
    count += list.length;
    found.push(...libraryIssues(list.map((e) => ({ name: e.name, scripts: e.lp.scripts })), { hasMacro: (n) => lib.parts.has(n.toLowerCase()) }));
  }
  if (!count) return toast('No GDL parts in the project or loaded libraries.', { kind: 'error' });
  const rows = found.flatMap((p) => issueRows(p.name, p.issues)).slice(0, 2000);
  const n = found.reduce((t, p) => t + p.issues.length, 0);
  return openDialog({ title: 'Library Part Script Check', size: 'lg', body: h('div', h('p', `${plural(count, 'part')} read: ${plural(found.length, 'part')} with ${plural(n, 'issue')}.`), rows.length ? scrollBox(table(['Part', 'Script', 'Line', 'Level', 'Message'], rows)) : h('p.field-hint', 'Nothing to report.')), actions: closeOnly });
}

/** Dump Library Parts of Selected Element: the parts it uses, and their scripts in a ZIP. */
export function dumpLibraryParts(app) {
  const doc = app.doc;
  const el = [...app.selection].map((id) => doc.get(id)).find((e) => doc.get(e?.typeId)?.gdl);
  if (!el) return toast('Select an element placed from a GDL part.');
  const type = doc.get(el.typeId);
  const parts = partsOfType(type);
  const rows = parts.map((p) => h('tr', h('td', p.name), h('td', p.role), h('td', p.path), h('td', Object.keys(p.scripts).join(', ')), h('td', String(Object.values(p.scripts).reduce((t, s) => t + s.split('\n').length, 0)))));
  const zip = () => {
    const enc = new TextEncoder();
    const files = parts.flatMap((p) => Object.entries(p.scripts).map(([k, s]) => ({ name: `${safeFileName(p.name)}/${k}.gdl`, data: enc.encode(s) })));
    download(new Blob([makeZip(files)], { type: 'application/zip' }), `${safeFileName(type.name || 'part')} - parts.zip`);
    return false;
  };
  return openDialog({ title: `Parts of ${type.name}`, size: 'lg', body: scrollBox(table(['Part', 'Role', 'Library path', 'Scripts', 'Lines'], rows)), actions: [{ label: 'Close', value: null }, { label: 'Save Scripts as ZIP', onClick: zip }] });
}

/** Check for Missing BIM Data. */
export function checkMissingBim(app) {
  const groups = missingBimData(app.doc);
  const body = groups.length
    ? table(['Problem', 'Elements', ''], groups.map((g) => h('tr', h('td', g.title), h('td', String(g.ids.length)), h('td', h('button.btn.sm', { type: 'button', onClick: () => (app.select(g.ids), toast(`${plural(g.ids.length, 'element')} selected.`)) }, 'Select')))))
    : h('p.field-hint', 'Every element has its classification, ID, name and material.');
  return openDialog({ title: 'Missing BIM Data', body, actions: closeOnly });
}

/** Check IFC Content: the model written as IFC, and read back. */
export function checkIfcContent(app) {
  let r;
  try {
    r = checkIfcText(writeIFC(app));
  } catch (err) {
    return toast(`The IFC could not be written: ${err?.message || err}`, { kind: 'error' });
  }
  const top = Object.entries(r.counts).filter(([k]) => /^IFC(WALL|SLAB|ROOF|COLUMN|BEAM|DOOR|WINDOW|STAIR|RAILING|COVERING|SPACE|FURNI|BUILDINGSTOREY|BUILDINGELEMENTPROXY|DUCT|PIPE|CABLE|FLOW|CURTAIN)/.test(k)).sort((a, b) => b[1] - a[1]);
  return openDialog({
    title: 'IFC Content',
    size: 'lg',
    body: h('div', h('p', `${r.schema}: ${plural(r.products, 'product')}.`), r.issues.length ? table(['Level', 'Problem', 'Count'], r.issues.map((i) => h('tr', h('td', i.level), h('td', i.title), h('td', String(i.count))))) : h('p.field-hint', 'Nothing to report.'), h('h3.dlg-sub', 'Entities'), scrollBox(table(['Entity', 'Count'], top.map(([k, v]) => h('tr', h('td', k), h('td', String(v))))))),
    actions: closeOnly,
  });
}

/** Subtype - Classification Mapping: which item each category of element takes. */
export function subtypeMapping(app) {
  const doc = app.doc;
  const systems = doc.all('classSystem');
  if (!systems.length) return toast('The project has no classification system.', { kind: 'error' });
  const sysSel = h('select.input', { 'aria-label': 'Classification system' }, systems.map((s) => h('option', { value: s.id }, s.name)));
  const box = h('div');
  const map = structuredClone(doc.get('project').subtypeMap || {});
  const used = new Set();
  for (const el of doc.items.values()) if (el.kind && classifiable(doc, el)) used.add(categoryOf(el, doc));
  const cats = CATEGORIES.filter((c) => used.has(c.id) || Object.values(map).some((m) => m[c.id]));
  const render = () => {
    const sys = doc.get(sysSel.value);
    const current = (map[sys.id] ||= {});
    const items = classTree(sys);
    box.replaceChildren(
      cats.length
        ? scrollBox(
            table(['Category', 'Classification'], cats.map((c) => {
              const s = h('select.input.sm', { 'aria-label': `Classification of ${c.label}` }, h('option', { value: '' }, 'Automatic'), items.map(({ item, depth }) => h('option', { value: item.code }, `${'  '.repeat(depth)}${classLabel(item)}`)));
              s.value = current[c.id] || '';
              s.addEventListener('change', () => (s.value ? (current[c.id] = s.value) : delete current[c.id]));
              return h('tr', h('td', c.label), h('td', s));
            })),
          )
        : h('p.field-hint', 'Nothing to classify in the project yet.'),
    );
  };
  sysSel.addEventListener('change', render);
  render();
  return openDialog({
    title: 'Subtype - Classification Mapping',
    size: 'lg',
    body: h('div', h('label.field', h('span.field-label', 'System'), sysSel), box, h('p.field-hint', 'Elements with no classification of their own take the item of their category.')),
    actions: [
      { label: 'Cancel', value: null },
      { label: 'OK', primary: true, onClick: () => (app.commit('Classification mapping', () => doc.update('project', { subtypeMap: map })), true) },
    ],
  });
}
