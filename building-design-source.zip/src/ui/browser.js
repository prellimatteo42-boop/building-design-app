/**
 * Project Browser: views, schedules, sheets and element types as a tree.
 * Full keyboard support (WAI-ARIA tree pattern), search filter, inline
 * rename (F2), context menus, and double-click (or Enter) to open a view or
 * place a type.
 *
 * In the Archicad workspace it is the Navigator, with four maps: the Project
 * Map (stories and the other viewpoints of the model), the View Map (views
 * with their scale and layer combination), the Layout Book (layouts and the
 * drawings placed on them), Favorites (saved settings and types, ready to
 * place) and Publisher Sets (views and layouts published together as PDF).
 */
import { h, clear } from './dom.js';
import { icon, KIND_ICON } from './icons.js';
import { showMenu } from './menu.js';
import { FAMILY_BY_KIND, CATEGORIES, KIND_LABEL } from '../core/catalog.js';
import { AREA_SCHEMES } from '../core/props.js';
import { scaleLabel } from '../core/units.js';

const TYPE_GROUPS = [
  { label: 'Walls', typeKind: 'wallType', kind: 'wall' },
  { label: 'Doors', typeKind: 'doorType', kind: 'door', byFamily: true },
  { label: 'Windows', typeKind: 'windowType', kind: 'window', byFamily: true },
  { label: 'Floors', typeKind: 'floorType', kind: 'floor' },
  { label: 'Roofs', typeKind: 'roofType', kind: 'roof' },
  { label: 'Ceilings', typeKind: 'ceilingType', kind: 'ceiling' },
  { label: 'Columns', typeKind: 'columnType', kind: 'column', byFamily: true },
  { label: 'Structural Framing', typeKind: 'beamType', kind: 'beam' },
  { label: 'Stairs', typeKind: 'stairType', kind: 'stair' },
  { label: 'Ramps', typeKind: 'rampType', kind: 'ramp' },
  { label: 'Railings', typeKind: 'railingType', kind: 'railing' },
  { label: 'Model Groups', typeKind: 'groupType', kind: 'group' },
  { label: 'Structural Foundations', typeKind: 'footingType', kind: 'footing' },
  { label: 'Wall Foundations', typeKind: 'wallFootingType', kind: 'wallFooting' },
  { label: 'Wall Sweeps and Reveals', typeKind: 'wallSweepType', kind: 'wallSweep' },
  { label: 'Structural Trusses', typeKind: 'trussType', kind: 'truss' },
  { label: 'Ducts', typeKind: 'ductType', kind: 'duct', byFamily: true },
  { label: 'Pipes', typeKind: 'pipeType', kind: 'pipe' },
  { label: 'Cable Trays', typeKind: 'cableTrayType', kind: 'cableTray' },
  { label: 'Conduits', typeKind: 'conduitType', kind: 'conduit' },
];

/** The Navigator's maps in the Archicad workspace. */
export const NAV_MAPS = [
  { id: 'project', label: 'Project Map', icon: 'project' },
  { id: 'views', label: 'View Map', icon: 'visibility' },
  { id: 'layouts', label: 'Layout Book', icon: 'sheet' },
  { id: 'favorites', label: 'Favorites', icon: 'types' },
  { id: 'publisher', label: 'Publisher Sets', icon: 'printer' },
];

/**
 * Story numbers as in Archicad: the story nearest elevation 0 is 0, those
 * above count up and those below count down. Map from level id.
 */
export function storyNumbers(levels) {
  const sorted = levels.slice().sort((a, b) => (+a.elevation || 0) - (+b.elevation || 0));
  let ground = 0;
  sorted.forEach((l, i) => {
    if (Math.abs(+l.elevation || 0) < Math.abs(+sorted[ground].elevation || 0)) ground = i;
  });
  return new Map(sorted.map((l, i) => [l.id, i - ground]));
}

export class ProjectBrowser {
  constructor(app, body, search) {
    this.app = app;
    this.body = body;
    this.search = search;
    this.expanded = new Set(load() ?? ['views', 'views/plan', 'views/view3d', 'views/elevation']);
    this.expandedNav = new Set(load('bd.navigatorExpanded') ?? ['pm', 'pm/stories', 'pm/view3d', 'vm', 'vm/plan', 'lb', 'fav', 'fav/saved', 'ps']);
    this.map = NAV_MAPS.some((m) => m.id === load('bd.navigatorMap')) ? load('bd.navigatorMap') : 'project';
    this.tabs = h('div.nav-maps', { role: 'tablist', 'aria-label': 'Navigator maps', hidden: true });
    search.parentNode?.before(this.tabs);
    this.focusKey = null;
    this.query = '';
    search.addEventListener('input', () => {
      this.query = search.value.trim().toLowerCase();
      this.render();
    });
    search.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        this.body.querySelector('.tnode')?.focus();
      }
    });
  }

  get navigator() {
    return !!this.app.workspace?.on;
  }

  get open() {
    return this.navigator ? this.expandedNav : this.expanded;
  }

  setMap(id) {
    this.map = id;
    save(id, 'bd.navigatorMap');
    this.render();
  }

  tree() {
    if (this.navigator) return this.navTree();
    const doc = this.app.doc;
    if (!doc) return [];
    const levelElev = (v) => doc.get(v.levelId)?.elevation ?? 0;
    const viewNode = (v) => ({ key: v.id, label: v.kind === 'sheet' ? `${v.number || ''} - ${v.name}` : v.name, icon: KIND_ICON[v.kind], itemId: v.id, item: v, type: 'view' });
    const sortByName = (a, b) => String(a.name).localeCompare(String(b.name), undefined, { numeric: true });
    const views = [
      { key: 'views/plan', label: 'Floor Plans', children: doc.all('plan').sort((a, b) => levelElev(a) - levelElev(b) || sortByName(a, b)).map(viewNode) },
      { key: 'views/ceilingPlan', label: 'Ceiling Plans', children: doc.all('ceilingPlan').sort((a, b) => levelElev(a) - levelElev(b)).map(viewNode) },
      ...AREA_SCHEMES.map((s) => ({ key: `views/areaPlan/${s.value}`, label: `Area Plans (${s.label})`, children: doc.all('areaPlan').filter((v) => (v.scheme || 'gross') === s.value).sort((a, b) => levelElev(a) - levelElev(b)).map(viewNode) })),
      { key: 'views/view3d', label: '3D Views', children: doc.all('view3d').sort(sortByName).map(viewNode) },
      { key: 'views/elevation', label: 'Elevations', children: doc.all('elevation').map(viewNode) },
      { key: 'views/section', label: 'Sections', children: doc.all('section').sort(sortByName).map(viewNode) },
      { key: 'views/drafting', label: 'Drafting Views', children: doc.all('drafting').sort(sortByName).map(viewNode) },
    ].filter((g) => g.children.length);
    const fam = this.familyNodes('fam');
    return [
      { key: 'views', label: 'Views (all)', icon: 'layers', children: views },
      { key: 'legends', label: 'Legends', icon: 'legend', children: doc.all('legend').sort(sortByName).map(viewNode) },
      { key: 'schedules', label: 'Schedules/Quantities', icon: 'schedule', children: doc.all('schedule').sort(sortByName).map(viewNode) },
      { key: 'sheets', label: 'Sheets (all)', icon: 'sheet', children: doc.all('sheet').sort((a, b) => String(a.number).localeCompare(String(b.number), undefined, { numeric: true })).map(viewNode) },
      { key: 'families', label: 'Families', icon: 'types', children: fam },
    ];
  }

  /** Types by category and family, as tree nodes keyed under prefix. */
  familyNodes(prefix) {
    const doc = this.app.doc;
    const fam = [];
    for (const g of TYPE_GROUPS) {
      const types = doc.all(g.typeKind);
      if (!types.length) continue;
      const typeNode = (t) => ({ key: t.id, label: t.name, icon: KIND_ICON[g.kind], itemId: t.id, item: t, type: 'type', kind: g.kind });
      if (g.byFamily) {
        const byF = new Map();
        for (const t of types) {
          const f = t.familyName || FAMILY_BY_KIND[t.kind];
          if (!byF.has(f)) byF.set(f, []);
          byF.get(f).push(t);
        }
        fam.push({ key: `${prefix}/${g.typeKind}`, label: g.label, children: [...byF].map(([f, list]) => ({ key: `${prefix}/${g.typeKind}/${f}`, label: f, children: list.map(typeNode) })) });
      } else fam.push({ key: `${prefix}/${g.typeKind}`, label: g.label, children: types.map(typeNode) });
    }
    // Components grouped by category, then family.
    const comps = doc.all('componentType');
    for (const cat of CATEGORIES) {
      const list = comps.filter((t) => t.category === cat.id);
      if (!list.length) continue;
      const byF = new Map();
      for (const t of list) {
        if (!byF.has(t.familyName)) byF.set(t.familyName, []);
        byF.get(t.familyName).push(t);
      }
      fam.push({
        key: `${prefix}/cat/${cat.id}`,
        label: cat.label,
        children: [...byF].map(([f, ts]) => ({ key: `${prefix}/cat/${cat.id}/${f}`, label: f, children: ts.map((t) => ({ key: t.id, label: t.name, icon: 'component', itemId: t.id, item: t, type: 'type', kind: 'component' })) })),
      });
    }
    return fam;
  }

  /** The Navigator's tree for the current map. */
  navTree() {
    const doc = this.app.doc;
    if (!doc) return [];
    const sortByName = (a, b) => String(a.name).localeCompare(String(b.name), undefined, { numeric: true });
    const levelElev = (v) => doc.get(v.levelId)?.elevation ?? 0;
    const viewNode = (v, extra = {}) => ({ key: v.id, label: v.kind === 'sheet' ? `${v.number || ''} ${v.name}`.trim() : v.name, icon: KIND_ICON[v.kind], itemId: v.id, item: v, type: 'view', ...extra });
    const tr = (x) => this.app.workspace?.tr?.(x) ?? x;
    const group = (key, label, ic, children, keep = false) => (children.length || keep ? { key, label: tr(label), icon: ic, children } : null);
    const projectName = this.app.file?.name || doc.project?.name || 'Project';
    if (this.map === 'project') {
      const num = storyNumbers(doc.levels());
      // Stories from the top down, as in Archicad.
      const stories = doc.all('plan').sort((a, b) => levelElev(b) - levelElev(a) || sortByName(a, b));
      const named = (v) => viewNode(v, { label: num.has(v.levelId) ? `${num.get(v.levelId)}. ${v.name}` : v.name });
      return [
        {
          key: 'pm',
          label: projectName,
          icon: 'project',
          children: [
            // In Archicad's order, each folder there even when it is empty.
            group('pm/stories', 'Stories', 'level', stories.map(named), true),
            group('pm/section', 'Sections', 'section', doc.all('section').sort(sortByName).map(viewNode), true),
            group('pm/elevation', 'Elevations', 'elevation', doc.all('elevation').filter((v) => !v.interiorOf).map(viewNode), true),
            group('pm/interior', 'Interior Elevations', 'elevation', doc.all('elevation').filter((v) => v.interiorOf).sort(sortByName).map(viewNode), true),
            group('pm/drafting', 'Worksheets', 'draftingView', doc.all('drafting').filter((v) => !v.doc3d && !v.calloutOf).sort(sortByName).map(viewNode), true),
            group('pm/detail', 'Details', 'callout', doc.all('drafting').filter((v) => v.calloutOf).sort(sortByName).map(viewNode), true),
            group('pm/doc3d', '3D Documents', 'view3d', doc.all('drafting').filter((v) => v.doc3d).sort(sortByName).map(viewNode), true),
            group('pm/view3d', '3D', 'view3d', doc.all('view3d').sort(sortByName).map(viewNode).map((n) => ({ ...n, label: tr(n.label) })), true),
            group('pm/schedule', 'Schedules', 'schedule', doc.all('schedule').sort(sortByName).map(viewNode), true),
            group('pm/indexes', 'Project Indexes', 'sheet', [], true),
            group('pm/lists', 'Lists', 'schedule', [], true),
            group('pm/info', 'Information', 'info', [{ key: 'pm/info/notes', label: tr('Project Notes'), icon: 'info', run: 'projectNotes' }], true),
            group('pm/help', 'Help', 'help', [{ key: 'pm/help/guide', label: tr('Guide'), icon: 'help', run: 'help' }], true),
            group('pm/legend', 'Legends', 'legend', doc.all('legend').sort(sortByName).map(viewNode)),
            group('pm/ceilingPlan', 'Reflected Ceiling Plans', 'ceilingPlan', doc.all('ceilingPlan').sort((a, b) => levelElev(b) - levelElev(a)).map(named)),
            group('pm/areaPlan', 'Zone Plans', 'areaPlan', doc.all('areaPlan').sort((a, b) => levelElev(b) - levelElev(a)).map(named)),
          ].filter(Boolean),
        },
      ];
    }
    if (this.map === 'views') {
      // Each view with the settings it is saved with.
      const meta = (v) => {
        const parts = [];
        if (v.scale && v.kind !== 'view3d') parts.push(scaleLabel(v.scale, doc.units));
        if (!['schedule', 'sheet'].includes(v.kind)) parts.push(v.layerComboId ? doc.get(v.layerComboId)?.name ?? 'Custom' : 'Custom');
        return parts.join(' · ');
      };
      const kinds = [
        ['plan', 'Floor Plans', (a, b) => levelElev(b) - levelElev(a) || sortByName(a, b)],
        ['section', 'Sections', sortByName],
        ['elevation', 'Elevations', null],
        ['ceilingPlan', 'Reflected Ceiling Plans', (a, b) => levelElev(b) - levelElev(a)],
        ['areaPlan', 'Zone Plans', (a, b) => levelElev(b) - levelElev(a)],
        ['drafting', 'Worksheets', sortByName],
        ['view3d', '3D', sortByName],
        ['schedule', 'Lists', sortByName],
        ['legend', 'Legends', sortByName],
      ];
      // Clone folders (core/viewclones.js) first, with their plans by story.
      const num = storyNumbers(doc.levels());
      const clones = doc
        .all('viewClone')
        .sort(sortByName)
        .map((c) => ({
          key: c.id,
          label: c.name,
          icon: 'tileViews',
          itemId: c.id,
          item: c,
          type: 'clone',
          children: doc
            .filter((v) => v.cloneId === c.id)
            .sort((a, b) => levelElev(b) - levelElev(a))
            .map((v) => viewNode(v, { label: `${num.get(v.levelId) ?? ''}. ${doc.get(v.levelId)?.name ?? v.name}`, meta: meta(v) })),
        }));
      return [
        {
          key: 'vm',
          label: projectName,
          icon: 'visibility',
          children: [
            ...clones,
            ...kinds
            .map(([k, label, sort]) => {
              const list = doc.all(k).filter((v) => !v.cloneId);
              if (sort) list.sort(sort);
              return group(`vm/${k}`, label, KIND_ICON[k], list.map((v) => viewNode(v, { meta: meta(v) })));
            })
            .filter(Boolean),
          ],
        },
      ];
    }
    if (this.map === 'layouts') {
      const sheets = doc.all('sheet').sort((a, b) => String(a.number).localeCompare(String(b.number), undefined, { numeric: true }));
      // Each layout with the drawings placed on it.
      const drawings = (sh) =>
        doc
          .all('viewport')
          .filter((vp) => vp.viewId === sh.id && doc.get(vp.placedId))
          .map((vp) => {
            const v = doc.get(vp.placedId);
            return { key: vp.id, label: v.name, icon: KIND_ICON[v.kind], itemId: v.id, item: v, type: 'view', meta: v.scale && v.kind !== 'view3d' ? scaleLabel(v.scale, doc.units) : '' };
          });
      return [{ key: 'lb', label: 'Layout Book', icon: 'sheet', children: sheets.map((sh) => { const d = drawings(sh); return viewNode(sh, d.length ? { children: d } : {}); }) }];
    }
    if (this.map === 'publisher') {
      // Each set with its views in publishing order.
      return [
        {
          key: 'ps',
          label: 'Publisher Sets',
          icon: 'printer',
          children: doc
            .all('publisherSet')
            .sort(sortByName)
            .map((set) => ({
              key: set.id,
              label: set.name,
              icon: 'printer',
              itemId: set.id,
              item: set,
              type: 'pubset',
              children: (set.items || []).filter((id) => doc.has(id)).map((id, i) => viewNode(doc.get(id), { key: `${set.id}/${i}`, setId: set.id })),
            })),
        },
      ];
    }
    // Saved favorites by tool (core/favorites.js), then the types ready to place.
    const saved = new Map();
    for (const f of doc.all('favorite')) {
      if (!saved.has(f.elementKind)) saved.set(f.elementKind, []);
      saved.get(f.elementKind).push(f);
    }
    const savedNodes = [...saved]
      .sort((x, y) => x[0].localeCompare(y[0]))
      .map(([k, list]) => ({
        key: `fav/saved/${k}`,
        label: KIND_LABEL[k] || k,
        icon: KIND_ICON[k],
        children: list.sort(sortByName).map((f) => ({ key: f.id, label: f.name, icon: 'selectionLoad', itemId: f.id, item: f, type: 'favorite', kind: k, meta: doc.get(f.typeId)?.name ?? '' })),
      }));
    return [
      ...(savedNodes.length ? [{ key: 'fav/saved', label: 'Saved Favorites', icon: 'selectionLoad', children: savedNodes }] : []),
      { key: 'fav', label: 'Types', icon: 'types', children: this.familyNodes('fav') },
    ];
  }

  /** Visible rows in order: { node, depth, parent }. */
  rows() {
    const out = [];
    const q = this.query;
    const matches = (n) => !q || n.label.toLowerCase().includes(q) || (n.children || []).some(matches);
    const walk = (nodes, depth, parent) => {
      for (const n of nodes) {
        if (!matches(n)) continue;
        out.push({ node: n, depth, parent });
        const open = q ? true : this.open.has(n.key);
        if (n.children && open) walk(n.children, depth + 1, n);
      }
    };
    walk(this.tree(), 0, null);
    return out;
  }

  render() {
    const app = this.app;
    // Keep keyboard focus on the same node when the tree is rebuilt.
    const hadFocus = this.body.contains(document.activeElement);
    if (hadFocus) this.focusKey = document.activeElement.dataset?.key ?? this.focusKey;
    clear(this.body);
    this.renderTabs();
    this.renderFoot();
    // No project (the home screen): no tree to show.
    if (!app.doc) return;
    const rows = this.rows();
    const mapLabel = this.app.workspace?.tr?.(NAV_MAPS.find((m) => m.id === this.map)?.label) ?? NAV_MAPS.find((m) => m.id === this.map)?.label;
    const ul = h('ul.tree', { role: 'tree', 'aria-label': this.navigator ? `Navigator: ${mapLabel}` : 'Project Browser' });
    const activeId = app.activeViewId;
    let focusable = rows.find((r) => r.node.key === this.focusKey) ? this.focusKey : rows[0]?.node.key;
    for (const r of rows) {
      const n = r.node;
      const hasKids = !!n.children;
      const open = this.query ? true : this.open.has(n.key);
      const btn = h(
        `li.tnode${n.itemId === activeId ? '.current' : ''}`,
        {
          role: 'treeitem',
          tabindex: n.key === focusable ? '0' : '-1',
          'aria-level': String(r.depth + 1),
          'aria-expanded': hasKids ? String(open) : null,
          'aria-selected': String(n.itemId != null && n.itemId === activeId),
          'aria-current': n.itemId === activeId ? 'page' : null,
          style: { '--depth': r.depth },
          dataset: { key: n.key },
          onClick: () => {
            this.focusKey = n.key;
            if (hasKids && !n.itemId) this.toggle(n.key);
            else if (n.type === 'view') app.selectViewInBrowser(n.item);
            else if (n.type === 'type') app.showTypeProperties(n.item, n.kind);
          },
          onDblclick: () => this.activate(n),
          onContextmenu: (e) => {
            e.preventDefault();
            this.menu(n, { x: e.clientX, y: e.clientY });
          },
          onKeydown: (e) => this.key(e, r, rows),
        },
        h('span.tnode-twisty' + (hasKids ? '' : '.leaf'), {
          // A node that is also an item (a layout with drawings) opens and closes from its twisty.
          onClick: hasKids && n.itemId ? (e) => {
            e.stopPropagation();
            this.toggle(n.key);
          } : null,
        }, icon('chevron-down', 13)),
        n.icon ? h('span.tnode-ico', icon(n.icon, 15)) : null,
        h('span.tnode-name', n.label),
        n.meta ? h('span.tnode-meta', n.meta) : null,
        hasKids && r.depth === 0 ? h('span.tnode-count', String(countLeaves(n))) : null,
      );
      ul.append(btn);
    }
    if (!rows.length) ul.append(h('li.props-empty', { role: 'none' }, 'Nothing matches the search.'));
    this.body.append(ul);
    if (hadFocus && focusable) this.body.querySelector(`[data-key="${cssEscape(focusable)}"]`)?.focus({ preventScroll: true });
  }

  /** Under the tree in the Archicad workspace: new, settings and delete for the view, then its number and name. */
  renderFoot() {
    const app = this.app;
    const pane = this.body.parentElement;
    if (!pane) return;
    this.foot?.remove();
    if (!this.navigator) return;
    const view = app.activeView;
    if (this.search) this.search.placeholder = app.workspace?.tr?.('Search Project Map') ?? 'Search Project Map';
    const tool = (ic, tip, cmd, args) => h('button.icon-btn.sm', { type: 'button', 'aria-label': tip, 'data-tip': tip, onClick: () => app.run(cmd, args) }, icon(ic, 16));
    const number = view?.levelId ? storyNumbers(app.doc.levels()).get(view.levelId) : null;
    this.foot = h(
      'div',
      h('div.nav-footer', tool('plus', 'Duplicate View', 'duplicateView', { id: view?.id }), tool('tileViews', 'Clone Folder', 'cloneFolder', {}), tool('types', 'View Settings', 'viewTemplates')),
      h(
        'div.nav-props',
        h('div.nav-props-head', app.workspace?.tr?.('Properties') ?? 'Properties'),
        h('div.nav-props-row', h('span', number == null ? '' : `${number}.`), h('span', app.workspace?.tr?.(view?.name) ?? view?.name ?? '')),
        h('button.nav-props-btn', { type: 'button', onClick: () => app.togglePane('props') }, app.workspace?.tr?.('Settings') ?? 'Settings'),
      ),
    );
    pane.append(this.foot);
  }

  renderTabs() {
    clear(this.tabs);
    this.tabs.hidden = !this.navigator;
    if (!this.navigator) return;
    const tabLabel = (x) => this.app.workspace?.tr?.(x) ?? x;
    for (const m of NAV_MAPS) {
      const on = m.id === this.map;
      this.tabs.append(
        h('button.nav-map', { type: 'button', role: 'tab', 'aria-selected': String(on), 'aria-label': tabLabel(m.label), 'data-tip': tabLabel(m.label), tabindex: on ? '0' : '-1', onClick: () => this.setMap(m.id), onKeydown: (e) => {
          const i = NAV_MAPS.indexOf(m);
          const next = e.key === 'ArrowRight' ? NAV_MAPS[(i + 1) % NAV_MAPS.length] : e.key === 'ArrowLeft' ? NAV_MAPS[(i + NAV_MAPS.length - 1) % NAV_MAPS.length] : null;
          if (!next) return;
          e.preventDefault();
          this.setMap(next.id);
          this.tabs.querySelector('[aria-selected="true"]')?.focus();
        } }, icon(m.icon, 16), on ? h('span', tabLabel(m.label)) : null),
      );
    }
  }

  toggle(key) {
    const set = this.open;
    if (set.has(key)) set.delete(key);
    else set.add(key);
    if (this.navigator) save([...set], 'bd.navigatorExpanded');
    else save([...set]);
    this.render();
    this.body.querySelector(`[data-key="${cssEscape(key)}"]`)?.focus();
  }

  activate(n) {
    const app = this.app;
    if (n.run) return app.run(n.run);
    if (n.children && !n.itemId) return this.toggle(n.key);
    if (n.type === 'view') app.openView(n.itemId);
    else if (n.type === 'type') app.placeType(n.item, n.kind);
    else if (n.type === 'favorite') app.applyFavorite(n.item);
    else if (n.type === 'clone') app.run('cloneFolder', { id: n.itemId });
    else if (n.type === 'pubset') app.publishSet(n.itemId);
  }

  key(e, r, rows) {
    const n = r.node;
    const i = rows.indexOf(r);
    const focus = (row) => {
      if (!row) return;
      this.focusKey = row.node.key;
      const el = this.body.querySelector(`[data-key="${cssEscape(row.node.key)}"]`);
      for (const b of this.body.querySelectorAll('.tnode')) b.tabIndex = -1;
      if (el) {
        el.tabIndex = 0;
        el.focus();
      }
    };
    e.stopPropagation();
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        focus(rows[i + 1]);
        break;
      case 'ArrowUp':
        e.preventDefault();
        if (i === 0) this.search.focus();
        else focus(rows[i - 1]);
        break;
      case 'ArrowRight':
        e.preventDefault();
        if (n.children && !this.open.has(n.key)) this.toggle(n.key);
        else if (n.children) focus(rows[i + 1]);
        break;
      case 'ArrowLeft':
        e.preventDefault();
        if (n.children && this.open.has(n.key)) this.toggle(n.key);
        else if (r.parent) focus(rows.find((x) => x.node === r.parent));
        break;
      case 'Home':
        e.preventDefault();
        focus(rows[0]);
        break;
      case 'End':
        e.preventDefault();
        focus(rows.at(-1));
        break;
      case 'Enter':
        e.preventDefault();
        this.activate(n);
        break;
      case 'F2':
        e.preventDefault();
        if (n.itemId) this.app.renameItem(n.itemId);
        break;
      case 'Delete':
        e.preventDefault();
        if (n.itemId) this.app.deleteItem(n.itemId);
        break;
      case 'ContextMenu':
        e.preventDefault();
        this.menu(n, e.currentTarget);
        break;
      default:
        if (e.shiftKey && e.key === 'F10') {
          e.preventDefault();
          this.menu(n, e.currentTarget);
        }
    }
  }

  menu(n, at) {
    const app = this.app;
    if (n.key === 'vm') return showMenu(at, [{ label: 'New Clone Folder of Stories...', icon: 'tileViews', action: () => app.run('cloneFolder') }], { label: 'View Map actions' });
    if (n.key === 'ps') return showMenu(at, [{ label: 'New Publisher Set', icon: 'plus', action: () => app.newPublisherSet() }], { label: 'Publisher actions' });
    if (!n.itemId) return;
    const it = n.item;
    let items;
    if (n.type === 'view') {
      const graphical = !['schedule', 'sheet'].includes(it.kind);
      const set = n.setId ? app.doc.get(n.setId) : null;
      if (set) {
        const list = set.items || [];
        const i = list.indexOf(it.id);
        const move = (d) => () => {
          const a = list.slice();
          [a[i], a[i + d]] = [a[i + d], a[i]];
          app.commit('Publisher set', () => app.doc.update(set.id, { items: a }));
        };
        return showMenu(at, [
          { label: 'Open', icon: 'external', action: () => app.openView(it.id) },
          { label: 'Move Up', icon: 'chevron-up', disabled: i <= 0, action: move(-1) },
          { label: 'Move Down', icon: 'chevron-down', disabled: i < 0 || i >= list.length - 1, action: move(1) },
          { separator: true },
          { label: 'Remove from Set', icon: 'minus', action: () => app.commit('Publisher set', () => app.doc.update(set.id, { items: list.filter((x) => x !== it.id) })) },
        ], { label: `${n.label} actions` });
      }
      items = [
        { label: 'Open', icon: 'external', action: () => app.openView(it.id) },
        graphical && it.kind !== 'elevation' ? { label: 'Duplicate View', icon: 'duplicate', action: () => app.duplicateView(it.id) } : null,
        graphical && app.doc.count('sheet') ? { label: 'Place on Sheet', icon: 'sheet', action: () => app.placeViewDialog(it.id) } : null,
        it.kind === 'schedule' ? { label: 'Export to CSV', icon: 'download', action: () => app.exportSchedule(it.id) } : null,
        it.kind === 'schedule' ? { label: 'Export to Excel', icon: 'download', action: () => app.exportScheduleXLSX(it.id) } : null,
        { separator: true },
        { label: 'Rename', icon: 'pencil', shortcut: 'F2', action: () => app.renameItem(it.id) },
        { label: 'Delete', icon: 'trash', shortcut: 'Delete', action: () => app.deleteItem(it.id) },
      ];
    } else if (n.type === 'pubset') {
      items = [
        { label: 'Publish as PDF', icon: 'printer', action: () => app.publishSet(it.id) },
        { label: 'Add the Open View', icon: 'plus', disabled: !app.activeViewId || (it.items || []).includes(app.activeViewId), action: () => app.commit('Publisher set', () => app.doc.update(it.id, { items: [...(it.items || []), app.activeViewId] })) },
        { separator: true },
        { label: 'Rename', icon: 'pencil', shortcut: 'F2', action: () => app.renameItem(it.id) },
        { label: 'Delete', icon: 'trash', action: () => app.deleteItem(it.id) },
      ];
    } else if (n.type === 'clone') {
      items = [
        { label: 'Folder Settings...', icon: 'pencil', action: () => app.run('cloneFolder', { id: it.id }) },
        { label: 'New Clone Folder of Stories...', icon: 'tileViews', action: () => app.run('cloneFolder') },
        { separator: true },
        { label: 'Delete Folder and Its Views', icon: 'trash', action: () => app.deleteItem(it.id) },
      ];
    } else if (n.type === 'favorite') {
      items = [
        { label: 'Apply', icon: 'selectionLoad', action: () => app.applyFavorite(it) },
        { label: 'Rename', icon: 'pencil', shortcut: 'F2', action: () => app.renameItem(it.id) },
        { separator: true },
        { label: 'Delete', icon: 'trash', action: () => app.deleteItem(it.id) },
      ];
    } else {
      items = [
        { label: 'Place', icon: n.icon || 'component', action: () => app.placeType(it, n.kind) },
        { label: 'Edit Type', icon: 'types', action: () => app.editTypeDialog(it) },
        { label: 'Duplicate', icon: 'duplicate', action: () => app.duplicateType(it) },
        { label: 'Rename', icon: 'pencil', shortcut: 'F2', action: () => app.renameItem(it.id) },
        { label: 'Select All Instances', icon: 'pointer', action: () => app.selectInstancesOfType(it.id) },
        { separator: true },
        { label: 'Delete', icon: 'trash', action: () => app.deleteItem(it.id) },
      ];
    }
    showMenu(at, items.filter(Boolean), { label: `${n.label} actions` });
  }
}

function countLeaves(n) {
  if (!n.children) return 1;
  return n.children.reduce((s, c) => s + countLeaves(c), 0);
}

function cssEscape(s) {
  return typeof CSS !== 'undefined' && CSS.escape ? CSS.escape(s) : String(s).replace(/["\\]/g, '\\$&');
}

function load(key = 'bd.browserExpanded') {
  try {
    return JSON.parse(localStorage.getItem(key) || 'null');
  } catch {
    return null;
  }
}

function save(v, key = 'bd.browserExpanded') {
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch {
    /* ignore */
  }
}

