/**
 * Profiler (Design menu): make a free body (a morph) from a cross-section,
 * extruded between two points, revolved round a vertical axis or swept
 * along the selected lines (core/profiler.js).
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { PickPointsTool } from './drafting.js';
import { formatLength, parseLength } from '../core/units.js';
import { levelElevation } from '../core/model.js';
import { PROFILER_MODES, chainPath, profilerMesh } from '../core/profiler.js';
import { PROFILES as SWEEP_PROFILES } from '../core/sweeps.js';

const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const PATH_KINDS = new Set(['line', 'detailLine', 'modelLine', 'spline', 'polyline', 'wall', 'beam', 'roomSeparator']);

export async function profilerDialog(app) {
  const doc = app.doc;
  const units = doc.units;
  const len = (v, label) => {
    const i = h('input.input', { type: 'text', value: formatLength(v, units), 'aria-label': label, spellcheck: 'false' });
    i.addEventListener('keydown', (e) => e.stopPropagation());
    i.read = () => parseLength(i.value, units);
    return i;
  };
  const num = (v, label) => {
    const i = h('input.input', { type: 'number', value: v, 'aria-label': label });
    i.addEventListener('keydown', (e) => e.stopPropagation());
    return i;
  };
  const picked = [...app.selection].map((id) => doc.get(id)).filter((el) => el && PATH_KINDS.has(el.kind));
  const mode = h('select.input', { 'aria-label': 'Mode' }, PROFILER_MODES.map((m) => h('option', { value: m.value }, m.label)));
  mode.value = picked.length ? 'sweep' : 'extrude';
  const profiles = doc.all('profile');
  const prof = h(
    'select.input',
    { 'aria-label': 'Cross-section' },
    h('optgroup', { label: 'Simple shapes (sized below)' }, Object.entries(SWEEP_PROFILES).map(([k, p]) => h('option', { value: `preset:${k}` }, p.label))),
    profiles.length ? h('optgroup', { label: 'Complex profiles' }, profiles.map((p) => h('option', { value: p.id }, p.name))) : null,
  );
  const width = len(300, 'Section width');
  const height = len(300, 'Section height');
  const base = len(0, 'Base height');
  const rise = len(0, 'Rise along the path');
  const angle = num(360, 'Revolve angle');
  const segments = num(36, 'Segments');
  const mat = h('select.input', { 'aria-label': 'Material' }, doc.all('material').map((m) => h('option', { value: m.id }, m.name)));
  mat.value = doc.has('mat-concrete') ? 'mat-concrete' : doc.all('material')[0]?.id;
  const hint = h('p.field-hint');
  const sync = () => {
    const preset = prof.value.startsWith('preset:');
    width.closest?.('label')?.toggleAttribute('hidden', !preset);
    height.closest?.('label')?.toggleAttribute('hidden', !preset);
    for (const [c, on] of [
      [rise, mode.value === 'sweep'],
      [angle, mode.value === 'revolve'],
      [segments, mode.value === 'revolve'],
    ])
      c.closest?.('label')?.toggleAttribute('hidden', !on);
    hint.textContent = {
      extrude: 'After OK, click the start and the end of the run in plan. The section stands across the run: x to the right of it, y up.',
      revolve: 'After OK, click the axis in plan. The section turns round it: x is the distance from the axis, y the height.',
      sweep: picked.length ? `The section runs along the ${picked.length} selected line${picked.length > 1 ? 's' : ''} (chained end to end), rising by the given amount.` : 'Select the lines, walls or beams to sweep along first.',
    }[mode.value];
  };
  const body = h(
    'div',
    h('div.row2', field('Mode', mode), field('Cross-section', prof)),
    h('div.row2', field('Section width', width), field('Section height', height)),
    h('div.row2', field('Base height above the story', base), field('Rise along the path', rise), field('Revolve angle (degrees)', angle), field('Segments', segments)),
    field('Material', mat),
    hint,
  );
  mode.addEventListener('change', sync);
  prof.addEventListener('change', sync);
  requestAnimationFrame(sync);
  const ok = await openDialog({ title: 'Profiler', body, size: 'md', actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] });
  if (ok !== 'ok') return;
  const levelId = app.activeView?.levelId || doc.levels()[0]?.id;
  const z0 = levelElevation(doc, levelId) + (base.read() || 0);
  const recipe = { mode: mode.value };
  if (prof.value.startsWith('preset:')) Object.assign(recipe, { preset: prof.value.slice(7), scale: [Math.max(1, width.read() || 300), Math.max(1, height.read() || 300)] });
  else recipe.profileId = prof.value;
  const create = (extra) => {
    const r = { ...recipe, ...extra };
    if (!profilerMesh(doc, r)) return app.toast('Nothing to build from that section and path.', { kind: 'error' });
    let id;
    app.commit('Profiler', () => (id = doc.add({ kind: 'morph', levelId, materialId: mat.value, profiler: r }).id));
    app.select([id]);
  };
  if (mode.value === 'sweep') {
    if (!picked.length) return app.toast('Select the lines, walls or beams to sweep along, then run Profiler.', { kind: 'error' });
    const chain = chainPath(picked, z0, rise.read() || 0);
    if (!chain) return app.toast('The selected lines do not join end to end.', { kind: 'error' });
    return create({ path: chain.path, closed: chain.closed });
  }
  if (mode.value === 'revolve') {
    return app.setTool(new PickPointsTool(app, { n: 1, title: 'Profiler', prompts: ['Click the axis of revolution'], done: ([c]) => create({ center: [c[0], c[1], z0], angle: +angle.value || 360, segments: +segments.value || 36 }) }));
  }
  app.setTool(new PickPointsTool(app, { n: 2, title: 'Profiler', prompts: ['Click the start of the run', 'Click the end of the run'], done: ([a, b]) => create({ path: [[a[0], a[1], z0], [b[0], b[1], z0]] }) }));
}
