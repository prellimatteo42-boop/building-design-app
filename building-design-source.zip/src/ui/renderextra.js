/**
 * Rendering helpers, as Archicad's: Align 3D Texture (Set Origin, Set
 * Direction, Reset All), Render Marquee Region (whole frame or cropped),
 * Apply Render Safe Frame and Align View.
 */
import { h } from './dom.js';
import { openDialog } from './dialog.js';
import { Tool } from '../editor/tool.js';
import { renderDialog } from './render.js';
import { lookToSurfaceTool } from './nav3d.js';

class ClickTool extends Tool {
  constructor(app, { title, prompt, done }) {
    super(app);
    this.titleText = title;
    this.promptText = prompt;
    this.done = done;
  }

  get title() {
    return this.titleText;
  }

  get prompt() {
    return this.promptText;
  }

  get viewKinds() {
    return ['view3d'];
  }

  down(ev) {
    const hit = this.app.vc?.raycastTexture?.(ev.x, ev.y);
    if (!hit) return this.app.toast('Click on a surface that shows a texture.', { kind: 'error' });
    this.app.cancelTool();
    this.done(hit);
  }
}

/** The new alignment that puts a drawn texture coordinate at the origin (composed with the element's own). */
export function originAt(align = {}, uvDrawn) {
  const a = +align.angle || 0;
  const c = Math.cos(a);
  const s = Math.sin(a);
  // The drawn uv' = R(-a)(uv - d): the raw uv at the hit is d + R(a) uv'.
  return { du: (align.du || 0) + c * uvDrawn[0] - s * uvDrawn[1], dv: (align.dv || 0) + s * uvDrawn[0] + c * uvDrawn[1], angle: a };
}

/** The new alignment that turns the texture so the drawn coordinate lies along +u from the origin. */
export function directionTo(align = {}, uvDrawn) {
  return { du: align.du || 0, dv: align.dv || 0, angle: (+align.angle || 0) + Math.atan2(uvDrawn[1], uvDrawn[0]) };
}

export const setTextureOriginTool = (app) =>
  new ClickTool(app, {
    title: 'Set Texture Origin',
    prompt: 'Click where the texture should start',
    done: (hit) => {
      const el = app.doc.get(hit.id);
      app.commit('Set texture origin', () => app.doc.update(el.id, { texAlign: originAt(el.texAlign, hit.uv) }));
      app.toast('Texture origin set. Set Direction turns it.');
    },
  });

export const setTextureDirectionTool = (app) =>
  new ClickTool(app, {
    title: 'Set Texture Direction',
    prompt: 'Click a point the texture should run toward from its origin',
    done: (hit) => {
      const el = app.doc.get(hit.id);
      app.commit('Set texture direction', () => app.doc.update(el.id, { texAlign: directionTo(el.texAlign, hit.uv) }));
    },
  });

export function resetTextures(app) {
  const els = app.doc.filter((el) => el.texAlign);
  app.commit('Reset texture alignment', () => els.forEach((el) => app.doc.update(el.id, { texAlign: undefined })));
  app.toast(`Texture alignment reset on ${els.length} element${els.length === 1 ? '' : 's'}.`);
}

/** Render Marquee Region: drag a rectangle in the 3D view, then render it. */
class RegionTool extends Tool {
  constructor(app, crop) {
    super(app);
    this.crop = crop;
  }

  get title() {
    return this.crop ? 'Render Marquee Region and Crop' : 'Render Marquee Region';
  }

  get prompt() {
    return this.start ? 'Release to render the region' : 'Drag a rectangle over the part to render';
  }

  get viewKinds() {
    return ['view3d'];
  }

  down(ev) {
    this.start = { x: ev.x, y: ev.y };
    this.end = { ...this.start };
  }

  move(ev) {
    if (this.start) (this.end = { x: ev.x, y: ev.y }), this.app.requestRender();
  }

  up(ev) {
    if (!this.start) return;
    const vp = this.app.viewport;
    const a = this.start;
    const b = { x: ev.x, y: ev.y };
    this.start = null;
    this.app.cancelTool();
    if (Math.abs(b.x - a.x) < 4 || Math.abs(b.y - a.y) < 4) return;
    const region = { x0: Math.max(0, Math.min(a.x, b.x) / vp.width), y0: Math.max(0, Math.min(a.y, b.y) / vp.height), x1: Math.min(1, Math.max(a.x, b.x) / vp.width), y1: Math.min(1, Math.max(a.y, b.y) / vp.height) };
    renderDialog(this.app, { region, crop: this.crop });
  }

  drawOverlay(ctx) {
    if (!this.start) return;
    ctx.save();
    ctx.strokeStyle = '#1f6fff';
    ctx.setLineDash([5, 4]);
    ctx.strokeRect(Math.min(this.start.x, this.end.x), Math.min(this.start.y, this.end.y), Math.abs(this.end.x - this.start.x), Math.abs(this.end.y - this.start.y));
    ctx.restore();
  }
}

export const regionTool = (app, crop) => new RegionTool(app, crop);

const FRAMES = [
  { value: '', label: 'Off' },
  { value: '1920x1080', label: '16:9 (1920 x 1080)' },
  { value: '1280x720', label: '16:9 (1280 x 720)' },
  { value: '2000x2000', label: 'Square' },
  { value: '2480x3508', label: 'A4 portrait' },
  { value: '3508x2480', label: 'A4 landscape' },
];

export function safeFrameDialog(app) {
  const sel = h('select.input', { 'aria-label': 'Frame' }, ...FRAMES.map((f) => h('option', { value: f.value, selected: f.value === (app.settings.renderSafeFrame || '') }, f.label)));
  return openDialog({ title: 'Apply Render Safe Frame', body: h('label.field', h('span.field-label', 'Show the proportions of'), sel), actions: [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }] }).then((r) => {
    if (r !== 'ok') return;
    app.settingsStore.set('renderSafeFrame', sel.value || null);
    app.requestRender();
  });
}

export const alignViewTool = (app) => lookToSurfaceTool(app);
