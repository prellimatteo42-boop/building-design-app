/**
 * Close Rooms at Doorways: room separators across the doorways round each room of the active level (or each selected
 * room) whose stamp is not in an area closed by walls and separators, the fewest that close it (core/roomclose.js).
 */
import { doorwayCandidates, closingSeparators } from '../core/roomclose.js';
import { typeThickness } from '../core/catalog.js';

export function closeRoomsAtDoorways(app) {
  const doc = app.doc;
  const levelId = app.activeLevelId();
  const sel = [...app.selection].map((id) => doc.get(id)).filter((e) => e?.kind === 'room');
  const rooms = (sel.length ? sel : doc.all('room').filter((r) => r.levelId === levelId)).filter((r) => !r.boundary?.length);
  const open = rooms.filter((r) => !app.scene.rooms.regionAt(r.levelId, r.at));
  if (!open.length) return app.toast(sel.length ? 'The selected rooms are already closed.' : 'Every room on this level is already closed.');
  const walls = doc.all('wall').filter((w) => w.levelId === levelId && !w.arc).map((w) => ({ a: w.a, b: w.b, thickness: typeThickness(doc.get(w.typeId)) || 100 }));
  const solved = app.scene.walls.level(levelId);
  const barriers = [...solved.walls.values()].map((g) => g.poly || [g.R0, g.R1, g.L1, g.L0]).filter((p) => p?.length >= 3);
  const segments = doc.all('roomSeparator').filter((s) => s.levelId === levelId).map((s) => ({ a: s.a, b: s.b }));
  const candidates = doorwayCandidates(walls);
  const stamps = doc.all('room').filter((r) => r.levelId === levelId);
  const added = [];
  let closed = 0;
  for (const r of open) {
    const others = stamps.filter((x) => x !== r).map((x) => x.at);
    const chosen = closingSeparators(r.at, barriers, [...segments, ...added], candidates, { others, want: +r.stampArea || 0 });
    if (!chosen) continue;
    added.push(...chosen);
    closed++;
  }
  if (!added.length) return app.toast(`No doorways close ${open.length === 1 ? 'this room' : 'these rooms'}: draw its outline with the Room tool's polygon method, or room separation lines.`, { kind: 'info' });
  app.commit('Close rooms at doorways', () => {
    for (const s of added) doc.add({ kind: 'roomSeparator', levelId, a: s.a, b: s.b });
  });
  app.toast(`${closed} of ${open.length} open room${open.length === 1 ? '' : 's'} closed with ${added.length} separation line${added.length === 1 ? '' : 's'} across doorways.${closed < open.length ? ' The rest have no doorway to close: draw them with the polygon method.' : ''}`, { kind: closed ? 'success' : 'info' });
}
