/**
 * Project Preferences dialogs (Options > Project Preferences): calculation
 * units and rules, dimensions, zones, structural units and representation, MEP
 * route preferences, the electrical load summary, and the site commands Set
 * Project North, Lock Survey Point and Show Survey Point Coordinates.
 */
import { h } from './dom.js';
import { openDialog, toast } from './dialog.js';
import { PickPointsTool } from './drafting.js';
import { AREA_UNITS, VOLUME_UNITS, DIMENSION_KINDS, formatLength, parseLength } from '../core/units.js';
import { CALC_DEFAULTS, calcRules, FORCE_UNITS, LOAD_LENGTHS, structuralUnits, ANALYTICAL_COLORS, analyticalColors, routePrefs, northFromPoints } from '../core/projectprefs.js';
import { zoneRules } from '../core/zonecalc.js';
import { electricalLoads } from '../core/electrical.js';

const stop = (i) => (i.addEventListener('keydown', (e) => e.stopPropagation()), i);
const field = (label, control, hint) => h('label.field', h('span.field-label', label), control, hint ? h('span.field-hint', hint) : null);
const num = (value, label, attrs = {}) => stop(h('input.input', { type: 'number', step: 'any', min: 0, value, 'aria-label': label, ...attrs }));
const select = (list, cur, label) => {
  const s = h('select.input', { 'aria-label': label }, list.map((x) => h('option', { value: x.value }, x.label)));
  s.value = cur;
  return s;
};
const okCancel = [{ label: 'Cancel', value: null }, { label: 'OK', primary: true, value: 'ok' }];

/** Calculation Units & Rules: units and decimals of areas and volumes, and the opening thresholds. */
export function calculationUnits(app) {
  const doc = app.doc;
  const u = doc.units;
  const auto = { value: '', label: 'Automatic' };
  const area = select([auto, ...AREA_UNITS], u.area || '', 'Area unit');
  const areaDec = num(u.areaDecimals ?? 2, 'Area decimals', { max: 6, step: 1 });
  const volume = select([auto, ...VOLUME_UNITS], u.volume || '', 'Volume unit');
  const volDec = num(u.volumeDecimals ?? 2, 'Volume decimals', { max: 6, step: 1 });
  const r = calcRules(doc.get('project'));
  const fields = Object.keys(CALC_DEFAULTS).map((k) => [k, num(r[k], k)]);
  const by = Object.fromEntries(fields);
  const body = h(
    'div',
    h('h3.dlg-sub', 'Units'),
    h('div.row2', field('Area', area), field('Area decimals', areaDec)),
    h('div.row2', field('Volume', volume), field('Volume decimals', volDec)),
    h('h3.dlg-sub', 'Do not take off'),
    field('Wall openings smaller than (m²)', by.wallOpeningMin, 'Doors, windows and openings under this size stay in the net area and volume of the wall.'),
    h('div.row2', field('Slab holes smaller than (m²)', by.slabHoleMin), field('Roof holes smaller than (m²)', by.roofHoleMin)),
  );
  return openDialog({ title: 'Calculation Units & Rules', size: 'md', body, actions: okCancel }).then((res) => {
    if (res !== 'ok') return;
    app.commit('Calculation units and rules', () => {
      doc.update('project', {
        units: { ...doc.units, area: area.value || undefined, areaDecimals: +areaDec.value, volume: volume.value || undefined, volumeDecimals: +volDec.value },
        calcRules: Object.fromEntries(fields.map(([k, i]) => [k, Math.max(0, +i.value || 0)])),
      });
    });
  });
}

const DIM_UNITS = [
  { value: 'default', label: 'As working units' },
  { value: 'mm', label: 'Millimetres' },
  { value: 'cm', label: 'Centimetres' },
  { value: 'm', label: 'Metres' },
  { value: 'ftin', label: 'Feet & inches' },
  { value: 'ft', label: 'Decimal feet' },
  { value: 'in', label: 'Decimal inches' },
];

/** Dimensions: a unit, decimals and a rounding step for each kind of dimension. */
export function dimensionUnits(app) {
  const doc = app.doc;
  const cur = doc.units.dim || {};
  const rows = DIMENSION_KINDS.map((k) => {
    const c = cur[k.value] || {};
    return { k, unit: select(DIM_UNITS, c.unit || 'default', `${k.label} unit`), decimals: num(c.decimals ?? 0, `${k.label} decimals`, { max: 64, step: 1 }), round: num(c.round ?? 0, `${k.label} rounding`) };
  });
  const body = h(
    'div',
    h('table.layers-table', h('thead', h('tr', h('th', 'Dimension'), h('th', 'Unit'), h('th', 'Decimals'), h('th', 'Round to (mm)'))), h('tbody', rows.map((r) => h('tr', h('td', r.k.label), h('td', r.unit), h('td', r.decimals), h('td', r.round))))),
    h('p.field-hint', 'For feet and inches, Decimals is the fraction of an inch (2 to 64). Round to 0 keeps the exact value. Angular dimensions follow the angle unit in Working Units.'),
  );
  return openDialog({ title: 'Dimensions', size: 'md', body, actions: okCancel }).then((res) => {
    if (res !== 'ok') return;
    app.commit('Dimension units', () => doc.update('project', { units: { ...doc.units, dim: Object.fromEntries(rows.map((r) => [r.k.value, { unit: r.unit.value, decimals: +r.decimals.value || 0, round: +r.round.value || 0 }])) } }));
  });
}

/** The part of the Zones dialog on what is taken off and added. */
export function zoneRulesSection(app) {
  const doc = app.doc;
  const units = doc.units;
  const r = zoneRules(doc.get('project'));
  const set = (patch) => app.commit('Zone rules', () => doc.update('project', { zoneRules: { ...zoneRules(doc.get('project')), ...patch } }));
  const change = (i, fn) => (i.addEventListener('change', fn), i);
  const pct = change(num(r.columnPercent, 'Columns taken off, percent', { max: 100 }), (e) => set({ columnPercent: Math.min(100, +e.target.value || 0) }));
  const minA = change(num(r.columnMinArea, 'Smallest column taken off, m²'), (e) => set({ columnMinArea: +e.target.value || 0 }));
  const fill = change(num(r.fillPercent, 'Fills taken off, percent', { max: 100 }), (e) => set({ fillPercent: Math.min(100, +e.target.value || 0) }));
  const niches = change(h('input', { type: 'checkbox', checked: !!r.addNiches }), (e) => set({ addNiches: e.target.checked }));
  const depth = change(stop(h('input.input', { type: 'text', value: formatLength(r.nicheMinDepth, units), 'aria-label': 'Smallest niche depth' })), (e) => {
    const v = parseLength(e.target.value, units);
    if (v >= 0) set({ nicheMinDepth: v });
  });
  return h(
    'section',
    h('h3.dlg-sub', 'Calculated Area'),
    h('div.row2', field('Columns taken off (%)', pct), field('Only columns from (m²)', minA)),
    field('Fills marked Subtract from Zones, taken off (%)', fill),
    h('label.check', niches, h('span', 'Add door and window niches that reach the floor')),
    field('Smallest niche depth', depth, 'A niche runs from the face of the wall to its centre line.'),
    h('p.field-hint', 'These apply to Calculated Area in Properties and schedules. Net Area stays the plain measured area.'),
  );
}

/** Structural units: what SAF writes, and the units loads are shown and typed in. */
export function structuralUnitsDialog(app) {
  const doc = app.doc;
  const u = structuralUnits(doc.get('project'));
  const sys = select([{ value: 'metric', label: 'Metric (m, mm, kN, MPa)' }, { value: 'imperial', label: 'Imperial (ft, in, kip, ksi)' }], u.system, 'SAF units');
  const force = select(FORCE_UNITS, u.force, 'Force unit');
  const len = select(LOAD_LENGTHS, u.length, 'Length unit of loads');
  const body = h('div', field('Analytical model units (SAF export)', sys, 'The two systems of the SAF units table. The file says which one it uses, and importing reads either.'), h('div.row2', field('Load force', force), field('Load length', len)), h('p.field-hint', 'Loads show and are typed in these units in Properties and on the drawing; the model keeps kN and metres.'));
  return openDialog({ title: 'Structural Analytical Model Units', size: 'sm', body, actions: okCancel }).then((res) => {
    if (res === 'ok') app.commit('Structural units', () => doc.update('project', { structuralUnits: { system: sys.value, force: force.value, length: len.value } }));
  });
}

/** Representation of the analytical model: a colour for each member kind and the line weight. */
export function analyticalRepresentation(app) {
  const doc = app.doc;
  const c = analyticalColors(doc.get('project'));
  const labels = { column: 'Columns', beam: 'Beams and braces', wall: 'Walls', slab: 'Slabs', link: 'Rigid links' };
  const inputs = Object.entries(labels).map(([k, label]) => [k, h('input', { type: 'color', value: c[k], 'aria-label': label }), label]);
  const width = num(c.width, 'Line weight', { max: 8 });
  const body = h('div', inputs.map(([, i, label]) => field(label, i)), field('Member line weight (px)', width));
  return openDialog({ title: 'Structural Analytical Model Representation', size: 'sm', body, actions: [{ label: 'Reset', value: 'reset' }, ...okCancel] }).then((res) => {
    if (!res) return;
    const next = res === 'reset' ? { ...ANALYTICAL_COLORS } : { ...Object.fromEntries(inputs.map(([k, i]) => [k, i.value])), width: +width.value || ANALYTICAL_COLORS.width };
    app.commit('Analytical representation', () => doc.update('project', { analyticalColors: next }));
    app.requestRender();
  });
}

/** Route Preferences: bend ratio and default slope for ducts, pipes and cable carriers. */
export function routePreferences(app) {
  const doc = app.doc;
  const r = routePrefs(doc.get('project'));
  const labels = { duct: 'Ducts', pipe: 'Pipes', cable: 'Cable carriers' };
  const rows = Object.entries(labels).map(([k, label]) => ({ k, label, bend: num(r[k].bend, `${label} bend ratio`, { step: 0.1 }), slope: num(r[k].slope, `${label} slope`, { step: 0.5 }) }));
  const body = h('div', h('table.layers-table', h('thead', h('tr', h('th', 'Route'), h('th', 'Bend ratio (× width)'), h('th', 'Default slope (%)'))), h('tbody', rows.map((x) => h('tr', h('td', x.label), h('td', x.bend), h('td', x.slope))))), h('p.field-hint', 'The bend ratio sets the radius of the elbows made as you route; the slope is what a new route starts with.'));
  return openDialog({ title: 'Route Preferences', size: 'md', body, actions: okCancel }).then((res) => {
    if (res === 'ok') app.commit('Route preferences', () => doc.update('project', { mepRoute: Object.fromEntries(rows.map((x) => [x.k, { bend: +x.bend.value || 1, slope: +x.slope.value || 0 }])) }));
  });
}

/** Electrical Load Summary, from the Electrical Project Settings. */
export function electricalLoadSummary(app) {
  const rows = electricalLoads(app.doc);
  if (!rows.length) return toast('No devices, lighting or electrical equipment are placed yet.', { kind: 'info' });
  const body = h(
    'div',
    h(
      'table.layers-table',
      h('thead', h('tr', h('th', 'Story'), h('th', 'Objects'), h('th', 'Load (W)'), h('th', 'Current (A)'), h('th', 'Longest run (m)'), h('th', 'Cable (mm²)'), h('th', 'Drop (%)'))),
      h('tbody', rows.map((r) => h('tr', h('td', r.level), h('td.num', String(r.count)), h('td.num', Math.round(r.watts).toLocaleString()), h('td.num', r.current.toFixed(1)), h('td.num', r.panel ? r.lengthM.toFixed(1) : 'no panel'), h('td.num', r.cable ? String(r.cable.section) : 'over 95'), h('td.num', r.cable ? r.cable.drop.toFixed(2) : '—')))),
    ),
    h('p.field-hint', 'Copper in conduit, PVC, IEC 60364-5-52 method B1. Objects without an Electrical Load use 15 W for lighting and 200 W for devices. A preliminary check, not a circuit design.'),
  );
  return openDialog({ title: 'Electrical Load Summary', size: 'lg', body, actions: [{ label: 'Close', value: null }] });
}

/** Set Project North: two clicks in a plan, from a point towards north. */
export function setProjectNorth(app) {
  if (!app.vc?.is2D || app.activeView?.kind === 'sheet') return toast('Open a floor plan to set the project north.', { kind: 'error' });
  app.setTool(
    new PickPointsTool(app, {
      n: 2,
      title: 'Project North',
      prompts: ['Click a point on the north line', 'Click towards north'],
      done: ([a, b]) => {
        if (Math.hypot(b[0] - a[0], b[1] - a[1]) < 1) return;
        const deg = northFromPoints(a, b);
        app.commit('Set project north', () => app.doc.update('project', { trueNorth: deg }));
        toast(`Project north is ${deg}° from the model's vertical.`, { kind: 'success' });
      },
    }),
  );
}

export const surveyLocked = (app) => !!app.doc.get('survey-point')?.pinned;

export function lockSurveyPoint(app) {
  const p = app.doc.get('survey-point');
  if (!p) return toast('This project has no survey point.', { kind: 'error' });
  app.commit(p.pinned ? 'Unlock survey point' : 'Lock survey point', () => app.doc.update(p.id, { pinned: !p.pinned }));
}

export function showSurveyCoordinates(app) {
  const v = app.activeView;
  if (!app.vc?.is2D || v?.kind === 'sheet') return toast('Open a plan to show the survey point.', { kind: 'error' });
  app.commit('Survey point coordinates', () => app.doc.update(v.id, { surveyCoords: !v.surveyCoords, ...(!v.surveyCoords ? { showBasePoints: true } : {}) }));
}
