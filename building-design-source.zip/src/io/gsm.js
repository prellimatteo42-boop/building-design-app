/**
 * Reading Archicad libraries, for interoperability with a user's own
 * Archicad installation: library containers (.lcf, and the .libpack
 * packages that hold one) and the library parts in them (.gsm).
 *
 * A container ("GLCF", big-endian) is a tree of entries: MAIN, FLDR
 * (folders) and FILE, each a 20-byte prefix (tag, two words, a count and the
 * entry's size) and a record whose header gives its name block (UTF-16) and,
 * for a file, where its bytes start and how many there are.
 *
 * A library part (little-endian) has a directory of sections (tag, offset,
 * length): the scripts (master 1DSC, 2D 2DSC, 3D 3DSC, parameter VLSC, UI
 * UISC, properties PRSC) as text after a 16-byte header, and the parameters
 * (PARD): a header with their count (at 0x2F) and where their string pool
 * starts (at 0x3D), then 72-byte records (type, flags, value, name) from
 * 0x41; array and dictionary contents follow the records, and the
 * descriptions are the pool's last strings, in the parameters' order.
 */

const td16be = typeof TextDecoder !== 'undefined' ? new TextDecoder('utf-16be') : null;
const td16le = typeof TextDecoder !== 'undefined' ? new TextDecoder('utf-16le') : null;
const tdLatin = typeof TextDecoder !== 'undefined' ? new TextDecoder('windows-1252') : null;
const tdUtf8 = typeof TextDecoder !== 'undefined' ? new TextDecoder('utf-8') : null;

const tag4 = (b, o) => String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]);

/** The files of a library container: [{ path, bytes }] (subarrays, not copies). */
export function readContainer(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (tag4(bytes, 0) !== 'GLCF') throw new Error('This is not an Archicad library container');
  const u32 = (o) => dv.getUint32(o, false);
  const nameAt = (o) => {
    const n = u32(o + 8);
    return td16be.decode(bytes.subarray(o + 12, o + 12 + 2 * n));
  };
  const out = [];
  const walk = (off, end, path, depth) => {
    if (depth > 64) return;
    while (off + 20 <= end) {
      const tag = tag4(bytes, off);
      const size = u32(off + 16);
      if (!(size > 0) || off + size > bytes.length + 1) break;
      const rec = off + 20;
      if (tag === 'FLDR') walk(rec + u32(rec + 24), off + size, [...path, nameAt(rec + u32(rec + 4))], depth + 1);
      else if (tag === 'FILE') {
        const start = rec + u32(off + 72);
        out.push({ path: [...path, nameAt(rec + u32(rec + 4))].join('/'), bytes: bytes.subarray(start, start + u32(off + 64)) });
      } else if (tag === 'MAIN') walk(off + 20, off + size, path, depth + 1);
      off += size;
    }
  };
  walk(u32(16), bytes.length, [], 0);
  return out;
}

/** The library parts of a container, looking into a .libpack's inner container too. */
export function libraryParts(bytes) {
  const files = readContainer(bytes);
  const inner = files.filter((f) => /\.lcf$/i.test(f.path) && tag4(f.bytes, 0) === 'GLCF');
  const all = [...files, ...inner.flatMap((f) => readContainer(f.bytes))];
  return all.filter((f) => /\.gsm$/i.test(f.path));
}

/** Parameter kinds by their type code in a library part. */
const PARAM_KINDS = {
  0: 'integer',
  1: 'length',
  2: 'length',
  3: 'angle',
  4: 'number',
  5: 'lightSwitch',
  6: 'color',
  7: 'intensity',
  8: 'lineType',
  9: 'material',
  10: 'fill',
  11: 'pen',
  12: 'string',
  13: 'boolean',
  14: 'separator',
  15: 'title',
  // An index into the project's building materials, its complex profiles; a dictionary (no value of its own).
  16: 'buildingMaterial',
  17: 'profile',
  18: 'dictionary',
};

/**
 * A library part's scripts and parameters:
 * { scripts: { master, script2d, script3d, paramScript, ui, props }, params: [{ name, kind, code, value, label }], sections,
 * pictures (index -> { mime, bytes }), binaries (index -> 3DBN section bytes), preview ({ mime, bytes } or null) }.
 */
export function readLibraryPart(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes[0] !== 0x57 || bytes[1] !== 0x57) throw new Error('This is not an Archicad library part');
  const n = dv.getUint32(0x24, true);
  const dir = dv.getUint32(0x34, true);
  const sections = {};
  // Embedded pictures (GDLP, and the catalogue preview GIFF as id 0): their index at +12 of the section,
  // a MIME type from +16 ending with a zero byte, then the image.
  const pictures = new Map();
  const binaries = new Map();
  let preview = null;
  for (let i = 0; i < n && dir + 16 * i + 16 <= bytes.length; i++) {
    const e = dir + 16 * i;
    const tag = tag4(bytes, e).split('').reverse().join('');
    const sec = { off: dv.getUint32(e + 4, true), len: dv.getUint32(e + 8, true) };
    if ((tag === 'GDLP' || tag === 'GIFF') && sec.len > 20 && sec.off + sec.len <= bytes.length) {
      const id = dv.getUint32(sec.off + 12, true);
      let z = sec.off + 16;
      while (z < sec.off + Math.min(sec.len, 80) && bytes[z]) z++;
      const pic = { mime: tdLatin.decode(bytes.subarray(sec.off + 16, z)), bytes: bytes.subarray(z + 1, sec.off + sec.len) };
      if (tag === 'GIFF') preview = pic;
      else pictures.set(id, pic);
    }
    // Binary 3D data (3DBN) by its index, the whole section.
    if (tag === '3DBN' && sec.len > 20 && sec.off + sec.len <= bytes.length) binaries.set(dv.getUint32(sec.off + 12, true), bytes.subarray(sec.off, sec.off + sec.len));
    if (!sections[tag]) sections[tag] = sec;
  }
  const text = (tag) => {
    const s = sections[tag];
    if (!s || s.len <= 16) return '';
    const raw = bytes.subarray(s.off + 16, s.off + s.len);
    // Newer parts are UTF-8 (with a BOM), older ones the Windows code page.
    const bom = raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf;
    return (bom ? tdUtf8.decode(raw.subarray(3)) : looksUtf8(raw) ? tdUtf8.decode(raw) : tdLatin.decode(raw)).replace(/\r\n?/g, '\n');
  };
  return {
    sections,
    scripts: { master: text('1DSC'), script2d: text('2DSC'), script3d: text('3DSC'), paramScript: text('VLSC'), ui: text('UISC'), props: text('PRSC') },
    params: readParams(bytes, sections.PARD),
    pictures,
    binaries,
    preview,
  };
}

/** A part's catalogue preview ({ mime, bytes }) from its section directory alone, or null. */
export function partPreview(bytes) {
  if (bytes.length < 0x38 || bytes[0] !== 0x57 || bytes[1] !== 0x57) return null;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const n = dv.getUint32(0x24, true);
  const dir = dv.getUint32(0x34, true);
  for (let i = 0; i < n && dir + 16 * i + 16 <= bytes.length; i++) {
    const e = dir + 16 * i;
    if (tag4(bytes, e).split('').reverse().join('') !== 'GIFF') continue;
    const off = dv.getUint32(e + 4, true);
    const len = dv.getUint32(e + 8, true);
    if (len <= 20 || off + len > bytes.length) return null;
    let z = off + 16;
    while (z < off + Math.min(len, 80) && bytes[z]) z++;
    const mime = tdLatin.decode(bytes.subarray(off + 16, z));
    return /^image\//.test(mime) ? { mime, bytes: bytes.subarray(z + 1, off + len) } : null;
  }
  return null;
}

function looksUtf8(raw) {
  for (let i = 0; i < raw.length; i++) {
    const c = raw[i];
    if (c < 0x80) continue;
    const n = c >= 0xf0 ? 3 : c >= 0xe0 ? 2 : c >= 0xc0 ? 1 : -1;
    if (n < 0) return false;
    for (let k = 1; k <= n; k++) if ((raw[i + k] & 0xc0) !== 0x80) return false;
    i += n;
  }
  return true;
}

// Array values' offsets count from the start of the parameter records.
const ARRAY_BASE = 0x41;

function readParams(bytes, sec) {
  if (!sec) return [];
  const d = bytes.subarray(sec.off, sec.off + sec.len);
  const dv = new DataView(d.buffer, d.byteOffset, d.byteLength);
  // The count of parameters and where the string pool starts; records follow the header.
  const count = dv.getUint16(0x2f, true);
  const pool = dv.getUint32(0x3d, true);
  const first = 0x41;
  const params = [];
  for (let i = 0; i < count; i++) {
    const r = first + 72 * i;
    if (r + 72 > d.length) break;
    const code = dv.getUint16(r + 16, true);
    const name = latin(d.subarray(r + 40, r + 72));
    if (!name) continue;
    const kind = PARAM_KINDS[code] || 'number';
    const real = ['length', 'angle', 'number', 'intensity'].includes(kind);
    // Lengths, angles and numbers are doubles; integers, pens, switches and attribute indices 32-bit integers.
    let value = real ? dv.getFloat64(r + 32, true) : dv.getInt32(r + 32, true);
    if (!Number.isFinite(value)) value = 0;
    // An array: its dimensions in the record, the offset of its values in the 4 bytes after the record;
    // GDL counts from 1.
    if (d[r + 18] === 1 && r + 76 <= d.length) {
      const n1 = dv.getUint32(r + 20, true);
      const n2 = dv.getUint32(r + 24, true);
      const start = ARRAY_BASE + dv.getUint32(r + 72, true);
      const size = real ? 8 : 4;
      const at = (k) => (start + size * k + size <= d.length ? (real ? dv.getFloat64(start + size * k, true) : dv.getInt32(start + size * k, true)) : 0);
      if (n1 > 0 && n1 < 100000 && n2 < 10000 && kind !== 'string') {
        if (!n2) value = [0, ...Array.from({ length: n1 }, (_, k) => at(k))];
        else value = [[], ...Array.from({ length: n1 }, (_, i) => [0, ...Array.from({ length: n2 }, (_, j) => at(i * n2 + j))])];
      }
    }
    // A string: UTF-16 ending with a zero, where an array's values would be (the offset after the record).
    if (kind === 'string' && d[r + 18] !== 1 && r + 76 <= d.length) {
      let at = ARRAY_BASE + dv.getUint32(r + 72, true);
      let str = '';
      for (; at + 1 < d.length && str.length < 4096; at += 2) {
        const c = dv.getUint16(at, true);
        if (!c) break;
        str += String.fromCharCode(c);
      }
      value = str;
    }
    params.push({ name, code, kind, value, flags: d[r + 19] });
  }
  // Descriptions: after the values, 12 bytes (1, 1, 0, their size), then one string per parameter, an empty one included.
  const block = first + pool;
  if (block + 12 < d.length && dv.getUint16(block, true) === 1 && dv.getUint16(block + 2, true) === 1) {
    const size = dv.getUint32(block + 8, true);
    const at = block + 12;
    const list = td16le.decode(d.subarray(at, Math.min(d.length, at + size))).split('\u0000');
    if (list.length >= count && params.length === count) {
      params.forEach((p, i) => (p.label = list[i] || p.label));
      return params;
    }
  }
  const poolStart = pool > first && pool < d.length ? pool : first + 72 * count;
  if (poolStart < d.length) {
    // The section sits at an odd offset as often as not: read the pool both ways and keep the readable one.
    const read = (at) => td16le.decode(d.subarray(at, d.length - ((d.length - at) % 2))).split('\u0000').filter((x) => x.trim());
    const readable = (list) => list.join('').split('').filter((c) => c.charCodeAt(0) < 0x2000).length;
    const a = read(poolStart);
    const b = read(poolStart + 1);
    const strings = readable(b) > readable(a) ? b : a;
    const labels = strings.slice(-params.length);
    if (labels.length === params.length) params.forEach((p, i) => (p.label = labels[i]));
  }
  return params;
}

function latin(sub) {
  let s = '';
  for (const c of sub) {
    if (!c) break;
    s += String.fromCharCode(c);
  }
  return s;
}

// Writing -------------------------------------------------------------------------------------

/** 16 bytes that depend only on the text, so saving a part again keeps its identity. */
function idBytes(text, salt = 0) {
  const out = new Uint8Array(16);
  let h = (2166136261 ^ salt) >>> 0;
  for (let i = 0; i < 16; i++) {
    for (const c of `${text}:${i}`) h = Math.imul(h ^ c.charCodeAt(0), 16777619) >>> 0;
    out[i] = h & 255;
  }
  return out;
}

/** A section: its tag read backwards, 'WW', a version, its whole length, then what it holds. */
function section(tag, version, body) {
  const out = new Uint8Array(16 + body.length);
  const dv = new DataView(out.buffer);
  for (let i = 0; i < 4; i++) out[i] = tag.charCodeAt(3 - i);
  out[4] = 0x57;
  out[5] = 0x57;
  dv.setUint16(6, version, true);
  dv.setUint32(8, out.length, true);
  out.set(body, 16);
  return out;
}

/** The parameter section of a part with no parameters. */
function emptyParams() {
  const b = new Uint8Array(85);
  const dv = new DataView(b.buffer);
  dv.setUint32(0, 0x1b, true);
  b[22] = 0xff;
  b[23] = 0xff;
  dv.setUint16(41, 1, true);
  dv.setUint16(43, 1, true);
  dv.setUint32(45, 0x10, true);
  dv.setUint32(53, 0x1b, true);
  dv.setUint16(65, 1, true);
  dv.setUint16(67, 1, true);
  return b;
}

const utf16 = (text) => {
  const out = new Uint8Array((text.length + 1) * 2);
  new Uint16Array(out.buffer).set([...text].map((c) => c.charCodeAt(0)));
  return out;
};

/** The parameter section's contents for a list of { name, code, value, flags, label }. Values are numbers or, for code 12, text. */
function paramsBody(list) {
  const n = list.length;
  const slots = list.map((p) => (p.code === 12 && p.value ? utf16(String(p.value)) : new Uint8Array(0)));
  const sizes = slots.map((b) => Math.max(8, Math.ceil(b.length / 8) * 8));
  const firstSlot = 72 * n + 16;
  const dataLen = sizes.reduce((a, b) => a + b, 0);
  const labels = list.map((p) => utf16(p.label || p.name));
  const labelLen = labels.reduce((a, b) => a + b.length, 0);
  const total = 0x41 + firstSlot + dataLen + 12 + labelLen + 16;
  const out = new Uint8Array(total);
  const dv = new DataView(out.buffer);
  dv.setUint32(0x10, 0x1b, true);
  out[0x26] = 0xff;
  out[0x27] = 0xff;
  dv.setUint16(0x2f, n, true);
  dv.setUint16(0x39, 1, true);
  dv.setUint16(0x3b, 1, true);
  dv.setUint32(0x3d, firstSlot + dataLen, true);
  let off = firstSlot;
  const write = (at, a, b, c) => {
    dv.setUint32(at, a, true);
    dv.setUint32(at + 4, b, true);
    dv.setUint32(at + 8, c, true);
  };
  write(0x41, n, 0x1b, 0);
  list.forEach((p, i) => {
    const r = 0x41 + 72 * i;
    dv.setUint16(r + 16, p.code, true);
    out[r + 19] = p.flags || 0;
    dv.setUint32(r + 28, p.fixed ? 1 : 0, true);
    if ([1, 2, 3, 4, 7].includes(p.code)) dv.setFloat64(r + 32, +p.value || 0, true);
    else if (p.code !== 12) dv.setInt32(r + 32, +p.value || 0, true);
    for (let k = 0; k < Math.min(31, p.name.length); k++) out[r + 40 + k] = p.name.charCodeAt(k);
    // The next record's start says where this one's extra data is.
    write(r + 72, off, sizes[i], p.code === 12 && !slots[i].length ? 0 : 8);
    out.set(slots[i], 0x41 + off);
    off += sizes[i];
  });
  const block = 0x41 + off;
  dv.setUint16(block, 1, true);
  dv.setUint16(block + 2, 1, true);
  dv.setUint32(block + 8, labelLen, true);
  let at = block + 12;
  for (const b of labels) {
    out.set(b, at);
    at += b.length;
  }
  return out.subarray(16);
}

const CODE_OF = { integer: 0, length: 2, angle: 3, number: 4, boolean: 13, string: 12, title: 15 };

const textSection = (tag, text) => {
  const body = new TextEncoder().encode(`\ufeff${String(text).replace(/\r\n?/g, '\n')}`);
  return section(tag, 0x14, body);
};

function pictureSection(index, url) {
  const m = /^data:([^;,]+);base64,(.*)$/.exec(url) || [];
  if (!m[1]) return null;
  const raw = atob(m[2]);
  const mime = new TextEncoder().encode(`${m[1]}\0`);
  const body = new Uint8Array(mime.length + raw.length);
  body.set(mime);
  for (let i = 0; i < raw.length; i++) body[mime.length + i] = raw.charCodeAt(i);
  const out = section('GDLP', 0x13, body);
  new DataView(out.buffer).setUint32(12, index, true);
  return out;
}

/**
 * A library object file (.gsm): { name, width, depth, height (mm), gdl: { params, script3d, script2d, pictures }, ancestry }.
 * In Archicad its origin is the front left corner, as the scripts draw it.
 */
export function writeObjectPart({ name, width, depth, height, gdl, ancestry = null }) {
  const own = (gdl.params || []).filter((p) => CODE_OF[p.kind] != null).map((p) => ({ name: p.name, code: CODE_OF[p.kind], value: p.kind === 'length' ? (+p.value || 0) / 1000 : p.value, label: p.label || p.name, flags: 1 }));
  const list = [
    { name: 'A', code: 2, value: +width / 1000, label: 'Dimension 1', fixed: true },
    { name: 'B', code: 2, value: +depth / 1000, label: 'Dimension 2', fixed: true },
    { name: 'ZZYZX', code: 2, value: +height / 1000, label: 'Height', fixed: true },
    ...own,
  ];
  const hot = 'HOTSPOT2 0, 0\nHOTSPOT2 A, 0\nHOTSPOT2 A, B\nHOTSPOT2 0, B\n';
  const parts = [
    ['ANCS', ancestry || section('ANCS', 1, new Uint8Array(32))],
    ['MCRS', section('MCRS', 2, new Uint8Array([1, 0, 0, 0, 0, 0]))],
    ['3DSC', textSection('3DSC', gdl.script3d || '')],
    ['2DSC', textSection('2DSC', hot + (gdl.script2d || ''))],
    ['1DSC', textSection('1DSC', '')],
    ['PARD', section('PARD', 0x1b, paramsBody(list))],
  ];
  for (const [index, url] of Object.entries(gdl.pictures || {})) {
    const pic = pictureSection(+index, url);
    if (pic) parts.push(['GDLP', pic]);
  }
  const HEAD_AT = 0x80;
  const dirLen = 16 * parts.length;
  let off = HEAD_AT + dirLen;
  const size = parts.reduce((s, [, b]) => s + b.length, off);
  const out = new Uint8Array(size);
  const dv = new DataView(out.buffer);
  out.set([0x57, 0x57, 0x2e], 0);
  dv.setUint32(0x24, parts.length, true);
  out.set([0x4d, 0x59, 0x53, 0x47, 0x43, 0x41, 0x53, 0x47], 0x28);
  out.set([0x44, 0x41, 0x45, 0x48], 0x30);
  dv.setUint32(0x34, HEAD_AT, true);
  dv.setUint32(0x38, dirLen, true);
  out.set(idBytes(name, 1), 0x48);
  out.set(idBytes(name, 2), 0x58);
  // Placeable and archivable, as an object in a library is.
  out[0x68] = 3;
  parts.forEach(([tag, b], i) => {
    const e = HEAD_AT + 16 * i;
    for (let k = 0; k < 4; k++) out[e + k] = tag.charCodeAt(3 - k);
    dv.setUint32(e + 4, off, true);
    dv.setUint32(e + 8, b.length, true);
    out.set(b, off);
    off += b.length;
  });
  return out;
}

/**
 * A library part file (.gsm) with a master script: { name, master, ancestry }.
 * ancestry: the bytes of an ANCS section (taken from a part of the user's own
 * library, which says what kind of part it is), or null for none.
 */
export function writeLibraryPart({ name, master, ancestry = null }) {
  const text = new TextEncoder().encode(String(master).replace(/\r\n?/g, '\n'));
  const script = new Uint8Array(text.length + 3);
  script.set([0xef, 0xbb, 0xbf]);
  script.set(text, 3);
  const parts = [
    ['ANCS', ancestry || section('ANCS', 1, new Uint8Array(32))],
    ['PARD', section('PARD', 0x1b, emptyParams())],
    ['MCRS', section('MCRS', 2, new Uint8Array([1, 0, 0, 0, 0, 0]))],
    ['1DSC', section('1DSC', 0x14, script)],
  ];
  const HEAD_AT = 0x80;
  const dirLen = 16 * parts.length;
  let off = HEAD_AT + dirLen;
  const size = parts.reduce((s, [, b]) => s + b.length, off);
  const out = new Uint8Array(size);
  const dv = new DataView(out.buffer);
  out.set([0x57, 0x57, 0x2e], 0);
  dv.setUint32(0x24, parts.length, true);
  out.set([0x53, 0x50, 0x47, 0x2e, 0x43, 0x41, 0x53, 0x47], 0x28);
  out.set([0x44, 0x41, 0x45, 0x48], 0x30);
  dv.setUint32(0x34, HEAD_AT, true);
  dv.setUint32(0x38, dirLen, true);
  out.set(idBytes(name, 1), 0x48);
  out.set(idBytes(name, 2), 0x58);
  parts.forEach(([tag, b], i) => {
    const e = HEAD_AT + 16 * i;
    for (let k = 0; k < 4; k++) out[e + k] = tag.charCodeAt(3 - k);
    dv.setUint32(e + 4, off, true);
    dv.setUint32(e + 8, b.length, true);
    out.set(b, off);
    off += b.length;
  });
  return out;
}

/** The ANCS section of a part, whole, or null. */
export function ancestryOf(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const n = dv.getUint32(0x24, true);
  const dir = dv.getUint32(0x34, true);
  for (let i = 0; i < n; i++) {
    const e = dir + 16 * i;
    if (String.fromCharCode(bytes[e + 3], bytes[e + 2], bytes[e + 1], bytes[e]) !== 'ANCS') continue;
    const off = dv.getUint32(e + 4, true);
    return bytes.slice(off, off + dv.getUint32(e + 8, true));
  }
  return null;
}

function nameRecord(name) {
  const n = name.length;
  const out = new Uint8Array(12 + 2 * n);
  const dv = new DataView(out.buffer);
  out[0] = 2;
  out[1] = 1;
  dv.setUint32(2, 6 + 2 * n, false);
  out[6] = 1;
  dv.setUint32(8, n, false);
  for (let i = 0; i < n; i++) dv.setUint16(12 + 2 * i, name.charCodeAt(i), false);
  return out;
}

const tagBytes = (t) => [...t].map((c) => c.charCodeAt(0));

function fileRecord(name, data, date) {
  const nm = nameRecord(name);
  const size = 20 + 0x38 + nm.length + data.length;
  const out = new Uint8Array(size);
  const dv = new DataView(out.buffer);
  out.set(tagBytes('FILE'), 0);
  dv.setUint32(12, 1, false);
  dv.setUint32(16, size, false);
  const rec = 20;
  dv.setUint32(rec, 2, false);
  dv.setUint32(rec + 4, 0x38, false);
  dv.setUint32(rec + 8, nm.length, false);
  for (const at of [rec + 28, rec + 36]) {
    dv.setUint16(at, date.getUTCFullYear(), false);
    out[at + 2] = date.getUTCMonth() + 1;
    out[at + 3] = date.getUTCDate();
    dv.setUint16(at + 4, date.getUTCHours(), false);
    out[at + 6] = date.getUTCMinutes();
    out[at + 7] = date.getUTCSeconds();
  }
  dv.setUint32(rec + 44, data.length, false);
  dv.setUint32(rec + 52, 0x38 + nm.length, false);
  out.set(nm, rec + 0x38);
  out.set(data, rec + 0x38 + nm.length);
  return out;
}

function folderRecord(name, node, date) {
  const nm = nameRecord(name);
  const folders = [...node.folders.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([n, sub]) => folderRecord(n, sub, date));
  const files = node.files.map((f) => fileRecord(f.name, f.data, date));
  const children = [...folders, ...files];
  const size = 20 + 0x1c + nm.length + children.reduce((s, c) => s + c.length, 0);
  const out = new Uint8Array(size);
  const dv = new DataView(out.buffer);
  out.set(tagBytes('FLDR'), 0);
  dv.setUint32(12, children.length, false);
  dv.setUint32(16, size, false);
  const rec = 20;
  dv.setUint32(rec, 2, false);
  dv.setUint32(rec + 4, 0x1c, false);
  dv.setUint32(rec + 8, nm.length, false);
  dv.setUint32(rec + 12, folders.length, false);
  dv.setUint32(rec + 16, files.length, false);
  dv.setUint32(rec + 24, 0x1c + nm.length, false);
  out.set(nm, rec + 0x1c);
  let at = rec + 0x1c + nm.length;
  for (const c of children) {
    out.set(c, at);
    at += c.length;
  }
  return out;
}

/** A library container (.lcf) holding files [{ path: 'a/b.gsm', data }], under one folder called root. */
export function writeContainer(files, root, { date = new Date(), pack = false } = {}) {
  const tree = { folders: new Map(), files: [] };
  for (const f of files) {
    const parts = f.path.split('/').filter(Boolean);
    const name = parts.pop();
    let node = tree;
    for (const p of parts) {
      if (!node.folders.has(p)) node.folders.set(p, { folders: new Map(), files: [] });
      node = node.folders.get(p);
    }
    node.files.push({ name, data: f.data });
  }
  const top = folderRecord(root, tree, date);
  const mainSize = 20 + top.length;
  const out = new Uint8Array(0x18 + mainSize);
  const dv = new DataView(out.buffer);
  out.set(tagBytes('GLCF'), 0);
  dv.setUint32(4, 0x65c07a1e, false);
  dv.setUint32(8, 0x00010000, false);
  dv.setUint32(16, 0x18, false);
  out.set(tagBytes('MAIN'), 0x18);
  dv.setUint32(0x18 + 8, pack ? 0x40 : 0, false);
  dv.setUint32(0x18 + 12, 1, false);
  dv.setUint32(0x18 + 16, mainSize, false);
  out.set(top, 0x18 + 20);
  return out;
}

/** package.info of a library package. */
export function packageInfo({ name, id, version = 1, subversion = 0, requiredAC = 30, lcf }) {
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<Package displayName="${esc(name)}" packageID="${esc(id)}" buildID="1.0" version="${version}" subversion="${subversion}" requiredACVersion="${requiredAC}" requiredACBuildNum="1">\n\t<LCFPath checksum="00000000000000000000000000000000" lcfPath="${esc(lcf)}"/>\n\t<Dependencies>\n\t</Dependencies>\n</Package>\n`;
}

/** A library package (.libpack): the files in an inner container with its package.info. */
export function writeLibraryPackage(files, { name, id, version = 1, subversion = 0, date = new Date() }) {
  const lcf = `${name}.lcf`;
  const inner = writeContainer(files, name, { date });
  const info = new TextEncoder().encode(packageInfo({ name, id, version, subversion, lcf }));
  return writeContainer([{ path: lcf, data: inner }, { path: 'package.info', data: info }], name, { date, pack: true });
}
