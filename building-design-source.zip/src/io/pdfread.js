/**
 * PDF pages as pictures, through Mozilla's PDF.js (pdfjs-dist, audited and
 * pinned): each page drawn into a canvas at a set resolution. Loaded only
 * when a PDF is opened. Its worker and the data it asks for (fonts,
 * character maps, image decoders) come from this app, never from elsewhere,
 * and the scripting sandbox for PDF JavaScript is never loaded.
 */
import * as pdfjs from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;

// The support files, as URLs Vite serves from this app, by file name.
const FILES = {
  // Image decoders and colour management only: not quickjs, the engine for scripts inside PDFs.
  wasmUrl: import.meta.glob('../../node_modules/pdfjs-dist/wasm/{jbig2,openjpeg,qcms_bg}.wasm', { query: '?url', import: 'default' }),
  standardFontDataUrl: import.meta.glob('../../node_modules/pdfjs-dist/standard_fonts/*.{pfb,ttf}', { query: '?url', import: 'default' }),
  cMapUrl: import.meta.glob('../../node_modules/pdfjs-dist/cmaps/*.bcmap', { query: '?url', import: 'default' }),
};

/** Hands PDF.js its support files from the app's own URLs. */
class AppBinaryDataFactory {
  async fetch({ kind, filename }) {
    const files = FILES[kind] || {};
    const key = Object.keys(files).find((k) => k.endsWith(`/${filename}`));
    if (!key) throw new Error(`PDF.js asked for an unknown file: ${filename}`);
    const res = await fetch(await files[key]());
    if (!res.ok) throw new Error(`Could not load ${filename}`);
    return new Uint8Array(await res.arrayBuffer());
  }
}

/** Points to millimetres. */
const PT = 25.4 / 72;

/** Open a PDF from its bytes: { pages: n, page(i) -> { widthMm, heightMm }, render(i, { dpi, maxEdge }) -> canvas, close() }. */
export async function openPDF(bytes) {
  const task = pdfjs.getDocument({
    data: bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes),
    BinaryDataFactory: AppBinaryDataFactory,
    // Placeholders: the factory above resolves the files by name.
    cMapUrl: 'pdfjs/cmaps/',
    standardFontDataUrl: 'pdfjs/standard_fonts/',
    wasmUrl: 'pdfjs/wasm/',
    useWorkerFetch: false,
    isEvalSupported: false,
    enableXfa: false,
  });
  const doc = await task.promise;
  return {
    pages: doc.numPages,
    async size(i) {
      const page = await doc.getPage(i);
      const v = page.getViewport({ scale: 1 });
      return { widthMm: v.width * PT, heightMm: v.height * PT };
    },
    /** Draw page i (from 1) at dpi, the long edge at most maxEdge pixels, on white. */
    async render(i, { dpi = 200, maxEdge = 6000 } = {}) {
      const page = await doc.getPage(i);
      const base = page.getViewport({ scale: 1 });
      const scale = Math.min(dpi / 72, maxEdge / Math.max(base.width, base.height));
      const vp = page.getViewport({ scale });
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.floor(vp.width));
      canvas.height = Math.max(1, Math.floor(vp.height));
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: ctx, canvas, viewport: vp, background: '#ffffff' }).promise;
      page.cleanup();
      return { canvas, widthMm: base.width * PT, heightMm: base.height * PT };
    },
    /**
     * The page's vector drawing: { segments: [[x0, y0, x1, y1]], texts: [{ at, text, size }] }
     * in millimetres on the paper from its bottom left, curves in short pieces.
     */
    async vectors(i) {
      const page = await doc.getPage(i);
      const vp = page.getViewport({ scale: 1 });
      const ops = await page.getOperatorList();
      const out = { segments: [], texts: [], paths: [] };
      // Page space (viewport, points, y down) to paper millimetres, y up.
      const toMm = ([x, y]) => [x * PT, (vp.height - y) * PT];
      collectPaths(
        ops,
        vp.transform,
        (a, b) => {
          const p = toMm(a);
          const q = toMm(b);
          out.segments.push([p[0], p[1], q[0], q[1]]);
        },
        (path) => out.paths.push({ ...path, pts: path.pts.map(toMm), lineWidth: path.lineWidth * PT }),
      );
      const tc = await page.getTextContent();
      for (const it of tc.items) {
        if (!it.str?.trim()) continue;
        const m = pdfjs.Util.transform(vp.transform, it.transform);
        const size = Math.hypot(m[2], m[3]) * PT;
        out.texts.push({ at: toMm([m[4], m[5]]), text: it.str.trim(), size, angle: Math.atan2(-m[1], m[0]) });
      }
      page.cleanup();
      out.segments = dedupe(out.segments);
      return { ...out, widthMm: vp.width * PT, heightMm: vp.height * PT };
    },
    close: () => task.destroy(),
  };
}

const mul = (m, n) => [m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1], m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3], m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]];
const apply = (m, x, y) => [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]];

/**
 * Walk an operator list, emitting each drawn path's straight pieces (curves
 * flattened) in page space, and each sub-path with how it was painted:
 * { pts, closed, fill, stroke, fillColor, strokeColor, lineWidth, dash } (width in page units).
 */
function collectPaths(ops, base, emit, emitPath = null) {
  const { OPS } = pdfjs;
  const D = pdfjs.DrawOPS || { moveTo: 0, lineTo: 1, curveTo: 2, quadraticCurveTo: 3, closePath: 4 };
  let m = base.slice();
  let gs = { fill: '#000000', stroke: '#000000', lw: 1 };
  const stack = [];
  const paint = new Set([OPS.stroke, OPS.closeStroke, OPS.fill, OPS.eoFill, OPS.fillStroke, OPS.eoFillStroke, OPS.closeFillStroke, OPS.closeEOFillStroke]);
  const fills = new Set([OPS.fill, OPS.eoFill, OPS.fillStroke, OPS.eoFillStroke, OPS.closeFillStroke, OPS.closeEOFillStroke]);
  const strokes = new Set([OPS.stroke, OPS.closeStroke, OPS.fillStroke, OPS.eoFillStroke, OPS.closeFillStroke, OPS.closeEOFillStroke]);
  const scaleOf = (mm) => Math.sqrt(Math.abs(mm[0] * mm[3] - mm[1] * mm[2])) || 1;
  for (let k = 0; k < ops.fnArray.length; k++) {
    const fn = ops.fnArray[k];
    const args = ops.argsArray[k];
    if (fn === OPS.save) stack.push([m, gs]);
    else if (fn === OPS.restore) [m, gs] = stack.pop() || [base.slice(), { fill: '#000000', stroke: '#000000', lw: 1 }];
    else if (fn === OPS.transform) m = mul(m, args);
    else if (fn === OPS.setFillRGBColor) gs = { ...gs, fill: typeof args?.[0] === 'string' ? args[0] : gs.fill };
    else if (fn === OPS.setStrokeRGBColor) gs = { ...gs, stroke: typeof args?.[0] === 'string' ? args[0] : gs.stroke };
    else if (fn === OPS.setLineWidth) gs = { ...gs, lw: +args?.[0] || 0 };
    else if (fn === OPS.setDash) gs = { ...gs, dash: Array.isArray(args?.[0]) && args[0].some((x) => x > 0) };
    else if (fn === OPS.setGState && Array.isArray(args?.[0])) {
      for (const [key, value] of args[0]) {
        if (key === 'D' && Array.isArray(value)) gs = { ...gs, dash: Array.isArray(value[0]) && value[0].some((x) => x > 0) };
        else if (key === 'LW') gs = { ...gs, lw: +value || 0 };
      }
    }
    else if (fn === OPS.paintFormXObjectBegin) {
      stack.push([m, gs]);
      if (args?.[0]) m = mul(m, args[0]);
    } else if (fn === OPS.paintFormXObjectEnd) [m, gs] = stack.pop() || [base.slice(), gs];
    else if (fn === OPS.constructPath && paint.has(args?.[0])) {
      const data = args[1]?.[0];
      if (!data) continue;
      const style = { fill: fills.has(args[0]), stroke: strokes.has(args[0]), fillColor: gs.fill, strokeColor: gs.stroke, lineWidth: Math.max(gs.lw, 0.0001) * scaleOf(m), dash: !!gs.dash };
      let start = null;
      let cur = null;
      let sub = null;
      const flush = (closed) => {
        if (emitPath && sub && sub.length >= 2) emitPath({ ...style, pts: sub, closed });
        sub = null;
      };
      for (let i = 0; i < data.length; ) {
        const op = data[i++];
        if (op === D.moveTo) {
          flush(false);
          cur = start = apply(m, data[i++], data[i++]);
          sub = [cur];
        } else if (op === D.lineTo) {
          const p = apply(m, data[i++], data[i++]);
          if (cur) emit(cur, p);
          cur = p;
          sub?.push(p);
        } else if (op === D.curveTo) {
          const c1 = [data[i++], data[i++]];
          const c2 = [data[i++], data[i++]];
          const e = [data[i++], data[i++]];
          if (!cur) {
            cur = apply(m, e[0], e[1]);
            continue;
          }
          // Back to user space for the control points: flatten in page space instead.
          const P0 = cur;
          const P1 = apply(m, ...c1);
          const P2 = apply(m, ...c2);
          const P3 = apply(m, ...e);
          let prev = P0;
          for (let t = 1; t <= 8; t++) {
            const u = t / 8;
            const v = 1 - u;
            const q = [v * v * v * P0[0] + 3 * v * v * u * P1[0] + 3 * v * u * u * P2[0] + u * u * u * P3[0], v * v * v * P0[1] + 3 * v * v * u * P1[1] + 3 * v * u * u * P2[1] + u * u * u * P3[1]];
            emit(prev, q);
            sub?.push(q);
            prev = q;
          }
          cur = P3;
        } else if (op === D.quadraticCurveTo) {
          const c = apply(m, data[i++], data[i++]);
          const e = apply(m, data[i++], data[i++]);
          if (cur) {
            let prev = cur;
            for (let t = 1; t <= 6; t++) {
              const u = t / 6;
              const v = 1 - u;
              const q = [v * v * cur[0] + 2 * v * u * c[0] + u * u * e[0], v * v * cur[1] + 2 * v * u * c[1] + u * u * e[1]];
              emit(prev, q);
              sub?.push(q);
              prev = q;
            }
          }
          cur = e;
        } else if (op === D.closePath) {
          if (cur && start) emit(cur, start);
          cur = start;
          flush(true);
          sub = start ? [start] : null;
        } else break;
      }
      // A filled path is closed whether or not it says so.
      flush(style.fill);
    }
  }
}

/** Segments without zero-length pieces or repeats (either direction). */
function dedupe(segs) {
  const seen = new Set();
  const out = [];
  for (const s of segs) {
    if (Math.hypot(s[2] - s[0], s[3] - s[1]) < 0.05) continue;
    const a = `${Math.round(s[0] * 100)},${Math.round(s[1] * 100)}`;
    const b = `${Math.round(s[2] * 100)},${Math.round(s[3] * 100)}`;
    const key = a < b ? `${a}|${b}` : `${b}|${a}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(s);
  }
  return out;
}
