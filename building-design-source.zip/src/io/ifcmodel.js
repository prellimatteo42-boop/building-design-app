/**
 * Opening an IFC file as a model of this app, as Archicad opens one: its
 * storeys become levels, and walls, curtain walls, slabs, doors, windows,
 * columns, beams and spaces become elements of those kinds, sized from the
 * shapes the file gives them (any representation: extrusions, B-reps,
 * tessellations), with their IFC GlobalId, name and property sets kept.
 * What has no kind here (furniture, stairs, railings, roofs...) comes in as
 * one imported model to show alongside.
 */
import { ifcProducts, SKIP } from './ifcread.js';
import { packParts } from '../core/imported.js';
import { wallTypeMaking } from '../core/floorplan.js';
import { typeThickness } from '../core/catalog.js';
import { minRect, convexHull, signedArea, pointInPolygon, centroid, dist, dot, sub } from '../core/geom.js';
import { unionAll } from '../core/polybool.js';

const WALLS = new Set(['IFCWALL', 'IFCWALLSTANDARDCASE', 'IFCWALLELEMENTEDCASE']);
// Runs of building services: ducts, pipes and cable trays (IFC2x3 has only IfcFlowSegment, told apart by size).
const RUNS = { IFCDUCTSEGMENT: 'duct', IFCPIPESEGMENT: 'pipe', IFCCABLECARRIERSEGMENT: 'cableTray', IFCFLOWSEGMENT: null };
const NATIVE = new Set([...WALLS, 'IFCCURTAINWALL', 'IFCSLAB', 'IFCFOOTING', 'IFCDOOR', 'IFCWINDOW', 'IFCCOLUMN', 'IFCBEAM', 'IFCSPACE', ...Object.keys(RUNS)]);

/** Points, z range and top-face outlines of a triangle list (flat x, y, z). */
function shapeOf(tris) {
  const pts = [];
  let z0 = Infinity;
  let z1 = -Infinity;
  for (let i = 0; i < tris.length; i += 3) {
    pts.push([tris[i], tris[i + 1]]);
    if (tris[i + 2] < z0) z0 = tris[i + 2];
    if (tris[i + 2] > z1) z1 = tris[i + 2];
  }
  return { pts, z0, z1 };
}

/**
 * The outlines of the upward faces at the top of a mesh (a slab's or a
 * space's footprint): the edges of those triangles used once, chained.
 * Returns { outer, holes } or null.
 */
export function topOutline(tris, z1, tol = 5) {
  const key = (x, y) => `${Math.round(x)},${Math.round(y)}`;
  const count = new Map();
  const P = new Map();
  for (let i = 0; i < tris.length; i += 9) {
    const a = [tris[i], tris[i + 1], tris[i + 2]];
    const b = [tris[i + 3], tris[i + 4], tris[i + 5]];
    const c = [tris[i + 6], tris[i + 7], tris[i + 8]];
    if (Math.max(a[2], b[2], c[2]) < z1 - tol || Math.min(a[2], b[2], c[2]) < z1 - tol) continue;
    const nz = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
    if (Math.abs(nz) < 1e-6) continue;
    const vs = nz > 0 ? [a, b, c] : [a, c, b];
    for (let k = 0; k < 3; k++) {
      const p = vs[k];
      const q = vs[(k + 1) % 3];
      const kp = key(p[0], p[1]);
      const kq = key(q[0], q[1]);
      P.set(kp, [p[0], p[1]]);
      P.set(kq, [q[0], q[1]]);
      const back = `${kq}>${kp}`;
      if (count.has(back)) count.delete(back);
      else count.set(`${kp}>${kq}`, [kp, kq]);
    }
  }
  const next = new Map();
  for (const [, [kp, kq]] of count) next.set(kp, kq);
  const used = new Set();
  const loops = [];
  for (const k0 of next.keys()) {
    if (used.has(k0)) continue;
    const loop = [];
    let k = k0;
    while (k && !used.has(k)) {
      used.add(k);
      loop.push(P.get(k));
      k = next.get(k);
    }
    // Drop points on straight runs.
    const clean = loop.filter((p, i) => {
      const a = loop[(i - 1 + loop.length) % loop.length];
      const b = loop[(i + 1) % loop.length];
      return Math.abs((p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0])) > 1e-3 * dist(a, b);
    });
    if (clean.length >= 3 && Math.abs(signedArea(clean)) > 1e4) loops.push(clean);
  }
  if (!loops.length) return null;
  loops.sort((p, q) => Math.abs(signedArea(q)) - Math.abs(signedArea(p)));
  const outer = signedArea(loops[0]) < 0 ? loops[0].slice().reverse() : loops[0];
  const holes = loops.slice(1).filter((l) => pointInPolygon(l[0], outer));
  return { outer, holes };
}

/** A wall's centre line from its footprint: the long sides' middles, averaged between both faces (mitred ends). */
function wallAxis(pts) {
  const r = minRect(pts);
  const n = [-r.u[1], r.u[0]];
  const side = [[Infinity, -Infinity], [Infinity, -Infinity]];
  for (const p of pts) {
    const s = dot(sub(p, r.c), r.u);
    const k = dot(sub(p, r.c), n) > 0 ? 0 : 1;
    side[k][0] = Math.min(side[k][0], s);
    side[k][1] = Math.max(side[k][1], s);
  }
  const ok = (x) => Number.isFinite(x[0]) && Number.isFinite(x[1]);
  const lo = ok(side[0]) && ok(side[1]) ? (side[0][0] + side[1][0]) / 2 : -r.L / 2;
  const hi = ok(side[0]) && ok(side[1]) ? (side[0][1] + side[1][1]) / 2 : r.L / 2;
  return { a: [r.c[0] + r.u[0] * lo, r.c[1] + r.u[1] * lo], b: [r.c[0] + r.u[0] * hi, r.c[1] + r.u[1] * hi], thickness: r.T, rect: r };
}

/** Property sets by entity id: Map id -> { 'Pset.Name': value }. */
export function propertySets(E) {
  const get = (v) => (v && v.ref != null ? E.get(v.ref) : null);
  const out = new Map();
  for (const e of E.values()) {
    if (e.type !== 'IFCRELDEFINESBYPROPERTIES') continue;
    const ps = get(e.args[5]);
    if (!ps || ps.type !== 'IFCPROPERTYSET') continue;
    const set = {};
    for (const r of ps.args[4] || []) {
      const p = get(r);
      if (p?.type === 'IFCPROPERTYSINGLEVALUE' && typeof p.args[0] === 'string') {
        const v = p.args[2];
        set[`${ps.args[2] || 'Pset'}.${p.args[0]}`] = v && typeof v === 'object' && 'enum' in v ? v.enum === 'T' : v;
      }
    }
    for (const o of e.args[4] || []) out.set(o.ref, { ...(out.get(o.ref) || {}), ...set });
  }
  return out;
}

/**
 * Make the model of an IFC file's text in doc (inside a transaction).
 * Returns { levels, walls, curtainWalls, slabs, doors, windows, columns, beams, spaces, other, skipped }.
 */
/** IFC Local Preferences (settings.ifcLocal): what an import keeps and how storeys meet existing levels. */
export const IFC_LOCAL_DEFAULTS = { keepGuids: true, keepNames: true, keepProps: true, matchLevels: true, levelTolerance: 20 };

export function ifcToModel(doc, text, { name = 'IFC model', prefs = null } = {}) {
  const P = { ...IFC_LOCAL_DEFAULTS, ...(prefs || {}) };
  const { E, scale, products } = ifcProducts(text, { skip: new Set([...SKIP].filter((t) => t !== 'IFCSPACE')) });
  const get = (v) => (v && v.ref != null ? E.get(v.ref) : null);
  const psets = propertySets(E);
  const out = { levels: 0, walls: 0, curtainWalls: 0, slabs: 0, doors: 0, windows: 0, columns: 0, beams: 0, spaces: 0, other: 0, skipped: [] };
  // Storeys as levels: an existing level at the same elevation is used.
  const storeyLevel = new Map();
  const storeys = [...E].filter(([, e]) => e.type === 'IFCBUILDINGSTOREY').map(([id, e]) => ({ id, name: typeof e.args[2] === 'string' ? e.args[2] : null, elevation: Math.round((+e.args[9] || 0) * scale) })).sort((a, b) => a.elevation - b.elevation);
  for (const s of storeys) {
    let lv = P.matchLevels ? doc.levels().find((l) => Math.abs(l.elevation - s.elevation) < Math.max(1, +P.levelTolerance || 20)) : null;
    if (!lv) {
      lv = doc.add({ kind: 'level', name: s.name || `Level ${doc.levels().length + 1}`, elevation: s.elevation });
      doc.add({ kind: 'plan', name: lv.name, levelId: lv.id, scale: 100, detail: 'medium' });
      out.levels++;
    }
    storeyLevel.set(s.id, lv);
  }
  const containedIn = new Map();
  for (const e of E.values()) {
    if (e.type === 'IFCRELCONTAINEDINSPATIALSTRUCTURE') for (const o of e.args[4] || []) containedIn.set(o.ref, e.args[5]?.ref);
    if (e.type === 'IFCRELAGGREGATES' && storeyLevel.has(e.args[4]?.ref)) for (const o of e.args[5] || []) containedIn.set(o.ref, e.args[4].ref);
  }
  // The level of a product: its storey, else the highest level at or below its bottom.
  const levelFor = (id, z0) => storeyLevel.get(containedIn.get(id)) || [...doc.levels()].sort((a, b) => b.elevation - a.elevation).find((l) => l.elevation <= z0 + 50) || doc.levels()[0];
  const keep = (id, e) => ({ ifcGuid: P.keepGuids && typeof e.args[0] === 'string' ? e.args[0] : undefined, ifcName: P.keepNames && typeof e.args[2] === 'string' ? e.args[2] : undefined, ...(P.keepProps && psets.get(id) ? { ifcProps: psets.get(id) } : {}) });
  const others = [];
  const walls = [];
  const openings = [];
  // Roofs whose parts are sloping slabs: one native roof each, the parts used up.
  const used = new Set();
  const partsOf = new Map();
  for (const e of E.values()) if (e.type === 'IFCRELAGGREGATES' && get(e.args[4])?.type === 'IFCROOF') partsOf.set(e.args[4].ref, (e.args[5] || []).map((o) => o.ref));
  const byId = new Map(products.map((p) => [p.id, p]));
  for (const [roofId, partIds] of partsOf) {
    const parts = partIds.map((id) => byId.get(id)).filter((p) => p?.tris?.length);
    const r = parts.length ? roofFromSlabs(parts) : null;
    if (!r) continue;
    const lv = levelFor(roofId, r.base);
    let type = doc.all('roofType').find((t) => Math.abs(typeThickness(t) - r.thickness) <= 5);
    if (!type) type = doc.add({ kind: 'roofType', name: `Roof - ${r.thickness} mm`, layers: [{ materialId: 'mat-roofing', thickness: r.thickness, function: 'structure' }] });
    const roof = get({ ref: roofId });
    doc.add({ kind: 'roof', typeId: type.id, levelId: lv.id, boundary: r.boundary, slopes: r.slopes, overhangs: r.overhangs, baseOffset: Math.round(r.base - lv.elevation), ...keep(roofId, roof) });
    for (const p of parts) used.add(p.id);
    out.roofs = (out.roofs || 0) + 1;
  }
  for (const p of products) {
    if (used.has(p.id)) continue;
    const e = E.get(p.id);
    if (!NATIVE.has(p.type)) {
      others.push(p);
      continue;
    }
    const shape = shapeOf(p.tris);
    if (!shape.pts.length) continue;
    const lv = levelFor(p.id, shape.z0);
    const z = (v) => Math.round(v - lv.elevation);
    if (WALLS.has(p.type) || p.type === 'IFCCURTAINWALL') {
      const ax = wallAxis(shape.pts);
      if (ax.thickness < 10 || dist(ax.a, ax.b) < 50) {
        others.push(p);
        continue;
      }
      const curtain = p.type === 'IFCCURTAINWALL';
      const ext = psets.get(p.id)?.['Pset_WallCommon.IsExternal'];
      const type = curtain ? doc.all('wallType').find((t) => t.curtain) : wallTypeMaking(doc, ax.thickness, ext === true ? true : ext === false ? false : undefined, true);
      const el = doc.add({ kind: 'wall', typeId: type?.id, levelId: lv.id, a: ax.a, b: ax.b, baseOffset: z(shape.z0), topLevelId: null, topOffset: 0, height: Math.round(shape.z1 - shape.z0), locationLine: 'center', joinA: true, joinB: true, roomBounding: true, ...keep(p.id, e) });
      walls.push({ el, guid: e.args[0], thickness: ax.thickness, base: shape.z0 });
      out[curtain ? 'curtainWalls' : 'walls']++;
    } else if (p.type === 'IFCSLAB') {
      const top = topOutline(p.tris, shape.z1);
      if (!top) {
        others.push(p);
        continue;
      }
      const th = Math.round(shape.z1 - shape.z0);
      let type = doc.all('floorType').find((t) => Math.abs(typeThickness(t) - th) <= 5);
      if (!type) type = doc.add({ kind: 'floorType', name: `Generic - ${th} mm`, layers: [{ materialId: 'mat-concrete', thickness: th, function: 'structure' }] });
      doc.add({ kind: 'floor', typeId: type.id, levelId: lv.id, boundary: top.outer, holes: top.holes, offset: z(shape.z1), ...keep(p.id, e) });
      out.slabs++;
    } else if (p.type === 'IFCFOOTING') {
      // A footing slab as a foundation slab, of a foundation floor type of its thickness.
      const top = topOutline(p.tris, shape.z1);
      if (!top) {
        others.push(p);
        continue;
      }
      const th = Math.round(shape.z1 - shape.z0);
      let type = doc.all('floorType').find((t) => t.foundation && Math.abs(typeThickness(t) - th) <= 5);
      if (!type) type = doc.add({ kind: 'floorType', name: `Foundation Slab - ${th} mm`, layers: [{ materialId: 'mat-concrete', thickness: th, function: 'structure' }], foundation: true });
      doc.add({ kind: 'floor', typeId: type.id, levelId: lv.id, boundary: top.outer, holes: top.holes, offset: z(shape.z1), ...keep(p.id, e) });
      out.foundations = (out.foundations || 0) + 1;
    } else if (p.type in RUNS) {
      // A level run: long in plan, its section about as tall as it is wide. Sloping or rising ones stay as shapes.
      const r = minRect(shape.pts);
      const h = shape.z1 - shape.z0;
      if (!(r.L > 2 * Math.max(r.T, h) && h <= 1.6 * r.T + 20)) {
        others.push(p);
        continue;
      }
      const kind = RUNS[p.type] || (r.T >= 100 ? 'duct' : 'pipe');
      const round = Math.abs(h - r.T) <= 0.06 * r.T;
      const size = kind === 'pipe' || (kind === 'duct' && round) ? { diameter: Math.round(r.T), ...(kind === 'duct' ? { shape: 'round' } : {}) } : { width: Math.round(r.T), height: Math.round(h) };
      doc.add({ kind, levelId: lv.id, a: [r.c[0] - (r.u[0] * r.L) / 2, r.c[1] - (r.u[1] * r.L) / 2], b: [r.c[0] + (r.u[0] * r.L) / 2, r.c[1] + (r.u[1] * r.L) / 2], offset: z((shape.z0 + shape.z1) / 2), ...size, ...keep(p.id, e) });
      out.runs = (out.runs || 0) + 1;
    } else if (p.type === 'IFCSPACE') {
      const top = topOutline(p.tris, shape.z1);
      if (!top) continue;
      const long = typeof e.args[7] === 'string' && e.args[7] ? e.args[7] : null;
      const short = typeof e.args[2] === 'string' ? e.args[2] : null;
      let at = centroid(top.outer);
      if (!pointInPolygon(at, top.outer)) at = top.outer[0].map((v, i) => (v + top.outer[2][i]) / 2);
      doc.add({ kind: 'room', levelId: lv.id, at, boundary: top.outer, name: long || short || 'Room', number: long ? short || '' : '', upperOffset: Math.round(shape.z1 - shape.z0), ...keep(p.id, e) });
      out.spaces++;
    } else if (p.type === 'IFCDOOR' || p.type === 'IFCWINDOW') openings.push({ p, e, shape, lv });
    else if (p.type === 'IFCCOLUMN') {
      const r = minRect(shape.pts);
      const hull = shape.pts;
      const area = Math.abs(signedArea(convexHull(hull)));
      const round = hull.length > 24 && Math.abs(area - (Math.PI * r.L * r.L) / 4) < 0.08 * area;
      const w = Math.round(r.L);
      const d = Math.round(r.T);
      const tname = round ? `Round ${w} mm` : `${w} x ${d} mm`;
      let type = doc.all('columnType').find((t) => t.name === tname);
      if (!type) {
        const base = doc.all('columnType')[0];
        const { id: _id, ...rest } = base || {};
        type = doc.add({ ...rest, kind: 'columnType', name: tname, width: w, depth: d, shape: round ? 'round' : 'rect' });
      }
      doc.add({ kind: 'column', typeId: type.id, levelId: lv.id, at: r.c, rotation: Math.round((Math.atan2(r.u[1], r.u[0]) * 180) / Math.PI * 100) / 100, baseOffset: z(shape.z0), topLevelId: null, height: Math.round(shape.z1 - shape.z0), ...keep(p.id, e) });
      out.columns++;
    } else if (p.type === 'IFCBEAM') {
      const r = minRect(shape.pts);
      const w = Math.round(r.T);
      const dd = Math.round(shape.z1 - shape.z0);
      let type = doc.all('beamType').find((t) => Math.abs(+t.width - w) <= 5 && Math.abs(+t.depth - dd) <= 5);
      if (!type) type = doc.add({ kind: 'beamType', name: `${w} x ${dd} mm`, width: w, depth: dd, materialId: 'mat-concrete' });
      doc.add({ kind: 'beam', typeId: type.id, levelId: lv.id, a: [r.c[0] - (r.u[0] * r.L) / 2, r.c[1] - (r.u[1] * r.L) / 2], b: [r.c[0] + (r.u[0] * r.L) / 2, r.c[1] + (r.u[1] * r.L) / 2], offset: z(shape.z1), ...keep(p.id, e) });
      out.beams++;
    }
  }
  // Doors and windows in the walls they fill (by the file's relations, else the nearest wall around them).
  const voids = new Map();
  for (const e of E.values()) if (e.type === 'IFCRELVOIDSELEMENT') voids.set(e.args[5]?.ref, e.args[4]?.ref);
  const fills = new Map();
  for (const e of E.values()) if (e.type === 'IFCRELFILLSELEMENT') fills.set(e.args[5]?.ref, voids.get(e.args[4]?.ref));
  const byGuid = new Map(walls.map((w) => [w.guid, w]));
  for (const { p, e, shape, lv } of openings) {
    const kind = p.type === 'IFCDOOR' ? 'door' : 'window';
    const r = minRect(shape.pts);
    const hostEnt = get({ ref: fills.get(p.id) });
    let host = hostEnt ? byGuid.get(hostEnt.args[0]) : null;
    if (!host)
      host = walls
        .filter((w) => w.el.levelId === lv.id || Math.abs(w.base - shape.z0) < 3000)
        .map((w) => ({ w, d: distToAxis(r.c, w.el) }))
        .filter((x) => x.d <= x.w.thickness / 2 + 150)
        .sort((x, y) => x.d - y.d)[0]?.w;
    if (!host) {
      others.push(p);
      out.skipped.push(`${kind} ${e.args[2] || p.id}: no wall around it`);
      continue;
    }
    const w = host.el;
    const L = dist(w.a, w.b);
    const u = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
    // Width along the wall; the file's overall sizes when it gives them.
    let width = 0;
    for (const q of shape.pts) width = Math.max(width, Math.abs(dot(sub(q, r.c), u)) * 2);
    width = Math.round((+e.args[9] || 0) * scale) || Math.round(width);
    const height = Math.round((+e.args[8] || 0) * scale) || Math.round(shape.z1 - shape.z0);
    const t = Math.min(L - width / 2, Math.max(width / 2, dot(sub(r.c, w.a), u)));
    const types = doc.all(kind === 'door' ? 'doorType' : 'windowType');
    const type = types.reduce((best, x) => (!best || Math.abs(+x.width - width) + Math.abs(+x.height - height) < Math.abs(+best.width - width) + Math.abs(+best.height - height) ? x : best), null);
    const el = { kind, typeId: type?.id, hostId: w.id, t: Math.round(t), ...keep(p.id, e) };
    if (Math.abs(+type?.width - width) > 10) el.width = width;
    if (Math.abs(+type?.height - height) > 10) el.height = height;
    if (kind === 'window') el.sill = Math.round(shape.z0 - host.base);
    else Object.assign(el, { flipFacing: false, flipHand: false });
    doc.add(el);
    out[kind === 'door' ? 'doors' : 'windows']++;
  }
  if (others.length) {
    doc.add({ kind: 'importedModel', name: `${name} - other elements`, source: name, at: [0, 0], rotation: 0, z: 0, ...packParts({ parts: others }) });
    out.other = others.length;
  }
  return out;
}

/**
 * A roof from its sloping slabs: { boundary (the pivot lines), slopes and
 * overhangs per edge, base (the lowest eave of the underside), thickness }
 * as a native roof takes them, or null when the parts are not planar
 * sloping slabs making one outline. Each slab's underside is a plane rising
 * from its eave; an eave higher than the lowest moves its pivot line out by
 * the rise over the slope, its overhang taking the outline back.
 */
export function roofFromSlabs(parts) {
  const planes = [];
  for (const p of parts) {
    const t = p.tris;
    // The sloping faces, their normals turned up (faces of a faceted body may come wound either way), each
    // with its plane's offset along the normal: the underside is the lower of the two parallel planes.
    const faces = [];
    for (let i = 0; i + 8 < t.length; i += 9) {
      const a = [t[i], t[i + 1], t[i + 2]];
      const b = [t[i + 3], t[i + 4], t[i + 5]];
      const c = [t[i + 6], t[i + 7], t[i + 8]];
      const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
      const v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
      let n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
      const l = Math.hypot(...n);
      if (l < 1e-6 || Math.abs(n[2] / l) < 0.2) continue;
      n = n.map((x) => (x / l) * Math.sign(n[2]));
      faces.push({ n, d: n[0] * a[0] + n[1] * a[1] + n[2] * a[2], corners: [a, b, c] });
    }
    if (faces.length < 2) return null;
    const dLow = Math.min(...faces.map((f) => f.d));
    const dHigh = Math.max(...faces.map((f) => f.d));
    if (dHigh - dLow < 10) return null;
    const lower = faces.filter((f) => f.d - dLow < (dHigh - dLow) / 2);
    const under = lower.flatMap((f) => f.corners);
    const over = faces.filter((f) => !lower.includes(f)).flatMap((f) => f.corners);
    const sum = lower.reduce((acc, f) => acc.map((x, k) => x + f.n[k]), [0, 0, 0]);
    const ln = Math.hypot(...sum);
    const n = sum.map((x) => x / ln);
    const slope = (Math.acos(Math.min(1, n[2])) * 180) / Math.PI;
    if (slope < 2 || slope > 80) return null;
    // Uphill in plan, and the plane through the underside: z = z0 + k * (m . p).
    const m = [-n[0] / Math.hypot(n[0], n[1]), -n[1] / Math.hypot(n[0], n[1])];
    const k = Math.tan((slope * Math.PI) / 180);
    const c = under.reduce((acc, q) => acc + q[2] - k * (m[0] * q[0] + m[1] * q[1]), 0) / under.length;
    // Planar: every underside corner on that plane.
    if (under.some((q) => Math.abs(q[2] - (c + k * (m[0] * q[0] + m[1] * q[1]))) > 15)) return null;
    const topC = over.reduce((acc, q) => acc + q[2] - k * (m[0] * q[0] + m[1] * q[1]), 0) / over.length;
    const hull = planOutline(under) || convexHull(under.map((q) => [q[0], q[1]]));
    planes.push({ m, k, slope, c, hull, thick: Math.max(1, (topC - c) * Math.cos((slope * Math.PI) / 180)) });
  }
  const outline = unionAll(planes.map((pl) => ({ boundary: signedArea(pl.hull) < 0 ? pl.hull.slice().reverse() : pl.hull })));
  if (outline.length !== 1) return null;
  let poly = outline[0].boundary.filter((q, i, arr) => dist(q, arr[(i + 1) % arr.length]) > 1);
  if (signedArea(poly) < 0) poly = poly.slice().reverse();
  const zAt = (pl, q) => pl.c + pl.k * (pl.m[0] * q[0] + pl.m[1] * q[1]);
  // Each edge: an eave when a plane's low edge lies along it (level, square to its uphill direction).
  const n = poly.length;
  const eaves = poly.map((a, i) => {
    const b = poly[(i + 1) % n];
    const d = [(b[0] - a[0]) / dist(a, b), (b[1] - a[1]) / dist(a, b)];
    const mid = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    return planes.find((pl) => Math.abs(d[0] * pl.m[0] + d[1] * pl.m[1]) < 0.02 && Math.abs(zAt(pl, a) - zAt(pl, b)) < 15 && pl.hull.some((q, j) => segDist(mid, q, pl.hull[(j + 1) % pl.hull.length]) < 20) && centroid(pl.hull).every((v, j) => true) && dot(sub(centroid(pl.hull), mid), pl.m) > 0) || null;
  });
  if (!eaves.some(Boolean)) return null;
  const base = Math.min(...eaves.map((pl, i) => (pl ? zAt(pl, poly[i]) : Infinity)));
  // Pivot lines: an eave above the base moves out by its rise over the slope; its overhang brings the outline back.
  const out = poly.map((a, i) => {
    const pl = eaves[i];
    return pl ? (zAt(pl, a) - base) / pl.k : 0;
  });
  const line = (i) => {
    const a = poly[i];
    const b = poly[(i + 1) % n];
    const L = dist(a, b);
    const o = [(b[1] - a[1]) / L, -(a[0] - b[0]) / L];
    // Outward normal of a counterclockwise polygon: the edge direction turned clockwise.
    const nrm = [(b[1] - a[1]) / L, (a[0] - b[0]) / L];
    void o;
    return { p: [a[0] + nrm[0] * out[i], a[1] + nrm[1] * out[i]], d: [b[0] - a[0], b[1] - a[1]] };
  };
  const meet = (l1, l2) => {
    const den = l1.d[0] * l2.d[1] - l1.d[1] * l2.d[0];
    if (Math.abs(den) < 1e-9) return l2.p;
    const t = ((l2.p[0] - l1.p[0]) * l2.d[1] - (l2.p[1] - l1.p[1]) * l2.d[0]) / den;
    return [l1.p[0] + l1.d[0] * t, l1.p[1] + l1.d[1] * t];
  };
  const pivot = poly.map((_, i) => meet(line((i - 1 + n) % n), line(i)).map((v) => Math.round(v)));
  // An edge whose pivot shrank to nothing (a notch between eaves now on one line) keeps 1 mm, along its
  // own direction: its line still meets its neighbours where the outline steps.
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    if (dist(pivot[i], pivot[j]) >= 1) continue;
    const a = poly[i];
    const b = poly[j];
    const L = dist(a, b) || 1;
    pivot[j] = [pivot[i][0] + (b[0] - a[0]) / L, pivot[i][1] + (b[1] - a[1]) / L];
  }
  const thickness = Math.round(planes.reduce((s, pl) => s + pl.thick, 0) / planes.length);
  return { boundary: pivot, slopes: eaves.map((pl) => (pl ? Math.round(pl.slope * 100) / 100 : 0)), overhangs: out.map((v) => (v ? -Math.round(v) : 0)), base: Math.round(base), thickness };
}

/**
 * The outer outline in plan of a face given as triangles (corners in threes):
 * its edges used by one triangle only, chained; the loop of largest area.
 */
function planOutline(corners) {
  const key = (q) => `${Math.round(q[0])},${Math.round(q[1])}`;
  const count = new Map();
  const dir = [];
  for (let i = 0; i + 2 < corners.length; i += 3)
    for (let e = 0; e < 3; e++) {
      const a = corners[i + e];
      const b = corners[i + ((e + 1) % 3)];
      const ka = key(a);
      const kb = key(b);
      if (ka === kb) continue;
      const k = ka < kb ? `${ka}|${kb}` : `${kb}|${ka}`;
      count.set(k, (count.get(k) || 0) + 1);
      dir.push([k, ka, kb, a, b]);
    }
  const next = new Map();
  const at = new Map();
  for (const [k, ka, kb, a, b] of dir) {
    if (count.get(k) !== 1) continue;
    next.set(ka, kb);
    at.set(ka, [a[0], a[1]]);
    at.set(kb, [b[0], b[1]]);
  }
  let best = null;
  const seen = new Set();
  for (const start of next.keys()) {
    if (seen.has(start)) continue;
    const loop = [];
    let k = start;
    while (k !== undefined && !seen.has(k)) {
      seen.add(k);
      loop.push(at.get(k));
      k = next.get(k);
    }
    if (loop.length >= 3 && (!best || Math.abs(signedArea(loop)) > Math.abs(signedArea(best)))) best = loop;
  }
  if (!best) return null;
  // Points along straight runs go.
  const clean = best.filter((q, i) => {
    const a = best[(i - 1 + best.length) % best.length];
    const b = best[(i + 1) % best.length];
    return Math.abs((q[0] - a[0]) * (b[1] - a[1]) - (q[1] - a[1]) * (b[0] - a[0])) > 1e-3 * dist(a, b) * dist(a, b) + 1;
  });
  return clean.length >= 3 ? clean : best;
}

function segDist(p, a, b) {
  const d = [b[0] - a[0], b[1] - a[1]];
  const L = d[0] * d[0] + d[1] * d[1] || 1;
  const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * d[0] + (p[1] - a[1]) * d[1]) / L));
  return Math.hypot(p[0] - a[0] - d[0] * t, p[1] - a[1] - d[1] * t);
}

function distToAxis(p, w) {
  const L = dist(w.a, w.b) || 1;
  const u = [(w.b[0] - w.a[0]) / L, (w.b[1] - w.a[1]) / L];
  const t = dot(sub(p, w.a), u);
  if (t < -50 || t > L + 50) return Infinity;
  return Math.abs(dot(sub(p, w.a), [-u[1], u[0]]));
}

