/** Read a DWG (or DXF) in a worker with LibreDWG; resolves to { units, entities, blocks, layers }. */
export function readCAD(bytes, { dxf = false, timeout = 120000 } = {}) {
  return new Promise((resolve, reject) => {
    const w = new Worker(new URL('./dwg.worker.js', import.meta.url), { type: 'module' });
    const timer = setTimeout(() => {
      w.terminate();
      reject(new Error('Reading the drawing took too long'));
    }, timeout);
    w.onmessage = (ev) => {
      clearTimeout(timer);
      w.terminate();
      if (ev.data?.ok) resolve(ev.data);
      else reject(new Error(ev.data?.error || 'The drawing could not be read'));
    };
    w.onerror = (ev) => {
      clearTimeout(timer);
      w.terminate();
      reject(new Error(ev.message || 'The drawing could not be read'));
    };
    const buf = bytes instanceof ArrayBuffer ? bytes : bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
    w.postMessage({ bytes: buf, dxf }, [buf]);
  });
}
