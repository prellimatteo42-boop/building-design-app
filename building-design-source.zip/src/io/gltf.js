/**
 * glTF 2.0 binary (GLB) in and out, for Blender and other modelling and rendering programs.
 *
 * Out: one node per element under a node per level, the element's id, kind, name and IDs in the node's extras (Blender
 * keeps them as custom properties), and one primitive per surface: triangles of the same colour and shine share a
 * material named after the project's material of that colour, with its roughness, metalness and, for see-through
 * surfaces, transmission (glass in Cycles and EEVEE).
 *
 * In: the triangles of every mesh in the default scene, placed by their nodes' transforms, with each primitive's
 * material (name, colour, opacity, roughness). glTF is in metres with Y up; the project is in millimetres with Z up.
 */

const srgbToLinear = (c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
const linearToSrgb = (c) => (c <= 0.0031308 ? c * 12.92 : 1.055 * c ** (1 / 2.4) - 0.055);
const hex2 = (v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');

/**
 * A GLB file from element meshes: items [{ el, m: { pos (mm, Z up), nrm (int8 ×127), col (RGBA bytes) }, level }],
 * `materials` the project's materials (to name surfaces by colour). Returns the file's bytes.
 */
export function writeGLB(items, { materials = [], name = 'Building Design' } = {}) {
  const byColour = new Map();
  for (const m of materials) if (m?.color && !byColour.has(m.color.toLowerCase())) byColour.set(m.color.toLowerCase(), m);
  const bufs = [];
  let byteLength = 0;
  const bufferViews = [];
  const accessors = [];
  const meshes = [];
  const nodes = [];
  const gMaterials = [];
  const materialIndex = new Map();
  const pushView = (arr, target) => {
    const bytes = new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
    const pad = (4 - (byteLength % 4)) % 4;
    if (pad) {
      bufs.push(new Uint8Array(pad));
      byteLength += pad;
    }
    bufferViews.push({ buffer: 0, byteOffset: byteLength, byteLength: bytes.length, target });
    bufs.push(bytes);
    byteLength += bytes.length;
    return bufferViews.length - 1;
  };
  // A surface's material: its colour, its shine from the last steps of an opaque alpha (254 satin, 253 glossy), glass
  // when it lets light through.
  const materialOf = (r, g, b, a) => {
    const key = `${r},${g},${b},${a}`;
    if (materialIndex.has(key)) return materialIndex.get(key);
    const hex = `#${hex2(r)}${hex2(g)}${hex2(b)}`;
    const own = byColour.get(hex);
    const clear = a < 250;
    const gloss = clear ? 2 : Math.max(0, 255 - a);
    const metal = !clear && gloss === 2 && /steel|alumin|metal|chrome|brass|copper|mirror|acciaio|metallo/i.test(`${own?.id || ''} ${own?.name || ''}`);
    const mat = {
      name: own?.name || `Colour ${hex}`,
      pbrMetallicRoughness: { baseColorFactor: [r, g, b].map((v) => +srgbToLinear(v / 255).toFixed(5)).concat(clear ? +(a / 255).toFixed(3) : 1), metallicFactor: metal ? 1 : 0, roughnessFactor: clear ? 0.05 : [0.8, 0.4, 0.15][gloss] },
      doubleSided: true,
    };
    if (clear) {
      mat.alphaMode = 'BLEND';
      mat.extensions = { KHR_materials_transmission: { transmissionFactor: +(1 - a / 255).toFixed(3) } };
    }
    if (own?.id) mat.extras = { bdMaterialId: own.id };
    gMaterials.push(mat);
    materialIndex.set(key, gMaterials.length - 1);
    return gMaterials.length - 1;
  };
  const levelNodes = new Map();
  const roots = [];
  for (const { el, m, level } of items) {
    const n = m.pos.length / 3;
    // Triangles by surface.
    const groups = new Map();
    for (let t = 0; t + 2 < n; t += 3) {
      const c = t * 4;
      const key = `${m.col[c]},${m.col[c + 1]},${m.col[c + 2]},${m.col[c + 3]}`;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(t);
    }
    const primitives = [];
    for (const [key, tris] of groups) {
      const k = tris.length * 3;
      const pos = new Float32Array(k * 3);
      const nrm = new Float32Array(k * 3);
      const min = [Infinity, Infinity, Infinity];
      const max = [-Infinity, -Infinity, -Infinity];
      let o = 0;
      for (const t of tris)
        for (let v = t; v < t + 3; v++, o++) {
          const p = [m.pos[v * 3] / 1000, m.pos[v * 3 + 2] / 1000, -m.pos[v * 3 + 1] / 1000];
          pos.set(p, o * 3);
          for (let i = 0; i < 3; i++) {
            min[i] = Math.min(min[i], p[i]);
            max[i] = Math.max(max[i], p[i]);
          }
          const q = [m.nrm[v * 3] / 127, m.nrm[v * 3 + 2] / 127, -m.nrm[v * 3 + 1] / 127];
          const l = Math.hypot(...q) || 1;
          nrm.set(q.map((x) => x / l), o * 3);
        }
      accessors.push({ bufferView: pushView(pos, 34962), componentType: 5126, count: k, type: 'VEC3', min, max });
      accessors.push({ bufferView: pushView(nrm, 34962), componentType: 5126, count: k, type: 'VEC3' });
      const [r, g, b, a] = key.split(',').map(Number);
      primitives.push({ attributes: { POSITION: accessors.length - 2, NORMAL: accessors.length - 1 }, material: materialOf(r, g, b, a) });
    }
    if (!primitives.length) continue;
    const label = el.name || el.elementId || el.number || el.typeName || el.id;
    meshes.push({ name: `${el.kind} ${label}`, primitives });
    const extras = { bdId: el.id, kind: el.kind };
    for (const [k, v] of [['name', el.name], ['elementId', el.elementId], ['guid', el.ifcGuid || el.acGuid], ['type', el.typeName], ['level', level?.name]]) if (v) extras[k] = String(v);
    nodes.push({ name: `${el.kind} ${label}`, mesh: meshes.length - 1, extras });
    const idx = nodes.length - 1;
    if (level) {
      if (!levelNodes.has(level.id)) {
        nodes.push({ name: level.name || 'Level', children: [], extras: { bdId: level.id, kind: 'level', elevation: level.elevation } });
        levelNodes.set(level.id, nodes.length - 1);
        roots.push(nodes.length - 1);
      }
      nodes[levelNodes.get(level.id)].children.push(idx);
    } else roots.push(idx);
  }
  const gltf = {
    asset: { version: '2.0', generator: 'Building Design' },
    scene: 0,
    scenes: [{ name, nodes: roots }],
    nodes,
    meshes,
    materials: gMaterials,
    accessors,
    bufferViews,
    buffers: [{ byteLength }],
  };
  if (gMaterials.some((m) => m.extensions)) gltf.extensionsUsed = ['KHR_materials_transmission'];
  if (!meshes.length) delete gltf.buffers;
  return glbBytes(gltf, bufs, byteLength);
}

function glbBytes(gltf, bufs, byteLength) {
  let json = new TextEncoder().encode(JSON.stringify(gltf));
  const jpad = (4 - (json.length % 4)) % 4;
  if (jpad) {
    const j = new Uint8Array(json.length + jpad).fill(0x20);
    j.set(json);
    json = j;
  }
  const bpad = (4 - (byteLength % 4)) % 4;
  const binLen = byteLength + bpad;
  const total = 12 + 8 + json.length + (byteLength ? 8 + binLen : 0);
  const out = new Uint8Array(total);
  const dv = new DataView(out.buffer);
  dv.setUint32(0, 0x46546c67, true);
  dv.setUint32(4, 2, true);
  dv.setUint32(8, total, true);
  dv.setUint32(12, json.length, true);
  dv.setUint32(16, 0x4e4f534a, true);
  out.set(json, 20);
  if (byteLength) {
    let o = 20 + json.length;
    dv.setUint32(o, binLen, true);
    dv.setUint32(o + 4, 0x004e4942, true);
    o += 8;
    for (const b of bufs) {
      out.set(b, o);
      o += b.length;
    }
  }
  return out;
}

const COMPONENTS = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };
const READERS = {
  5120: ['getInt8', 1, 127],
  5121: ['getUint8', 1, 255],
  5122: ['getInt16', 2, 32767],
  5123: ['getUint16', 2, 65535],
  5125: ['getUint32', 4, 0],
  5126: ['getFloat32', 4, 0],
};

/** The JSON and binary chunk of a .glb, or of a .gltf with its buffers embedded as data URIs. */
export function parseGLTF(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let json;
  const bins = [];
  if (bytes.length >= 12 && dv.getUint32(0, true) === 0x46546c67) {
    let o = 12;
    while (o + 8 <= bytes.length) {
      const len = dv.getUint32(o, true);
      const type = dv.getUint32(o + 4, true);
      const body = bytes.subarray(o + 8, o + 8 + len);
      if (type === 0x4e4f534a) json = JSON.parse(new TextDecoder().decode(body));
      else if (type === 0x004e4942) bins.push(body);
      o += 8 + len + ((4 - (len % 4)) % 4);
    }
  } else json = JSON.parse(new TextDecoder().decode(bytes));
  if (!json?.asset) throw new Error('Not a glTF file.');
  if (!String(json.asset.version || '').startsWith('2')) throw new Error(`glTF ${json.asset.version} is not supported (only 2.0).`);
  const unsupported = (json.extensionsRequired || []).filter((e) => e !== 'KHR_materials_transmission');
  if (unsupported.length) throw new Error(`The file needs ${unsupported.join(', ')}, which is not supported: export it again without compression.`);
  const buffers = (json.buffers || []).map((b, i) => {
    if (b.uri == null) return bins[0] || new Uint8Array(0);
    const m = /^data:[^,]*;base64,(.*)$/.exec(b.uri);
    if (!m) throw new Error(`Buffer ${i} is a separate file (${b.uri}): export a single .glb instead.`);
    const s = atob(m[1]);
    const u = new Uint8Array(s.length);
    for (let k = 0; k < s.length; k++) u[k] = s.charCodeAt(k);
    return u;
  });
  return { json, buffers };
}

function readAccessor(g, i) {
  const a = g.json.accessors[i];
  const n = COMPONENTS[a.type];
  const [get, size, norm] = READERS[a.componentType];
  const out = new Float64Array(a.count * n);
  if (a.bufferView == null) return out;
  const view = g.json.bufferViews[a.bufferView];
  const buf = g.buffers[view.buffer];
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  const stride = view.byteStride || size * n;
  const base = (view.byteOffset || 0) + (a.byteOffset || 0);
  for (let e = 0; e < a.count; e++)
    for (let c = 0; c < n; c++) {
      let v = dv[get](base + e * stride + c * size, true);
      if (a.normalized && norm) v = Math.max(v / norm, -1);
      out[e * n + c] = v;
    }
  return out;
}

const mul = (A, B) => {
  const C = new Array(16).fill(0);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) for (let k = 0; k < 4; k++) C[c * 4 + r] += A[k * 4 + r] * B[c * 4 + k];
  return C;
};
const IDENTITY = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];

function nodeMatrix(node) {
  if (node.matrix) return node.matrix;
  const [tx, ty, tz] = node.translation || [0, 0, 0];
  const [x, y, z, w] = node.rotation || [0, 0, 0, 1];
  const [sx, sy, sz] = node.scale || [1, 1, 1];
  // Column-major T · R · S.
  return [
    (1 - 2 * (y * y + z * z)) * sx, 2 * (x * y + z * w) * sx, 2 * (x * z - y * w) * sx, 0,
    2 * (x * y - z * w) * sy, (1 - 2 * (x * x + z * z)) * sy, 2 * (y * z + x * w) * sy, 0,
    2 * (x * z + y * w) * sz, 2 * (y * z - x * w) * sz, (1 - 2 * (x * x + y * y)) * sz, 0,
    tx, ty, tz, 1,
  ];
}

/** A glTF material as this app reads it: name, colour (#rrggbb, sRGB), opacity, roughness, metalness. */
function materialInfo(m, i) {
  const pbr = m?.pbrMetallicRoughness || {};
  const f = pbr.baseColorFactor || [0.8, 0.8, 0.8, 1];
  const transmission = m?.extensions?.KHR_materials_transmission?.transmissionFactor || 0;
  const opacity = Math.min(m?.alphaMode === 'BLEND' ? f[3] ?? 1 : 1, 1 - transmission * 0.85);
  return {
    name: m?.name || `Material ${i + 1}`,
    color: `#${f.slice(0, 3).map((v) => hex2(linearToSrgb(Math.max(0, Math.min(1, v))) * 255)).join('')}`,
    opacity: +Math.max(0.05, opacity).toFixed(3),
    roughness: pbr.roughnessFactor ?? 1,
    metallic: pbr.metallicFactor ?? 1,
    textured: !!pbr.baseColorTexture,
  };
}

/**
 * The meshes of a glTF file in this project's units: [{ name, material, pos (Float32Array triangles, mm, Z up),
 * edges (outline and creases, as segments) }], one per primitive, placed by the transforms of the nodes above them.
 * `scale` turns the file's metres into mm (1000).
 */
export function readGLTF(buffer, { scale = 1000 } = {}) {
  const g = parseGLTF(buffer);
  const { json } = g;
  const out = [];
  const scene = json.scenes?.[json.scene ?? 0];
  const roots = scene ? scene.nodes || [] : (json.nodes || []).map((_, i) => i);
  const seen = new Set();
  const visit = (i, parent) => {
    if (seen.has(i)) return;
    seen.add(i);
    const node = json.nodes[i];
    const M = mul(parent, nodeMatrix(node));
    if (node.mesh != null) {
      const mesh = json.meshes[node.mesh];
      (mesh.primitives || []).forEach((p, k) => {
        if ((p.mode ?? 4) !== 4 || p.attributes?.POSITION == null) return;
        const P = readAccessor(g, p.attributes.POSITION);
        const I = p.indices != null ? readAccessor(g, p.indices) : Array.from({ length: P.length / 3 }, (_, v) => v);
        const V = new Float32Array(P.length);
        for (let v = 0; v < P.length; v += 3) {
          const [x, y, z] = [P[v], P[v + 1], P[v + 2]];
          const w = [M[0] * x + M[4] * y + M[8] * z + M[12], M[1] * x + M[5] * y + M[9] * z + M[13], M[2] * x + M[6] * y + M[10] * z + M[14]];
          // Y up in metres → Z up in mm.
          V[v] = w[0] * scale;
          V[v + 1] = -w[2] * scale;
          V[v + 2] = w[1] * scale;
        }
        // A mirroring transform turns the faces inside out: swap two corners to keep them facing out.
        const det = M[0] * (M[5] * M[10] - M[9] * M[6]) - M[4] * (M[1] * M[10] - M[9] * M[2]) + M[8] * (M[1] * M[6] - M[5] * M[2]);
        const F = new Uint32Array(I.length - (I.length % 3));
        for (let t = 0; t < F.length; t += 3) {
          F[t] = I[t];
          F[t + 1] = det < 0 ? I[t + 2] : I[t + 1];
          F[t + 2] = det < 0 ? I[t + 1] : I[t + 2];
        }
        const mi = p.material;
        const N = p.attributes.NORMAL != null ? readAccessor(g, p.attributes.NORMAL) : null;
        out.push({ name: (mesh.name || node.name || `Mesh ${node.mesh + 1}`) + (mesh.primitives.length > 1 ? ` ${k + 1}` : ''), material: materialInfo(json.materials?.[mi], mi ?? 0), ...triangles(V, F, N) });
      });
    }
    for (const c of node.children || []) visit(c, M);
  };
  for (const r of roots) visit(r, IDENTITY);
  return out;
}

/**
 * Triangles from vertices and faces, with the outline and the creases as edges: faces meeting at over 20° along an
 * edge the file draws hard (its normals split there; a smooth-shaded cylinder has no edges down its sides).
 */
function triangles(V, F, N = null) {
  const pos = new Float32Array(F.length * 3);
  const P = (i) => [V[i * 3], V[i * 3 + 1], V[i * 3 + 2]];
  // Vertices at the same place are one (meshes are often split at UV seams).
  const keyOf = new Map();
  const weld = (i) => {
    const p = P(i);
    const k = p.map((v) => Math.round(v * 10)).join(',');
    if (!keyOf.has(k)) keyOf.set(k, i);
    return keyOf.get(k);
  };
  const W = Array.from(F, weld);
  const normals = [];
  for (let f = 0; f < F.length; f += 3) {
    const [a, b, c] = [P(F[f]), P(F[f + 1]), P(F[f + 2])];
    pos.set([...a, ...b, ...c], f * 3);
    const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
    const v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    const n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    const l = Math.hypot(...n) || 1;
    normals.push(n.map((x) => x / l));
  }
  const edgeFaces = new Map();
  for (let f = 0; f < W.length; f += 3)
    for (const [i, j] of [
      [W[f], W[f + 1]],
      [W[f + 1], W[f + 2]],
      [W[f + 2], W[f]],
    ]) {
      if (i === j) continue;
      const k = i < j ? `${i},${j}` : `${j},${i}`;
      if (!edgeFaces.has(k)) edgeFaces.set(k, []);
      edgeFaces.get(k).push(f / 3);
    }
  // The file's normal at each corner of a face, by welded vertex.
  const cornerNormal = (face, w) => {
    for (let c = 0; c < 3; c++) if (W[face * 3 + c] === w) return F[face * 3 + c];
    return -1;
  };
  const sameNormal = (a, b) => a === b || (a >= 0 && b >= 0 && N[a * 3] * N[b * 3] + N[a * 3 + 1] * N[b * 3 + 1] + N[a * 3 + 2] * N[b * 3 + 2] > 0.999);
  const smooth = (f0, f1, i, j) => N && sameNormal(cornerNormal(f0, i), cornerNormal(f1, i)) && sameNormal(cornerNormal(f0, j), cornerNormal(f1, j));
  const edges = [];
  const cos20 = Math.cos((20 * Math.PI) / 180);
  for (const [k, fs] of edgeFaces) {
    const [i0, j0] = k.split(',').map(Number);
    const crease = fs.length !== 2 || (normals[fs[0]].reduce((s, x, i) => s + x * normals[fs[1]][i], 0) < cos20 && !smooth(fs[0], fs[1], i0, j0));
    if (!crease) continue;
    const [i, j] = k.split(',').map(Number);
    edges.push(...P(i), ...P(j));
  }
  return { pos, edges: new Float32Array(edges) };
}
