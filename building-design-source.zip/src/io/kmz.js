/**
 * Send Model to Google Earth: the model as a KMZ (a ZIP with a KML placing
 * a COLLADA model at the project's location, turned to true north). The
 * model's origin goes to the project's latitude and longitude, on the ground.
 */
import { makeZip } from './zip.js';

const esc = (s) => String(s).replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' })[c]);
const r = (v) => Math.round(v * 1e4) / 1e4;

/**
 * COLLADA 1.4.1 text for meshes [{ name, pos (mm, Z up, 3 per vertex, 3 vertices per triangle), col (RGBA bytes per
 * vertex) }]: metres, Z up, one material per colour (a triangle takes its first vertex's colour).
 */
export function collada(meshes, { title = 'Model' } = {}) {
  const colours = new Map();
  const colourOf = (m, v) => {
    const c = m.col ? [m.col[v * 4], m.col[v * 4 + 1], m.col[v * 4 + 2], m.col[v * 4 + 3] ?? 255] : [200, 200, 200, 255];
    const key = c.join(',');
    if (!colours.has(key)) colours.set(key, { id: `mat${colours.size}`, c });
    return colours.get(key).id;
  };
  const geoms = [];
  meshes.forEach((m, gi) => {
    const n = m.pos.length / 3;
    if (n < 3) return;
    const byMat = new Map();
    for (let t = 0; t + 2 < n; t += 3) {
      const id = colourOf(m, t);
      if (!byMat.has(id)) byMat.set(id, []);
      byMat.get(id).push(t, t + 1, t + 2);
    }
    const pos = [];
    for (let i = 0; i < n * 3; i++) pos.push(r(m.pos[i] / 1000));
    const gid = `g${gi}`;
    const tris = [...byMat].map(([mat, idx]) => `<triangles material="${mat}" count="${idx.length / 3}"><input semantic="VERTEX" source="#${gid}-v" offset="0"/><p>${idx.join(' ')}</p></triangles>`);
    geoms.push({
      gid,
      name: m.name || gid,
      mats: [...byMat.keys()],
      xml: `<geometry id="${gid}" name="${esc(m.name || gid)}"><mesh><source id="${gid}-p"><float_array id="${gid}-a" count="${pos.length}">${pos.join(' ')}</float_array><technique_common><accessor source="#${gid}-a" count="${n}" stride="3"><param name="X" type="float"/><param name="Y" type="float"/><param name="Z" type="float"/></accessor></technique_common></source><vertices id="${gid}-v"><input semantic="POSITION" source="#${gid}-p"/></vertices>${tris.join('')}</mesh></geometry>`,
    });
  });
  const mats = [...colours.values()];
  const effects = mats.map(({ id, c }) => `<effect id="${id}-fx"><profile_COMMON><technique sid="common"><lambert><diffuse><color>${c.slice(0, 3).map((v) => r(v / 255)).join(' ')} 1</color></diffuse>${c[3] < 255 ? `<transparency><float>${r(c[3] / 255)}</float></transparency>` : ''}</lambert></technique></profile_COMMON></effect>`);
  const materials = mats.map(({ id }) => `<material id="${id}" name="${id}"><instance_effect url="#${id}-fx"/></material>`);
  const nodes = geoms.map((g) => `<node id="n-${g.gid}" name="${esc(g.name)}"><instance_geometry url="#${g.gid}"><bind_material><technique_common>${g.mats.map((m) => `<instance_material symbol="${m}" target="#${m}"/>`).join('')}</technique_common></bind_material></instance_geometry></node>`);
  return `<?xml version="1.0" encoding="utf-8"?>
<COLLADA xmlns="http://www.collada.org/2005/11/COLLADASchema" version="1.4.1">
<asset><contributor><authoring_tool>Building Design</authoring_tool></contributor><title>${esc(title)}</title><unit name="meter" meter="1"/><up_axis>Z_UP</up_axis></asset>
<library_effects>${effects.join('')}</library_effects>
<library_materials>${materials.join('')}</library_materials>
<library_geometries>${geoms.map((g) => g.xml).join('')}</library_geometries>
<library_visual_scenes><visual_scene id="scene">${nodes.join('')}</visual_scene></library_visual_scenes>
<scene><instance_visual_scene url="#scene"/></scene>
</COLLADA>
`;
}

/** KML placing models/model.dae at { lat, lon } with the model's +Y turned by `heading` degrees clockwise from north. */
export function kml({ name = 'Model', lat = 0, lon = 0, heading = 0 } = {}) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
<Placemark><name>${esc(name)}</name>
<LookAt><longitude>${lon}</longitude><latitude>${lat}</latitude><altitude>0</altitude><heading>0</heading><tilt>55</tilt><range>120</range></LookAt>
<Model><altitudeMode>relativeToGround</altitudeMode>
<Location><longitude>${lon}</longitude><latitude>${lat}</latitude><altitude>0</altitude></Location>
<Orientation><heading>${r(heading)}</heading><tilt>0</tilt><roll>0</roll></Orientation>
<Scale><x>1</x><y>1</y><z>1</z></Scale>
<Link><href>models/model.dae</href></Link></Model>
</Placemark>
</kml>
`;
}

/**
 * A KMZ (bytes) for meshes and a project: location { lat, lon } and trueNorth (degrees counterclockwise from the
 * model's +Y to north, so the model's +Y lies that many degrees clockwise from north).
 */
export function kmz(meshes, project = {}) {
  const loc = project.location || {};
  const name = project.name || 'Model';
  return makeZip([
    { name: 'doc.kml', data: kml({ name, lat: +loc.lat || 0, lon: +loc.lon || 0, heading: +project.trueNorth || 0 }) },
    { name: 'models/model.dae', data: collada(meshes, { title: name }) },
  ]);
}
