/**
 * The project built in a running Archicad (25 and later, through the Tapir add-on's JSON commands) and saved there as
 * a .pln: Archicad itself writes the file, so it opens in that Archicad version as any project of its own.
 *
 * Native elements where Archicad has the same thing: stories, straight and curved walls (at their centre line, base
 * and height), slabs with their holes, zones, columns, beams, doors and windows in their walls at their size and
 * sill. Everything else (roofs, stairs, railings, curtain walls, objects, morphs, terrains, MEP) goes as a morph with
 * the element's 3D as this app builds it, so nothing is lost in shape.
 *
 * `call(command, parameters)` runs one command and returns its response (the app sends it through its server, a test
 * passes its own). Lengths go in metres.
 */
import { verticalExtent, wallAxis, wallThickness, levelElevation, openingSize } from '../core/model.js';
import { typeThickness } from '../core/catalog.js';
import { signedArea } from '../core/geom.js';

const m = (v) => Math.round(+v) / 1000;
const xy = (p) => ({ x: m(p[0]), y: m(p[1]) });
// Kinds whose 3D goes across as a morph.
const AS_MORPH = ['roof', 'stair', 'railing', 'ramp', 'component', 'morph', 'shell', 'topo', 'mepSegment', 'mepFitting', 'mepAccessory', 'mepFlex', 'mepTerminal', 'equipment', 'ceiling'];

/** Story index of each level: the lowest level at or above zero is 0, the ones below negative. */
export function storyIndices(doc) {
  const levels = [...doc.levels()].sort((a, b) => (+a.elevation || 0) - (+b.elevation || 0));
  let ground = levels.findIndex((l) => (+l.elevation || 0) >= -1);
  if (ground < 0) ground = levels.length - 1;
  return new Map(levels.map((l, i) => [l.id, i - ground]));
}

/** A morph body from triangles (mm): shared vertices, one polygon per triangle. */
export function morphBody(pos) {
  const idx = new Map();
  const vertices = [];
  const polygons = [];
  const at = (i) => {
    const k = `${Math.round(pos[i])},${Math.round(pos[i + 1])},${Math.round(pos[i + 2])}`;
    if (!idx.has(k)) {
      idx.set(k, vertices.length);
      vertices.push({ x: m(pos[i]), y: m(pos[i + 1]), z: m(pos[i + 2]) });
    }
    return idx.get(k);
  };
  const key = (i) => `${Math.round(pos[i])},${Math.round(pos[i + 1])},${Math.round(pos[i + 2])}`;
  for (let t = 0; t + 8 < pos.length; t += 9) {
    // A triangle with two corners at one point is a sliver: none of its corners is added for it.
    if (new Set([key(t), key(t + 3), key(t + 6)]).size < 3) continue;
    polygons.push({ vertexIds: [at(t), at(t + 3), at(t + 6)] });
  }
  return { vertices, polygons };
}

const guidOf = (r, i = 0) => r?.elements?.[i]?.elementId?.guid || r?.elements?.[i]?.guid || null;
const unwrap = (r) => r?.result?.addOnCommandResponse ?? r?.addOnCommandResponse ?? r?.result ?? r;

/**
 * Build the project in Archicad. Options: { path (the .pln to save, absolute), newProject (start from an empty one,
 * default true), meshOf(el) (triangles in mm for the elements that go as morphs), onProgress(text) }.
 * Returns { counts, failed: [{ id, kind, error }], path }.
 */
export async function exportToArchicad(doc, call, { path, newProject = true, meshOf = () => null, onProgress = () => {} } = {}) {
  const run = async (command, parameters) => {
    const r = unwrap(await call(command, parameters));
    if (r?.error || r?.succeeded === false) throw new Error(r?.error?.message || r?.error || `${command} failed`);
    return r;
  };
  const counts = {};
  const failed = [];
  const count = (k, n = 1) => (counts[k] = (counts[k] || 0) + n);
  const fail = (el, e) => failed.push({ id: el.id, kind: el.kind, error: String(e?.message || e) });
  if (newProject) {
    onProgress('New project');
    await run('NewProject', {});
  }
  // Stories, from the bottom up.
  const index = storyIndices(doc);
  const levels = [...doc.levels()].sort((a, b) => (+a.elevation || 0) - (+b.elevation || 0));
  onProgress('Stories');
  await run('SetStories', { stories: levels.map((l) => ({ index: index.get(l.id), name: l.name || `Story ${index.get(l.id)}`, level: m(l.elevation || 0), dispOnSections: true })) });
  count('stories', levels.length);
  const floorOf = (el) => index.get(el.levelId) ?? 0;
  // Walls, then the openings in them.
  const wallGuid = new Map();
  const walls = doc.all('wall').filter((w) => !doc.get(w.typeId)?.curtain && !w.curtain);
  onProgress(`${walls.length} walls`);
  for (const w of walls) {
    try {
      const ax = wallAxis(doc, w);
      const { base, top } = verticalExtent(doc, w);
      const lv = levelElevation(doc, w.levelId);
      const data = { begCoordinate: xy(ax.curve ? w.a : ax.a), endCoordinate: xy(ax.curve ? w.b : ax.b), floorIndex: floorOf(w), zCoordinate: m(base - lv), height: m(top - base), thickness: m(wallThickness(doc, w)), structureType: 'Basic', referenceLineLocation: 'Center' };
      if (w.arc) data.arcAngle = +w.arc;
      if (w.arc && ax.curve) {
        // The arc's centre line: Archicad's reference line is the drawn one moved to the centre.
        const c = ax.curve;
        const p = (ang) => [c.c[0] + c.r * Math.cos(ang), c.c[1] + c.r * Math.sin(ang)];
        data.begCoordinate = xy(p(c.a0));
        data.endCoordinate = xy(p(c.a0 + c.sweep));
      }
      const r = await run('CreateWalls', { wallsData: [data] });
      const g = guidOf(r);
      if (g) wallGuid.set(w.id, g);
      count('walls');
    } catch (e) {
      fail(w, e);
    }
  }
  for (const kind of ['door', 'window']) {
    const list = doc.all(kind).filter((o) => wallGuid.has(o.hostId));
    for (const o of list) {
      try {
        const host = doc.get(o.hostId);
        const size = openingSize(doc, o);
        const width = +o.width || +doc.get(o.typeId)?.width || size?.width || 900;
        const height = +o.height || +doc.get(o.typeId)?.height || size?.height || (kind === 'door' ? 2100 : 1200);
        const sill = kind === 'door' ? 0 : +(o.sill ?? doc.get(o.typeId)?.sill ?? 900);
        // Archicad measures along the reference line from its start; the app's t is from a along the drawn line.
        const item = { ownerWallId: { guid: wallGuid.get(host.id) }, centerOffset: m(+o.t || 0), width: m(width), height: m(height), sillHeight: m(sill) };
        const r = await run(kind === 'door' ? 'CreateDoors' : 'CreateWindows', { [`${kind}sData`]: [item] });
        const g = guidOf(r);
        // Archicad sizes the hole from the library part's own defaults until the size is set again.
        if (g) await run(kind === 'door' ? 'ModifyDoors' : 'ModifyWindows', { [`${kind}sWithDetails`]: [{ elementId: { guid: g }, width: m(width), height: m(height), sillHeight: m(sill) }] }).catch(() => {});
        count(`${kind}s`);
      } catch (e) {
        fail(o, e);
      }
    }
  }
  // Slabs at their top, with their holes.
  for (const f of doc.all('floor')) {
    try {
      if (!Array.isArray(f.boundary) || f.boundary.length < 3) continue;
      const th = typeThickness(doc.get(f.typeId)) || 200;
      const outer = signedArea(f.boundary) < 0 ? [...f.boundary].reverse() : f.boundary;
      const data = { floorIndex: floorOf(f), level: m(+f.offset || 0), thickness: m(th), structureType: 'Basic', polygonCoordinates: outer.map(xy) };
      const holes = (f.holes || []).filter((h) => h.length >= 3).map((h) => ({ polygonCoordinates: h.map(xy) }));
      try {
        await run('CreateSlabs', { slabsData: [holes.length ? { ...data, holes } : data] });
      } catch (e) {
        if (!holes.length) throw e;
        await run('CreateSlabs', { slabsData: [data] });
        failed.push({ id: f.id, kind: 'floor', error: `holes left out: ${e.message}` });
      }
      count('slabs');
    } catch (e) {
      fail(f, e);
    }
  }
  // Zones by their outline.
  for (const room of doc.all('room')) {
    try {
      const outline = room.boundary?.length >= 3 ? room.boundary : null;
      if (!outline || outline.length < 3) {
        await run('CreateZones', { zonesData: [{ floorIndex: floorOf(room), name: room.name || 'Zone', numberStr: String(room.number || ''), geometry: { referencePosition: xy(room.at) } }] });
      } else {
        const outer = signedArea(outline) < 0 ? [...outline].reverse() : outline;
        await run('CreateZones', { zonesData: [{ floorIndex: floorOf(room), name: room.name || 'Zone', numberStr: String(room.number || ''), geometry: { polygonCoordinates: outer.map(xy) } }] });
      }
      count('zones');
    } catch (e) {
      fail(room, e);
    }
  }
  // Columns and beams.
  for (const c of doc.all('column')) {
    try {
      const t = doc.get(c.typeId) || {};
      const { base, top } = verticalExtent(doc, c);
      const r = await run('CreateColumns', { columnsData: [{ coordinates: { x: m(c.at[0]), y: m(c.at[1]), z: m(base) } }] });
      const g = guidOf(r);
      const round = t.shape === 'round' || t.shape === 'circle';
      if (g) await run('ModifyColumns', { columnsWithDetails: [{ elementId: { guid: g }, isWidthAndHeightLinked: false, circleBased: round, width: m(t.width || 300), depth: m(round ? t.width || 300 : t.depth || t.width || 300), height: m(top - base), axisRotationAngle: +c.rotation || 0 }] });
      count('columns');
    } catch (e) {
      fail(c, e);
    }
  }
  for (const b of doc.all('beam')) {
    try {
      const t = doc.get(b.typeId) || {};
      const lv = levelElevation(doc, b.levelId);
      const z = lv + (+b.offset || +b.baseOffset || 0);
      await run('CreateBeams', { beamsData: [{ begCoordinate: xy(b.a), endCoordinate: xy(b.b), zCoordinate: m(z - lv), floorIndex: floorOf(b), width: m(t.width || 200), height: m(t.depth || t.height || 400), isWidthAndHeightLinked: false }] });
      count('beams');
    } catch (e) {
      fail(b, e);
    }
  }
  // The rest as morphs of their 3D.
  const others = [];
  for (const k of AS_MORPH) for (const el of doc.all(k)) others.push(el);
  for (const w of doc.all('wall')) if (doc.get(w.typeId)?.curtain || w.curtain) others.push(w);
  onProgress(`${others.length} elements as morphs`);
  for (const el of others) {
    try {
      const pos = meshOf(el);
      if (!pos || pos.length < 9) continue;
      const body = morphBody(pos);
      if (body.polygons.length < 1) continue;
      await run('CreateMorphs', { morphsData: [{ basePoint: { x: 0, y: 0, z: 0 }, body, floorIndex: floorOf(el) }] });
      count('morphs');
    } catch (e) {
      fail(el, e);
    }
  }
  if (path) {
    onProgress('Saving');
    await run('SaveProject', { projectPath: path });
  }
  return { counts, failed, path: path || null };
}
