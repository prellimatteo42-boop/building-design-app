/**
 * An Archicad project (.pln, read by pln.js) as elements of this project: its stories as levels, walls, slabs, zones,
 * doors and windows in their walls, and placed objects. A door, window or object takes its Archicad library part when the
 * caller can make one (partTypeOf), else a type of this app of its size. Experimental: what is not read is counted.
 */
import { wallTypeMaking } from '../core/floorplan.js';
import { patternLines } from '../core/cwscheme.js';

const area2 = (pts) => pts.reduce((a, p, i) => a + p[0] * pts[(i + 1) % pts.length][1] - pts[(i + 1) % pts.length][0] * p[1], 0);

function centroid(pts) {
  const A = area2(pts);
  if (Math.abs(A) < 1e-9) return pts[0];
  let cx = 0;
  let cy = 0;
  for (let i = 0; i < pts.length; i++) {
    const [a, b] = [pts[i], pts[(i + 1) % pts.length]];
    const k = a[0] * b[1] - b[0] * a[1];
    cx += (a[0] + b[0]) * k;
    cy += (a[1] + b[1]) * k;
  }
  return [Math.round(cx / (3 * A)), Math.round(cy / (3 * A))];
}

function inside(p, poly) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [a, b] = [poly[i], poly[j]];
    if (a[1] > p[1] !== b[1] > p[1] && p[0] < ((b[0] - a[0]) * (p[1] - a[1])) / (b[1] - a[1]) + a[0]) c = !c;
  }
  return c;
}

/**
 * Adds what pln holds to doc (inside a transaction). partTypeOf(part, kind) → a door, window or object type (not yet
 * added) from the user's Archicad libraries, or null. → counts of what was made, with skipped and notes.
 */
export function plnToModel(doc, pln, { name = 'Archicad project', partTypeOf = null, renameLevels = false } = {}) {
  const out = { levels: 0, walls: 0, slabs: 0, zones: 0, doors: 0, windows: 0, objects: 0, columns: 0, beams: 0, roofs: 0, meshes: 0, curtainWalls: 0, railings: 0, stairs: 0, morphs: 0, libraryParts: 0, skipped: { ...pln.skipped }, notes: [...pln.notes] };
  const skip = (what) => (out.skipped[what] = (out.skipped[what] || 0) + 1);
  // Stories as levels; one at the same elevation is used.
  const levelOf = new Map();
  for (const s of [...pln.stories].sort((a, b) => a.elevation - b.elevation)) {
    let lv = doc.levels().find((l) => Math.abs(l.elevation - s.elevation) < 20);
    if (lv && renameLevels && s.name) {
      doc.update(lv.id, { name: s.name });
      for (const v of doc.all('plan').filter((x) => x.levelId === lv.id)) doc.update(v.id, { name: s.name });
    }
    if (!lv) {
      lv = doc.add({ kind: 'level', name: s.name || `Story ${s.index}`, elevation: Math.round(s.elevation) });
      doc.add({ kind: 'plan', name: lv.name, levelId: lv.id, scale: 100, detail: 'medium' });
      out.levels++;
    }
    levelOf.set(s.index, lv);
  }
  const ground = levelOf.get(0) || doc.levels()[0];
  const level = (story) => levelOf.get(story) || ground;
  // Walls: the reference line moved to the wall's centre. The wall lies on the inside of its reference line, which is
  // `offset` from its outside face: the inside is to the right of the line, or to the left when the wall is flipped. A
  // slanted wall leans to its outside face (alpha from the floor; a trapezoid wall's inside face at beta), and its
  // thickness across the slant is wider on the floor. Its top is linked to a story or set by its height.
  const walls = new Map();
  for (const w of pln.walls) {
    const L = Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]);
    if (L < 1) {
      skip('walls of no length');
      continue;
    }
    const side = w.flipped ? -1 : 1;
    const inward = [(side * (w.b[1] - w.a[1])) / L, (-side * (w.b[0] - w.a[0])) / L];
    const leanOut = (x) => Math.round(((Math.PI / 2 - x) * 180) / Math.PI * 100) / 100;
    const thick = w.slant && w.slant.outside === w.slant.inside && Math.sin(w.slant.outside) > 0.2 ? w.thickness / Math.sin(w.slant.outside) : w.thickness;
    const shift = w.arc ? 0 : thick / 2 - w.offset;
    const move = (p) => [Math.round(p[0] + inward[0] * shift), Math.round(p[1] + inward[1] * shift)];
    // A curved wall keeps its reference line, placed by the app's location line on the same side.
    const near = (x) => Math.abs(w.offset - x) < 1;
    const curved = w.arc ? { arc: w.arc, locationLine: near(0) ? 'exterior' : near(w.thickness) ? 'interior' : 'center', ...(w.flipped ? { flipped: true } : {}) } : {};
    // The app's exterior is to the left of a → b, Archicad's outside face is there unless the wall is flipped.
    const slant = w.slant && !w.arc
      ? w.slant.outside === w.slant.inside
        ? { slant: 'slanted', slantOuter: side * leanOut(w.slant.outside) }
        : { slant: 'double', slantOuter: side * leanOut(w.flipped ? w.slant.inside : w.slant.outside), slantInner: side * leanOut(w.flipped ? w.slant.outside : w.slant.inside) }
      : {};
    const lv = level(w.story);
    const topLv = w.topStory != null ? levelOf.get(w.topStory) : null;
    const top = topLv && topLv !== lv ? { topLevelId: topLv.id, topOffset: Math.round(w.topOffset || 0) } : { topLevelId: null, topOffset: 0 };
    // A slanted wall is wider on the floor than its thickness: a generic type of that exact width.
    const t = Math.round(thick);
    const type =
      t === Math.round(w.thickness)
        ? wallTypeMaking(doc, t, undefined, true)
        : doc.all('wallType').find((x) => x.name === `Generic - ${t} mm`) || doc.add({ kind: 'wallType', name: `Generic - ${t} mm`, function: 'interior', layers: [{ materialId: 'mat-default', thickness: t, function: 'structure' }] });
    const el = doc.add({ kind: 'wall', typeId: type.id, levelId: lv.id, a: move(w.a), b: move(w.b), baseOffset: Math.round(w.bottomOffset || 0), ...top, height: Math.round(w.height), locationLine: 'center', ...curved, ...slant, joinA: true, joinB: true, roomBounding: true, elementId: w.elementId || undefined, acGuid: w.guid });
    walls.set(w.guid, { el, lv });
    out.walls++;
  }
  for (const s of pln.slabs) {
    const lv = level(s.story);
    const th = s.z ? Math.max(1, Math.round(s.z[1] - s.z[0])) : 250;
    let type = doc.all('floorType').find((t) => !t.foundation && Math.abs((t.layers || []).reduce((a, l) => a + (+l.thickness || 0), 0) - th) <= 1);
    if (!type) type = doc.add({ kind: 'floorType', name: `Generic - ${th} mm`, layers: [{ materialId: 'mat-concrete', thickness: th, function: 'structure' }] });
    doc.add({ kind: 'floor', typeId: type.id, levelId: lv.id, boundary: s.boundary, holes: s.holes, offset: s.z ? Math.round(s.z[1] - lv.elevation) : 0, elementId: s.elementId || undefined, acGuid: s.guid });
    out.slabs++;
  }
  for (const z of pln.zones) {
    const lv = level(z.story);
    let at = centroid(z.boundary);
    if (!inside(at, z.boundary)) at = z.boundary[0].map((v, i) => Math.round((v + z.boundary[Math.min(2, z.boundary.length - 1)][i]) / 2));
    doc.add({ kind: 'room', levelId: lv.id, at, boundary: z.boundary, name: z.name || 'Zone', number: z.number || '', acGuid: z.guid });
    out.zones++;
  }
  for (const c of pln.columns || []) {
    const lv = level(c.story);
    const round = c.shape === 'round';
    const tname = round ? `Round ${Math.round(c.width)} mm` : `${Math.round(c.width)} x ${Math.round(c.depth)} mm`;
    let type = doc.all('columnType').find((t) => t.name === tname);
    if (!type) {
      const { id: _id, ...rest } = doc.all('columnType')[0] || {};
      type = doc.add({ ...rest, kind: 'columnType', name: tname, width: Math.round(c.width), depth: Math.round(round ? c.width : c.depth), shape: round ? 'round' : 'rect' });
    }
    doc.add({ kind: 'column', typeId: type.id, levelId: lv.id, at: c.at.map(Math.round), rotation: 0, baseOffset: Math.round(c.z[0]), topLevelId: null, height: Math.round(c.z[1] - c.z[0]), elementId: c.elementId || undefined, acGuid: c.guid });
    out.columns++;
  }
  for (const b of pln.beams || []) {
    const lv = level(b.story);
    const [w, d] = [Math.round(b.width), Math.round(b.depth)];
    let type = doc.all('beamType').find((t) => Math.abs(+t.width - w) <= 1 && Math.abs(+t.depth - d) <= 1);
    if (!type) type = doc.add({ kind: 'beamType', name: `${w} x ${d} mm`, width: w, depth: d, materialId: 'mat-concrete' });
    // The axis is the beam's top, as Archicad's reference; a sloping beam has a height at each end.
    doc.add({ kind: 'beam', typeId: type.id, levelId: lv.id, a: b.a.map(Math.round), b: b.b.map(Math.round), offset: Math.round(b.z[0]), ...(Math.abs(b.z[1] - b.z[0]) > 1 ? { endOffset: Math.round(b.z[1]) } : {}), elementId: b.elementId || undefined, acGuid: b.guid });
    out.beams++;
  }
  for (const r of pln.roofs || []) {
    const lv = level(r.story);
    let poly = r.boundary.map((p) => p.map(Math.round));
    if (area2(poly) < 0) poly = poly.reverse();
    const [pa, pb] = r.pivot;
    const L = Math.hypot(pb[0] - pa[0], pb[1] - pa[1]);
    if (poly.length < 3 || L < 1) {
      skip('roofs not understood');
      continue;
    }
    const dir = [(pb[0] - pa[0]) / L, (pb[1] - pa[1]) / L];
    // Uphill is to the left of the pivot line; an edge along it on the low side is an eave, the rest are gables.
    const up = [-dir[1], dir[0]];
    const height = (q) => (q[0] - pa[0]) * up[0] + (q[1] - pa[1]) * up[1];
    const lowest = Math.min(...poly.map(height));
    const n = poly.length;
    const eave = poly.map((a, i) => {
      const b = poly[(i + 1) % n];
      const e = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
      const along = Math.abs(((b[0] - a[0]) * up[0] + (b[1] - a[1]) * up[1]) / e) < 0.01;
      return along && Math.abs(height(a) - lowest) < 5;
    });
    if (!eave.some(Boolean)) {
      skip('roofs not understood');
      continue;
    }
    // An eave beyond the pivot line overhangs it: the outline's edge moves onto the pivot line.
    const over = Math.round(-lowest);
    const moved = poly.map((p) => p.slice());
    poly.forEach((a, i) => {
      if (!eave[i] || !over) return;
      const j = (i + 1) % n;
      for (const k of [i, j]) {
        // Along the neighbouring edge, back to the pivot line.
        const nb = k === i ? poly[(i - 1 + n) % n] : poly[(j + 1) % n];
        const v = [nb[0] - poly[k][0], nb[1] - poly[k][1]];
        const rise = v[0] * up[0] + v[1] * up[1];
        if (Math.abs(rise) < 1e-6) continue;
        const t = over / rise;
        moved[k] = [Math.round(poly[k][0] + v[0] * t), Math.round(poly[k][1] + v[1] * t)];
      }
    });
    let type = doc.all('roofType').find((t) => Math.abs((t.layers || []).reduce((a, l) => a + (+l.thickness || 0), 0) - r.thickness) <= 1);
    if (!type) type = doc.add({ kind: 'roofType', name: `Roof - ${Math.round(r.thickness)} mm`, layers: [{ materialId: 'mat-roofing', thickness: Math.round(r.thickness), function: 'structure' }] });
    doc.add({ kind: 'roof', typeId: type.id, levelId: lv.id, boundary: moved, slopes: eave.map((e) => (e ? Math.round(r.slope * 100) / 100 : 0)), overhangs: eave.map((e) => (e ? Math.max(0, over) : 0)), baseOffset: 0, acGuid: r.guid });
    out.roofs++;
  }
  for (const m of pln.meshes || []) {
    // A terrain: its corners at their heights above the project zero; its bottom as deep as Archicad's.
    const z0 = level(m.story).elevation;
    const pts = m.boundary.map((p) => [Math.round(p[0]), Math.round(p[1]), Math.round(p[2] + z0)]);
    const low = Math.min(...pts.map((p) => p[2]));
    const thickness = m.bottom != null && low - (m.bottom + z0) > 1 ? Math.round(low - (m.bottom + z0)) : 1000;
    doc.add({ kind: 'topo', points: [], boundary: pts, ridges: [], thickness, contour: 500, materialId: 'mat-earth', acGuid: m.guid });
    out.meshes++;
  }
  const curtainType = doc.all('wallType').find((t) => t.curtain);
  for (const c of pln.curtainWalls || []) {
    if (!curtainType) {
      skip('curtain walls with no curtain wall type');
      continue;
    }
    const lv = level(c.story);
    // Archicad's frame sizes: a curtain wall type of those frames (one per set of sizes).
    let cwType = curtainType;
    if (c.frames && Object.keys(c.frames).length) {
      const frames = Object.fromEntries(Object.entries(c.frames).map(([role, f]) => [role, { kind: 'rect', width: Math.round(f.width), depth: Math.round(f.depth) }]));
      const key = JSON.stringify(frames);
      cwType = doc.all('wallType').find((t) => t.curtain && t.acFrames === key);
      if (!cwType) {
        const { id, ...rest } = curtainType;
        const m = frames.mullion || frames.boundary;
        cwType = doc.add({ ...structuredClone(rest), name: `${curtainType.name} ${m.width}x${m.depth}`, acFrames: key, curtain: { ...structuredClone(curtainType.curtain), frames } });
      }
    }
    for (const sgm of c.segments) {
      // The segment's own grid (Archicad's pattern) as the wall's grid lines.
      const inner = (pat, total) => (pat ? patternLines(total, pat).slice(1, -1).map((x) => Math.round(x)) : undefined);
      const grid = { curtainU: inner(sgm.primary, Math.hypot(sgm.b[0] - sgm.a[0], sgm.b[1] - sgm.a[1])), curtainV: inner(sgm.secondary, sgm.height) };
      for (const k of Object.keys(grid)) if (!grid[k]) delete grid[k];
      doc.add({ kind: 'wall', typeId: cwType.id, levelId: lv.id, a: sgm.a.map(Math.round), b: sgm.b.map(Math.round), baseOffset: 0, topLevelId: null, topOffset: 0, height: Math.round(sgm.height), locationLine: 'center', joinA: true, joinB: true, roomBounding: true, acGuid: c.guid, ...grid });
    }
    out.curtainWalls++;
  }
  for (const r of pln.railings || []) {
    const lv = level(r.story);
    let type = doc.all('railingType').find((t) => Math.abs(+t.height - r.height) <= 1) || null;
    if (!type) {
      const { id: _id, ...rest } = doc.all('railingType')[0] || { kind: 'railingType', familyName: 'Railing', spacing: 110, rail: 50, baluster: 20, materialId: 'mat-steel' };
      type = doc.add({ ...rest, kind: 'railingType', name: `Railing - ${Math.round(r.height)} mm`, height: Math.round(r.height) });
    }
    const zs = r.path.map((p) => Math.round(p[2] - lv.elevation));
    const flat = zs.every((z) => Math.abs(z - zs[0]) < 1);
    doc.add({ kind: 'railing', typeId: type.id, levelId: lv.id, path: r.path.map((p) => [Math.round(p[0]), Math.round(p[1])]), offset: flat ? zs[0] : 0, ...(flat ? {} : { pathZ: zs }), acGuid: r.guid });
    out.railings++;
  }
  for (const st of pln.stairs || []) {
    const lv = level(st.story);
    const f = st.flights;
    if (!f?.length || f.length > 2) {
      skip('stairs of more than two flights');
      continue;
    }
    const d1 = f[0].dir;
    const W = st.width;
    const el = { kind: 'stair', typeId: doc.all('stairType')[0]?.id, levelId: lv.id, topLevelId: null, baseOffset: 0, topOffset: 0, height: Math.round(st.rise), a: st.start.map(Math.round), b: [Math.round(st.start[0] + d1[0] * 1000), Math.round(st.start[1] + d1[1] * 1000)], width: Math.round(W), tread: Math.round(st.tread), risers: st.risers, railings: false, shape: 'straight', acGuid: st.guid };
    if (f.length === 2) {
      const d2 = f[1].dir;
      const dot = d1[0] * d2[0] + d1[1] * d2[1];
      const cross = d1[0] * d2[1] - d1[1] * d2[0];
      const r1 = f[0].treads;
      const s1 = (r1 - 1) * st.tread;
      const v = [f[1].start[0] - st.start[0], f[1].start[1] - st.start[1]];
      const along = v[0] * d1[0] + v[1] * d1[1];
      const across = Math.abs(v[0] * -d1[1] + v[1] * d1[0]);
      el.turn = cross > 0 ? 'left' : 'right';
      el.splitRisers = r1;
      if (Math.abs(dot) < 0.1) {
        el.shape = 'l';
        el.landingDepth = Math.round(Math.max(W, along - s1 + W / 2));
      } else if (dot < -0.9) {
        el.shape = 'u';
        el.gap = Math.round(Math.max(0, across - W));
      }
    }
    doc.add(el);
    out.stairs++;
  }
  for (const m of pln.morphs || []) {
    const lv = level(m.story);
    // Triangles in model coordinates, their heights from the project zero.
    const tris = m.tris.flatMap((t) => t.flatMap((p) => [Math.round(p[0]), Math.round(p[1]), Math.round(p[2] + lv.elevation)]));
    doc.add({ kind: 'morph', levelId: lv.id, tris, materialId: 'mat-default', acGuid: m.guid });
    out.morphs++;
  }
  // Library parts made once each.
  const madeTypes = new Map();
  const typeFromLibrary = (part, kind) => {
    if (!part || !partTypeOf) return null;
    const key = `${kind}|${part.file}`;
    if (!madeTypes.has(key)) {
      let t = null;
      try {
        const spec = partTypeOf(part, kind);
        if (spec) {
          t = doc.add(spec);
          out.libraryParts++;
        }
      } catch {
        t = null;
      }
      madeTypes.set(key, t);
    }
    return madeTypes.get(key);
  };
  for (const kind of ['door', 'window']) {
    for (const o of pln[`${kind}s`]) {
      const host = walls.get(o.host);
      if (!host) {
        skip(`${kind}s whose wall was not read`);
        continue;
      }
      const w = host.el;
      const lib = typeFromLibrary(o.part, kind);
      const types = doc.all(kind === 'door' ? 'doorType' : 'windowType').filter((t) => t.family !== 'gdl');
      const type = (lib?.kind === `${kind}Type` ? lib : null) || types.reduce((best, x) => (!best || Math.abs(+x.width - o.width) + Math.abs(+x.height - o.height) < Math.abs(+best.width - o.width) + Math.abs(+best.height - o.height) ? x : best), null);
      if (!type) {
        skip(`${kind}s with no type`);
        continue;
      }
      const el = { kind, typeId: type.id, hostId: w.id, t: Math.round(o.t), acGuid: o.guid };
      if (Math.abs(+type.width - o.width) > 1) el.width = Math.round(o.width);
      if (Math.abs(+type.height - o.height) > 1) el.height = Math.round(o.height);
      const sill = o.sillElevation == null ? (kind === 'window' ? 900 : 0) : Math.round(o.sillElevation - host.lv.elevation - (+w.baseOffset || 0));
      if (kind === 'window') el.sill = sill;
      else Object.assign(el, { flipFacing: false, flipHand: false });
      doc.add(el);
      out[`${kind}s`]++;
    }
  }
  for (const o of pln.objects) {
    const lv = level(o.story);
    const lib = typeFromLibrary(o.part, 'object');
    const own = {};
    if (o.width) own.A = o.width;
    if (o.depth) own.B = o.depth;
    let type = lib?.kind === 'componentType' ? lib : null;
    let at = o.at;
    if (!type) {
      // A box of its size, named after its part; boxes stand on their centre, Archicad's parts on their origin.
      const w = Math.round(o.width || 600);
      const d = Math.round(o.depth || 600);
      const label = o.part?.name || 'Archicad object';
      type = doc.all('componentType').find((t) => t.acPart === label && t.width === w && t.depth === d) || doc.add({ kind: 'componentType', family: 'cabinet', category: 'furniture', familyName: 'Archicad Object', name: `${label} (not in loaded libraries)`, acPart: label, width: w, depth: d, height: 750 });
      const r = (o.rotation * Math.PI) / 180;
      at = [Math.round(o.at[0] + (Math.cos(r) * w - Math.sin(r) * d) / 2), Math.round(o.at[1] + (Math.sin(r) * w + Math.cos(r) * d) / 2)];
    }
    doc.add({ kind: 'component', typeId: type.id, levelId: lv.id, at, rotation: Math.round(o.rotation * 100) / 100, offset: Math.round(o.z || 0), ...(type.family === 'gdl' && Object.keys(own).length ? { gdlValues: own } : {}), elementId: o.elementId || undefined, acGuid: o.guid });
    out.objects++;
  }
  out.name = name;
  return out;
}
