/**
 * BCF 2.1 (BIM Collaboration Format) files of the project's issues, to
 * exchange them with other BIM software: one folder per topic with its
 * markup, viewpoint (camera and selected components, by IFC GlobalId) and
 * snapshot.
 */
import { makeZip, readZip } from './zip.js';
import { ifcGuidFor, cameraToBCF, cameraFromBCF, uuid } from '../core/issues.js';

const xml = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const unxml = (s) => String(s ?? '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
const vec = (tag, v) => `<${tag}><X>${v[0]}</X><Y>${v[1]}</Y><Z>${v[2]}</Z></${tag}>`;
const HEAD = '<?xml version="1.0" encoding="UTF-8"?>\n';

function dataURLBytes(url) {
  const m = /^data:[^;]+;base64,(.*)$/.exec(url || '');
  if (!m) return null;
  const bin = atob(m[1]);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function bytesDataURL(bytes, type = 'image/png') {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return `data:${type};base64,${btoa(bin)}`;
}

/** The BCF zip (Uint8Array) of issues. cameraOf(issue) gives a 3D orbit camera for its viewpoint, or null. */
export function writeBCF(doc, issues, cameraOf = (i) => i.viewpoint?.camera) {
  const files = [{ name: 'bcf.version', data: `${HEAD}<Version VersionId="2.1"><DetailedVersion>2.1</DetailedVersion></Version>\n` }];
  files.push({ name: 'project.bcfp', data: `${HEAD}<ProjectExtension><Project ProjectId="${xml(doc.project?.id || 'project')}"><Name>${xml(doc.project?.name)}</Name></Project><ExtensionSchema></ExtensionSchema></ProjectExtension>\n` });
  for (const is of issues) {
    const g = is.guid || uuid();
    const vg = uuid();
    const snap = dataURLBytes(is.snapshot);
    const comments = (is.comments || [])
      .map((c) => `<Comment Guid="${xml(c.guid || uuid())}"><Date>${xml(c.date)}</Date><Author>${xml(c.author)}</Author><Comment>${xml(c.text)}</Comment><Viewpoint Guid="${vg}"/></Comment>`)
      .join('');
    files.push({
      name: `${g}/markup.bcf`,
      data: `${HEAD}<Markup><Topic Guid="${xml(g)}" TopicType="${xml(is.type || 'Issue')}" TopicStatus="${xml(is.status || 'Open')}"><Title>${xml(is.title)}</Title><Priority>${xml(is.priority || 'Normal')}</Priority><CreationDate>${xml(is.created)}</CreationDate><CreationAuthor>${xml(is.author)}</CreationAuthor>${is.modified ? `<ModifiedDate>${xml(is.modified)}</ModifiedDate>` : ''}${is.assignedTo ? `<AssignedTo>${xml(is.assignedTo)}</AssignedTo>` : ''}<Description>${xml(is.description)}</Description></Topic>${comments}<Viewpoints Guid="${vg}"><Viewpoint>viewpoint.bcfv</Viewpoint>${snap ? '<Snapshot>snapshot.png</Snapshot>' : ''}</Viewpoints></Markup>\n`,
    });
    const sel = (is.viewpoint?.selection || []).filter((id) => doc.has(id)).map((id) => `<Component IfcGuid="${ifcGuidFor(id)}" AuthoringToolId="${xml(id)}"/>`).join('');
    const cam = cameraOf(is);
    let camXml = '';
    if (cam) {
      const c = cameraToBCF(cam);
      camXml = c.persp
        ? `<PerspectiveCamera>${vec('CameraViewPoint', c.eye)}${vec('CameraDirection', c.dir)}${vec('CameraUpVector', c.up)}<FieldOfView>${c.fov}</FieldOfView></PerspectiveCamera>`
        : `<OrthogonalCamera>${vec('CameraViewPoint', c.eye)}${vec('CameraDirection', c.dir)}${vec('CameraUpVector', c.up)}<ViewToWorldScale>${(cam.dist || 10000) / 1000}</ViewToWorldScale></OrthogonalCamera>`;
    }
    files.push({ name: `${g}/viewpoint.bcfv`, data: `${HEAD}<VisualizationInfo Guid="${vg}"><Components>${sel ? `<Selection>${sel}</Selection>` : ''}<Visibility DefaultVisibility="true"/></Components>${camXml}</VisualizationInfo>\n` });
    if (snap) files.push({ name: `${g}/snapshot.png`, data: snap });
  }
  return makeZip(files);
}

const tag = (src, name) => {
  const m = new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`).exec(src);
  return m ? unxml(m[1].trim()) : '';
};
const attr = (src, el, name) => {
  const m = new RegExp(`<${el}\\b[^>]*\\b${name}="([^"]*)"`).exec(src);
  return m ? unxml(m[1]) : '';
};
const vecOf = (src, name) => {
  const inner = new RegExp(`<${name}>([\\s\\S]*?)</${name}>`).exec(src)?.[1];
  if (!inner) return null;
  return ['X', 'Y', 'Z'].map((k) => parseFloat(tag(inner, k)) || 0);
};

/**
 * Issues read from a BCF zip: plain issue objects (no ids yet), their
 * selection mapped back to element ids through IFC GlobalIds or the
 * authoring tool's ids.
 */
export async function readBCF(doc, bytes) {
  const files = await readZip(bytes);
  const dec = new TextDecoder();
  const byGuid = new Map([...doc.items.values()].filter((e) => e.kind && !e.kind.endsWith('Type')).map((e) => [ifcGuidFor(e.id), e.id]));
  const out = [];
  for (const [name, data] of files) {
    if (!name.endsWith('/markup.bcf') || !data) continue;
    const folder = name.slice(0, -'markup.bcf'.length);
    const markup = dec.decode(data);
    const topic = /<Topic\b[\s\S]*?<\/Topic>/.exec(markup)?.[0] || '';
    const comments = [...markup.matchAll(/<Comment\b[^>]*Guid="([^"]*)"[^>]*>([\s\S]*?)<\/Comment>\s*(?=<Comment\b|<Viewpoints|<\/Markup)/g)].map((m) => ({ guid: m[1], date: tag(m[2], 'Date'), author: tag(m[2], 'Author'), text: tag(m[2], 'Comment') }));
    const vps = tag(markup, 'Viewpoints');
    const vpName = tag(vps, 'Viewpoint') || 'viewpoint.bcfv';
    const snapName = tag(vps, 'Snapshot');
    const vp = files.get(folder + vpName);
    const vpx = vp ? dec.decode(vp) : '';
    const selection = [...vpx.matchAll(/<Component\b([^>]*)\/?>/g)]
      .map((m) => {
        const g = /IfcGuid="([^"]*)"/.exec(m[1])?.[1];
        const own = /AuthoringToolId="([^"]*)"/.exec(m[1])?.[1];
        return (own && doc.has(own) && own) || byGuid.get(g) || null;
      })
      .filter(Boolean);
    const camSrc = /<(Perspective|Orthogonal)Camera>[\s\S]*?<\/\1Camera>/.exec(vpx);
    let camera = null;
    if (camSrc) {
      const eye = vecOf(camSrc[0], 'CameraViewPoint');
      const dir = vecOf(camSrc[0], 'CameraDirection');
      if (eye && dir) camera = cameraFromBCF({ eye, dir, fov: parseFloat(tag(camSrc[0], 'FieldOfView')) || 45, persp: camSrc[1] === 'Perspective' });
    }
    const snap = snapName && files.get(folder + snapName);
    out.push({
      guid: attr(topic, 'Topic', 'Guid') || folder.replace(/\/$/, ''),
      title: tag(topic, 'Title') || 'Untitled issue',
      type: attr(topic, 'Topic', 'TopicType') || 'Issue',
      status: attr(topic, 'Topic', 'TopicStatus') || 'Open',
      priority: tag(topic, 'Priority') || 'Normal',
      created: tag(topic, 'CreationDate'),
      author: tag(topic, 'CreationAuthor'),
      modified: tag(topic, 'ModifiedDate') || null,
      assignedTo: tag(topic, 'AssignedTo') || '',
      description: tag(topic, 'Description'),
      comments,
      viewpoint: { viewId: null, camera, selection },
      snapshot: snap ? bytesDataURL(snap) : null,
    });
  }
  return out;
}
