/**
 * Library parts made with a model-import add-on for Archicad ("ModelPort") keep their 3D in a data section of their
 * own ('mpcu') that their scripts hand to the add-on. The section is a scene, written field by field with its class
 * schemas inline: nodes ("Locator") with a transform (position, rotation in radians about x, y, z, scale) and the
 * GUIDs of their children, and geometry parts whose mesh is an LZMA stream: positions (doubles, inches), then per
 * corner normals and UVs, then edges (two vertex numbers each), polygons (corner count and material number) and per
 * corner a signed edge number (1-based; negative = the edge run backwards). Read from the files themselves: this is
 * what lets such parts show in 3D without the add-on.
 *
 * `modelPortGeometry(section)` → { groups: [{ name, color: [r, g, b], tris: number[] (x, y, z metres, 9 per
 * triangle), edges: number[] (6 per edge) }], min, max } or null when the section is not one this reads.
 */
import earcut from 'earcut';
import { lzmaDecode } from './lzma.js';

const INCH = 0.0254;
const ascii = (s) => Array.from(s, (c) => c.charCodeAt(0));
const CHILDREN = [9, 0, 0, 0, 0, 0, 0, 0, ...ascii('children'), 0, 1, 4, 0, 3];
const PARENT = [7, 0, 0, 0, 0, 0, 0, 0, ...ascii('parent'), 0, 1, 3, 0];
const CAMERA = [0, ...ascii('Camera'), 0];
const MATERIAL_REF = [9, 0, 0, 0, 0, 0, 0, 0, ...ascii('Material'), 0];
const COLOR = [6, 3, 0, 0, 1, 0];

function find(b, pat, from = 0, to = b.length) {
  const first = pat[0];
  for (let i = from; i + pat.length <= to; i++) {
    if (b[i] !== first) continue;
    let k = 1;
    while (k < pat.length && b[i + k] === pat[k]) k++;
    if (k === pat.length) return i;
  }
  return -1;
}
function findAll(b, pat) {
  const out = [];
  for (let i = find(b, pat); i >= 0; i = find(b, pat, i + 1)) out.push(i);
  return out;
}
function findLast(b, pat, from, to) {
  for (let i = to - pat.length; i >= from; i--) {
    let k = 0;
    while (k < pat.length && b[i + k] === pat[k]) k++;
    if (k === pat.length) return i;
  }
  return -1;
}
const hex = (b, o) => Array.from(b.subarray(o, o + 16), (x) => x.toString(16).padStart(2, '0')).join('');

/** The GUIDs of a reference list: 05 02 g, 06 03 g, 02 g or 03 g, one after another. */
function guidList(b, p, end) {
  const out = [];
  while (p + 17 <= end) {
    if ((b[p] === 5 || b[p] === 6) && (b[p + 1] === 2 || b[p + 1] === 3)) {
      out.push(hex(b, p + 2));
      p += 18;
    } else if (b[p] === 2 || b[p] === 3) {
      out.push(hex(b, p + 1));
      p += 17;
    } else break;
  }
  return out;
}

// 3x4 matrices, rows.
function transform(t) {
  const [px, py, pz, a, b, c, sx, sy, sz] = t;
  const [ca, sa, cb, sb, cc, sc] = [Math.cos(a), Math.sin(a), Math.cos(b), Math.sin(b), Math.cos(c), Math.sin(c)];
  // Rz · Ry · Rx: x first.
  const R = [
    [cc * cb, cc * sb * sa - sc * ca, cc * sb * ca + sc * sa],
    [sc * cb, sc * sb * sa + cc * ca, sc * sb * ca - cc * sa],
    [-sb, cb * sa, cb * ca],
  ];
  return R.map((r, i) => [r[0] * sx, r[1] * sy, r[2] * sz, [px, py, pz][i]]);
}
function compose(A, B) {
  return A.map((r) => [0, 1, 2, 3].map((j) => r[0] * B[0][j] + r[1] * B[1][j] + r[2] * B[2][j] + (j === 3 ? r[3] : 0)));
}
const apply = (M, x, y, z) => [M[0][0] * x + M[0][1] * y + M[0][2] * z + M[0][3], M[1][0] * x + M[1][1] * y + M[1][2] * z + M[1][3], M[2][0] * x + M[2][1] * y + M[2][2] * z + M[2][3]];
const IDENTITY = transform([0, 0, 0, 0, 0, 0, 1, 1, 1]);

/** The scene's nodes: transform, own GUIDs, children's GUIDs and parent, cameras left out. */
function sceneNodes(b, dv) {
  const cams = findAll(b, CAMERA);
  const isCam = (at) => cams.some((c) => c < at && at < c + 400);
  const nodes = [];
  for (const at of findAll(b, CHILDREN)) {
    const t = at + CHILDREN.length;
    if (t + 72 > b.length) continue;
    const T = [];
    for (let i = 0; i < 9; i++) T.push(dv.getFloat64(t + 8 * i, true));
    if (!T.every(Number.isFinite) || isCam(t)) continue;
    const pa = findLast(b, PARENT, Math.max(0, at - 2000), at);
    nodes.push({ at: t, M: transform(T), own: pa >= 36 ? guidList(b, pa - 36, pa) : [], kids: pa >= 0 ? guidList(b, pa + PARENT.length, at) : [] });
  }
  for (const n of nodes) n.parent = nodes.find((x) => x !== n && x.kids.some((k) => n.own.includes(k))) || null;
  const world = (n, depth = 0) => (n.parent && depth < 64 ? compose(world(n.parent, depth + 1), n.M) : n.M);
  for (const n of nodes) n.world = world(n);
  return nodes;
}

/** The materials a geometry part names (in its own order), each by its two GUIDs. */
function materialRefs(b, from, to) {
  const out = [];
  for (let i = find(b, MATERIAL_REF, from, to); i >= 0; i = find(b, MATERIAL_REF, i + 1, to)) {
    // 05 02 g1 06 03 g2 just before the label.
    const p = i - 36;
    if (p >= 0 && b[p] === 5 && b[p + 1] === 2 && b[p + 18] === 6 && b[p + 19] === 3) out.push([hex(b, p + 2), hex(b, p + 20)]);
  }
  return out;
}

/** A material's diffuse colour: its record holds its two GUIDs the other way round, then the colour floats. */
function materialOf(b, dv, ref) {
  const pat = [5, 2, ...ref[1].match(/../g).map((h) => parseInt(h, 16)), 6, 3, ...ref[0].match(/../g).map((h) => parseInt(h, 16))];
  const at = find(b, pat);
  if (at < 0) return null;
  // The name: the length-prefixed string just before (… name 00 01 01 03 00 05 02 …).
  let name = null;
  for (let q = at - 6; q > Math.max(0, at - 300); q--) {
    const n = Number(dv.getBigUint64(q, true));
    if (n > 0 && n < 200 && q + 8 + n === at - 5) {
      name = new TextDecoder().decode(b.subarray(q + 8, q + 8 + n)).replace(/\0+$/, '');
      break;
    }
  }
  const c = find(b, COLOR, at, Math.min(b.length, at + 2000));
  if (c < 0) return { name, color: null };
  const rgb = [0, 1, 2].map((k) => dv.getFloat32(c + COLOR.length + 4 * k, true));
  return { name, color: rgb.every((v) => v >= 0 && v <= 1) ? rgb : null };
}

/** A geometry block, decoded: positions, edges, polygons with their material numbers and corner edges. */
export function readMesh(o) {
  const dv = new DataView(o.buffer, o.byteOffset, o.byteLength);
  const tagAt = (p) => (p + 4 <= o.length ? String.fromCharCode(o[p + 3], o[p + 2], o[p + 1], o[p]) : '');
  const isTag = (p) => /^[A-Za-z ]{4}$/.test(tagAt(p)) && tagAt(p).trim().length >= 2;
  let p = find(o, ascii(' sop'));
  if (p < 0) return null;
  let pos = null;
  // Attribute blocks: tag, GUID, index count and indices, byte count and data; up to 12 bytes (a count and a number)
  // may come between two of them. Where no tag follows, the mesh does.
  for (let guard = 0; guard < 16; guard++) {
    let skip = 0;
    while (skip <= 12 && !isTag(p + skip)) skip += 4;
    if (skip > 12) break;
    p += skip;
    const tag = tagAt(p);
    let q = p + 20;
    const nIdx = dv.getUint32(q, true);
    q += 4 + 4 * nIdx;
    const nBytes = dv.getUint32(q, true);
    q += 4;
    if (q + nBytes > o.length) return null;
    if (tag === 'pos ') pos = new Float64Array(o.buffer.slice(o.byteOffset + q, o.byteOffset + q + nBytes - (nBytes % 24)));
    p = q + nBytes;
  }
  if (!pos) return null;
  // The mesh: the attributes it uses (a count and their GUIDs), edges, polygons, corners.
  const nAttr = dv.getUint16(p, true);
  if (nAttr > 16) return null;
  p += 2 + 16 * nAttr;
  const nE = dv.getUint32(p, true);
  p += 4;
  if (p + 8 * nE > o.length) return null;
  const edges = new Int32Array(o.buffer.slice(o.byteOffset + p, o.byteOffset + p + 8 * nE));
  p += 8 * nE;
  const nP = dv.getUint32(p, true);
  p += 4;
  if (p + 6 * nP > o.length) return null;
  const sizes = new Uint32Array(nP);
  const mats = new Uint16Array(nP);
  for (let i = 0; i < nP; i++, p += 6) {
    sizes[i] = dv.getUint32(p, true);
    mats[i] = dv.getUint16(p + 4, true);
  }
  const nC = dv.getUint32(p, true);
  p += 4;
  if (p + 4 * nC > o.length) return null;
  // The polygons' corners add up to the corner list, or this is not a mesh read right.
  let sum = 0;
  for (let i = 0; i < nP; i++) sum += sizes[i];
  if (sum !== nC) return null;
  const corners = new Int32Array(o.buffer.slice(o.byteOffset + p, o.byteOffset + p + 4 * nC));
  return { pos, edges, sizes, mats, corners };
}

/** A polygon (points) as triangles, in its own plane; earcut on the plane its normal is most across. */
function triangulate(pts) {
  if (pts.length === 3) return [0, 1, 2];
  let nx = 0;
  let ny = 0;
  let nz = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const c = pts[(i + 1) % pts.length];
    nx += (a[1] - c[1]) * (a[2] + c[2]);
    ny += (a[2] - c[2]) * (a[0] + c[0]);
    nz += (a[0] - c[0]) * (a[1] + c[1]);
  }
  const ax = Math.abs(nx);
  const ay = Math.abs(ny);
  const az = Math.abs(nz);
  const [u, v] = az >= ax && az >= ay ? [0, 1] : ax >= ay ? [1, 2] : [2, 0];
  const flat = [];
  for (const q of pts) flat.push(q[u], q[v]);
  const t = earcut(flat);
  return t.length ? t : pts.slice(2).flatMap((_, i) => [0, i + 1, i + 2]);
}

const normalOf = (pts) => {
  let n = [0, 0, 0];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const c = pts[(i + 1) % pts.length];
    n = [n[0] + (a[1] - c[1]) * (a[2] + c[2]), n[1] + (a[2] - c[2]) * (a[0] + c[0]), n[2] + (a[0] - c[0]) * (a[1] + c[1])];
  }
  const l = Math.hypot(...n) || 1;
  return n.map((x) => x / l);
};

/** The 3D of a part's 'mpcu' section, placed and in metres; null when it is not one this reads. */
export function modelPortGeometry(section, { edgeAngle = 30, maxTriangles = 1500000 } = {}) {
  const b = section instanceof Uint8Array ? section : new Uint8Array(section);
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  if (b.length < 64) return null;
  const nodes = sceneNodes(b, dv);
  const groups = new Map();
  const cosEdge = Math.cos((edgeAngle * Math.PI) / 180);
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  let triangles = 0;
  let blocks = 0;
  let prevEnd = 0;
  for (let i = 9; i + 5 <= b.length; i++) {
    // A geometry block: 04, its length (u64), then LZMA properties 5d and a dictionary size.
    if (b[i] !== 0x5d || b[i - 9] !== 4 || b[i + 1] !== 0 || b[i + 2] !== 0 || b[i + 4] !== 0 || b[i + 3] < 1 || b[i + 3] > 0x40) continue;
    const len = Number(dv.getBigUint64(i - 8, true));
    if (len < 13 || i + len > b.length) continue;
    let mesh = null;
    try {
      mesh = readMesh(lzmaDecode(b.subarray(0, i + len), i));
    } catch {
      mesh = null;
    }
    if (!mesh) continue;
    blocks++;
    const owner = nodes.filter((n) => n.at < i).pop();
    const M = owner?.world || IDENTITY;
    const refs = materialRefs(b, Math.max(prevEnd, owner?.at || 0), i);
    prevEnd = i + len;
    const nv = mesh.pos.length / 3;
    const P = new Float64Array(nv * 3);
    for (let v = 0; v < nv; v++) {
      const q = apply(M, mesh.pos[3 * v], mesh.pos[3 * v + 1], mesh.pos[3 * v + 2]);
      for (let k = 0; k < 3; k++) {
        P[3 * v + k] = q[k] * INCH;
        if (P[3 * v + k] < min[k]) min[k] = P[3 * v + k];
        if (P[3 * v + k] > max[k]) max[k] = P[3 * v + k];
      }
    }
    const pt = (v) => [P[3 * v], P[3 * v + 1], P[3 * v + 2]];
    // Polygons as vertex loops; each edge's polygons, for which edges to draw.
    const edgeFaces = new Map();
    const loops = [];
    let k = 0;
    for (let f = 0; f < mesh.sizes.length; f++) {
      const loop = [];
      for (let c = 0; c < mesh.sizes[f]; c++) {
        const ref = mesh.corners[k++];
        const e = Math.abs(ref) - 1;
        if (e < 0 || 2 * e + 1 >= mesh.edges.length) continue;
        loop.push(ref > 0 ? mesh.edges[2 * e] : mesh.edges[2 * e + 1]);
        if (!edgeFaces.has(e)) edgeFaces.set(e, []);
        edgeFaces.get(e).push(f);
      }
      loops.push(loop.filter((v) => v >= 0 && v < nv));
    }
    const normals = loops.map((l) => (l.length >= 3 ? normalOf(l.map(pt)) : [0, 0, 1]));
    for (let f = 0; f < loops.length; f++) {
      const loop = loops[f];
      if (loop.length < 3) continue;
      const m = mesh.mats[f];
      const key = `${blocks}:${m}`;
      if (!groups.has(key)) {
        const mat = refs[m] ? materialOf(b, dv, refs[m]) : null;
        groups.set(key, { name: mat?.name || null, color: mat?.color || [0.7, 0.7, 0.7], tris: [], edges: [] });
      }
      const g = groups.get(key);
      const pts = loop.map(pt);
      const t = triangulate(pts);
      triangles += t.length / 3;
      if (triangles > maxTriangles) return null;
      for (const ix of t) g.tris.push(...pts[ix]);
    }
    // Edges between polygons that turn, and open ones; drawn with the first polygon's group.
    for (const [e, fs] of edgeFaces) {
      const draw = fs.length === 1 || fs.some((f) => normals[f][0] * normals[fs[0]][0] + normals[f][1] * normals[fs[0]][1] + normals[f][2] * normals[fs[0]][2] < cosEdge);
      if (!draw) continue;
      const g = groups.get(`${blocks}:${mesh.mats[fs[0]]}`);
      if (g) g.edges.push(...pt(mesh.edges[2 * e]), ...pt(mesh.edges[2 * e + 1]));
    }
  }
  if (!blocks) return null;
  // Groups of one colour together.
  const byColor = new Map();
  for (const g of groups.values()) {
    const key = g.color.map((v) => Math.round(v * 255)).join(',');
    if (!byColor.has(key)) byColor.set(key, { name: g.name, color: g.color, tris: [], edges: [] });
    const h = byColor.get(key);
    for (const v of g.tris) h.tris.push(v);
    for (const v of g.edges) h.edges.push(v);
  }
  return { groups: [...byColor.values()].filter((g) => g.tris.length), min, max, blocks, triangles };
}

/** A body for GDL's BINARY: 'BDMP', triangle count, triangles (float32 x, y, z), edge count, edges. */
export function meshBinary(tris, edges) {
  const nt = tris.length / 9;
  const ne = edges.length / 6;
  const buf = new ArrayBuffer(12 + 4 * (tris.length + edges.length));
  const dv = new DataView(buf);
  dv.setUint32(0, 0x504d4442, true); // BDMP
  dv.setUint32(4, nt, true);
  const f = new Float32Array(buf, 12, tris.length + edges.length);
  f.set(tris, 0);
  dv.setUint32(8, ne, true);
  f.set(edges, tris.length);
  return new Uint8Array(buf);
}

/** Bodies (as read3DBinary gives them) of a 'BDMP' block: one body with its triangles and edges. */
export function readMeshBinary(bytes) {
  if (bytes.length < 12) return null;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (dv.getUint32(0, true) !== 0x504d4442) return null;
  const nt = dv.getUint32(4, true);
  const ne = dv.getUint32(8, true);
  const f = new Float32Array(bytes.buffer.slice(bytes.byteOffset + 12, bytes.byteOffset + 12 + 4 * (9 * nt + 6 * ne)));
  const polys = [];
  for (let t = 0; t < nt; t++) polys.push([[f[9 * t], f[9 * t + 1], f[9 * t + 2]], [f[9 * t + 3], f[9 * t + 4], f[9 * t + 5]], [f[9 * t + 6], f[9 * t + 7], f[9 * t + 8]]]);
  const edges = [];
  for (let e = 0, o = 9 * nt; e < ne; e++, o += 6) edges.push([[f[o], f[o + 1], f[o + 2]], [f[o + 3], f[o + 4], f[o + 5]]]);
  return [{ polys, edges }];
}
