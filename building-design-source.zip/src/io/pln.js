/**
 * Archicad project files (.pln), read for interoperability (experimental). Only what the file itself shows is read: no
 * Graphisoft code or data is part of this app.
 *
 * The file is an object store: a 32-byte header ("ROF " "FDB "), then blocks ("BL", a size in 16-byte units, a type, a
 * version) holding tables of contents and objects. A table of contents lists entries of 30 bytes (type, position in
 * units, size, a 16-byte id); an entry of type 0xFF78 is a group with its own table, often compressed (a 16-byte sign,
 * the total size, the number of pieces, then each piece's length and its data compressed with QuickLZ level 1). An
 * object's data may be stored plain, with zero bytes left out (a mask byte before every 8), or QuickLZ compressed.
 *
 * Each object starts with the id of its class; the id in the table is the element's own GUID. The elements read here
 * keep their fields in a fixed order for the class versions Archicad 30 writes, which is checked before reading: a
 * class written in another version is counted as skipped, not guessed at. Polygons (slabs, zones) are found by their
 * bounding box followed by the vertices that fill it exactly, which does not depend on what comes before them.
 */
import earcut from 'earcut';

const BLOCK_SIGN = 0x4c42; // "BL"
const GROUP_SIGN = '79a8a99645b44af3983833c33a061b06';

/** A GUID as text from 16 stored bytes (the first three fields little-endian). */
export function guidAt(b, o = 0) {
  const h = (i) => b[o + i].toString(16).padStart(2, '0');
  const r = (...ix) => ix.map(h).join('');
  return `${r(3, 2, 1, 0)}-${r(5, 4)}-${r(7, 6)}-${r(8, 9)}-${r(10, 11, 12, 13, 14, 15)}`.toUpperCase();
}

const hexOf = (b, o, n) => Array.from(b.subarray(o, o + n), (x) => x.toString(16).padStart(2, '0')).join('');

/** QuickLZ 1.5, level 1: one compressed piece at off (header 3 or 9 bytes) → its bytes. */
export function quickLZ(src, off = 0) {
  const dv = new DataView(src.buffer, src.byteOffset, src.byteLength);
  const flags = src[off];
  const long = flags & 2;
  const head = long ? 9 : 3;
  const size = long ? dv.getUint32(off + 5, true) : src[off + 2];
  if (!(flags & 1)) return src.slice(off + head, off + head + size);
  const out = new Uint8Array(size);
  // Where each 3-byte prefix was last seen, by a 12-bit hash of the prefix.
  const seen = new Int32Array(4096).fill(-1);
  const hash = (p) => ((out[p] | ((out[p + 1] & 15) << 8)) ^ (((out[p + 1] << 8) | (out[p + 2] << 16)) >>> 12)) & 0xfff;
  let s = off + head;
  let d = 0;
  let hashed = -1;
  let control = 1;
  for (;;) {
    if (control === 1) {
      control = dv.getUint32(s, true);
      s += 4;
    }
    if (control & 1) {
      // A match: a 12-bit hash of where it was, the length in 4 bits or a byte of its own.
      const tok = src[s] | (src[s + 1] << 8) | (src[s + 2] << 16);
      const from = seen[(tok >> 4) & 0xfff];
      let n;
      if (tok & 15) {
        n = (tok & 15) + 2;
        s += 2;
      } else {
        n = (tok >> 16) & 255;
        s += 3;
      }
      if (from < 0) throw new Error('This project file is damaged (a compressed block refers to nothing).');
      const start = d;
      for (let i = 0; i < n; i++) out[d + i] = out[from + i];
      d += n;
      for (let p = hashed + 1; p <= start; p++) seen[hash(p)] = p;
      hashed = d - 1;
      control >>>= 1;
    } else if (d < size - 11) {
      // Literals: 1 to 4 of them, as many as the control bits that follow say.
      const n = LITERALS[(control & 0xe) >>> 1];
      for (let i = 0; i < 4; i++) out[d + i] = src[s + i];
      control >>>= n;
      d += n;
      s += n;
      while (hashed < d - 3) {
        hashed++;
        seen[hash(hashed)] = hashed;
      }
    } else {
      // The last bytes are literals, with control words still between them.
      while (d < size) {
        if (control === 1) {
          s += 4;
          control = 0x40000000;
        } else control >>>= 1;
        out[d++] = src[s++];
      }
      return out;
    }
  }
}
const LITERALS = [4, 1, 2, 1, 3, 1, 2, 1];

/** A run of QuickLZ pieces of csize bytes in all → the joined bytes. */
function quickLZPieces(src, off, csize) {
  const dv = new DataView(src.buffer, src.byteOffset, src.byteLength);
  const parts = [];
  let p = off;
  while (p < off + csize) {
    const n = src[p] & 2 ? dv.getUint32(p + 1, true) : src[p + 1];
    if (!n) throw new Error('This project file is damaged (an empty compressed piece).');
    parts.push(quickLZ(src, p));
    p += n;
  }
  return join(parts);
}

function join(parts) {
  const out = new Uint8Array(parts.reduce((a, x) => a + x.length, 0));
  let o = 0;
  for (const x of parts) (out.set(x, o), (o += x.length));
  return out;
}

/** One block at p: { units, type, id, data } or null when no block starts there; free blocks have no data. */
function readBlock(b, p) {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  if (p + 11 > b.length || dv.getUint16(p, true) !== BLOCK_SIGN) return null;
  const blk = { units: dv.getUint32(p + 2, true), type: dv.getUint16(p + 6, true) };
  let q = p + 9;
  const flags = dv.getUint16(q, true);
  q += 2;
  if ((flags & 0xc0c0) !== 0x8080) return { ...blk, free: true };
  if (flags & 0x20) {
    blk.id = hexOf(b, q, 16);
    q += 16;
  }
  let stored;
  if ((flags & 0x1f) < 7) {
    stored = dv.getUint16(q, true);
    q += 2;
  } else {
    stored = dv.getUint32(q, true);
    q += 4;
  }
  let size = stored;
  const zeros = flags & 0x100;
  const qlz = flags & 0x200;
  if (zeros || qlz) {
    size = dv.getUint32(q, true);
    q += 4;
  }
  if (flags & 0x400) q += 4; // checksum, not checked
  if (!zeros && !qlz) blk.data = b.subarray(q, q + size);
  else if (zeros) {
    const out = new Uint8Array(size);
    let s = q;
    for (let d = 0; d < size && s < q + stored; ) {
      const mask = b[s++];
      for (let bit = 0; bit < 8 && d < size; bit++, d++) if (mask & (1 << bit)) out[d] = b[s++];
    }
    blk.data = out;
  } else blk.data = quickLZPieces(b, q, stored);
  return blk;
}

function tableOf(data) {
  const dv = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const entries = [];
  for (let q = 40; q + 30 <= data.length; q += 30) entries.push({ type: dv.getUint16(q, true), pos: Number(dv.getBigUint64(q + 2, true)), id: hexOf(data, q + 14, 16) });
  return entries;
}

/** Every object of a .pln: [{ id: element GUID, cls: class GUID, data }]. */
export function plnObjects(bytes) {
  const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  if (b.length < 64 || dv.getUint32(0, true) !== 0x20464f52 || dv.getUint32(4, true) !== 0x20424446) throw new Error('This is not an Archicad project file (.pln).');
  const main = readBlock(b, 0x20);
  if (!main?.data) throw new Error('This project file has no contents table.');
  const metaUnits = new DataView(main.data.buffer, main.data.byteOffset, main.data.byteLength).getUint32(0, true);
  const tables = new Map();
  let root = null;
  for (let p = 0x20, u = 0; u < metaUnits; ) {
    const blk = readBlock(b, p);
    if (!blk || !blk.units) throw new Error('This project file is damaged (its contents table cannot be read).');
    if (blk.type === 0xfdea || blk.type === 0xfdeb) {
      const t = { id: blk.id, entries: tableOf(blk.data) };
      tables.set(blk.id, t);
      if (blk.type === 0xfdeb) root = t;
    }
    u += blk.units;
    p += blk.units * 16;
  }
  if (!root) throw new Error('This project file has no root table.');
  const base = 0x20 + metaUnits * 16;
  const out = [];
  const visit = (table, buf, at, depth) => {
    if (depth > 8) return;
    for (const e of table.entries) {
      if (e.type === 0xffde) continue;
      const p = at + e.pos * 16;
      if (e.type === 0xff78) {
        const sub = tables.get(e.id);
        if (!sub || p + 32 > buf.length) continue;
        if (hexOf(buf, p, 16) === GROUP_SIGN) {
          const gdv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
          const n = Number(gdv.getBigUint64(p + 24, true));
          let q = p + 32;
          const parts = [];
          for (let i = 0; i < n; i++) {
            const len = gdv.getUint32(q, true);
            q += 4;
            parts.push(quickLZ(buf, q));
            q += len;
          }
          visit(sub, join(parts), 0, depth + 1);
        } else visit(sub, buf, p, depth + 1);
      } else if (e.type < 0xff78) {
        const blk = readBlock(buf, p);
        if (blk?.data && blk.data.length >= 16) out.push({ id: guidOfHex(e.id), cls: guidAt(blk.data, 0), data: blk.data });
      }
    }
  };
  visit(root, b, base, 0);
  return out;
}

const guidOfHex = (h) => guidAt(Uint8Array.from(h.match(/../g), (x) => parseInt(x, 16)));

/** The classes read, by their id, and the version of each that Archicad 30 writes. */
export const PLN_CLASSES = {
  '4F654582-33AF-4E52-ABFC-C35D46765EC4': { kind: 'wall', version: 17 },
  '945C1275-7948-41D4-8744-9D22D72CA486': { kind: 'slab', version: 13 },
  '3AD0332E-EFE2-491A-92A6-5B14BFDD7229': { kind: 'zone', version: 11 },
  'D8F07689-9CFA-4FBE-AEB4-0A60B8E667EE': { kind: 'door', version: 3 },
  '93F161A0-4C4E-4DF7-A100-4FD0E8C4F1E1': { kind: 'window', version: 3 },
  'DBEFCEC3-1BBF-4867-B8B3-C4F7C859DF61': { kind: 'object', version: 7 },
  '13E8EB85-5A33-47A3-A4D4-1E05296AEC7E': { kind: 'column', version: 15 },
  'A5C2D285-5A7C-4A68-9554-9EDA9D4556CA': { kind: 'beam', version: 13 },
  '9D4C7621-51E9-4523-A3BA-F2121777BCBE': { kind: 'roof', version: 10 },
  '8F2FEE46-6A3F-41AC-A32B-69E44DC6276D': { kind: 'mesh', version: 10 },
  'C653C817-A855-4446-AEF4-24EFB46271AA': { kind: 'curtain', version: 10 },
  '4C5AE61A-AF17-4B85-93E0-005C987D5F5B': { kind: 'railing', version: 3 },
  'E6363C7B-940E-4DEB-AF95-8B3B39E86BD2': { kind: 'morph', version: 10 },
};
/** A morph's body: vertices, then edges with the two faces each one parts. */
const MORPH_BODY = 'F1588CAD-2558-495C-820B-F3BCF4651007';
/** Curtain wall segments (a line and a height each), railing paths (in the railing's current state) and segments. */
const CW_SEGMENT = '56E6A742-89F9-4A08-A470-434D1D202DB9';
const RAILING_STATE = '22FBD570-5494-4706-A3DC-818BA797DC96';
const RAILING_SEGMENT = '29F59599-F972-44F7-AF1D-1F24770725C3';
// Before each node's x, y, z in a railing's state.
const RAILING_NODE = [1, 1, 0x55, 0, 0, 0, 1, 1, 0x4f, 0, 0, 0];
const PATTERN_LOGIC = ['fixed', 'best'];
const PATTERN_ORIGIN = ['start', 'startCenter', 'alignCenter', 'end'];

/**
 * The grid patterns of a curtain wall segment, along it (primary) then up it (secondary). Each is a block
 * 01 01, u32 length, then u32 logic (0 fixed sizes, 1 best division), u16 1, u32 n, n doubles (sizes in m),
 * u16 1, u32 m, m u32 flexible indices, ..., and the origin as the last u32 of the block.
 */
export function cwPatterns(b) {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  const found = [];
  for (let p = 0; p + 22 <= b.length && found.length < 2; p++) {
    if (b[p] !== 1 || b[p + 1] !== 1) continue;
    const len = dv.getUint32(p + 2, true);
    const logic = dv.getUint32(p + 6, true);
    const n = dv.getUint32(p + 12, true);
    const end = p + 6 + len;
    if (logic > 1 || dv.getUint16(p + 10, true) !== 1 || n < 1 || n > 256 || end > b.length || 16 + 8 * n + 6 > len + 6) continue;
    const sizes = Array.from({ length: n }, (_, k) => dv.getFloat64(p + 16 + 8 * k, true));
    if (!sizes.every((x) => x > 1e-4 && x < 1000)) continue;
    const k = p + 16 + 8 * n;
    const m = dv.getUint32(k + 2, true);
    if (dv.getUint16(k, true) !== 1 || m > n || k + 6 + 4 * m > end - 4) continue;
    const flexible = Array.from({ length: m }, (_, i) => dv.getUint32(k + 6 + 4 * i, true));
    const origin = dv.getUint32(end - 4, true);
    if (flexible.some((i) => i >= n) || origin > 3) continue;
    found.push({ sizes: sizes.map((x) => Math.round(x * 1e6) / 1e3), logic: PATTERN_LOGIC[logic], origin: PATTERN_ORIGIN[origin], flexible });
    p = end - 1;
  }
  return found;
}

/** Columns and beams keep their section in segments, each with a shape: rectangular (width, height) or round. */
const SEGMENTS = new Set(['7A1A82AB-69CD-40E6-A7D8-76564F981CF9', 'CBAB7BC6-E03A-4133-9161-C28ED3368672']);
const SHAPES = { 'C4191955-87C6-4FB6-B074-5F094FE9F6A6': 'rect', 'D6C12939-D905-40E0-AA57-F7C8D687DC7B': 'round' };
/** Other element classes, counted in what was not read. */
const OTHER = {};
const STAIR = 'FA0F7F15-29B4-4905-80FA-C6769109847B';
const STORIES = '2FA7B8CB-EE33-48D6-8DAA-8A3FE02BDDEA';
const STORY_VIEW = '25B6AC67-592B-4870-912D-3FD0D55006C9';
const LIB_PART = '2BFCA33D-BD38-49E3-BF6D-52AC8B850B9F';

/**
 * A contour with its arcs drawn as short straight pieces (5 degrees at most): arcs [{ edge, angle }] on the edge from
 * corner `edge` to the next, the angle counterclockwise positive. Corners may carry a third value (a height), which
 * the arc's points take in proportion.
 */
export function withArcs(contour, arcs) {
  if (!arcs.length) return contour;
  const out = [];
  const m = contour.length;
  for (let i = 0; i < m; i++) {
    const p = contour[i];
    const q = contour[(i + 1) % m];
    out.push(p);
    const a = arcs.find((x) => x.edge === i);
    if (!a || Math.abs(a.angle) < 1e-6) continue;
    const dx = q[0] - p[0];
    const dy = q[1] - p[1];
    const chord = Math.hypot(dx, dy);
    if (chord < 1e-9) continue;
    const s = a.angle;
    const r = chord / (2 * Math.sin(Math.abs(s) / 2));
    const nrm = [-dy / chord, dx / chord];
    const h = Math.sign(s) * r * Math.cos(s / 2);
    const c = [(p[0] + q[0]) / 2 + nrm[0] * h, (p[1] + q[1]) / 2 + nrm[1] * h];
    const t0 = Math.atan2(p[1] - c[1], p[0] - c[0]);
    const steps = Math.max(2, Math.ceil(Math.abs(s) / (Math.PI / 36)));
    for (let k = 1; k < steps; k++) {
      const t = t0 + (s * k) / steps;
      const pt = [c[0] + r * Math.cos(t), c[1] + r * Math.sin(t)];
      if (p.length > 2) pt.push(p[2] + ((q[2] - p[2]) * k) / steps);
      out.push(pt);
    }
  }
  return out;
}

export class Reader {
  constructor(data) {
    this.b = data;
    this.dv = new DataView(data.buffer, data.byteOffset, data.byteLength);
  }
  ok(o, n) {
    return o >= 0 && o + n <= this.b.length;
  }
  f64(o) {
    return this.ok(o, 8) ? this.dv.getFloat64(o, true) : NaN;
  }
  u32(o) {
    return this.ok(o, 4) ? this.dv.getUint32(o, true) : 0;
  }
  i32(o) {
    return this.ok(o, 4) ? this.dv.getInt32(o, true) : 0;
  }
  i16(o) {
    return this.ok(o, 2) ? this.dv.getInt16(o, true) : 0;
  }
  u16(o) {
    return this.ok(o, 2) ? this.dv.getUint16(o, true) : 0;
  }
  /** A string stored as a u32 count and UTF-16 characters; null when what is there is not one. */
  str(o, max = 256) {
    const n = this.u32(o);
    if (n > max || !this.ok(o + 4, 2 * n)) return null;
    let s = '';
    for (let i = 0; i < n; i++) s += String.fromCharCode(this.dv.getUint16(o + 4 + 2 * i, true));
    return s;
  }
  /** The element's story: after the header's marker (0, 6..8, 1, 0), a class code, then the story. */
  story(from = 190, to = 240) {
    for (let i = from; i < to; i++) {
      if (this.b[i] !== 0 || this.b[i + 1] < 6 || this.b[i + 1] > 8 || this.b[i + 2] !== 1 || this.b[i + 3] !== 0) continue;
      if (this.u32(i + 4) < 256 && this.u32(i + 12) === 1 && Math.abs(this.i32(i + 8)) < 1000) return this.i32(i + 8);
    }
    return null;
  }
  /** A polygon: its bounding box, then (32 bytes on) the vertex count, contour count, and the vertices. */
  polygon(from = 0) {
    const b = this.b;
    for (let i = from; i + 76 < b.length; i++) {
      const n = this.u32(i + 32);
      const nc = this.u32(i + 40);
      if (n < 3 || n > 100000 || nc < 1 || nc > n || !this.ok(i + 60, 16 * n + 4 * (nc + 2))) continue;
      const box = [this.f64(i), this.f64(i + 8), this.f64(i + 16), this.f64(i + 24)];
      if (!box.every(Number.isFinite) || !(box[2] > box[0] && box[3] > box[1])) continue;
      const pts = [];
      let lo = [Infinity, Infinity];
      let hi = [-Infinity, -Infinity];
      for (let k = 0; k < n; k++) {
        const p = [this.f64(i + 60 + 16 * k), this.f64(i + 68 + 16 * k)];
        pts.push(p);
        lo = [Math.min(lo[0], p[0]), Math.min(lo[1], p[1])];
        hi = [Math.max(hi[0], p[0]), Math.max(hi[1], p[1])];
      }
      // The box is the vertices' own, or larger where arcs bulge past them.
      const na = this.u32(i + 36);
      if (na > n) continue;
      if (na ? lo[0] < box[0] - 1e-6 || lo[1] < box[1] - 1e-6 || hi[0] > box[2] + 1e-6 || hi[1] > box[3] + 1e-6 : Math.abs(lo[0] - box[0]) + Math.abs(lo[1] - box[1]) + Math.abs(hi[0] - box[2]) + Math.abs(hi[1] - box[3]) > 1e-6) continue;
      // After the vertices, the arcs (with arcs only): records of the first and last vertex (counted from 1 over all
      // the contours) and the angle (radians, counterclockwise positive), after an empty record. Then the contour
      // ends, after a leading 0: each contour repeats its first point at its end.
      const e0 = i + 60 + 16 * n;
      const a0 = na ? 16 * (na + 1) : 0;
      if (!this.ok(e0, a0 + 4 * (nc + 1))) continue;
      const arcList = [];
      for (let k = 1; k <= na; k++) arcList.push({ from: this.i32(e0 + 16 * k), to: this.i32(e0 + 16 * k + 4), angle: this.f64(e0 + 16 * k + 8) });
      if (arcList.some((a) => !(a.from >= 1 && a.to >= 1 && a.from <= n && a.to <= n) || !Number.isFinite(a.angle))) continue;
      const ends = [];
      for (let k = 1; k <= nc; k++) ends.push(this.u32(e0 + a0 + 4 * k));
      if (ends.at(-1) !== n || ends.some((x, k) => x <= (ends[k - 1] || 0))) continue;
      const contours = ends.map((end, k) => pts.slice(k ? ends[k - 1] : 0, end)).map((c) => (c.length > 3 && same(c[0], c.at(-1)) ? c.slice(0, -1) : c));
      // Each arc on its contour: { contour, edge (the index of its first corner) , angle }.
      const arcs = [];
      for (const a of arcList) {
        const k = ends.findIndex((e) => a.from <= e);
        const start = k ? ends[k - 1] + 1 : 1;
        const m = contours[k].length;
        arcs.push({ contour: k, edge: (a.from - start) % m, angle: a.angle });
      }
      return { at: i, end: e0 + a0 + 4 * (nc + 1), box, contours, arcs, curved: contours.map((c, k) => withArcs(c, arcs.filter((a) => a.contour === k))) };
    }
    return null;
  }
  /** The 3D box written after a polygon: its plan box again, then the bottom and top. */
  zRange(poly) {
    for (let i = poly.end; i + 48 <= this.b.length; i++) {
      if (Math.abs(this.f64(i) - poly.box[0]) > 1e-9 || Math.abs(this.f64(i + 8) - poly.box[1]) > 1e-9) continue;
      if (Math.abs(this.f64(i + 16) - poly.box[2]) > 1e-9 || Math.abs(this.f64(i + 24) - poly.box[3]) > 1e-9) continue;
      const [z0, z1] = [this.f64(i + 32), this.f64(i + 40)];
      if (Number.isFinite(z0) && Number.isFinite(z1) && z1 >= z0) return [z0, z1];
    }
    return null;
  }
  /** The GUIDs of the given set found inside this object. */
  refs(ids) {
    const out = [];
    for (let i = 16; i + 16 <= this.b.length; i++) {
      if (!this.b[i] && !this.b[i + 1] && !this.b[i + 2]) continue;
      const g = guidAt(this.b, i);
      if (ids.has(g)) out.push(g);
    }
    return out;
  }
}

const same = (a, b) => Math.abs(a[0] - b[0]) < 1e-9 && Math.abs(a[1] - b[1]) < 1e-9;
const mm = (v) => Math.round(v * 10000) / 10;

/**
 * What a .pln holds, in millimetres: { stories, walls, slabs, zones, doors, windows, objects, skipped, notes }.
 * Experimental: the classes Archicad 30 writes; anything else is counted, not read.
 */
export function readPln(bytes) {
  const objs = plnObjects(bytes);
  const out = { stories: [], walls: [], slabs: [], zones: [], doors: [], windows: [], objects: [], columns: [], beams: [], roofs: [], meshes: [], curtainWalls: [], railings: [], stairs: [], morphs: [], skipped: {}, notes: [] };
  const treads = [];
  const skip = (what) => (out.skipped[what] = (out.skipped[what] || 0) + 1);
  // Stories: elevation and name for each, in order; their numbers start from the lowest the story views name.
  const views = objs.filter((o) => o.cls === STORY_VIEW).map((o) => new Reader(o.data).i16(60));
  const st = objs.find((o) => o.cls === STORIES);
  if (st) {
    const r = new Reader(st.data);
    const recs = [];
    // Each record: elevation (double), 1 (u16), name; then the next record's id (u16), a flag (u8), 2 (u16).
    for (let p = 52; r.ok(p, 14) && recs.length < 1000; ) {
      const elevation = r.f64(p);
      const name = r.u16(p + 8) === 1 ? r.str(p + 10) : null;
      if (!Number.isFinite(elevation) || name == null) break;
      recs.push({ elevation: mm(elevation), name });
      p += 10 + 4 + 2 * name.length;
      if (r.u16(p + 3) !== 2) break;
      p += 5;
    }
    const first = views.length ? Math.min(...views) : 0;
    out.stories = recs.map((s, i) => ({ index: first + i, ...s }));
  }
  if (!out.stories.length) out.stories = [{ index: 0, elevation: 0, name: '' }];
  const libParts = new Map();
  for (const o of objs) {
    if (o.cls !== LIB_PART) continue;
    const r = new Reader(o.data);
    // File name, then the localised name and the package, as the first strings that read as text.
    const strs = [];
    for (let i = 16; i + 4 < o.data.length && strs.length < 3; i++) {
      const s = r.str(i, 200);
      if (s && s.length > 2 && /^[\x20-\x7e -ɏ]+$/.test(s)) (strs.push(s), (i += 3 + 2 * s.length));
    }
    if (strs.length) libParts.set(o.id, { file: strs[0], name: strs[0].replace(/\.gsm$/i, ''), local: strs[1] || null, pack: strs.find((s) => /\.libpack$/i.test(s)) || null });
  }
  const libIds = new Set(libParts.keys());
  const wallIds = new Set(objs.filter((o) => PLN_CLASSES[o.cls]?.kind === 'wall').map((o) => o.id));
  // Sections: shape → segment → column or beam, each found by the other's GUID inside it.
  const owners = new Set(objs.filter((o) => ['column', 'beam'].includes(PLN_CLASSES[o.cls]?.kind)).map((o) => o.id));
  const segIds = new Set(objs.filter((o) => SEGMENTS.has(o.cls)).map((o) => o.id));
  const segOwner = new Map();
  for (const o of objs) if (SEGMENTS.has(o.cls)) segOwner.set(o.id, new Reader(o.data).refs(owners)[0]);
  // Curtain wall segments and railing paths and heights, by the element they belong to.
  const idsOf = (kind) => new Set(objs.filter((o) => PLN_CLASSES[o.cls]?.kind === kind).map((o) => o.id));
  const cwIds = idsOf('curtain');
  const railIds = idsOf('railing');
  const cwSegs = new Map();
  const railPath = new Map();
  const railHeight = new Map();
  for (const o of objs) {
    if (o.cls === CW_SEGMENT) {
      const r = new Reader(o.data);
      const owner = r.refs(cwIds)[0];
      const a = [r.f64(256), r.f64(264)];
      const b = [r.f64(280), r.f64(288)];
      const [len, h] = [r.f64(360), r.f64(368)];
      if (owner && [...a, ...b].every(Number.isFinite) && len > 1e-3 && Math.abs(Math.hypot(b[0] - a[0], b[1] - a[1]) - len) < 1e-6 && h > 0 && h < 1000) {
        if (!cwSegs.has(owner)) cwSegs.set(owner, []);
        const [primary, secondary] = cwPatterns(o.data);
        cwSegs.get(owner).push({ a: a.map(mm), b: b.map(mm), height: mm(h), primary, secondary });
      }
    } else if (o.cls === RAILING_STATE) {
      const r = new Reader(o.data);
      const owner = r.refs(railIds)[0];
      const pts = [];
      for (let i = 16; i + 36 <= o.data.length; i++) {
        if (!RAILING_NODE.every((v, k) => o.data[i + k] === v)) continue;
        const p = [r.f64(i + 12), r.f64(i + 20), r.f64(i + 28)];
        if (p.every(Number.isFinite) && p.every((v) => Math.abs(v) < 1e5)) pts.push(p.map(mm));
        i += 35;
      }
      if (owner && pts.length >= 2 && !railPath.has(owner)) railPath.set(owner, pts);
    } else if (o.cls === RAILING_SEGMENT) {
      const r = new Reader(o.data);
      const owner = r.refs(railIds)[0];
      const h = r.f64(308);
      if (owner && h > 0.1 && h < 10 && !railHeight.has(owner)) railHeight.set(owner, mm(h));
    }
  }
  const morphIds = idsOf('morph');
  const bodies = new Map();
  for (const o of objs) {
    if (o.cls !== MORPH_BODY) continue;
    const r = new Reader(o.data);
    const owner = r.refs(morphIds)[0];
    const body = owner && morphBody(r);
    if (body) bodies.set(owner, body);
  }
  const section = new Map();
  for (const o of objs) {
    const shape = SHAPES[o.cls];
    if (!shape) continue;
    const r = new Reader(o.data);
    const owner = segOwner.get(r.refs(segIds)[0]);
    const [w, h] = [r.f64(91), r.f64(99)];
    if (owner && !section.has(owner) && w > 0 && w < 50 && h > 0 && h < 50) section.set(owner, { shape, width: mm(w), depth: mm(h) });
  }
  for (const o of objs) {
    const cls = PLN_CLASSES[o.cls];
    if (!cls) {
      if (OTHER[o.cls]) skip(OTHER[o.cls]);
      continue;
    }
    const r = new Reader(o.data);
    if (o.data[39] !== cls.version) {
      skip(`${cls.kind}s (another Archicad version)`);
      continue;
    }
    try {
      if (cls.kind === 'wall') {
        const id = r.str(240, 200);
        if (id == null) throw 0;
        const s = 244 + 2 * id.length;
        const a = [r.f64(s), r.f64(s + 8)];
        const b = [r.f64(s + 16), r.f64(s + 24)];
        const t = r.f64(s + 77);
        const tEnd = r.f64(s + 85);
        const height = r.f64(s + 153);
        const arc = r.f64(s + 117);
        const offset = r.f64(s + 243);
        if (![...a, ...b, t, height].every(Number.isFinite) || !(t > 0) || !(height > 0)) throw 0;
        out.walls.push({ guid: o.id, elementId: id, story: r.story() ?? r.i16(212), a: a.map(mm), b: b.map(mm), thickness: mm(t), thicknessEnd: Number.isFinite(tEnd) ? mm(tEnd) : mm(t), height: mm(height), arc: Number.isFinite(arc) && Math.abs(arc) > 1e-6 ? arc : 0, offset: Number.isFinite(offset) ? mm(offset) : mm(t / 2) });
      } else if (cls.kind === 'slab' || cls.kind === 'zone') {
        const poly = r.polygon(200);
        if (!poly) throw 0;
        const contours = poly.curved.map((c) => c.map((p) => p.map(mm)));
        const story = r.story();
        if (cls.kind === 'slab') {
          const z = r.zRange(poly);
          out.slabs.push({ guid: o.id, elementId: r.str(232, 200) || '', story, boundary: contours[0], holes: contours.slice(1), z: z && z.map(mm) });
        } else {
          const name = r.str(296, 200) || '';
          const number = r.str(302 + 2 * name.length, 64) || '';
          out.zones.push({ guid: o.id, story, name, number, boundary: contours[0], holes: contours.slice(1) });
        }
      } else if (cls.kind === 'door' || cls.kind === 'window') {
        const width = r.f64(253);
        const height = r.f64(261);
        const at = r.f64(383);
        // The sill's elevation from the project zero (the host's story is taken off when it is placed).
        const sill = r.f64(423);
        const host = r.refs(wallIds)[0];
        if (!host || !(width > 0.05 && width < 20) || !(height > 0.05 && height < 20) || !Number.isFinite(at)) throw 0;
        const part = libParts.get(r.refs(libIds)[0]) || null;
        out[cls.kind === 'door' ? 'doors' : 'windows'].push({ guid: o.id, host, width: mm(width), height: mm(height), t: mm(at), sillElevation: Number.isFinite(sill) && Math.abs(sill) < 10000 ? mm(sill) : null, part });
      } else if (cls.kind === 'column' || cls.kind === 'beam') {
        // The element ID, then the story 28 bytes before its count; the axis from the start of the data.
        const idAt = cls.kind === 'column' ? 780 : 784;
        const id = r.str(idAt, 200);
        if (id == null) throw 0;
        const story = r.i16(idAt - 28);
        const sec = section.get(o.id);
        if (!sec) {
          skip(`${cls.kind}s of a section not read`);
          continue;
        }
        if (cls.kind === 'column') {
          const base = [r.f64(237), r.f64(245), r.f64(253)];
          const top = [r.f64(261), r.f64(269), r.f64(277)];
          if (![...base, ...top].every(Number.isFinite) || !(top[2] > base[2])) throw 0;
          out.columns.push({ guid: o.id, elementId: id, story, at: [mm(base[0]), mm(base[1])], z: [mm(base[2]), mm(top[2])], ...sec });
        } else {
          const a = [r.f64(241), r.f64(249), r.f64(257)];
          const b = [r.f64(265), r.f64(273), r.f64(281)];
          if (![...a, ...b].every(Number.isFinite)) throw 0;
          out.beams.push({ guid: o.id, elementId: id, story, a: [mm(a[0]), mm(a[1])], b: [mm(b[0]), mm(b[1])], z: [mm(a[2]), mm(b[2])], ...sec });
        }
      } else if (cls.kind === 'roof') {
        // One plane: its outline, thickness, slope (degrees) and the pivot line it rises from, to its left.
        const poly = r.polygon(400);
        const t = r.f64(275);
        const slope = r.f64(483);
        const pa = [r.f64(491), r.f64(499)];
        const pb = [r.f64(507), r.f64(515)];
        if (!poly || !(t > 0 && t < 5) || !(slope > 0 && slope < 90) || ![...pa, ...pb].every(Number.isFinite)) throw 0;
        out.roofs.push({ guid: o.id, story: r.story(), boundary: poly.curved[0].map((p) => p.map(mm)), holes: poly.curved.slice(1).map((c) => c.map((p) => p.map(mm))), thickness: mm(t), slope, pivot: [pa.map(mm), pb.map(mm)] });
      } else if (cls.kind === 'mesh') {
        // The outline, then each corner's height followed by the number of the next corner.
        const poly = r.polygon(250);
        if (!poly) throw 0;
        const ring = poly.contours[0];
        const m = ring.length;
        let zs = null;
        for (let i = poly.end; i + 12 * m <= o.data.length && !zs; i++) {
          let ok = true;
          for (let k = 0; k < m && ok; k++) ok = r.u16(i + 12 * k + 8) === ((k + 1) % m) + 1 && Number.isFinite(r.f64(i + 12 * k)) && Math.abs(r.f64(i + 12 * k)) < 1e4;
          if (ok) zs = Array.from({ length: m }, (_, k) => r.f64(i + 12 * k));
        }
        if (!zs) throw 0;
        const box = r.zRange(poly);
        // The heights go with the corners, and along an arc in proportion.
        const corners = withArcs(ring.map((p, k) => [p[0], p[1], zs[k]]), poly.arcs.filter((a) => a.contour === 0));
        out.meshes.push({ guid: o.id, story: r.story(), boundary: corners.map((p) => p.map(mm)), bottom: box ? mm(box[0]) : null });
      } else if (cls.kind === 'curtain') {
        const segs = cwSegs.get(o.id);
        if (!segs?.length) throw 0;
        out.curtainWalls.push({ guid: o.id, story: r.story(), segments: segs });
      } else if (cls.kind === 'railing') {
        const path = railPath.get(o.id);
        if (!path) throw 0;
        out.railings.push({ guid: o.id, story: r.story(), path, height: railHeight.get(o.id) || 1100 });
      } else if (cls.kind === 'morph') {
        // Its body in its own coordinates, placed by a 3 x 4 matrix (rows of a rotation and a move).
        const body = bodies.get(o.id);
        if (!body) throw 0;
        const M = Array.from({ length: 12 }, (_, k) => r.f64(255 + 8 * k));
        if (!M.every(Number.isFinite)) throw 0;
        const place = (v) => [0, 1, 2].map((i) => mm(M[4 * i] * v[0] + M[4 * i + 1] * v[1] + M[4 * i + 2] * v[2] + M[4 * i + 3]));
        out.morphs.push({ guid: o.id, story: r.story(), tris: body.map((t) => t.map(place)) });
      } else if (cls.kind === 'object') {
        const id = r.str(251, 200);
        if (id == null) throw 0;
        const s = 255 + 2 * id.length;
        const at = [r.f64(s), r.f64(s + 8)];
        const angle = r.f64(s + 16);
        const z = r.f64(s + 24);
        const A = r.f64(s + 32);
        const B = r.f64(s + 40);
        if (!at.every(Number.isFinite)) throw 0;
        const part = libParts.get(r.refs(libIds)[0]) || null;
        // Markers and stamps of views and zones are Archicad's own annotations, placed with their views.
        if (part && /marker|stamp|revision history/i.test(part.name)) continue;
        // Parts of stairs, railings and curtain walls belong to those elements, not placed on their own.
        // A stair's treads are kept: the stair is rebuilt from them.
        if (part && /tread/i.test(part.name) && A > 0) {
          const p = { at: at.map(mm), angle, z: mm(z) };
          if (Math.hypot(p.at[0], p.at[1]) > 1 || Math.abs(p.z) > 1) treads.push(p);
        }
        if (part && (/^(Stair and Railing|Curtain Wall)\.libpack$/i.test(part.pack || '') || /^Built-?in (CW|Frame|Butt|Break|Tread|Riser|Post|Rail|Panel)/i.test(part.name))) {
          skip('parts of stairs, railings and curtain walls');
          continue;
        }
        out.objects.push({ guid: o.id, elementId: id, story: r.story(200, 250), at: at.map(mm), rotation: Number.isFinite(angle) && Math.abs(angle) < 100 ? (angle * 180) / Math.PI : 0, z: Number.isFinite(z) ? mm(z) : 0, width: A > 0 && A < 100 ? mm(A) : null, depth: B > 0 && B < 100 ? mm(B) : null, part });
      }
    } catch {
      skip(`${cls.kind}s not understood`);
    }
  }
  for (const o of objs) {
    if (o.cls !== STAIR) continue;
    const st = stairOf(new Reader(o.data), treads, (story) => out.stories.find((x) => x.index === story)?.elevation ?? 0);
    if (st) out.stairs.push({ guid: o.id, ...st });
    else skip('stairs not understood');
  }
  return out;
}

/**
 * A morph's body as triangles: its vertices (a count, then x, y, z), its edges (a count, then 24 bytes: the two vertices at
 * +8 and +12), then the faces' edges in order (signed by direction). Each face is triangulated in its plane, its own way
 * round; the whole is turned out if its volume comes out negative.
 */
export function morphBody(r) {
  const nv = r.u32(195);
  if (!(nv >= 3 && nv < 200000) || !r.ok(199, 24 * nv + 8)) return null;
  const V = Array.from({ length: nv }, (_, k) => [r.f64(199 + 24 * k), r.f64(207 + 24 * k), r.f64(215 + 24 * k)]);
  if (!V.every((v) => v.every(Number.isFinite))) return null;
  const e0 = 199 + 24 * nv + 4;
  const ne = r.u32(e0);
  if (!(ne >= 3 && ne < 600000) || !r.ok(e0 + 4, 24 * ne)) return null;
  const edges = [];
  for (let k = 0; k < ne; k++) {
    const [a, b] = [r.i32(e0 + 12 + 24 * k), r.i32(e0 + 16 + 24 * k)];
    if (a < 0 || b < 0 || a >= nv || b >= nv) return null;
    edges.push([a, b]);
  }
  // The faces' edges in order, 1-based, negative when an edge is run backwards: a loop closes where it began.
  const p0 = e0 + 4 + 24 * ne;
  const nref = r.u32(p0);
  if (!(nref >= 3 && nref <= 4 * ne) || !r.ok(p0 + 4, 4 * nref)) return null;
  // A 0 between two loops makes the next one a hole in the face before (as GDL's PGON writes them).
  const faces = [];
  let cur = [];
  let hole = false;
  for (let k = 0; k < nref; k++) {
    const ref = r.i32(p0 + 4 + 4 * k);
    if (!ref) {
      if (cur.length) return null;
      hole = true;
      continue;
    }
    const e = edges[Math.abs(ref) - 1];
    if (!e) return null;
    const [from, to] = ref > 0 ? e : [e[1], e[0]];
    cur.push(from);
    if (to === cur[0]) {
      if (hole && faces.length) faces.at(-1).holes.push(cur);
      else faces.push({ loop: cur, holes: [] });
      cur = [];
      hole = false;
    }
  }
  const tris = [];
  for (const { loop, holes } of faces) {
    {
      if (loop.length < 3) continue;
      // Newell's normal, then the loop in the plane across its largest component.
      const n = [0, 0, 0];
      loop.forEach((i, k) => {
        const p = V[i];
        const q = V[loop[(k + 1) % loop.length]];
        n[0] += (p[1] - q[1]) * (p[2] + q[2]);
        n[1] += (p[2] - q[2]) * (p[0] + q[0]);
        n[2] += (p[0] - q[0]) * (p[1] + q[1]);
      });
      const ax = n.map(Math.abs).indexOf(Math.max(...n.map(Math.abs)));
      const [u, w] = [[1, 2], [2, 0], [0, 1]][ax];
      const all = [...loop, ...holes.flat()];
      const starts = [];
      let at = loop.length;
      for (const h of holes) (starts.push(at), (at += h.length));
      const flat = all.flatMap((i) => [V[i][u], V[i][w]]);
      const ids = earcut(flat, starts, 2);
      for (let k = 0; k < ids.length; k += 3) {
        let t = [V[all[ids[k]]], V[all[ids[k + 1]]], V[all[ids[k + 2]]]];
        // The triangle the face's own way round.
        const c = [t[1][0] - t[0][0], t[1][1] - t[0][1], t[1][2] - t[0][2]];
        const d = [t[2][0] - t[0][0], t[2][1] - t[0][1], t[2][2] - t[0][2]];
        const tn = [c[1] * d[2] - c[2] * d[1], c[2] * d[0] - c[0] * d[2], c[0] * d[1] - c[1] * d[0]];
        if (tn[0] * n[0] + tn[1] * n[1] + tn[2] * n[2] < 0) t = [t[0], t[2], t[1]];
        tris.push(t);
      }
    }
  }
  if (!tris.length) return null;
  const vol = tris.reduce((s, [a, b, c]) => s + a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0]) + a[2] * (b[0] * c[1] - b[1] * c[0]), 0);
  return vol < 0 ? tris.map(([a, b, c]) => [a, c, b]) : tris;
}

/**
 * A stair: its start (the middle of the first riser line), width, rise, riser and tread from its placement (a point and a
 * rotation matrix, the sizes before it), then its flights from its treads, followed riser by riser from the start.
 */
function stairOf(r, treads, elevationOf) {
  const b = r.b;
  let t = -1;
  for (let i = 100; i + 96 <= b.length && t < 0; i++) {
    const m = Array.from({ length: 9 }, (_, k) => r.f64(i + 24 + 8 * k));
    if (!m.every((v) => Number.isFinite(v) && Math.abs(v) <= 1 + 1e-9)) continue;
    const col = (j) => [m[j], m[3 + j], m[6 + j]];
    const unit = [0, 1, 2].every((j) => Math.abs(Math.hypot(...col(j)) - 1) < 1e-6);
    const det = m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6]);
    const p = [r.f64(i), r.f64(i + 8), r.f64(i + 16)];
    const width = r.f64(i - 62);
    const height = r.f64(i - 54);
    if (unit && Math.abs(det - 1) < 1e-6 && p.every((v) => Number.isFinite(v) && Math.abs(v) < 1e5) && width > 0.3 && width < 10 && height > 0.1 && height < 100) t = i;
  }
  if (t < 0) return null;
  const start = [mm(r.f64(t)), mm(r.f64(t + 8))];
  const width = mm(r.f64(t - 62));
  const rise = mm(r.f64(t - 54));
  const riser = mm(r.f64(t - 29));
  const tread = mm(r.f64(t - 21));
  const story = r.story();
  // Each tread's centre on its front edge and its direction (its angle turns +y).
  const dirOf = (q) => [-Math.sin(q.angle), Math.cos(q.angle)];
  const centre = (q) => {
    const d = dirOf(q);
    return [q.at[0] - d[1] * (width / 2), q.at[1] + d[0] * (width / 2)];
  };
  const step = riser > 1 ? riser : rise / 18;
  const pool = treads.map((q) => ({ ...q, c: centre(q), d: dirOf(q) }));
  // The first tread: at the start, one riser up from the lowest it can be.
  const near = (q, p, lim) => Math.hypot(q.c[0] - p[0], q.c[1] - p[1]) < lim;
  const base = elevationOf(story);
  let cur = pool.filter((q) => near(q, start, Math.max(tread * 1.5, 400)) && Math.abs(q.z - base - step) < step * 0.5).sort((a, c) => a.z - c.z)[0];
  const chain = [];
  while (cur && chain.length < 200) {
    chain.push(cur);
    const prev = cur;
    cur = pool.filter((q) => !chain.includes(q) && Math.abs(q.z - prev.z - step) < step * 0.3 && near(q, prev.c, Math.max(width, tread) * 2.5)).sort((a, c) => Math.hypot(a.c[0] - prev.c[0], a.c[1] - prev.c[1]) - Math.hypot(c.c[0] - prev.c[0], c.c[1] - prev.c[1]))[0];
  }
  const flights = [];
  for (const q of chain) {
    const f = flights.at(-1);
    if (f && Math.abs(f.d[0] * q.d[0] + f.d[1] * q.d[1] - 1) < 1e-3) f.n++;
    else flights.push({ d: q.d, n: 1, at: q.c });
  }
  return { story, start, width, rise, riser: step, risers: Math.max(2, Math.round(rise / step)), tread, flights: flights.map((f) => ({ dir: f.d, treads: f.n, start: f.at })) };
}
