/**
 * Working together through a team server (scripts/teamwork.mjs): one's changes go up element by element, others' come in as
 * soon as they are sent, and reserved elements cannot be taken.
 */
import { localChanges } from '../core/sync.js';
import { upgradeDoc } from '../core/template.js';
import { Doc } from '../core/doc.js';

const SEND_AFTER = 1200;

export class TeamSession {
  constructor(app, { server, code, user }) {
    Object.assign(this, { app, server: String(server).replace(/\/+$/, ''), code, user });
    this.project = null;
    this.rev = 0;
    this.base = null;
    this.people = [];
    this.conflicts = [];
    this.busy = null;
    this.again = false;
    this.timer = 0;
    this.off = null;
    this.reader = null;
    this.closed = false;
    this.listeners = new Set();
  }

  get active() {
    return !!this.project && !this.closed;
  }

  notify() {
    for (const fn of this.listeners) fn();
  }

  async api(path, body) {
    const res = await fetch(`${this.server}/team/${path}`, {
      method: body ? 'POST' : 'GET',
      headers: { 'x-team-code': this.code, ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const out = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(out.error || `The team server answered ${res.status}`);
    return out;
  }

  check() {
    return this.api('ping');
  }

  projects() {
    return this.api('projects').then((r) => r.projects);
  }

  /** Puts the open project on the server, for others to join. */
  async publish(name) {
    const app = this.app;
    const created = await this.api('projects', { name, document: app.doc.toJSON() });
    this.attach({ id: created.id, name }, created.rev, new Map(app.doc.items));
    return created;
  }

  /** Opens a project of the server here. */
  async join(id) {
    const s = await this.api(`p/${id}/state`);
    const doc = upgradeDoc(Doc.fromJSON(s.document));
    const app = this.app;
    app.setDoc(doc, { name: s.name, source: 'team' });
    this.attach({ id, name: s.name }, s.rev, new Map(s.document.items.map((it) => [it.id, doc.items.get(it.id)])));
    return s;
  }

  attach(project, rev, base) {
    this.project = project;
    this.rev = rev;
    this.base = base;
    this.app.team = this;
    // Upgrading an older file adds items the server does not have yet: they count as changes and go up with the first send.
    this.off = this.app.doc.on((ev) => {
      if (ev.remote || ev.preview) return;
      this.state('pending');
      if (this.app.settings.autoSync !== false) this.sendSoon();
    });
    this.listen();
    this.state('synced');
  }

  state(s) {
    this.app.sync.setState(s);
    this.notify();
  }

  sendSoon() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.sendReceive().catch(() => {}), SEND_AFTER);
  }

  /** Follows what the server says while the project is open, and picks up where it left off after a break. */
  async listen() {
    while (this.active) {
      try {
        const res = await fetch(`${this.server}/team/p/${this.project.id}/events?user=${encodeURIComponent(this.user)}`, { headers: { 'x-team-code': this.code } });
        if (!res.ok) throw new Error('no stream');
        this.reader = res.body.getReader();
        const text = new TextDecoder();
        let buf = '';
        for (;;) {
          const { value, done } = await this.reader.read();
          if (done) break;
          buf += text.decode(value, { stream: true });
          let i;
          while ((i = buf.indexOf('\n\n')) >= 0) {
            const line = buf.slice(0, i);
            buf = buf.slice(i + 2);
            if (line.startsWith('data: ')) this.heard(JSON.parse(line.slice(6)));
          }
        }
      } catch {
        // The connection dropped: below, and try again.
      }
      if (!this.active) return;
      this.state('offline');
      await new Promise((r) => setTimeout(r, 2000));
      if (this.active) this.sendReceive().catch(() => {});
    }
  }

  heard(ev) {
    if (ev.people) {
      this.people = ev.people;
      this.notify();
    }
    if (ev.rev && ev.rev > this.rev) {
      if (this.app.settings.autoSync === false) this.state('pending');
      else this.sendReceive().catch(() => {});
    }
  }

  /** Sends what changed here and takes what changed elsewhere. */
  async sendReceive({ comment = '' } = {}) {
    if (!this.active) return null;
    if (this.busy) {
      this.again = true;
      return this.busy;
    }
    this.busy = this.exchange(comment);
    try {
      return await this.busy;
    } finally {
      this.busy = null;
      if (this.again) {
        this.again = false;
        this.sendReceive().catch(() => {});
      }
    }
  }

  async exchange(comment) {
    const app = this.app;
    const doc = app.doc;
    // Not in the middle of someone's edit: it is picked up when that ends.
    if (doc.inTransaction || app.tool?.busy) {
      this.sendSoon();
      return null;
    }
    const ids = localChanges(this.base, doc);
    this.state('syncing');
    let out;
    try {
      out = await this.api(`p/${this.project.id}/sync`, { base: this.rev, user: this.user, comment, changes: ids.map((id) => [id, doc.items.get(id) ?? null]) });
    } catch (err) {
      this.state('offline');
      throw err;
    }
    if (doc !== app.doc || !this.active) return null;
    // Edits made while the answer was on its way stay local and go up next time.
    const edited = new Set(localChanges(this.base, doc).filter((id) => {
      const sent = ids.includes(id);
      return !sent;
    }));
    for (const id of ids) this.base.set(id, doc.items.get(id));
    for (const id of ids) if (!doc.items.has(id)) this.base.delete(id);
    const refused = new Set([...out.rejected.map((r) => r.id), ...out.conflicts]);
    const take = out.incoming.filter(([id]) => !edited.has(id) || refused.has(id));
    if (take.length) doc.applyRemote(take, 'Changes from others');
    for (const [id, item] of take) {
      if (item) this.base.set(id, doc.items.get(id));
      else this.base.delete(id);
    }
    this.rev = out.rev;
    this.conflicts = [...out.conflicts, ...out.rejected.map((r) => r.id)];
    if (take.length) {
      const n = take.filter(([id]) => !refused.has(id)).length;
      if (n) app.setPrompt(`${n} change${n === 1 ? '' : 's'} from others. The model is up to date.`);
    }
    if (refused.size) app.toast?.(`${refused.size} of your changes could not go in: ${out.rejected.length ? `reserved by ${[...new Set(out.rejected.map((r) => r.by))].join(', ')}` : 'someone changed the same element first'}. You have their version.`, { kind: 'error' });
    this.state(localChanges(this.base, doc).length ? 'pending' : 'synced');
    return out;
  }

  /** Reserves elements (or frees them); the server decides, so two people cannot get the same one. */
  async reserve(ids, release = false) {
    const out = await this.api(`p/${this.project.id}/reserve`, { ids, user: this.user, release });
    await this.sendReceive();
    return out;
  }

  history() {
    return this.api(`p/${this.project.id}/history`).then((r) => r.log);
  }

  leave() {
    this.closed = true;
    clearTimeout(this.timer);
    this.off?.();
    this.reader?.cancel().catch(() => {});
    if (this.app.team === this) this.app.team = null;
    this.app.sync.setState('off');
  }
}
