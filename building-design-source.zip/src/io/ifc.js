/**
 * IFC export (STEP physical file) through a translator (core/ifctranslators.js):
 * IFC4 Reference View with tessellated geometry (IfcTriangulatedFaceSet) or
 * IFC2x3 Coordination View 2.0 with faceted B-rep geometry, in millimetres or
 * metres, with the translator's element filter and options. The spatial
 * structure is project, site, building and one storey per level, named as the
 * IFC Project Manager says; rooms become spaces with extruded outlines.
 */
import { MODEL_KINDS } from '../core/scene.js';
import { levelOf, levelElevation, openingSize, verticalExtent, wallAxis, wallLength, wallThickness } from '../core/model.js';
import { typeLabel, typeThickness } from '../core/catalog.js';
import { axisPoint } from '../core/walls.js';
import { trimmedBeam } from '../core/build3d.js';
import { classOf } from '../core/classify.js';
import { paramsForElement, paramValueOf } from '../core/params.js';
import { ifcGuidFor } from '../core/issues.js';
import { translatorFor, translatorIncludes, productLine } from '../core/ifctranslators.js';

const CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$';

export function ifcGuid() {
  let s = CHARS[Math.floor(Math.random() * 4)];
  for (let i = 1; i < 22; i++) s += CHARS[Math.floor(Math.random() * 64)];
  return s;
}

/** Encode text for a STEP string (ASCII with \X2\ escapes). */
export function stepString(s) {
  if (s == null) return '$';
  let out = '';
  for (const ch of String(s)) {
    const c = ch.codePointAt(0);
    if (ch === "'") out += "''";
    else if (ch === '\\') out += '\\\\';
    else if (c >= 32 && c < 127) out += ch;
    else out += `\\X2\\${c.toString(16).toUpperCase().padStart(4, '0')}\\X0\\`;
  }
  return `'${out}'`;
}

const num = (v) => {
  const r = Math.round(v * 1000) / 1000;
  const s = String(r);
  return s.includes('.') || s.includes('e') ? s : `${s}.`;
};

const ENTITY = {
  wall: (g, n, p, r, tag) => `IFCWALL('${g}',$,${n},$,$,${p},${r},${tag},.NOTDEFINED.)`,
  floor: (g, n, p, r, tag) => `IFCSLAB('${g}',$,${n},$,$,${p},${r},${tag},.FLOOR.)`,
  ceiling: (g, n, p, r, tag) => `IFCCOVERING('${g}',$,${n},$,$,${p},${r},${tag},.CEILING.)`,
  roof: (g, n, p, r, tag) => `IFCROOF('${g}',$,${n},$,$,${p},${r},${tag},.NOTDEFINED.)`,
  door: (g, n, p, r, tag, el, ctx) => `IFCDOOR('${g}',$,${n},$,$,${p},${r},${tag},${num(ctx.size(el).height)},${num(ctx.size(el).width)},.DOOR.,.NOTDEFINED.,$)`,
  window: (g, n, p, r, tag, el, ctx) => `IFCWINDOW('${g}',$,${n},$,$,${p},${r},${tag},${num(ctx.size(el).height)},${num(ctx.size(el).width)},.WINDOW.,.NOTDEFINED.,$)`,
  column: (g, n, p, r, tag) => `IFCCOLUMN('${g}',$,${n},$,$,${p},${r},${tag},.COLUMN.)`,
  beam: (g, n, p, r, tag) => `IFCBEAM('${g}',$,${n},$,$,${p},${r},${tag},.BEAM.)`,
  stair: (g, n, p, r, tag) => `IFCSTAIR('${g}',$,${n},$,$,${p},${r},${tag},.STRAIGHT_RUN_STAIR.)`,
  railing: (g, n, p, r, tag) => `IFCRAILING('${g}',$,${n},$,$,${p},${r},${tag},.HANDRAIL.)`,
  furniture: (g, n, p, r, tag) => `IFCFURNITURE('${g}',$,${n},$,$,${p},${r},${tag},.NOTDEFINED.)`,
  plumbing: (g, n, p, r, tag) => `IFCSANITARYTERMINAL('${g}',$,${n},$,$,${p},${r},${tag},.NOTDEFINED.)`,
  proxy: (g, n, p, r, tag) => `IFCBUILDINGELEMENTPROXY('${g}',$,${n},$,$,${p},${r},${tag},.NOTDEFINED.)`,
};

// IFC entities with the common attributes and a predefined type last, which a classification may choose.
const GENERIC = new Set(['IfcWall', 'IfcCurtainWall', 'IfcSlab', 'IfcRoof', 'IfcColumn', 'IfcBeam', 'IfcFooting', 'IfcStair', 'IfcRamp', 'IfcRailing', 'IfcCovering', 'IfcFurniture', 'IfcSanitaryTerminal', 'IfcElectricAppliance', 'IfcLightFixture', 'IfcGeographicElement', 'IfcDuctSegment', 'IfcPipeSegment', 'IfcCableCarrierSegment', 'IfcAirTerminal', 'IfcFireSuppressionTerminal', 'IfcUnitaryEquipment', 'IfcElectricDistributionBoard', 'IfcOutlet', 'IfcBuildingElementProxy']);

/**
 * The IFC entity an element is exported as, and its predefined type, by the same rules writeIFC follows:
 * { entity: 'IFCWALL', predefinedType: 'NOTDEFINED' } (null for elements that do not export).
 */
export function ifcEntityOf(doc, el, entityMap = null) {
  const k = el.kind;
  const forced = entityMap?.[k];
  if (forced && /^Ifc[A-Za-z]+$/.test(forced)) return { entity: forced.toUpperCase(), predefinedType: k === 'door' || k === 'window' ? k.toUpperCase() : 'NOTDEFINED' };
  const type = doc.get(el.typeId);
  let maker = ENTITY[k];
  if (k === 'component') maker = type?.category === 'plumbing' ? ENTITY.plumbing : type?.category === 'furniture' || type?.category === 'casework' ? ENTITY.furniture : ENTITY.proxy;
  if (k === 'room') return { entity: 'IFCSPACE', predefinedType: 'INTERNAL' };
  if (!maker && !MODEL_KINDS.includes(k)) return null;
  const system = doc.all('classSystem')[0];
  const cls = system ? classOf(doc, el, system) : null;
  if (cls?.ifc && GENERIC.has(cls.ifc) && k !== 'door' && k !== 'window') return { entity: cls.ifc.toUpperCase(), predefinedType: 'NOTDEFINED' };
  if (k === 'door' || k === 'window') return { entity: k === 'door' ? 'IFCDOOR' : 'IFCWINDOW', predefinedType: k.toUpperCase() };
  const line = (maker || ENTITY.proxy)('', '', '', '', '', el, { size: () => ({ width: 0, height: 0 }) });
  const m = /^(IFC[A-Z]+)\(/.exec(line);
  const pre = /\.([A-Z_]+)\.(?:,\$)?\)$/.exec(line);
  return { entity: m ? m[1] : 'IFCBUILDINGELEMENTPROXY', predefinedType: pre ? pre[1] : 'NOTDEFINED' };
}

/** Writes the file's data section in pieces through emit(text), so that a large model is never one string or one array. */
function ifcBody(app, translator, emit) {
  const doc = app.doc;
  const scene = app.scene;
  const t = translatorFor(doc, translator);
  const x3 = t.schema === 'IFC2X3';
  // Lengths in the translator's unit.
  const k = t.unit === 'm' ? 0.001 : 1;
  const L = (v) => num(v * k);
  const tree = doc.get('project')?.ifcProject || {};
  let lines = [];
  let id = 0;
  const add = (s) => {
    lines.push(`#${++id}=${s};`);
    if (lines.length >= 100000) {
      emit(`${lines.join('\n')}\n`);
      lines = [];
    }
    return `#${id}`;
  };
  const project = doc.project;
  const origin = add('IFCCARTESIANPOINT((0.,0.,0.))');
  const zAxis = add('IFCDIRECTION((0.,0.,1.))');
  const xAxis = add('IFCDIRECTION((1.,0.,0.))');
  const place = add(`IFCAXIS2PLACEMENT3D(${origin},${zAxis},${xAxis})`);
  const context = add(`IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,${place},$)`);
  const body = add(`IFCGEOMETRICREPRESENTATIONSUBCONTEXT('Body','Model',*,*,*,*,${context},$,.MODEL_VIEW.,$)`);
  const u1 = add(t.unit === 'm' ? 'IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.)' : 'IFCSIUNIT(*,.LENGTHUNIT.,.MILLI.,.METRE.)');
  const u2 = add('IFCSIUNIT(*,.AREAUNIT.,$,.SQUARE_METRE.)');
  const u3 = add('IFCSIUNIT(*,.VOLUMEUNIT.,$,.CUBIC_METRE.)');
  const u4 = add('IFCSIUNIT(*,.PLANEANGLEUNIT.,$,.RADIAN.)');
  const units = add(`IFCUNITASSIGNMENT((${u1},${u2},${u3},${u4}))`);
  const proj = add(`IFCPROJECT('${ifcGuid()}',$,${stepString(tree.projectName || project.name)},${stepString(tree.projectDescription || (project.number ? `Project ${project.number}` : null))},$,$,${stepString(tree.phase || null)},(${context}),${units})`);
  const sitePl = add(`IFCLOCALPLACEMENT($,${place})`);
  const site = add(`IFCSITE('${ifcGuid()}',$,${stepString(tree.siteName || 'Site')},${stepString(tree.siteDescription || null)},$,${sitePl},$,$,.ELEMENT.,$,$,$,${stepString(project.address || null)},$)`);
  const bldPl = add(`IFCLOCALPLACEMENT(${sitePl},${place})`);
  const building = add(`IFCBUILDING('${ifcGuid()}',$,${stepString(tree.buildingName || project.name)},${stepString(tree.buildingDescription || null)},$,${bldPl},$,$,.ELEMENT.,$,$,$)`);
  add(`IFCRELAGGREGATES('${ifcGuid()}',$,$,$,${proj},(${site}))`);
  add(`IFCRELAGGREGATES('${ifcGuid()}',$,$,$,${site},(${building}))`);
  const storeys = new Map();
  for (const lv of doc.levels()) {
    const p = add(`IFCCARTESIANPOINT((0.,0.,${L(lv.elevation)}))`);
    const ax = add(`IFCAXIS2PLACEMENT3D(${p},${zAxis},${xAxis})`);
    const pl = add(`IFCLOCALPLACEMENT(${bldPl},${ax})`);
    const st = add(`IFCBUILDINGSTOREY('${ifcGuid()}',$,${stepString(lv.name)},$,$,${pl},$,$,.ELEMENT.,${L(lv.elevation)})`);
    storeys.set(lv.id, { st, pl, z: lv.elevation, items: [], spaces: [] });
  }
  if (storeys.size) add(`IFCRELAGGREGATES('${ifcGuid()}',$,$,$,${building},(${[...storeys.values()].map((s) => s.st).join(',')}))`);
  const firstStorey = [...storeys.values()][0];
  // Element placement: the building origin; geometry in absolute coordinates.
  const elPlace = add(`IFCLOCALPLACEMENT(${bldPl},${place})`);
  const ctx = { size: (el) => {
    const t = doc.get(el.typeId) || {};
    return { width: +t.width || 900, height: +t.height || 2100 };
  } };
  // Property sets an element brought from an IFC file go back out with it.
  const propSets = (el, ent) => {
    if (!t.properties) return;
    const bySet = new Map();
    const put = (set, prop, val) => {
      if (!bySet.has(set)) bySet.set(set, []);
      bySet.get(set).push(add(`IFCPROPERTYSINGLEVALUE(${stepString(prop)},$,${val},$)`));
    };
    for (const [k, v] of Object.entries(el.ifcProps || {})) {
      const dot = k.indexOf('.');
      const set = dot > 0 ? k.slice(0, dot) : 'Pset';
      const prop = dot > 0 ? k.slice(dot + 1) : k;
      put(set, prop, typeof v === 'boolean' ? `IFCBOOLEAN(${v ? '.T.' : '.F.'})` : typeof v === 'number' ? `IFCREAL(${num(v)})` : `IFCLABEL(${stepString(String(v))})`);
    }
    // Custom properties, one property set per group (as Archicad exports them).
    for (const p of paramsForElement(doc, el)) {
      const r = paramValueOf({ doc }, el, p);
      const v = r.error ? null : r.value;
      if (v === null || v === undefined || v === '' || (Array.isArray(v) && !v.length)) continue;
      const t = p.type === 'expression' ? p.result : p.type;
      const val =
        t === 'bool' ? `IFCBOOLEAN(${v ? '.T.' : '.F.'})`
        : t === 'length' ? `IFCLENGTHMEASURE(${L(+v)})`
        : t === 'area' ? `IFCAREAMEASURE(${num(+v / 1e6)})`
        : t === 'volume' ? `IFCVOLUMEMEASURE(${num(+v / 1e9)})`
        : t === 'angle' ? `IFCPLANEANGLEMEASURE(${num((+v * Math.PI) / 180)})`
        : t === 'number' ? `IFCREAL(${num(+v)})`
        : `IFCLABEL(${stepString(Array.isArray(v) ? v.join('; ') : String(v))})`;
      put(p.group || 'Identity Data', p.name, val);
    }
    for (const [set, props] of bySet) {
      const ps = add(`IFCPROPERTYSET('${ifcGuid()}',$,${stepString(set)},$,(${props.join(',')}))`);
      add(`IFCRELDEFINESBYPROPERTIES('${ifcGuid()}',$,$,$,(${ent}),${ps})`);
    }
  };
  // Plain solids stay parametric, so other programs read real walls, slabs, columns and beams.
  const axisCtx = add(`IFCGEOMETRICREPRESENTATIONSUBCONTEXT('Axis','Model',*,*,*,*,${context},$,.GRAPH_VIEW.,$)`);
  const point2 = (q) => add(`IFCCARTESIANPOINT((${L(q[0])},${L(q[1])}))`);
  const polyline = (P) => {
    const ids = P.map(point2);
    return add(`IFCPOLYLINE((${[...ids, ids[0]].join(',')}))`);
  };
  const areaOf = (outer, holes = []) => (holes.length ? add(`IFCARBITRARYPROFILEDEFWITHVOIDS(.AREA.,$,${polyline(outer)},(${holes.map(polyline).join(',')}))`) : add(`IFCARBITRARYCLOSEDPROFILEDEF(.AREA.,$,${polyline(outer)})`));
  const upward = (profile, z, h) => {
    const p = add(`IFCCARTESIANPOINT((0.,0.,${L(z)}))`);
    const ax = add(`IFCAXIS2PLACEMENT3D(${p},${zAxis},${xAxis})`);
    return add(`IFCEXTRUDEDAREASOLID(${profile},${ax},${zAxis},${L(h)})`);
  };
  const near = (a, b) => Math.abs(a - b) <= 1.5;
  /** The element as a swept solid when its built shape is exactly that (checked against its mesh); else null. { solid, axis } */
  const sweptOf = (el, kind, m) => {
    const box = m.bounds;
    if (!box) return null;
    if (kind === 'wall') {
      const type = doc.get(el.typeId) || {};
      if (el.arc || el.slant || type.curtain || el.profileId || el.attachTopId) return null;
      const { base, top } = verticalExtent(doc, el);
      if (!near(box.min[2], base) || !near(box.max[2], top)) return null;
      const axis = wallAxis(doc, el);
      const len = wallLength(el);
      const half = wallThickness(doc, el) / 2;
      const a = axisPoint(axis, 0, 0);
      const b = axisPoint(axis, len, 0);
      const d = [(b[0] - a[0]) / len, (b[1] - a[1]) / len];
      const n = [-d[1] * half, d[0] * half];
      const area = areaOf([[a[0] - n[0], a[1] - n[1]], [b[0] - n[0], b[1] - n[1]], [b[0] + n[0], b[1] + n[1]], [a[0] + n[0], a[1] + n[1]]]);
      const curve = add(`IFCPOLYLINE((${point2(a)},${point2(b)}))`);
      return { solid: upward(area, base, top - base), axis: add(`IFCSHAPEREPRESENTATION(${axisCtx},'Axis','Curve2D',(${curve}))`) };
    }
    if (kind === 'floor') {
      if (!el.boundary || el.boundary.length < 3) return null;
      const thick = typeThickness(doc.get(el.typeId));
      if (!near(box.max[2] - box.min[2], thick)) return null;
      return { solid: upward(areaOf(el.boundary, el.holes || []), box.min[2], thick) };
    }
    if (kind === 'column') {
      const type = doc.get(el.typeId) || {};
      if (el.profileId || el.topWidth || el.topDepth) return null;
      const { base, top } = verticalExtent(doc, el);
      if (!near(box.min[2], base) || !near(box.max[2], top)) return null;
      const w = +type.width || 450;
      const dp = +type.depth || w;
      const r = ((+el.rotation || 0) * Math.PI) / 180;
      const pos = add(`IFCAXIS2PLACEMENT2D(${point2(el.at)},${add(`IFCDIRECTION((${num(Math.cos(r))},${num(Math.sin(r))}))`)})`);
      const profile = type.shape === 'round' ? add(`IFCCIRCLEPROFILEDEF(.AREA.,$,${pos},${L(w / 2)})`) : add(`IFCRECTANGLEPROFILEDEF(.AREA.,$,${pos},${L(w)},${L(dp)})`);
      return { solid: upward(profile, base, top - base) };
    }
    if (kind === 'beam') {
      const type = doc.get(el.typeId) || {};
      if (el.profileId || el.endWidth || el.endDepth || (el.endOffset != null && !near(+el.endOffset, +el.offset || 0))) return null;
      const t2 = trimmedBeam(doc, el);
      const len = Math.hypot(t2.b[0] - t2.a[0], t2.b[1] - t2.a[1]);
      if (len < 1) return null;
      const dep = +type.depth || 600;
      const zt = levelElevation(doc, el.levelId) + (+el.offset || 0);
      if (!near(box.max[2], zt) || !near(box.min[2], zt - dep)) return null;
      const d = [(t2.b[0] - t2.a[0]) / len, (t2.b[1] - t2.a[1]) / len];
      const at = add(`IFCCARTESIANPOINT((${L(t2.a[0])},${L(t2.a[1])},${L(zt - dep / 2)}))`);
      const along = add(`IFCDIRECTION((${num(d[0])},${num(d[1])},0.))`);
      const across = add(`IFCDIRECTION((${num(-d[1])},${num(d[0])},0.))`);
      const pos = add(`IFCAXIS2PLACEMENT3D(${at},${along},${across})`);
      const profile = add(`IFCRECTANGLEPROFILEDEF(.AREA.,$,$,${L(+type.width || 300)},${L(dep)})`);
      return { solid: add(`IFCEXTRUDEDAREASOLID(${profile},${pos},${zAxis},${L(len)})`) };
    }
    return null;
  };
  const written = new Map();
  const styles = new Map();
  const systems = doc.all('classSystem');
  const system = systems[0] || null;
  const classified = new Map(systems.map((sys) => [sys.id, new Map()]));
  for (const kd of MODEL_KINDS)
    for (const el of kd === 'link' || kd === 'importedModel' ? [] : doc.all(kd)) {
      if (!translatorIncludes(doc, t, el)) continue;
      const m = scene.mesh(el);
      if (!m || !m.pos.length) continue;
      const n = m.pos.length / 3;
      // Merge identical vertices to keep the file small.
      const index = new Map();
      const pts = [];
      const tris = [];
      for (let t = 0; t < n; t += 3) {
        const tri = [];
        for (let k2 = 0; k2 < 3; k2++) {
          const i = t + k2;
          const key = `${Math.round(m.pos[i * 3] * 10)},${Math.round(m.pos[i * 3 + 1] * 10)},${Math.round(m.pos[i * 3 + 2] * 10)}`;
          let v = index.get(key);
          if (v === undefined) {
            v = pts.length;
            index.set(key, v);
            pts.push(`(${L(m.pos[i * 3])},${L(m.pos[i * 3 + 1])},${L(m.pos[i * 3 + 2])})`);
          }
          tri.push(v + 1);
        }
        if (tri[0] !== tri[1] && tri[1] !== tri[2] && tri[0] !== tri[2]) tris.push(`(${tri.join(',')})`);
      }
      if (!tris.length) continue;
      const swept = sweptOf(el, kd, m);
      let fs;
      if (swept) fs = swept.solid;
      else if (x3) {
        // IFC2x3 has no triangulated face sets: a faceted B-rep, one polygon loop per triangle.
        const cps = pts.map((q) => add(`IFCCARTESIANPOINT(${q})`));
        const faces = tris.map((tr) => {
          const ids = tr.slice(1, -1).split(',').map((i) => cps[+i - 1]);
          const loop = add(`IFCPOLYLOOP((${ids.join(',')}))`);
          const bound = add(`IFCFACEOUTERBOUND(${loop},.T.)`);
          return add(`IFCFACE((${bound}))`);
        });
        const shell = add(`IFCCLOSEDSHELL((${faces.join(',')}))`);
        fs = add(`IFCFACETEDBREP(${shell})`);
      } else {
        const pl = add(`IFCCARTESIANPOINTLIST3D((${pts.join(',')}),$)`);
        fs = add(`IFCTRIANGULATEDFACESET(${pl},$,.F.,(${tris.join(',')}),$)`);
      }
      // The element's main colour as a surface style, so other tools show it too.
      const counts = new Map();
      for (let i = 0; i < n; i += 3) {
        const key = `${m.col[i * 4]},${m.col[i * 4 + 1]},${m.col[i * 4 + 2]},${m.col[i * 4 + 3]}`;
        // Weighted by area, and upward faces count double (roofs show their top).
        const P = (k) => [m.pos[(i + k) * 3], m.pos[(i + k) * 3 + 1], m.pos[(i + k) * 3 + 2]];
        const [a, b2, c] = [P(0), P(1), P(2)];
        const u = [b2[0] - a[0], b2[1] - a[1], b2[2] - a[2]];
        const v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
        const cx = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
        const area = Math.hypot(...cx) / 2;
        counts.set(key, (counts.get(key) || 0) + area * (cx[2] > 0.5 * Math.hypot(...cx) ? 2 : 1));
      }
      const main = [...counts].sort((a, b) => b[1] - a[1])[0]?.[0];
      if (main) {
        let style = styles.get(main);
        if (!style) {
          const [r, g, b2, a] = main.split(',').map(Number);
          const rgb = add(`IFCCOLOURRGB($,${num(r / 255)},${num(g / 255)},${num(b2 / 255)})`);
          const shading = add(`IFCSURFACESTYLESHADING(${rgb},${num(1 - a / 255)})`);
          style = add(`IFCSURFACESTYLE($,.BOTH.,(${shading}))`);
          if (x3) style = add(`IFCPRESENTATIONSTYLEASSIGNMENT((${style}))`);
          styles.set(main, style);
        }
        add(`IFCSTYLEDITEM(${fs},(${style}),$)`);
      }
      const sr = add(`IFCSHAPEREPRESENTATION(${body},'Body',${swept ? "'SweptSolid'" : x3 ? "'Brep'" : "'Tessellation'"},(${fs}))`);
      const pds = add(`IFCPRODUCTDEFINITIONSHAPE($,$,(${swept?.axis ? `${swept.axis},` : ''}${sr}))`);
      const type = doc.get(el.typeId);
      const own = el.ifcAttrs || {};
      const name = stepString(own.Name || (type ? typeLabel(type) : kd));
      const tag = stepString(el.mark || el.id);
      // The entity: the translator's map, else the first classification system, else the element's kind.
      const { entity, predefinedType } = ifcEntityOf(doc, el, t.entityMap);
      const sz = ctx.size(el);
      // Stable GlobalIds, so BCF viewpoints and later exports name the same elements.
      const ent = add(
        productLine(t.schema, entity, predefinedType, {
          g: el.ifcGuid || ifcGuidFor(el.id),
          n: name,
          d: stepString(own.Description || null),
          o: stepString(own.ObjectType || null),
          p: elPlace,
          r: pds,
          tag,
          height: L(sz.height),
          width: L(sz.width),
        }),
      );
      written.set(el.id, { ent, swept: !!swept });
      propSets(el, ent);
      if (t.classifications) for (const sys of systems) {
        const item = classOf(doc, el, sys);
        if (item) classified.get(sys.id).set(item.code, [...(classified.get(sys.id).get(item.code) || []), ent]);
      }
      const lv = levelOf(doc, el);
      (storeys.get(lv?.id) || firstStorey)?.items.push(ent);
    }
  // The holes doors and windows stand in, cut from walls that went out as solids.
  for (const kind of ['door', 'window', 'opening'])
    for (const el of doc.all(kind)) {
      const host = written.get(el.hostId);
      if (!host?.swept) continue;
      const wall = doc.get(el.hostId);
      const { width, height, sill } = openingSize(doc, el);
      const { base } = verticalExtent(doc, wall);
      const axis = wallAxis(doc, wall);
      const len = wallLength(wall);
      const a = axisPoint(axis, 0, 0);
      const b = axisPoint(axis, len, 0);
      const d = [(b[0] - a[0]) / len, (b[1] - a[1]) / len];
      const c = [a[0] + d[0] * el.t, a[1] + d[1] * el.t];
      const half = wallThickness(doc, wall) / 2 + 10;
      const [ux, uy, nx, ny] = [(d[0] * width) / 2, (d[1] * width) / 2, -d[1] * half, d[0] * half];
      const area = areaOf([[c[0] - ux - nx, c[1] - uy - ny], [c[0] + ux - nx, c[1] + uy - ny], [c[0] + ux + nx, c[1] + uy + ny], [c[0] - ux + nx, c[1] - uy + ny]]);
      const solid = upward(area, base + sill, height);
      const sr = add(`IFCSHAPEREPRESENTATION(${body},'Body','SweptSolid',(${solid}))`);
      const pds = add(`IFCPRODUCTDEFINITIONSHAPE($,$,(${sr}))`);
      const hole = add(`IFCOPENINGELEMENT('${ifcGuid()}',$,'Opening',$,$,${elPlace},${pds},$${x3 ? '' : ',.OPENING.'})`);
      add(`IFCRELVOIDSELEMENT('${ifcGuid()}',$,$,$,${host.ent},${hole})`);
      const fill = written.get(el.id);
      if (fill) add(`IFCRELFILLSELEMENT('${ifcGuid()}',$,$,$,${hole},${fill.ent})`);
    }
  // Rooms as spaces.
  for (const r of t.spaces ? doc.all('room') : []) {
    const region = scene.rooms.room(r);
    const s = storeys.get(r.levelId);
    if (!region || !s) continue;
    const pts = region.outer.map((p) => add(`IFCCARTESIANPOINT((${L(p[0])},${L(p[1])}))`));
    const poly = add(`IFCPOLYLINE((${[...pts, pts[0]].join(',')}))`);
    const prof = add(`IFCARBITRARYCLOSEDPROFILEDEF(.AREA.,$,${poly})`);
    const p0 = add(`IFCCARTESIANPOINT((0.,0.,${L(s.z)}))`);
    const ax = add(`IFCAXIS2PLACEMENT3D(${p0},${zAxis},${xAxis})`);
    const solid = add(`IFCEXTRUDEDAREASOLID(${prof},${ax},${zAxis},${L(+r.upperOffset || 2700)})`);
    const sr = add(`IFCSHAPEREPRESENTATION(${body},'Body','SweptSolid',(${solid}))`);
    const pds = add(`IFCPRODUCTDEFINITIONSHAPE($,$,(${sr}))`);
    const sp = add(`IFCSPACE('${r.ifcGuid || ifcGuidFor(r.id)}',$,${stepString(r.number || r.name)},$,$,${elPlace},${pds},${stepString(r.name)},.ELEMENT.,.INTERNAL.,$)`);
    s.spaces.push(sp);
    propSets(r, sp);
    if (t.classifications) for (const sys of systems) {
      const item = classOf(doc, r, sys);
      if (item) classified.get(sys.id).set(item.code, [...(classified.get(sys.id).get(item.code) || []), sp]);
    }
  }
  // Classification systems and the items elements belong to.
  for (const sys of systems) {
    const used = classified.get(sys.id);
    if (!used.size) continue;
    const cl = add(x3 ? `IFCCLASSIFICATION(${stepString('Building Design')},${stepString(sys.edition || '')},$,${stepString(sys.name)})` : `IFCCLASSIFICATION(${stepString('Building Design')},${stepString(sys.edition || null)},$,${stepString(sys.name)},$,$,$)`);
    for (const [code, ents] of used) {
      const item = sys.items.find((i) => i.code === code);
      const ref = add(x3 ? `IFCCLASSIFICATIONREFERENCE($,${stepString(code)},${stepString(item?.name || code)},${cl})` : `IFCCLASSIFICATIONREFERENCE($,${stepString(code)},${stepString(item?.name || code)},${cl},$,$)`);
      add(`IFCRELASSOCIATESCLASSIFICATION('${ifcGuid()}',$,$,$,(${ents.join(',')}),${ref})`);
    }
  }
  for (const s of storeys.values()) {
    if (s.items.length) add(`IFCRELCONTAINEDINSPATIALSTRUCTURE('${ifcGuid()}',$,$,$,(${s.items.join(',')}),${s.st})`);
    if (s.spaces.length) add(`IFCRELAGGREGATES('${ifcGuid()}',$,$,$,${s.st},(${s.spaces.join(',')}))`);
  }
  const now = new Date().toISOString().slice(0, 19);
  const header = [
    'ISO-10303-21;',
    'HEADER;',
    `FILE_DESCRIPTION(('ViewDefinition [${x3 ? 'CoordinationView_V2.0' : 'ReferenceView'}]'),'2;1');`,
    `FILE_NAME(${stepString(`${project.name}.ifc`)},'${now}',(${stepString(project.author || '')}),(''),'Building Design','Building Design','');`,
    `FILE_SCHEMA(('${x3 ? 'IFC2X3' : 'IFC4'}'));`,
    'ENDSEC;',
    'DATA;',
  ];
  emit(lines.length ? `${lines.join('\n')}\n` : '');
  return header;
}

const IFC_END = 'ENDSEC;\nEND-ISO-10303-21;\n';

/** The IFC file as text. A browser's string stops at about 512 MB: for a whole large model use writeIFCBlob. */
export function writeIFC(app, translator = null) {
  const data = [];
  const header = ifcBody(app, translator, (t) => data.push(t));
  return `${header.join('\n')}\n${data.join('')}${IFC_END}`;
}

/** The IFC file as a Blob, whatever its size: the browser can keep what is written on disk. */
export function writeIFCBlob(app, translator = null) {
  const data = [];
  const header = ifcBody(app, translator, (t) => data.push(new Blob([t])));
  return new Blob([`${header.join('\n')}\n`, ...data, IFC_END], { type: 'application/x-step' });
}
