/**
 * Placing a read CAD drawing (DWG or DXF) in a view: its layers either
 * become model elements by their role (walls, columns, doors, windows,
 * zones) or come in as drafting that remembers its CAD layer.
 */
import { flattenCAD } from '../core/cadflatten.js';
import { recognizeCAD, buildRecognized, layerRole } from '../core/recognize.js';

const MODEL_ROLES = new Set(['wall', 'column', 'door', 'window', 'zone', 'stamp']);

/** The middle of a flattened drawing's lines and arcs (in drawing units). */
export function cadMiddle(flat) {
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  const add = (p) => {
    if (p[0] < x0) x0 = p[0];
    if (p[0] > x1) x1 = p[0];
    if (p[1] < y0) y0 = p[1];
    if (p[1] > y1) y1 = p[1];
  };
  for (const l of flat.lines) add(l.a), add(l.b);
  for (const a of flat.arcs) add(a.c);
  return Number.isFinite(x0) ? [(x0 + x1) / 2, (y0 + y1) / 2] : [0, 0];
}

/** Default roles for a drawing's layers, from their names. */
export function defaultRoles(layerNames) {
  return new Map(layerNames.map((n) => [n, layerRole(n)]));
}

/**
 * Place a drawing (inside a transaction). opts:
 *   view      the plan / drafting view
 *   layers    Set of layer names to take (all when missing)
 *   roles     Map layer -> role (from layer names when missing)
 *   unitMm    millimetres per drawing unit
 *   centre    move the drawing's middle to the origin
 *   fills     solid fills as filled regions
 *   mode      'drafting' (everything as drafting), 'model' (model only)
 *             or 'smart' (model from the model layers, the rest as drafting)
 * Returns { drafting: count, model: { walls, doors, windows, rooms, columns, skipped } | null }.
 */
/**
 * Smart Merge (Archicad's): remove what an earlier import of the same file brought into a view (its drafting there,
 * and the model elements it made on that level), so the new version replaces it. Returns the number removed.
 */
export function removeCADImport(doc, source, view) {
  let n = 0;
  for (const el of [...doc.items.values()])
    if (el.cadSource === source && (el.viewId === view.id || (!el.viewId && el.levelId === view.levelId))) {
      doc.remove(el.id);
      n++;
    }
  return n;
}

export function placeCAD(doc, cad, { view, layers = null, roles = null, unitMm = 1, centre = true, fills = true, mode = 'drafting', source = null }) {
  const flat = flattenCAD(cad, layers ? { layers } : {});
  const role = roles || defaultRoles([...new Set([...flat.lines, ...flat.arcs, ...flat.texts, ...flat.fills].map((x) => x.layer))]);
  const k = +unitMm || 1;
  const [mx, my] = centre ? cadMiddle(flat) : [0, 0];
  const T = (p) => [(p[0] - mx) * k, (p[1] - my) * k];
  const wantModel = mode !== 'drafting' && view?.kind === 'plan' && view.levelId;
  const asDrafting = (layer) => mode === 'drafting' || !wantModel || (mode === 'smart' && !MODEL_ROLES.has(role.get(layer)) && role.get(layer) !== 'ignore');
  let model = null;
  if (wantModel) {
    const mm = {
      lines: flat.lines.map((l) => ({ ...l, a: T(l.a), b: T(l.b) })),
      arcs: flat.arcs.map((a) => ({ ...a, c: T(a.c), r: a.r * k })),
      texts: flat.texts.map((t) => ({ ...t, at: T(t.at) })),
      fills: flat.fills.map((f) => ({ ...f, poly: f.poly.map(T) })),
    };
    // The layouts' texts (a room schedule there) name zones too.
    const paperTexts = cad.paper?.length ? flattenCAD({ ...cad, entities: cad.paper }).texts : [];
    const rec = recognizeCAD(mm, role, { extraTexts: paperTexts });
    const before = new Set(doc.items.keys());
    model = { ...buildRecognized(doc, rec, { levelId: view.levelId }), counts: rec.counts };
    // Remember where the model came from, for Smart Merge.
    if (source) for (const id of [...doc.items.keys()]) if (!before.has(id) && !doc.get(id).kind.endsWith('Type')) doc.update(id, { cadSource: source });
  }
  const vs = +view.scale || 100;
  let drafting = 0;
  const put = (el) => (doc.add({ ...el, viewId: view.id, ...(source ? { cadSource: source } : {}) }), drafting++);
  for (const l of flat.lines) if (asDrafting(l.layer)) put({ kind: 'detailLine', a: T(l.a), b: T(l.b), style: 'thin', cadLayer: l.layer });
  for (const a of flat.arcs)
    if (asDrafting(a.layer)) {
      let a1 = a.a1;
      while (a1 <= a.a0) a1 += Math.PI * 2;
      put({ kind: 'detailArc', c: T(a.c), r: a.r * k, a0: a.a0, a1, style: 'thin', cadLayer: a.layer });
    }
  for (const t of flat.texts) if (asDrafting(t.layer)) put({ kind: 'text', at: T(t.at), text: t.text, size: Math.max(0.5, Math.round(((t.height * k) / vs) * 10) / 10), rotation: (t.rotation * 180) / Math.PI, align: 'left', cadLayer: t.layer });
  if (fills) for (const fl of flat.fills) if (asDrafting(fl.layer)) put({ kind: 'region', boundary: fl.poly.map(T), holes: [], pattern: 'solid', outline: false, cadLayer: fl.layer });
  return { drafting, model };
}
