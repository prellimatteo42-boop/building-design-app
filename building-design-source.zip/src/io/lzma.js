/**
 * LZMA (the first version, as 7-Zip and xz's "lzma alone" write it): a range-coded stream of literals and matches
 * over a sliding dictionary. `lzmaDecode(bytes, at)` reads the five-byte properties (lc, lp, pb packed in the first,
 * then the dictionary size) at `at` and the stream right after them, up to its end marker or the end of the input.
 * Written from the format's published description; returns the decoded bytes.
 */

const PROB_INIT = 1024;

class RangeDecoder {
  constructor(b, p) {
    this.b = b;
    this.p = p + 1; // the first byte is always 0
    this.range = 0xffffffff;
    this.code = 0;
    for (let i = 0; i < 4; i++) this.code = ((this.code << 8) | this.byte()) >>> 0;
  }
  byte() {
    return this.p < this.b.length ? this.b[this.p++] : 0;
  }
  norm() {
    if (this.range < 0x1000000) {
      this.range = (this.range << 8) >>> 0;
      this.code = ((this.code << 8) | this.byte()) >>> 0;
    }
  }
  bit(probs, i) {
    const v = probs[i];
    const bound = (this.range >>> 11) * v;
    let bit;
    if (this.code < bound) {
      this.range = bound;
      probs[i] = v + ((2048 - v) >>> 5);
      bit = 0;
    } else {
      this.range = (this.range - bound) >>> 0;
      this.code = (this.code - bound) >>> 0;
      probs[i] = v - (v >>> 5);
      bit = 1;
    }
    this.norm();
    return bit;
  }
  direct(n) {
    let res = 0;
    while (n-- > 0) {
      this.range >>>= 1;
      this.code = (this.code - this.range) >>> 0;
      const neg = this.code >>> 31;
      if (neg) this.code = (this.code + this.range) >>> 0;
      this.norm();
      res = ((res << 1) | (neg ? 0 : 1)) >>> 0;
    }
    return res;
  }
  tree(probs, base, bits) {
    let m = 1;
    for (let i = 0; i < bits; i++) m = (m << 1) + this.bit(probs, base + m);
    return m - (1 << bits);
  }
  reverse(probs, base, bits) {
    let m = 1;
    let sym = 0;
    for (let i = 0; i < bits; i++) {
      const b = this.bit(probs, base + m);
      m = (m << 1) + b;
      sym |= b << i;
    }
    return sym;
  }
}

const probs = (n) => new Uint16Array(n).fill(PROB_INIT);

class LenDecoder {
  constructor() {
    this.choice = probs(2);
    this.low = probs(16 << 3);
    this.mid = probs(16 << 3);
    this.high = probs(256);
  }
  decode(rc, posState) {
    if (rc.bit(this.choice, 0) === 0) return rc.tree(this.low, posState << 3, 3);
    if (rc.bit(this.choice, 1) === 0) return 8 + rc.tree(this.mid, posState << 3, 3);
    return 16 + rc.tree(this.high, 0, 8);
  }
}

/** Decode the LZMA stream whose properties start at `at`. `limit` caps the output (bytes). */
export function lzmaDecode(bytes, at = 0, { limit = 1 << 30 } = {}) {
  let d = bytes[at];
  if (d >= 9 * 5 * 5) throw new Error('Bad LZMA properties');
  const lc = d % 9;
  d = (d / 9) | 0;
  const lp = d % 5;
  const pb = (d / 5) | 0;
  const rc = new RangeDecoder(bytes, at + 5);
  let out = new Uint8Array(Math.min(limit, Math.max(1 << 16, (bytes.length - at) * 4)));
  let n = 0;
  const put = (v) => {
    if (n >= out.length) {
      if (out.length >= limit) throw new Error('LZMA output over its limit');
      const next = new Uint8Array(Math.min(limit, out.length * 2));
      next.set(out);
      out = next;
    }
    out[n++] = v;
  };
  const lit = probs(0x300 << (lc + lp));
  const isMatch = probs(12 << 4);
  const isRep = probs(12);
  const isRepG0 = probs(12);
  const isRepG1 = probs(12);
  const isRepG2 = probs(12);
  const isRep0Long = probs(12 << 4);
  const posSlot = probs(4 << 6);
  const posDec = probs(1 + 128 - 14);
  const align = probs(16);
  const lenDec = new LenDecoder();
  const repLenDec = new LenDecoder();
  const pbMask = (1 << pb) - 1;
  const lpMask = (1 << lp) - 1;
  let state = 0;
  let rep0 = 0;
  let rep1 = 0;
  let rep2 = 0;
  let rep3 = 0;
  const end = bytes.length;
  while (rc.p <= end + 4) {
    const posState = n & pbMask;
    if (rc.bit(isMatch, (state << 4) + posState) === 0) {
      const prev = n > 0 ? out[n - 1] : 0;
      const base = 0x300 * (((n & lpMask) << lc) + (prev >>> (8 - lc)));
      let sym = 1;
      if (state >= 7) {
        let match = out[n - rep0 - 1];
        do {
          const mb = (match >>> 7) & 1;
          match <<= 1;
          const b = rc.bit(lit, base + ((1 + mb) << 8) + sym);
          sym = (sym << 1) | b;
          if (mb !== b) break;
        } while (sym < 0x100);
      }
      while (sym < 0x100) sym = (sym << 1) | rc.bit(lit, base + sym);
      put(sym - 0x100);
      state = state < 4 ? 0 : state < 10 ? state - 3 : state - 6;
      continue;
    }
    let len;
    if (rc.bit(isRep, state) !== 0) {
      if (n === 0) throw new Error('Bad LZMA data');
      if (rc.bit(isRepG0, state) === 0) {
        if (rc.bit(isRep0Long, (state << 4) + posState) === 0) {
          state = state < 7 ? 9 : 11;
          put(out[n - rep0 - 1]);
          continue;
        }
      } else {
        let dist;
        if (rc.bit(isRepG1, state) === 0) dist = rep1;
        else {
          if (rc.bit(isRepG2, state) === 0) dist = rep2;
          else {
            dist = rep3;
            rep3 = rep2;
          }
          rep2 = rep1;
        }
        rep1 = rep0;
        rep0 = dist;
      }
      len = repLenDec.decode(rc, posState);
      state = state < 7 ? 8 : 11;
    } else {
      rep3 = rep2;
      rep2 = rep1;
      rep1 = rep0;
      len = lenDec.decode(rc, posState);
      state = state < 7 ? 7 : 10;
      // The distance: a slot, then its low bits from their own models or direct with an aligned tail.
      const slot = rc.tree(posSlot, Math.min(len, 3) << 6, 6);
      if (slot < 4) rep0 = slot;
      else {
        const direct = (slot >>> 1) - 1;
        let dist = ((2 | (slot & 1)) << direct) >>> 0;
        if (slot < 14) dist = (dist + rc.reverse(posDec, dist - slot, direct)) >>> 0;
        else {
          dist = (dist + (rc.direct(direct - 4) << 4)) >>> 0;
          dist = (dist + rc.reverse(align, 0, 4)) >>> 0;
        }
        rep0 = dist;
      }
      if (rep0 === 0xffffffff) break; // the end marker
    }
    len += 2;
    if (rep0 >= n) throw new Error('Bad LZMA distance');
    for (let i = 0; i < len; i++) put(out[n - rep0 - 1]);
  }
  return out.subarray(0, n);
}
