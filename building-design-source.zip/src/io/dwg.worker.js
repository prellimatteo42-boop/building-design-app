/**
 * Reads a DWG file with LibreDWG (WebAssembly, @mlightcad/libredwg-web,
 * audited and pinned) in its own worker, so a damaged file can at worst
 * fail here. Posts back the drawing as plain data: units, layers, blocks
 * and model space entities.
 */
// The package exports only its wrapper, so the raw module is reached by path.
import createModule from '../../node_modules/@mlightcad/libredwg-web/wasm/libredwg-web.js';
import { LibreDwg, Dwg_File_Type } from '@mlightcad/libredwg-web';
import wasmUrl from '../../node_modules/@mlightcad/libredwg-web/wasm/libredwg-web.wasm?url';

let lib = null;

async function ready() {
  if (!lib) lib = LibreDwg.createByWasmInstance(await createModule({ locateFile: () => wasmUrl }));
  return lib;
}

self.onmessage = async (ev) => {
  const { bytes, dxf } = ev.data || {};
  try {
    const l = await ready();
    const dwg = l.dwg_read_data(bytes, dxf ? Dwg_File_Type.DXF : Dwg_File_Type.DWG);
    if (!dwg) throw new Error('The file could not be read');
    const db = l.convert(dwg);
    l.dwg_free(dwg);
    const blocks = {};
    // Layouts (paper space) hold title blocks and room schedules: their entities come along apart.
    const paper = [];
    for (const b of db.tables.BLOCK_RECORD.entries || []) {
      if (!b.name || /^\*model_space$/i.test(b.name)) continue;
      if (/^\*paper_space/i.test(b.name)) paper.push(...(b.entities || []));
      else blocks[b.name] = { basePoint: b.basePoint || { x: 0, y: 0 }, entities: b.entities || [] };
    }
    const layers = (db.tables.LAYER.entries || []).map((x) => ({ name: x.name, off: !!x.off || (x.colorIndex ?? 0) < 0, frozen: !!x.frozen }));
    self.postMessage({ ok: true, units: db.header?.INSUNITS ?? 0, entities: db.entities || [], blocks, layers, paper });
  } catch (err) {
    self.postMessage({ ok: false, error: String(err?.message || err) });
  }
};
