/**
 * Archicad's binary 3D data (the 3DBN sections of a library part, drawn by
 * GDL's BINARY): bodies of polygons. Layout (little-endian), read from
 * Archicad 30's libraries, for the versions they hold (4001 to 4029, the
 * word at 0x10):
 *   after the version, a header of 0x30 bytes (before 4008), 0x38 (before
 *   4016) or 0x40; its counts at 0x18: bodies, polygons, polygon edge list
 *   entries, edges, vertices, normals (and from 4014 transformations at
 *   0x48, 104 bytes each, after the bodies);
 *   bodies of 76 bytes (before 4013: five 1-based [first, last] ranges into
 *   the polygons, edge list, edges, vertices and normals at +0x24), 124
 *   (before 4018), 136 (before 4027) or 140 (ranges at +0x30);
 *   polygons of 24 bytes (before 4003), 28 (first and last of their edge
 *   list entries at +12 and +16, counted from their body's first, 0-based)
 *   or 32 (before 4031; at +16 and +20);
 *   the edge list: int32 edge numbers (from the body's first, 1-based),
 *   negative where the polygon runs the edge backwards;
 *   edges of 20 bytes (before 4015; vertices at +4 and +8) or 24 (at +8 and
 *   +12), 0-based from their body's first;
 *   vertices of 3 floats (before 4012) or 3 doubles; normals likewise.
 * Returns [{ polys: [[[x, y, z], ...]], min, max }] or null when the data
 * does not hold together.
 */
export function read3DBinary(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.length < 0x54) return null;
  const ver = dv.getUint32(0x10, true);
  // 4018 has a body record of its own, and later versions other layouts.
  if (ver < 0xfa1 || ver > 0xfbe || ver === 0xfb2) return null;
  const [nb, np, nl, ne, nv] = [0x18, 0x1c, 0x20, 0x24, 0x28].map((o) => dv.getUint32(o, true));
  const head = ver < 0xfa8 ? 0x30 : ver < 0xfb0 ? 0x38 : 0x40;
  const bodySize = ver < 0xfad ? 0x4c : ver < 0xfb2 ? 0x7c : ver < 0xfbb ? 0x88 : 0x8c;
  const ranges = bodySize === 0x4c ? 0x24 : 0x30;
  const transforms = ver >= 0xfae ? dv.getUint32(0x48, true) : 0;
  const pgonSize = ver < 0xfa3 ? 24 : ver < 0xfaf ? 28 : 32;
  const pedg = pgonSize === 32 ? 16 : 12;
  const edgeSize = ver < 0xfaf ? 20 : 24;
  const edgeVert = edgeSize === 20 ? 4 : 8;
  const floats = ver < 0xfab;
  const bodiesAt = 0x14 + head;
  const pgonsAt = bodiesAt + bodySize * nb + 104 * transforms;
  const listAt = pgonsAt + pgonSize * np;
  const edgesAt = listAt + 4 * nl;
  const vertsAt = edgesAt + edgeSize * ne;
  const vertSize = floats ? 12 : 24;
  if (nb > 10000 || transforms > 10000 || vertsAt + vertSize * nv > bytes.length) return null;
  const bodies = [];
  for (let b = 0; b < nb; b++) {
    const r = bodiesAt + bodySize * b + ranges;
    const [p0, p1, l0, , e0, , v0] = Array.from({ length: 10 }, (_, k) => dv.getUint32(r + 4 * k, true) - 1);
    // A body with no polygons (lines only) draws nothing here.
    if (p1 < p0 || p0 < 0) continue;
    const vert = (i) => {
      const o = vertsAt + vertSize * (v0 + i);
      return floats ? [dv.getFloat32(o, true), dv.getFloat32(o + 4, true), dv.getFloat32(o + 8, true)] : [dv.getFloat64(o, true), dv.getFloat64(o + 8, true), dv.getFloat64(o + 16, true)];
    };
    const polys = [];
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (let p = p0; p <= p1 && p < np; p++) {
      const o = pgonsAt + pgonSize * p;
      const a = dv.getUint32(o + pedg, true);
      const z = dv.getUint32(o + pedg + 4, true);
      const loop = [];
      for (let k = a; k <= z && l0 + k < nl; k++) {
        const s = dv.getInt32(listAt + 4 * (l0 + k), true);
        if (!s) break; // a hole follows: its outline is left out
        const e = edgesAt + edgeSize * (e0 + Math.abs(s) - 1);
        const v = dv.getUint32(e + edgeVert + (s > 0 ? 0 : 4), true);
        if (v0 + v >= nv) return null;
        loop.push(vert(v));
      }
      if (loop.length < 3) continue;
      for (const q of loop)
        for (let i = 0; i < 3; i++) {
          if (q[i] < min[i]) min[i] = q[i];
          if (q[i] > max[i]) max[i] = q[i];
        }
      polys.push(loop);
    }
    bodies.push({ polys, min, max });
  }
  return bodies;
}
