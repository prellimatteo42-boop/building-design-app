/**
 * Excel workbooks (.xlsx, Office Open XML) written directly: one sheet per
 * table, a bold header row, numbers as numbers, through the small ZIP
 * writer. Enough for schedules.
 */
import { makeZip } from './zip.js';

const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');

/** Column letters: 0 -> A, 26 -> AA. */
export function colName(i) {
  let s = '';
  for (let n = i + 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s;
  return s;
}

/** A sheet name Excel accepts: at most 31 characters, none of []:*?/\, unique in the book. */
function sheetName(name, used) {
  let base = String(name || 'Sheet').replace(/[[\]:*?/\\]/g, ' ').trim().slice(0, 31) || 'Sheet';
  let n = base;
  for (let k = 2; used.has(n.toLowerCase()); k++) n = `${base.slice(0, 28)} ${k}`;
  used.add(n.toLowerCase());
  return n;
}

function sheetXML(rows, widths) {
  const cols = widths?.length ? `<cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${Math.max(6, Math.min(80, w))}" customWidth="1"/>`).join('')}</cols>` : '';
  const body = rows
    .map((r, ri) => {
      const cells = r.cells
        .map((v, ci) => {
          const ref = `${colName(ci)}${ri + 1}`;
          const s = r.bold ? ' s="1"' : '';
          if (typeof v === 'number' && Number.isFinite(v)) return `<c r="${ref}"${s}><v>${v}</v></c>`;
          if (v == null || v === '') return '';
          return `<c r="${ref}" t="inlineStr"${s}><is><t xml:space="preserve">${esc(v)}</t></is></c>`;
        })
        .join('');
      return `<row r="${ri + 1}">${cells}</row>`;
    })
    .join('');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>${cols}<sheetData>${body}</sheetData></worksheet>`;
}

/**
 * A workbook from sheets [{ name, rows: [{ cells: [string | number], bold }], widths: [chars] }].
 * Returns the .xlsx bytes.
 */
export function writeXLSX(sheets) {
  const used = new Set();
  const names = sheets.map((s) => sheetName(s.name, used));
  const files = [
    {
      name: '[Content_Types].xml',
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`,
    },
    { name: '_rels/.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
    {
      name: 'xl/workbook.xml',
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n, i) => `<sheet name="${esc(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`,
    },
    {
      name: 'xl/_rels/workbook.xml.rels',
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
    },
    {
      name: 'xl/styles.xml',
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`,
    },
    ...sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXML(s.rows, s.widths) })),
  ];
  return makeZip(files);
}

/**
 * The first sheet of an .xlsx workbook as rows of cell values (strings and numbers), read with the ZIP reader:
 * shared and inline strings, numbers, booleans; empty cells as ''.
 */
export async function readXLSX(bytes) {
  const all = await readXLSXSheets(bytes);
  return all.first || [];
}

/**
 * Every sheet of a workbook by name: Map(name → rows), and `.first` the rows of the first sheet listed.
 */
export async function readXLSXSheets(bytes) {
  const { readZip } = await import('./zip.js');
  const files = await readZip(bytes);
  const text = (name) => (files.get(name) ? new TextDecoder().decode(files.get(name)) : '');
  const un = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n)).replace(/&amp;/g, '&');
  const shared = [...text('xl/sharedStrings.xml').matchAll(/<si>([\s\S]*?)<\/si>/g)].map((m) => un([...m[1].matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map((t) => t[1]).join('')));
  const rel = text('xl/_rels/workbook.xml.rels');
  const targetOf = (id) => new RegExp(`Id="${id}"[^>]*Target="([^"]+)"`).exec(rel)?.[1] || new RegExp(`Target="([^"]+)"[^>]*Id="${id}"`).exec(rel)?.[1] || null;
  const colIndex = (ref) => {
    let n = 0;
    for (const ch of ref.replace(/\d+$/, '')) n = n * 26 + (ch.charCodeAt(0) - 64);
    return n - 1;
  };
  const parse = (sheet) => {
    const rows = [];
    for (const rm of sheet.matchAll(/<row[^>]*?(?:r="(\d+)")?[^>]*>([\s\S]*?)<\/row>/g)) {
      const r = [];
      for (const cm of rm[2].matchAll(/<c ([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const attrs = cm[1];
        const ref = /r="([A-Z]+\d+)"/.exec(attrs)?.[1];
        const t = /t="(\w+)"/.exec(attrs)?.[1];
        const inner = cm[2] || '';
        const v = /<v>([\s\S]*?)<\/v>/.exec(inner)?.[1];
        let val = '';
        if (t === 's') val = shared[+v] ?? '';
        else if (t === 'inlineStr') val = un([...inner.matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map((x) => x[1]).join(''));
        else if (t === 'b') val = v === '1';
        else if (t === 'str') val = un(v ?? '');
        else if (v !== undefined) val = Number.isFinite(+v) ? +v : un(v);
        r[ref ? colIndex(ref) : r.length] = val;
      }
      rows[(rm[1] ? +rm[1] : rows.length + 1) - 1] = Array.from(r, (x) => x ?? '');
    }
    return Array.from(rows, (x) => x ?? []);
  };
  const out = new Map();
  const wb = text('xl/workbook.xml');
  for (const m of wb.matchAll(/<sheet ([^>]*?)\/?>/g)) {
    const name = un(/name="([^"]*)"/.exec(m[1])?.[1] || '');
    const id = /r:id="([^"]+)"/.exec(m[1])?.[1];
    const target = id ? targetOf(id) : null;
    const xml = target ? text(`xl/${target.replace(/^\/?xl\//, '')}`) : '';
    if (xml) out.set(name, parse(xml));
  }
  if (!out.size && text('xl/worksheets/sheet1.xml')) out.set('Sheet1', parse(text('xl/worksheets/sheet1.xml')));
  out.first = [...out.values()][0] || [];
  return out;
}
