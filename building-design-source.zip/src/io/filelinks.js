/**
 * Links to files on this computer (for xrefs and external drawings): where
 * the browser has the File System Access API, the picked file's handle is
 * kept in IndexedDB under the link's id, so the file can be read again
 * later (after asking for permission) and its changes noticed. Elsewhere a
 * link is a copy: it is updated by picking the file again.
 */
import { pickFile } from './files.js';

const DB = 'bd-filelinks';
const STORE = 'handles';

function db() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') return reject(new Error('No IndexedDB'));
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function tx(mode, fn) {
  const d = await db();
  return new Promise((resolve, reject) => {
    const t = d.transaction(STORE, mode);
    const r = fn(t.objectStore(STORE));
    t.oncomplete = () => resolve(r?.result);
    t.onerror = () => reject(t.error);
  });
}

export const linksSupported = () => typeof window !== 'undefined' && typeof window.showOpenFilePicker === 'function';

/** Pick a file to link: { file, handle } (handle null where linking is not available), or null. */
export async function pickLinkedFile(accept, description = 'Drawing') {
  if (linksSupported()) {
    try {
      const exts = accept.split(',').map((x) => x.trim()).filter((x) => x.startsWith('.'));
      const [handle] = await window.showOpenFilePicker({ multiple: false, types: exts.length ? [{ description, accept: { 'application/octet-stream': exts } }] : undefined });
      return { file: await handle.getFile(), handle };
    } catch (err) {
      if (err?.name === 'AbortError') return null;
    }
  }
  const file = await pickFile(accept);
  return file ? { file, handle: null } : null;
}

export async function saveHandle(id, handle) {
  if (!handle) return;
  try {
    await tx('readwrite', (s) => s.put(handle, id));
  } catch {
    /* links are best effort */
  }
}

export async function loadHandle(id) {
  try {
    const d = await db();
    return await new Promise((resolve) => {
      const r = d.transaction(STORE, 'readonly').objectStore(STORE).get(id);
      r.onsuccess = () => resolve(r.result || null);
      r.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function dropHandle(id) {
  try {
    await tx('readwrite', (s) => s.delete(id));
  } catch {
    /* ignore */
  }
}

/**
 * The linked file now: { file } when it can be read, { state: 'permission' } when the browser must ask first
 * (ask = true asks), { state: 'missing' } when it is gone or was never linked.
 */
export async function linkedFile(id, { ask = false } = {}) {
  const handle = await loadHandle(id);
  if (!handle) return { state: 'missing' };
  try {
    let p = (await handle.queryPermission?.({ mode: 'read' })) ?? 'granted';
    if (p !== 'granted' && ask) p = await handle.requestPermission({ mode: 'read' });
    if (p !== 'granted') return { state: 'permission' };
    return { file: await handle.getFile() };
  } catch {
    return { state: 'missing' };
  }
}
