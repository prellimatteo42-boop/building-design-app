/**
 * Opening, saving and recovering projects: Puter cloud files, device files
 * and IndexedDB recovery copies (so work survives reloads without an
 * account). Projects are always stored as files.
 */
import { h, clear } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { openDialog as modal, toast, unsavedDialog, promptDialog, confirmDialog } from '../ui/dialog.js';
import { encodeProject, decodeProject, baseName, safeFileName, NATIVE_EXT } from './native.js';
import {
  cloudList,
  cloudRead,
  cloudWrite,
  isExistsError,
  deviceOpen,
  deviceSave,
  download,
  recovery,
  versions,
  acquireSessionLock,
  recentFiles as recent,
  addRecent,
  removeRecent,
  usePuterPickers,
  puterOpenPicker,
  puterSavePicker,
  CLOUD_DIR,
} from './storage.js';
import { isSignedIn, puterAvailable, whenPuter } from '../platform.js';
import { scheduleRows, scheduleColumns, toCSV, scheduleTable } from '../core/schedule.js';
import { writeXLSX } from './xlsx.js';
import { PLAN_VIEW_KINDS } from '../core/doc.js';
import { checkIntegrity, repairIntegrity } from '../core/integrity.js';

export const recentFiles = recent;

// Recovery ---------------------------------------------------------------------------------

let recoveryTimer = 0;
let ownsSession = null;

export function scheduleRecovery(app) {
  clearTimeout(recoveryTimer);
  if (app.settings?.recoveryOff) return;
  recoveryTimer = setTimeout(() => writeRecovery(app), Math.max(1, +app.settings?.recoveryDelay || 1.2) * 1000);
}

async function writeRecovery(app) {
  if (!app.doc) return;
  if (ownsSession === null) ownsSession = await acquireSessionLock();
  if (!ownsSession) return;
  try {
    const blob = await encodeProject(app.doc);
    const data = await blob.arrayBuffer();
    const meta = app.file ? { name: app.file.name, path: app.file.path || null, source: app.file.source } : null;
    await recovery.put({ id: app.docId, data, file: meta, modified: app.doc.modified, savedAt: Date.now(), name: app.file?.name || app.doc.project.name });
    await recovery.setSession({ docId: app.docId, views: app.openViews, active: app.activeViewId });
  } catch (err) {
    console.warn('Recovery copy failed', err);
  }
}

/** Restore the last session in this browser. Returns true when a project was restored. */
export async function recover(app) {
  ownsSession = await acquireSessionLock();
  if (!ownsSession) return false;
  const session = await recovery.getSession();
  if (!session?.docId) return false;
  const rec = await recovery.get(session.docId);
  if (!rec?.data) return false;
  try {
    const doc = await decodeProject(rec.data);
    if (rec.modified) doc.savedRevision = -1;
    const file = rec.file ? { ...rec.file, recoveryId: rec.id } : { recoveryId: rec.id, name: rec.name, source: 'local' };
    app.setDoc(doc, file);
    for (const id of session.views || []) if (doc.has(id)) app.openView(id);
    if (session.active && doc.has(session.active)) app.activateView(session.active);
    return true;
  } catch (err) {
    console.warn('Could not restore the last session', err);
    return false;
  }
}

// Opening ------------------------------------------------------------------------------------

export async function confirmDiscard(app) {
  if (!app.doc?.modified) return true;
  // Projects kept only in this browser are safe in the recovery store, but ask anyway.
  const r = await unsavedDialog(app.file?.name || app.doc.project.name || 'Untitled');
  if (r === 'save') return (await save(app)) !== false;
  return r === 'discard';
}

/** A copy of the project as just saved, for Previous Versions (best effort: storage may be full or missing). */
function remember(name, blob, doc) {
  versions.put(name || 'Untitled', blob, doc.items.size).catch(() => {});
}

export async function loadBuffer(app, buffer, file) {
  try {
    const doc = await decodeProject(buffer);
    await recovery.delete(app.docId);
    app.setDoc(doc, file);
    // References to elements that are not there (a damaged or hand-edited file): repaired, and said so.
    const problems = checkIntegrity(app.doc).filter((p) => p.repair);
    if (problems.length) {
      let n = 0;
      app.commit('Repair on open', () => (n = repairIntegrity(app.doc, problems)));
      toast(`${file?.name || 'The project'} had ${problems.length} broken reference${problems.length === 1 ? '' : 's'}: ${n} element${n === 1 ? '' : 's'} repaired (Undo puts them back as they were).`, { kind: 'info' });
    }
    if (file?.path) addRecent({ name: file.name, path: file.path, source: file.source });
    toast(`Opened ${file?.name || 'project'}.`, { kind: 'success' });
    return true;
  } catch (err) {
    toast(err.message || 'This file could not be opened.', { kind: 'error' });
    return false;
  }
}

export async function openCloud(app, path, name) {
  if (!(await confirmDiscard(app))) return;
  try {
    const buf = await cloudRead(path);
    await loadBuffer(app, buf, { name: baseName(name || path), path, source: 'cloud' });
  } catch (err) {
    toast(`Could not open the file: ${err.message || err}`, { kind: 'error' });
    removeRecent(path);
  }
}

export async function openRecent(app, r) {
  if (r.source === 'cloud') return openCloud(app, r.path, r.name);
  toast('Device files are opened with Open > This device.', { kind: 'info' });
}

export async function openDevice(app) {
  if (!(await confirmDiscard(app))) return;
  const f = await deviceOpen();
  if (!f) return;
  await loadBuffer(app, f.buffer, { name: baseName(f.name), handle: f.handle || null, source: 'device' });
}

/** Files passed by the Puter desktop ("Open with"). */
export async function handleLaunchItems(app) {
  try {
    if (typeof puter?.ui?.onLaunchedWithItems !== 'function') return;
    puter.ui.onLaunchedWithItems(async (items) => {
      const f = items?.[0];
      if (!f) return;
      if (!(await confirmDiscard(app))) return;
      const blob = await f.read();
      await loadBuffer(app, await blob.arrayBuffer(), { name: baseName(f.name), path: f.path, source: 'cloud' });
    });
  } catch {
    /* not launched from the desktop */
  }
}

export async function openDialog(app, tab = null) {
  if (usePuterPickers() && !tab) {
    if (!(await confirmDiscard(app))) return;
    try {
      const f = await puterOpenPicker();
      if (f) await loadBuffer(app, f.buffer, { name: baseName(f.name), path: f.path, source: 'cloud' });
    } catch (err) {
      if (err) toast(`Could not open: ${err.message || err}`, { kind: 'error' });
    }
    return;
  }
  const list = h('ul.file-list', { role: 'list' });
  const status = h('div.file-empty', { role: 'status' });
  const tabs = h('div.tabs', { role: 'tablist', 'aria-label': 'Where to open from' });
  const panel = h('div', { role: 'tabpanel' });
  let close = null;
  const show = async (which) => {
    for (const b of tabs.children) b.setAttribute('aria-selected', String(b.dataset.tab === which));
    clear(panel);
    clear(list);
    clear(status);
    if (which === 'device') {
      panel.append(
        h('p.dialog-text', 'Open a project file (.bdp) from this computer or phone.'),
        h('div', { style: { marginTop: '12px', display: 'flex', gap: '8px', flexWrap: 'wrap' } }, h('button.btn.primary', { type: 'button', onClick: () => (close?.(), openDevice(app)) }, icon('device', 16), 'Choose a file'), h('button.btn', { type: 'button', onClick: () => (close?.(), app.openPln()) }, 'Archicad project (.pln)')),
      );
      return;
    }
    if (which === 'recent') {
      const rec = recent();
      if (!rec.length) panel.append(h('p.dialog-text', 'Projects you open from Puter appear here.'));
      for (const r of rec) list.append(fileItem(r.name, new Date(r.at).toLocaleString(), r.source === 'cloud' ? 'cloud' : 'device', () => (close?.(), openRecent(app, r))));
      panel.append(list);
      return;
    }
    panel.append(status, list);
    if (!puterAvailable() || !(await whenPuter(4000))) {
      status.append(h('p', 'Puter could not be reached. Check your connection.'));
      return;
    }
    if (!(await isSignedIn())) {
      status.append(h('p', which === 'shared' ? 'Sign in to see projects other people shared with you.' : 'Sign in with Puter to keep projects in your cloud storage.'), h('button.btn.primary', { type: 'button', onClick: async () => (await app.signIn()) && show(which) }, icon('log-in', 16), 'Sign in'));
      return;
    }
    status.append(h('p', 'Loading...'));
    try {
      let items;
      if (which === 'shared') {
        const r = await puter.fs.listShared();
        items = (r?.items || []).filter((f) => !f.is_dir && /\.bdp$/i.test(f.name));
      } else items = (await cloudList()).items;
      clear(status);
      if (!items.length) status.append(h('p', which === 'shared' ? 'Nothing has been shared with you yet.' : `No projects in ${CLOUD_DIR} yet. Save a project to see it here.`));
      for (const f of items) {
        const when = f.modified ? new Date((f.modified > 1e12 ? f.modified : f.modified * 1000)).toLocaleString() : '';
        list.append(fileItem(baseName(f.name), when, which === 'shared' ? 'users' : 'cloud', () => (close?.(), openCloud(app, f.path, f.name))));
      }
    } catch (err) {
      clear(status);
      status.append(h('p', `Could not list files: ${err.message || err}`));
    }
  };
  for (const [id, label, ic] of [
    ['cloud', 'Puter', 'cloud'],
    ['shared', 'Shared with me', 'users'],
    ['device', 'This device', 'device'],
    ['recent', 'Recent', 'history'],
  ])
    tabs.append(h('button.tab', { type: 'button', role: 'tab', dataset: { tab: id }, onClick: () => show(id) }, h('span.inline', icon(ic, 14), label)));
  const body = h('div', tabs, panel);
  const p = modal({ title: 'Open Project', body, size: 'md', actions: [{ label: 'Cancel', value: null }], onClose: () => (close = null) });
  close = () => document.querySelector('dialog[open]')?._close?.(null);
  const signed = puterAvailable() && (await isSignedIn().catch(() => false));
  show(tab || (signed ? 'cloud' : 'device'));
  return p;
}

function fileItem(name, meta, ic, onClick) {
  return h('li', h('button.file-item', { type: 'button', onClick }, icon(ic, 16), h('span.file-name', name), h('span.file-meta', meta)));
}

// Saving --------------------------------------------------------------------------------------

export async function save(app) {
  if (!app.doc) return false;
  const f = app.file;
  if (f?.source === 'cloud' && f.path) return writeCloud(app, f.path, f.name);
  if (f?.source === 'device' && f.handle) return writeDevice(app, f.name, f.handle);
  return saveAs(app);
}

async function writeCloud(app, path, name) {
  // A project open from the cloud: merge in what others saved, then write.
  if (app.sync.active && app.sync.path === path) {
    const ok = await app.sync.sync({ quiet: true });
    if (ok) {
      app.updateTitle();
      scheduleRecovery(app);
      toast(`Saved ${name} to Puter.`, { kind: 'success' });
    }
    return ok;
  }
  try {
    const doc = app.doc;
    const rev = doc.revision;
    const snapshot = new Map(doc.items);
    const blob = await encodeProject(doc);
    await cloudWrite(path, blob, true);
    doc.markSaved(rev);
    remember(name, blob, doc);
    if (doc !== app.doc) return true;
    app.file = { ...app.file, name, path, source: 'cloud' };
    app.sync.attach(snapshot);
    addRecent({ name, path, source: 'cloud' });
    app.updateTitle();
    scheduleRecovery(app);
    toast(`Saved ${name} to Puter.`, { kind: 'success' });
    return true;
  } catch (err) {
    toast(`Could not save: ${err.message || err}`, { kind: 'error' });
    return false;
  }
}

async function writeDevice(app, name, handle) {
  const doc = app.doc;
  const rev = doc.revision;
  const blob = await encodeProject(doc);
  const r = await deviceSave(blob, `${safeFileName(name)}${NATIVE_EXT}`, handle);
  if (!r) return false;
  doc.markSaved(rev);
  remember(baseName(r.name), blob, doc);
  if (doc !== app.doc) return true;
  app.file = { ...app.file, name: baseName(r.name), handle: r.handle || null, source: 'device' };
  app.updateTitle();
  scheduleRecovery(app);
  toast(r.downloaded ? `Downloaded ${r.name}.` : `Saved ${r.name}.`, { kind: 'success' });
  return true;
}

export async function saveAs(app) {
  if (!app.doc) return false;
  const name0 = app.file?.name || app.doc.project.name || 'Untitled';
  if (usePuterPickers()) {
    try {
      const doc = app.doc;
      const rev = doc.revision;
      const snapshot = new Map(doc.items);
      const blob = await encodeProject(doc);
      const r = await puterSavePicker(blob, `${safeFileName(name0)}${NATIVE_EXT}`);
      if (!r) return false;
      doc.markSaved(rev);
      remember(baseName(r.name), blob, doc);
      if (doc !== app.doc) return true;
      app.file = { ...app.file, name: baseName(r.name), path: r.path, source: 'cloud', handle: null };
      app.sync.attach(snapshot);
      addRecent({ name: app.file.name, path: r.path, source: 'cloud' });
      app.updateTitle();
      scheduleRecovery(app);
      toast(`Saved ${app.file.name}.`, { kind: 'success' });
      return true;
    } catch (err) {
      toast(`Could not save: ${err.message || err}`, { kind: 'error' });
      return false;
    }
  }
  const signed = puterAvailable() && (await isSignedIn().catch(() => false));
  const choice = await modal({
    title: 'Save Project',
    size: 'sm',
    body: h(
      'div.open-sources',
      h('button.btn.big', { type: 'button', onClick: () => document.querySelector('dialog[open]')._close('cloud') }, icon('cloud', 22), h('span', h('strong', 'Puter cloud'), h('small', signed ? 'Keep it in your Puter storage, open it anywhere and share it.' : 'Sign in to keep it in your Puter storage and share it.'))),
      h('button.btn.big', { type: 'button', onClick: () => document.querySelector('dialog[open]')._close('device') }, icon('device', 22), h('span', h('strong', 'This device'), h('small', 'Save a .bdp file on this computer or phone.'))),
    ),
    actions: [{ label: 'Cancel', value: null }],
  });
  if (choice === 'device') return writeDevice(app, name0, null);
  if (choice !== 'cloud') return false;
  if (!signed && !(await app.signIn())) return false;
  const name = await promptDialog('Save to Puter', 'Project name', name0, { okLabel: 'Save', validate: (v) => (!v ? 'Enter a name.' : null) });
  if (!name) return false;
  const path = `${CLOUD_DIR}/${safeFileName(name)}${NATIVE_EXT}`;
  try {
    const blob = await encodeProject(app.doc);
    await cloudWrite(path, blob, false);
  } catch (err) {
    if (isExistsError(err)) {
      if (!(await confirmDialog('Replace project?', `"${name}" already exists in Puter. Replace it?`, { confirm: 'Replace', danger: true }))) return false;
    } else {
      toast(`Could not save: ${err.message || err}`, { kind: 'error' });
      return false;
    }
  }
  return writeCloud(app, path, safeFileName(name));
}

// Import ---------------------------------------------------------------------------------------

/** Pick a local file; resolves to a File or null. */
export function pickFile(accept) {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = accept;
    input.addEventListener('change', () => resolve(input.files?.[0] ?? null));
    input.addEventListener('cancel', () => resolve(null));
    input.click();
  });
}

/** Import a DXF drawing into the active view as detail lines and text. */
export async function importDXF(app) {
  const view = app.activeView;
  if (!view || ![...PLAN_VIEW_KINDS, 'elevation', 'section', 'sheet'].includes(view.kind)) {
    if (!app.requirePlan()) return;
  }
  const target = app.activeView;
  const file = await pickFile('.dxf');
  if (!file) return;
  const { parseDXF } = await import('./dxf.js');
  let parsed;
  try {
    parsed = parseDXF(await file.text(), app.doc.units.system === 'imperial' ? 25.4 : 1);
  } catch (err) {
    return toast(`Could not read the DXF file: ${err.message || err}`, { kind: 'error' });
  }
  const { lines, texts } = parsed;
  if (!lines.length && !texts.length) return toast('The file has no lines or text in model space.', { kind: 'error' });
  const scale = target.kind === 'sheet' ? 1 : +target.scale || 100;
  const ids = [];
  app.commit('Import DXF', () => {
    for (const [a, b] of lines) ids.push(app.doc.add({ kind: 'detailLine', viewId: target.id, a, b, style: 'thin' }).id);
    for (const t of texts) ids.push(app.doc.add({ kind: 'text', viewId: target.id, at: t.at, text: t.text, size: Math.max(1, Math.round((t.height / scale) * 10) / 10 || 2.5), rotation: t.rotation, align: 'left' }).id);
  });
  app.select(ids);
  app.vc?.zoomExtents?.(true, new Set(ids));
  toast(`Imported ${lines.length} lines and ${texts.length} texts into ${target.name}. They are selected: move them into place with Move (MV).`);
}

// Exports --------------------------------------------------------------------------------------

/** Schedules as an Excel workbook: the one given, or every schedule of the project, one sheet each. */
export function exportSchedulesXLSX(app, id = null) {
  const views = id ? [app.doc.get(id)].filter((v) => v?.kind === 'schedule') : app.doc.all('schedule');
  if (!views.length) return toast('There are no schedules to export.', { kind: 'error' });
  const bytes = writeXLSX(views.map((v) => scheduleTable(app, v)));
  const name = id ? views[0].name : `${app.doc.project?.name || 'Project'} - Schedules`;
  download(new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), `${safeFileName(name)}.xlsx`);
}

export function exportScheduleCSV(app, id) {
  const view = app.doc.get(id);
  if (!view || view.kind !== 'schedule') return;
  const cols = scheduleColumns(app.doc, view);
  const rows = scheduleRows(app, view);
  const csv = toCSV(cols, rows, app.doc.units);
  download(new Blob([csv], { type: 'text/csv' }), `${safeFileName(view.name)}.csv`);
}


/** Previous Versions: the copies kept at each save of this project (or of all), each opened as a copy. */
export async function versionsDialog(app) {
  const name = app.file?.name || app.doc?.project.name || null;
  let list = await versions.list(name);
  let all = false;
  if (!list.length) {
    list = await versions.list();
    all = true;
  }
  const fmt = (t) => new Date(t).toLocaleString();
  const size = (b) => (b > 1e6 ? `${(b / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1e3))} KB`);
  const body = h('div');
  if (!list.length) body.append(h('p', 'No saved versions yet: a copy is kept here each time a project is saved (the latest 20 of each).'));
  else {
    body.append(h('p', all ? 'No copies of this project yet; copies of other projects:' : `Copies of ${name} kept at each save (the latest 20). Opening one opens it as a copy; the project file is not changed.`));
    const table = h('table.table', h('thead', h('tr', h('th', 'Project'), h('th', 'Saved'), h('th', 'Elements'), h('th', 'Size'), h('th', ''))));
    const tb = h('tbody');
    for (const v of list) {
      const open = h('button.btn.sm', { type: 'button' }, 'Open as copy');
      open.addEventListener('click', async () => {
        if (!(await confirmDiscard(app))) return;
        const rec = await versions.get(v.id);
        if (!rec) return toast('That copy is no longer there.', { kind: 'error' });
        open.closest('dialog')?.querySelector('.dialog-x')?.click();
        await loadBuffer(app, rec.bytes.buffer, { name: `${v.name} (${fmt(v.at)})`, source: 'device' });
      });
      tb.append(h('tr', h('td', v.name), h('td', fmt(v.at)), h('td', String(v.count)), h('td', size(v.size)), h('td', open)));
    }
    table.append(tb);
    body.append(table);
  }
  return modal({ title: 'Previous Versions', body, actions: [{ label: 'Close', value: null }] });
}
