/**
 * Skylight tool: click on a roof to put a skylight there, lying on the
 * slope under the point (core/skylight.js).
 */
import { Tool } from './tool.js';
import { lengthField } from './draw.js';
import { skylightGeometry } from '../core/skylight.js';
import { roofGeometry } from '../core/build3d.js';
import { fillModel, strokeModel } from '../views/overlay.js';
import { pointInPolygon } from '../core/geom.js';
import { PLAN_VIEW_KINDS } from '../core/doc.js';

export class SkylightTool extends Tool {
  get placingKind() {
    return 'skylight';
  }

  get viewKinds() {
    return PLAN_VIEW_KINDS;
  }

  get title() {
    return 'Skylight';
  }

  get prompt() {
    return 'Click on a roof to place a skylight';
  }

  get o() {
    const imp = this.app.doc.units.system === 'imperial';
    return this.app.toolOptions('skylight', { width: imp ? 762 : 780, length: imp ? 1194 : 980 });
  }

  options() {
    const o = this.o;
    return [lengthField(this, 'Width', o.width, (v) => (o.width = Math.max(200, v))), lengthField(this, 'Length', o.length, (v) => (o.length = Math.max(200, v)))];
  }

  /** The roof under p: the one whose footprint holds it, on any level (the highest). */
  roofAt(p) {
    let best = null;
    for (const r of this.doc.all('roof')) {
      if (!r.boundary?.length) continue;
      const g = roofGeometry(this.doc, r);
      if (pointInPolygon(p, g.poly) && (!best || g.base > best.base)) best = { r, base: g.base };
    }
    return best?.r ?? null;
  }

  candidate(p) {
    const roof = p && this.roofAt(p);
    return roof ? { kind: 'skylight', hostId: roof.id, levelId: roof.levelId, at: p, width: this.o.width, length: this.o.length } : null;
  }

  down(ev) {
    const p = this.snap(ev);
    const el = this.candidate(p);
    if (!el) return this.app.toast('Click inside a roof.', { kind: 'error' });
    this.app.commit('Skylight', () => this.doc.add(el));
  }

  move(ev) {
    this.cursor = this.snap(ev);
    this.app.requestRender();
  }

  drawOverlay(ctx, vc, vp) {
    this.drawSnap?.(ctx, vc, vp);
    const el = this.cursor && this.candidate(this.cursor);
    const s = el && skylightGeometry(this.doc, el);
    if (!s) return;
    const S = (q) => vc.modelToScreen(q);
    fillModel(ctx, s.poly, S, vp.theme.preview, 0.15);
    strokeModel(ctx, s.poly, S, vp.theme.preview, 1.4, null, true);
  }
}
