/**
 * Calibrate Image: give a placed picture (a scanned or photographed floor
 * plan) its true scale by clicking two points on it and typing the length
 * between them, as with Archicad's drawing scale from a known dimension.
 */
import { turnTrace } from '../core/trace.js';
import { Tool } from './tool.js';
import { dist } from '../core/geom.js';
import { calibrateImagePatch, modelPointToImage } from '../core/floorplan.js';
import { strokeModel, drawTempDim } from '../views/overlay.js';
import { h } from '../ui/dom.js';

export class CalibrateImageTool extends Tool {
  get title() {
    return 'Calibrate Image';
  }

  get prompt() {
    if (!this.image) return 'Select an image first, or place one with File > Image';
    return this.a ? 'Click the other end of a length you know' : 'Click one end of a length you know on the image (a dimension or a door width)';
  }

  start() {
    const v = this.app.activeView;
    const images = this.doc.all('image').filter((i) => i.viewId === v?.id);
    const sel = [...this.app.selection].map((id) => this.doc.get(id)).find((e) => e?.kind === 'image');
    this.image = sel || (images.length === 1 ? images[0] : null);
    this.app.setPrompt(this.prompt);
  }

  down(ev) {
    if (!this.image) return this.app.setPrompt(this.prompt);
    const p = this.snap(ev, this.a || null);
    if (!p) return;
    if (!this.a) {
      this.a = p;
      return this.app.setPrompt(this.prompt);
    }
    if (dist(this.a, p) < 1) return;
    this.b = p;
    const a = this.a;
    this.openInput(ev.x, ev.y, {
      label: 'True length',
      value: '',
      onSubmit: (text) => {
        const d = this.parseLen(text);
        if (!(d > 0)) return false;
        const img = this.doc.get(this.image.id);
        const patch = calibrateImagePatch(img, modelPointToImage(img, a), modelPointToImage(img, p), d);
        if (!patch) return false;
        this.app.commit('Calibrate image', () => this.doc.update(img.id, patch));
        this.app.toast(`Image scaled: those points are now ${this.fmt(d)} apart.`, { kind: 'success' });
        this.a = this.b = null;
        this.app.cancelTool(true);
        return true;
      },
      onCancel: () => {
        this.b = null;
        this.app.requestRender();
      },
    });
  }

  move(ev) {
    this.cursor = this.snap(ev, this.a || null);
    this.app.requestRender();
  }

  cancel() {
    if (this.a) {
      this.a = this.b = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    const b = this.b || this.cursor;
    if (this.a && b && dist(this.a, b) > 0.5) {
      strokeModel(ctx, [this.a, b], S, vp.theme.snap, 2);
      drawTempDim(ctx, S(this.a), S(b), this.fmt(dist(this.a, b)), vp.theme.snap, vp.theme, -18);
    }
    this.drawSnap(ctx, vc, vp);
  }
}

/** Move Reference: move the traced drawing by two clicks, from a point to where it should be. */
/** Erase Guide Line: click a guide to remove it. */
export class EraseGuideTool extends Tool {
  get title() {
    return 'Erase Guide Line';
  }

  get prompt() {
    return 'Click a guide line to remove it';
  }

  down(ev) {
    const id = this.app.activeViewId;
    const list = this.app.guides.get(id) || [];
    const tol = 8 / this.vc.cam.zoom;
    const i = list.findIndex((g) => Math.abs((ev.p[0] - g.p[0]) * g.d[1] - (ev.p[1] - g.p[1]) * g.d[0]) < tol);
    if (i < 0) return;
    this.app.guides.set(id, list.filter((_, k) => k !== i));
    this.app.requestRender();
  }
}

/** Rotate Reference: the centre, a point to turn from, and where it goes. */
export class RotateReferenceTool extends Tool {
  get title() {
    return 'Rotate Reference';
  }

  get prompt() {
    return !this.c ? 'Click the centre of rotation' : !this.from ? 'Click a point of the reference to turn' : 'Click where that point goes';
  }

  start() {
    this.c = null;
    this.from = null;
    if (!this.app.traces.get(this.app.activeViewId)?.on) this.app.setPrompt('Turn on Trace & Reference first (Window menu).');
    else this.app.setPrompt(this.prompt);
  }

  down(ev) {
    const t = this.app.traces.get(this.app.activeViewId);
    if (!t?.on) return;
    const p = this.snap(ev, this.c || null);
    if (!p) return;
    if (!this.c) this.c = p;
    else if (!this.from) {
      if (dist(p, this.c) < 1) return;
      this.from = p;
    } else {
      const deg = (Math.atan2(p[1] - this.c[1], p[0] - this.c[0]) - Math.atan2(this.from[1] - this.c[1], this.from[0] - this.c[0])) * (180 / Math.PI);
      this.app.traces.set(this.app.activeViewId, { ...t, ...turnTrace(t, this.c, deg) });
      this.app.tracePalette?.render();
      this.app.cancelTool(true);
      this.app.requestRender();
      return;
    }
    this.app.setPrompt(this.prompt);
  }

  move(ev) {
    this.cursor = this.snap(ev, this.c || null);
    this.app.requestRender();
  }

  cancel() {
    if (this.c) {
      this.c = null;
      this.from = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    if (this.c && this.cursor) strokeModel(ctx, [this.c, this.from || this.cursor], S, vp.theme.snapCss || vp.theme.selCss || '#1f6fff');
    if (this.c && this.from && this.cursor) strokeModel(ctx, [this.c, this.cursor], S, vp.theme.snapCss || vp.theme.selCss || '#1f6fff');
    this.drawSnap(ctx, vc, vp);
  }
}

export class MoveReferenceTool extends Tool {
  get title() {
    return 'Move Reference';
  }

  get prompt() {
    return this.a ? 'Click where that point of the reference goes' : 'Click a point of the reference to move it';
  }

  start() {
    if (!this.app.traces.get(this.app.activeViewId)?.on) this.app.setPrompt('Turn on Trace & Reference first (Window menu).');
    else this.app.setPrompt(this.prompt);
  }

  down(ev) {
    const t = this.app.traces.get(this.app.activeViewId);
    if (!t?.on) return;
    const p = this.snap(ev, this.a || null);
    if (!p) return;
    if (!this.a) {
      this.a = p;
      return this.app.setPrompt(this.prompt);
    }
    const o = t.offset || [0, 0];
    this.app.traces.set(this.app.activeViewId, { ...t, ...(this.opts?.temporary && !t.tempFrom ? { tempFrom: o } : {}), offset: [o[0] + p[0] - this.a[0], o[1] + p[1] - this.a[1]] });
    this.a = null;
    this.app.tracePalette?.render();
    this.app.cancelTool(true);
    this.app.requestRender();
  }

  move(ev) {
    this.cursor = this.snap(ev, this.a || null);
    this.app.requestRender();
  }

  cancel() {
    if (this.a) {
      this.a = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    if (this.a && this.cursor && dist(this.a, this.cursor) > 0.5) strokeModel(ctx, [this.a, this.cursor], S, vp.theme.snap, 1.5, [6, 4]);
    this.drawSnap(ctx, vc, vp);
  }
}

/**
 * Guide Line: an infinite line through two clicked points, or a horizontal
 * or vertical one through one point, shown dashed in the view and snapped
 * to like any line. Remove Guide Lines clears them.
 */
export class GuideLineTool extends Tool {
  get title() {
    return 'Guide Line';
  }

  get o() {
    return this.app.toolOptions('guideLine', { mode: 'two' });
  }

  get prompt() {
    if (this.o.mode === 'segment') return this.a ? 'Click the end of the guide segment' : 'Click the start of the guide segment';
    if (this.o.mode !== 'two') return `Click where the ${this.o.mode === 'h' ? 'horizontal' : 'vertical'} guide line goes`;
    return this.a ? 'Click a second point to set its direction' : 'Click a point the guide line passes through';
  }

  options() {
    const o = this.o;
    const sel = h('select.input.sm', { 'aria-label': 'Guide line' }, h('option', { value: 'two' }, 'Through two points'), h('option', { value: 'segment' }, 'Segment (between two points)'), h('option', { value: 'h' }, 'Horizontal'), h('option', { value: 'v' }, 'Vertical'));
    sel.value = o.mode;
    sel.addEventListener('change', () => {
      o.mode = sel.value;
      this.a = null;
      this.app.setPrompt(this.prompt);
    });
    const count = this.app.guides.get(this.app.activeViewId)?.length || 0;
    return [h('div.ob-group', h('label', 'Guide'), sel), h('button.btn.sm', { type: 'button', disabled: !count, onClick: () => this.app.run('removeGuides') }, `Remove All (${count})`)];
  }

  add(p, d, seg = null) {
    const id = this.app.activeViewId;
    const l = Math.hypot(d[0], d[1]);
    if (!id || l < 1e-9) return;
    this.app.guides.set(id, [...(this.app.guides.get(id) || []), { p, d: [d[0] / l, d[1] / l], ...(seg ? { seg } : {}) }]);
    this.app.renderOptions();
    this.app.requestRender();
  }

  down(ev) {
    const p = this.snap(ev, this.a || null);
    if (!p) return;
    if (this.o.mode === 'h') return this.add(p, [1, 0]);
    if (this.o.mode === 'v') return this.add(p, [0, 1]);
    if (!this.a) {
      this.a = p;
      return this.app.setPrompt(this.prompt);
    }
    if (dist(this.a, p) < 1) return;
    // A guide segment (Archicad's Create Guide Line Segment) runs only between its two points.
    this.add(this.a, [p[0] - this.a[0], p[1] - this.a[1]], this.o.mode === 'segment' ? [this.a, p] : null);
    this.a = null;
    this.app.setPrompt(this.prompt);
  }

  move(ev) {
    this.cursor = this.snap(ev, this.a || null);
    this.app.requestRender();
  }

  cancel() {
    if (this.a) {
      this.a = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    if (this.a && this.cursor && dist(this.a, this.cursor) > 0.5) strokeModel(ctx, [this.a, this.cursor], S, vp.theme.snap, 1, [8, 5]);
    this.drawSnap(ctx, vc, vp);
  }
}
