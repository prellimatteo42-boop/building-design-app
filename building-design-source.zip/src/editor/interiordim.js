/**
 * Interior Dimensioning tool: click the two ends of a line across walls;
 * a dimension chain through every wall face it crosses is placed on that
 * line (core/autodim.js). The tool stays on for the next line.
 */
import { Tool } from './tool.js';
import { strokeModel } from '../views/overlay.js';
import { interiorDimension } from '../core/autodim.js';

export class InteriorDimTool extends Tool {
  get title() {
    return 'Interior Dimensioning';
  }

  get viewKinds() {
    return ['plan'];
  }

  get prompt() {
    return this.first ? 'Click the other end of the line across the walls' : 'Click the start of a line across the walls to dimension';
  }

  walls() {
    const levelId = this.vc.view.levelId;
    return this.doc.all('wall').filter((w) => w.levelId === levelId);
  }

  down(ev) {
    const p = this.snap(ev, this.first);
    if (!p) return;
    if (!this.first) {
      this.first = p;
      this.app.setPrompt(this.prompt);
      return;
    }
    const a = this.first;
    this.first = null;
    const dim = interiorDimension(this.doc, this.walls(), a, p, this.vc.view.id);
    if (!dim) {
      this.app.toast('The line crosses no walls to dimension.', { kind: 'error' });
      return;
    }
    this.app.commit('Interior dimension', () => this.doc.add(dim));
    this.app.setPrompt(this.prompt);
  }

  move(ev) {
    this.cursor = this.snap(ev, this.first);
    this.app.requestRender();
  }

  cancel() {
    if (this.first) {
      this.first = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    this.drawSnap?.(ctx, vc, vp);
    if (this.first && this.cursor) strokeModel(ctx, [this.first, this.cursor], (q) => vc.modelToScreen(q), vp.theme.preview, 1.5, [6, 4]);
  }
}
