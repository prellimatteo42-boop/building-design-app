/**
 * Modify tools working on the selection: move, copy, rotate, mirror, array,
 * align, offset, trim/extend, split, measure, match type.
 */
import { multiply, multiplyMirror, spreadStep } from '../core/multiply.js';
import { createGroup, groupable } from '../core/groups.js';
import { Tool, isNumericStart } from './tool.js';
import { add, sub, scale, dot, norm, perp, dist, len, angleOf, closestOnSegment, cross } from '../core/geom.js';
import {
  transformElements,
  copyElements,
  arrayRadial,
  translation,
  rotation,
  mirrorAcross,
  splitLinear,
  scaling,
  cornerWalls,
  extendToLine,
  offsetElement,
  moveElements,
} from '../core/ops.js';
import { formatAngle, parseAngleDegrees, formatArea } from '../core/units.js';
import { strokeModel, drawTempDim, drawTag } from '../views/overlay.js';
import { previewGraphics, ANNOTATION_VIEWS } from './draw.js';
import { h } from '../ui/dom.js';

function selectionIds(app) {
  return [...app.selection].filter((id) => {
    const el = app.doc.get(id);
    return el && el.id !== 'project' && el.kind !== 'level';
  });
}

function checkbox(label, value, onChange) {
  const c = h('input', { type: 'checkbox', checked: value });
  c.addEventListener('change', () => onChange(c.checked));
  return h('label.ob-group', c, h('span.ob-label', label));
}

/** Tools that need a selection first. */
class SelectionTool extends Tool {
  start() {
    this.ids = selectionIds(this.app);
    if (!this.ids.length) {
      this.app.toast('Select elements first, then choose this tool.', { kind: 'error' });
      this.app.cancelTool();
      return false;
    }
    this.exclude = new Set(this.ids);
    return true;
  }

  /** Preview the transformed selection on the overlay. */
  preview(ctx, vc, vp, xf) {
    for (const id of this.ids.slice(0, 200)) {
      const el = this.doc.get(id);
      if (!el || el.hostId) continue;
      const moved = { ...el };
      const patch = this.patchFor(el, xf);
      Object.assign(moved, patch);
      previewGraphics(this.app, vc, moved, ctx, vp.theme.preview, 0.08);
    }
  }

  patchFor(el, xf) {
    const holder = { patch: {} };
    // Reuse the transform without touching the document.
    const fakeDoc = { update: (_id, p) => (holder.patch = p), get: (id) => this.doc.get(id), all: (...k) => this.doc.all(...k) };
    transformElements(fakeDoc, [el.id], xf);
    return holder.patch;
  }
}

export class MoveTool extends SelectionTool {
  constructor(app, opts) {
    super(app, opts);
    this.copy = !!opts.copy;
    this.multiple = !!opts.copy;
    // The Pet palette starts from the clicked point.
    this.base = opts.base ?? null;
  }

  get title() {
    return this.copy ? 'Copy' : 'Move';
  }

  get prompt() {
    return this.base ? 'Click the destination, or type a distance' : 'Click the start point (base point) of the move';
  }

  options() {
    return [
      checkbox('Copy', this.copy, (v) => {
        this.copy = v;
        this.app.renderOptions();
      }),
      this.copy ? checkbox('Multiple', this.multiple, (v) => (this.multiple = v)) : null,
    ];
  }

  down(ev) {
    const p = this.snap(ev, this.base, { exclude: this.exclude });
    if (!p) return;
    if (!this.base) {
      this.base = p;
      this.app.setPrompt(this.prompt);
      return;
    }
    this.apply(sub(p, this.base));
  }

  apply(d) {
    if (this.copy) {
      let ids;
      this.app.commit('Copy', () => (ids = copyElements(this.doc, this.ids, translation(d))));
      if (!this.multiple) {
        this.app.select(ids);
        this.app.cancelTool();
      }
    } else {
      this.app.commit('Move', () => moveElements(this.doc, this.ids, d));
      this.app.cancelTool();
    }
  }

  move(ev) {
    this.cursor = this.snap(ev, this.base, { exclude: this.exclude });
    this.app.requestRender();
  }

  key(e) {
    if (this.base && isNumericStart(e)) {
      e.preventDefault();
      const s = this.vc.modelToScreen(this.cursor || this.base);
      const input = this.openInput(s.x, s.y, {
        label: 'Distance',
        onSubmit: (v) => {
          const L = this.parseLen(v);
          if (!Number.isFinite(L)) return false;
          const d = norm(sub(this.cursor || add(this.base, [1, 0]), this.base));
          this.apply(scale(len(d) ? d : [1, 0], L));
          return true;
        },
      });
      input.value = e.key;
      return true;
    }
    return false;
  }

  drawOverlay(ctx, vc, vp) {
    if (this.base && this.cursor) {
      const d = sub(this.cursor, this.base);
      this.preview(ctx, vc, vp, translation(d));
      const S = (p) => vc.modelToScreen(p);
      strokeModel(ctx, [this.base, this.cursor], S, vp.theme.preview, 1.2, [5, 4]);
      drawTempDim(ctx, S(this.base), S(this.cursor), this.fmt(len(d)), vp.theme.preview, vp.theme, -18);
    }
    this.drawSnap(ctx, vc, vp);
  }
}

export class RotateTool extends SelectionTool {
  start() {
    if (!super.start()) return false;
    const b = this.vc.extents?.(new Set(this.ids));
    this.center = this.opts.center ?? (b ? [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2] : [0, 0]);
    this.copy = false;
    return true;
  }

  get title() {
    return 'Rotate';
  }

  get prompt() {
    if (this.placing) return 'Click the center of rotation';
    return this.ray ? 'Click to end the rotation, or type an angle' : 'Click the start ray, or type an angle. Click "Place center" to move the center.';
  }

  options() {
    const ang = h('input.input.sm.num', { type: 'text', placeholder: '90°', 'aria-label': 'Angle in degrees' });
    ang.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') {
        const a = (parseAngleDegrees(ang.value, this.doc.units) * Math.PI) / 180;
        if (Number.isFinite(a)) this.apply(a);
      }
    });
    return [
      checkbox('Copy', this.copy, (v) => (this.copy = v)),
      h('button.btn.sm', { type: 'button', onClick: () => ((this.placing = true), this.app.setPrompt(this.prompt)) }, 'Place center'),
      h('div.ob-group', h('label', 'Angle'), ang),
    ];
  }

  down(ev) {
    const p = this.snap(ev, this.center, { exclude: this.exclude });
    if (!p) return;
    if (this.placing) {
      this.center = p;
      this.placing = false;
    } else if (!this.ray) this.ray = p;
    else {
      const a = angleOf(sub(p, this.center)) - angleOf(sub(this.ray, this.center));
      this.apply(a);
      return;
    }
    this.app.setPrompt(this.prompt);
  }

  apply(a) {
    const xf = rotation(this.center, a);
    if (this.copy) this.app.commit('Rotate copy', () => copyElements(this.doc, this.ids, xf));
    else this.app.commit('Rotate', () => transformElements(this.doc, this.ids, xf));
    this.app.cancelTool();
  }

  move(ev) {
    this.cursor = this.snap(ev, this.center, { exclude: this.exclude });
    this.app.requestRender();
  }

  key(e) {
    if (isNumericStart(e)) {
      e.preventDefault();
      const s = this.vc.modelToScreen(this.cursor || this.center);
      const input = this.openInput(s.x, s.y, {
        label: 'Angle',
        onSubmit: (v) => {
          const a = (parseAngleDegrees(v, this.doc.units) * Math.PI) / 180;
          if (!Number.isFinite(a)) return false;
          this.apply(a);
          return true;
        },
      });
      input.value = e.key;
      return true;
    }
    return false;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    const c = S(this.center);
    ctx.save();
    ctx.strokeStyle = vp.theme.preview;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(c.x, c.y, 7, 0, Math.PI * 2);
    ctx.moveTo(c.x - 11, c.y);
    ctx.lineTo(c.x + 11, c.y);
    ctx.moveTo(c.x, c.y - 11);
    ctx.lineTo(c.x, c.y + 11);
    ctx.stroke();
    ctx.restore();
    if (this.ray) strokeModel(ctx, [this.center, this.ray], S, vp.theme.preview, 1.2);
    if (this.ray && this.cursor) {
      const a = angleOf(sub(this.cursor, this.center)) - angleOf(sub(this.ray, this.center));
      strokeModel(ctx, [this.center, this.cursor], S, vp.theme.preview, 1.2, [5, 4]);
      this.preview(ctx, vc, vp, rotation(this.center, a));
      const s = S(this.cursor);
      let deg = a;
      while (deg > Math.PI) deg -= Math.PI * 2;
      while (deg < -Math.PI) deg += Math.PI * 2;
      drawTag(ctx, s.x + 30, s.y + 20, formatAngle(deg, 1, this.doc.units), { bg: vp.theme.bgCss, fg: vp.theme.inkCss, border: vp.theme.preview });
    }
    this.drawSnap(ctx, vc, vp);
  }
}

export class MirrorTool extends SelectionTool {
  constructor(app, opts) {
    super(app, opts);
    this.draw = !!opts.draw;
    this.copy = true;
    this.axisStart = opts.axisStart ?? null;
  }

  get title() {
    return this.draw ? 'Mirror - Draw Axis' : 'Mirror - Pick Axis';
  }

  get prompt() {
    if (!this.draw) return 'Click a line, wall or grid to mirror about';
    return this.axisStart ? 'Click the end of the mirror axis' : 'Click the start of the mirror axis';
  }

  options() {
    return [checkbox('Copy', this.copy, (v) => (this.copy = v))];
  }

  axisFrom(ev) {
    this.snap(ev, this.axisStart, { exclude: this.exclude });
    const line = this.snapRes?.ref?.line || this.snapRes?.line;
    return line ? [line.a, line.b] : null;
  }

  down(ev) {
    if (!this.draw) {
      const ax = this.axisFrom(ev);
      if (!ax) return;
      return this.apply(ax[0], ax[1]);
    }
    const p = this.snap(ev, this.axisStart, { exclude: this.exclude });
    if (!p) return;
    if (!this.axisStart) {
      this.axisStart = p;
      this.app.setPrompt(this.prompt);
      return;
    }
    if (dist(p, this.axisStart) < 1) return;
    this.apply(this.axisStart, p);
  }

  apply(a, b) {
    const xf = mirrorAcross(a, b);
    if (this.copy) this.app.commit('Mirror', () => copyElements(this.doc, this.ids, xf));
    else this.app.commit('Mirror', () => transformElements(this.doc, this.ids, xf));
    this.app.cancelTool();
  }

  move(ev) {
    if (this.draw) this.cursor = this.snap(ev, this.axisStart, { exclude: this.exclude });
    else this.hoverAxis = this.axisFrom(ev);
    this.app.requestRender();
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    const ax = this.draw ? (this.axisStart && this.cursor && dist(this.axisStart, this.cursor) > 1 ? [this.axisStart, this.cursor] : null) : this.hoverAxis;
    if (ax) {
      const d = norm(sub(ax[1], ax[0]));
      const L = 1e5;
      strokeModel(ctx, [add(ax[0], scale(d, -L)), add(ax[0], scale(d, L))], S, vp.theme.preview, 1.2, [10, 4, 2, 4]);
      this.preview(ctx, vc, vp, mirrorAcross(ax[0], ax[1]));
    }
    this.drawSnap(ctx, vc, vp);
  }
}

export class ArrayTool extends SelectionTool {
  constructor(app, opts) {
    super(app, opts);
    this.count = app.toolOptions('array', { count: 3 }).count;
    this.base = opts.base ?? null;
  }

  get title() {
    return 'Array';
  }

  get o() {
    return this.app.toolOptions('array', { count: 3, mode: 'linear', angle: 360 });
  }

  get prompt() {
    if (this.o.mode === 'radial') return 'Click the center to turn the copies about';
    if (this.o.mode === 'mirror') return this.base ? 'Click the second point of the mirror axis' : 'Click the first point of the mirror axis';
    if (this.o.method === 'spread') return this.base ? 'Click the end of the path to fill' : 'Click the start point';
    const spread = this.o.method === 'distribute';
    if (this.o.mode === 'matrix' && this.v1) return spread ? 'Click the far end of the rows' : 'Click the position of the first item of the second row';
    return this.base ? (spread ? 'Click the position of the last item' : 'Click the position of the second item') : 'Click the start point';
  }

  options() {
    const o = this.o;
    const inp = h('input.input.sm.num', { type: 'number', min: 2, max: 200, value: o.count, 'aria-label': 'Number of items' });
    inp.addEventListener('change', () => (o.count = this.count = Math.max(2, Math.min(200, Math.round(+inp.value || 2)))));
    inp.addEventListener('keydown', (e) => e.stopPropagation());
    const mode = h('select.input.sm', { 'aria-label': 'Array type' }, h('option', { value: 'linear' }, 'Linear'), h('option', { value: 'matrix' }, 'Matrix'), h('option', { value: 'radial' }, 'Radial'), h('option', { value: 'mirror' }, 'Mirror'));
    mode.value = o.mode;
    mode.addEventListener('change', () => {
      o.mode = mode.value;
      this.base = null;
      this.app.renderOptions();
      this.app.setPrompt(this.prompt);
    });
    const out = [h('div.ob-group', h('label', 'Type'), mode), h('div.ob-group', h('label', 'Number of items'), inp)];
    if (o.mode === 'mirror') {
      const dz = h('input.input.sm.num', { type: 'number', step: 10, value: o.dz || 0, 'aria-label': 'Elevation step in mm' });
      dz.addEventListener('change', () => (o.dz = +dz.value || 0));
      dz.addEventListener('keydown', (e) => e.stopPropagation());
      out.push(h('div.ob-group', h('label', 'Elevation'), dz));
    }
    if (o.mode !== 'radial' && o.mode !== 'mirror') {
      // Multiply's spacing method, a second row for a matrix, and an elevation step between copies.
      const method = h('select.input.sm', { 'aria-label': 'Spacing' }, h('option', { value: 'increment' }, 'Increment'), h('option', { value: 'distribute' }, 'Distribute'), h('option', { value: 'spread' }, 'Spread'));
      method.value = o.method || 'increment';
      method.addEventListener('change', () => {
        o.method = method.value;
        this.app.renderOptions();
        this.app.setPrompt(this.prompt);
      });
      out.push(h('div.ob-group', h('label', 'Spacing'), method));
      if (o.method === 'spread') {
        // Spread: copies at this spacing, as many as fit along the path.
        const sp = h('input.input.sm.num', { type: 'number', min: 1, step: 10, value: o.spacing || 1000, 'aria-label': 'Spacing between copies in mm' });
        sp.addEventListener('change', () => (o.spacing = Math.max(1, +sp.value || 1000)));
        sp.addEventListener('keydown', (e) => e.stopPropagation());
        out.push(h('div.ob-group', h('label', 'Distance'), sp));
      }
      if (o.mode === 'matrix') {
        const n2 = h('input.input.sm.num', { type: 'number', min: 1, max: 200, value: o.count2 || 2, 'aria-label': 'Number of rows' });
        n2.addEventListener('change', () => (o.count2 = Math.max(1, Math.min(200, Math.round(+n2.value || 1)))));
        n2.addEventListener('keydown', (e) => e.stopPropagation());
        out.push(h('div.ob-group', h('label', 'Rows'), n2));
      }
      const dz = h('input.input.sm.num', { type: 'number', step: 10, value: o.dz || 0, 'aria-label': 'Elevation step in mm' });
      dz.addEventListener('change', () => (o.dz = +dz.value || 0));
      dz.addEventListener('keydown', (e) => e.stopPropagation());
      out.push(h('div.ob-group', h('label', 'Elevation'), dz));
    }
    if (o.mode === 'radial') {
      const ang = h('input.input.sm.num', { type: 'number', min: -360, max: 360, value: o.angle, 'aria-label': 'Total angle in degrees' });
      ang.addEventListener('change', () => (o.angle = Math.max(-360, Math.min(360, +ang.value || 360))));
      ang.addEventListener('keydown', (e) => e.stopPropagation());
      out.push(h('div.ob-group', h('label', 'Angle'), ang));
    }
    return out;
  }

  /** Archicad's Autogroup: the elements made in one go (the originals and their copies) become a group. */
  autogroup(copies) {
    if (!this.app.settings.autogroup || !copies?.length) return;
    const ids = [...this.ids, ...copies].filter((id) => groupable(this.doc.get(id)) && !this.doc.get(id)?.groupId);
    if (ids.length > 1) createGroup(this.doc, ids, { name: 'Multiply', levelId: this.doc.get(ids[0])?.levelId });
  }

  down(ev) {
    const p = this.snap(ev, this.base, { exclude: this.exclude });
    if (!p) return;
    if (this.o.mode === 'radial') {
      const o = this.o;
      this.app.commit('Radial array', () => this.autogroup(arrayRadial(this.doc, this.ids, p, o.count, (o.angle * Math.PI) / 180)));
      this.app.cancelTool();
      return;
    }
    if (!this.base) {
      this.base = p;
      this.app.setPrompt(this.prompt);
      return;
    }
    const d = sub(p, this.base);
    const o = this.o;
    if (o.mode === 'mirror') {
      const a = this.base;
      this.app.commit('Multiply (mirror)', () => this.autogroup(multiplyMirror(this.doc, this.ids, a, p, { n: this.count, dz: +o.dz || 0 })));
      this.app.cancelTool();
      return;
    }
    if (o.mode === 'matrix' && !this.v1) {
      this.v1 = d;
      this.app.setPrompt(this.prompt);
      return;
    }
    const opts = o.mode === 'matrix' ? { d1: this.v1, n1: this.count, d2: d, n2: o.count2 || 2 } : { d1: d, n1: this.count };
    this.app.commit('Multiply', () => this.autogroup(multiply(this.doc, this.ids, { ...opts, dz: +o.dz || 0, method: o.method || 'increment', spacing: +o.spacing || 1000 })));
    this.app.cancelTool();
  }

  move(ev) {
    this.cursor = this.snap(ev, this.base, { exclude: this.exclude });
    this.app.requestRender();
  }

  drawOverlay(ctx, vc, vp) {
    if (this.o.mode === 'radial' && this.cursor) {
      const o = this.o;
      const sweep = (o.angle * Math.PI) / 180;
      const full = Math.abs(Math.abs(sweep) - Math.PI * 2) < 1e-6;
      const step = full ? sweep / o.count : sweep / Math.max(1, o.count - 1);
      for (let i = 1; i < Math.min(o.count, 60); i++) this.preview(ctx, vc, vp, rotation(this.cursor, step * i));
    } else if (this.o.mode === 'mirror' && this.base && this.cursor) {
      const S = (p) => vc.modelToScreen(p);
      ctx.save();
      ctx.strokeStyle = vp.theme.preview;
      ctx.setLineDash([8, 4]);
      ctx.beginPath();
      ctx.moveTo(...S(this.base));
      ctx.lineTo(...S(this.cursor));
      ctx.stroke();
      ctx.restore();
      if (len(sub(this.cursor, this.base)) > 1) this.preview(ctx, vc, vp, mirrorAcross(this.base, this.cursor));
    } else if (this.base && this.cursor && this.o.method === 'spread' && !this.v1) {
      const { n, step } = spreadStep(sub(this.cursor, this.base), +this.o.spacing || 1000);
      for (let i = 1; i < Math.min(n, 60); i++) this.preview(ctx, vc, vp, translation(scale(step, i)));
      const S = (p) => vc.modelToScreen(p);
      drawTempDim(ctx, S(this.base), S(this.cursor), `${n} × ${this.fmt(+this.o.spacing || 1000)}`, vp.theme.preview, vp.theme, -18);
    } else if (this.base && this.cursor) {
      const d = sub(this.cursor, this.base);
      const spread = (v, n) => (this.o.method === 'distribute' && n > 1 ? scale(v, 1 / (n - 1)) : v);
      if (this.v1) {
        const s1 = spread(this.v1, this.count);
        const n2 = this.o.count2 || 2;
        const s2 = spread(d, n2);
        for (let j = 0; j < Math.min(n2, 20); j++) for (let i = 0; i < Math.min(this.count, 20); i++) if (i || j) this.preview(ctx, vc, vp, translation(add(scale(s1, i), scale(s2, j))));
      } else for (let i = 1; i < Math.min(this.count, 30); i++) this.preview(ctx, vc, vp, translation(scale(spread(d, this.count), i)));
      const S = (p) => vc.modelToScreen(p);
      drawTempDim(ctx, S(this.base), S(this.cursor), this.fmt(len(d)), vp.theme.preview, vp.theme, -18);
    }
    this.drawSnap(ctx, vc, vp);
  }
}

/** Pick an element's line feature near a pointer (walls: faces and centerline). */
function lineUnder(tool, ev, filter) {
  const vc = tool.vc;
  const p = ev.p;
  const feats = vc.snapFeaturesNear(p, 12 * vc.mmPerPx());
  let best = null;
  for (const f of feats)
    for (const l of f.lines) {
      if (filter && !filter(tool.doc.get(l.id), l)) continue;
      const c = closestOnSegment(p, l.a, l.b);
      const d = dist(c.point, p);
      if (d < 12 * vc.mmPerPx() && (!best || d < best.d)) best = { d, l, point: c.point };
    }
  return best;
}

export class AlignTool extends Tool {
  get title() {
    return 'Align';
  }

  get prompt() {
    return this.ref ? 'Click the edge of the element to align to the reference' : 'Click the reference line or face to align to';
  }

  down(ev) {
    const hit = lineUnder(this, ev);
    if (!hit) return;
    if (!this.ref) {
      this.ref = hit.l;
      this.app.setPrompt(this.prompt);
      return;
    }
    const target = hit.l;
    const d1 = norm(sub(this.ref.b, this.ref.a));
    const d2 = norm(sub(target.b, target.a));
    if (Math.abs(cross(d1, d2)) > 0.01) return this.app.toast('The edges must be parallel to align.', { kind: 'error' });
    const n = perp(d1);
    const off = dot(sub(this.ref.a, target.a), n);
    const el = this.doc.get(target.id);
    if (!el) return;
    if (el.pinned) return this.app.toast('That element is pinned.', { kind: 'error' });
    this.app.commit('Align', () => moveElements(this.doc, [el.id], scale(n, off)));
    this.ref = null;
    this.app.setPrompt(this.prompt);
  }

  move(ev) {
    this.hover = ev.p ? lineUnder(this, ev) : null;
    this.app.requestRender();
  }

  cancel() {
    if (this.ref) {
      this.ref = null;
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    if (this.ref) strokeModel(ctx, [this.ref.a, this.ref.b], S, vp.theme.selCss, 2.5);
    if (this.hover) strokeModel(ctx, [this.hover.l.a, this.hover.l.b], S, vp.theme.preview, 2, [6, 3]);
  }
}

export class OffsetTool extends Tool {
  constructor(app, opts) {
    super(app, opts);
    this.o = app.toolOptions('offset', { distance: 1000, copy: true, count: 1 });
  }

  get title() {
    return 'Offset';
  }

  get prompt() {
    return 'Click a wall or line; the copy goes to the side of the cursor';
  }

  options() {
    const field = h('input.input.sm.num', { type: 'text', value: this.fmt(this.o.distance), 'aria-label': 'Offset distance' });
    field.addEventListener('change', () => {
      const v = this.parseLen(field.value);
      if (Number.isFinite(v) && v > 0) this.o.distance = v;
      field.value = this.fmt(this.o.distance);
    });
    field.addEventListener('keydown', (e) => e.stopPropagation());
    // Archicad's Multiple Offset: several copies at the distance from each other.
    const count = h('input.input.sm.num', { type: 'number', min: 1, max: 100, value: this.o.count, 'aria-label': 'Number of copies' });
    count.addEventListener('change', () => (this.o.count = Math.max(1, Math.min(100, Math.round(+count.value) || 1))));
    count.addEventListener('keydown', (e) => e.stopPropagation());
    return [h('div.ob-group', h('label', 'Offset'), field), checkbox('Copy', this.o.copy, (v) => (this.o.copy = v)), h('div.ob-group', h('label', 'Copies'), count)];
  }

  target(ev) {
    for (const id of this.vc.hitTest(ev.x, ev.y)) {
      const el = this.doc.get(id);
      if (el && ['wall', 'detailLine', 'roomSeparator', 'grid', 'beam'].includes(el.kind)) return el;
    }
    return null;
  }

  move(ev) {
    this.hover = this.target(ev);
    this.cursor = ev.p;
    this.app.setHover(this.hover?.id ?? null);
    this.app.requestRender();
  }

  down(ev) {
    const el = this.target(ev);
    if (!el || !ev.p) return;
    if (this.o.copy) this.app.commit(this.o.count > 1 ? 'Multiple offset' : 'Offset', () => { for (let k = 1; k <= (this.o.count || 1); k++) offsetElement(this.doc, el, this.o.distance * k, ev.p); });
    else {
      const n = perp(norm(sub(el.b, el.a)));
      const s = dot(sub(ev.p, el.a), n) >= 0 ? 1 : -1;
      this.app.commit('Offset', () => moveElements(this.doc, [el.id], scale(n, s * this.o.distance)));
    }
  }

  drawOverlay(ctx, vc, vp) {
    if (this.hover && this.cursor) {
      const el = this.hover;
      const n = perp(norm(sub(el.b, el.a)));
      const s = dot(sub(this.cursor, el.a), n) >= 0 ? 1 : -1;
      const off = scale(n, s * this.o.distance);
      strokeModel(ctx, [add(el.a, off), add(el.b, off)], (p) => vc.modelToScreen(p), vp.theme.preview, 2, [6, 4]);
    }
  }
}

export class TrimTool extends Tool {
  constructor(app, opts) {
    super(app, opts);
    this.mode = opts.mode || 'corner';
  }

  get title() {
    return this.mode === 'corner' ? 'Trim/Extend to Corner' : 'Trim/Extend Single Element';
  }

  get prompt() {
    if (this.mode === 'corner') return this.first ? 'Click the second wall or line (on the part to keep)' : 'Click the first wall or line (on the part to keep)';
    return this.ref ? 'Click the wall or line to trim or extend (on the part to keep)' : 'Click the reference to trim or extend to';
  }

  target(ev) {
    for (const id of this.vc.hitTest(ev.x, ev.y)) {
      const el = this.doc.get(id);
      if (el && ['wall', 'detailLine', 'roomSeparator', 'beam', 'grid'].includes(el.kind)) return el;
    }
    return null;
  }

  down(ev) {
    if (this.mode === 'single' && !this.ref) {
      const hit = lineUnder(this, ev);
      if (!hit) return;
      this.ref = hit.l;
      this.app.setPrompt(this.prompt);
      return;
    }
    const el = this.target(ev);
    if (!el) return;
    if (this.mode === 'single') {
      this.app.commit('Extend', () => extendToLine(this.doc, el, ev.p, this.ref.a, this.ref.b));
      return;
    }
    if (!this.first) {
      this.first = { el, p: ev.p };
      this.app.select([el.id]);
      this.app.setPrompt(this.prompt);
      return;
    }
    if (el.id === this.first.el.id) return;
    const ok = this.app.commit('Corner', () => cornerWalls(this.doc, this.doc.get(this.first.el.id), this.first.p, el, ev.p));
    if (ok === false) this.app.toast('These elements are parallel.', { kind: 'error' });
    this.first = null;
    this.app.select([]);
    this.app.setPrompt(this.prompt);
  }

  move(ev) {
    const t = this.mode === 'single' && !this.ref ? null : this.target(ev);
    this.app.setHover(t?.id ?? null);
    this.hover = this.mode === 'single' && !this.ref ? lineUnder(this, ev) : null;
    this.app.requestRender();
  }

  cancel() {
    if (this.first || this.ref) {
      this.first = null;
      this.ref = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    if (this.ref) strokeModel(ctx, [this.ref.a, this.ref.b], S, vp.theme.selCss, 2.5);
    if (this.hover) strokeModel(ctx, [this.hover.l.a, this.hover.l.b], S, vp.theme.preview, 2, [6, 3]);
  }
}

export class SplitTool extends Tool {
  get title() {
    return 'Split Element';
  }

  get prompt() {
    return 'Click on a wall or line where it should be split';
  }

  get gap() {
    return this.app.toolOptions('split', { gap: 0 }).gap;
  }

  options() {
    const o = this.app.toolOptions('split', { gap: 0 });
    const input = h('input.input.sm.num', { type: 'text', value: this.fmt(o.gap), 'aria-label': 'Gap' });
    input.addEventListener('change', () => {
      const v = this.parseLen(input.value);
      if (Number.isFinite(v) && v >= 0) o.gap = v;
      input.value = this.fmt(o.gap);
    });
    input.addEventListener('keydown', (e) => e.stopPropagation());
    return [h('div.ob-group', h('label', 'Gap'), input), h('span.ob-label', o.gap ? 'Leaves a gap of this width at the split.' : 'Set a gap to split with an opening between the parts.')];
  }

  target(ev) {
    for (const id of this.vc.hitTest(ev.x, ev.y)) {
      const el = this.doc.get(id);
      if (el && ['wall', 'detailLine', 'roomSeparator', 'beam', 'modelLine', 'refPlane', 'areaBoundary', 'insulation'].includes(el.kind)) return el;
    }
    return null;
  }

  move(ev) {
    this.hoverEl = this.target(ev);
    this.cursor = this.snap(ev);
    this.app.setHover(this.hoverEl?.id ?? null);
    this.app.requestRender();
  }

  down(ev) {
    const el = this.target(ev);
    if (!el) return;
    const p = this.snap(ev) || ev.p;
    const c = closestOnSegment(p, el.a, el.b).point;
    const r = this.app.commit(el.kind === 'wall' ? 'Split wall' : 'Split', () => splitLinear(this.doc, el, c, this.gap));
    if (r === null) this.app.toast(this.gap ? 'The gap does not fit there. Click farther from the ends.' : 'Click away from the ends.', { kind: 'error' });
  }

  drawOverlay(ctx, vc, vp) {
    if (this.hoverEl && this.cursor) {
      const c = closestOnSegment(this.cursor, this.hoverEl.a, this.hoverEl.b).point;
      const n = perp(norm(sub(this.hoverEl.b, this.hoverEl.a)));
      const S = (p) => vc.modelToScreen(p);
      const k = 14 * vc.mmPerPx();
      strokeModel(ctx, [add(c, scale(n, -k)), add(c, scale(n, k))], S, vp.theme.snap, 2);
    }
    this.drawSnap(ctx, vc, vp);
  }
}

/**
 * Scale the selection about a base point: graphically (a reference length,
 * then the new length) or by a typed factor.
 */
export class ScaleTool extends SelectionTool {
  get title() {
    return 'Scale';
  }

  get prompt() {
    if (!this.base) return 'Click the base point (it stays in place), or type a scale factor in the options bar';
    if (!this.ref) return 'Click the end of the reference length';
    return 'Click to set the new length, or type it';
  }

  options() {
    const f = h('input.input.sm.num', { type: 'text', placeholder: '2', 'aria-label': 'Scale factor' });
    f.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') {
        const k = parseFloat(f.value);
        if (!(k > 0)) return f.setAttribute('aria-invalid', 'true');
        if (!this.base) {
          const b = this.vc.extents?.(new Set(this.ids));
          this.base = b ? [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2] : [0, 0];
        }
        this.apply(k);
      }
    });
    return [h('div.ob-group', h('label', 'Factor'), f), h('span.ob-label', 'Positions and lengths scale; the sizes of doors, furniture and other types stay.')];
  }

  down(ev) {
    const p = this.snap(ev, this.ref || this.base, { exclude: this.exclude });
    if (!p) return;
    if (!this.base) this.base = p;
    else if (!this.ref) {
      if (dist(p, this.base) < 1) return;
      this.ref = p;
    } else {
      const k = dist(p, this.base) / dist(this.ref, this.base);
      if (k > 0) this.apply(k);
      return;
    }
    this.app.setPrompt(this.prompt);
  }

  apply(k) {
    this.app.commit('Scale', () => transformElements(this.doc, this.ids, scaling(this.base, k)));
    this.app.cancelTool();
  }

  move(ev) {
    this.cursor = this.snap(ev, this.ref || this.base, { exclude: this.exclude });
    this.app.requestRender();
  }

  key(e) {
    if (this.ref && isNumericStart(e)) {
      e.preventDefault();
      const s = this.vc.modelToScreen(this.cursor || this.ref);
      const input = this.openInput(s.x, s.y, {
        label: 'New length',
        onSubmit: (v) => {
          const L = this.parseLen(v);
          if (!(L > 0)) return false;
          this.apply(L / dist(this.ref, this.base));
          return true;
        },
      });
      input.value = e.key;
      return true;
    }
    return false;
  }

  cancel() {
    if (this.ref || this.base) {
      if (this.ref) this.ref = null;
      else this.base = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    if (this.base && this.cursor) {
      strokeModel(ctx, [this.base, this.ref || this.cursor], S, vp.theme.preview, 1.4, [5, 4]);
      if (this.ref) {
        const k = dist(this.cursor, this.base) / dist(this.ref, this.base);
        strokeModel(ctx, [this.base, this.cursor], S, vp.theme.preview, 1.4);
        this.preview(ctx, vc, vp, scaling(this.base, k));
        const s = S(this.cursor);
        drawTag(ctx, s.x + 30, s.y + 20, `x ${Math.round(k * 1000) / 1000}`, { bg: vp.theme.bgCss, fg: vp.theme.inkCss, border: vp.theme.preview });
      }
    }
    this.drawSnap(ctx, vc, vp);
  }
}

/**
 * Measure, as in Archicad: click points to measure the distance of each
 * segment, the total along the chain and its angle; with three points or
 * more, the area and perimeter of the shape they enclose. Enter, a
 * double-click or Escape starts over.
 */
export class MeasureTool extends Tool {
  get title() {
    return 'Measure';
  }

  get viewKinds() {
    return ANNOTATION_VIEWS;
  }

  get prompt() {
    return this.pts?.length ? 'Click the next point; Enter or double-click to start over' : 'Click the first point to measure distances, angles and areas';
  }

  start() {
    this.pts = [];
  }

  /** The readout for the clicked points (and the cursor). */
  readout(pts) {
    if (pts.length < 2) return '';
    const segs = pts.slice(1).map((p, i) => dist(pts[i], p));
    const last = segs.at(-1);
    const total = segs.reduce((x, y) => x + y, 0);
    const a = pts.at(-2);
    const b = pts.at(-1);
    const ang = (angleOf(sub(b, a)) * 180) / Math.PI;
    const parts = [`Distance ${this.fmt(last)}`, `Angle ${(((ang % 360) + 360) % 360).toFixed(1)}°`, `ΔX ${this.fmt(Math.abs(b[0] - a[0]))}`, `ΔY ${this.fmt(Math.abs(b[1] - a[1]))}`];
    if (pts.length > 2) parts.push(`Total ${this.fmt(total)}`);
    if (pts.length > 2) {
      let s2 = 0;
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        const q = pts[(i + 1) % pts.length];
        s2 += p[0] * q[1] - q[0] * p[1];
      }
      parts.push(`Area ${formatArea(Math.abs(s2) / 2, this.doc.units)}`, `Perimeter ${this.fmt(total + dist(pts.at(-1), pts[0]))}`);
    }
    return parts.join('   ');
  }

  down(ev) {
    const p = this.snap(ev, this.pts.at(-1) || null);
    if (!p) return;
    this.pts.push(p);
    this.app.setPrompt(this.readout(this.pts) || this.prompt);
  }

  dblclick() {
    this.pts = [];
    this.app.setPrompt(this.prompt);
  }

  key(e) {
    if (e.key === 'Enter' && this.pts.length) {
      e.preventDefault();
      this.pts = [];
      this.app.setPrompt(this.prompt);
      return true;
    }
    return false;
  }

  move(ev) {
    this.cursor = this.snap(ev, this.pts.at(-1) || null);
    if (this.pts.length && this.cursor) this.app.setPrompt(this.readout([...this.pts, this.cursor]));
    this.app.requestRender();
  }

  cancel() {
    if (this.pts.length) {
      this.pts = [];
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    const pts = [...this.pts, this.cursor].filter(Boolean);
    if (pts.length >= 3) {
      ctx.save();
      ctx.fillStyle = vp.theme.snap;
      ctx.globalAlpha = 0.12;
      ctx.beginPath();
      pts.forEach((p, i) => {
        const q = S(p);
        if (i) ctx.lineTo(q.x, q.y);
        else ctx.moveTo(q.x, q.y);
      });
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
    for (let i = 0; i + 1 < pts.length; i++) {
      if (dist(pts[i], pts[i + 1]) < 0.5) continue;
      strokeModel(ctx, [pts[i], pts[i + 1]], S, vp.theme.snap, 1.5);
      drawTempDim(ctx, S(pts[i]), S(pts[i + 1]), this.fmt(dist(pts[i], pts[i + 1])), vp.theme.snap, vp.theme, -18);
    }
    this.drawSnap(ctx, vc, vp);
  }
}

/** Element Transfer Settings (Archicad's): what Pick Up and Inject carry from one element to another. */
export const TRANSFER_DEFAULTS = { type: true, layer: true, heights: true, parameters: true, surfaces: true };
const HEIGHT_KEYS = ['height', 'baseOffset', 'topLevelId', 'topOffset', 'offset', 'endOffset', 'sill', 'width', 'depth'];
const PARAM_KEYS = ['gdlValues', 'params', 'locationLine', 'flipped', 'structural', 'refPlane'];
const SURFACE_KEYS = ['paintId', 'materialId'];

export function transferPatch(source, target, settings = {}) {
  const s = { ...TRANSFER_DEFAULTS, ...(settings || {}) };
  const patch = {};
  const take = (keys) => keys.forEach((k) => source[k] !== undefined && (patch[k] = structuredClone(source[k])));
  if (s.type && source.typeId) patch.typeId = source.typeId;
  if (s.layer && source.layerId) patch.layerId = source.layerId;
  if (s.heights) take(HEIGHT_KEYS);
  if (s.parameters) take(PARAM_KEYS);
  if (s.surfaces) take(SURFACE_KEYS);
  // Hosted elements keep their host and place; elements keep their own story.
  delete patch.levelId;
  void target;
  return patch;
}

export class MatchTypeTool extends Tool {
  get title() {
    return 'Match Type';
  }

  get viewKinds() {
    return null;
  }

  get prompt() {
    return this.source ? `Click elements to give them the type of the source (${this.app.describe(this.source)})` : 'Click the element whose type to copy';
  }

  down(ev) {
    const id = this.vc.hitTest(ev.x, ev.y)[0];
    const el = id && this.doc.get(id);
    if (!el || !el.typeId) return;
    if (!this.source) {
      this.source = el;
      this.app.setPrompt(this.prompt);
      return;
    }
    if (el.kind !== this.source.kind) return this.app.toast('Pick an element of the same category.', { kind: 'error' });
    this.app.commit('Match type', () => this.doc.update(el.id, transferPatch(this.source, el, this.app.settings.transfer)));
  }

  move(ev) {
    const id = this.vc.hitTest(ev.x, ev.y)[0];
    this.app.setHover(id ?? null);
  }

  cancel() {
    if (this.source) {
      this.source = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }
}

export class ZoomRegionTool extends Tool {
  get title() {
    return 'Zoom in Region';
  }

  get viewKinds() {
    return ANNOTATION_VIEWS;
  }

  get prompt() {
    return 'Drag a rectangle to zoom into';
  }

  down(ev) {
    this.a = { x: ev.x, y: ev.y };
  }

  move(ev) {
    if (this.a) {
      this.b = { x: ev.x, y: ev.y };
      this.app.requestRender();
    }
  }

  up(ev) {
    if (!this.a) return;
    const vc = this.vc;
    const b = { x: ev.x, y: ev.y };
    if (Math.abs(b.x - this.a.x) > 8 && Math.abs(b.y - this.a.y) > 8) {
      const p = vc.screenToModel(Math.min(this.a.x, b.x), Math.max(this.a.y, b.y));
      const q = vc.screenToModel(Math.max(this.a.x, b.x), Math.min(this.a.y, b.y));
      if (vc.zoomToBox) vc.zoomToBox({ x0: p[0], y0: p[1], x1: q[0], y1: q[1] });
      else {
        const f = Math.min(this.app.viewport.width / Math.abs(b.x - this.a.x), this.app.viewport.height / Math.abs(b.y - this.a.y));
        vc.zoomAt((this.a.x + b.x) / 2, (this.a.y + b.y) / 2, 1);
        vc.pan(this.app.viewport.width / 2 - (this.a.x + b.x) / 2, this.app.viewport.height / 2 - (this.a.y + b.y) / 2);
        vc.zoomAt(this.app.viewport.width / 2, this.app.viewport.height / 2, f);
      }
    }
    this.app.cancelTool();
  }

  drawOverlay(ctx, vc, vp) {
    if (this.a && this.b) {
      ctx.save();
      ctx.strokeStyle = vp.theme.preview;
      ctx.setLineDash([5, 4]);
      ctx.strokeRect(Math.min(this.a.x, this.b.x), Math.min(this.a.y, this.b.y), Math.abs(this.b.x - this.a.x), Math.abs(this.b.y - this.a.y));
      ctx.restore();
    }
  }
}

