/**
 * Marquee, as in Archicad: a rectangle drawn in a plan that marks an area of
 * the current story. It stays until another is drawn or Escape clears it;
 * Show Selection/Marquee in 3D (F5) then shows that part of the story.
 * The marquee lives on the app: { viewId, levelId, x0, y0, x1, y1 }.
 */
import { Tool } from './tool.js';
import { strokeModel } from '../views/overlay.js';
import { PLAN_VIEW_KINDS } from '../core/doc.js';

export class MarqueeTool extends Tool {
  get title() {
    return 'Marquee';
  }

  get viewKinds() {
    return PLAN_VIEW_KINDS;
  }

  get prompt() {
    if (this.first) return 'Click the opposite corner of the marquee';
    return this.app.marquee ? 'Draw a new marquee, press F5 to see it in 3D, or Escape to clear it' : 'Click the first corner of the marquee';
  }

  down(ev) {
    const p = this.snap(ev, this.first);
    if (!p) return;
    if (!this.first) {
      this.first = p;
      this.app.setPrompt(this.prompt);
      return;
    }
    const a = this.first;
    this.first = null;
    if (Math.abs(a[0] - p[0]) < 1 || Math.abs(a[1] - p[1]) < 1) return;
    const view = this.vc.view;
    this.app.marquee = { viewId: view.id, levelId: view.levelId, x0: Math.min(a[0], p[0]), y0: Math.min(a[1], p[1]), x1: Math.max(a[0], p[0]), y1: Math.max(a[1], p[1]) };
    this.app.setPrompt(this.prompt);
    this.app.requestRender();
  }

  move(ev) {
    this.cursor = this.snap(ev, this.first);
    this.app.requestRender();
  }

  cancel() {
    if (this.first) {
      this.first = null;
      return false;
    }
    if (this.app.marquee) {
      this.app.marquee = null;
      this.app.setPrompt(this.prompt);
      this.app.requestRender();
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    this.drawSnap?.(ctx, vc, vp);
    drawMarquee(this.app, ctx, vc, vp);
    if (this.first && this.cursor) {
      const a = this.first;
      const b = this.cursor;
      strokeModel(ctx, [a, [b[0], a[1]], b, [a[0], b[1]]], (q) => vc.modelToScreen(q), vp.theme.preview, 1.5, [8, 4], true);
    }
  }
}

/** The app's marquee, in the view it was drawn in. */
export function drawMarquee(app, ctx, vc, vp) {
  const m = app.marquee;
  if (!m || vc.view?.id !== m.viewId) return;
  const pts = [[m.x0, m.y0], [m.x1, m.y0], [m.x1, m.y1], [m.x0, m.y1]];
  strokeModel(ctx, pts, (q) => vc.modelToScreen(q), vp.theme.selCss, 2.5, [10, 5], true);
}
