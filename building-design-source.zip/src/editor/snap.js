/**
 * Object snapping in plan views: endpoints, midpoints, intersections,
 * centers, perpendicular and nearest points on element edges, plus angle
 * tracking and length rounding from the previous point, and alignment
 * with nearby points.
 */
import { constrainedPoint, divisionsAlong, extensionPoint } from '../core/drafting.js';
import { polylineSegments } from '../core/polyline.js';
import { add, sub, scale, dot, dist, norm, closestOnSegment, lineIntersect, len, angleOf, mid } from '../core/geom.js';
import { wallAxis, rampOutline } from '../core/model.js';
import { axisPoint } from '../core/walls.js';
import { footingOutline } from '../core/build3d.js';
import { columnOutline } from '../core/plan.js';
import { buildFamily } from '../core/families.js';
import { Frame } from '../core/mesh.js';
import { snapIncrement } from '../core/units.js';
import { sectionFrame } from '../core/plan.js';
import { snapToGrid, constrainToDirection } from '../core/drafting.js';

export const SNAP_KINDS = {
  endpoint: { label: 'Endpoint', rank: 0 },
  intersection: { label: 'Intersection', rank: 0 },
  center: { label: 'Center', rank: 1 },
  midpoint: { label: 'Midpoint', rank: 1 },
  perpendicular: { label: 'Perpendicular', rank: 2 },
  nearest: { label: 'Nearest', rank: 3 },
  grid: { label: 'Grid', rank: 2 },
  division: { label: 'Division', rank: 1 },
  percent: { label: 'Percentage', rank: 1 },
  distance: { label: 'Distance', rank: 1 },
  constraint: { label: 'Constraint', rank: 2 },
};

/**
 * Special snap points along a line, as in Archicad: its division into n
 * equal parts, a percentage of its length from each end, and a distance
 * from each end. [{ p, kind, label }].
 */
/**
 * The tracking direction nearest an angle (radians): multiples of the step (degrees, 15 by default) and your own
 * angles, each also from the other three axes (45 gives 45, 135, 225, 315).
 */
export function nearestAngle(a, stepDeg, custom = []) {
  const step = ((+stepDeg || 15) * Math.PI) / 180;
  let best = Math.round(a / step) * step;
  const off = (x) => Math.abs(Math.atan2(Math.sin(a - x), Math.cos(a - x)));
  for (const d of custom || [])
    for (const k of [0, 1, 2, 3])
      for (const s of [1, -1]) {
        const x = s * ((+d * Math.PI) / 180) + (k * Math.PI) / 2;
        if (off(x) < off(best)) best = x;
      }
  return best;
}

export function specialPoints(l, { divisions = 0, percent = 0, distance = 0, fromMiddle = false } = {}) {
  const out = [];
  const L = dist(l.a, l.b);
  if (L < 1e-6) return out;
  const at = (t) => [l.a[0] + (l.b[0] - l.a[0]) * t, l.a[1] + (l.b[1] - l.a[1]) * t];
  const n = Math.round(+divisions || 0);
  if (n >= 2 && n <= 100) for (let k = 1; k < n; k++) out.push({ p: at(k / n), kind: 'division', label: `${k}/${n}` });
  const pc = +percent || 0;
  if (pc > 0 && pc < 100) for (const t of [pc / 100, 1 - pc / 100]) out.push({ p: at(t), kind: 'percent', label: `${pc}%` });
  const d = +distance || 0;
  // From the ends, or (Archicad's Snap Points From Middle) from the midpoint both ways.
  if (fromMiddle) {
    if (d > 0 && d < L / 2) for (const t of [0.5 - d / L, 0.5 + d / L]) out.push({ p: at(t), kind: 'distance', label: null });
  } else if (d > 0 && d < L) for (const t of [d / L, 1 - d / L]) out.push({ p: at(t), kind: 'distance', label: null });
  return out;
}

/** Snap features of an element in plan: { points: [{p, kind}], lines: [{a, b, ref}] }. */
export function snapFeatures(scene, el) {
  const doc = scene.doc;
  const points = [];
  const lines = [];
  const P = (p, kind = 'endpoint') => p && points.push({ p, kind, id: el.id });
  const Lg = (a, b, ref) => lines.push({ a, b, id: el.id, ref });
  switch (el.kind) {
    case 'wall': {
      const g = scene.walls.wall(el.id);
      P(el.a);
      P(el.b);
      // A curved wall snaps at its ends, face corners and the middle of its arc, not along lines.
      if (el.arc) {
        const ax = wallAxis(doc, el);
        P(axisPoint(ax, ax.length / 2), 'midpoint');
        if (g) for (const c of [g.L0, g.L1, g.R0, g.R1]) P(c);
        break;
      }
      P(mid(el.a, el.b), 'midpoint');
      Lg(el.a, el.b, 'center');
      if (g) {
        for (const c of [g.L0, g.L1, g.R0, g.R1]) P(c);
        Lg(g.L0, g.L1, 'left');
        Lg(g.R0, g.R1, 'right');
      } else {
        const ax = wallAxis(doc, el);
        Lg(ax.a, ax.b, 'center');
      }
      break;
    }
    case 'ramp': {
      const o = rampOutline(doc, el);
      o.forEach((p) => P(p));
      for (let i = 0; i < o.length; i++) Lg(o[i], o[(i + 1) % o.length], 'edge');
      P(el.a, 'midpoint');
      break;
    }
    case 'grid':
    case 'detailLine':
    case 'roomSeparator':
    case 'beam':
    case 'spline': {
      const pts = el.path || [];
      pts.forEach((q) => P(q));
      break;
    }
    case 'polyline':
      (el.path || []).forEach((q) => P(q));
      for (const s of polylineSegments(el)) if (Math.abs(s.bulge) < 1e-9) Lg(s.a, s.b, 'edge');
      break;
    case 'camera':
      P(el.at);
      P(el.target);
      break;
    case 'detailArc': {
      P(el.c, 'center');
      const full = Math.abs((el.a1 ?? Math.PI * 2) - (el.a0 ?? 0)) >= Math.PI * 2 - 1e-6;
      if (!full) for (const a of [el.a0, el.a1]) P([el.c[0] + Math.cos(a) * el.r, el.c[1] + Math.sin(a) * el.r]);
      break;
    }
    case 'footing': {
      const o = footingOutline(doc, el);
      P(el.at, 'center');
      o.forEach((p) => P(p));
      for (let i = 0; i < o.length; i++) Lg(o[i], o[(i + 1) % o.length], 'edge');
      break;
    }
    case 'propertyLine':
    case 'mass': {
      const bnd = el.boundary || [];
      bnd.forEach((p) => P(p));
      for (let i = 0; i < bnd.length; i++) Lg(bnd[i], bnd[(i + 1) % bnd.length], 'edge');
      break;
    }
    case 'topo':
      (el.points || []).forEach((p) => P([p[0], p[1]]));
      break;
    case 'refPlane':
    case 'modelLine':
    case 'areaBoundary':
    case 'insulation':
    case 'brace':
    case 'truss':
    case 'wire':
    case 'matchline':
    case 'duct':
    case 'pipe':
    case 'cableTray':
    case 'conduit':
      P(el.a);
      P(el.b);
      P(mid(el.a, el.b), 'midpoint');
      Lg(el.a, el.b, 'center');
      break;
    case 'column': {
      P(el.at, 'center');
      const o = columnOutline(doc, el);
      if (o.length <= 8) o.forEach((p) => P(p));
      for (let i = 0; i < o.length; i++) Lg(o[i], o[(i + 1) % o.length], 'edge');
      break;
    }
    case 'component': {
      P(el.at, 'center');
      const type = doc.get(el.typeId);
      if (type) {
        const fr = new Frame(el.at, ((+el.rotation || 0) * Math.PI) / 180);
        const sym = buildFamily(type, fr, null, () => null);
        const o = sym.outline.map((p) => fr.apply(p));
        if (o.length <= 8) o.forEach((p) => P(p));
        for (let i = 0; i < o.length; i++) Lg(o[i], o[(i + 1) % o.length], 'edge');
      }
      break;
    }
    case 'floor':
    case 'ceiling':
    case 'roof': {
      const b = el.boundary || [];
      b.forEach((p) => P(p));
      for (let i = 0; i < b.length; i++) {
        Lg(b[i], b[(i + 1) % b.length], 'edge');
        P(mid(b[i], b[(i + 1) % b.length]), 'midpoint');
      }
      break;
    }
    case 'railing': {
      const pth = el.path || [];
      pth.forEach((p) => P(p));
      for (let i = 0; i + 1 < pth.length; i++) Lg(pth[i], pth[i + 1], 'edge');
      break;
    }
    case 'stair':
      P(el.a);
      P(el.b);
      break;
    case 'room':
      P(el.at, 'center');
      break;
    case 'door':
    case 'window': {
      const host = doc.get(el.hostId);
      if (host) {
        const ax = wallAxis(doc, host);
        P(axisPoint(ax, el.t), 'midpoint');
      }
      break;
    }
    case 'hotspot':
      P(el.at);
      break;
    case 'section': {
      P(el.a);
      P(el.b);
      Lg(el.a, el.b, 'center');
      void sectionFrame;
      break;
    }
    default:
      break;
  }
  return { points, lines };
}

/**
 * Snap a model point. ctx: { vc (view controller), from, exclude: Set,
 * settings, units }. Returns { point, kind, label, ref, guides: [[a, b]] }.
 */
export function snapPoint(ctx, p) {
  const { vc, from, exclude, settings = {} } = ctx;
  const tolPx = settings.tolPx ?? 12;
  const mmPerPx = vc.mmPerPx();
  const tol = tolPx * mmPerPx;
  const feats = vc.snapFeaturesNear(p, tol * 3, exclude);
  let best = null;
  const consider = (q, kind, ref, extra) => {
    const d = dist(p, q);
    if (d > tol) return;
    const rank = SNAP_KINDS[kind]?.rank ?? 3;
    // Prefer higher-ranked snaps unless a lower one is much closer.
    const score = d / mmPerPx + rank * 6;
    if (!best || score < best.score) best = { point: q, kind, label: SNAP_KINDS[kind]?.label || kind, ref, score, ...extra };
  };
  if (settings.enabled !== false) {
    for (const f of feats) {
      for (const pt of f.points) {
        if (pt.kind === 'midpoint' && settings.midpoints === false) continue;
        if (pt.kind === 'endpoint' && settings.endpoints === false) continue;
        consider(pt.p, pt.kind, { id: pt.id });
      }
    }
    // Special snap points along nearby lines: divisions, percentages and distances from their ends.
    if (settings.divisions || settings.percent || settings.distance) {
      const all = feats.flatMap((f) => f.lines);
      for (const l of all) {
        if (dist(p, closestOnSegment(p, l.a, l.b).point) > tol * 2) continue;
        // Between Intersection Points: the stretch of the line between the crossings around the cursor.
        const seg = settings.betweenIntersections ? stretchBetweenIntersections(l, all, p) : l;
        for (const sp of specialPoints(seg, settings)) consider(sp.p, sp.kind, { id: l.id }, sp.label ? { label: sp.label } : {});
      }
    }
    // Along Entire Element: the divisions of a whole outline or chain, not of each of its sides.
    if (settings.alongEntire && settings.divisions) {
      const byId = new Map();
      for (const f of feats) for (const l of f.lines) if (l.id) byId.set(l.id, [...(byId.get(l.id) || []), l]);
      for (const [id, ls] of byId) {
        if (ls.length < 2 || !ls.some((l) => dist(p, closestOnSegment(p, l.a, l.b).point) <= tol * 2)) continue;
        const chain = [ls[0].a, ls[0].b];
        let joined = true;
        for (const l of ls.slice(1)) {
          if (dist(chain.at(-1), l.a) > 1) {
            joined = false;
            break;
          }
          chain.push(l.b);
        }
        if (joined) for (const q of divisionsAlong(chain, +settings.divisions)) consider(q, 'division', { id });
      }
    }
    // Intersections of nearby lines.
    if (settings.intersections !== false) {
      const near = [];
      for (const f of feats) for (const l of f.lines) if (closestOnSegment(p, l.a, l.b) && dist(p, closestOnSegment(p, l.a, l.b).point) < tol * 2) near.push(l);
      for (let i = 0; i < near.length && i < 40; i++)
        for (let j = i + 1; j < near.length && j < 40; j++) {
          const A = near[i];
          const B = near[j];
          if (A.id === B.id) continue;
          const hit = lineIntersect(A.a, sub(A.b, A.a), B.a, sub(B.b, B.a));
          if (!hit || hit.t < -0.001 || hit.t > 1.001 || hit.u < -0.001 || hit.u > 1.001) continue;
          consider(hit.point, 'intersection', { id: A.id });
        }
    }
    if (!best || best.kind === 'nearest') {
      for (const f of feats)
        for (const l of f.lines) {
          if (from && settings.perpendicular !== false) {
            const d = norm(sub(l.b, l.a));
            const q = add(l.a, scale(d, dot(sub(from, l.a), d)));
            const t = dot(sub(q, l.a), d);
            if (t >= 0 && t <= len(sub(l.b, l.a))) consider(q, 'perpendicular', { id: l.id, ref: l.ref, line: l });
          }
          if (settings.nearest !== false) {
            const c = closestOnSegment(p, l.a, l.b);
            consider(c.point, 'nearest', { id: l.id, ref: l.ref, line: l }, { line: l });
          }
        }
    }
  }
  // A constraint that needs no previous point: the cursor stays on its line or its points.
  if (ctx.constraint?.a && ['offset', 'multiOffset', 'snapPoints'].includes(ctx.constraint.kind)) {
    const q = constrainedPoint(ctx.constraint, best && ctx.constraint.kind !== 'snapPoints' ? best.point : p);
    return { point: q, kind: 'constraint', label: ctx.constraint.label, ref: null, guides: [[ctx.constraint.a, ctx.constraint.b]] };
  }
  if (best) return { ...best, guides: [] };

  // A cursor constraint (parallel to an edge, or along a bisector) from the previous point.
  if (from && ctx.constraint?.dir) {
    const d = ctx.constraint.dir;
    let q = constrainToDirection(p, from, d);
    // Lengths along it round like tracking does.
    if (settings.lengths !== false) {
      const inc = snapIncrement(mmPerPx, ctx.units);
      const l = Math.hypot(d[0], d[1]) || 1;
      const t = Math.round(((q[0] - from[0]) * d[0] + (q[1] - from[1]) * d[1]) / l / inc) * inc;
      q = [from[0] + (d[0] / l) * t, from[1] + (d[1] / l) * t];
    }
    return { point: q, kind: 'constraint', label: ctx.constraint.label || 'Parallel', ref: null, guides: [[from, add(from, scale(norm(d), Math.max(dist(from, q), 1) + 40 * mmPerPx))]] };
  }

  // The construction grid, when its snap is on: the nearest node.
  if (ctx.grid && settings.enabled !== false) {
    const q = snapToGrid(ctx.grid, p);
    return { point: q, kind: 'grid', label: 'Grid', ref: null, guides: [] };
  }

  // Tracking from the previous point: angles and lengths.
  let q = p;
  const guides = [];
  let kind = null;
  if (from && settings.angles !== false) {
    const v = sub(p, from);
    const L = len(v);
    if (L > mmPerPx * 4) {
      const a = angleOf(v);
      const snapped = nearestAngle(a, settings.angleStep, settings.customAngles);
      const offPx = Math.abs(Math.sin(a - snapped)) * L / mmPerPx;
      if (offPx < (+settings.trackRange || 10)) {
        const dir = [Math.cos(snapped), Math.sin(snapped)];
        let l2 = dot(v, dir);
        if (settings.lengths !== false) {
          const inc = snapIncrement(mmPerPx, ctx.units);
          l2 = Math.round(l2 / inc) * inc;
        }
        q = add(from, scale(dir, l2));
        guides.push([from, add(from, scale(dir, Math.max(l2, L) + (+settings.guideExtend || 40) * mmPerPx))]);
        kind = 'tracking';
      }
    }
  }
  // Alignment with nearby points (horizontal and vertical).
  if (!kind && settings.alignment !== false) {
    let ax = null;
    let ay = null;
    for (const f of feats)
      for (const pt of f.points) {
        if (pt.kind !== 'endpoint' && pt.kind !== 'center') continue;
        const dx = Math.abs(pt.p[0] - p[0]);
        const dy = Math.abs(pt.p[1] - p[1]);
        if (dx < tol * 0.6 && (!ax || dx < Math.abs(ax[0] - p[0]))) ax = pt.p;
        if (dy < tol * 0.6 && (!ay || dy < Math.abs(ay[1] - p[1]))) ay = pt.p;
      }
    if (ax || ay) {
      q = [ax ? ax[0] : p[0], ay ? ay[1] : p[1]];
      if (ax) guides.push([ax, q]);
      if (ay) guides.push([ay, q]);
      kind = 'alignment';
    }
  }
  // Snap Guides: on the extension of a nearby line, past its end.
  if (!kind && settings.snapGuides) {
    let hit = null;
    for (const f of feats)
      for (const l of f.lines) {
        const e = extensionPoint(p, l.a, l.b, tol * 0.6, 200 * mmPerPx);
        if (e && (!hit || dist(e.foot, p) < dist(hit.foot, p))) hit = e;
      }
    if (hit) return { point: hit.foot, kind: 'alignment', label: 'Extension', ref: null, guides: [[hit.end, hit.foot]] };
  }
  return { point: q, kind, label: kind === 'tracking' ? '' : kind === 'alignment' ? 'Alignment' : '', ref: null, guides };
}

/** The part of line l between the two crossings with other lines that enclose the cursor's foot on it. */
export function stretchBetweenIntersections(l, lines, p) {
  const d = sub(l.b, l.a);
  const L2 = dot(d, d);
  if (L2 < 1e-9) return l;
  const ts = [0, 1];
  for (const o of lines) {
    if (o === l || o.id === l.id) continue;
    const hit = lineIntersect(l.a, d, o.a, sub(o.b, o.a));
    if (hit && hit.t > 1e-6 && hit.t < 1 - 1e-6 && hit.u >= -1e-6 && hit.u <= 1 + 1e-6) ts.push(hit.t);
  }
  ts.sort((x, y) => x - y);
  const tp = Math.max(0, Math.min(1, dot(sub(p, l.a), d) / L2));
  let i = 0;
  while (i < ts.length - 2 && ts[i + 1] < tp) i++;
  return { a: add(l.a, scale(d, ts[i])), b: add(l.a, scale(d, ts[i + 1])), id: l.id };
}
