/**
 * RoofMaker's single members (core/roofmaker.js): Create a rafter, a hip or
 * valley rafter, a purlin, an eaves purlin, a trimmer — two clicks on a
 * roof, the member's top on its planes — and Create multiple rafters at a
 * spacing between two clicks across a roof face. Members placed this way
 * stay when the roof's framing is made again.
 */
import { Tool } from './tool.js';
import { lengthField } from './draw.js';
import { PLAN_VIEW_KINDS } from '../core/doc.js';
import { roofAt, roofMember, rafterRow, addFramingMembers } from '../core/roofmaker.js';
import { strokeModel } from '../views/overlay.js';
import { dist } from '../core/geom.js';

const TITLES = { rafter: 'Create a Rafter', hip: 'Create a Hip or Valley Rafter', purlin: 'Create a Purlin', plate: 'Create an Eaves Purlin', trimmer: 'Create a Trimmer', multiple: 'Create Multiple Rafters' };

export class RoofMemberTool extends Tool {
  constructor(app, opts) {
    super(app, opts);
    this.role = opts.role || 'rafter';
  }

  get viewKinds() {
    return PLAN_VIEW_KINDS;
  }

  get title() {
    return TITLES[this.role];
  }

  get prompt() {
    if (this.role === 'multiple') return this.from ? 'Click the other end of the row, across the slope' : 'Click on a roof face where the row of rafters starts';
    return this.from ? 'Click the end of the member' : 'Click on a roof where the member starts';
  }

  options() {
    if (this.role !== 'multiple') return null;
    const o = this.app.toolOptions('roofRafters', { spacing: 600 });
    return [lengthField(this, 'Spacing', o.spacing, (v) => (o.spacing = Math.max(100, v)))];
  }

  down(ev) {
    const p = this.snap(ev, this.from);
    if (!p) return;
    if (!this.from) {
      if (!roofAt(this.doc, p)) return this.app.setPrompt('Click inside a roof.');
      this.from = p;
      this.app.setPrompt(this.prompt);
      return;
    }
    if (dist(this.from, p) < 50) return;
    const roof = roofAt(this.doc, [(this.from[0] + p[0]) / 2, (this.from[1] + p[1]) / 2]) || roofAt(this.doc, this.from);
    const members = this.role === 'multiple' ? rafterRow(this.doc, roof, this.from, p, this.app.toolOptions('roofRafters', { spacing: 600 }).spacing) : [roofMember(this.doc, roof, this.role, this.from, p)].filter(Boolean);
    if (!members.length) return this.app.setPrompt('No roof face there.');
    this.app.commit(this.title, () => addFramingMembers(this.doc, roof, members, { manual: true }));
    this.from = null;
    this.app.setPrompt(this.prompt);
  }

  move(ev) {
    this.cursor = this.snap(ev, this.from);
    this.app.requestRender();
  }

  cancel() {
    if (this.from) {
      this.from = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    if (this.from && this.cursor) strokeModel(ctx, [this.from, this.cursor], (q) => vc.modelToScreen(q), vp.theme.preview, 3, this.role === 'multiple' ? [6, 4] : null);
    this.drawSnap(ctx, vc, vp);
  }
}
