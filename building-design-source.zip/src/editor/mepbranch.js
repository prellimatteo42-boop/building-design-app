/**
 * Branch / Take-Off and Fitting tools for ducts, pipes and cable carriers
 * (core/meproute.js): a branch starts on the middle of a run and goes to a
 * clicked point; a fitting splits a run where it is clicked and the part
 * after it takes the new size, so a transition is made there.
 */
import { Tool } from './tool.js';
import { h } from '../ui/dom.js';
import { FITTING_LIBRARY, placedFitting } from '../core/mepfittings.js';
import { runEnds } from '../core/mepnet.js';
import { levelElevation } from '../core/model.js';
import { systemOf } from '../core/mep.js';
import { lengthField } from './draw.js';
import { PLAN_VIEW_KINDS } from '../core/doc.js';
import { mepSize } from '../core/mep.js';
import { onRun, splitRun, branchRun, refreshFittings } from '../core/meproute.js';
import { strokeModel } from '../views/overlay.js';

const LABEL = { duct: 'Duct', pipe: 'Pipe', cableTray: 'Cable Carrier', conduit: 'Conduit' };

/** The run of a kind nearest a plan point within its half width plus a tolerance: { run, at } or null. */
function runNear(doc, kind, q, tol) {
  let best = null;
  for (const r of doc.all(kind)) {
    const at = onRun(r, q);
    if (!at) continue;
    const d = Math.hypot(at.p[0] - q[0], at.p[1] - q[1]);
    if (d <= mepSize(doc, r).w / 2 + tol && (!best || d < best.d)) best = { run: r, at, d };
  }
  return best;
}

class MepPartTool extends Tool {
  constructor(app, opts) {
    super(app, opts);
    this.kind = opts.kind;
  }

  get viewKinds() {
    return PLAN_VIEW_KINDS;
  }

  get o() {
    return this.app.toolOptions(`${this.mode}-${this.kind}`, {});
  }

  /** Size fields: a diameter for round runs, else width and height (empty keeps the run's own). */
  sizeOptions() {
    const o = this.o;
    const round = mepSize(this.doc, { kind: this.kind, typeId: this.app.currentType(this.kind)?.id }).round;
    if (round) return [lengthField(this, 'Diameter', o.diameter || 0, (v) => (o.diameter = v > 0 ? v : null))];
    return [lengthField(this, 'Width', o.width || 0, (v) => (o.width = v > 0 ? v : null)), lengthField(this, 'Height', o.height || 0, (v) => (o.height = v > 0 ? v : null))];
  }

  sizePatch() {
    const o = this.o;
    const p = {};
    for (const k of ['width', 'height', 'diameter']) if (o[k] > 0) p[k] = o[k];
    return p;
  }

  pickRun(ev) {
    const hit = runNear(this.doc, this.kind, ev.p, 12 * this.vc.mmPerPx());
    if (!hit) this.app.setPrompt(`Click on a ${LABEL[this.kind].toLowerCase()} run.`);
    return hit;
  }
}

export class MepBranchTool extends MepPartTool {
  get mode() {
    return 'branch';
  }

  get title() {
    return this.kind === 'duct' ? 'Duct Branch / Take-Off' : `${LABEL[this.kind]} Branch`;
  }

  get prompt() {
    return this.from ? 'Click where the branch goes' : `Click on a ${LABEL[this.kind].toLowerCase()} run where the branch starts`;
  }

  options() {
    return this.sizeOptions();
  }

  down(ev) {
    if (!this.from) {
      const hit = this.pickRun(ev);
      if (!hit) return;
      if (hit.at.t <= 0.02 || hit.at.t >= 0.98) return this.app.setPrompt('Start the branch along the run, not at its end (the route continues there).');
      this.from = hit;
      this.app.setPrompt(this.prompt);
      return;
    }
    const to = this.snap(ev, this.from.at.p);
    if (!to) return;
    const br = branchRun(this.doc.get(this.from.run.id), this.from.at.p, to, this.sizePatch());
    if (!br) return;
    this.app.commit(this.title, () => {
      this.doc.add(br);
      refreshFittings(this.doc);
    });
    this.from = null;
    this.app.setPrompt(this.prompt);
  }

  move(ev) {
    this.cursor = this.snap(ev, this.from?.at.p || null);
    this.app.requestRender();
  }

  cancel() {
    if (this.from) {
      this.from = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    if (this.from && this.cursor) strokeModel(ctx, [this.from.at.p, this.cursor], (p) => vc.modelToScreen(p), vp.theme.preview, 3);
    this.drawSnap(ctx, vc, vp);
  }
}

export class MepFittingTool extends MepPartTool {
  get mode() {
    return 'fitting';
  }

  get title() {
    return `${LABEL[this.kind]} Fitting`;
  }

  /** The part chosen in the options: 'split' (a transition where the run is clicked) or a library part. */
  get part() {
    return this.o.part || 'split';
  }

  get prompt() {
    if (this.part === 'split') return 'Click on a run where the size changes: a transition goes there, the run after it takes the new size';
    return 'Click to place the fitting (on the end of a run it follows that run and joins it)';
  }

  options() {
    const o = this.o;
    const parts = [{ value: 'split', label: 'Transition on a run' }, ...FITTING_LIBRARY.filter((x) => !x.families || x.families.includes(this.kind))];
    const sel = h('select.input.sm', { 'aria-label': 'Fitting' }, parts.map((x) => h('option', { value: x.value }, x.label)));
    sel.value = this.part;
    sel.addEventListener('change', () => {
      o.part = sel.value;
      this.app.renderOptions();
      this.app.setPrompt(this.prompt);
    });
    const out = [h('div.ob-group', h('label', 'Fitting'), sel), ...this.sizeOptions()];
    if (this.part !== 'split') {
      const rot = h('input.input.sm.num', { type: 'number', value: o.rotation || 0, 'aria-label': 'Rotation', step: 15 });
      rot.addEventListener('keydown', (e) => e.stopPropagation());
      rot.addEventListener('change', () => (o.rotation = +rot.value || 0));
      out.push(h('div.ob-group', h('label', 'Rotation°'), rot), lengthField(this, 'Height', o.z || 0, (v) => (o.z = v)));
    }
    return out;
  }

  /** The size of a placed fitting: the options, else the run's, else the current type's. */
  sizeFor(run) {
    const base = mepSize(this.doc, run || { kind: this.kind, typeId: this.app.currentType(this.kind)?.id });
    const o = this.o;
    if (base.round) return o.diameter > 0 ? { ...base, w: o.diameter, h: o.diameter } : base;
    return { ...base, w: o.width > 0 ? o.width : base.w, h: o.height > 0 ? o.height : base.h };
  }

  down(ev) {
    if (this.part !== 'split') return this.place(ev);
    const hit = this.pickRun(ev);
    if (!hit) return;
    const patch = this.sizePatch();
    if (!Object.keys(patch).length) return this.app.setPrompt('Give the size after the fitting first.');
    this.app.commit(this.title, () => {
      splitRun(this.doc, hit.run.id, hit.at.t, patch);
      refreshFittings(this.doc);
    });
  }

  place(ev) {
    const q = this.snap(ev) || ev.p;
    if (!q) return;
    const doc = this.doc;
    const tol = 12 * this.vc.mmPerPx();
    // At the end of a run: the fitting continues it.
    let attach = null;
    for (const r of doc.all(this.kind)) {
      const ends = runEnds(doc, r);
      for (const end of [0, 1]) {
        const p = ends[end];
        if (Math.hypot(p[0] - q[0], p[1] - q[1]) <= Math.max(tol, mepSize(doc, r).w / 2)) {
          const o = ends[1 - end];
          attach = { run: r, end, p, along: [p[0] - o[0], p[1] - o[1], p[2] - o[2]] };
        }
      }
    }
    const levelId = this.vc.view?.levelId || doc.levels()[0]?.id;
    const run = attach?.run || null;
    const size = this.sizeFor(run);
    const f = placedFitting({
      family: this.kind,
      part: this.part,
      at: attach ? [attach.p[0], attach.p[1]] : q,
      z: attach ? attach.p[2] : levelElevation(doc, levelId) + (+this.o.z || 0),
      rotation: +this.o.rotation || 0,
      along: attach ? attach.along : null,
      size: run ? mepSize(doc, run) : size,
      size2: this.part === 'reducer' ? size : null,
      system: run ? run.system ?? systemOf(run).value : systemOf({ kind: this.kind }).value,
      levelId: run?.levelId || levelId,
      attach: attach ? { id: attach.run.id, end: attach.end } : null,
    });
    if (!f) return;
    // On a run's end the fitting's first leg takes the end of the run (the run is trimmed back to it).
    this.app.commit(this.title, () => doc.add(f));
  }
}
