/**
 * Stretch: draw a box round the points to move, then give the distance by
 * two clicks. Points inside the box move; the rest of each element stays.
 */
import { Tool } from './tool.js';
import { strokeModel } from '../views/overlay.js';
import { stretchPatches } from '../core/editmore.js';

export class StretchTool extends Tool {
  get title() {
    return 'Stretch';
  }

  get prompt() {
    return !this.c0 ? 'Click a corner of the box round the points to stretch' : !this.box ? 'Click the opposite corner' : !this.a ? 'Click the point to move from' : 'Click where it goes';
  }

  start() {
    this.c0 = this.box = this.a = null;
    this.app.setPrompt(this.prompt);
  }

  ids() {
    return this.app.selection.size ? [...this.app.selection] : [...this.vc.layer.items.keys()].filter((id) => this.doc.has(id));
  }

  down(ev) {
    const p = this.snap(ev, this.a || this.c0 || null);
    if (!p) return;
    if (!this.c0) this.c0 = p;
    else if (!this.box) this.box = { x0: Math.min(this.c0[0], p[0]), y0: Math.min(this.c0[1], p[1]), x1: Math.max(this.c0[0], p[0]), y1: Math.max(this.c0[1], p[1]) };
    else if (!this.a) this.a = p;
    else {
      const patches = stretchPatches(this.doc, this.ids(), this.box, [p[0] - this.a[0], p[1] - this.a[1]]);
      if (patches.length) this.app.commit('Stretch', () => patches.forEach((x) => this.doc.update(x.id, x.patch)));
      else this.app.toast('No points inside that box.');
      this.app.cancelTool(true);
      return;
    }
    this.app.setPrompt(this.prompt);
  }

  move(ev) {
    this.cursor = this.snap(ev, this.a || this.c0 || null);
    this.app.requestRender();
  }

  cancel() {
    if (this.c0) {
      this.start();
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    const S = (p) => vc.modelToScreen(p);
    const col = vp.theme.selCss || '#1f6fff';
    const b = this.box || (this.c0 && this.cursor ? { x0: this.c0[0], y0: this.c0[1], x1: this.cursor[0], y1: this.cursor[1] } : null);
    if (b) strokeModel(ctx, [[b.x0, b.y0], [b.x1, b.y0], [b.x1, b.y1], [b.x0, b.y1], [b.x0, b.y0]], S, col);
    if (this.a && this.cursor) strokeModel(ctx, [this.a, this.cursor], S, col);
    this.drawSnap(ctx, vc, vp);
  }
}
