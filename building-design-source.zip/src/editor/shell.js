/**
 * Shell tool: a barrel vault (click both ends of its axis) or a dome
 * (click its centre, then a point of its base circle), with span, rise and
 * thickness in the options bar (core/shell.js).
 */
import { Tool } from './tool.js';
import { h } from '../ui/dom.js';
import { segmented, lengthField } from './draw.js';
import { shellOutline, shellProfile, PROFILE_PRESETS } from '../core/shell.js';
import { fillModel, strokeModel } from '../views/overlay.js';
import { dist } from '../core/geom.js';
import { PLAN_VIEW_KINDS } from '../core/doc.js';

export class ShellTool extends Tool {
  get placingKind() {
    return 'shell';
  }

  get viewKinds() {
    return PLAN_VIEW_KINDS;
  }

  get title() {
    return 'Shell';
  }

  get o() {
    const imp = this.app.doc.units.system === 'imperial';
    return this.app.toolOptions('shell', { shape: 'vault', span: imp ? 4876.8 : 5000, rise: imp ? 1828.8 : 1800, thickness: imp ? 152.4 : 150 });
  }

  get prompt() {
    if (this.o.shape === 'dome' || this.o.shape === 'revolved') return this.first ? 'Click a point of the base circle' : 'Click the centre (the axis of revolution)';
    return this.first ? 'Click the other end of the vault axis' : 'Click the start of the vault axis';
  }

  options() {
    const o = this.o;
    const shape = segmented(
      [
        { value: 'vault', label: 'Vault', icon: 'roof' },
        { value: 'dome', label: 'Dome', icon: 'circle' },
        { value: 'extruded', label: 'Extruded', icon: 'roof' },
        { value: 'revolved', label: 'Revolved', icon: 'circle' },
        { value: 'ruled', label: 'Ruled', icon: 'roof' },
      ],
      o.shape,
      (v) => {
        o.shape = v;
        this.first = null;
        this.app.renderOptions();
        this.app.setPrompt(this.prompt);
      },
      'Shell shape',
    );
    const free = ['extruded', 'revolved', 'ruled'].includes(o.shape);
    const out = [shape, o.shape === 'vault' || o.shape === 'extruded' || o.shape === 'ruled' ? lengthField(this, 'Span', o.span, (v) => (o.span = Math.max(100, v))) : null, lengthField(this, 'Rise', o.rise, (v) => (o.rise = Math.max(10, v))), lengthField(this, 'Thickness', o.thickness, (v) => (o.thickness = Math.max(1, v)))];
    if (free) {
      // The profile: a preset (Arch, Parabola, Gable, Wave); a ruled shell runs to a lower one at its far end.
      const pre = h('select.input.sm', { 'aria-label': 'Profile' }, ...PROFILE_PRESETS.map((x) => h('option', { value: x.value }, x.label)));
      pre.value = o.preset || 'arch';
      pre.addEventListener('change', () => (o.preset = pre.value));
      out.push(h('div.ob-group', h('label', 'Profile'), pre));
    }
    if (o.shape === 'revolved') {
      const sw = h('input.input.sm.num', { type: 'number', min: 10, max: 360, value: o.sweep || 360, 'aria-label': 'Revolution angle' });
      sw.addEventListener('change', () => (o.sweep = Math.max(10, Math.min(360, +sw.value || 360))));
      sw.addEventListener('keydown', (e) => e.stopPropagation());
      out.push(h('div.ob-group', h('label', 'Angle'), sw));
    }
    return out;
  }

  element(p) {
    const o = this.o;
    const common = { kind: 'shell', levelId: this.app.activeLevelId(), baseOffset: 0, shape: o.shape, rise: o.rise, thickness: o.thickness, materialId: 'mat-concrete' };
    if (o.shape === 'dome') return { ...common, at: this.first, radius: dist(this.first, p) };
    if (o.shape === 'revolved') {
      const radius = dist(this.first, p);
      const el = { ...common, at: this.first, radius, sweep: o.sweep || 360, preset: o.preset || 'arch' };
      return { ...el, profile: shellProfile(el, 'revolved') };
    }
    const el = { ...common, a: this.first, b: p, span: o.span };
    if (o.shape === 'extruded' || o.shape === 'ruled') {
      el.preset = o.preset || 'arch';
      el.profile = shellProfile(el, 'extruded');
      if (o.shape === 'ruled') el.profileEnd = shellProfile({ ...el, rise: o.rise / 2 }, 'extruded');
    }
    return el;
  }

  down(ev) {
    const p = this.snap(ev, this.first);
    if (!p) return;
    if (!this.first) {
      this.first = p;
      this.app.setPrompt(this.prompt);
      return;
    }
    if (dist(this.first, p) < 100) return;
    const el = this.element(p);
    this.app.commit('Shell', () => this.doc.add(el));
    this.first = null;
    this.app.setPrompt(this.prompt);
  }

  move(ev) {
    this.cursor = this.snap(ev, this.first);
    this.app.requestRender();
  }

  cancel() {
    if (this.first) {
      this.first = null;
      this.app.setPrompt(this.prompt);
      return false;
    }
    return true;
  }

  drawOverlay(ctx, vc, vp) {
    this.drawSnap?.(ctx, vc, vp);
    if (!this.first || !this.cursor || dist(this.first, this.cursor) < 1) return;
    const S = (q) => vc.modelToScreen(q);
    const o = shellOutline(this.element(this.cursor));
    fillModel(ctx, o, S, vp.theme.preview, 0.12);
    strokeModel(ctx, o, S, vp.theme.preview, 1.4, null, true);
  }
}
