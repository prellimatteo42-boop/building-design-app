/** A ray tracing worker: builds the scene once, then keeps sending samples of the whole image. */
import { buildScene, tracePass } from '../core/raytrace.js';

self.onmessage = (e) => {
  const { pos, col, cam, width, height, options, seed, passes } = e.data;
  const scene = buildScene({ pos, col });
  for (let i = 0; i < passes; i++) {
    const img = tracePass(scene, cam, width, height, options, (seed + i * 7919) >>> 0);
    self.postMessage({ img }, [img.buffer]);
  }
  self.postMessage({ done: true });
};
