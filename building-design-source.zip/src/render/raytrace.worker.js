/** A ray tracing worker: builds the scene once, then keeps sending samples of the whole image. */
import { buildScene, tracePass, tracePrimary } from '../core/raytrace.js';

self.onmessage = (e) => {
  const { pos, col, nrm, uv, tid, textures, glow, cam, width, height, options, seed, passes, guide } = e.data;
  const scene = buildScene({ pos, col, nrm, uv, tid, textures, glow });
  if (guide) self.postMessage({ guide: tracePrimary(scene, cam, width, height, options.clip) });
  for (let i = 0; i < passes; i++) {
    const img = tracePass(scene, cam, width, height, options, (seed + i * 7919) >>> 0);
    self.postMessage({ img }, [img.buffer]);
  }
  self.postMessage({ done: true });
};
