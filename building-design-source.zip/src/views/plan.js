/**
 * Plan view controller (floor and ceiling plans): 2D camera, graphics kept
 * in sync with the scene, picking, window selection, snapping features and
 * text overlay.
 */
import { classColors } from '../core/attrs.js';
import { viewFrame } from '../core/elevation.js';
import { runSlope } from '../core/mepnet.js';
import { MEP_KINDS } from '../core/mep.js';
import { viewMatrix2D } from '../render/renderer2d.js';
import { planContext, PlanBuilder, W, dimensionGeometry } from '../core/plan.js';
import { pointInPolygon, distToSegment, bboxIntersects, bboxContains, segmentIntersectsBox, bboxUnion } from '../core/geom.js';
import { snapFeatures } from '../editor/snap.js';
import { drawLayerTexts } from './overlay.js';
import { traceReference, traceReferences, traceTransform, transformBuilder } from '../core/trace.js';
import { landingGuides } from '../core/landingguides.js';
import { figureHandlePoints, fillHandlePoints, splineTangentHandles, walkingLine, distanceHits } from '../core/onscreen.js';
import { wallAxis, openingSize } from '../core/model.js';
import { add as add2d, scale as scale2d } from '../core/geom.js';
import { drawTempDim as drawDimOverlay } from './overlay.js';
import { formatLength as fmtLen } from '../core/units.js';
import { mepNetworks } from '../core/mepnet.js';
import { COMPARE_COLORS } from '../core/compare.js';
import { ZoomHistory, actualSizeZoom, draftingOf, gridLines, referenceLines } from '../core/drafting.js';

/** Pick priority: lower wins when several elements are under the cursor. */
const PICK_RANK = {
  text: 0,
  tag: 0,
  dimension: 0,
  door: 1,
  window: 1,
  component: 2,
  column: 2,
  stair: 2,
  ramp: 2,
  railing: 2,
  detailLine: 2,
  modelLine: 2,
  roomSeparator: 2,
  areaBoundary: 2,
  duct: 2,
  pipe: 2,
  cableTray: 2,
  conduit: 2,
  wall: 3,
  beam: 3,
  brace: 3,
  grid: 4,
  propertyLine: 4,
  footing: 6,
  wallFooting: 6,
  mass: 6,
  topo: 8,
  refPlane: 4,
  plan: 4,
  ceilingPlan: 4,
  area: 5,
  section: 4,
  elevation: 4,
  room: 5,
  ceiling: 6,
  roof: 6,
  floor: 7,
};

const CELL = 3000;

export class PlanController {
  constructor(app, view) {
    this.app = app;
    this.viewId = view.id;
    this.graphical = true;
    this.is2D = true;
    this.vp = app.viewport;
    this.layer = this.vp.r2.layer();
    this.syncedVersion = -1;
    this.syncedView = null;
    this.grid = new Map();
    this.bounds = new Map();
    this.featureCache = new Map();
    const saved = app.viewStates.get(view.id);
    this.cam = saved ? { ...saved } : null;
    // Archicad's Previous / Next Zoom: the cameras the user settled on.
    this.zoomHistory = app.zoomHistories?.get(view.id) || new ZoomHistory();
    app.zoomHistories?.set(view.id, this.zoomHistory);
  }

  /** Record the camera once navigation settles (a burst of wheel steps counts once). */
  noteCamera(now = false) {
    clearTimeout(this.zoomTimer);
    const rec = () => this.cam && this.zoomHistory.push(this.cam);
    if (now) rec();
    else this.zoomTimer = setTimeout(rec, 350);
  }

  /** Go to a camera of the zoom history: -1 previous, +1 next. */
  stepZoom(dir) {
    clearTimeout(this.zoomTimer);
    if (this.cam) this.zoomHistory.push(this.cam);
    const c = dir < 0 ? this.zoomHistory.back() : this.zoomHistory.forward();
    if (!c) return false;
    this.cam = c;
    this.userMoved = true;
    this.vp.requestRender();
    return true;
  }

  /** Zoom so the drawing shows at its printed size on screen. */
  actualSize() {
    if (!this.cam) return;
    this.cam = { ...this.cam, zoom: actualSizeZoom(this.view?.kind === 'sheet' ? 1 : this.view?.scale) };
    this.userMoved = true;
    this.noteCamera(true);
    this.vp.requestRender();
  }

  get view() {
    return this.app.doc.get(this.viewId);
  }

  get scene() {
    return this.app.scene;
  }

  activate() {
    if (!this.cam) {
      this.sync();
      this.zoomExtents(false);
    }
  }

  deactivate() {
    this.app.viewStates.set(this.viewId, { ...this.cam });
  }

  dispose() {
    this.layer.dispose();
  }

  // Graphics ----------------------------------------------------------------------

  sync() {
    const view = this.view;
    if (!view) return;
    const scene = this.scene;
    const trace = this.app.traces?.get(view.id) || null;
    if (this.syncedVersion === scene.version && this.syncedView === view && this.syncedTrace === trace) return;
    const pc = planContext(scene.doc, view, scene.walls, scene.rooms, scene.areas);
    const keep = new Set();
    this.grid.clear();
    this.bounds.clear();
    // Pictures elements draw in plan (GDL objects' PICTURE2), as images under the linework.
    this.pictures = [];
    for (const el of scene.planCandidates(view)) {
      const g = scene.planOf(view, el, pc);
      if (!g) continue;
      keep.add(el.id);
      (g.pictures || []).forEach((q, k) => {
        const [p0, p1, , p3] = q.pts;
        const w = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
        const h = Math.hypot(p3[0] - p0[0], p3[1] - p0[1]);
        this.pictures.push({ id: `${el.id}#${k}`, el: el.id, src: q.src, at: p0, w, h, rotation: (Math.atan2(p1[1] - p0[1], p1[0] - p0[0]) * 180) / Math.PI });
      });
      this.layer.set(el.id, scene.indexOf(el.id), el.kind, g, el.drawZ ?? null);
      const b = scene.planBounds(view, el.id);
      if (b) {
        this.bounds.set(el.id, b);
        this.index(el.id, b);
      }
    }
    // Underlay: the plan of another level, drawn in halftone and not selectable.
    const under = this.underlayView(view);
    if (under) {
      const upc = planContext(scene.doc, under, scene.walls, scene.rooms);
      for (const el of scene.planCandidates(under)) {
        if (el.viewId || ['section', 'elevation', 'grid', 'room', 'roomSeparator'].includes(el.kind) || keep.has(el.id)) continue;
        const g = scene.planOf(under, el, upc);
        if (!g) continue;
        const key = `u:${el.id}`;
        keep.add(key);
        this.layer.set(key, scene.indexOf(key), el.kind === 'wall' ? 'floor' : el.kind, g);
      }
    }
    // Trace & Reference: another drawing, moved and rotated, faded and not selectable.
    this.traceLines = [];
    const many = trace?.refId === 'entire';
    for (const ref of traceReferences(scene.doc, view, trace)) {
      const rpc = planContext(scene.doc, ref, scene.walls, scene.rooms, scene.areas);
      const T = traceTransform(trace);
      for (const el of scene.planCandidates(ref)) {
        if (['section', 'elevation'].includes(el.kind)) continue;
        const g = scene.planOf(ref, el, rpc);
        if (!g) continue;
        const key = many ? `t:${ref.id}:${el.id}` : `t:${el.id}`;
        const b = transformBuilder(g, T, +trace.rotation || 0);
        keep.add(key);
        // Reference on Top: drawn over the active content instead of under it.
        this.layer.set(key, scene.indexOf(key), el.kind, b, trace.onTop ? 12 : null);
        for (const l of b.lines) this.traceLines.push(l);
      }
    }
    // The crop region's outline, when it is shown (not an element: not selectable).
    if (view.cropShow && view.crop) {
      const key = `crop:${view.id}`;
      const r = view.crop;
      const b = new PlanBuilder();
      b.poly(
        [
          [r.x0, r.y0],
          [r.x1, r.y0],
          [r.x1, r.y1],
          [r.x0, r.y1],
        ],
        true,
        W.light,
        1,
      );
      keep.add(key);
      this.layer.set(key, scene.indexOf(key), 'overlay', b);
    }
    this.layer.retain(keep);
    this.syncedVersion = scene.version;
    this.syncedView = view;
    this.syncedTrace = trace;
    // The traced reference's pieces are new to the scene: give them their state (faded, split) on the next frame.
    if (this.traceLines.length) {
      this.app.flagsKey = null;
      this.app.requestRender();
    }
    this.featureCache.clear();
  }

  /** Plan view of the underlay level (view.underlay: 'below' | levelId | null). */
  underlayView(view) {
    const doc = this.app.doc;
    let levelId = view.underlay;
    if (!levelId) return null;
    if (levelId === 'below') {
      const lv = doc.levels();
      const i = lv.findIndex((l) => l.id === view.levelId);
      levelId = i > 0 ? lv[i - 1].id : null;
    }
    if (!levelId || levelId === view.levelId) return null;
    const base = doc.all('plan').find((p) => p.levelId === levelId);
    if (!base) return null;
    // Same object while its inputs are unchanged, so cached graphics stay valid.
    if (this._under?.base === base && this._under.view === view) return this._under.v;
    const v = { ...base, id: `${view.id}:underlay`, hiddenIds: view.hiddenIds, hiddenCats: view.hiddenCats, scale: view.scale, detail: 'coarse' };
    this._under = { base, view, v };
    return v;
  }

  index(id, b) {
    const x0 = Math.floor(b.x0 / CELL);
    const x1 = Math.floor(b.x1 / CELL);
    const y0 = Math.floor(b.y0 / CELL);
    const y1 = Math.floor(b.y1 / CELL);
    if ((x1 - x0 + 1) * (y1 - y0 + 1) > 4000) {
      // Very large items live in a catch-all bucket.
      if (!this.grid.has('big')) this.grid.set('big', new Set());
      this.grid.get('big').add(id);
      return;
    }
    for (let x = x0; x <= x1; x++)
      for (let y = y0; y <= y1; y++) {
        const k = `${x},${y}`;
        if (!this.grid.has(k)) this.grid.set(k, new Set());
        this.grid.get(k).add(id);
      }
  }

  /** Ids whose bounds touch a model-space box. */
  query(box) {
    const out = new Set(this.grid.get('big') || []);
    const x0 = Math.floor(box.x0 / CELL);
    const x1 = Math.floor(box.x1 / CELL);
    const y0 = Math.floor(box.y0 / CELL);
    const y1 = Math.floor(box.y1 / CELL);
    if ((x1 - x0 + 1) * (y1 - y0 + 1) > 2500) {
      for (const id of this.bounds.keys()) out.add(id);
      return [...out].filter((id) => bboxIntersects(this.bounds.get(id) || box, box));
    }
    for (let x = x0; x <= x1; x++)
      for (let y = y0; y <= y1; y++) {
        const s = this.grid.get(`${x},${y}`);
        if (s) for (const id of s) out.add(id);
      }
    return [...out].filter((id) => {
      const b = this.bounds.get(id);
      return b && bboxIntersects(b, box);
    });
  }

  render(vp) {
    this.sync();
    if (!this.cam) this.zoomExtents(false);
    const view = this.view;
    const scale = +view?.scale || 100;
    const images = [...this.app.doc.all('image').filter((i) => i.viewId === view.id), ...(this.pictures || [])];
    if (images.length) {
      const { cx, cy, zoom } = this.cam;
      vp.images.draw(images, viewMatrix2D(cx, cy, zoom, vp.width, vp.height, [0, 0], this.cam.rot || 0), vp.theme, (id) => this.app.flagsOf(String(id).split('#')[0]));
    }
    const split = this.app.traces?.get(this.view?.id)?.split;
    this.vp.r2.draw(this.layer, this.camera(), vp.theme, { dashScale: scale, spacing: scale * 1.6, thin: this.app.settings.thinLines, noBold: this.app.settings.boldCutLines === false, classColors: classColors(this.app.doc.project), pen: this.view?.penSet, split: split != null ? split * this.vp.canvas.width : -1 });
  }

  camera() {
    const vp = this.vp;
    const { cx, cy, zoom } = this.cam;
    return {
      matrix: viewMatrix2D(cx, cy, zoom, vp.width, vp.height, this.layer.origin, this.cam.rot || 0),
      width: vp.canvas.width,
      height: vp.canvas.height,
      dpr: vp.dpr,
    };
  }

  drawOverlay(ctx, vp) {
    const drafting = draftingOf(this.app.doc.project);
    if (drafting.grid.show && this.app.settings.drawingAids !== false) this.drawConstructionGrid(ctx, vp, drafting.grid);
    else if (this.app.settings.workPlaneGrid && !this.cam.rot) this.drawWorkPlane(ctx, vp);
    if (drafting.userOrigin[0] || drafting.userOrigin[1]) this.drawUserOrigin(ctx, vp, drafting.userOrigin);
    // Rulers read along the screen's edges: only while the view is not turned.
    if (this.app.settings.rulers && !this.cam.rot) this.drawRulers(ctx, vp, drafting.userOrigin);
    if (this.app.settings.refLines && this.app.settings.drawingAids !== false) this.drawReferenceLines(ctx, vp);
    if (this.app.settings.highlightSourceMarkers) this.drawSourceMarkers(ctx, vp);
    if (this.app.settings.mepSlopes) this.drawMepSlopes(ctx, vp);
    if (this.app.settings.markerRange) this.drawMarkerRange(ctx, vp);
    if (this.app.settings.landingGuides) this.drawLandingGuides(ctx, vp);
    if (this.app.settings.dimRefLines) this.drawDimensionRefs(ctx, vp);
    this.drawHandles(ctx);
    if (this.app.settings.distanceGuides) this.drawDistanceGuides(ctx, vp);
    if (this.app.settings.openMepConnections) this.drawOpenMep(ctx);
    if (this.app.settings.walkingLines) this.drawWalkingLines(ctx);
    // Trace & Reference splitter: the line the reference stops at.
    const split = this.app.traces?.get(this.view?.id)?.split;
    if (split != null) {
      const x = split * vp.width;
      ctx.save();
      ctx.strokeStyle = vp.theme.selCss || '#1f6fff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, vp.height);
      ctx.stroke();
      ctx.fillStyle = vp.theme.selCss || '#1f6fff';
      ctx.fillRect(x - 6, vp.height / 2 - 18, 12, 36);
      ctx.restore();
    }
    drawLayerTexts(ctx, this.layer, (p) => this.modelToScreen(p), this.cam.zoom, vp.theme, (id) => this.app.flagsOf(id), this.cam.rot || 0);
    if (this.app.settings.drawingAids !== false) this.drawGuides(ctx, vp);
    this.drawCompare(ctx);
  }

  /** Model Compare: outlines of new (green) and modified (orange) elements. */
  drawCompare(ctx) {
    const cmp = this.app.compareHighlight;
    if (!cmp) return;
    ctx.save();
    ctx.lineWidth = 2.5;
    for (const [set, c] of [[cmp.added, COMPARE_COLORS.added], [cmp.modified, COMPARE_COLORS.modified]]) {
      ctx.strokeStyle = `rgb(${c.join(',')})`;
      ctx.fillStyle = `rgba(${c.join(',')},0.12)`;
      for (const id of set) {
        const it = this.layer.items.get(id);
        if (!it) continue;
        for (const poly of it.g.picks || []) {
          ctx.beginPath();
          poly.forEach((p, i) => {
            const s = this.modelToScreen(p);
            if (i) ctx.lineTo(s.x, s.y);
            else ctx.moveTo(s.x, s.y);
          });
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      }
    }
    ctx.restore();
  }

  /** Guide lines (Archicad's): infinite dashed lines across the view, to draw and snap against. */
  drawGuides(ctx, vp) {
    const guides = this.app.guides?.get(this.viewId);
    if (!guides?.length) return;
    const reach = (Math.hypot(vp.width, vp.height) / this.cam.zoom) * 1.5;
    const c = [this.cam.cx, this.cam.cy];
    ctx.save();
    ctx.strokeStyle = vp.theme.guide || '#0ea5e9';
    ctx.globalAlpha = 0.85;
    ctx.lineWidth = 1;
    ctx.setLineDash([8, 5]);
    for (const g of guides) {
      if (g.seg) {
        const a = this.modelToScreen(g.seg[0]);
        const b = this.modelToScreen(g.seg[1]);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        continue;
      }
      // The part of the line around the view's centre.
      const t = (c[0] - g.p[0]) * g.d[0] + (c[1] - g.p[1]) * g.d[1];
      const m = [g.p[0] + g.d[0] * t, g.p[1] + g.d[1] * t];
      const a = this.modelToScreen([m[0] - g.d[0] * reach, m[1] - g.d[1] * reach]);
      const b = this.modelToScreen([m[0] + g.d[0] * reach, m[1] + g.d[1] * reach]);
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.restore();
  }

  /** The construction grid (Archicad's Grids & Background): its spacing and rotation, thinned when zoomed out. */
  drawConstructionGrid(ctx, vp, grid) {
    // The four screen corners in the model (the view may be turned).
    const cs = [this.screenToModel(0, 0), this.screenToModel(vp.width, 0), this.screenToModel(vp.width, vp.height), this.screenToModel(0, vp.height)];
    const box = { x0: Math.min(...cs.map((c) => c[0])), y0: Math.min(...cs.map((c) => c[1])), x1: Math.max(...cs.map((c) => c[0])), y1: Math.max(...cs.map((c) => c[1])) };
    const lines = gridLines(grid, box, 8 / this.cam.zoom);
    ctx.save();
    ctx.strokeStyle = vp.theme.guide || '#0ea5e9';
    ctx.lineWidth = 1;
    for (const [list, alpha] of [
      [lines.minor, 0.12],
      [lines.major, 0.28],
    ]) {
      ctx.globalAlpha = alpha;
      ctx.beginPath();
      for (const [p, q] of list) {
        const sp = this.modelToScreen(p);
        const sq = this.modelToScreen(q);
        ctx.moveTo(sp.x, sp.y);
        ctx.lineTo(sq.x, sq.y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  /** Reference lines of walls, beams, railings, services, roof pivot lines and stair baselines, with their direction. */
  /** MEP Slopes on screen: the fall of each sloping run, in percent, with an arrow downhill. */
  drawMepSlopes(ctx, vp) {
    const doc = this.app.doc;
    ctx.save();
    ctx.font = `11px ${vp.theme.font || 'system-ui'}`;
    ctx.fillStyle = vp.theme.snap || '#d97706';
    ctx.textAlign = 'center';
    for (const k of MEP_KINDS)
      for (const el of doc.all(k)) {
        if (el.levelId !== this.view.levelId) continue;
        const s = runSlope(doc, el);
        if (s == null || Math.abs(s) < 0.01) continue;
        const [hi, lo] = s > 0 ? [el.b, el.a] : [el.a, el.b];
        const m = this.modelToScreen([(el.a[0] + el.b[0]) / 2, (el.a[1] + el.b[1]) / 2]);
        const q = this.modelToScreen(lo);
        const r = this.modelToScreen(hi);
        const ang = Math.atan2(q.y - r.y, q.x - r.x);
        ctx.fillText(`${Math.abs(s).toFixed(1)}%`, m.x, m.y - 8);
        ctx.beginPath();
        ctx.moveTo(m.x + Math.cos(ang) * 14, m.y + Math.sin(ang) * 14);
        ctx.lineTo(m.x + Math.cos(ang + 2.6) * 7 + Math.cos(ang) * 14, m.y + Math.sin(ang + 2.6) * 7 + Math.sin(ang) * 14);
        ctx.lineTo(m.x + Math.cos(ang - 2.6) * 7 + Math.cos(ang) * 14, m.y + Math.sin(ang - 2.6) * 7 + Math.sin(ang) * 14);
        ctx.closePath();
        ctx.fill();
      }
    ctx.restore();
  }

  /** Marker Range: how far each section and elevation looks, as a dashed area beyond its line. */
/** Dimension Reference Lines: what each dimension point is tied to (a ring on elements it follows, a cross where it is loose). */
  /** Distance Guides: while drawing, how far the point is from the nearest edges and openings. */
  drawDistanceGuides(ctx, vp) {
    const app = this.app;
    const p = app.tool && app.tool !== app.selectTool ? app.tool.snapRes?.point : null;
    if (!p) return;
    const doc = app.doc;
    const lines = [];
    const s = app.settings;
    for (const w of doc.all('wall')) {
      if (w.levelId !== this.view.levelId) continue;
      const ax = wallAxis(doc, w);
      if (s.guideToEdges !== false)
        for (const k of [1, -1]) lines.push({ a: add2d(ax.a, scale2d(ax.n, k * ax.half)), b: add2d(ax.b, scale2d(ax.n, k * ax.half)) });
      if (s.guideToOpenings)
        for (const o of [...doc.all('door'), ...doc.all('window')]) {
          if (o.hostId !== w.id) continue;
          const half = openingSize(doc, o).width / 2;
          for (const k of [o.t - half, o.t + half]) {
            const c = add2d(ax.a, scale2d(ax.dir, k));
            lines.push({ a: add2d(c, scale2d(ax.n, ax.half)), b: add2d(c, scale2d(ax.n, -ax.half)) });
          }
        }
    }
    const a = this.modelToScreen(p);
    for (const hit of distanceHits(lines, p, 6000)) drawDimOverlay(ctx, a, this.modelToScreen(hit.to), fmtLen(hit.d, doc.units), 'rgba(31, 111, 255, 0.9)', vp.theme, 0);
  }

  /** Figure, fill and spline handles (On-Screen View Options). */
  drawHandles(ctx) {
    const s = this.app.settings;
    if (!s.figureHandles && !s.fillHandles && !s.splineHandles) return;
    const doc = this.app.doc;
    const id = this.view.id;
    const box = (p, color) => {
      const q = this.modelToScreen(p);
      ctx.fillStyle = color;
      ctx.fillRect(q.x - 2.5, q.y - 2.5, 5, 5);
    };
    ctx.save();
    if (s.figureHandles) figureHandlePoints(doc, id).forEach((p) => box(p, 'rgba(31, 111, 255, 0.9)'));
    if (s.fillHandles) fillHandlePoints(doc, id).forEach((p) => box(p, 'rgba(0, 150, 110, 0.9)'));
    if (s.splineHandles) {
      ctx.strokeStyle = 'rgba(190, 70, 170, 0.9)';
      ctx.lineWidth = 1;
      for (const sp of doc.all('spline')) {
        if (sp.viewId !== id) continue;
        for (const t of splineTangentHandles(sp)) {
          const [a, b] = [this.modelToScreen(t.a), this.modelToScreen(t.b)];
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
          box(t.a, 'rgba(190, 70, 170, 0.9)');
          box(t.b, 'rgba(190, 70, 170, 0.9)');
        }
      }
    }
    ctx.restore();
  }

  /** Ends of duct, pipe and cable runs that nothing is connected to, on this story. */
  drawOpenMep(ctx) {
    const doc = this.app.doc;
    ctx.save();
    ctx.strokeStyle = 'rgba(220, 40, 40, 0.95)';
    ctx.lineWidth = 2;
    for (const n of mepNetworks(doc))
      for (const o of n.openEnds) {
        const run = doc.get(o.id);
        if (run?.levelId && this.view.levelId && run.levelId !== this.view.levelId) continue;
        const q = this.modelToScreen(o.p);
        ctx.beginPath();
        ctx.arc(q.x, q.y, 7, 0, Math.PI * 2);
        ctx.moveTo(q.x - 5, q.y - 5);
        ctx.lineTo(q.x + 5, q.y + 5);
        ctx.moveTo(q.x + 5, q.y - 5);
        ctx.lineTo(q.x - 5, q.y + 5);
        ctx.stroke();
      }
    ctx.restore();
  }

  /** Each stair's calculated walking line, a mark at every tread and the step rule. */
  drawWalkingLines(ctx) {
    const doc = this.app.doc;
    const color = 'rgba(214, 90, 20, 0.95)';
    ctx.save();
    ctx.font = '11px system-ui, sans-serif';
    for (const el of doc.all('stair')) {
      if (el.levelId !== this.view.levelId) continue;
      const w = walkingLine(doc, el);
      if (w.path.length < 2) continue;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 3]);
      ctx.beginPath();
      w.path.forEach((p, i) => {
        const q = this.modelToScreen(p);
        if (i) ctx.lineTo(q.x, q.y);
        else ctx.moveTo(q.x, q.y);
      });
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = color;
      for (const p of w.nodes) {
        const q = this.modelToScreen(p);
        ctx.beginPath();
        ctx.arc(q.x, q.y, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
      const at = this.modelToScreen(w.path[0]);
      ctx.fillText(`${w.risers} R ${Math.round(w.rise)} / T ${Math.round(w.going)}, 2R+T ${Math.round(w.step)}, L ${(w.length / 1000).toFixed(2)} m`, at.x + 8, at.y + 14);
    }
    ctx.restore();
  }

  drawDimensionRefs(ctx) {
    const doc = this.app.doc;
    ctx.save();
    ctx.lineWidth = 1;
    for (const d of doc.all('dimension')) {
      if (d.viewId !== this.view.id || !d.refs?.length || !d.dir) continue;
      const g = dimensionGeometry(doc, this.app.scene?.walls, d);
      d.refs.forEach((r, i) => {
        const p = this.modelToScreen(g.refs[i]);
        const q = this.modelToScreen(g.at(g.pos[i]));
        const tied = !!(r.id && doc.get(r.id));
        ctx.strokeStyle = tied ? 'rgba(30, 150, 90, 0.9)' : 'rgba(200, 80, 40, 0.9)';
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(q.x, q.y);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.beginPath();
        if (tied) ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
        else (ctx.moveTo(p.x - 4, p.y - 4), ctx.lineTo(p.x + 4, p.y + 4), ctx.moveTo(p.x + 4, p.y - 4), ctx.lineTo(p.x - 4, p.y + 4));
        ctx.stroke();
      });
    }
    ctx.restore();
  }

    /** Stair Landing Calculation Guidelines for the selected stairs (core/landingguides.js). */
  drawLandingGuides(ctx, vp) {
    const doc = this.app.doc;
    const stairs = [...this.app.selection].map((id) => doc.get(id)).filter((el) => el?.kind === 'stair' && el.levelId === this.view.levelId);
    if (!stairs.length) return;
    ctx.save();
    ctx.font = '11px system-ui, sans-serif';
    for (const st of stairs)
      for (const g of landingGuides(doc, st)) {
        const pts = g.path.map((p) => this.modelToScreen(p));
        ctx.strokeStyle = g.ok ? '#2b8a3e' : '#e8590c';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 4]);
        ctx.beginPath();
        pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = vp.theme.selCss || '#1f6fff';
        for (const x of g.ideal) {
          const q = this.modelToScreen(x.at);
          ctx.beginPath();
          ctx.arc(q.x, q.y, 4, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillText(`n=${x.n}: ${x.length}`, q.x + 6, q.y - 6);
        }
        const m = pts[Math.floor(pts.length / 2)];
        ctx.fillStyle = g.ok ? '#2b8a3e' : '#e8590c';
        ctx.fillText(`Landing walk line ${g.length} mm (step 2R+T = ${g.step})${g.ok ? ' ✓' : ''}`, m.x + 8, m.y + 14);
      }
    ctx.restore();
  }

  drawMarkerRange(ctx) {
    const doc = this.app.doc;
    ctx.save();
    ctx.strokeStyle = 'rgba(31, 111, 255, 0.7)';
    ctx.fillStyle = 'rgba(31, 111, 255, 0.06)';
    ctx.setLineDash([6, 4]);
    for (const v of doc.all('section', 'elevation')) {
      if (!v.a || !v.b) continue;
      const f = viewFrame(v);
      const far = f.far || 10000;
      const pts = [v.a, v.b, [v.b[0] + f.look[0] * far, v.b[1] + f.look[1] * far], [v.a[0] + f.look[0] * far, v.a[1] + f.look[1] * far]].map((p) => this.modelToScreen(p));
      ctx.beginPath();
      pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();
  }

  /** Highlight Source Markers: section and elevation lines and detail boundaries that define views, haloed. */
  drawSourceMarkers(ctx) {
    const doc = this.app.doc;
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 150, 0, 0.45)';
    ctx.lineWidth = 9;
    ctx.lineCap = 'round';
    for (const v of doc.all('section', 'elevation')) {
      if (!v.a || !v.b || (v.levelIds && !v.levelIds.includes(this.view.levelId))) continue;
      const a = this.modelToScreen(v.a);
      const c = this.modelToScreen(v.b);
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(c.x, c.y);
      ctx.stroke();
    }
    for (const v of doc.filter((x) => x.calloutOf === this.view.id && x.crop)) {
      const c = v.crop;
      const pts = [[c.x0, c.y0], [c.x1, c.y0], [c.x1, c.y1], [c.x0, c.y1]].map((p) => this.modelToScreen(p));
      ctx.beginPath();
      pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
      ctx.closePath();
      ctx.stroke();
    }
    ctx.restore();
  }

  drawReferenceLines(ctx, vp) {
    const lines = referenceLines(this.app.doc, this.view, this.app.settings.refLines);
    if (!lines.length) return;
    ctx.save();
    ctx.strokeStyle = vp.theme.snap || '#e8590c';
    ctx.fillStyle = vp.theme.snap || '#e8590c';
    ctx.lineWidth = 1.2;
    for (const l of lines) {
      const s = l.pts.map((p) => this.modelToScreen(p));
      ctx.setLineDash(l.pivot ? [10, 3, 2, 3] : [6, 3]);
      ctx.beginPath();
      s.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
      if (l.closed) ctx.closePath();
      ctx.stroke();
      if (l.arrow && s.length >= 2) {
        // An arrow at the end shows which way the element was drawn.
        const a = s[s.length - 2];
        const b = s[s.length - 1];
        const ang = Math.atan2(b.y - a.y, b.x - a.x);
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(b.x, b.y);
        ctx.lineTo(b.x - 9 * Math.cos(ang - 0.4), b.y - 9 * Math.sin(ang - 0.4));
        ctx.lineTo(b.x - 9 * Math.cos(ang + 0.4), b.y - 9 * Math.sin(ang + 0.4));
        ctx.closePath();
        ctx.fill();
      }
    }
    ctx.restore();
  }

  /** The user origin: a small cross with its axes, where coordinates are read from. */
  drawUserOrigin(ctx, vp, o) {
    const s = this.modelToScreen(o);
    ctx.save();
    ctx.strokeStyle = vp.theme.snap || '#e8590c';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(s.x - 10, s.y);
    ctx.lineTo(s.x + 18, s.y);
    ctx.moveTo(s.x, s.y + 10);
    ctx.lineTo(s.x, s.y - 18);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(s.x, s.y, 4, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  /** Rulers along the top and left edges, in the project's units from the user origin. */
  drawRulers(ctx, vp, o) {
    const T = 18;
    const u = this.app.doc.units;
    const imp = u.system === 'imperial';
    const steps = imp ? [25.4, 76.2, 152.4, 304.8, 1524, 3048, 15240, 30480, 152400] : [10, 50, 100, 500, 1000, 5000, 10000, 50000, 100000];
    const major = steps.find((st) => st * this.cam.zoom >= 70) ?? steps.at(-1);
    const minor = major / 5;
    ctx.save();
    ctx.fillStyle = vp.theme.bgCss || '#fff';
    ctx.globalAlpha = 0.92;
    ctx.fillRect(0, 0, vp.width, T);
    ctx.fillRect(0, 0, T, vp.height);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = vp.theme.inkCss || '#333';
    ctx.fillStyle = vp.theme.inkCss || '#333';
    ctx.font = '10px system-ui, sans-serif';
    ctx.lineWidth = 1;
    const a = this.screenToModel(0, vp.height);
    const b = this.screenToModel(vp.width, 0);
    const label = (v) => (imp ? `${Math.round((v / 304.8) * 10) / 10}'` : Math.abs(v) >= 1000 ? `${Math.round(v / 100) / 10} m` : `${Math.round(v)}`);
    ctx.beginPath();
    for (let x = Math.ceil((a[0] - o[0]) / minor) * minor; x + o[0] <= b[0]; x += minor) {
      const px = Math.round(this.modelToScreen([x + o[0], 0]).x) + 0.5;
      const big = Math.abs(x / major - Math.round(x / major)) < 1e-6;
      ctx.moveTo(px, T);
      ctx.lineTo(px, big ? 4 : T - 5);
      if (big) ctx.fillText(label(x), px + 2, 11);
    }
    for (let y = Math.ceil((a[1] - o[1]) / minor) * minor; y + o[1] <= b[1]; y += minor) {
      const py = Math.round(this.modelToScreen([0, y + o[1]]).y) + 0.5;
      const big = Math.abs(y / major - Math.round(y / major)) < 1e-6;
      ctx.moveTo(T, py);
      ctx.lineTo(big ? 4 : T - 5, py);
      if (big) {
        ctx.save();
        ctx.translate(11, py - 2);
        ctx.rotate(-Math.PI / 2);
        ctx.fillText(label(y), 0, 0);
        ctx.restore();
      }
    }
    ctx.moveTo(0, T + 0.5);
    ctx.lineTo(vp.width, T + 0.5);
    ctx.moveTo(T + 0.5, 0);
    ctx.lineTo(T + 0.5, vp.height);
    ctx.stroke();
    ctx.restore();
  }

  /** A light grid on the level, spaced so lines stay at least ~28 px apart. */
  drawWorkPlane(ctx, vp) {
    const imp = this.app.doc.units.system === 'imperial';
    const steps = imp ? [152.4, 304.8, 609.6, 1524, 3048, 6096, 15240, 30480] : [100, 250, 500, 1000, 2500, 5000, 10000, 25000];
    const step = steps.find((s) => s * this.cam.zoom >= 28) ?? steps.at(-1);
    const a = this.screenToModel(0, vp.height);
    const b = this.screenToModel(vp.width, 0);
    ctx.save();
    ctx.strokeStyle = vp.theme.inkCss;
    ctx.lineWidth = 1;
    for (const major of [false, true]) {
      const s = major ? step * 5 : step;
      ctx.globalAlpha = major ? 0.14 : 0.06;
      ctx.beginPath();
      for (let x = Math.ceil(a[0] / s) * s; x <= b[0]; x += s) {
        const px = Math.round(this.modelToScreen([x, 0]).x) + 0.5;
        ctx.moveTo(px, 0);
        ctx.lineTo(px, vp.height);
      }
      for (let y = Math.ceil(a[1] / s) * s; y <= b[1]; y += s) {
        const py = Math.round(this.modelToScreen([0, y]).y) + 0.5;
        ctx.moveTo(0, py);
        ctx.lineTo(vp.width, py);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  // Coordinates -----------------------------------------------------------------------

  // The view may be turned (Archicad's Rotate Orientation): cam.rot, radians, turns the model on screen.
  screenToModel(x, y) {
    const { cx, cy, zoom, rot = 0 } = this.cam;
    const u = (x - this.vp.width / 2) / zoom;
    const v = -(y - this.vp.height / 2) / zoom;
    const c = Math.cos(rot);
    const s = Math.sin(rot);
    return [cx + c * u + s * v, cy - s * u + c * v];
  }

  modelToScreen(p) {
    const { cx, cy, zoom, rot = 0 } = this.cam;
    const dx = p[0] - cx;
    const dy = p[1] - cy;
    const c = Math.cos(rot);
    const s = Math.sin(rot);
    return { x: (c * dx - s * dy) * zoom + this.vp.width / 2, y: this.vp.height / 2 - (s * dx + c * dy) * zoom };
  }

  /** Turn the view so the direction `angle` (radians, in the model) reads horizontal; 0 resets. */
  setOrientation(rot) {
    this.cam = { ...this.cam, rot };
    this.userMoved = true;
    this.vp.requestRender();
  }

  mmPerPx() {
    return 1 / this.cam.zoom;
  }

  /** Until the user navigates, keep the view fitted when the canvas resizes. */
  resized() {
    if (!this.userMoved && this.cam) this.zoomExtents(false);
  }

  pan(dx, dy) {
    this.userMoved = true;
    const rot = this.cam.rot || 0;
    const u = dx / this.cam.zoom;
    const v = -dy / this.cam.zoom;
    this.cam.cx -= Math.cos(rot) * u + Math.sin(rot) * v;
    this.cam.cy -= -Math.sin(rot) * u + Math.cos(rot) * v;
    this.noteCamera();
  }

  zoomAt(x, y, f) {
    this.userMoved = true;
    const before = this.screenToModel(x, y);
    this.cam.zoom = Math.max(1e-5, Math.min(50, this.cam.zoom * f));
    const after = this.screenToModel(x, y);
    this.cam.cx += before[0] - after[0];
    this.cam.cy += before[1] - after[1];
    this.noteCamera();
  }

  zoomBy(f) {
    this.zoomAt(this.vp.width / 2, this.vp.height / 2, f);
    this.vp.requestRender();
  }

  extents(ids = null) {
    let b = null;
    for (const [id, bb] of this.bounds) {
      if (ids && !ids.has(id)) continue;
      const el = this.app.doc.get(id);
      // Markers far from the model would make the fit too loose.
      if (!ids && (el?.kind === 'elevation' || el?.kind === 'section')) continue;
      b = bboxUnion(b, bb);
    }
    return b;
  }

  zoomExtents(render = true, ids = null) {
    this.sync();
    const b = this.extents(ids) || { x0: -5000, y0: -5000, x1: 15000, y1: 12000 };
    this.zoomToBox(b, render);
  }

  zoomToBox(b, render = true) {
    const w = Math.max(1000, b.x1 - b.x0);
    const h = Math.max(1000, b.y1 - b.y0);
    const zoom = Math.min((this.vp.width * 0.86) / w, (this.vp.height * 0.86) / h);
    this.cam = { cx: (b.x0 + b.x1) / 2, cy: (b.y0 + b.y1) / 2, zoom: Math.max(1e-5, Math.min(50, zoom)), rot: this.cam?.rot || 0 };
    this.noteCamera(true);
    if (render) this.vp.requestRender();
  }

  // Picking ----------------------------------------------------------------------------

  /** Ids under a screen point, best first. */
  hitTest(x, y, tolPx = 6) {
    this.sync();
    const p = this.screenToModel(x, y);
    const tol = tolPx / this.cam.zoom;
    const cands = this.query({ x0: p[0] - tol, y0: p[1] - tol, x1: p[0] + tol, y1: p[1] + tol });
    const hits = [];
    for (const id of cands) {
      const it = this.layer.items.get(id);
      if (!it || !this.app.doc.has(id)) continue;
      if (this.app.flagsOf(id) & 4) continue;
      const g = it.g;
      let d = Infinity;
      for (const poly of g.picks) if (pointInPolygon(p, poly)) d = 0;
      if (d > 0) for (const l of g.lines) d = Math.min(d, distToSegment(p, l.a, l.b));
      if (d > tol) continue;
      hits.push({ id, d, rank: PICK_RANK[it.kind] ?? 3 });
    }
    hits.sort((a, b) => a.rank - b.rank || a.d - b.d);
    return hits.map((h) => h.id);
  }

  /** Window (inside) or crossing selection with a model-space box. */
  boxSelect(box, crossing) {
    this.sync();
    const out = [];
    for (const id of this.query(box)) {
      const it = this.layer.items.get(id);
      if (!it || !this.app.doc.has(id) || this.app.flagsOf(id) & 4) continue;
      const b = this.bounds.get(id);
      if (!b) continue;
      if (bboxContains(box, b)) {
        out.push(id);
        continue;
      }
      if (!crossing) continue;
      const g = it.g;
      let hit = g.lines.some((l) => segmentIntersectsBox(l.a, l.b, box));
      if (!hit) for (const poly of g.picks) if (pointInPolygon([box.x0, box.y0], poly) || poly.some((q) => q[0] >= box.x0 && q[0] <= box.x1 && q[1] >= box.y0 && q[1] <= box.y1)) hit = true;
      if (hit) out.push(id);
    }
    return out;
  }

  /** Snap features of elements near a model point. */
  snapFeaturesNear(p, r, exclude) {
    this.sync();
    const out = [];
    for (const id of this.query({ x0: p[0] - r, y0: p[1] - r, x1: p[0] + r, y1: p[1] + r })) {
      if (exclude?.has(id)) continue;
      const el = this.app.doc.get(id);
      if (!el) continue;
      let f = this.featureCache.get(id);
      if (!f) {
        f = snapFeatures(this.scene, el);
        this.featureCache.set(id, f);
      }
      out.push(f);
    }
    // Guide lines snap along them and where they cross each other and the drawing.
    const guides = this.app.guides?.get(this.viewId);
    if (guides?.length) {
      const lines = [];
      const points = [];
      for (const g of guides) {
        if (g.seg) {
          const id = `guide:${guides.indexOf(g)}`;
          lines.push({ a: g.seg[0], b: g.seg[1], id });
          points.push({ p: g.seg[0], kind: 'endpoint', id }, { p: g.seg[1], kind: 'endpoint', id }, { p: [(g.seg[0][0] + g.seg[1][0]) / 2, (g.seg[0][1] + g.seg[1][1]) / 2], kind: 'midpoint', id });
          continue;
        }
        const t = (p[0] - g.p[0]) * g.d[0] + (p[1] - g.p[1]) * g.d[1];
        const m = [g.p[0] + g.d[0] * t, g.p[1] + g.d[1] * t];
        if (Math.hypot(m[0] - p[0], m[1] - p[1]) > r) continue;
        const R = Math.max(r * 50, 100000);
        lines.push({ a: [m[0] - g.d[0] * R, m[1] - g.d[1] * R], b: [m[0] + g.d[0] * R, m[1] + g.d[1] * R], id: `guide:${guides.indexOf(g)}` });
      }
      if (lines.length) out.push({ points, lines });
    }
    // The reference's lines snap too, at their ends, middles and along them.
    if (this.traceLines?.length) {
      const points = [];
      const lines = [];
      for (const l of this.traceLines) {
        const lx0 = Math.min(l.a[0], l.b[0]) - r;
        const ly0 = Math.min(l.a[1], l.b[1]) - r;
        if (p[0] < lx0 || p[1] < ly0 || p[0] > Math.max(l.a[0], l.b[0]) + r || p[1] > Math.max(l.a[1], l.b[1]) + r) continue;
        points.push({ p: l.a, kind: 'endpoint', id: 'trace' }, { p: l.b, kind: 'endpoint', id: 'trace' }, { p: [(l.a[0] + l.b[0]) / 2, (l.a[1] + l.b[1]) / 2], kind: 'midpoint', id: 'trace' });
        lines.push({ a: l.a, b: l.b, id: 'trace' });
      }
      if (points.length) out.push({ points, lines });
    }
    return out;
  }
}
