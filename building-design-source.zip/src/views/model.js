/**
 * Model view controller for 3D views, elevations and sections. All of them
 * draw the shared 3D scene; elevations and sections use an orthographic
 * camera fixed to the view frame, clip to the view depth and draw their 2D
 * annotations (levels, grids, dimensions, text) on top.
 */
import { MODEL_KINDS } from '../core/scene.js';
import { PlanBuilder } from '../core/plan.js';
import { independentDrawing } from '../core/hiddenline.js';
import { analyticalColors, hexAlpha } from '../core/projectprefs.js';
import { horizontalPlane, planeFromSurface, isHorizontal, inputPoint } from '../core/editplane.js';
import { wallAxis, openingSize, verticalExtent } from '../core/model.js';
import { cloudPoints } from '../core/pointcloud.js';
import { viewCutPlanes } from '../core/cutplanes.js';
import { lookAt, perspective, ortho, multiply, invert, transformPoint } from '../render/math3d.js';
import { viewMatrix2D } from '../render/renderer2d.js';
import { viewFrame, viewClip, elevationAnnotations, sectionCuts } from '../core/elevation.js';
import { analyticalModel } from '../core/analytical.js';
import { pointInPolygon, distToSegment, bboxContains, bboxIntersects } from '../core/geom.js';
import { drawLayerTexts } from './overlay.js';
import { sunDirection } from '../core/sun.js';
import { lampSources, DAYLIGHT } from '../core/lamps.js';
import { hiddenInView } from '../core/plan.js';

const SECTION_BOX_PAD = 0;

export class ModelController {
  constructor(app, view) {
    this.app = app;
    this.viewId = view.id;
    this.kind = view.kind;
    this.graphical = true;
    this.is3D = view.kind === 'view3d';
    this.vp = app.viewport;
    this.orbit = this.is3D ? (dx, dy) => this.orbitBy(dx, dy) : null;
    this.annot = this.is3D ? null : this.vp.r2.layer();
    this.syncedKey = null;
    const saved = app.viewStates.get(view.id);
    if (this.is3D) this.cam = saved ? structuredClone(saved) : structuredClone(view.camera || { target: [0, 0, 0], dist: 30000, yaw: -0.8, pitch: 0.5, persp: true, fov: 45 });
    else this.cam = saved ? { ...saved } : null;
  }

  get view() {
    return this.app.doc.get(this.viewId);
  }

  activate() {
    this.app.syncModel();
    if (!this.is3D && !this.cam) this.zoomExtents(false);
    if (this.is3D && !this.app.viewStates.has(this.viewId) && !this.view.camera?.fitted) this.zoomExtents(false, true);
  }

  deactivate() {
    this.app.viewStates.set(this.viewId, this.is3D ? structuredClone(this.cam) : { ...this.cam });
  }

  dispose() {
    this.annot?.dispose();
  }

  // Cameras ------------------------------------------------------------------------------

  eye() {
    const { target, dist, yaw, pitch } = this.cam;
    return [target[0] + dist * Math.cos(pitch) * Math.cos(yaw), target[1] + dist * Math.cos(pitch) * Math.sin(yaw), target[2] + dist * Math.sin(pitch)];
  }

  basis() {
    const { yaw, pitch } = this.cam;
    const back = [Math.cos(pitch) * Math.cos(yaw), Math.cos(pitch) * Math.sin(yaw), Math.sin(pitch)];
    const right = [-Math.sin(yaw), Math.cos(yaw), 0];
    const up = [back[1] * right[2] - back[2] * right[1], back[2] * right[0] - back[0] * right[2], back[0] * right[1] - back[1] * right[0]];
    return { back, right, up };
  }

  /** World units per CSS pixel at the target depth. */
  worldPerPx() {
    if (!this.is3D) return 1 / this.cam.zoom;
    const fov = ((this.cam.fov || 45) * Math.PI) / 180;
    return (2 * this.cam.dist * Math.tan(fov / 2)) / this.vp.height;
  }

  mmPerPx() {
    return this.worldPerPx();
  }

  matrices() {
    const vp = this.vp;
    const aspect = vp.width / vp.height;
    if (this.is3D) {
      const eye = this.eye();
      const { target, dist } = this.cam;
      const up = Math.abs(Math.cos(this.cam.pitch)) < 1e-4 ? [Math.cos(this.cam.yaw + Math.PI), Math.sin(this.cam.yaw + Math.PI), 0] : [0, 0, 1];
      const view = lookAt(eye, target, up);
      const b = this.app.viewport.r3.bounds();
      const size = b ? Math.hypot(b.max[0] - b.min[0], b.max[1] - b.min[1], b.max[2] - b.min[2]) : 50000;
      const fov = ((this.cam.fov || 45) * Math.PI) / 180;
      let proj;
      if (this.cam.persp !== false && this.cam.twoPoint) {
        // Two-point perspective: look level so verticals stay vertical, and shift the lens to keep the target in view.
        const flat = [target[0], target[1], eye[2]];
        const hd = Math.hypot(target[0] - eye[0], target[1] - eye[1]) || 1;
        const shift = (target[2] - eye[2]) / hd / Math.tan(fov / 2);
        const p0 = perspective(fov, aspect, Math.max(dist * 0.005, 10), dist + size * 2 + 10000);
        const T = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, -shift, 0, 1];
        return { vp: multiply(multiply(T, p0), lookAt(eye, flat, [0, 0, 1])), eye };
      }
      if (this.cam.persp !== false) proj = perspective(fov, aspect, Math.max(dist * 0.005, 10), dist + size * 2 + 10000);
      else {
        const hh = dist * Math.tan(fov / 2);
        proj = ortho(-hh * aspect, hh * aspect, -hh, hh, -size * 4 - dist, dist + size * 4 + 10000);
      }
      return { vp: multiply(proj, view), eye };
    }
    const f = this.frame();
    const { cx, cy, zoom } = this.cam;
    const sx = (zoom * 2) / vp.width;
    const sy = (zoom * 2) / vp.height;
    const R = 1e6;
    const r = f.right;
    const L = f.look;
    const ro = r[0] * f.origin[0] + r[1] * f.origin[1];
    const lo = L[0] * f.origin[0] + L[1] * f.origin[1];
    const m = new Float64Array(16);
    m[0] = sx * r[0];
    m[4] = sx * r[1];
    m[12] = -sx * (ro + cx);
    m[9] = sy;
    m[13] = -sy * cy;
    m[2] = L[0] / R;
    m[6] = L[1] / R;
    m[14] = -lo / R;
    m[15] = 1;
    const eye = [f.origin[0] - L[0] * 1e5, f.origin[1] - L[1] * 1e5, cy];
    return { vp: m, eye };
  }

  frame() {
    return viewFrame(this.view);
  }

  // Rendering -------------------------------------------------------------------------------

  syncAnnotations() {
    if (this.is3D) return;
    const view = this.view;
    const trace = this.app.traces?.get(view.id);
    const siblings = view.interiorOf && trace?.on && trace.refId === 'siblings';
    const key = `${this.app.scene.version}|${view === this.syncedView}|${siblings ? 1 : 0}`;
    if (this.syncedKey === key && this.syncedView === view) return;
    const frame = this.frame();
    const range = this.modelRange(frame);
    const items = [...sectionCuts(this.app.doc, frame, (el) => this.app.scene.mesh(el), view.detail, view.structureDisplay || 'entire'), ...elevationAnnotations(this.app.doc, view, frame, range, this.app.scene.walls, (el) => this.app.scene.mesh(el))];
    if (siblings) items.push(...siblingDrawings(this.app, view));
    const keep = new Set();
    this.annBounds = new Map();
    for (const it of items) {
      keep.add(it.id);
      this.annot.set(it.id, this.app.scene.indexOf(it.id), it.kind, it.g);
      const b = it.g.bounds();
      if (b) this.annBounds.set(it.id, b);
    }
    this.annot.retain(keep);
    this.syncedKey = key;
    this.syncedView = view;
  }

  /** Model extents in view coordinates (u, z). */
  modelRange(frame) {
    const b = this.app.viewport.r3.bounds();
    if (!b) return { u0: -5000, u1: 5000, z0: 0, z1: 6000 };
    let u0 = Infinity;
    let u1 = -Infinity;
    for (const x of [b.min[0], b.max[0]])
      for (const y of [b.min[1], b.max[1]]) {
        const u = (x - frame.origin[0]) * frame.right[0] + (y - frame.origin[1]) * frame.right[1];
        u0 = Math.min(u0, u);
        u1 = Math.max(u1, u);
      }
    const lv = this.app.doc.levels();
    // Interior elevations keep to their room's height.
    if (frame.z0 != null) return { u0, u1, z0: frame.z0, z1: frame.z1 };
    const z0 = Math.min(b.min[2], lv[0]?.elevation ?? 0);
    const z1 = Math.max(b.max[2], lv.at(-1)?.elevation ?? 0);
    return { u0, u1, z0, z1 };
  }

  clipPlanes() {
    const view = this.view;
    if (this.is3D) {
      const sb = view.sectionBox;
      const cuts = viewCutPlanes(view);
      if (!sb) return cuts;
      const p = SECTION_BOX_PAD;
      return [
        ...cuts,
        [1, 0, 0, sb.max[0] + p],
        [-1, 0, 0, -sb.min[0] + p],
        [0, 1, 0, sb.max[1] + p],
        [0, -1, 0, -sb.min[1] + p],
        [0, 0, 1, sb.max[2] + p],
        [0, 0, -1, -sb.min[2] + p],
      ];
    }
    return viewClip(this.frame());
  }

  render(vp) {
    this.app.syncModel();
    const view = this.view;
    if (!view) return;
    if (!this.cam) this.zoomExtents(false);
    const m = this.matrices();
    this.lastMatrices = m;
    const cam = { vp: m.vp, eye: m.eye, width: vp.canvas.width, height: vp.canvas.height, dpr: vp.dpr };
    const style = view.style || (this.is3D ? 'shaded' : 'hidden');
    let light = [0.35, -0.45, 0.82];
    if (this.is3D) {
      // Light from over the viewer's left shoulder.
      const { back, right, up } = this.basis();
      light = norm3([back[0] * 0.6 - right[0] * 0.45 + up[0] * 0.65, back[1] * 0.6 - right[1] * 0.45 + up[1] * 0.65, back[2] * 0.6 - right[2] * 0.45 + up[2] * 0.65 + 0.3]);
    } else {
      const f = this.frame();
      light = norm3([-f.look[0] * 0.7 - f.right[0] * 0.3, -f.look[1] * 0.7 - f.right[1] * 0.3, 0.55]);
    }
    // Shadows: light comes from the sun of the project's location, date and time.
    let sun = null;
    if (view.shadows) {
      // A view may stand at another date and time (a sun study's frames).
      const project = this.app.doc.get('project');
      sun = sunDirection(view.sunAt ? { ...project, sun: { ...(project?.sun || {}), ...view.sunAt } } : project).dir;
      if (sun[2] > 0.01) light = sun;
    }
    // Lamps light the view when it asks for them (Render, or the view's Lamp Light setting).
    let lamps = null;
    let daylight = 1;
    if (this.is3D && view.lampLight && style !== 'wireframe' && style !== 'hidden') {
      const scene = this.app.scene;
      const doc = this.app.doc;
      lamps = lampSources(doc, (el) => scene.mesh(el)?.bounds, { eye: m.eye, hidden: (el) => hiddenInView(doc, view, el) }).map((l) => ({ ...l, color: l.color.map((c) => c * (view.lampDimmer ?? 1)), elem: l.noGlow ? -1 : scene.indexOf(l.id) }));
      daylight = DAYLIGHT.find((d) => d.value === view.daylight)?.amount ?? 1;
    }
    vp.r3.draw(cam, vp.theme, { style, clip: this.clipPlanes(), light, sun, lamps, daylight, fill: +view.interiorFill || 0, edges: view.renderEdges === true ? true : undefined, edgeWidth: this.app.settings.thinLines ? 1 : 1.15 });
    if (!this.is3D) {
      this.syncAnnotations();
      const { cx, cy, zoom } = this.cam;
      const scale = +view.scale || 100;
      vp.r2.draw(this.annot, { matrix: viewMatrix2D(cx, cy, zoom, vp.width, vp.height, this.annot.origin), width: vp.canvas.width, height: vp.canvas.height, dpr: vp.dpr }, vp.theme, { dashScale: scale, spacing: scale * 1.6, thin: this.app.settings.thinLines, pen: view.penSet });
    }
    this.updateCube();
  }

  /** A member's section as a rectangle across it, at its middle. */
  drawMemberSection(ctx, m, am, P, ok) {
    const sec = (Array.isArray(am.sections) ? am.sections.find((s) => s.name === m.section) : am.sections?.get?.(m.section)) || null;
    if (!sec?.params?.length) return;
    const [h, w = h] = sec.params;
    const c = [(m.a[0] + m.b[0]) / 2, (m.a[1] + m.b[1]) / 2, (m.a[2] + m.b[2]) / 2];
    const d = [m.b[0] - m.a[0], m.b[1] - m.a[1], m.b[2] - m.a[2]];
    const L = Math.hypot(...d) || 1;
    const u = d.map((v) => v / L);
    const ref = Math.abs(u[2]) > 0.9 ? [1, 0, 0] : [0, 0, 1];
    const cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
    const n1 = cr(u, ref);
    const l1 = Math.hypot(...n1) || 1;
    const x = n1.map((v) => v / l1);
    const y = cr(u, x);
    const pts = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([i, j]) => P([0, 1, 2].map((k) => c[k] + (x[k] * i * w) / 2 + (y[k] * j * h) / 2)));
    if (!pts.every(ok)) return;
    ctx.save();
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
    ctx.closePath();
    ctx.stroke();
    ctx.restore();
  }

  drawOverlay(ctx, vp) {
    if (!this.is3D) {
      drawLayerTexts(ctx, this.annot, (p) => this.modelToScreen(p), this.cam.zoom, vp.theme, (id) => this.app.flagsOf(id));
      return;
    }
    if (this.view?.analytical) this.drawAnalytical(ctx, vp);
    if (this.app.settings.editPlaneDisplay) this.drawEditPlane(ctx, vp);
    if (this.app.settings.openingBodies || this.app.settings.openingPlanes) this.drawOpeningBodies(ctx);
    if (this.app.settings.trimmingBodies) this.drawTrimmingBodies(ctx);
    if (this.app.settings.hiddenMorphGeometry) this.drawMorphTriangles(ctx);
    if (this.app.doc.count('pointCloud')) this.drawPointClouds(ctx, vp);
    // Render Safe Frame: the part of the view the render's proportions keep, the rest dimmed.
    const sf = this.app.settings.renderSafeFrame;
    if (sf) {
      const [rw, rh] = String(sf).split('x').map(Number);
      if (rw > 0 && rh > 0) {
        const k = Math.min(vp.width / rw, vp.height / rh);
        const fw = rw * k;
        const fh = rh * k;
        const x0 = (vp.width - fw) / 2;
        const y0 = (vp.height - fh) / 2;
        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
        ctx.fillRect(0, 0, vp.width, y0);
        ctx.fillRect(0, y0 + fh, vp.width, vp.height - y0 - fh);
        ctx.fillRect(0, y0, x0, fh);
        ctx.fillRect(x0 + fw, y0, vp.width - x0 - fw, fh);
        ctx.strokeStyle = '#ffffff';
        ctx.setLineDash([6, 4]);
        ctx.strokeRect(x0 + 0.5, y0 + 0.5, fw - 1, fh - 1);
        ctx.restore();
      }
    }
    const sb = this.view?.sectionBox;
    if (!sb) return;
    // Outline of the section box.
    const P = (i) => this.project3([i & 1 ? sb.max[0] : sb.min[0], i & 2 ? sb.max[1] : sb.min[1], i & 4 ? sb.max[2] : sb.min[2]]);
    const pts = [0, 1, 2, 3, 4, 5, 6, 7].map(P);
    if (pts.some((p) => p.z < -1 || p.z > 1)) return;
    ctx.save();
    ctx.strokeStyle = vp.theme.selCss;
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    for (const [a, b] of [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]]) {
      ctx.moveTo(pts[a].x, pts[a].y);
      ctx.lineTo(pts[b].x, pts[b].y);
    }
    ctx.stroke();
    ctx.restore();
  }

  /** Point clouds: each point as a dot of its colour (thinned to about 120 000 dots a frame). */
  drawPointClouds(ctx) {
    const clouds = this.app.doc.all('pointCloud').filter((el) => !(this.app.flagsOf(el.id, this.view) & 4));
    const total = clouds.reduce((s, el) => s + (el.count || 0), 0);
    const step = Math.max(1, Math.ceil(total / 120000));
    const m = (this.lastMatrices || this.matrices()).vp;
    const W = this.vp.width;
    const H = this.vp.height;
    const img = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
    const k = ctx.canvas.width / W;
    const data = img.data;
    const cw = ctx.canvas.width;
    for (const el of clouds) {
      const { xyz, rgb } = cloudPoints(el);
      const a = el.at || [0, 0, 0];
      for (let i = 0; i < xyz.length; i += 3 * step) {
        const x = xyz[i] + a[0];
        const y = xyz[i + 1] + a[1];
        const z = xyz[i + 2] + a[2];
        const w = m[3] * x + m[7] * y + m[11] * z + m[15];
        if (w <= 0) continue;
        const nx = (m[0] * x + m[4] * y + m[8] * z + m[12]) / w;
        const ny = (m[1] * x + m[5] * y + m[9] * z + m[13]) / w;
        if (nx < -1 || nx > 1 || ny < -1 || ny > 1) continue;
        const px = Math.floor((nx * 0.5 + 0.5) * W * k);
        const py = Math.floor((1 - (ny * 0.5 + 0.5)) * H * k);
        for (let dy = 0; dy < 2; dy++)
          for (let dx = 0; dx < 2; dx++) {
            const o = ((py + dy) * cw + px + dx) * 4;
            if (o < 0 || o >= data.length) continue;
            data[o] = rgb[i];
            data[o + 1] = rgb[i + 1];
            data[o + 2] = rgb[i + 2];
            data[o + 3] = 255;
          }
      }
    }
    ctx.putImageData(img, 0, 0);
  }

  /**
   * Opening Cutting Bodies and Opening Reference Planes: the box each door, window and opening cuts out of its
   * wall, and the face it is placed on.
   */
  drawOpeningBodies(ctx) {
    const doc = this.app.doc;
    const st = this.app.settings;
    ctx.save();
    ctx.lineWidth = 1.2;
    const seg = (a, b) => {
      const p = this.project3(a);
      const q = this.project3(b);
      if (p.z < -1 || p.z > 1 || q.z < -1 || q.z > 1) return;
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(q.x, q.y);
    };
    for (const k of ['door', 'window', 'opening']) {
      for (const el of doc.all(k)) {
        const w = doc.get(el.hostId);
        if (!w || w.kind !== 'wall' || w.arc || this.app.flagsOf(el.id, this.view) & 4) continue;
        const ax = wallAxis(doc, w);
        const { width, height, sill } = openingSize(doc, el);
        const { base } = verticalExtent(doc, w);
        const c = [ax.a[0] + ax.dir[0] * el.t, ax.a[1] + ax.dir[1] * el.t];
        const z0 = base + (k === 'door' ? 0 : sill);
        const z1 = z0 + height;
        const P = (u, v, z) => [c[0] + ax.dir[0] * u + ax.n[0] * v, c[1] + ax.dir[1] * u + ax.n[1] * v, z];
        const hw = width / 2;
        const ht = ax.half;
        if (st.openingBodies) {
          ctx.strokeStyle = 'rgba(214, 58, 58, 0.85)';
          ctx.beginPath();
          for (const v of [-ht, ht]) for (const [a, b] of [[[-hw, z0], [hw, z0]], [[hw, z0], [hw, z1]], [[hw, z1], [-hw, z1]], [[-hw, z1], [-hw, z0]]]) seg(P(a[0], v, a[1]), P(b[0], v, b[1]));
          for (const u of [-hw, hw]) for (const z of [z0, z1]) seg(P(u, -ht, z), P(u, ht, z));
          ctx.stroke();
        }
        if (st.openingPlanes) {
          // The face the opening sits on: the exterior unless flipped.
          const side = (w.flipped ? -1 : 1) * (el.flipFacing ? -1 : 1) * ht;
          ctx.strokeStyle = 'rgba(31, 111, 255, 0.9)';
          ctx.setLineDash([5, 3]);
          ctx.beginPath();
          const m = 120;
          for (const [a, b] of [[[-hw - m, z0 - m], [hw + m, z0 - m]], [[hw + m, z0 - m], [hw + m, z1 + m]], [[hw + m, z1 + m], [-hw - m, z1 + m]], [[-hw - m, z1 + m], [-hw - m, z0 - m]]]) seg(P(a[0], side, a[1]), P(b[0], side, b[1]));
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }
    }
    ctx.restore();
  }

  /** Hidden Morph Geometry: every edge of the morphs' faces, the ones merged by smoothing too, faint. */
  drawMorphTriangles(ctx) {
    const doc = this.app.doc;
    ctx.save();
    ctx.strokeStyle = 'rgba(90, 90, 110, 0.45)';
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    for (const el of doc.all('morph')) {
      if (this.app.flagsOf(el.id, this.view) & 4) continue;
      const P = this.app.scene.mesh(el)?.pos;
      if (!P || P.length > 9 * 40000) continue;
      for (let i = 0; i < P.length; i += 9) {
        const q = [0, 3, 6].map((k) => this.project3([P[i + k], P[i + k + 1], P[i + k + 2]]));
        if (q.some((x) => x.z < -1 || x.z > 1)) continue;
        ctx.moveTo(q[0].x, q[0].y);
        ctx.lineTo(q[1].x, q[1].y);
        ctx.lineTo(q[2].x, q[2].y);
        ctx.lineTo(q[0].x, q[0].y);
      }
    }
    ctx.stroke();
    ctx.restore();
  }

  /** Trimming Bodies: the elements used as operators of solid element operations, as wireframes. */
  drawTrimmingBodies(ctx) {
    const doc = this.app.doc;
    const ops = new Set();
    for (const el of doc.items.values()) for (const o of el.seo || []) ops.add(o.id);
    ctx.save();
    ctx.strokeStyle = 'rgba(230, 140, 20, 0.95)';
    ctx.setLineDash([4, 3]);
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    for (const id of ops) {
      const el = doc.get(id);
      const E = el && this.app.scene.mesh(el)?.edges;
      if (!E) continue;
      for (let i = 0; i < E.length; i += 6) {
        const p = this.project3([E[i], E[i + 1], E[i + 2]]);
        const q = this.project3([E[i + 3], E[i + 4], E[i + 5]]);
        if (p.z < -1 || p.z > 1 || q.z < -1 || q.z > 1) continue;
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(q.x, q.y);
      }
    }
    ctx.stroke();
    ctx.restore();
  }

  /** Editing Plane Display: a grid on the editing plane around the camera's target. */
  drawEditPlane(ctx, vp) {
    const z = this.planeZ();
    const c = this.cam.target;
    const step = this.cam.dist > 40000 ? 5000 : 1000;
    const n = 12;
    const x0 = Math.round(c[0] / step) * step - n * step;
    const y0 = Math.round(c[1] / step) * step - n * step;
    ctx.save();
    ctx.strokeStyle = vp.theme.selCss || '#1f6fff';
    ctx.globalAlpha = 0.35;
    ctx.lineWidth = 1;
    const line = (a, b) => {
      const p = this.project3(a);
      const q = this.project3(b);
      if (p.z < -1 || p.z > 1 || q.z < -1 || q.z > 1) return;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(q.x, q.y);
      ctx.stroke();
    };
    if (this.editPlane?.o) {
      // A picked plane: a grid on it around its origin, along its own axes (one level in the plane, one up it).
      const { o, n: nr } = this.editPlane;
      let u = [-nr[1], nr[0], 0];
      const lu = Math.hypot(u[0], u[1]);
      u = lu > 1e-9 ? [u[0] / lu, u[1] / lu, 0] : [1, 0, 0];
      const v = [nr[1] * u[2] - nr[2] * u[1], nr[2] * u[0] - nr[0] * u[2], nr[0] * u[1] - nr[1] * u[0]];
      const P = (a, b) => [o[0] + u[0] * a + v[0] * b, o[1] + u[1] * a + v[1] * b, o[2] + u[2] * a + v[2] * b];
      const m = n * step;
      for (let i = -n; i <= n; i++) {
        line(P(i * step, -m), P(i * step, m));
        line(P(-m, i * step), P(m, i * step));
      }
      ctx.restore();
      return;
    }
    for (let i = 0; i <= 2 * n; i++) {
      line([x0 + i * step, y0, z], [x0 + i * step, y0 + 2 * n * step, z]);
      line([x0, y0 + i * step, z], [x0 + 2 * n * step, y0 + i * step, z]);
    }
    ctx.restore();
  }

  /**
   * The structural analytical model over the 3D view (Archicad's Structural
   * Analytical Model display): surfaces shaded on their mid-planes, members
   * on their axes, nodes, and supports as triangles.
   */
  drawAnalytical(ctx, vp) {
    const key = this.app.scene.version;
    if (this.analyticalKey !== key) {
      this.analyticalKey = key;
      this.analyticalModel = analyticalModel(this.app.doc);
    }
    const am = this.analyticalModel;
    const P = (p) => this.project3(p);
    const ok = (q) => q.z > -1 && q.z < 1;
    const nodeAt = new Map(am.nodes.map((n) => [n.name, n.p]));
    // Display options (Archicad's Structural Analytical Model view options).
    const opt = { physical: true, members2d: true, symbols: false, axes: false, ...(this.app.settings.analyticalDisplay || {}) };
    ctx.save();
    // Transparent Physical Model: a veil over the shaded model so the analytical one reads on top.
    if (opt.physical) {
      ctx.save();
      ctx.globalAlpha = 0.55;
      ctx.fillStyle = vp.theme.bgCss || '#ffffff';
      ctx.fillRect(0, 0, vp.width, vp.height);
      ctx.restore();
    }
    const fillA = opt.members2d ? 0.18 : 0.7;
    const colors = analyticalColors(this.app.doc.get('project'));
    for (const s of am.surfaces) {
      const pts = s.corners.map(P);
      if (!pts.every(ok)) continue;
      ctx.beginPath();
      pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
      ctx.closePath();
      ctx.fillStyle = hexAlpha(s.type === 'Wall' ? colors.wall : colors.slab, fillA);
      ctx.fill();
      ctx.strokeStyle = hexAlpha(s.type === 'Wall' ? colors.wall : colors.slab, 0.9);
      ctx.lineWidth = 1.2;
      ctx.stroke();
    }
    ctx.lineWidth = +colors.width || 2.5;
    for (const m of am.members) {
      const a = P(m.a);
      const b = P(m.b);
      if (!ok(a) || !ok(b)) continue;
      ctx.strokeStyle = m.type === 'Column' ? colors.column : colors.beam;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
      // Profiles of Load-Bearing Cores: the section of the member, drawn at its middle.
      if (opt.profiles) this.drawMemberSection(ctx, m, am, P, ok);
      // Hinged ends: a ring a little way along the member.
      if (m.release && opt.releases !== false) {
        const ring = (p, q) => {
          const t = Math.min(12, Math.hypot(q.x - p.x, q.y - p.y) / 3) / (Math.hypot(q.x - p.x, q.y - p.y) || 1);
          ctx.save();
          ctx.lineWidth = 1.5;
          ctx.fillStyle = vp.theme.bgCss || '#fff';
          ctx.beginPath();
          ctx.arc(p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, 4, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
          ctx.restore();
        };
        if (m.release === 'begin' || m.release === 'both') ring(a, b);
        if (m.release === 'end' || m.release === 'both') ring(b, a);
      }
    }
    ctx.fillStyle = vp.theme.inkCss || '#222';
    for (const n of opt.nodes === false ? [] : am.nodes) {
      const q = P(n.p);
      if (!ok(q)) continue;
      ctx.beginPath();
      ctx.arc(q.x, q.y, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }
    // Rigid links: dashed, magenta.
    ctx.save();
    ctx.setLineDash([6, 4]);
    ctx.strokeStyle = '#be28a0';
    ctx.lineWidth = 2;
    for (const l of am.links || []) {
      const a = nodeAt.get(l.nodes[0]);
      const b = nodeAt.get(l.nodes[1]);
      const qa = a && P(a);
      const qb = b && P(b);
      if (!qa || !qb || !ok(qa) || !ok(qb)) continue;
      ctx.beginPath();
      ctx.moveTo(qa.x, qa.y);
      ctx.lineTo(qb.x, qb.y);
      ctx.stroke();
    }
    ctx.restore();
    // Local axes of members (x red along, y green, z blue) and their section names.
    if (opt.axes) {
      const L = 600;
      ctx.save();
      ctx.lineWidth = 1.5;
      ctx.font = '11px system-ui, sans-serif';
      for (const m of am.members) {
        const mid = [(m.a[0] + m.b[0]) / 2, (m.a[1] + m.b[1]) / 2, (m.a[2] + m.b[2]) / 2];
        const len = m.length || 1;
        const x = [(m.b[0] - m.a[0]) / len, (m.b[1] - m.a[1]) / len, (m.b[2] - m.a[2]) / len];
        const y = m.y || [0, 1, 0];
        const z = [x[1] * y[2] - x[2] * y[1], x[2] * y[0] - x[0] * y[2], x[0] * y[1] - x[1] * y[0]];
        const o = P(mid);
        if (!ok(o)) continue;
        for (const [v, c] of [[x, '#d63a3a'], [y, '#2f9e44'], [z, '#2f6fd6']]) {
          const q = P([mid[0] + v[0] * L, mid[1] + v[1] * L, mid[2] + v[2] * L]);
          if (!ok(q)) continue;
          ctx.strokeStyle = c;
          ctx.beginPath();
          ctx.moveTo(o.x, o.y);
          ctx.lineTo(q.x, q.y);
          ctx.stroke();
        }
        ctx.fillStyle = vp.theme.inkCss || '#222';
        if (m.section) ctx.fillText(`${m.name} ${m.section}`, o.x + 6, o.y - 6);
      }
      ctx.restore();
    }
    ctx.globalAlpha = opt.symbols ? 0.35 : 1;
    ctx.fillStyle = '#7b3fc4';
    for (const s of am.supports) {
      const p = nodeAt.get(s.node);
      const q = p && P(p);
      if (!q || !ok(q)) continue;
      ctx.beginPath();
      ctx.moveTo(q.x, q.y);
      ctx.lineTo(q.x - 7, q.y + 11);
      ctx.lineTo(q.x + 7, q.y + 11);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }

  // Coordinates ----------------------------------------------------------------------------

  /** Elevations: view coordinates (u, z). 3D: null. */
  // Editing plane (Archicad's): the horizontal plane 3D input lands on, at the active story unless picked.
  planeZ() {
    if (this.editPlane?.o) return this.editPlane.o[2];
    if (Number.isFinite(this.editPlane?.z)) return this.editPlane.z;
    const lv = this.app.doc.get(this.app.activeLevelId());
    return lv?.elevation ?? 0;
  }

  setPlane(z) {
    const cur = this.planeZ();
    if (Math.abs(cur - z) > 0.5 || this.editPlane?.o) this.planeHistory = [...(this.planeHistory || []), cur].slice(-20);
    this.editPlane = { z };
    this.app.requestRender();
  }

  /** The editing plane as { o, n }: horizontal at planeZ unless one was picked from a surface (core/editplane.js). */
  plane() {
    return this.editPlane?.o ? this.editPlane : horizontalPlane(this.planeZ());
  }

  /** Put the editing plane on a surface (tilted or vertical planes too). */
  setSurfacePlane(hit) {
    const pl = planeFromSurface(hit);
    if (!pl) return;
    this.planeHistory = [...(this.planeHistory || []), this.planeZ()].slice(-20);
    this.editPlane = isHorizontal(pl) ? { z: Math.round(pl.o[2]) } : pl;
    this.app.requestRender();
  }

  /** The points clicked so far in the running 3D input (reset when a tool starts or adds its element). */
  inputSoFar() {
    const key = `${this.app.tool?.constructor?.name}|${this.app.scene?.version}`;
    if (this.inputKey !== key) (this.inputKey = key), (this.inputPoints = []);
    return this.inputPoints;
  }

  /** Called after a click in 3D: the last input point becomes the projections' anchor. */
  noteInput() {
    if (!this.is3D || !this.lastInput3) return;
    const pts = this.inputSoFar();
    pts.push(this.lastInput3.slice());
    // The click may add an element (scene version moves): keep the point for the hook that sets its height.
    this.placedAt = this.lastInput3.slice();
  }

  /** The model surface under a screen point: { p, n, id } (nearest triangle of the picked element), or null. */
  raycast(x, y) {
    const id = this.pickId(x, y);
    const el = id && this.app.doc.get(id);
    const mesh = el && this.app.scene.mesh(el);
    if (!mesh?.pos) return null;
    const { o, d } = this.ray(x, y);
    const P = mesh.pos;
    let best = null;
    for (let i = 0; i < P.length; i += 9) {
      const e1 = [P[i + 3] - P[i], P[i + 4] - P[i + 1], P[i + 5] - P[i + 2]];
      const e2 = [P[i + 6] - P[i], P[i + 7] - P[i + 1], P[i + 8] - P[i + 2]];
      const h = [d[1] * e2[2] - d[2] * e2[1], d[2] * e2[0] - d[0] * e2[2], d[0] * e2[1] - d[1] * e2[0]];
      const a = e1[0] * h[0] + e1[1] * h[1] + e1[2] * h[2];
      if (Math.abs(a) < 1e-9) continue;
      const f = 1 / a;
      const sv = [o[0] - P[i], o[1] - P[i + 1], o[2] - P[i + 2]];
      const u = f * (sv[0] * h[0] + sv[1] * h[1] + sv[2] * h[2]);
      if (u < -1e-6 || u > 1 + 1e-6) continue;
      const q = [sv[1] * e1[2] - sv[2] * e1[1], sv[2] * e1[0] - sv[0] * e1[2], sv[0] * e1[1] - sv[1] * e1[0]];
      const v = f * (d[0] * q[0] + d[1] * q[1] + d[2] * q[2]);
      if (v < -1e-6 || u + v > 1 + 1e-6) continue;
      const t = f * (e2[0] * q[0] + e2[1] * q[1] + e2[2] * q[2]);
      if (t <= 0 || (best && t >= best.t)) continue;
      let n = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
      const l = Math.hypot(n[0], n[1], n[2]) || 1;
      n = n.map((c) => c / l);
      // Face the viewer.
      if (n[0] * d[0] + n[1] * d[1] + n[2] * d[2] > 0) n = n.map((c) => -c);
      best = { t, n };
    }
    if (!best) return null;
    return { p: [o[0] + d[0] * best.t, o[1] + d[1] * best.t, o[2] + d[2] * best.t], n: best.n, id };
  }

  /** The textured surface under a screen point: { p, uv (as drawn), id }, or null (the triangles that show pictures). */
  raycastTexture(x, y) {
    const id = this.pickId(x, y);
    const el = id && this.app.doc.get(id);
    const mesh = el && this.app.scene.mesh(el);
    if (!mesh?.tex?.length) return null;
    const { o, d } = this.ray(x, y);
    let best = null;
    for (const g of mesh.tex) {
      const P = g.pos;
      for (let i = 0, k = 0; i < P.length; i += 9, k += 6) {
        const e1 = [P[i + 3] - P[i], P[i + 4] - P[i + 1], P[i + 5] - P[i + 2]];
        const e2 = [P[i + 6] - P[i], P[i + 7] - P[i + 1], P[i + 8] - P[i + 2]];
        const h = [d[1] * e2[2] - d[2] * e2[1], d[2] * e2[0] - d[0] * e2[2], d[0] * e2[1] - d[1] * e2[0]];
        const a = e1[0] * h[0] + e1[1] * h[1] + e1[2] * h[2];
        if (Math.abs(a) < 1e-9) continue;
        const f = 1 / a;
        const sv = [o[0] - P[i], o[1] - P[i + 1], o[2] - P[i + 2]];
        const u = f * (sv[0] * h[0] + sv[1] * h[1] + sv[2] * h[2]);
        if (u < -1e-6 || u > 1 + 1e-6) continue;
        const q = [sv[1] * e1[2] - sv[2] * e1[1], sv[2] * e1[0] - sv[0] * e1[2], sv[0] * e1[1] - sv[1] * e1[0]];
        const v = f * (d[0] * q[0] + d[1] * q[1] + d[2] * q[2]);
        if (v < -1e-6 || u + v > 1 + 1e-6) continue;
        const t = f * (e2[0] * q[0] + e2[1] * q[1] + e2[2] * q[2]);
        if (t <= 0 || (best && t >= best.t)) continue;
        const U = g.uv;
        const w = 1 - u - v;
        best = { t, uv: [w * U[k] + u * U[k + 2] + v * U[k + 4], w * U[k + 1] + u * U[k + 3] + v * U[k + 5]] };
      }
    }
    if (!best) return null;
    return { p: [o[0] + d[0] * best.t, o[1] + d[1] * best.t, o[2] + d[2] * best.t], uv: best.uv, id };
  }

  screenToModel(x, y) {
    if (this.is3D) {
      // Surface Snap: the point on the model under the cursor; else where the ray meets the editing plane.
      const set = this.app.settings;
      const pts = this.inputSoFar();
      const anchor = pts.at(-1) || null;
      const mode = anchor ? set.inputProjection || 'free' : 'free';
      const hit = (set.surfaceSnap && mode === 'free') || set.alignToSurface ? this.raycast(x, y) : null;
      if (hit && set.surfaceSnap && mode === 'free') {
        this.lastInput3 = hit.p.slice();
        return [hit.p[0], hit.p[1]];
      }
      // Align to Surface: the editing plane follows the surface under the cursor.
      const plane = (hit && planeFromSurface(hit)) || this.plane();
      const { o, d } = this.ray(x, y);
      const p = inputPoint(o, d, plane, { mode, anchor, points: pts, view: d });
      if (!p) return null;
      this.lastInput3 = p;
      return [p[0], p[1]];
    }
    const { cx, cy, zoom } = this.cam;
    return [cx + (x - this.vp.width / 2) / zoom, cy - (y - this.vp.height / 2) / zoom];
  }

  modelToScreen(p) {
    if (this.is3D) return this.project3(p.length >= 3 ? p : [p[0], p[1], this.planeZ()]);
    const { cx, cy, zoom } = this.cam;
    return { x: (p[0] - cx) * zoom + this.vp.width / 2, y: this.vp.height / 2 - (p[1] - cy) * zoom };
  }

  /** World point to screen (CSS px). */
  project3(p) {
    const m = this.lastMatrices || this.matrices();
    const c = transformPoint(m.vp, [p[0], p[1], p[2] ?? 0]);
    return { x: (c[0] * 0.5 + 0.5) * this.vp.width, y: (1 - (c[1] * 0.5 + 0.5)) * this.vp.height, z: c[2] };
  }

  /** Ray through a screen point: { o, d } in world space. */
  ray(x, y) {
    const m = this.lastMatrices || this.matrices();
    const inv = invert(m.vp);
    const nx = (x / this.vp.width) * 2 - 1;
    const ny = 1 - (y / this.vp.height) * 2;
    const a = transformPoint(inv, [nx, ny, -1]);
    const b = transformPoint(inv, [nx, ny, 1]);
    const d = norm3([b[0] - a[0], b[1] - a[1], b[2] - a[2]]);
    return { o: a, d };
  }

  // Navigation -------------------------------------------------------------------------------

  resized() {
    // A view stood at a chosen point (Camera view) stays there when the window changes size.
    if (!this.userMoved && this.cam && !this.view.camera?.fitted) this.zoomExtents(false, true);
  }

  pan(dx, dy) {
    this.userMoved = true;
    if (!this.is3D) {
      this.cam.cx -= dx / this.cam.zoom;
      this.cam.cy += dy / this.cam.zoom;
      return;
    }
    const w = this.worldPerPx();
    const { right, up } = this.basis();
    const t = this.cam.target;
    this.cam.target = [t[0] - right[0] * dx * w + up[0] * dy * w, t[1] - right[1] * dx * w + up[1] * dy * w, t[2] - right[2] * dx * w + up[2] * dy * w];
  }

  zoomAt(x, y, f) {
    this.userMoved = true;
    if (!this.is3D) {
      const { cx, cy, zoom } = this.cam;
      const before = [cx + (x - this.vp.width / 2) / zoom, cy - (y - this.vp.height / 2) / zoom];
      this.cam.zoom = Math.max(1e-5, Math.min(50, zoom * f));
      const z = this.cam.zoom;
      const after = [this.cam.cx + (x - this.vp.width / 2) / z, this.cam.cy - (y - this.vp.height / 2) / z];
      this.cam.cx += before[0] - after[0];
      this.cam.cy += before[1] - after[1];
      return;
    }
    const w = this.worldPerPx();
    const { right, up } = this.basis();
    const t = this.cam.target;
    const ox = (x - this.vp.width / 2) * w;
    const oy = -(y - this.vp.height / 2) * w;
    const P = [t[0] + right[0] * ox + up[0] * oy, t[1] + right[1] * ox + up[1] * oy, t[2] + right[2] * ox + up[2] * oy];
    const k = 1 / f;
    this.cam.target = [P[0] + (t[0] - P[0]) * k, P[1] + (t[1] - P[1]) * k, P[2] + (t[2] - P[2]) * k];
    this.cam.dist = Math.max(200, Math.min(5e6, this.cam.dist * k));
  }

  zoomBy(f) {
    this.zoomAt(this.vp.width / 2, this.vp.height / 2, f);
    this.vp.requestRender();
  }

  beginNavigate(x, y, orbit) {
    if (!orbit || !this.is3D) return;
    // Orbit around the selection, else around what is under the cursor, else the target.
    let pivot = null;
    const sel = this.app.selection;
    // Lock Target Point: the view always turns about its target.
    if (this.app.settings.lockTarget) {
      this.pivot = this.cam?.target ? [...this.cam.target] : null;
      return;
    }
    if (sel.size) {
      const b = this.vp.r3.bounds(sel);
      if (b) pivot = [(b.min[0] + b.max[0]) / 2, (b.min[1] + b.max[1]) / 2, (b.min[2] + b.max[2]) / 2];
    }
    if (!pivot) {
      const id = this.pickId(x, y);
      if (id) {
        const b = this.vp.r3.bounds(new Set([id]));
        if (b) pivot = [(b.min[0] + b.max[0]) / 2, (b.min[1] + b.max[1]) / 2, (b.min[2] + b.max[2]) / 2];
      }
    }
    this.pivot = pivot;
  }

  endNavigate() {
    this.pivot = null;
  }

  orbitBy(dx, dy) {
    this.userMoved = true;
    const dYaw = -dx * 0.0085;
    let dPitch = dy * 0.0085;
    const p0 = this.cam.pitch;
    const p1 = Math.max(-1.5607, Math.min(1.5607, p0 + dPitch));
    dPitch = p1 - p0;
    // Camera mode, Turn and Walk: the camera turns on the spot (the eye stays, the target moves).
    const mode = this.app.settings.navMode;
    if (mode === 'camera' || mode === 'turn' || mode === 'walk') {
      const eye = this.eye();
      this.cam.yaw -= dYaw;
      this.cam.pitch = Math.max(-1.5607, Math.min(1.5607, this.cam.pitch - dPitch));
      const { back } = this.basis();
      this.cam.target = [eye[0] - back[0] * this.cam.dist, eye[1] - back[1] * this.cam.dist, eye[2] - back[2] * this.cam.dist];
      return;
    }
    const pivot = this.pivot;
    if (!pivot) {
      this.cam.yaw += dYaw;
      this.cam.pitch = p1;
      return;
    }
    // Rotate the eye and target about the pivot.
    const eye = this.eye();
    const rotZ = (p, a) => {
      const c = Math.cos(a);
      const s = Math.sin(a);
      const x = p[0] - pivot[0];
      const y = p[1] - pivot[1];
      return [pivot[0] + x * c - y * s, pivot[1] + x * s + y * c, p[2]];
    };
    let e = rotZ(eye, dYaw);
    let t = rotZ(this.cam.target, dYaw);
    const yaw = this.cam.yaw + dYaw;
    const axis = [-Math.sin(yaw), Math.cos(yaw), 0];
    const rotAxis = (p, a) => {
      const v = [p[0] - pivot[0], p[1] - pivot[1], p[2] - pivot[2]];
      const c = Math.cos(a);
      const s = Math.sin(a);
      const k = axis;
      const kv = k[0] * v[0] + k[1] * v[1] + k[2] * v[2];
      const cr = [k[1] * v[2] - k[2] * v[1], k[2] * v[0] - k[0] * v[2], k[0] * v[1] - k[1] * v[0]];
      return [pivot[0] + v[0] * c + cr[0] * s + k[0] * kv * (1 - c), pivot[1] + v[1] * c + cr[1] * s + k[1] * kv * (1 - c), pivot[2] + v[2] * c + cr[2] * s + k[2] * kv * (1 - c)];
    };
    e = rotAxis(e, -dPitch);
    t = rotAxis(t, -dPitch);
    const d = [e[0] - t[0], e[1] - t[1], e[2] - t[2]];
    const dist = Math.hypot(d[0], d[1], d[2]);
    this.cam.target = t;
    this.cam.dist = dist;
    this.cam.yaw = Math.atan2(d[1], d[0]);
    this.cam.pitch = Math.asin(Math.max(-1, Math.min(1, d[2] / dist)));
  }

  /** Animate to a yaw and pitch (orientation cube, standard views). */
  orient(yaw, pitch, fit = false) {
    const from = { yaw: this.cam.yaw, pitch: this.cam.pitch };
    let dy = yaw - from.yaw;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    const start = performance.now();
    const dur = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 320;
    const step = (now) => {
      const k = dur ? Math.min(1, (now - start) / dur) : 1;
      const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      this.cam.yaw = from.yaw + dy * e;
      this.cam.pitch = from.pitch + (pitch - from.pitch) * e;
      this.vp.requestRender();
      if (k < 1) requestAnimationFrame(step);
      else {
        if (fit) this.zoomExtents();
        this.app.viewChanged?.();
      }
    };
    requestAnimationFrame(step);
  }

  zoomExtents(render = true, initial = false, ids = null) {
    this.app.syncModel();
    const b = this.vp.r3.bounds(ids);
    if (this.is3D) {
      if (!b) return;
      const c = [(b.min[0] + b.max[0]) / 2, (b.min[1] + b.max[1]) / 2, (b.min[2] + b.max[2]) / 2];
      const r = Math.hypot(b.max[0] - b.min[0], b.max[1] - b.min[1], b.max[2] - b.min[2]) / 2 || 5000;
      const fov = ((this.cam.fov || 45) * Math.PI) / 180;
      const aspect = this.vp.width / this.vp.height;
      const f = Math.min(fov, 2 * Math.atan(Math.tan(fov / 2) * aspect));
      this.cam.target = c;
      this.cam.dist = (r / Math.sin(f / 2)) * 0.82;
      if (initial) this.cam.fitted = true;
    } else {
      const frame = this.frame();
      const range = this.modelRange(frame);
      const u0 = frame.u0 ?? range.u0;
      const u1 = frame.u1 ?? range.u1;
      const w = Math.max(2000, u1 - u0) * 1.2 + 6000;
      const h = Math.max(2000, range.z1 - range.z0) * 1.25 + 4000;
      const zoom = Math.min(this.vp.width / w, this.vp.height / h);
      this.cam = { cx: (u0 + u1) / 2 + 1500, cy: (range.z0 + range.z1) / 2 + 800, zoom };
    }
    if (render) this.vp.requestRender();
  }

  // Picking -----------------------------------------------------------------------------------

  pickId(x, y) {
    const idx = this.vp.r3.pickAt(x * this.vp.dpr, y * this.vp.dpr);
    return this.app.scene.idAt(idx);
  }

  hitTest(x, y) {
    const out = [];
    if (!this.is3D) {
      this.syncAnnotations();
      const p = this.screenToModel(x, y);
      const tol = 6 / this.cam.zoom;
      for (const [id, it] of this.annot.items) {
        if (this.app.flagsOf(id) & 4) continue;
        const g = it.g;
        let hit = g.picks.some((poly) => pointInPolygon(p, poly));
        if (!hit) hit = g.lines.some((l) => distToSegment(p, l.a, l.b) <= tol);
        if (hit) out.push(id);
      }
    }
    const id = this.pickId(x, y);
    if (id && !out.includes(id)) out.push(id);
    return out;
  }

  /** Screen-rectangle selection: window (all corners inside) or crossing. */
  boxSelectScreen(r, crossing) {
    const out = [];
    for (const [id, it] of this.vp.r3.items) {
      if (this.app.flagsOf(id) & 4) continue;
      const b = it.mesh.bounds;
      if (!b) continue;
      let x0 = Infinity;
      let y0 = Infinity;
      let x1 = -Infinity;
      let y1 = -Infinity;
      let behind = false;
      for (const x of [b.min[0], b.max[0]])
        for (const y of [b.min[1], b.max[1]])
          for (const z of [b.min[2], b.max[2]]) {
            const s = this.project3([x, y, z]);
            if (s.z > 1 || s.z < -1) behind = true;
            x0 = Math.min(x0, s.x);
            y0 = Math.min(y0, s.y);
            x1 = Math.max(x1, s.x);
            y1 = Math.max(y1, s.y);
          }
      if (behind && this.is3D) continue;
      const sb = { x0, y0, x1, y1 };
      if (bboxContains(r, sb) || (crossing && bboxIntersects(r, sb))) out.push(id);
    }
    if (!this.is3D) {
      for (const [id, b] of this.annBounds || []) {
        const a = this.modelToScreen([b.x0, b.y1]);
        const c = this.modelToScreen([b.x1, b.y0]);
        const sb = { x0: a.x, y0: a.y, x1: c.x, y1: c.y };
        if (bboxContains(r, sb) || (crossing && bboxIntersects(r, sb))) out.push(id);
      }
    }
    return out;
  }

  /** Elevations snap to annotation features only (levels and grids lines). */
  snapFeaturesNear() {
    return [];
  }

  // Orientation cube ---------------------------------------------------------------------------

  updateCube() {
    const cube = this.app.shell.viewcube;
    if (!cube || this.vp !== this.app.viewport) return;
    cube.hidden = !this.is3D;
    if (!this.is3D) return;
    const { right, up, back } = this.basis();
    // Columns are the images of the world axes in CSS space (x right, y down, z toward viewer).
    const m = [right[0], -up[0], back[0], 0, right[1], -up[1], back[1], 0, right[2], -up[2], back[2], 0, 0, 0, 0, 1];
    this.app.shell.cubeInner.style.transform = `matrix3d(${m.map((v) => v.toFixed(5)).join(',')})`;
  }
}

function norm3(v) {
  const l = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / l, v[1] / l, v[2] / l];
}

/** Reference - IE Siblings: the interior elevations of the same room, faded, beside this one in unfolded order. */
function siblingDrawings(app, view) {
  const doc = app.doc;
  const all = doc.all('elevation').filter((v) => v.interiorOf === view.interiorOf);
  const at = all.findIndex((v) => v.id === view.id);
  const meshOf = (el) => app.scene.mesh(el);
  const draw = all.map((v) => independentDrawing(doc, v, meshOf, MODEL_KINDS).lines);
  const span = draw.map((ls) => {
    const xs = ls.flatMap((l) => [l.a[0], l.b[0]]);
    return xs.length ? [Math.min(...xs), Math.max(...xs)] : [0, 0];
  });
  const out = [];
  const gap = 1000;
  let right = span[at][1];
  for (let i = at + 1; i < all.length; i++) {
    const dx = right + gap - span[i][0];
    out.push(siblingItem(all[i], draw[i], dx));
    right = span[i][1] + dx;
  }
  let left = span[at][0];
  for (let i = at - 1; i >= 0; i--) {
    const dx = left - gap - span[i][1];
    out.push(siblingItem(all[i], draw[i], dx));
    left = span[i][0] + dx;
  }
  return out;
}

function siblingItem(view, lines, dx) {
  const g = new PlanBuilder();
  for (const l of lines) g.line([l.a[0] + dx, l.a[1]], [l.b[0] + dx, l.b[1]], 1, 0, [150, 150, 150, 255]);
  return { id: `t:${view.id}`, kind: 'detailLine', g };
}
