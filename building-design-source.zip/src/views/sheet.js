/**
 * Sheet view: paper space with the title block and viewports. Viewports
 * are elements ({ kind: 'viewport', viewId: sheet, placedId: view, at })
 * so they select, move and delete like anything else.
 */
import { classColors } from '../core/attrs.js';
import { viewMatrix2D } from '../render/renderer2d.js';
import { PlanController } from './plan.js';
import { titleBlock, planViewportGraphics, modelViewportGraphics, scheduleViewportGraphics, viewportTitle, sheetSize } from '../core/sheet.js';
import { scheduleTable } from '../core/schedule.js';
import { translateLabel, uiLanguage } from '../ui/aclang.js';
import { viewFrame, sectionCuts, elevationAnnotations } from '../core/elevation.js';
import { hiddenLineEdges, viewMeshes } from '../core/hiddenline.js';
import { MODEL_KINDS } from '../core/scene.js';
import { hatchSegments, surfaceHatchOf } from '../core/elevhatch.js';
import { categoryOf } from '../core/catalog.js';
import { planContext, PlanBuilder } from '../core/plan.js';
import { renderViewImage } from './snapshot.js';
import { isFlatView } from '../core/doc.js';

const IMAGE_DPMM = 6;

export class SheetController extends PlanController {
  constructor(app, view) {
    super(app, view);
    this.images = new Map();
  }

  sync() {
    const sheet = this.view;
    if (!sheet) return;
    const scene = this.scene;
    const masterOn = this.app.settings.masterItems !== false;
    if (this.syncedVersion === scene.version && this.syncedView === sheet && this.syncedMaster === masterOn) return;
    this.syncedMaster = masterOn;
    const keep = new Set();
    this.grid.clear();
    this.bounds.clear();
    const tb = titleBlock(this.app.doc, sheet, { master: masterOn });
    this.area = tb.area;
    this.layer.set(`${sheet.id}#tb`, scene.indexOf(`${sheet.id}#tb`), 'grid', tb.builder);
    keep.add(`${sheet.id}#tb`);
    this.modelViewports = [];
    for (const vpEl of this.app.doc.all('viewport')) {
      if (vpEl.viewId !== sheet.id) continue;
      const view = this.app.doc.get(vpEl.placedId);
      if (!view) continue;
      let g;
      let rect;
      if (isFlatView(view)) {
        const pc = planContext(this.app.doc, view, scene.walls, scene.rooms);
        const r = planViewportGraphics(scene, view, vpEl, pc);
        g = r.builder;
        rect = r.rect;
        for (const it of r.items) {
          this.layer.set(it.key, scene.indexOf(vpEl.id), it.kind, it.builder);
          keep.add(it.key);
        }
      } else if (view.kind === 'schedule') {
        // A schedule as a ruled table, read from the model as it is now.
        const lang = uiLanguage(this.app.settings);
        const r = scheduleViewportGraphics(this.app.doc, view, vpEl, scheduleTable({ doc: this.app.doc, scene }, view, { label: (t) => translateLabel(t, lang) }));
        g = r.builder;
        rect = r.rect;
        for (const it of r.items) {
          this.layer.set(it.key, scene.indexOf(vpEl.id), it.kind, it.builder);
          keep.add(it.key);
        }
      } else if ((view.kind === 'elevation' || view.kind === 'section') && this.vectorDrawing(view)) {
        // Elevations and sections as vectors (cut parts and the edges seen), so they print and export with the rest.
        const r = modelViewportGraphics(this.app.doc, view, vpEl, this.vectorDrawing(view));
        g = r.builder;
        rect = r.rect;
        for (const it of r.items) {
          this.layer.set(it.key, scene.indexOf(vpEl.id), it.kind, it.builder);
          keep.add(it.key);
        }
      } else {
        const size = vpEl.size || [180, 120];
        rect = { x0: vpEl.at[0] - size[0] / 2, y0: vpEl.at[1] - size[1] / 2, x1: vpEl.at[0] + size[0] / 2, y1: vpEl.at[1] + size[1] / 2 };
        g = new PlanBuilder();
        viewportTitle(g, view, rect, this.app.doc, vpEl);
        g.pick([
          [rect.x0, rect.y0],
          [rect.x1, rect.y0],
          [rect.x1, rect.y1],
          [rect.x0, rect.y1],
        ]);
        this.modelViewports.push({ el: vpEl, view, rect });
      }
      this.layer.set(vpEl.id, scene.indexOf(vpEl.id), 'detailLine', g);
      keep.add(vpEl.id);
      const b = g.bounds();
      if (b) {
        this.bounds.set(vpEl.id, b);
        this.index(vpEl.id, b);
      }
    }
    // The master's own drawing (logos, lines, texts placed on the master): shown, not picked here.
    const masterId = sheet.kind === 'sheet' ? sheet.masterId : null;
    const master = masterId ? this.app.doc.get(masterId) : null;
    if (master?.kind === 'masterLayout' && masterOn)
      for (const el of this.app.doc.items.values()) {
        if (el.viewId !== masterId || el.kind === 'viewport') continue;
        const g = scene.planOf(master, el, { ...planContext(this.app.doc, { ...master, scale: 1 }, scene.walls, scene.rooms), scale: 1, view: master });
        if (!g) continue;
        this.layer.set(`m:${el.id}`, scene.indexOf(`m:${el.id}`), el.kind, g, el.drawZ ?? null);
        keep.add(`m:${el.id}`);
      }
    for (const el of this.app.doc.items.values()) {
      if (el.viewId !== sheet.id || el.kind === 'viewport') continue;
      const g = scene.planOf(sheet, el, { ...planContext(this.app.doc, { ...sheet, scale: 1 }, scene.walls, scene.rooms), scale: 1, view: sheet });
      if (!g) continue;
      this.layer.set(el.id, scene.indexOf(el.id), el.kind, g, el.drawZ ?? null);
      keep.add(el.id);
      const b = scene.planBounds(sheet, el.id);
      if (b) {
        this.bounds.set(el.id, b);
        this.index(el.id, b);
      }
    }
    this.layer.retain(keep);
    this.syncedVersion = scene.version;
    this.syncedView = sheet;
    this.featureCache.clear();
    this.imagesDirty = true;
  }

  render(vp) {
    this.sync();
    if (!this.cam) this.zoomExtents(false);
    // External drawings and pictures placed on the layout (paper millimetres).
    const images = this.app.doc.all('image').filter((i) => i.viewId === this.view?.id || (this.view?.kind === 'sheet' && this.view.masterId && i.viewId === this.view.masterId));
    if (images.length) {
      const { cx, cy, zoom } = this.cam;
      vp.images.draw(images, viewMatrix2D(cx, cy, zoom, vp.width, vp.height, [0, 0], this.cam.rot || 0), vp.theme, (id) => this.app.flagsOf(String(id).split('#')[0]));
    }
    this.vp.r2.draw(this.layer, this.camera(), vp.theme, { dashScale: 1, spacing: 1.6, thin: this.app.settings.thinLines, noBold: this.app.settings.boldCutLines === false, classColors: classColors(this.app.doc.project), pen: this.view?.penSet });
  }

  extents() {
    const { w, h } = sheetSize(this.view);
    return { x0: -10, y0: -10, x1: w + 10, y1: h + 10 };
  }

  zoomExtents(render = true) {
    this.zoomToBox(this.extents(), render);
  }

  /**
   * An elevation's or section's vector drawing, kept until the model or the view changes; null for a model too large to
   * draw this way (it stays a picture).
   */
  vectorDrawing(view) {
    const scene = this.app.scene;
    const key = `${scene.version}|${JSON.stringify(view)}`;
    this.vectors ||= new Map();
    const had = this.vectors.get(view.id);
    if (had?.key === key) return had.drawing;
    const doc = this.app.doc;
    const meshOf = (el) => scene.mesh(el);
    const meshes = viewMeshes(doc, view, meshOf, MODEL_KINDS);
    let drawing = null;
    if (meshes.reduce((n, m) => n + m.pos.length / 9, 0) <= 400000) {
      const frame = viewFrame(view);
      const cuts = sectionCuts(doc, frame, meshOf, view.detail, view.structureDisplay || 'entire');
      const f = frame.cut ? { ...frame, near: 1 } : frame;
      // Elevations: the hatches of the materials seen (tiles on a roof), as lines the hidden line drawing keeps where seen.
      let hatch = null;
      if (!frame.cut) {
        const hiddenCats = new Set(view.hiddenCats || []);
        const hiddenIds = new Set(view.hiddenIds || []);
        const elements = [];
        for (const kind of MODEL_KINDS)
          for (const el of doc.all(kind)) {
            if (hiddenIds.has(el.id)) continue;
            const cat = categoryOf(el, doc);
            if (cat && hiddenCats.has(cat)) continue;
            const h = surfaceHatchOf(doc, el);
            const mesh = h ? meshOf(el) : null;
            if (mesh?.pos) elements.push({ mesh, hatch: h, up: el.kind === 'roof' });
          }
        const segs = elements.length ? hatchSegments(frame, elements) : null;
        if (segs?.length) hatch = { pos: new Float32Array(0), edges: segs };
      }
      const lines = hiddenLineEdges(hatch ? [...meshes, hatch] : meshes, f, { res: 20 });
      // Levels and grids as the view shows them, across what is drawn.
      const pts = [...lines.flatMap((l) => [l.a, l.b]), ...cuts.flatMap((c) => (c.g.lines || []).flatMap((l) => [l.a, l.b]))];
      const range = pts.length ? { u0: Math.min(...pts.map((p) => p[0])), u1: Math.max(...pts.map((p) => p[0])), z0: Math.min(...pts.map((p) => p[1])), z1: Math.max(...pts.map((p) => p[1])) } : { u0: 0, u1: 1000, z0: 0, z1: 1000 };
      const notes = elevationAnnotations(doc, view, { ...frame, u0: range.u0, u1: range.u1 }, range, scene.walls, meshOf).map((a) => a.g);
      drawing = { builders: cuts.map((c) => c.g), lines, notes };
    }
    this.vectors.set(view.id, { key, drawing });
    return drawing;
  }

  /** Images of 3D, elevation and section viewports, rendered when needed. */
  imageFor(m) {
    const key = `${m.el.id}|${this.scene.version}|${m.view === this.app.doc.get(m.view.id)}`;
    const cached = this.images.get(m.el.id);
    if (cached && cached.key === key) return cached.canvas;
    if (this.rendering) return cached?.canvas ?? null;
    // Render after this frame so the main view is not interrupted.
    this.rendering = true;
    setTimeout(() => {
      try {
        const w = (m.rect.x1 - m.rect.x0) * IMAGE_DPMM;
        const h = (m.rect.y1 - m.rect.y0) * IMAGE_DPMM;
        const { canvas } = renderViewImage(this.app, m.view, w, h, { fit: true });
        this.images.set(m.el.id, { key, canvas });
      } catch (err) {
        // Remember the failure so it is not retried on every frame.
        console.warn(err);
        this.images.set(m.el.id, { key, canvas: null });
      }
      this.rendering = false;
      this.vp.requestRender();
    }, 0);
    return cached?.canvas ?? null;
  }

  drawOverlay(ctx, vp) {
    for (const m of this.modelViewports || []) {
      const img = this.imageFor(m);
      if (!img) continue;
      const a = this.modelToScreen([m.rect.x0, m.rect.y1]);
      const b = this.modelToScreen([m.rect.x1, m.rect.y0]);
      ctx.drawImage(img, a.x, a.y, b.x - a.x, b.y - a.y);
    }
    if (this.app.settings.drawingFrames) {
      ctx.save();
      ctx.strokeStyle = 'rgba(31, 111, 255, 0.8)';
      ctx.setLineDash([5, 3]);
      ctx.lineWidth = 1;
      for (const el of this.app.doc.all('viewport')) {
        const r = el.viewId === this.view.id && this.bounds.get(el.id);
        if (!r) continue;
        const a = this.modelToScreen([r.x0, r.y1]);
        const b = this.modelToScreen([r.x1, r.y0]);
        ctx.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y);
      }
      ctx.restore();
    }
    super.drawOverlay(ctx, vp);
  }

  dispose() {
    super.dispose();
    this.images.clear();
  }
}
