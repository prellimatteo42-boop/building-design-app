/**
 * Project files for automation through the MCP bridge (Claude Code): start a
 * new project, open a saved one, save it, and export it in any format the app
 * writes, to paths on this computer. The page never touches the disk: the
 * dev server (mcp-bridge.mjs) reads the file for open_project and writes the
 * `_file` a tool returns, inside the user's home folder only.
 */
import { encodeProject, decodeProject, NATIVE_EXT } from '../io/native.js';
import { exportAs } from '../io/exporters.js';
import { isView } from '../core/doc.js';

export const EXPORT_FORMATS = ['bdp', 'ifc', 'pdf', 'png', 'svg', 'dxf', 'xlsx', 'csv', 'obj', 'glb', 'kmz', 'saf'];

const toBase64 = async (blob) => {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
};

/** Run fn while catching the files it would download: [{ blob, name }]. */
async function captured(fn) {
  const prev = globalThis.__bdCapture;
  globalThis.__bdCapture = [];
  try {
    await fn();
    return globalThis.__bdCapture;
  } finally {
    globalThis.__bdCapture = prev;
  }
}

function findView(doc, name) {
  const n = String(name || '').toLowerCase();
  const views = doc.filter(isView);
  return views.find((v) => v.name.toLowerCase() === n) || views.find((v) => v.name.toLowerCase().includes(n)) || null;
}

export const FILE_TOOLS = [
  {
    bridgeOnly: true,
    name: 'new_project',
    description: 'Start a new empty project (metric or imperial), replacing the open one without asking: save first with save_project if it matters.',
    parameters: { type: 'object', properties: { system: { type: 'string', enum: ['metric', 'imperial'] }, name: { type: 'string' } } },
    run(app, { system = 'metric', name }) {
      app.newProject(system);
      if (name) app.commit('Project name', () => app.doc.update('project', { name }));
      return { project: app.doc.project?.name || name || 'Untitled', levels: app.doc.levels().map((l) => l.name) };
    },
  },
  {
    bridgeOnly: true,
    name: 'open_project',
    description: `Open a Building Design project file (${NATIVE_EXT}) from an absolute path on this computer, replacing the open project. For DWG, DXF, IFC, PDF or pictures use model_from_file instead.`,
    parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] },
    async run(app, { data_base64, name }) {
      if (!data_base64) return { error: 'open_project works through Claude Code (the file is read by the dev server)' };
      const bin = atob(data_base64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const doc = await decodeProject(bytes.buffer);
      app.setDoc(doc, { name });
      return { opened: name, levels: doc.levels().map((l) => l.name), elements: doc.items.size };
    },
  },
  {
    bridgeOnly: true,
    name: 'save_project',
    description: `Save the open project as a ${NATIVE_EXT} file at an absolute path on this computer (inside the home folder).`,
    parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] },
    async run(app) {
      const blob = await encodeProject(app.doc);
      return { _file: { base64: await toBase64(blob), bytes: blob.size } };
    },
  },
  {
    bridgeOnly: true,
    name: 'export_file',
    description: `Export the open project to a file at an absolute path on this computer (inside the home folder). Formats: ${EXPORT_FORMATS.join(', ')}. pdf, png, svg and dxf export a view (give view, else the active one; a sheet gives a drawing set page); csv one schedule (view); xlsx all schedules; ifc, obj, glb the model; saf the structural analytical model.`,
    parameters: { type: 'object', properties: { path: { type: 'string' }, format: { type: 'string', enum: EXPORT_FORMATS }, view: { type: 'string', description: 'View, sheet or schedule name' } }, required: ['path', 'format'] },
    async run(app, { format, view }) {
      if (view) {
        const v = findView(app.doc, view);
        if (!v) return { error: `No view named ${view}` };
        app.openView(v.id);
      }
      const files = await captured(async () => {
        if (format === 'saf') await app.exportSAF();
        else await exportAs(app, format);
      });
      if (!files.length) return { error: `Nothing to export as ${format} (open a fitting view, or the model has nothing for it)` };
      // Several files (e.g. one per schedule) go out as the first; the rest are named in the reply.
      return { _file: { base64: await toBase64(files[0].blob), bytes: files[0].blob.size }, suggested_name: files[0].name, also: files.slice(1).map((f) => f.name) };
    },
  },
];
