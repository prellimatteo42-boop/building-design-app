/**
 * The page's side of the line to Claude: posts one turn to the dev server,
 * which adds the API key and forwards it (see claude-proxy.mjs). Resolves to
 * the Claude message: content blocks and a stop reason.
 */
export async function askClaude({ system, messages, tools = [] }) {
  const key = browserKey();
  if (key) return askFromBrowser(key, { system, messages, tools });
  let res;
  try {
    res = await fetch('./api/claude', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ system, messages, tools }) });
  } catch {
    throw new Error('The AI could not be reached. Is the dev server running?');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `The AI did not answer (${res.status})`);
  return data;
}

/** Which AI the server offers: 'api' (API key), 'claude-code' (Claude Code login) or 'none'; on a plain website, the user's own key. */
export async function aiBackend() {
  let backend = 'none';
  try {
    const res = await fetch('./api/claude-backend', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    if (res.ok && /json/.test(res.headers.get('content-type') || '')) backend = (await res.json()).backend || 'none';
  } catch {
    backend = 'none';
  }
  return backend === 'none' && browserKey() ? 'api' : backend;
}

const KEY_NAME = 'bd.claudeKey';

/** The user's own Claude API key, kept in this browser (where there is no server to keep it). */
export function browserKey() {
  try {
    return localStorage.getItem(KEY_NAME) || '';
  } catch {
    return '';
  }
}

export function setBrowserKey(key) {
  localStorage.setItem(KEY_NAME, key);
}

/** One turn straight from this browser to the Claude API, with the user's own key, on a site that has no server. */
async function askFromBrowser(apiKey, { system, messages, tools }) {
  const { default: Anthropic } = await import('@anthropic-ai/sdk');
  const client = new Anthropic({ apiKey, dangerouslyAllowBrowser: true });
  try {
    return await client.beta.messages.create({
      model: 'claude-opus-5-5',
      max_tokens: 16000,
      output_config: { effort: 'medium' },
      cache_control: { type: 'ephemeral' },
      system,
      messages,
      ...(tools.length ? { tools: tools.map(({ name, description, input_schema }) => ({ name, description, input_schema })) } : {}),
    });
  } catch (err) {
    if (err instanceof Anthropic.AuthenticationError) throw new Error('Claude rejected the API key.');
    if (err instanceof Anthropic.RateLimitError) throw new Error('Too many requests to Claude. Wait a moment and try again.');
    if (err instanceof Anthropic.APIConnectionError) throw new Error('Could not reach the Claude API. Check your connection.');
    throw err;
  }
}

/**
 * One turn with Claude Code: it works on the project through the MCP bridge
 * and resolves to { text, session }; pass session back to continue.
 */
export async function askClaudeCode({ system, message, session }) {
  let res;
  try {
    res = await fetch('./api/claude-code', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ system, message, session }) });
  } catch {
    throw new Error('The AI could not be reached. Is the dev server running?');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `The AI did not answer (${res.status})`);
  return data;
}

/** The text of a Claude message, without its thinking or tool calls. */
export function messageText(msg) {
  return (msg?.content || [])
    .filter((b) => b.type === 'text')
    .map((b) => b.text)
    .join('');
}
