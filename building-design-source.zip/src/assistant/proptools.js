/**
 * Assistant functions for properties, as the property tools Archicad gives
 * an AI: property groups and custom property definitions (search, create,
 * modify, delete), reading and setting property values of elements, finding
 * elements by criteria on their properties, and named element lists that
 * later calls can refer to instead of repeating ids.
 *
 * Units in and out: lengths in millimetres, areas in m², volumes in m³,
 * angles in degrees. Built-in properties are the fields schedules and
 * autotext show (group "General"); custom ones are the project parameters.
 */
import { KIND_LABEL, categoryOf, CATEGORIES } from '../core/catalog.js';
import { isView } from '../core/doc.js';
import { autotextFields } from '../core/autotext.js';
import { PARAM_TYPES, RESULT_TYPES, projectParams, propertyGroups, paramsForElement, paramValueOf, coerceParamValue } from '../core/params.js';

const BUILT_IN = 'General';
const TYPES = PARAM_TYPES.map((t) => t.value);
const OUT = { area: 1e6, volume: 1e9 };

/** Element lists of this session, by name: Map name -> [id]. */
function lists(app) {
  if (!app.elementLists) app.elementLists = new Map();
  return app.elementLists;
}

/** The elements a call names: ids, a stored list, or the selection. */
function targets(app, { ids, list }) {
  const doc = app.doc;
  let src = ids;
  if (!src?.length && list) {
    src = lists(app).get(list);
    if (!src) throw new Error(`No element list "${list}"; lists: ${[...lists(app).keys()].join(', ') || 'none'}`);
  }
  if (!src?.length) src = [...(app.selection || [])];
  return src.map((id) => doc.get(id)).filter(Boolean);
}

/** Every model element that can carry properties. */
function modelElements(doc) {
  const out = [];
  for (const el of doc.items.values()) {
    if (isView(el) || el.kind.endsWith('Type') || el.viewId) continue;
    if (!categoryOf(el, doc) && !el.classes) continue;
    out.push(el);
  }
  return out;
}

const fuzzy = (q) => {
  const words = String(q || '').toLowerCase().split(/\s+/).filter(Boolean);
  return (text) => words.every((w) => String(text).toLowerCase().includes(w));
};

/** The group a name refers to (any case), or null. */
function groupNamed(doc, name) {
  const n = String(name || '').toLowerCase();
  return propertyGroups(doc).find((g) => g.name.toLowerCase() === n) || null;
}

function describeDefinition(doc, p) {
  const systems = doc.all('classSystem');
  return {
    group: p.group || 'Identity Data',
    name: p.name,
    type: p.type,
    ...(p.description ? { description: p.description } : {}),
    ...(p.options?.length ? { options: p.options } : {}),
    ...(p.default != null && p.default !== '' ? { default: outValue(p, p.default) } : {}),
    ...(p.type === 'expression' ? { expression: p.expression, result: p.result } : {}),
    categories: p.categories || [],
    ...(p.classes?.length ? { classifications: p.classes.map((c) => `${systems.find((s) => s.id === c.system)?.name ?? c.system}: ${c.code}`) } : {}),
    editable: p.type !== 'expression',
  };
}

/** A stored value in the units the assistant uses. */
function outValue(p, v) {
  const t = p.type === 'expression' ? p.result : p.type;
  if (v === null || v === undefined) return null;
  if (OUT[t]) return Math.round((+v / OUT[t]) * 1e4) / 1e4;
  if (typeof v === 'number') return Math.round(v * 1e4) / 1e4;
  return v;
}

/** A value from the assistant in stored units, or an Error. */
function inValue(p, v) {
  const c = coerceParamValue(p, v);
  if (c instanceof Error || c === null) return c;
  return OUT[p.type] ? c * OUT[p.type] : c;
}

/** The properties of an element by group and name: custom ones, then built-in fields. */
function propertyOf(doc, el, { group, name }) {
  const n = String(name || '').toLowerCase();
  const g = group ? String(group).toLowerCase() : null;
  if (!g || g !== BUILT_IN.toLowerCase()) {
    const p = paramsForElement(doc, el).find((x) => x.name.toLowerCase() === n && (!g || (x.group || 'Identity Data').toLowerCase() === g));
    if (p) return { custom: p };
    if (g) {
      const any = projectParams(doc).find((x) => x.name.toLowerCase() === n && (x.group || 'Identity Data').toLowerCase() === g);
      if (any) return { unavailable: true };
    }
  }
  if (g && g !== BUILT_IN.toLowerCase()) return null;
  const f = autotextFields(el).find((x) => !x.project && (x.label.toLowerCase() === n || x.id.toLowerCase() === n));
  return f ? { builtIn: f } : null;
}

function readProperty(app, el, prop) {
  const doc = app.doc;
  const ctx = { doc, scene: app.scene };
  if (prop.custom) {
    const r = paramValueOf(ctx, el, prop.custom);
    return r.error ? { error: r.error } : { value: outValue(prop.custom, r.value) };
  }
  let v;
  try {
    v = prop.builtIn.get(el, ctx);
  } catch {
    v = null;
  }
  const t = prop.builtIn.type;
  if (OUT[t] && typeof v === 'number') v = Math.round((v / OUT[t]) * 1e4) / 1e4;
  else if (typeof v === 'number') v = Math.round(v * 1e4) / 1e4;
  return { value: v ?? null };
}

const COMPARE = {
  '=': (a, b) => eq(a, b),
  '!=': (a, b) => !eq(a, b),
  '<': (a, b) => +a < +b,
  '<=': (a, b) => +a <= +b,
  '>': (a, b) => +a > +b,
  '>=': (a, b) => +a >= +b,
  contains: (a, b) => (Array.isArray(a) ? a.some((x) => String(x).toLowerCase().includes(String(b).toLowerCase())) : String(a ?? '').toLowerCase().includes(String(b).toLowerCase())),
  not_contains: (a, b) => !COMPARE.contains(a, b),
  empty: (a) => a === null || a === undefined || a === '' || (Array.isArray(a) && !a.length),
  not_empty: (a) => !COMPARE.empty(a),
};

function eq(a, b) {
  if (Array.isArray(a)) return a.some((x) => eq(x, b));
  if (typeof a === 'number' || typeof b === 'number') return Math.abs(+a - +b) < 1e-6 * Math.max(1, Math.abs(+b));
  if (typeof a === 'boolean') return a === (b === true || ['yes', 'true', '1'].includes(String(b).toLowerCase()));
  return String(a ?? '').toLowerCase() === String(b ?? '').toLowerCase();
}

const PROP_ID = { type: 'object', properties: { group: { type: 'string', description: 'Property group (leave out to find the name in any group; "General" for built-in fields)' }, name: { type: 'string' } }, required: ['name'] };
const ELEMENTS = {
  ids: { type: 'array', items: { type: 'string' }, description: 'Element ids (default: the stored list named by `list`, else the selection)' },
  list: { type: 'string', description: 'Name of an element list stored with element_lists or find_by_criteria' },
};

export const PROPERTY_TOOLS = [
  {
    name: 'property_groups',
    description: 'Property groups (as in Archicad\'s Property Manager): list or search them, or create, rename or delete groups of your own. Built-in groups cannot be changed. Create a group before adding properties to it with property_definitions.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['search', 'create', 'modify', 'delete'] },
        query: { type: 'string', description: 'Words to search group names (search; empty lists all)' },
        groups: { type: 'array', description: 'create: [{ name, description }]; modify: [{ name, new_name, description }]; delete: [{ name }]', items: { type: 'object', properties: { name: { type: 'string' }, new_name: { type: 'string' }, description: { type: 'string' } }, required: ['name'] } },
      },
      required: ['action'],
    },
    run(app, { action, query, groups = [] }) {
      const doc = app.doc;
      if (action === 'search') {
        const m = fuzzy(query);
        return { groups: propertyGroups(doc).filter((g) => m(g.name)).map((g) => ({ name: g.name, description: g.description, user_defined: g.userDefined, properties: projectParams(doc).filter((p) => (p.group || 'Identity Data') === g.name).length })) };
      }
      const done = [];
      const errors = [];
      app.commit(`Assistant: ${action} property groups`, () => {
        for (const g of groups) {
          const name = String(g.name || '').trim();
          const cur = groupNamed(doc, name);
          if (action === 'create') {
            if (!name) errors.push({ name, error: 'A group needs a name' });
            else if (cur) errors.push({ name, error: 'A group with this name exists; choose another name' });
            else done.push(doc.add({ kind: 'propertyGroup', name, description: String(g.description || '') }).name);
            continue;
          }
          if (!cur) errors.push({ name, error: 'No such group' });
          else if (!cur.userDefined) errors.push({ name, error: 'Built-in groups cannot be changed' });
          else if (action === 'delete') {
            const used = projectParams(doc).filter((p) => p.group === cur.name);
            if (used.length) errors.push({ name, error: `The group still holds ${used.length} properties: ${used.map((p) => p.name).join(', ')}` });
            else (doc.remove(cur.id), done.push(cur.name));
          } else {
            const nn = g.new_name ? String(g.new_name).trim() : cur.name;
            if (nn.toLowerCase() !== cur.name.toLowerCase() && groupNamed(doc, nn)) {
              errors.push({ name, error: `A group named ${nn} exists` });
              continue;
            }
            doc.update(cur.id, { name: nn, ...(g.description !== undefined ? { description: String(g.description) } : {}) });
            for (const p of projectParams(doc)) if (p.group === cur.name) doc.update(p.id, { group: nn });
            done.push(nn);
          }
        }
      });
      return { success: !errors.length, done, ...(errors.length ? { errors } : {}) };
    },
  },
  {
    name: 'property_definitions',
    description: `Custom properties (project parameters): search all properties, custom and built-in, or create, modify or delete custom ones. Types: ${TYPES.join(', ')} (choice = one option of a set, multi = several options, list = a list of texts). A property is available for the categories listed (${CATEGORIES.filter((c) => c.model).slice(0, 8).map((c) => c.id).join(', ')}, ... or "*" for all) and/or for classification items (codes, with the items under them). Defaults use the units: length mm, area m², volume m³, angle degrees.`,
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['search', 'create', 'modify', 'delete'] },
        query: { type: 'string', description: 'search: words matched against names, groups, descriptions and options' },
        group: { type: 'string', description: 'search: only properties of this group' },
        kind: { type: 'string', description: 'search: also list the built-in fields of this element kind (wall, door, room...)' },
        properties: {
          type: 'array',
          description: 'create / modify / delete: one entry per property',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              group: { type: 'string', description: 'Group (create: default Identity Data; modify: identifies the property when names repeat)' },
              new_name: { type: 'string' },
              new_group: { type: 'string' },
              type: { type: 'string', enum: TYPES },
              description: { type: 'string' },
              options: { type: 'array', items: { type: 'string' } },
              default: { description: 'Default value' },
              categories: { type: 'array', items: { type: 'string' } },
              classifications: { type: 'array', items: { type: 'string' }, description: 'Classification item codes, optionally "System: code"' },
              expression: { type: 'string', description: 'For type expression: e.g. {Area} * 1.1' },
              result: { type: 'string', enum: RESULT_TYPES.map((r) => r.value) },
            },
            required: ['name'],
          },
        },
      },
      required: ['action'],
    },
    run(app, { action, query, group, kind, properties = [] }) {
      const doc = app.doc;
      if (action === 'search') {
        const m = fuzzy(query);
        const g = group ? String(group).toLowerCase() : null;
        const custom = projectParams(doc)
          .filter((p) => !g || (p.group || 'Identity Data').toLowerCase() === g)
          .filter((p) => m(`${p.name} ${p.group || ''} ${p.description || ''} ${(p.options || []).join(' ')}`))
          .map((p) => describeDefinition(doc, p));
        const builtIn = kind && (!g || g === BUILT_IN.toLowerCase()) ? autotextFields({ kind }).filter((f) => !f.project && m(f.label)).map((f) => ({ group: BUILT_IN, name: f.label, type: f.type, editable: !!f.edit })) : [];
        return { count: custom.length + builtIn.length, properties: [...custom, ...builtIn].slice(0, 150) };
      }
      const systems = doc.all('classSystem');
      const classesOf = (codes) => {
        const out = [];
        for (const c of codes || []) {
          const [sysName, code] = String(c).includes(':') ? String(c).split(':').map((x) => x.trim()) : [null, String(c).trim()];
          const sys = sysName ? systems.find((s) => s.name.toLowerCase().includes(sysName.toLowerCase())) : systems.find((s) => s.items.some((i) => i.code === code));
          if (!sys || !sys.items.some((i) => i.code === code)) throw new Error(`No classification item ${c}`);
          out.push({ system: sys.id, code });
        }
        return out;
      };
      const find = (q) => {
        const n = String(q.name).toLowerCase();
        const all = projectParams(doc).filter((p) => p.name.toLowerCase() === n);
        return q.group ? all.find((p) => (p.group || 'Identity Data').toLowerCase() === String(q.group).toLowerCase()) : all[0];
      };
      const done = [];
      const errors = [];
      app.commit(`Assistant: ${action} properties`, () => {
        for (const q of properties) {
          try {
            if (action === 'create') {
              const type = q.type || 'text';
              if (!TYPES.includes(type)) throw new Error(`Unknown type ${type}`);
              const gr = groupNamed(doc, q.group || 'Identity Data');
              if (!gr) throw new Error(`No group ${q.group}; create it first with property_groups`);
              if (find({ name: q.name, group: gr.name })) throw new Error(`${gr.name} already has a property ${q.name}`);
              if ((type === 'choice' || type === 'multi') && !q.options?.length) throw new Error('An option set needs options');
              const p = { kind: 'projectParam', name: String(q.name).trim(), type, group: gr.name, description: q.description || '', categories: q.categories || [], classes: classesOf(q.classifications), ...(q.options ? { options: [...new Set(q.options.map(String))] } : {}), ...(type === 'expression' ? { expression: q.expression || '', result: q.result || 'number' } : {}) };
              if (!p.categories.length && !p.classes.length) throw new Error('Say which categories or classifications the property is for');
              if (q.default !== undefined && type !== 'expression') {
                const d = inValue(p, q.default);
                if (d instanceof Error) throw d;
                p.default = d;
              }
              done.push(describeDefinition(doc, doc.add(p)));
              continue;
            }
            const p = find(q);
            if (!p) throw new Error('No such custom property (built-in ones cannot be changed)');
            if (action === 'delete') {
              for (const el of doc.items.values())
                if (el.params && p.id in el.params) {
                  const { [p.id]: _drop, ...rest } = el.params;
                  void _drop;
                  doc.update(el.id, { params: rest });
                }
              doc.remove(p.id);
              done.push({ name: p.name, group: p.group, deleted: true });
              continue;
            }
            const patch = {};
            if (q.new_name) patch.name = String(q.new_name).trim();
            if (q.new_group) {
              const gr = groupNamed(doc, q.new_group);
              if (!gr) throw new Error(`No group ${q.new_group}`);
              patch.group = gr.name;
            }
            for (const k of ['description', 'categories', 'expression', 'result']) if (q[k] !== undefined) patch[k] = q[k];
            if (q.options) patch.options = [...new Set(q.options.map(String))];
            if (q.classifications) patch.classes = classesOf(q.classifications);
            if (q.type && q.type !== p.type) {
              if (!TYPES.includes(q.type)) throw new Error(`Unknown type ${q.type}`);
              patch.type = q.type;
            }
            const next = { ...p, ...patch };
            if (q.default !== undefined) {
              const d = inValue(next, q.default);
              if (d instanceof Error) throw d;
              patch.default = d;
            }
            doc.update(p.id, patch);
            done.push(describeDefinition(doc, doc.get(p.id)));
          } catch (err) {
            errors.push({ name: q.name, error: err.message });
          }
        }
      });
      return { success: !errors.length, [action === 'delete' ? 'deleted' : action === 'create' ? 'created' : 'modified']: done, ...(errors.length ? { errors } : {}) };
    },
  },
  {
    name: 'get_property_values',
    description: 'Read property values of elements, custom and built-in (lengths mm, areas m², volumes m³, angles degrees). Without properties, gives every custom property available for each element.',
    parameters: { type: 'object', properties: { ...ELEMENTS, properties: { type: 'array', items: PROP_ID } } },
    run(app, input) {
      const doc = app.doc;
      const els = targets(app, input);
      if (!els.length) return { error: 'No elements: give ids, a list or select them' };
      const out = [];
      for (const el of els.slice(0, 300)) {
        const values = [];
        const asked = input.properties?.length ? input.properties : paramsForElement(doc, el).map((p) => ({ group: p.group || 'Identity Data', name: p.name }));
        for (const q of asked) {
          const prop = propertyOf(doc, el, q);
          if (!prop) values.push({ ...q, error: 'No such property' });
          else if (prop.unavailable) values.push({ ...q, error: 'Not available for this element' });
          else values.push({ group: prop.custom ? prop.custom.group || 'Identity Data' : BUILT_IN, name: prop.custom ? prop.custom.name : prop.builtIn.label, ...readProperty(app, el, prop) });
        }
        out.push({ id: el.id, kind: el.kind, label: KIND_LABEL[el.kind] || el.kind, values });
      }
      return { count: out.length, ...(els.length > out.length ? { note: `First ${out.length} of ${els.length}` } : {}), elements: out };
    },
  },
  {
    name: 'set_property_values',
    description: 'Set property values on elements in one undoable change: custom properties (option sets take one of their options; multi and list take arrays) and the editable built-in fields such as Name, Number, Mark and Comments. Lengths mm, areas m², volumes m³, angles degrees. Expression properties are computed and cannot be set.',
    parameters: { type: 'object', properties: { ...ELEMENTS, values: { type: 'array', items: { ...PROP_ID, properties: { ...PROP_ID.properties, value: { description: 'The new value; null clears it' } }, required: ['name', 'value'] } } }, required: ['values'] },
    run(app, input) {
      const doc = app.doc;
      const els = targets(app, input);
      if (!els.length) return { error: 'No elements: give ids, a list or select them' };
      const errors = new Map();
      const fail = (msg, id) => (errors.has(msg) ? errors.get(msg) : errors.set(msg, []).get(msg)).push(id);
      let changed = 0;
      app.commit('Assistant: set property values', () => {
        for (const el of els) {
          let patch = {};
          for (const q of input.values || []) {
            const prop = propertyOf(doc, el, q);
            const label = `${q.group ? `${q.group} / ` : ''}${q.name}`;
            if (!prop) fail(`${label}: no such property`, el.id);
            else if (prop.unavailable) fail(`${label}: not available for this element`, el.id);
            else if (prop.custom) {
              const v = inValue(prop.custom, q.value);
              if (v instanceof Error) fail(`${label}: ${v.message}`, el.id);
              else patch = { ...patch, params: { ...(el.params || {}), ...(patch.params || {}), [prop.custom.id]: v } };
            } else if (!prop.builtIn.edit) fail(`${label}: read-only`, el.id);
            else patch[prop.builtIn.edit] = q.value == null ? '' : String(q.value);
          }
          if (Object.keys(patch).length) (doc.update(el.id, patch), changed++);
        }
      });
      return { success: !errors.size, changed_elements: changed, ...(errors.size ? { errors: [...errors].map(([message, ids]) => ({ message, ids: ids.slice(0, 50), count: ids.length })) } : {}) };
    },
  },
  {
    name: 'find_by_criteria',
    description: 'Find elements whose properties meet criteria (as Archicad\'s Find & Select): a list of groups, an element matches when it meets any group; inside a group the checks are combined with "and" (default) or "or", and kinds/level narrow it. Operators: =, !=, <, <=, >, >=, contains, not_contains, empty, not_empty. Units: lengths mm, areas m², volumes m³. The result can be stored as a named element list and/or selected.',
    parameters: {
      type: 'object',
      properties: {
        groups: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              kinds: { type: 'array', items: { type: 'string' } },
              level: { type: 'string' },
              combine: { type: 'string', enum: ['and', 'or'] },
              checks: { type: 'array', items: { type: 'object', properties: { ...PROP_ID.properties, op: { type: 'string', enum: Object.keys(COMPARE) }, value: {} }, required: ['name', 'op'] } },
            },
          },
        },
        store_as: { type: 'string', description: 'Store the matches as an element list with this name' },
        select: { type: 'boolean', description: 'Select the matches' },
      },
      required: ['groups'],
    },
    run(app, { groups, store_as, select }) {
      const doc = app.doc;
      const levels = doc.levels();
      const hits = [];
      for (const el of modelElements(doc)) {
        const ok = (groups || []).some((g) => {
          if (g.kinds?.length && !g.kinds.includes(el.kind)) return false;
          if (g.level) {
            const lv = levels.find((l) => l.name.toLowerCase() === String(g.level).toLowerCase());
            if (!lv || el.levelId !== lv.id) return false;
          }
          const checks = g.checks || [];
          if (!checks.length) return true;
          const test = (c) => {
            const prop = propertyOf(doc, el, c);
            if (!prop || prop.unavailable) return false;
            const r = readProperty(app, el, prop);
            return !r.error && COMPARE[c.op]?.(r.value, c.value);
          };
          return g.combine === 'or' ? checks.some(test) : checks.every(test);
        });
        if (ok) hits.push(el);
      }
      if (store_as) lists(app).set(String(store_as), hits.map((e) => e.id));
      if (select) app.showElements(hits.map((e) => e.id));
      const byKind = {};
      for (const e of hits) byKind[e.kind] = (byKind[e.kind] || 0) + 1;
      return { count: hits.length, by_kind: byKind, ids: hits.slice(0, 200).map((e) => e.id), ...(store_as ? { stored_as: store_as } : {}) };
    },
  },
  {
    name: 'element_lists',
    description: 'Named lists of element ids kept for this conversation, so later calls can pass `list` instead of the ids: store one, get it, list them all, or clear one or all.',
    parameters: { type: 'object', properties: { action: { type: 'string', enum: ['store', 'get', 'list', 'clear'] }, name: { type: 'string' }, ids: { type: 'array', items: { type: 'string' }, description: 'store: the ids (default: the selection)' } }, required: ['action'] },
    run(app, { action, name, ids }) {
      const L = lists(app);
      if (action === 'list') return { lists: [...L].map(([n, v]) => ({ name: n, count: v.length })) };
      if (action === 'clear') {
        if (name) L.delete(name);
        else L.clear();
        return { success: true };
      }
      if (!name) return { error: 'Give the list a name' };
      if (action === 'store') {
        const live = (ids?.length ? ids : [...(app.selection || [])]).filter((id) => app.doc.has(id));
        L.set(name, live);
        return { stored: live.length, name };
      }
      const v = L.get(name);
      return v ? { name, count: v.length, ids: v.filter((id) => app.doc.has(id)) } : { error: `No list ${name}` };
    },
  },
];

