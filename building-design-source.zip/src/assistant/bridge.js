/**
 * The page's end of the MCP bridge (mcp-bridge.mjs): tool calls from Claude
 * Code arrive as server-sent events, run on the open project exactly like the
 * assistant's own calls (one undo step each), and their results go back.
 */
import { runTool } from './tools.js';

/** Listen for bridged tool calls; onStep(name, input, result) after each; onReplaced when another page takes over. Returns a stop function. */
export function connectBridge(app, onStep, onReplaced) {
  if (typeof EventSource === 'undefined') return () => {};
  const events = new EventSource('./api/bridge');
  // Another page (a newer tab, or npm run headless) took the bridge: stop, so they do not alternate.
  events.addEventListener('replaced', () => {
    events.close();
    onReplaced?.();
  });
  events.addEventListener('call', async (ev) => {
    let call;
    try {
      call = JSON.parse(ev.data);
    } catch {
      return;
    }
    const result = await runTool(app, call.name, call.input);
    onStep?.(call.name, call.input, result);
    fetch('./api/bridge', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: call.id, result }) }).catch(() => {});
  });
  return () => events.close();
}
