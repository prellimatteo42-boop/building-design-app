/**
 * PDF pages as pictures for the assistant: each page drawn at 150 dpi (at
 * most 4000 pixels across), with its paper size, through io/pdfread.js.
 */
const MAX_PAGES = 3;

/** [{ page, src (PNG data URL), px: [w, h], pageMm: [w, h] }] for some pages (default the first three). */
export async function pdfPagePictures(source, pages = null) {
  const { openPDF } = await import('../io/pdfread.js');
  const bytes = source instanceof Uint8Array ? source : Uint8Array.from(atob(String(source).slice(String(source).indexOf(',') + 1)), (c) => c.charCodeAt(0));
  const pdf = await openPDF(bytes);
  try {
    const list = (pages || Array.from({ length: Math.min(MAX_PAGES, pdf.pages) }, (_, i) => i + 1)).filter((i) => i >= 1 && i <= pdf.pages);
    const out = [];
    for (const i of list) {
      const { canvas, widthMm, heightMm } = await pdf.render(i, { dpi: 150, maxEdge: 4000 });
      out.push({ page: i, src: canvas.toDataURL('image/png'), px: [canvas.width, canvas.height], pageMm: [widthMm, heightMm] });
    }
    return out;
  } finally {
    pdf.close();
  }
}
