/**
 * Assistant functions for project settings, as the tools Archicad gives an
 * AI: graphic override rules and combinations, classification systems and
 * items, the keynote catalogue, views with their settings and view
 * templates (presets of view options), and a search over attributes.
 */
import { isView, VIEW_LABEL } from '../core/doc.js';
import { CATEGORIES } from '../core/catalog.js';
import { FILTER_PARAMS, FILTER_OPS, overrideCombos, saveOverrideCombo, overrideComboPatch, applyTemplatePatch, templateKindOf } from '../core/graphics.js';
import { projectParams } from '../core/params.js';
import { classTree, classLabel } from '../core/classify.js';
import { keynotes, keynoteTree, editKeynotes, keynoteByKey } from '../core/keynotes.js';
import { PEN_SETS } from '../core/props.js';
import { SYSTEMS } from '../core/mep.js';
import { assignIds, idField } from '../core/idmanager.js';
import { mepNetworks, mepQuality, connectedMep } from '../core/mepnet.js';
import { fittingsFor } from '../core/mepfittings.js';
import { annualEnergy, CLIMATES, HEATING_SYSTEMS } from '../core/energysim.js';
import { simulateJunction, junctionBox, simulateSection, sectionJunctionBox } from '../core/thermalbridge.js';
import { physicalQuality, QUALITY_CHECKS } from '../core/modelquality.js';
import { parseIDS, checkIDS } from '../core/ids.js';
import { mergeWalls, mergeBeams, mergeColumns, consolidateLines } from '../core/merge.js';
import { checkLevel, applyEgress, RVITA } from '../core/egressmodel.js';
import { fireReport, fireReportMarkdown } from '../core/firereport.js';

const lc = (s) => String(s ?? '').toLowerCase();
const fuzzy = (q) => {
  const words = lc(q).split(/\s+/).filter(Boolean);
  return (text) => words.every((w) => lc(text).includes(w));
};
const byName = (list, name) => list.find((x) => lc(x.name) === lc(name)) || null;

function findView(doc, name) {
  const views = doc.filter(isView);
  return views.find((v) => lc(v.name) === lc(name)) || views.find((v) => lc(v.name).includes(lc(name))) || null;
}

function viewOf(app, name) {
  const v = name ? findView(app.doc, name) : app.activeView;
  if (!v) throw new Error(name ? `No view named "${name}"` : 'No active view');
  return v;
}

/** A rule's criterion parameter: a built-in filter parameter or a custom property (by name). */
function criterionParam(doc, param) {
  if (FILTER_PARAMS.some((p) => p.value === param)) return param;
  const p = FILTER_PARAMS.find((x) => lc(x.label) === lc(param));
  if (p) return p.value;
  const cp = projectParams(doc).find((x) => lc(x.name) === lc(param));
  if (cp) return cp.id;
  throw new Error(`Unknown criterion ${param}; use one of ${FILTER_PARAMS.map((x) => x.value).join(', ')} or a custom property name`);
}

const paramName = (doc, param) => FILTER_PARAMS.find((x) => x.value === param)?.value ?? doc.get(param)?.name ?? param;

function describeRule(doc, f) {
  return { name: f.name, categories: f.categories || [], criteria: (f.rules || []).map((r) => ({ param: paramName(doc, r.param), op: r.op, value: r.value })) };
}

function describeEntries(doc, filters) {
  return (filters || []).filter((f) => doc.has(f.id)).map((f) => ({ rule: doc.get(f.id).name, visible: f.visible !== false, ...(f.override || {}) }));
}

const STYLE = { visible: { type: 'boolean' }, color: { type: 'string', description: '#rrggbb' }, weight: { type: 'integer', description: 'Line weight 1 (fine) to 5 (heavy)' }, halftone: { type: 'boolean' }, transparency: { type: 'number', description: '0-100' } };

function entryFor(doc, e) {
  const def = byName(doc.all('viewFilter'), e.rule);
  if (!def) throw new Error(`No graphic override rule ${e.rule}`);
  const override = {};
  for (const k of ['color', 'halftone', 'transparency']) if (e[k] !== undefined) override[k] = e[k];
  if (e.weight !== undefined && e.weight !== null) override.weight = Math.max(1, Math.min(5, Math.round(+e.weight)));
  if (override.transparency !== undefined) override.transparency = Math.max(0, Math.min(100, +override.transparency));
  return { id: def.id, visible: e.visible !== false, override };
}

/** The layered "attributes" of the project, as Archicad lists them. */
function attributes(doc) {
  const named = (kind, type) => doc.all(kind).map((x) => ({ type, name: x.name }));
  const composites = doc.filter((x) => /^(wall|floor|roof|ceiling)Type$/.test(x.kind) && x.layers?.length).map((x) => ({ type: 'composite', name: x.name, element: x.kind.replace('Type', ''), layers: x.layers.map((l) => `${doc.get(l.materialId)?.name ?? l.function ?? 'layer'} ${l.thickness} mm`) }));
  return [
    ...named('layer', 'layer'),
    ...named('layerCombo', 'layer_combination'),
    ...named('lineStyle', 'line_type'),
    ...named('fillType', 'fill_type'),
    ...composites,
    ...doc.all('material').map((m) => ({ type: 'building_material', name: m.name, ...(m.class ? { class: m.class } : {}) })),
    ...named('profile', 'profile'),
    ...named('zoneCategory', 'zone_category'),
    ...PEN_SETS.map((p) => ({ type: 'pen_table', name: p.label ?? p.name ?? p.value })),
    ...Object.entries(SYSTEMS).flatMap(([k, list]) => list.map((s) => ({ type: 'mep_system', name: s.label, domain: k }))),
  ];
}

const ATTR_TYPES = ['layer', 'layer_combination', 'line_type', 'fill_type', 'composite', 'building_material', 'profile', 'zone_category', 'pen_table', 'mep_system'];

export const DOC_TOOLS = [
  {
    name: 'graphic_overrides',
    description: `Graphic override rules (view filters: categories plus criteria) and how views use them, as Archicad's Graphic Override Combinations. Actions: search_rules, create_rules, modify_rules, delete_rules, get_view (the ordered rules of a view with their style), set_view (replace them; later rules win), search_combinations, save_combination (from a view), apply_combination (to views). Criteria ops: ${FILTER_OPS.map((o) => o.value).join(', ')}; params: ${FILTER_PARAMS.map((p) => p.value).join(', ')} or a custom property name. Categories: ${CATEGORIES.filter((c) => c.model).slice(0, 10).map((c) => c.id).join(', ')}, ...`,
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['search_rules', 'create_rules', 'modify_rules', 'delete_rules', 'get_view', 'set_view', 'search_combinations', 'save_combination', 'apply_combination'] },
        query: { type: 'string' },
        rules: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, new_name: { type: 'string' }, categories: { type: 'array', items: { type: 'string' } }, criteria: { type: 'array', items: { type: 'object', properties: { param: { type: 'string' }, op: { type: 'string' }, value: { type: 'string' } }, required: ['param', 'op'] } } }, required: ['name'] } },
        view: { type: 'string', description: 'View name (default: the active view)' },
        views: { type: 'array', items: { type: 'string' }, description: 'apply_combination: views (default: the active view)' },
        entries: { type: 'array', description: 'set_view: [{ rule, visible, color, weight, halftone, transparency }]', items: { type: 'object', properties: { rule: { type: 'string' }, ...STYLE }, required: ['rule'] } },
        combination: { type: 'string' },
      },
      required: ['action'],
    },
    run(app, input) {
      const doc = app.doc;
      const { action, query } = input;
      const filters = () => doc.all('viewFilter');
      if (action === 'search_rules') return { rules: filters().filter((f) => fuzzy(query)(f.name)).map((f) => describeRule(doc, f)) };
      if (action === 'search_combinations') return { combinations: overrideCombos(doc).filter((c) => fuzzy(query)(c.name)).map((c) => ({ name: c.name, entries: describeEntries(doc, c.filters) })) };
      if (action === 'get_view') {
        const v = viewOf(app, input.view);
        return { view: v.name, combination: v.overrideCombo ?? null, entries: describeEntries(doc, v.filters) };
      }
      const done = [];
      const errors = [];
      app.commit(`Assistant: graphic overrides (${action})`, () => {
        if (action === 'create_rules' || action === 'modify_rules' || action === 'delete_rules') {
          for (const r of input.rules || []) {
            try {
              const cur = byName(filters(), r.name);
              if (action === 'create_rules') {
                if (cur) throw new Error('A rule with this name exists');
                const cats = (r.categories || []).map((c) => CATEGORIES.find((x) => x.id === c || lc(x.label) === lc(c))?.id ?? c);
                for (const c of cats) if (!CATEGORIES.some((x) => x.id === c)) throw new Error(`Unknown category ${c}`);
                doc.add({ kind: 'viewFilter', name: r.name, categories: cats, rules: (r.criteria || []).map((c) => ({ param: criterionParam(doc, c.param), op: c.op, value: c.value ?? '' })) });
              } else if (!cur) throw new Error('No such rule');
              else if (action === 'delete_rules') {
                doc.remove(cur.id);
                for (const v of doc.filter(isView)) if (v.filters?.some((f) => f.id === cur.id)) doc.update(v.id, { filters: v.filters.filter((f) => f.id !== cur.id) });
              } else {
                const patch = {};
                if (r.new_name) patch.name = r.new_name;
                if (r.categories) patch.categories = r.categories;
                if (r.criteria) patch.rules = r.criteria.map((c) => ({ param: criterionParam(doc, c.param), op: c.op, value: c.value ?? '' }));
                doc.update(cur.id, patch);
              }
              for (const c of r.criteria || []) if (!FILTER_OPS.some((o) => o.value === c.op)) throw new Error(`Unknown op ${c.op}`);
              done.push(r.new_name || r.name);
            } catch (err) {
              errors.push({ rule: r.name, error: err.message });
            }
          }
          return;
        }
        try {
          if (action === 'set_view') {
            const v = viewOf(app, input.view);
            doc.update(v.id, { filters: (input.entries || []).map((e) => entryFor(doc, e)), overrideCombo: null });
            done.push(v.name);
          } else if (action === 'save_combination') {
            if (!input.combination) throw new Error('Give the combination a name');
            const v = viewOf(app, input.view);
            saveOverrideCombo(doc, input.combination, v.filters);
            doc.update(v.id, { overrideCombo: input.combination });
            done.push(input.combination);
          } else if (action === 'apply_combination') {
            const patch = overrideComboPatch(doc, input.combination);
            if (!patch) throw new Error(`No combination ${input.combination}`);
            const vs = input.views?.length ? input.views.map((n) => viewOf(app, n)) : [viewOf(app)];
            for (const v of vs) (doc.update(v.id, patch), done.push(v.name));
          } else throw new Error(`Unknown action ${action}`);
        } catch (err) {
          errors.push({ error: err.message });
        }
      });
      return { success: !errors.length, done, ...(errors.length ? { errors } : {}) };
    },
  },
  {
    name: 'classifications',
    description: 'Manage classification systems and their items (as Archicad\'s Classification Manager): search_systems, create_system, modify_system, delete_system, create_items, modify_item, delete_items. Items have a code, a name, an optional parent code and IFC entity. To give elements an item use classify_elements.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['search_systems', 'create_system', 'modify_system', 'delete_system', 'create_items', 'modify_item', 'delete_items'] },
        query: { type: 'string' },
        system: { type: 'string', description: 'System name' },
        new_name: { type: 'string' },
        edition: { type: 'string', description: 'Version or edition of the system' },
        items: { type: 'array', items: { type: 'object', properties: { code: { type: 'string' }, new_code: { type: 'string' }, name: { type: 'string' }, parent: { type: 'string' }, ifc: { type: 'string' } }, required: ['code'] } },
      },
      required: ['action'],
    },
    run(app, input) {
      const doc = app.doc;
      const systems = doc.all('classSystem');
      const { action } = input;
      if (action === 'search_systems') return { systems: systems.filter((s) => fuzzy(input.query)(s.name)).map((s) => ({ name: s.name, edition: s.edition || '', items: s.items.length, top: classTree(s).filter((t) => t.depth === 0).slice(0, 20).map((t) => classLabel(t.item)) })) };
      if (action === 'create_system') {
        if (!input.system) return { error: 'Give the system a name' };
        if (byName(systems, input.system)) return { error: 'A system with this name exists' };
        app.commit('Assistant: new classification system', () => doc.add({ kind: 'classSystem', name: input.system, edition: input.edition || '1.0', items: [] }));
        return { success: true, created: input.system };
      }
      const sys = byName(systems, input.system) || (input.system ? systems.find((s) => lc(s.name).includes(lc(input.system))) : systems[0]);
      if (!sys) return { error: `No classification system ${input.system ?? ''}` };
      if (action === 'modify_system') {
        app.commit('Assistant: edit classification system', () => doc.update(sys.id, { ...(input.new_name ? { name: input.new_name } : {}), ...(input.edition ? { edition: input.edition } : {}) }));
        return { success: true, system: doc.get(sys.id).name };
      }
      if (action === 'delete_system') {
        if (systems.length === 1) return { error: 'The project needs at least one classification system' };
        app.commit('Assistant: delete classification system', () => {
          for (const el of doc.items.values())
            if (el.classes && sys.id in el.classes) {
              const { [sys.id]: _drop, ...rest } = el.classes;
              void _drop;
              doc.update(el.id, { classes: rest });
            }
          doc.remove(sys.id);
        });
        return { success: true, deleted: sys.name };
      }
      let items = sys.items.map((i) => ({ ...i }));
      const errors = [];
      const done = [];
      for (const q of input.items || []) {
        const code = String(q.code).trim();
        const cur = items.find((i) => i.code === code);
        if (action === 'create_items') {
          if (!code) errors.push({ code, error: 'An item needs a code' });
          else if (cur) errors.push({ code, error: 'The code is taken' });
          else if (q.parent && !items.some((i) => i.code === q.parent)) errors.push({ code, error: `No parent ${q.parent}` });
          else (items.push({ code, name: q.name || code, parent: q.parent || null, ifc: q.ifc || null, kinds: [], cats: [] }), done.push(code));
        } else if (!cur) errors.push({ code, error: 'No such item' });
        else if (action === 'delete_items') {
          if (items.some((i) => i.parent === code)) errors.push({ code, error: 'The item has items under it' });
          else (items = items.filter((i) => i !== cur), done.push(code));
        } else {
          if (q.new_code && q.new_code !== code) {
            if (items.some((i) => i.code === q.new_code)) {
              errors.push({ code, error: `Code ${q.new_code} is taken` });
              continue;
            }
            for (const i of items) if (i.parent === code) i.parent = q.new_code;
            cur.code = q.new_code;
          }
          if (q.name !== undefined) cur.name = q.name;
          if (q.parent !== undefined) cur.parent = q.parent || null;
          if (q.ifc !== undefined) cur.ifc = q.ifc || null;
          done.push(cur.code);
        }
      }
      if (done.length)
        app.commit('Assistant: classification items', () => {
          doc.update(sys.id, { items });
          // Elements classified with a renamed or removed code follow it.
          const renamed = new Map((input.items || []).filter((q) => q.new_code && done.includes(q.new_code)).map((q) => [q.code, q.new_code]));
          for (const el of doc.items.values()) {
            const c = el.classes?.[sys.id];
            if (c === undefined || c === '') continue;
            if (renamed.has(c)) doc.update(el.id, { classes: { ...el.classes, [sys.id]: renamed.get(c) } });
            else if (action === 'delete_items' && !items.some((i) => i.code === c)) {
              const { [sys.id]: _drop, ...rest } = el.classes;
              void _drop;
              doc.update(el.id, { classes: rest });
            }
          }
        });
      return { success: !errors.length, system: sys.name, done, ...(errors.length ? { errors } : {}) };
    },
  },
  {
    name: 'keynotes',
    description: 'The keynote catalogue (as Archicad\'s Keynote Manager): search keynotes and folders, create, modify or delete them (folder: true for folders; parent is a folder key), and assign a keynote key to elements or to their types so keynote tags show it.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['search', 'create', 'modify', 'delete', 'assign'] },
        query: { type: 'string' },
        entries: { type: 'array', items: { type: 'object', properties: { key: { type: 'string' }, new_key: { type: 'string' }, title: { type: 'string' }, description: { type: 'string' }, parent: { type: 'string' }, folder: { type: 'boolean' } } } },
        key: { type: 'string', description: 'assign: the keynote key (empty removes it)' },
        ids: { type: 'array', items: { type: 'string' }, description: 'assign: elements (default: the selection)' },
        to_type: { type: 'boolean', description: 'assign: put the key on the elements\' types instead' },
      },
      required: ['action'],
    },
    run(app, input) {
      const doc = app.doc;
      const { action } = input;
      if (action === 'search') {
        const m = fuzzy(input.query);
        return { entries: keynoteTree(keynotes(doc)).filter(({ item }) => m(`${item.key} ${item.title} ${item.description}`)).slice(0, 200).map(({ item, depth }) => ({ key: item.key, title: item.title, ...(item.description ? { description: item.description } : {}), folder: !!item.folder, parent: item.parent, depth })) };
      }
      if (action === 'assign') {
        const key = String(input.key ?? '');
        if (key && !keynoteByKey(doc, key)) return { error: `No keynote ${key} in the catalogue` };
        const els = (input.ids?.length ? input.ids : [...(app.selection || [])]).map((id) => doc.get(id)).filter(Boolean);
        if (!els.length) return { error: 'No elements: give ids or select them' };
        const targets = new Set(els.map((el) => (input.to_type && el.typeId ? el.typeId : el.id)));
        app.commit('Assistant: assign keynote', () => targets.forEach((id) => doc.update(id, { keynote: key })));
        return { success: true, assigned: targets.size, key, title: keynoteByKey(doc, key)?.title ?? '' };
      }
      const op = { create: 'add', modify: 'modify', delete: 'delete' }[action];
      try {
        const next = editKeynotes(keynotes(doc), (input.entries || []).map((e) => ({ op, ...e })));
        app.commit('Assistant: keynotes', () => doc.update('project', { keynotes: next }));
        return { success: true, count: next.length };
      } catch (err) {
        return { success: false, error: err.message };
      }
    },
  },
  {
    name: 'views',
    description: 'Search views, sheets and schedules like Archicad\'s Navigator (by name and kind), read their settings (scale, detail level, template, phase, layer combination, override rules), list view templates (presets of view options) and apply one to views.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['search', 'settings', 'search_templates', 'apply_template'] },
        query: { type: 'string' },
        kind: { type: 'string', description: 'plan, ceilingPlan, elevation, section, view3d, drafting, legend, schedule, sheet, ...' },
        views: { type: 'array', items: { type: 'string' }, description: 'View names (default: the active view)' },
        template: { type: 'string' },
      },
      required: ['action'],
    },
    run(app, input) {
      const doc = app.doc;
      const { action } = input;
      const m = fuzzy(input.query);
      if (action === 'search') {
        const vs = doc.filter(isView).filter((v) => !v.kind.endsWith('Template') && (!input.kind || v.kind === input.kind) && m(v.name));
        return { count: vs.length, views: vs.slice(0, 200).map((v) => ({ name: v.name, kind: v.kind, label: VIEW_LABEL[v.kind] || v.kind, ...(v.levelId ? { level: doc.get(v.levelId)?.name } : {}), active: v.id === app.activeView?.id })) };
      }
      const templates = doc.all('viewTemplate');
      if (action === 'search_templates') return { templates: templates.filter((t) => m(t.name)).map((t) => ({ name: t.name, for: t.viewKind, settings: Object.keys(t.settings || {}), used_by: doc.filter((v) => v.templateId === t.id).length })) };
      const vs = input.views?.length ? input.views.map((n) => viewOf(app, n)) : [viewOf(app)];
      if (action === 'settings')
        return {
          views: vs.map((v) => ({
            name: v.name,
            kind: v.kind,
            ...(v.scale ? { scale: `1:${v.scale}` } : {}),
            ...(v.detail ? { detail: v.detail } : {}),
            ...(v.style ? { style: v.style } : {}),
            template: doc.get(v.templateId)?.name ?? null,
            phase: doc.get(v.phaseId)?.name ?? null,
            phase_filter: v.phaseFilter || 'all',
            layer_combination: doc.get(v.layerComboId)?.name ?? null,
            ...(v.cutHeight != null ? { cut_height: v.cutHeight } : {}),
            ...(v.viewDepth != null ? { view_depth: v.viewDepth } : {}),
            hidden_categories: v.hiddenCats || [],
            override_rules: describeEntries(doc, v.filters),
            ...(v.overrideCombo ? { override_combination: v.overrideCombo } : {}),
          })),
        };
      const tpl = byName(templates, input.template) || templates.find((t) => lc(t.name).includes(lc(input.template)));
      if (!tpl) return { error: `No view template ${input.template ?? ''}` };
      const bad = vs.filter((v) => tpl.viewKind && templateKindOf(v.kind) !== tpl.viewKind);
      if (bad.length) return { error: `${tpl.name} is for ${tpl.viewKind} views, not ${bad.map((v) => v.name).join(', ')}` };
      app.commit('Assistant: apply view template', () => vs.forEach((v) => doc.update(v.id, applyTemplatePatch(tpl))));
      return { success: true, template: tpl.name, views: vs.map((v) => v.name) };
    },
  },
  {
    name: 'attribute_search',
    description: `Search the project's attributes by name (as Archicad's attributes): ${ATTR_TYPES.join(', ')}. Composites list their layers.`,
    parameters: { type: 'object', properties: { query: { type: 'string' }, type: { type: 'string', enum: ATTR_TYPES } } },
    run(app, { query, type }) {
      const m = fuzzy(query);
      const all = attributes(app.doc).filter((a) => (!type || a.type === type) && m(a.name));
      return { total_count: all.length, attributes: all.slice(0, 150) };
    },
  },
];

DOC_TOOLS.push({
  name: 'assign_ids',
  description: 'Element ID Manager: give elements new IDs in one go (rooms, areas and spaces their number, others their mark), ordered by level and by place in plan: prefix + level code + separator + counter with leading zeros + suffix, e.g. D1.03. Elements: ids, else the selection, else all of `kind`. With preview true nothing changes.',
  parameters: {
    type: 'object',
    properties: {
      ids: { type: 'array', items: { type: 'string' } },
      kind: { type: 'string' },
      prefix: { type: 'string' },
      suffix: { type: 'string' },
      level_code: { type: 'string', enum: ['none', 'index', 'name'] },
      separator: { type: 'string' },
      start: { type: 'integer' },
      step: { type: 'integer' },
      digits: { type: 'integer' },
      order: { type: 'string', enum: ['rows', 'columns', 'current', 'given'] },
      restart_per_level: { type: 'boolean' },
      per_kind: { type: 'boolean' },
      preview: { type: 'boolean' },
    },
  },
  run(app, i) {
    const doc = app.doc;
    let els = (i.ids?.length ? i.ids : [...(app.selection || [])]).map((id) => doc.get(id)).filter(Boolean);
    if (!els.length && i.kind) els = doc.all(i.kind);
    if (!els.length) return { error: 'No elements: give ids, a kind, or select them' };
    const ids = assignIds(doc, els, { prefix: i.prefix ?? '', suffix: i.suffix ?? '', levelCode: i.level_code ?? 'none', separator: i.separator ?? '', start: i.start ?? 1, step: i.step ?? 1, digits: i.digits ?? 0, order: i.order ?? 'rows', restartPerLevel: i.restart_per_level ?? true, perKind: i.per_kind ?? false });
    if (!i.preview) app.commit('Assistant: assign IDs', () => ids.forEach((v, id) => doc.update(id, { [idField(doc.get(id))]: v })));
    return { [i.preview ? 'would_assign' : 'assigned']: [...ids].slice(0, 200).map(([id, v]) => ({ id, kind: doc.get(id).kind, id_value: v })) };
  },
});

DOC_TOOLS.push({
  name: 'mep_networks',
  description: 'MEP systems (as Archicad\'s MEP System Browser and MEP Model Quality, and its routing fittings): create_fittings makes elbows, tees, crosses, transitions and branches where runs meet (replacing those made before); list the networks of ducts, pipes, cable trays and conduits (system, runs, terminals, length in m, open ends), list problems (open connections, size or system changes at joints, overlapping runs, sanitary pipes without fall), or select every element connected to the given ones.',
  parameters: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'quality', 'select_connected', 'create_fittings', 'remove_fittings'] }, ids: { type: 'array', items: { type: 'string' } } }, required: ['action'] },
  run(app, { action, ids }) {
    const doc = app.doc;
    if (action === 'list') return { networks: mepNetworks(doc).map((n, i) => ({ network: i + 1, kind: n.kind, system: n.system, runs: n.runs.length, terminals: n.terminals.length, length_m: Math.round(n.length) / 1000, open_ends: n.openEnds.length, ids: n.runs.slice(0, 50) })) };
    if (action === 'quality') {
      const q = mepQuality(doc);
      return { count: q.length, issues: q.slice(0, 100).map((i) => ({ kind: i.kind, message: i.message, ids: i.ids })) };
    }
    if (action === 'create_fittings' || action === 'remove_fittings') {
      const made = action === 'create_fittings' ? fittingsFor(doc) : [];
      const old = doc.all('mepFitting').filter((f) => f.auto || action === 'remove_fittings');
      app.commit(`Assistant: ${action.replace('_', ' ')}`, () => {
        for (const f of old) doc.remove(f.id);
        for (const f of made) doc.add(f);
      });
      const by = {};
      for (const f of made) by[f.fittingType] = (by[f.fittingType] || 0) + 1;
      return { removed: old.length, created: made.length, by_type: by };
    }
    const sel = connectedMep(doc, ids?.length ? ids : [...(app.selection || [])]);
    if (!sel.size) return { error: 'Give the id of a run or terminal, or select one' };
    app.showElements([...sel]);
    return { selected: sel.size };
  },
});

DOC_TOOLS.push({
  name: 'energy_evaluation',
  description: 'Energy Evaluation (as Archicad\'s): the annual heating and cooling needs month by month (kWh), delivered energy by source, non-renewable primary energy, CO₂ and cost, with the climate and systems used; the design heat loss of each zone; or the Energy Model Review (envelope parts with area, U-value and facing). Settings can be changed: climate (a listed city), heating_system, set points, internal gains, thermal mass, method (monthly or hourly simulation with peak loads and overheating hours), ventilation (natural, mechanical, mvhr with heat recovery), hot water need, solar thermal m², photovoltaic kWp. Thermal blocks are reported with their own needs.',
  parameters: {
    type: 'object',
    properties: {
      report: { type: 'string', enum: ['annual', 'heat_loss', 'review'] },
      settings: { type: 'object', properties: { climate: { type: 'string', enum: CLIMATES.map((c) => c.name) }, heating_system: { type: 'string', enum: HEATING_SYSTEMS.map((s) => s.value) }, inside: { type: 'number' }, cooling: { type: 'number' }, internal_gains: { type: 'number' }, mass: { type: 'string', enum: ['light', 'medium', 'heavy'] }, method: { type: 'string', enum: ['monthly', 'hourly'] }, ventilation: { type: 'string', enum: ['natural', 'mechanical', 'mvhr'] }, heat_recovery: { type: 'number' }, dhw_kwh_m2: { type: 'number' }, solar_thermal_m2: { type: 'number' }, pv_kwp: { type: 'number' }, cooled: { type: 'boolean' } } },
    },
    required: ['report'],
  },
  run(app, { report, settings }) {
    const doc = app.doc;
    if (settings && Object.keys(settings).length) {
      const cur = doc.get('project')?.energy || {};
      const patch = { ...cur };
      if (settings.climate) patch.climate = CLIMATES.find((c) => c.name === settings.climate) || cur.climate;
      if (settings.heating_system) (patch.heatingSystem = settings.heating_system), delete patch.heatingEfficiency;
      for (const [k, v] of [['inside', settings.inside], ['cooling', settings.cooling], ['internalGains', settings.internal_gains], ['mass', settings.mass], ['method', settings.method], ['coolingOn', settings.cooled], ['solarThermal', settings.solar_thermal_m2]]) if (v !== undefined) patch[k] = v;
      if (settings.ventilation || settings.heat_recovery != null) patch.ventilation = { ...(cur.ventilation || {}), ...(settings.ventilation ? { type: settings.ventilation } : {}), ...(settings.heat_recovery != null ? { recovery: settings.heat_recovery } : {}) };
      if (settings.dhw_kwh_m2 != null) patch.dhw = { ...(cur.dhw || {}), demand: settings.dhw_kwh_m2 };
      if (settings.pv_kwp != null) patch.pv = { ...(cur.pv || {}), kwp: settings.pv_kwp };
      app.commit('Assistant: energy settings', () => doc.update('project', { energy: patch }));
    }
    const r = annualEnergy(doc, app.scene);
    if (!r.report.rows.length) return { error: 'No enclosed rooms (zones) to evaluate' };
    const rd = (v) => Math.round(v * 10) / 10;
    if (report === 'heat_loss') return { zones: r.report.rows.map((z) => ({ zone: `${z.room.number ?? ''} ${z.room.name ?? ''}`.trim(), area_m2: rd(z.area), HT: rd(z.HT), HV: rd(z.HV), load_W: Math.round(z.load), W_per_m2: rd(z.perArea), notes: z.notes })), totals: { area_m2: rd(r.report.totals.area), load_W: Math.round(r.report.totals.load) } };
    if (report === 'review') return { parts: r.report.rows.flatMap((z) => (z.faces || []).map((f) => ({ zone: z.room.name, part: f.kind, structure: f.name, area_m2: rd(f.area), U: Math.round(f.u * 100) / 100, facing_deg: f.azimuth == null ? null : Math.round(f.azimuth), g: f.g || undefined, id: f.id }))).slice(0, 200) };
    const a = r.annual;
    return { climate: r.climate.name, heating_system: r.settings.heatingSystem, floor_area_m2: rd(r.area), heating_kWh: Math.round(a.heating), cooling_kWh: Math.round(a.cooling), heating_kWh_m2: rd(a.heatingPerArea), cooling_kWh_m2: rd(a.coolingPerArea), delivered_kWh: Object.fromEntries(Object.entries(a.delivered).map(([k, v]) => [k, Math.round(v)])), primary_kWh: Math.round(a.primary), primary_kWh_m2: rd(a.primaryPerArea), co2_kg: Math.round(a.co2), cost: Math.round(a.cost), method: r.method, peak_heating_W: a.peakHeating == null ? undefined : Math.round(a.peakHeating), peak_cooling_W: a.peakCooling == null ? undefined : Math.round(a.peakCooling), overheating_hours: a.overheatingHours ?? undefined, dhw_kWh: Math.round(a.dhw) || undefined, fans_kWh: Math.round(a.fans) || undefined, pv_kWh: Math.round(a.pv) || undefined, solar_thermal_kWh: Math.round(a.solarThermal) || undefined, renewable_share: a.renewableShare ? rd(a.renewableShare * 100) : undefined, blocks: r.blocks.length > 1 ? r.blocks.map((b) => ({ block: b.name, area_m2: rd(b.area), heating_kWh: Math.round(b.result.heating), cooling_kWh: Math.round(b.result.cooling) })) : undefined, months: r.months.map((m) => ({ month: m.month, te: m.te, heating: Math.round(m.heating), cooling: Math.round(m.cooling), solar: Math.round(m.solar) })) };
  },
});

DOC_TOOLS.push({
  name: 'thermal_bridge',
  description: 'Thermal Bridge Simulation (EN ISO 10211, in plan): the junction of the given walls and columns (default: the selection) solved in 2D from their layers\' thermal conductivity. Returns heat flow Q (W/m), L2D, ψ with interior and exterior dimensions (W/mK), lowest interior surface temperature and fRsi (below 0.75: mould risk).',
  parameters: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' } }, section: { type: 'string', description: 'Name of a section view: solve the junction (walls, slabs, columns) as cut there instead of in plan' }, inside: { type: 'number' }, outside: { type: 'number' }, cell: { type: 'number', description: 'Cell size in mm (default 10)' } } },
  run(app, { ids, section, inside, outside, cell }) {
    const doc = app.doc;
    const view = section ? doc.all('section').find((v) => v.name.toLowerCase() === String(section).toLowerCase()) : null;
    if (section && !view) return { error: `No section named ${section}` };
    const list = (ids?.length ? ids : [...(app.selection || [])]).filter((id) => (view ? ['wall', 'column', 'floor'] : ['wall', 'column']).includes(doc.get(id)?.kind));
    const box = list.length && (view ? sectionJunctionBox(doc, app.scene, view, list) : junctionBox(doc, app.scene, list));
    if (!box) return { error: view ? 'Those elements are not cut by the section' : 'Give the ids of the walls (and columns) that meet, or select them' };
    const run = (o) => (view ? simulateSection(doc, app.scene, view, box, o) : simulateJunction(doc, app.scene, box.levelId, box, o));
    const r = run({ ...doc.get('project')?.thermalBridge, ...(inside != null ? { inside } : {}), ...(outside != null ? { outside } : {}), ...(cell ? { cell } : {}) });
    if (r.error) return r;
    const r3 = (v) => (v == null ? null : Math.round(v * 1000) / 1000);
    return { Q_W_per_m: r3(r.Q), L2D: r3(r.L2D), psi_interior: r3(r.psiI), psi_exterior: r3(r.psiE), theta_si_min: r3(r.thetaSiMin), fRsi: r3(r.fRsi), flanking: r.flanking.map((f) => ({ wall: f.name, U: r3(f.u), l_inside_m: r3(f.lIn), l_outside_m: r3(f.lOut) })), notes: r.notes };
  },
});

DOC_TOOLS.push({
  name: 'physical_model_quality',
  description: 'Physical Model Quality (as Archicad\'s check): elements of one kind in the same place, elements too small, wall ends that nearly meet another wall without being joined, walls and beams that stop short of the slab above, walls and columns with nothing under them. Each problem lists its element ids.',
  parameters: { type: 'object', properties: { checks: { type: 'array', items: { type: 'string', enum: QUALITY_CHECKS.map((c) => c.id) } } } },
  run(app, { checks }) {
    const all = physicalQuality(app.doc, app.scene).filter((x) => !checks?.length || checks.includes(x.check));
    return { count: all.length, problems: all.slice(0, 150).map((x) => ({ check: x.check, message: x.message, ids: x.ids })) };
  },
});

DOC_TOOLS.push({
  name: 'ids_check',
  description: 'Check the model against a buildingSMART IDS file (Information Delivery Specification 1.0) as it would export to IFC: for each specification, how many elements it applies to, which pass, and which fail with the reasons. Give the .ids path (through Claude Code) or its text.',
  parameters: { type: 'object', properties: { path: { type: 'string', description: 'Absolute path of the .ids file on this computer' }, ids_text: { type: 'string', description: 'The IDS XML itself' }, select_failing: { type: 'boolean' } } },
  run(app, { ids_text, select_failing }) {
    if (!ids_text) return { error: 'Give the IDS file path (through Claude Code) or its XML text' };
    const ids = parseIDS(ids_text);
    const r = checkIDS(app.doc, ids);
    const failing = r.specifications.flatMap((s) => [...s.failed.map((f) => f.id), ...s.prohibited]);
    if (select_failing && failing.length) app.showElements(failing);
    app.lastIDS = { name: ids.title, ids };
    return { title: r.title, ok: r.ok, specifications: r.specifications.map((s) => ({ name: s.name, use: s.use, ok: s.ok, applicable: s.applicable, passed: s.passed, failed: s.failed.length + s.prohibited.length, note: s.note || undefined, examples: s.failed.slice(0, 8).map((f) => ({ id: f.id, entity: f.entity, name: f.name, reasons: f.reasons })) })) };
  },
});

DOC_TOOLS.push({
  name: 'cleanup_model',
  description: 'Clean up a model brought in from DWG or PDF (as Archicad\'s Merge Walls/Beams/Columns and Linework Consolidation): merge walls or beams in line that touch or overlap with the same settings (doors and windows stay in place), merge columns stacked through levels, or remove doubled and empty detail lines and join pieces of one line in a view. Works on the given ids, else on all.',
  parameters: { type: 'object', properties: { action: { type: 'string', enum: ['merge_walls', 'merge_beams', 'merge_columns', 'consolidate_lines'] }, ids: { type: 'array', items: { type: 'string' } }, view: { type: 'string', description: 'consolidate_lines: view name (default the active view)' } }, required: ['action'] },
  run(app, { action, ids, view }) {
    const doc = app.doc;
    const only = ids?.length ? ids : null;
    if (action === 'consolidate_lines') {
      const v = view ? viewOf(app, view) : app.activeView;
      if (!v) return { error: 'No view' };
      let r;
      app.commit('Assistant: linework consolidation', () => (r = consolidateLines(doc, { viewId: v.id, ids: only })));
      return { view: v.name, ...r };
    }
    let n = 0;
    app.commit(`Assistant: ${action.replace('_', ' ')}`, () => (n = action === 'merge_walls' ? mergeWalls(doc, only) : action === 'merge_beams' ? mergeBeams(doc, only) : mergeColumns(doc, only)));
    return { removed: n };
  },
});

DOC_TOOLS.push({
  name: 'escape_check',
  description: `Escape check after the Italian fire code (D.M. 3 agosto 2015, S.4) on a level: for every zone its occupants, longest way out (lunghezza d'esodo) and dead end (corridoio cieco) against the limits of the risk profile (Rvita: ${Object.keys(RVITA).join(', ')}; hotels and hostels Ciii2), and every exit with the occupants it takes and the width they need. Exits on the lowest level are the doors and openings that lead outside; above, doors marked as exits (exit) or leading onto a stair marked external. Zones count their beds, else occupants by use. draw: true draws each zone's way out on the level's plan and keeps the results on the zones (for a room schedule).`,
  parameters: { type: 'object', properties: { level: { type: 'string' }, profile: { type: 'string' }, draw: { type: 'boolean' } } },
  run(app, { level, profile = 'Ciii2', draw = false }) {
    const doc = app.doc;
    const lv = level ? doc.levels().find((l) => l.name === level || l.id === level) : doc.get(app.activeLevelId());
    if (!lv) return { error: `No level ${level}` };
    if (!RVITA[profile]) return { error: `Unknown profile; use one of ${Object.keys(RVITA).join(', ')}` };
    const r = checkLevel(doc, app.scene, lv.id, profile);
    if (draw) app.commit('Assistant: escape check', () => applyEgress(doc, r, doc.all('plan').find((v) => v.levelId === lv.id)));
    const m = (v) => (Number.isFinite(v) ? Math.round(v * 10) / 10 : 'no way out');
    return {
      level: lv.name,
      profile,
      limits: { longest_way_out_m: r.limits.les, dead_end_m: r.limits.lcc, unit_width_mm_per_person: r.limits.unit },
      compliant: r.ok,
      zones: r.rooms.map((x) => ({ zone: x.name, occupants: x.occupants, longest_way_out_m: m(x.les), dead_end_m: m(x.lcc), ok: x.ok })),
      exits: r.exits.map((e) => ({ exit: e.name, occupants: e.occupants, width_mm: e.width, needed_mm: e.required, ok: e.ok })),
    };
  },
});

DOC_TOOLS.push({
  name: 'fire_report',
  description: `Fire safety technical report after the Italian fire code (D.M. 3 agosto 2015): the activity classified from the model (beds → PA..PE, floor height → HA..HE, area types TA..TZ of each zone), performance levels of the ten measures S.1-S.10 with their criteria (V.5 for accommodation over 25 beds), and checks on the model: escape per level, escape stairs (tables S.4-29/30), reach of extinguishers (table S.6-5), detectors in every zone, protected enclosure of kitchens, laundries, technical rooms and stores (table V.5-2), fire ratings against table V.5-1, smoke outlets A/40. Returns the summary and the failed checks; markdown: true returns the whole report text (Italian). Zones count their beds (beds), occupants, and fireArea (TA..TZ) when set; equipment is recognised from component names (extinguisher, hose reel, detector, call point, exit sign).`,
  parameters: { type: 'object', properties: { profile: { type: 'string', description: 'Reference Rvita (default the project escape profile or Ciii2)' }, rbeni: { type: 'number' }, activity: { type: 'string', enum: ['auto', 'V.5', 'RTO'] }, markdown: { type: 'boolean' } } },
  run(app, { profile, rbeni = 1, activity = 'auto', markdown = false }) {
    if (profile && !RVITA[profile]) return { error: `Unknown profile; use one of ${Object.keys(RVITA).join(', ')}` };
    const rep = fireReport(app.doc, app.scene, { profile, rbeni, activity });
    const d = rep.data;
    const n = (s) => rep.checks.filter((c) => c.status === s).length;
    return {
      activity: d.activity, beds: d.beds, beds_class: d.P, height_class: d.H, highest_floor_m: Math.round(d.hMax * 100) / 100, occupants: d.occTot,
      levels: rep.measures.map((m) => ({ measure: `${m.code} ${m.title}`, level: m.level })),
      checks: { compliant: n('ok'), not_compliant: n('ko'), to_check: n('check') },
      failed: rep.checks.filter((c) => c.status === 'ko').map((c) => `${c.code} ${c.text}: ${c.detail}`),
      ...(markdown ? { markdown: fireReportMarkdown(rep) } : {}),
    };
  },
});
