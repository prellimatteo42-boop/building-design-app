/**
 * Pictures for Claude: an image underlay (or a part of it) drawn into a
 * canvas no larger than Claude reads at full detail, as base64, with the
 * mapping back to the full image's pixels that tool calls use.
 */
export const MAX_EDGE = 1568;

export function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('The image could not be read'));
    img.src = src;
  });
}

/**
 * The picture, or the region [x0, y0, x1, y1] of it in its own pixels,
 * scaled to fit MAX_EDGE: { media_type, data, width, height, region, factor }
 * where a pixel of the result is `factor` pixels of the full image.
 */
export async function imageForClaude(src, region = null, maxEdge = MAX_EDGE) {
  const img = await loadImage(src);
  const W = img.naturalWidth;
  const H = img.naturalHeight;
  const r = region && region.length === 4 ? region.map(Number) : [0, 0, W, H];
  const x0 = Math.max(0, Math.min(W - 1, Math.round(Math.min(r[0], r[2]))));
  const y0 = Math.max(0, Math.min(H - 1, Math.round(Math.min(r[1], r[3]))));
  const x1 = Math.max(x0 + 1, Math.min(W, Math.round(Math.max(r[0], r[2]))));
  const y1 = Math.max(y0 + 1, Math.min(H, Math.round(Math.max(r[1], r[3]))));
  const rw = x1 - x0;
  const rh = y1 - y0;
  const k = Math.min(1, maxEdge / Math.max(rw, rh));
  // Small regions are enlarged so that text in them can be read.
  const up = Math.max(1, Math.min(4, 800 / Math.max(rw, rh)));
  const s = k < 1 ? k : up;
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(rw * s));
  c.height = Math.max(1, Math.round(rh * s));
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(img, x0, y0, rw, rh, 0, 0, c.width, c.height);
  const url = c.toDataURL('image/jpeg', 0.9);
  return { media_type: 'image/jpeg', data: url.slice(url.indexOf(',') + 1), width: c.width, height: c.height, region: [x0, y0, x1, y1], factor: rw / c.width, natural: [W, H] };
}
