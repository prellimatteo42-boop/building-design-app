/**
 * What the assistant can do in a project: functions it may call, each with
 * a JSON schema for the model and an implementation working through the
 * app (so every change is one undo step, and selection, views and dialogs
 * behave as if the user had done it).
 */
import { KIND_LABEL, categoryOf } from '../core/catalog.js';
import { SCHEDULE_CATEGORIES } from '../core/schedule.js';
import { isView, newId, VIEW_LABEL } from '../core/doc.js';
import { modelWarnings } from '../core/warnings.js';
import { formatLength } from '../core/units.js';
import { uniqueName } from '../core/ops.js';
import { buildFloorPlan, imagePointToModel, calibrateImagePatch, imageScale } from '../core/floorplan.js';
import { imageForClaude, loadImage } from './images.js';
import { segmentsOf, convertLines } from '../core/convert.js';
import { placeCAD, defaultRoles } from '../io/cadplace.js';
import { INSUNITS_MM, flattenCAD, layerCounts } from '../core/cadflatten.js';
import * as gdlModule from '../core/gdlobject.js';
import { classOf, classTree, classLabel } from '../core/classify.js';
import { favoritesFor, favoriteFrom, favoritePatch } from '../core/favorites.js';
import { layersInOrder, layerState, setLayerState } from '../core/layers.js';
import { phasesInOrder, PHASE_FILTERS } from '../core/phases.js';
import { PROPERTY_TOOLS } from './proptools.js';
import { DOC_TOOLS } from './doctools.js';
import { FILE_TOOLS } from './filetools.js';

const round = (v) => (typeof v === 'number' ? Math.round(v * 10) / 10 : v);
const pt = (p) => (Array.isArray(p) ? p.map(round) : p);

/** A compact, readable summary of an element for the model. */
function brief(doc, el) {
  const type = doc.get(el.typeId);
  const out = { id: el.id, kind: el.kind, label: KIND_LABEL[el.kind] || VIEW_LABEL[el.kind] || el.kind };
  if (type) out.type = type.name;
  if (el.name) out.name = el.name;
  if (el.number) out.number = el.number;
  if (el.mark) out.mark = el.mark;
  if (el.levelId) out.level = doc.get(el.levelId)?.name;
  if (el.a) out.a = pt(el.a);
  if (el.b) out.b = pt(el.b);
  if (el.at) out.at = pt(el.at);
  return out;
}

function findLevel(doc, name) {
  const levels = doc.levels();
  if (!name) return levels[0];
  const n = String(name).toLowerCase();
  return levels.find((l) => l.name.toLowerCase() === n) || levels.find((l) => l.name.toLowerCase().includes(n)) || null;
}

function findView(doc, name) {
  const n = String(name || '').toLowerCase();
  const views = doc.filter(isView);
  return views.find((v) => v.name.toLowerCase() === n) || views.find((v) => v.name.toLowerCase().includes(n)) || null;
}


/** The plan view an underlay goes in: the active plan, else the plan of a level. */
function planFor(app, level) {
  const doc = app.doc;
  const v = app.activeView;
  if (!level && v && (v.kind === 'plan' || v.kind === 'draftingView')) return v;
  const lv = findLevel(doc, level) || doc.levels()[0];
  return doc.all('plan').find((p) => p.levelId === lv?.id) || null;
}

/**
 * Place a picture of a floor plan as an underlay in a plan view, about 20 m
 * across until it is calibrated. Returns the image element.
 */
export function placeUnderlay(app, { src, name, px, level, width = 20000, at = [0, 0], calibrated = false, pageMm = null }) {
  const view = planFor(app, level);
  if (!view) return null;
  const w = width;
  const h = (w * px[1]) / Math.max(1, px[0]);
  let el;
  app.commit('Place floor plan image', () => (el = app.doc.add({ kind: 'image', viewId: view.id, at, w, h, rotation: 0, opacity: 0.6, src, name: name || 'Floor plan', px: [...px], ...(calibrated ? { calibrated: true } : {}), ...(pageMm ? { pageMm } : {}) })));
  if (app.activeView?.id !== view.id) app.openView(view.id);
  return el;
}

function findImage(doc, id) {
  const img = id ? doc.get(id) : doc.all('image').at(-1);
  return img?.kind === 'image' ? img : null;
}

/** An image's full size in pixels, read from the picture when it was placed without it. */
async function withPixels(app, img) {
  if (img.px) return img;
  const pic = await loadImage(img.src);
  const px = [pic.naturalWidth, pic.naturalHeight];
  app.commit('Image size', () => app.doc.update(img.id, { px }));
  return app.doc.get(img.id);
}

function describeImage(doc, img) {
  return { id: img.id, name: img.name, view: doc.get(img.viewId)?.name, pixels: img.px, mmPerPixel: img.px ? round(imageScale(img)) : null, calibrated: !!img.calibrated, ...(img.pageMm ? { pdfPageMm: img.pageMm.map(round) } : {}) };
}

const PT = { type: 'array', items: { type: 'number' }, minItems: 2, maxItems: 2 };

/** Commands safe to run on request (they open dialogs, views or tools, or change what is shown). */
// Commands that replace, publish or send out the project, which the assistant leaves to the user.
const NOT_FOR_ASSISTANT = new Set(['newProject', 'open', 'openSample', 'home', 'save', 'saveAs', 'export', 'publish', 'print', 'share', 'signIn', 'syncNow', 'linkProject', 'reloadLinkFrom', 'assistant', 'about']);


export const TOOLS = [
  {
    name: 'project_summary',
    description: 'Overview of the open project: name, units, levels, how many elements of each kind, views, sheets and schedules.',
    parameters: { type: 'object', properties: {} },
    run(app) {
      const doc = app.doc;
      const counts = {};
      for (const el of doc.items.values()) {
        if (isView(el) || el.kind.endsWith('Type') || !categoryOf(el, doc)) continue;
        counts[KIND_LABEL[el.kind] || el.kind] = (counts[KIND_LABEL[el.kind] || el.kind] || 0) + 1;
      }
      return {
        name: doc.project.name,
        units: doc.units.system,
        levels: doc.levels().map((l) => ({ name: l.name, elevation: formatLength(l.elevation, doc.units) })),
        elements: counts,
        views: doc.filter(isView).map((v) => ({ name: v.name, kind: VIEW_LABEL[v.kind] })),
        activeView: app.activeView?.name,
        selection: [...app.selection].length,
      };
    },
  },
  {
    name: 'find_elements',
    description: 'Find elements by kind (wall, door, window, room, floor, roof, column, beam, stair, component, space, duct, pipe, ...), level name and/or type or element name text. Returns up to 200 matches with ids.',
    parameters: { type: 'object', properties: { kind: { type: 'string' }, level: { type: 'string' }, text: { type: 'string', description: 'Part of the type name, element name, number or mark.' } } },
    run(app, { kind, level, text }) {
      const doc = app.doc;
      const lv = level ? findLevel(doc, level) : null;
      const q = text ? String(text).toLowerCase() : null;
      const out = [];
      for (const el of doc.items.values()) {
        if (isView(el) || el.kind.endsWith('Type') || el.kind === 'material') continue;
        if (kind && el.kind !== kind) continue;
        if (lv && el.levelId !== lv.id) continue;
        if (q) {
          const hay = `${doc.get(el.typeId)?.name || ''} ${el.name || ''} ${el.number || ''} ${el.mark || ''}`.toLowerCase();
          if (!hay.includes(q)) continue;
        }
        if (!kind && !categoryOf(el, doc)) continue;
        out.push(brief(doc, el));
        if (out.length >= 200) break;
      }
      return { count: out.length, elements: out };
    },
  },
  {
    name: 'room_areas',
    description: 'Rooms with their level, number, name, area (m² or ft²) and perimeter.',
    parameters: { type: 'object', properties: { level: { type: 'string' } } },
    run(app, { level }) {
      const doc = app.doc;
      const lv = level ? findLevel(doc, level) : null;
      const imp = doc.units.system === 'imperial';
      return doc.all('room').filter((r) => !lv || r.levelId === lv.id).map((r) => {
        const reg = app.scene.rooms.room(r);
        const a = reg ? reg.area / 1e6 : null;
        return { id: r.id, level: doc.get(r.levelId)?.name, number: r.number, name: r.name, area: a == null ? 'not enclosed' : imp ? `${(a * 10.7639).toFixed(1)} ft²` : `${a.toFixed(2)} m²` };
      });
    },
  },
  {
    name: 'get_element',
    description: 'All stored fields of one element (lengths in millimetres).',
    parameters: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] },
    run(app, { id }) {
      const el = app.doc.get(id);
      if (!el) return { error: 'No element with that id' };
      const json = JSON.stringify(el);
      return json.length > 4000 ? { ...brief(app.doc, el), note: 'Element too large to show in full' } : el;
    },
  },
  {
    name: 'set_parameters',
    description: 'Change stored fields of elements, for example { name, number, mark, comments, height, offset } (lengths in millimetres). One undoable change.',
    parameters: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' } }, values: { type: 'object' } }, required: ['ids', 'values'] },
    run(app, { ids, values }) {
      const doc = app.doc;
      const bad = ['id', 'kind'];
      const patch = Object.fromEntries(Object.entries(values || {}).filter(([k]) => !bad.includes(k)));
      const live = (ids || []).filter((id) => doc.has(id));
      if (!live.length) return { error: 'None of those ids exist' };
      app.commit('Assistant: change parameters', () => live.forEach((id) => doc.update(id, patch)));
      return { changed: live.length };
    },
  },
  {
    name: 'select_elements',
    description: 'Select elements in the app and show them (opens a plan of their level and zooms to them); with mode add or remove, add them to the selection or take them out of it without moving the view.',
    parameters: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' } }, mode: { type: 'string', enum: ['replace', 'add', 'remove'] } }, required: ['ids'] },
    run(app, { ids, mode = 'replace' }) {
      const live = (ids || []).filter((id) => app.doc.has(id));
      if (mode === 'replace') app.showElements(live);
      else app.select(live, mode);
      return { selected: app.selection.size, [mode === 'remove' ? 'removed' : 'added']: live.length };
    },
  },
  {
    name: 'open_view',
    description: 'Open a view, schedule or sheet by name.',
    parameters: { type: 'object', properties: { name: { type: 'string' } }, required: ['name'] },
    run(app, { name }) {
      const v = findView(app.doc, name);
      if (!v) return { error: `No view named "${name}"` };
      app.openView(v.id);
      return { opened: v.name };
    },
  },
  {
    name: 'look_at_view',
    description: 'See a view of the model as a picture, to check your work: a floor plan, the 3D view, a section, an elevation, a sheet. view is a view\'s name (or "3d"; the open view when left out). For plans and other 2D views, region [x0, y0, x1, y1] in model millimetres shows just that part, larger. The picture comes back to you.',
    parameters: { type: 'object', properties: { view: { type: 'string' }, region: { type: 'array', items: { type: 'number' } }, size: { type: 'number', description: 'Longest side in pixels, up to 1568 (default 1200)' } } },
    async run(app, { view, region, size }) {
      const doc = app.doc;
      let v = view ? (/^3d$/i.test(view) ? doc.all('view3d')[0] : findView(doc, view)) : app.activeView;
      if (!v) return { error: view ? `No view named "${view}"` : 'No view is open' };
      const { renderViewImage } = await import('../views/snapshot.js');
      const longest = Math.max(256, Math.min(1568, +size || 1200));
      const vp = app.viewport;
      const aspect = vp?.width && vp?.height ? vp.width / vp.height : 4 / 3;
      const w = aspect >= 1 ? longest : Math.round(longest * aspect);
      const h = aspect >= 1 ? Math.round(longest / aspect) : longest;
      let camera = null;
      if (Array.isArray(region) && region.length === 4 && v.kind !== 'view3d') {
        const [x0, y0, x1, y1] = region.map(Number);
        // A 2D view's camera: the region's middle, at the zoom that fits it.
        camera = { cx: (x0 + x1) / 2, cy: (y0 + y1) / 2, zoom: Math.min(w / Math.max(1, Math.abs(x1 - x0)), h / Math.max(1, Math.abs(y1 - y0))) * 0.95 };
      }
      const { canvas } = renderViewImage(app, v, w, h, { fit: !camera, ...(camera ? { camera } : {}) });
      const url = canvas.toDataURL('image/jpeg', 0.85);
      return { view: v.name, kind: v.kind, pixels: [w, h], ...(camera ? { region } : {}), _image: { media_type: 'image/jpeg', data: url.slice(url.indexOf(',') + 1) } };
    },
  },
  {
    name: 'create_schedule',
    description: `Create a schedule and open it. category is one of: ${Object.keys(SCHEDULE_CATEGORIES).join(', ')}. fields are field ids of that category (leave out for the defaults); sortBy and groupBy are field ids.`,
    parameters: { type: 'object', properties: { category: { type: 'string' }, name: { type: 'string' }, fields: { type: 'array', items: { type: 'string' } }, sortBy: { type: 'string' }, descending: { type: 'boolean' }, groupBy: { type: 'string' } }, required: ['category'] },
    run(app, { category, name, fields, sortBy, descending, groupBy }) {
      const cat = SCHEDULE_CATEGORIES[category];
      if (!cat) return { error: `Unknown category. Use one of: ${Object.keys(SCHEDULE_CATEGORIES).join(', ')}` };
      const ids = new Set(cat.fields.map((f) => f.id));
      const doc = app.doc;
      const v = { id: newId('v'), kind: 'schedule', name: uniqueName(doc.all('schedule').map((s) => s.name), name || `${cat.label} Schedule`), category, fields: fields?.length ? fields.filter((f) => ids.has(f)) : null, sortBy: ids.has(sortBy) ? sortBy : null, sortDir: descending ? 'desc' : 'asc', groupBy: ids.has(groupBy) ? groupBy : null };
      app.commit('Assistant: create schedule', () => doc.add(v));
      app.openView(v.id);
      return { created: v.name, fields: cat.fields.map((f) => f.id) };
    },
  },
  {
    name: 'create_level',
    description: 'Add a level at an elevation (millimetres) with a plan view.',
    parameters: { type: 'object', properties: { name: { type: 'string' }, elevation: { type: 'number' } }, required: ['elevation'] },
    run(app, { name, elevation }) {
      const doc = app.doc;
      let lv;
      app.commit('Assistant: create level', () => {
        lv = doc.add({ kind: 'level', name: name || uniqueName(doc.levels().map((l) => l.name), `Level ${doc.levels().length + 1}`), elevation: +elevation || 0 });
        doc.add({ kind: 'plan', name: lv.name, levelId: lv.id, scale: 100, detail: 'medium' });
      });
      return { created: lv.name };
    },
  },
  {
    name: 'create_walls',
    description: 'Draw walls on a level as a chain through points [[x, y], ...] in millimetres (closed: back to the first point). Uses the current wall type unless typeName matches another.',
    parameters: { type: 'object', properties: { level: { type: 'string' }, points: { type: 'array', items: { type: 'array', items: { type: 'number' } } }, closed: { type: 'boolean' }, typeName: { type: 'string' }, height: { type: 'number' } }, required: ['points'] },
    run(app, { level, points, closed, typeName, height }) {
      const doc = app.doc;
      const lv = findLevel(doc, level);
      if (!lv) return { error: 'No such level' };
      const pts = (points || []).filter((p) => Array.isArray(p) && p.length >= 2).map((p) => [+p[0], +p[1]]);
      if (pts.length < 2) return { error: 'Give at least two points' };
      const type = (typeName && doc.all('wallType').find((t) => t.name.toLowerCase().includes(String(typeName).toLowerCase()))) || app.currentType('wall');
      const above = doc.levelAbove(lv.id);
      const segs = pts.slice(0, -1).map((p, i) => [p, pts[i + 1]]);
      if (closed && pts.length > 2) segs.push([pts.at(-1), pts[0]]);
      const ids = [];
      app.commit('Assistant: walls', () => {
        for (const [a, b] of segs) ids.push(doc.add({ kind: 'wall', typeId: type?.id, levelId: lv.id, a, b, baseOffset: 0, topLevelId: height ? null : above?.id ?? null, topOffset: 0, height: +height || 3000, locationLine: 'center', joinA: true, joinB: true, roomBounding: true }).id);
      });
      app.showElements(ids);
      return { created: ids.length, type: type?.name };
    },
  },
  {
    name: 'list_images',
    description: 'Pictures placed in the project (for example floor plans to trace): id, view, size in pixels, millimetres per pixel and whether the scale was calibrated.',
    parameters: { type: 'object', properties: {} },
    run(app) {
      return app.doc.all('image').map((i) => describeImage(app.doc, i));
    },
  },
  {
    name: 'view_image',
    description: 'Look at a placed picture, whole or a region of it to read small text and details. region is [x0, y0, x1, y1] in the full image\'s pixels (origin top left). Coordinates you pass to calibrate_image and trace_floor_plan are always full-image pixels: a point at (x, y) in the returned picture is at (region.x0 + x * factor, region.y0 + y * factor).',
    parameters: { type: 'object', properties: { image_id: { type: 'string' }, region: { type: 'array', items: { type: 'number' }, minItems: 4, maxItems: 4 } } },
    async run(app, { image_id, region }) {
      let img = findImage(app.doc, image_id);
      if (!img) return { error: 'No such image. Use list_images.' };
      img = await withPixels(app, img);
      const pic = await imageForClaude(img.src, region);
      return { ...describeImage(app.doc, img), region: pic.region, shown: [pic.width, pic.height], factor: round(pic.factor), _image: { media_type: pic.media_type, data: pic.data } };
    },
  },
  {
    name: 'calibrate_image',
    description: 'Set the true scale of a placed picture from a length you can read on it: the two ends of a dimension line (or of a door opening of known width) in full-image pixels, and their real distance in millimetres. Or, for a page from a PDF (list_images shows pdfPageMm), give scale: the N of the drawing scale 1:N printed on it. Do this before tracing.',
    parameters: { type: 'object', properties: { image_id: { type: 'string' }, from: PT, to: PT, distance: { type: 'number', description: 'Millimetres' }, scale: { type: 'number', description: 'N of a 1:N drawing scale, for PDF pages' } } },
    async run(app, { image_id, from, to, distance, scale }) {
      let img = findImage(app.doc, image_id);
      if (!img) return { error: 'No such image. Use list_images.' };
      if (+scale > 0) {
        if (!img.pageMm) return { error: 'This picture did not come from a PDF page; calibrate it from a known length instead.' };
        const k = +scale;
        app.commit('Assistant: set drawing scale', () => app.doc.update(img.id, { w: img.pageMm[0] * k, h: img.pageMm[1] * k, calibrated: true }));
        return { calibrated: true, scale: `1:${k}`, mmPerPixel: round(imageScale(app.doc.get(img.id))) };
      }
      if (!from || !to || !distance) return { error: 'Give from, to and distance, or scale for a PDF page' };
      img = await withPixels(app, img);
      const patch = calibrateImagePatch(img, from, to, distance);
      if (!patch) return { error: 'Give two different points and a positive distance' };
      app.commit('Assistant: calibrate image', () => app.doc.update(img.id, patch));
      const next = app.doc.get(img.id);
      return { calibrated: true, mmPerPixel: round(imageScale(next)), imageWidth: formatLength(next.w, app.doc.units) };
    },
  },
  {
    name: 'gdl_object',
    description: 'Make or change a parametric object written in GDL, Archicad\'s object language, and place it if asked. Lengths in the scripts are metres; A, B, ZZYZX are the width, depth and height (given here in mm); the origin is the box\'s front left bottom corner, x right, y back, z up. 3D: ADD/ADDX/ADDY/ADDZ, ROTX/ROTY/ROTZ (degrees), MUL, DEL n, MATERIAL (a material parameter, an id such as "mat-wood", or "#rrggbb"), BLOCK a,b,c, CYLIND h,r, CONE h,r1,r2,90,90, SPHERE r, ELLIPS h,r, PRISM_ n,h, x,y,s..., CPRISM_ top,bottom,side, n,h, x,y,s..., SLAB_ n,h, x,y,z,s..., REVOLVE n,angle,mask, x,y,s..., LIN_, HOTSPOT. 2D: LINE2, RECT2, POLY2_ n,frame_fill, x,y,s..., CIRCLE2, ARC2, TEXT2, ADD2, ROT2, PROJECT2 (or leave the 2D script empty for the 3D seen from above). Control: IF/THEN/ELSE/ENDIF, FOR/NEXT, WHILE/ENDWHILE, REPEAT/UNTIL, GOSUB/RETURN, DIM arrays; SIN/COS/TAN in degrees. Parameters: [{ name, label, kind: length (mm) | number | integer | angle | boolean | material | string, value }]. The result reports script errors with their line, or the triangle count: fix and call again with the same name.',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string' },
        category: { type: 'string', description: 'furniture, casework, lighting, plumbing, specialty, genericModels...' },
        width: { type: 'number' },
        depth: { type: 'number' },
        height: { type: 'number' },
        params: { type: 'array', items: { type: 'object' } },
        script3d: { type: 'string' },
        script2d: { type: 'string' },
        place_at: { type: 'array', items: { type: 'number' }, description: '[x, y] in mm: place one there' },
        rotation: { type: 'number' },
        level: { type: 'string' },
      },
      required: ['name'],
    },
    run(app, { name, category, width, depth, height, params, script3d, script2d, place_at, rotation, level }) {
      const doc = app.doc;
      const { runGdlType } = gdlModule;
      let type = doc.all('componentType').find((t) => t.family === 'gdl' && t.name === name);
      const gdl = { params: Array.isArray(params) ? params : type?.gdl?.params || [], script3d: script3d ?? type?.gdl?.script3d ?? '', script2d: script2d ?? type?.gdl?.script2d ?? '' };
      const fields = { name, category: category || type?.category || 'genericModels', width: +width || type?.width || 1000, depth: +depth || type?.depth || 1000, height: +height || type?.height || 1000, gdl };
      const check = runGdlType(fields);
      let placed = null;
      app.commit(type ? 'Assistant: edit GDL object' : 'Assistant: GDL object', () => {
        if (type) doc.update(type.id, fields);
        else type = doc.add({ kind: 'componentType', family: 'gdl', familyName: 'GDL Object', ...fields });
        if (Array.isArray(place_at) && place_at.length === 2) {
          const view = planFor(app, level);
          const lv = view?.levelId || doc.levels()[0]?.id;
          placed = doc.add({ kind: 'component', typeId: type.id, levelId: lv, at: [+place_at[0], +place_at[1]], rotation: +rotation || 0, offset: 0 }).id;
        }
      });
      return check.error ? { type: type.id, error: check.error } : { type: type.id, triangles: check.tris.length, planLines: check.lines.length + check.polys.length, placed };
    },
  },
  {
    name: 'model_from_file',
    description: 'Model a drawing file in one step, the best way for its kind: an IFC opens as elements of this project; a DWG or DXF becomes walls, doors, windows, columns and zones from its layers; a PDF from a CAD program a model from its vectors (at the scale its title block states, or scale); a scanned PDF, a picture or a photo of a plan is straightened when it is a photo and modelled from its pixels, its scale estimated from its walls and doors when not known. Claude Code: pass path, the absolute path of the file. Then check what it says to check.',
    parameters: { type: 'object', properties: { path: { type: 'string' }, name: { type: 'string' }, scale: { type: 'number', description: 'N of a 1:N drawing scale, for PDFs' } } },
    async run(app, { data_url, name, scale }) {
      if (typeof data_url !== 'string' || !data_url.startsWith('data:')) return { error: 'Pass path, the absolute path of a DWG, DXF, IFC, PDF or picture file on this computer' };
      const type = data_url.slice(5, data_url.indexOf(';'));
      const ext = { 'application/acad': 'dwg', 'application/dxf': 'dxf', 'application/x-step': 'ifc', 'application/pdf': 'pdf', 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' }[type];
      if (!ext) return { error: 'That kind of file cannot be modelled' };
      const bin = atob(data_url.slice(data_url.indexOf(',') + 1));
      const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
      const base = (name || 'drawing').replace(/\.[a-z0-9]+$/i, '');
      return app.modelFromFile(new File([bytes], `${base}.${ext}`, { type }), { scale: +scale || 0 });
    },
  },
  {
    name: 'straighten_image',
    description: 'Square up a photo of a printed plan taken at an angle: the perspective is taken out so walls are straight and lengths true. The sheet\'s corners are found automatically; if that fails or is wrong, look with view_image and give corners: [top left, top right, bottom right, bottom left] in full-image pixels. Then calibrate_image and model_from_image.',
    parameters: { type: 'object', properties: { image_id: { type: 'string' }, corners: { type: 'array', items: { type: 'array', items: { type: 'number' } } } } },
    async run(app, { image_id, corners }) {
      return app.straightenImage(image_id || null, corners || null);
    },
  },
  {
    name: 'model_from_image',
    description: 'Model a calibrated picture of a floor plan automatically: its thick dark strokes become walls, gaps with a door swing doors, gaps with glass lines windows, and each enclosed floor area a zone with its exact outline. Fast and exact for clean plans (exports, scans); then look at the picture with view_image to name the zones (set_parameters) and fix what it missed with trace_floor_plan or create_walls. Calibrate the picture first.',
    parameters: { type: 'object', properties: { image_id: { type: 'string' } } },
    async run(app, { image_id }) {
      return app.modelFromImage(image_id || null);
    },
  },
  {
    name: 'trace_floor_plan',
    description: 'Model a floor plan in one step: walls (centre lines, with thickness), doors and windows (a point on or near their wall, with width) and rooms (a point inside, with a name). With image_id, all points are full-image pixels of that calibrated picture; without it, millimetres. Wall ends that nearly meet are joined and near-straight walls squared, so trace each straight wall from corner to corner. Undo removes it all.',
    parameters: {
      type: 'object',
      properties: {
        image_id: { type: 'string' },
        level: { type: 'string' },
        walls: { type: 'array', items: { type: 'object', properties: { from: PT, to: PT, thickness: { type: 'number', description: 'Millimetres' }, exterior: { type: 'boolean' } }, required: ['from', 'to'] } },
        doors: { type: 'array', items: { type: 'object', properties: { at: PT, width: { type: 'number' }, height: { type: 'number' } }, required: ['at'] } },
        windows: { type: 'array', items: { type: 'object', properties: { at: PT, width: { type: 'number' }, height: { type: 'number' }, sill: { type: 'number' } }, required: ['at'] } },
        rooms: { type: 'array', items: { type: 'object', properties: { at: PT, name: { type: 'string' }, number: { type: 'string' } }, required: ['at'] } },
        height: { type: 'number', description: 'Wall height in millimetres when there is no level above' },
      },
    },
    async run(app, { image_id, level, walls = [], doors = [], windows = [], rooms = [], height }) {
      const doc = app.doc;
      let img = image_id ? findImage(doc, image_id) : null;
      if (image_id && !img) return { error: 'No such image. Use list_images.' };
      if (img) img = await withPixels(app, img);
      const M = (p) => (Array.isArray(p) && p.length >= 2 ? (img ? imagePointToModel(img, [+p[0], +p[1]]) : [+p[0], +p[1]]) : null);
      const lv = findLevel(doc, level || (img ? doc.get(doc.get(img.viewId)?.levelId)?.name : null));
      if (!lv) return { error: 'No such level' };
      const plan = {
        walls: walls.map((w) => ({ a: M(w.from), b: M(w.to), thickness: w.thickness, exterior: w.exterior })).filter((w) => w.a && w.b),
        doors: doors.map((d) => ({ ...d, at: M(d.at) })),
        windows: windows.map((d) => ({ ...d, at: M(d.at) })),
        rooms: rooms.map((r) => ({ ...r, at: M(r.at) })),
      };
      let out;
      app.commit('Assistant: trace floor plan', () => (out = buildFloorPlan(doc, plan, { levelId: lv.id, height: +height || 3000 })));
      app.showElements(out.walls);
      const rooms_ = out.rooms.map((id) => {
        const r = doc.get(id);
        const reg = app.scene.rooms.room(r);
        return { id, name: r.name, area: reg ? `${(reg.area / 1e6).toFixed(2)} m²` : 'not enclosed: a wall is missing or does not meet' };
      });
      return { level: lv.name, walls: out.walls.length, doors: out.doors.length, windows: out.windows.length, rooms: rooms_, skipped: out.skipped, calibrated: img ? !!img.calibrated : undefined };
    },
  },
  {
    name: 'import_floor_plan_image',
    description: 'Place a picture, PDF, DWG, DXF or IFC of a floor plan in the plan of a level. An IFC file (BIM model from other software) opens as elements of this project on its storeys\' levels. Claude Code: pass path, the absolute path of the file on this computer. A picture or PDF comes in as an underlay to calibrate and trace (page: one PDF page, else the first three). For a PDF exported from a CAD program, as: "model" makes walls, doors, windows, columns and zones from the page straight away (at the scale its title block states, or scale N), and as: "lines" with scale N brings its drawing in as exact lines and text instead. A DWG or DXF becomes a model straight away: walls, doors, windows, curtain walls, columns and zones from its layers by their names (as: "lines" keeps it all as drafting); roles: { layer: role } overrides a layer\'s role (wall, column, door, window, zone, stamp, drafting, ignore).',
    parameters: { type: 'object', properties: { path: { type: 'string' }, level: { type: 'string' }, name: { type: 'string' }, page: { type: 'number' }, as: { type: 'string', enum: ['picture', 'lines', 'model'] }, scale: { type: 'number' }, roles: { type: 'object' } } },
    async run(app, { data_url, level, name, page, as = 'picture', scale, roles }) {
      if (typeof data_url === 'string' && data_url.startsWith('data:application/x-step;base64,')) {
        const bin = atob(data_url.slice(data_url.indexOf(',') + 1));
        const text = new TextDecoder().decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
        const out = await app.openIFC(new File([text], name || 'model.ifc'));
        return out ? { ...out, next: 'The file\'s elements are now this project\'s: walls, slabs, doors, windows, columns, beams and zones, with their IFC GlobalIds and property sets. Check them with project_summary and room_areas.' } : { error: 'The IFC file could not be read' };
      }
      const cad = typeof data_url === 'string' && /^data:application\/(acad|dxf);base64,/.exec(data_url);
      if (cad) {
        const { readCAD } = await import('../io/dwgread.js');
        const bytes = Uint8Array.from(atob(data_url.slice(data_url.indexOf(',') + 1)), (c) => c.charCodeAt(0));
        const drawing = await readCAD(bytes, { dxf: cad[1] === 'dxf' });
        const view = planFor(app, level);
        if (!view) return { error: 'No plan view to place it in' };
        const layerNames = [...layerCounts(flattenCAD(drawing)).keys()];
        const roleMap = defaultRoles(layerNames);
        for (const [l, r] of Object.entries(roles || {})) if (roleMap.has(l)) roleMap.set(l, String(r));
        let res;
        app.commit('Import DWG', () => (res = placeCAD(app.doc, drawing, { view, roles: roleMap, unitMm: INSUNITS_MM[drawing.units] ?? 1, mode: as === 'lines' ? 'drafting' : 'smart' })));
        if (app.activeView?.id !== view.id) app.openView(view.id);
        const m = res.model;
        return {
          layers: Object.fromEntries(roleMap),
          made: m ? { walls: m.walls.length, doors: m.doors.length, windows: m.windows.length, columns: m.columns.length, zones: m.rooms.length, curtainWalls: m.counts.curtainWalls } : null,
          drafting: res.drafting,
          skipped: m?.skipped?.slice(0, 10),
          next: 'Check the result with room_areas and model_warnings. If a layer had the wrong role, undo (run_command undo) and import again with roles. Name the zones from the drawing\'s texts with set_parameters.',
        };
      }
      if (typeof data_url === 'string' && data_url.startsWith('data:application/pdf;base64,') && as === 'model') {
        const { openPDF } = await import('../io/pdfread.js');
        const bytes = Uint8Array.from(atob(data_url.slice(data_url.indexOf(',') + 1)), (c) => c.charCodeAt(0));
        const view = planFor(app, level);
        if (!view) return { error: 'No plan view to place it in' };
        if (app.activeView?.id !== view.id) app.openView(view.id);
        const made = await app.modelFromPdf(await openPDF(bytes), +page || 1, +scale || 0, name || 'PDF');
        return { ...made, next: made?.error ? 'Give scale (the N of 1:N) if the sheet does not state it, or import as a picture and trace.' : 'The page is placed under the model to compare. Zones whose areas differ from their stamps need a wall or a separator: check them with room_areas; fix what is missing with create_walls or trace_floor_plan.' };
      }
      if (typeof data_url === 'string' && data_url.startsWith('data:application/pdf;base64,') && as === 'lines') {
        const { openPDF } = await import('../io/pdfread.js');
        const bytes = Uint8Array.from(atob(data_url.slice(data_url.indexOf(',') + 1)), (c) => c.charCodeAt(0));
        const pdf = await openPDF(bytes);
        try {
          const vec = await pdf.vectors(+page || 1);
          const view = planFor(app, level);
          const ids = app.placePdfVectors(vec, +scale || 100, [0, 0], view);
          if (app.activeView?.id !== view?.id && view) app.openView(view.id);
          return { lines: vec.segments.length, texts: vec.texts.slice(0, 200).map((t) => ({ text: t.text, at: t.at.map((v) => round(v * (+scale || 100))) })), placed: ids.length, next: 'Texts give room names and dimensions in mm. Use convert_lines to make walls from the face lines, then add doors, windows and rooms with trace_floor_plan (in mm).' };
        } finally {
          pdf.close();
        }
      }
      if (typeof data_url === 'string' && data_url.startsWith('data:application/pdf;base64,')) {
        const { pdfPagePictures } = await import('./pdfpages.js');
        const pics = await pdfPagePictures(data_url, page ? [+page] : null);
        const placed = pics.map((p, i) => placeUnderlay(app, { src: p.src, name: `${name || 'PDF'} - page ${p.page}`, px: p.px, level, pageMm: p.pageMm, at: [i * 25000, 0] })).filter(Boolean);
        if (!placed.length) return { error: 'No plan view to place it in' };
        return { placed: placed.map((el) => describeImage(app.doc, el)), next: 'Call view_image to see each page. If the drawing states its scale (1:N), calibrate_image with scale N; else calibrate from a dimension. Then model_from_image (or, for a PDF from a CAD program, import it again with as: "model"), and trace_floor_plan.' };
      }
      if (typeof data_url !== 'string' || !/^data:image\/(png|jpeg|webp|gif);base64,/.test(data_url)) return { error: 'Pass path, the absolute path of a PNG, JPEG, PDF, DWG or DXF file on this computer' };
      const pic = await loadImage(data_url);
      const el = placeUnderlay(app, { src: data_url, name, px: [pic.naturalWidth, pic.naturalHeight], level });
      if (!el) return { error: 'No plan view to place it in' };
      return { placed: describeImage(app.doc, el), next: 'Call view_image to see it, calibrate_image with a known dimension, then model_from_image, and trace_floor_plan for what it misses (hand sketches, photos at an angle).' };
    },
  },
  {
    name: 'convert_lines',
    description: 'Turn detail lines in a plan (for example from a PDF or DXF) into model elements: to "wallPairs" (pairs of parallel face lines 50 to 600 mm apart become walls of that thickness), "walls" (lines as centre lines), "slabs" or "zones" (closed shapes). within: [x0, y0, x1, y1] in mm limits it to lines inside that box. The lines used are removed.',
    parameters: { type: 'object', properties: { to: { type: 'string', enum: ['wallPairs', 'walls', 'slabs', 'zones'] }, level: { type: 'string' }, within: { type: 'array', items: { type: 'number' }, minItems: 4, maxItems: 4 } }, required: ['to'] },
    run(app, { to, level, within }) {
      const doc = app.doc;
      const view = planFor(app, level);
      if (!view) return { error: 'No plan view' };
      const inBox = (p) => !within || (p[0] >= Math.min(within[0], within[2]) && p[0] <= Math.max(within[0], within[2]) && p[1] >= Math.min(within[1], within[3]) && p[1] <= Math.max(within[1], within[3]));
      const lines = doc.all('detailLine').filter((l) => l.viewId === view.id && inBox(l.a) && inBox(l.b));
      if (!lines.length) return { error: 'No detail lines in that plan (or box)' };
      let res;
      app.commit('Assistant: convert lines', () => {
        res = convertLines(doc, segmentsOf(lines), to, { levelId: view.levelId, viewId: view.id });
        if (res.ids.length) for (const l of lines) doc.remove(l.id);
      });
      app.showElements(res.ids);
      return { made: res.ids.length, skipped: res.skipped };
    },
  },
  {
    name: 'check_requirements',
    description: 'Check the design against the requirements for dwellings of a building code (Italy: DM 5/7/1975 heights, minimum room areas, windows of 1/8 of the floor, bathroom ventilation, one-room dwelling area; DM 236/1989 door widths). Room uses are read from their names. make_issues: true keeps each finding as an issue. Explain the findings to the user and offer fixes (larger rooms, wider windows with set_parameters...).',
    parameters: { type: 'object', properties: { make_issues: { type: 'boolean' } } },
    async run(app, { make_issues }) {
      const { checkCompliance } = await import('../core/compliance.js');
      const findings = checkCompliance(app.doc, app.scene);
      let issues = 0;
      if (make_issues && findings.length) {
        const { makeIssues } = await import('../ui/compliance.js');
        issues = makeIssues(app, findings);
      }
      return { met: !findings.some((f) => f.severity === 'error'), findings: findings.map((f) => ({ rule: f.rule, severity: f.severity, message: f.message, elements: f.ids })), issues };
    },
  },
  {
    name: 'model_warnings',
    description: 'Problems found in the model (overlapping walls, rooms not enclosed, duplicate marks...).',
    parameters: { type: 'object', properties: {} },
    run(app) {
      return modelWarnings(app.doc, app.scene).slice(0, 60).map((w) => ({ message: w.message, ids: w.ids }));
    },
  },
  {
    name: 'search_commands',
    description: 'Find app commands by words (as on the menus: tools, dialogs, display, Archicad features such as Roof Framing or Sun Study). Returns their names for run_command.',
    parameters: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] },
    run(app, { query }) {
      const words = String(query || '').toLowerCase().split(/\s+/).filter(Boolean);
      const out = [];
      for (const name of app.commandNames()) {
        const d = app.commandDef(name);
        const text = `${name} ${d.label || ''} ${d.desc || ''} ${d.search || ''}`.toLowerCase();
        if (words.every((w) => text.includes(w))) out.push({ command: name, label: d.label, description: d.desc, available: !NOT_FOR_ASSISTANT.has(name) && (!d.enabled || !!d.enabled(app)) });
      }
      return { commands: out.slice(0, 40), more: Math.max(0, out.length - 40) };
    },
  },
  {
    name: 'run_command',
    description: 'Run an app command by its name (see search_commands): a tool, a dialog, a display change or an action on the selection. Commands that replace or send out the project are not available.',
    parameters: { type: 'object', properties: { command: { type: 'string' } }, required: ['command'] },
    run(app, { command }) {
      const def = !NOT_FOR_ASSISTANT.has(command) && app.commandDef(command);
      if (!def) return { error: 'That command is not available to the assistant' };
      if (def.enabled && !def.enabled(app)) return { error: `${def.label} is not available now (select elements or open a fitting view first)` };
      app.run(command);
      return { ran: def.label };
    },
  },
  {
    name: 'get_selection',
    description: 'The elements selected now.',
    parameters: { type: 'object', properties: {} },
    run(app) {
      const els = [...app.selection].map((id) => app.doc.get(id)).filter(Boolean);
      return { count: els.length, elements: els.slice(0, 200).map((el) => brief(app.doc, el)) };
    },
  },
  {
    name: 'classify_elements',
    description: 'Classification (as Archicad and IFC): list the items of the classification systems that match a query, or give elements an item by its code (an empty code removes their own choice and they take the fitting item again).',
    parameters: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' }, description: 'Elements to classify (default: the selection). Leave out with code to only search.' }, code: { type: 'string' }, query: { type: 'string', description: 'Words to search item codes and names' }, system: { type: 'string', description: 'System name (default: the first)' } } },
    run(app, { ids, code, query, system }) {
      const doc = app.doc;
      const systems = doc.all('classSystem');
      const sys = (system && systems.find((x) => x.name.toLowerCase().includes(String(system).toLowerCase()))) || systems[0];
      if (!sys) return { error: 'The project has no classification system' };
      if (code === undefined) {
        const q = String(query || '').toLowerCase();
        return { system: sys.name, systems: systems.map((x) => x.name), items: classTree(sys).filter(({ item }) => !q || classLabel(item).toLowerCase().includes(q)).slice(0, 60).map(({ item, depth }) => ({ code: item.code, name: item.name, depth, ifc: item.ifc || undefined })) };
      }
      if (code && !sys.items.some((i) => i.code === code)) return { error: `No item ${code} in ${sys.name}` };
      const els = (ids?.length ? ids : [...app.selection]).map((id) => doc.get(id)).filter(Boolean);
      if (!els.length) return { error: 'No elements: give ids or select them' };
      app.commit('Classify', () => els.forEach((el) => doc.update(el.id, { classes: { ...(el.classes || {}), [sys.id]: code } })));
      return { classified: els.length, as: classLabel(classOf(doc, doc.get(els[0].id), sys)) || 'fitting item' };
    },
  },
  {
    name: 'favorites',
    description: 'Favorites (named tool settings, as in Archicad): list them, save one from an element, apply one to elements (their type and settings, not their place), or make one the settings its tool places new elements with (set_defaults).',
    parameters: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'save', 'apply', 'set_defaults'] }, name: { type: 'string' }, kind: { type: 'string', description: 'Element kind to list (wall, door, floor...)' }, ids: { type: 'array', items: { type: 'string' } } }, required: ['action'] },
    run(app, { action, name, kind, ids }) {
      const doc = app.doc;
      const els = (ids?.length ? ids : [...app.selection]).map((id) => doc.get(id)).filter(Boolean);
      if (action === 'list') {
        const kinds = kind ? [kind] : [...new Set(doc.all('favorite').map((f) => f.elementKind))];
        return { favorites: kinds.flatMap((k) => favoritesFor(doc, k).map((f) => ({ name: f.name, kind: f.elementKind, type: doc.get(f.typeId)?.name }))) };
      }
      if (!name) return { error: 'Give the favorite a name' };
      if (action === 'save') {
        const el = els[0];
        if (!el) return { error: 'Select the element to take the settings from' };
        app.commit('Save favorite', () => doc.add(favoriteFrom(doc, el, uniqueName(doc.all('favorite').map((f) => f.name), name))));
        return { saved: name, kind: el.kind };
      }
      const fav = doc.all('favorite').find((f) => f.name.toLowerCase() === String(name).toLowerCase());
      if (!fav) return { error: `No favorite named ${name}` };
      if (action === 'set_defaults') {
        if (fav.typeId && doc.has(fav.typeId)) app.setCurrentType?.(fav.elementKind, fav.typeId);
        app.armFavorite?.(fav.elementKind, fav.id);
        return { defaults: fav.elementKind, favorite: fav.name };
      }
      const fit = els.filter((el) => el.kind === fav.elementKind);
      if (!fit.length) return { error: `Select ${fav.elementKind} elements to apply it to` };
      app.commit('Apply favorite', () => fit.forEach((el) => doc.update(el.id, favoritePatch(doc, fav, el))));
      return { applied: fav.name, elements: fit.length };
    },
  },
  {
    name: 'layers',
    description: 'Layers and layer combinations (as in Archicad): list them with their state in a view, show, hide or lock a layer, apply a layer combination to a view, or store the current layer states as a combination.',
    parameters: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'set', 'apply_combination', 'store_combination'] }, layer: { type: 'string' }, hidden: { type: 'boolean' }, locked: { type: 'boolean' }, combination: { type: 'string' }, view: { type: 'string', description: 'View name (default: the active view)' } }, required: ['action'] },
    run(app, { action, layer, hidden, locked, combination, view }) {
      const doc = app.doc;
      const v = view ? findView(doc, view) : app.activeView;
      const combos = doc.all('layerCombo');
      if (action === 'list') return { view: v?.name, combination: v?.layerComboId ? doc.get(v.layerComboId)?.name : null, combinations: combos.map((c) => c.name), layers: layersInOrder(doc).map((l) => ({ name: l.name, ...layerState(doc, v, l.id) })) };
      if (action === 'set') {
        const l = layersInOrder(doc).find((x) => x.name.toLowerCase() === String(layer || '').toLowerCase()) || layersInOrder(doc).find((x) => x.name.toLowerCase().includes(String(layer || '').toLowerCase()));
        if (!l) return { error: `No layer ${layer}` };
        const patch = {};
        if (hidden !== undefined) patch.hidden = !!hidden;
        if (locked !== undefined) patch.locked = !!locked;
        app.commit('Layer', () => setLayerState(doc, v, l.id, patch));
        return { layer: l.name, ...layerState(doc, v, l.id) };
      }
      if (action === 'store_combination') {
        if (!combination) return { error: 'Give the combination a name' };
        app.commit('Store layer combination', () => doc.add({ kind: 'layerCombo', name: combination, states: Object.fromEntries(doc.all('layer').map((l) => [l.id, { hidden: !!l.hidden, locked: !!l.locked, wireframe: !!l.wireframe }])) }));
        return { stored: combination };
      }
      const c = combos.find((x) => x.name.toLowerCase() === String(combination || '').toLowerCase()) || combos.find((x) => x.name.toLowerCase().includes(String(combination || '').toLowerCase()));
      if (!c || !v) return { error: !v ? 'No view' : `No layer combination ${combination}` };
      app.commit('Layer combination', () => doc.update(v.id, { layerComboId: c.id }));
      return { view: v.name, combination: c.name };
    },
  },
  {
    name: 'set_view_range',
    description: "A plan view's cut plane (as Archicad's Floor Plan Cut Plane): the height it cuts at and how far below it shows, in mm above its level.",
    parameters: { type: 'object', properties: { view: { type: 'string' }, cut_height: { type: 'number' }, view_depth: { type: 'number' } } },
    run(app, { view, cut_height, view_depth }) {
      const doc = app.doc;
      const v = view ? findView(doc, view) : app.activeView;
      if (!v || !['plan', 'ceilingPlan', 'areaPlan'].includes(v.kind)) return { error: 'Name a plan view (or open one)' };
      const patch = {};
      if (Number.isFinite(+cut_height)) patch.cutHeight = +cut_height;
      if (Number.isFinite(+view_depth)) patch.viewDepth = +view_depth;
      if (Object.keys(patch).length) app.commit('View range', () => doc.update(v.id, patch));
      const now = doc.get(v.id);
      return { view: now.name, cut_height: +now.cutHeight || 1200, view_depth: +now.viewDepth || 0 };
    },
  },
  {
    name: 'set_view_phase',
    description: "A view's phase and phase filter (as Archicad's renovation filter): which construction phase it shows and how existing, demolished and new elements look.",
    parameters: { type: 'object', properties: { view: { type: 'string' }, phase: { type: 'string' }, filter: { type: 'string', enum: PHASE_FILTERS.map((f) => f.value) } } },
    run(app, { view, phase, filter }) {
      const doc = app.doc;
      const v = view ? findView(doc, view) : app.activeView;
      if (!v) return { error: 'No view' };
      const phases = phasesInOrder(doc);
      const patch = {};
      if (phase) {
        const ph = phases.find((x) => x.name.toLowerCase() === String(phase).toLowerCase()) || phases.find((x) => x.name.toLowerCase().includes(String(phase).toLowerCase()));
        if (!ph) return { error: `No phase ${phase}; phases: ${phases.map((x) => x.name).join(', ')}` };
        patch.phaseId = ph.id;
      }
      if (filter) patch.phaseFilter = filter;
      if (Object.keys(patch).length) app.commit('View phase', () => doc.update(v.id, patch));
      const now = doc.get(v.id);
      return { view: now.name, phase: doc.get(now.phaseId)?.name ?? phases.at(-1)?.name, filter: now.phaseFilter || 'all', phases: phases.map((x) => x.name), filters: PHASE_FILTERS.map((f) => `${f.value}: ${f.label}`) };
    },
  },
  ...PROPERTY_TOOLS,
  ...DOC_TOOLS,
  ...FILE_TOOLS,
];

/** Tool definitions in the shape the Claude API takes. */
export function toolSchemas({ bridge = false } = {}) {
  // File tools work only through the MCP bridge, which reads and writes the disk for them.
  return TOOLS.filter((t) => bridge || !t.bridgeOnly).map((t) => ({ name: t.name, description: t.description, input_schema: t.parameters }));
}

/** Run a function; resolves to its result ({ error } when it fails). An `_image` in it is a picture for Claude. */
export async function runTool(app, name, input) {
  const t = TOOLS.find((x) => x.name === name);
  if (!t) return { error: `Unknown function ${name}` };
  try {
    return (await t.run(app, input || {})) ?? { ok: true };
  } catch (err) {
    return { error: err.message || String(err) };
  }
}

/** A function result as Claude API tool_result content: text, and the picture when there is one. */
export function resultContent(result) {
  const { _image, ...rest } = result || {};
  const text = JSON.stringify(rest).slice(0, 12000);
  return _image ? [{ type: 'text', text }, { type: 'image', source: { type: 'base64', media_type: _image.media_type, data: _image.data } }] : text;
}
