/**
 * Assistant functions for interiors: search the object libraries in Italian or English, load the Archicad
 * libraries from this computer, make parametric furniture, place objects against a wall of a room, and add
 * any model element from a plain description.
 */
import { runGdlType } from '../core/gdlobject.js';
import { furnitureObject, FURNITURE_KINDS, matchesQuery, placeAgainst } from '../core/furniture.js';
import { ArchicadLibrary, partType } from '../core/aclib.js';
import { hexOf, paintOf, pictureMaterial, planksPicture } from '../core/finish.js';
import { deleteElements } from '../core/ops.js';
import { cameraLooking } from '../core/flythrough.js';
import { default3DView } from '../core/template.js';
import { imageForClaude } from './images.js';

const INTERIOR_PACKS = ['Beds', 'Cabinets and Shelves', 'Chairs', 'Couches and Sofas', 'Tables', 'Kitchen', 'Appliances', 'Decoration', 'Light Sources', 'Plumbing Fixtures and Bathroom', 'Office and School Equipment', 'Furniture Macros', 'Object Macros', 'Essential Library'];
const ADDABLE = new Set(['floor', 'ceiling', 'column', 'beam', 'roof', 'stair', 'railing', 'ramp', 'door', 'window', 'opening', 'room', 'morph', 'shell', 'topo', 'duct', 'pipe', 'component', 'wall']);
const TYPE_KIND = { floor: 'floorType', ceiling: 'ceilingType', column: 'columnType', beam: 'beamType', roof: 'roofType', stair: 'stairType', railing: 'railingType', ramp: 'rampType', door: 'doorType', window: 'windowType', duct: 'ductType', pipe: 'pipeType', component: 'componentType', wall: 'wallType' };

/** What an element has from its type, and so cannot take as its own field. */
const IGNORED_FIELDS = { wall: ['thickness', 'width'], floor: ['thickness', 'elevation', 'z'], ceiling: ['thickness', 'z'], roof: ['thickness'] };

const levelOf = (doc, name) => {
  const all = doc.levels();
  if (name == null || name === '') return all[0];
  const n = String(name).toLowerCase();
  return all.find((l) => l.id === name || l.name.toLowerCase() === n) || all.find((l) => l.name.toLowerCase().includes(n)) || null;
};

/** The extent of a room: { x0, y0, x1, y1 } of its floor, or null. */
function roomBox(app, room) {
  const outer = app.scene.rooms.room(room)?.outer || room.boundary;
  if (!outer?.length) return null;
  return { x0: Math.min(...outer.map((p) => p[0])), y0: Math.min(...outer.map((p) => p[1])), x1: Math.max(...outer.map((p) => p[0])), y1: Math.max(...outer.map((p) => p[1])) };
}

const roomNamed = (doc, name) => {
  const n = String(name ?? '').toLowerCase();
  const all = doc.all('room');
  return all.find((r) => r.id === name || r.name?.toLowerCase() === n || String(r.number).toLowerCase() === n) || all.find((r) => r.name?.toLowerCase().includes(n)) || null;
};

/** The plan extent of a placed object from its mesh. */
const extent = (app, el) => {
  const b = app.scene.mesh(el)?.bounds;
  return b ? { x0: b.min[0], y0: b.min[1], x1: b.max[0], y1: b.max[1], z0: b.min[2], z1: b.max[2] } : null;
};

/** Whether two pieces are in each other's way. A lamp on a table is not, nor a picture above a bed, nor a rug under anything. */
const FLAT = 60;
const overlaps = (a, b) => a.x0 < b.x1 - 1 && b.x0 < a.x1 - 1 && a.y0 < b.y1 - 1 && b.y0 < a.y1 - 1 && a.z0 < b.z1 - 1 && b.z0 < a.z1 - 1 && a.z1 - a.z0 > FLAT && b.z1 - b.z0 > FLAT;

const SIDE_TURN = { north: 0, west: 90, south: 180, east: -90 };
const sideOf = (v) => (SIDE_TURN[String(v).toLowerCase()] != null ? String(v).toLowerCase() : null);

/** How far to move a piece, from where it really is, so that its outline touches a wall of a room. */
function towardWall(mine, box, side, along, gap) {
  const a = Math.max(0, Math.min(1, along ?? 0.5));
  const w = mine.x1 - mine.x0;
  const d = mine.y1 - mine.y0;
  const dx = box.x0 + (box.x1 - box.x0 - w) * a - mine.x0;
  const dy = box.y0 + (box.y1 - box.y0 - d) * a - mine.y0;
  if (side === 'north') return [dx, box.y1 - gap - mine.y1];
  if (side === 'south') return [dx, box.y0 + gap - mine.y0];
  if (side === 'east') return [box.x1 - gap - mine.x1, dy];
  return [box.x0 + gap - mine.x0, dy];
}

/** How far to move a piece so that it stands on one side of another, centred on it (slide moves it along that side). */
function besidePiece(mine, ref, side, gap, slide = 0) {
  const dx = (ref.x0 + ref.x1) / 2 - (mine.x0 + mine.x1) / 2 + slide;
  const dy = (ref.y0 + ref.y1) / 2 - (mine.y0 + mine.y1) / 2 + slide;
  if (side === 'north') return [dx, ref.y1 + gap - mine.y0];
  if (side === 'south') return [dx, ref.y0 - gap - mine.y1];
  if (side === 'east') return [ref.x1 + gap - mine.x0, dy];
  return [ref.x0 - gap - mine.x1, dy];
}

/**
 * Adds a component where it is asked for, and reports where it ended up and what it runs into. Library objects have
 * their origin anywhere (Archicad's usually at a corner), so the piece goes by its real outline, not by its origin.
 */
function putComponent(app, type0, { at, rotation, room, wall, along, level, offset, next_to, side, gap, slide, faces, ignore, width, depth, height, color, values }, placed) {
  const doc = app.doc;
  const r = room != null ? roomNamed(doc, room) : null;
  if (room != null && !r) return { error: `No room called ${room}; rooms: ${doc.all('room').map((x) => x.name).join(', ') || 'none'}` };
  const other = next_to != null ? placed?.get(next_to) || doc.get(next_to) : null;
  if (next_to != null && !other) return { error: `next_to: no element ${next_to}` };
  const lv = r ? doc.get(r.levelId) : other ? doc.get(other.levelId) : levelOf(doc, level);
  if (!lv) return { error: `No level ${level}` };
  const onWall = sideOf(wall);
  const onSide = other ? sideOf(side) || 'south' : null;
  if (!at && !onWall && !other && !r) return { error: 'Give at: [x, y] in mm, or room and wall (north, south, east, west), or next_to and side' };
  const box = r ? roomBox(app, r) : null;
  if (r && !box) return { error: `Room ${r.name} has no floor outline yet: it needs walls round it` };
  const turn = rotation != null ? +rotation : onWall ? SIDE_TURN[onWall] : other && faces !== false ? SIDE_TURN[onSide] : 0;
  const start = at || (other ? other.at : r.at);
  const { type, own } = sizedType(doc, type0, { width, depth, height });
  const paint = color != null ? hexOf(color) : null;
  const set = ownValues(doc, type, values);
  const gdlValues = { ...own, ...set.values };
  const el = doc.add({ kind: 'component', typeId: type.id, levelId: lv.id, at: [+start[0], +start[1]], rotation: turn, offset: +offset || 0, ...(Object.keys(gdlValues).length ? { gdlValues } : {}), ...(paint ? { paintId: paintOf(doc, paint).id } : {}) });
  let mine = extent(app, el);
  if (mine && !at && (onWall || other || r)) {
    const pad = gap != null ? +gap : other ? 150 : 10;
    const refBox = other ? extent(app, other) : null;
    const move = refBox ? besidePiece(mine, refBox, onSide, pad, +slide || 0) : onWall ? towardWall(mine, box, onWall, along, pad) : [(box.x0 + box.x1 - mine.x0 - mine.x1) / 2, (box.y0 + box.y1 - mine.y0 - mine.y1) / 2];
    doc.update(el.id, { at: [Math.round(el.at[0] + move[0]), Math.round(el.at[1] + move[1])] });
    mine = { ...mine, x0: mine.x0 + move[0], y0: mine.y0 + move[1], x1: mine.x1 + move[0], y1: mine.y1 + move[1] };
  }
  const skip = new Set([el.id, other?.id, ...(ignore || [])]);
  const hits = mine ? doc.all('component').filter((o) => !skip.has(o.id) && o.levelId === lv.id && (() => { const x = extent(app, o); return x && overlaps(mine, x); })()).map((o) => doc.get(o.typeId)?.name) : [];
  const out = box && mine && (mine.x0 < box.x0 - 1 || mine.y0 < box.y0 - 1 || mine.x1 > box.x1 + 1 || mine.y1 > box.y1 + 1);
  const quarter = Math.abs(Math.round(turn)) % 180 === 90;
  const real = mine ? [mine.x1 - mine.x0, mine.y1 - mine.y0].map(Math.round) : null;
  const [realW, realD] = real && quarter ? [real[1], real[0]] : real || [];
  const missed = real && ((+width && Math.abs(realW - +width) > +width * 0.05) || (+depth && Math.abs(realD - +depth) > +depth * 0.05));
  const warnings = [missed ? `Asked for ${+width || realW} x ${+depth || realD} mm, it came out ${realW} x ${realD} mm: this object takes its size from its own options, see object_parameters` : '', hits.length ? `It overlaps: ${hits.join(', ')}` : '', out ? `It sticks out of ${r.name}` : '', set.unknown.length ? `No such parameters: ${set.unknown.join(', ')}` : ''].filter(Boolean);
  return { id: el.id, at: doc.get(el.id).at, rotation: turn, plan_extent: mine, ...(warnings.length ? { warning: warnings.join('. ') } : {}) };
}

/**
 * The parameters given for a placed object, by name whatever their case. A colour for a material parameter becomes a
 * project material, so that it can be picked and changed like any other.
 */
function ownValues(doc, type, values) {
  const out = { values: {}, unknown: [] };
  if (!values || typeof values !== 'object') return out;
  const params = type.gdl?.params || [];
  for (const [name, v] of Object.entries(values)) {
    const p = params.find((x) => x.name.toLowerCase() === name.toLowerCase());
    if (!p) {
      out.unknown.push(name);
      continue;
    }
    const hex = p.kind === 'material' && typeof v === 'string' && !doc.get(v) ? hexOf(v) : null;
    out.values[p.name] = hex ? paintOf(doc, hex).id : v;
  }
  return out;
}

/**
 * A placed object of the size asked for: a GDL object keeps its type and has its own size; a catalogue
 * object has its size in its type, so it gets a type of that size.
 */
function sizedType(doc, type, { width, depth, height }) {
  const want = { width: +width || 0, depth: +depth || 0, height: +height || 0 };
  const same = (k) => !want[k] || Math.abs(want[k] - +type[k]) < 1;
  if (same('width') && same('depth') && same('height')) return { type, own: null };
  if (type.family === 'gdl') {
    const own = {};
    if (want.width) own.A = want.width;
    if (want.depth) own.B = want.depth;
    if (want.height) own.ZZYZX = want.height;
    // Some objects are sized by what they hold (a bed by its mattress); the frame round it stays as it is.
    const nominal = (name, asked, whole) => {
      const p = asked ? type.gdl?.params?.find((x) => x.name.toLowerCase() === name) : null;
      if (p && +p.value > 0 && +whole > +p.value) own[p.name] = asked - (+whole - +p.value);
    };
    nominal('nominalwidth', want.width, type.width);
    nominal('nominallength', want.depth, type.depth);
    return { type, own };
  }
  const size = { width: want.width || type.width, depth: want.depth || type.depth, height: want.height || type.height };
  const twin = doc.all('componentType').find((t) => t.family === type.family && t.category === type.category && t.width === size.width && t.depth === size.depth && t.height === size.height);
  if (twin) return { type: twin, own: null };
  const { id, ...rest } = type;
  return { type: doc.add({ ...rest, ...size, name: `${Math.round(size.width)} x ${Math.round(size.depth)} x ${Math.round(size.height)} mm` }), own: null };
}

/** The picture a piece shows, cut from a placed image: read before the change, because reading it takes time. */
async function cutPicture(app, from) {
  const img = from.image_id ? app.doc.get(from.image_id) : app.doc.all('image').at(-1);
  if (img?.kind !== 'image') return { error: 'from_image: no such image; use list_images' };
  const src = img.src;
  if (!src) return { error: 'from_image: the picture could not be read' };
  const pic = await imageForClaude(src, from.region || null, 1024);
  return { url: `data:${pic.media_type};base64,${pic.data}` };
}

function placeComponent(app, type, spec) {
  let out;
  app.commit('Assistant: place object', () => {
    out = putComponent(app, type, spec);
  });
  return out;
}

/** The project type a library reference names, bringing the part into the project the first time. */
function typeOfRef(app, ref) {
  const doc = app.doc;
  const key = String(ref);
  if (key.startsWith('type:')) {
    const t = doc.get(key.slice(5));
    return t?.kind === 'componentType' ? { type: t } : { error: `${ref} is not a placeable object; find one with library_search` };
  }
  if (!key.startsWith('lib:')) return { error: `${ref} is not a placeable object; find one with library_search` };
  const e = app.acLibrary?.get(key.slice(4));
  if (!e) return { error: `${ref} is not in the loaded libraries` };
  return { type: doc.all('componentType').find((t) => t.name === e.name && t.family === 'gdl') || doc.add(partType(app.acLibrary, e)) };
}

/** Where n chairs go round a table: along its long sides first, then at its ends. */
export function seatsAround(w, d, n) {
  const long = w >= d ? ['north', 'south'] : ['east', 'west'];
  const short = w >= d ? ['east', 'west'] : ['north', 'south'];
  const L = Math.max(w, d);
  const fit = Math.max(1, Math.floor(L / 600));
  const onLong = Math.min(n, fit * 2);
  const seats = [];
  for (let s = 0; s < 2; s++) {
    const here = Math.ceil((onLong - s) / 2);
    for (let i = 0; i < here; i++) seats.push({ side: long[s], slide: (i - (here - 1) / 2) * (L / Math.max(here, 1)) });
  }
  for (let i = 0; i < Math.min(n - onLong, 2); i++) seats.push({ side: short[i], slide: 0 });
  return seats;
}

/** A new furniture type from a description; a picture shows what was cut from an image. Inside a transaction. */
function makePiece(app, spec, cut) {
  const doc = app.doc;
  const fields = furnitureObject(cut ? { ...spec, image: cut.url } : spec);
  const check = runGdlType(fields);
  if (check.error) return { error: check.error };
  return { type: doc.add({ kind: 'componentType', family: 'gdl', familyName: 'GDL Object', ...fields }), triangles: check.tris.length };
}

export const INTERIOR_TOOLS = [
  {
    name: 'library_search',
    description: 'Find furniture and objects to place, in Italian or English (armadio, divano, wardrobe...): the project\'s catalogue and every Archicad library loaded. Returns a ref for place_object, with the size in mm. Empty? library_load brings in the interior libraries, or make_furniture makes the piece to measure.',
    parameters: { type: 'object', properties: { query: { type: 'string' }, limit: { type: 'number' } }, required: ['query'] },
    run(app, { query, limit = 25 }) {
      const out = [];
      for (const t of app.doc.all('componentType')) if (matchesQuery(`${t.name} ${t.familyName || ''} ${t.category || ''}`, query)) out.push({ ref: `type:${t.id}`, name: t.name, family: t.familyName, category: t.category, width: t.width, depth: t.depth, height: t.height, source: 'project' });
      const lib = app.acLibrary;
      if (lib) for (const e of lib.objects()) if (matchesQuery(`${e.name} ${e.path}`, query)) out.push({ ref: `lib:${e.name}`, name: e.name, folder: e.path.split('/').slice(0, -1).join('/'), source: 'Archicad library' });
      return { count: out.length, results: out.slice(0, +limit || 25), archicad_library_loaded: !!lib?.parts?.size };
    },
  },
  {
    name: 'library_preview',
    description: 'See what objects of the loaded Archicad libraries look like, side by side, to choose the one closest to what you want: names is a list of names from library_search (up to 16). Returns a picture of their catalogue previews, in that order.',
    parameters: { type: 'object', properties: { names: { type: 'array', items: { type: 'string' } } }, required: ['names'] },
    async run(app, { names }) {
      const lib = app.acLibrary;
      if (!lib) return { error: 'No library is loaded; use library_load' };
      const list = (names || []).slice(0, 16).map((n) => String(n).replace(/^lib:/, '')).map((name) => ({ name, pic: lib.get(name)?.lp?.preview }));
      const shown = [];
      for (const it of list) {
        if (!it.pic) continue;
        try {
          shown.push({ name: it.name, bmp: await createImageBitmap(new Blob([it.pic.bytes], { type: it.pic.mime })) });
        } catch {
          // A preview that cannot be read is left out, and listed below.
        }
      }
      if (!shown.length) return { error: 'None of these has a preview', names };
      const cell = 240;
      const label = 26;
      const cols = Math.min(4, shown.length);
      const rows = Math.ceil(shown.length / cols);
      const cv = document.createElement('canvas');
      cv.width = cols * cell;
      cv.height = rows * (cell + label);
      const g = cv.getContext('2d');
      g.fillStyle = '#fff';
      g.fillRect(0, 0, cv.width, cv.height);
      g.font = '15px sans-serif';
      g.textAlign = 'center';
      shown.forEach(({ name, bmp }, i) => {
        const x = (i % cols) * cell;
        const y = Math.floor(i / cols) * (cell + label);
        const k = Math.min((cell - 12) / bmp.width, (cell - 12) / bmp.height);
        g.drawImage(bmp, x + (cell - bmp.width * k) / 2, y + (cell - bmp.height * k) / 2, bmp.width * k, bmp.height * k);
        g.fillStyle = '#000';
        g.fillText(name, x + cell / 2, y + cell + 18, cell - 8);
      });
      const url = cv.toDataURL('image/jpeg', 0.85);
      return { shown: shown.map((s) => s.name), without_preview: list.filter((it) => !shown.some((s) => s.name === it.name)).map((it) => it.name), _image: { media_type: 'image/jpeg', data: url.slice(url.indexOf(',') + 1) } };
    },
  },
  {
    name: 'object_parameters',
    description: 'What can be set on an object before placing it: its size in mm, its material parameters (give a #rrggbb or a material id in values) and its other options, by name. Objects come plain: switch on in values what you want to see (bPillow: 1 for a bed\'s pillows, 0 or 1 for parts and picture options: a Carpet with bPict 1 shows a stock rug picture, with bPict 0 its carpet_mat). ref is what library_search gave.',
    parameters: { type: 'object', properties: { ref: { type: 'string' } }, required: ['ref'] },
    run(app, { ref }) {
      const key = String(ref);
      const e = key.startsWith('lib:') ? app.acLibrary?.get(key.slice(4)) : null;
      const type = e ? partType(app.acLibrary, e) : key.startsWith('type:') ? app.doc.get(key.slice(5)) : null;
      if (!type) return { error: `${ref} is not a placeable object; find one with library_search` };
      const row = (p) => ({ name: p.name, value: p.value });
      const params = (type.gdl?.params || []).filter((p) => !/^(ac_|gs_ui|gs_list|FM_|ifc_)/i.test(p.name) && !['title', 'separator'].includes(p.kind));
      const other = params.filter((p) => ['boolean', 'integer', 'string', 'length', 'number', 'angle'].includes(p.kind) && !Array.isArray(p.value) && !/^(iDetLev|gs_shadow|gs_detlevel|gs_cont_|gs_fill_|gs_back_|fill|pen|back|MS[A-Z]|iSymbol|iFMType|bUniformFill|gs_resol)/.test(p.name));
      return { name: type.name, width: type.width, depth: type.depth, height: type.height, materials: params.filter((p) => p.kind === 'material').map(row), options: other.slice(0, 50).map(row), more: Math.max(0, other.length - 50) };
    },
  },
  {
    name: 'library_load',
    description: 'Load the interior object libraries of the Archicad installed on this computer (furniture, kitchens, bathrooms, lighting, decoration), when the app runs on it. On the website, or without Archicad, the user loads them with File > Libraries; make_furniture needs no library.',
    parameters: { type: 'object', properties: { packs: { type: 'array', items: { type: 'string' }, description: 'Names of library packs; by default the interior ones' } } },
    async run(app, { packs }) {
      let list;
      try {
        const res = await fetch('./api/archicad-libraries');
        if (!res.ok || !/json/.test(res.headers.get('content-type') || '')) throw new Error('none');
        list = (await res.json()).files;
      } catch {
        return { error: 'The Archicad libraries are not reachable from here. Use make_furniture and the project catalogue, or ask the user to load them with the Archicad Library command.' };
      }
      const want = (Array.isArray(packs) && packs.length ? packs : INTERIOR_PACKS).map((p) => String(p).toLowerCase());
      const chosen = list.filter((f) => want.includes(f.replace(/\.libpack$/i, '').toLowerCase()));
      app.acLibrary ||= new ArchicadLibrary();
      let added = 0;
      for (const f of chosen) {
        if (app.acLibrary.files.some((x) => x.name === f)) continue;
        const res = await fetch(`./api/archicad-libraries?file=${encodeURIComponent(f)}`);
        if (res.ok) added += app.acLibrary.add(f, new Uint8Array(await res.arrayBuffer()));
      }
      return { packs: chosen.length, parts_added: added, objects: app.acLibrary.objects().length, available: list.map((f) => f.replace(/\.libpack$/i, '')) };
    },
  },
  {
    name: 'make_furniture',
    description: `Make a piece of furniture to measure, when the libraries have nothing like it or are not available, as a parametric object (its doors, drawers, shelves and size stay editable), and place it if asked. kind: ${FURNITURE_KINDS.join(', ')}. Sizes in mm; colours by name (white, oak, walnut, grey, black, blue, green, or Italian) or #rrggbb, and #rrggbb read from a photo is better than a name. Place with room and wall (north, south, east, west; along 0..1 from one end), its back to that wall, or with at: [x, y]. bed: color is the wood, front_color the bedding, accent_color a throw at the foot, top_color the big pillows, pillow_color the small ones. closet: glass doors over glass_share of its width (0..1), hanging space on the left, shelves on the right. table_lamp: color the base, front_color the shade. picture: hung with offset = height of its bottom edge above the floor, depth 30; from_image { image_id, region: [x0, y0, x1, y1] in full-image pixels } makes it show that part of a placed image, so a painting in a photo is the painting. curtain: sheer unless opaque is true; depth is how deep its folds are.`,
    parameters: {
      type: 'object',
      properties: {
        kind: { type: 'string', enum: FURNITURE_KINDS },
        name: { type: 'string' },
        width: { type: 'number' },
        depth: { type: 'number' },
        height: { type: 'number' },
        doors: { type: 'number' },
        drawers: { type: 'number' },
        shelves: { type: 'number' },
        color: { type: 'string' },
        front_color: { type: 'string' },
        top_color: { type: 'string' },
        accent_color: { type: 'string' },
        pillow_color: { type: 'string' },
        glass_share: { type: 'number' },
        frame: { type: 'number' },
        opaque: { type: 'boolean' },
        from_image: { type: 'object', properties: { image_id: { type: 'string' }, region: { type: 'array', items: { type: 'number' } } } },
        room: { type: 'string' },
        wall: { type: 'string', enum: ['north', 'south', 'east', 'west'] },
        along: { type: 'number' },
        at: { type: 'array', items: { type: 'number' } },
        rotation: { type: 'number' },
        level: { type: 'string' },
        offset: { type: 'number', description: 'Height above the level, mm; a kitchen wall unit is usually 1400' },
      },
      required: ['kind'],
    },
    async run(app, input) {
      const cut = input.from_image ? await cutPicture(app, input.from_image) : null;
      if (cut?.error) return cut;
      const out = {};
      const { width: _w, depth: _d, height: _h, color: _c, ...where } = input;
      app.commit('Assistant: furniture', () => {
        const made = makePiece(app, input, cut);
        if (made.error) return Object.assign(out, made);
        const { type, triangles } = made;
        Object.assign(out, { type: type.id, name: type.name, width: type.width, depth: type.depth, height: type.height, triangles });
        if (input.room != null || input.at || input.next_to != null) {
          const r = putComponent(app, type, { ...where, offset: input.offset ?? (input.kind === 'kitchen_wall' ? 1400 : 0) });
          Object.assign(out, r);
        }
      });
      return out;
    },
  },
  {
    name: 'place_object',
    description: 'Place an object found with library_search, by its ref, optionally at a size (width, depth, height in mm), with its own parameters (values: { name: value } from object_parameters; a material parameter takes #rrggbb) and in one colour over the whole object (color, for a rug or a curtain). Against a wall of a room (room and wall: north, south, east, west; along 0..1), its back to it; beside another piece (next_to: its id, side: north, south, east or west of it, gap in mm, slide along that side), facing it unless faces is false; in the middle of a room (room alone); or at [x, y] in mm with a rotation in degrees. It goes by the object\'s real outline. Answers where it went and what it overlaps. For several pieces use place_objects.',
    parameters: { type: 'object', properties: { ref: { type: 'string' }, room: { type: 'string' }, wall: { type: 'string', enum: ['north', 'south', 'east', 'west'] }, along: { type: 'number' }, next_to: { type: 'string' }, side: { type: 'string', enum: ['north', 'south', 'east', 'west'] }, gap: { type: 'number' }, slide: { type: 'number' }, faces: { type: 'boolean' }, at: { type: 'array', items: { type: 'number' } }, rotation: { type: 'number' }, level: { type: 'string' }, offset: { type: 'number' }, width: { type: 'number' }, depth: { type: 'number' }, height: { type: 'number' }, color: { type: 'string' }, values: { type: 'object' } }, required: ['ref'] },
    run(app, input) {
      let out;
      app.commit('Assistant: place object', () => {
        const { type, error } = typeOfRef(app, input.ref);
        out = error ? { error } : putComponent(app, type, input);
      });
      return out;
    },
  },
  {
    name: 'place_objects',
    description: 'Furnish in one go, one undo step: much quicker than one call per piece. items: each is what place_object takes (ref) or what make_furniture takes (kind), with these additions: key, a name for the piece that later items use in next_to; around: the key or id of a table, with count, to set that many of this chair round it, tucked in. A sofa, then a coffee table next_to it on the side it faces, then chairs around a table, in one list. Answers per item, with warnings.',
    parameters: { type: 'object', properties: { items: { type: 'array', items: { type: 'object' } } }, required: ['items'] },
    async run(app, { items }) {
      if (!Array.isArray(items) || !items.length) return { error: 'Give items' };
      const doc = app.doc;
      const placed = new Map();
      const results = [];
      const cuts = new Map();
      for (const item of items) if (item.from_image) cuts.set(item, await cutPicture(app, item.from_image));
      app.commit('Assistant: furnish', () => {
        for (const item of items) {
          let type;
          const cut = cuts.get(item);
          if (cut?.error) {
            results.push({ key: item.key, error: cut.error });
            continue;
          }
          if (item.kind) {
            const made = makePiece(app, item, cut);
            if (made.error) {
              results.push({ key: item.key, error: made.error });
              continue;
            }
            type = made.type;
          } else {
            const found = typeOfRef(app, item.ref);
            if (found.error) {
              results.push({ key: item.key, error: found.error });
              continue;
            }
            type = found.type;
          }
          if (item.around != null) {
            const table = placed.get(item.around) || doc.get(item.around);
            const box = table && extent(app, table);
            if (!box) {
              results.push({ key: item.key, error: `around: no element ${item.around}` });
              continue;
            }
            const ids = [];
            for (const seat of seatsAround(box.x1 - box.x0, box.y1 - box.y0, Math.max(1, +item.count || 4))) {
              const r = putComponent(app, type, { next_to: table.id, gap: item.gap ?? -120, ...seat, ignore: ids }, placed);
              if (r.id) ids.push(r.id);
              results.push({ key: item.key, name: type.name, ...r });
            }
            continue;
          }
          const offset = item.offset ?? (item.kind === 'kitchen_wall' ? 1400 : 0);
          // A made piece has its size and colours already; a library piece takes them here.
          const r = putComponent(app, type, item.kind ? { ...item, width: undefined, depth: undefined, height: undefined, color: undefined, offset } : { ...item, offset }, placed);
          if (r.id && item.key != null) placed.set(item.key, doc.get(r.id));
          results.push({ key: item.key, name: type.name, ...r });
        }
      });
      return { placed: results.filter((r) => r.id).length, results };
    },
  },
  {
    name: 'add_elements',
    description: `Add model elements from a description, several at once (one undo step). Each item: { kind: ${[...ADDABLE].join('|')}, level (name), type (name of its type, optional), color (optional, a paint), and the element's own fields in mm }. A wall's or a slab's thickness comes from its type. The answer lists under ignored what had no effect. floor/ceiling/roof: boundary [[x,y]...] (roof also slopes [degrees per edge]; ceiling: offset, its height above the level in mm); column/component: at [x,y]; beam/stair/ramp/wall/duct/pipe: a [x,y], b [x,y]; railing: path; door/window/opening: host (wall id) and t (mm along it), window sill; room: at, name. Use trace_floor_plan for whole plans.`,
    parameters: { type: 'object', properties: { items: { type: 'array', items: { type: 'object' } } }, required: ['items'] },
    run(app, { items }) {
      const doc = app.doc;
      if (!Array.isArray(items) || !items.length) return { error: 'Give items' };
      const made = [];
      const failed = [];
      const ignored = [];
      app.commit('Assistant: add elements', () => {
        for (const raw of items) {
          const { kind, level, top_level, type, host, color, ...fields } = raw || {};
          for (const key of Object.keys(fields)) {
            if (IGNORED_FIELDS[kind]?.includes(key)) {
              ignored.push(`${kind}.${key}`);
              delete fields[key];
            }
          }
          if (!ADDABLE.has(kind)) {
            failed.push({ kind, error: 'This kind cannot be added here' });
            continue;
          }
          const lv = levelOf(doc, level);
          const el = { kind, ...fields };
          if (lv && !['door', 'window', 'opening'].includes(kind)) el.levelId = lv.id;
          const top = top_level ? levelOf(doc, top_level) : kind === 'wall' || kind === 'column' || kind === 'stair' ? doc.levelAbove(lv?.id) : null;
          if (top) el.topLevelId = top.id;
          const tk = TYPE_KIND[kind];
          if (tk) {
            const list = doc.all(tk);
            const t = (type != null && (list.find((x) => x.id === type || x.name.toLowerCase() === String(type).toLowerCase()) || list.find((x) => x.name.toLowerCase().includes(String(type).toLowerCase())))) || list[0];
            if (!t) {
              failed.push({ kind, error: `No ${tk} in the project` });
              continue;
            }
            el.typeId = t.id;
          }
          if (host) el.hostId = host;
          if (color != null) {
            const hex = hexOf(color);
            if (hex) el.paintId = paintOf(doc, hex).id;
            else ignored.push(`${kind}.color (${color} is not a colour)`);
          }
          if (kind === 'wall') Object.assign(el, { baseOffset: 0, topOffset: 0, height: 3000, locationLine: 'center', joinA: true, joinB: true, roomBounding: true, ...el });
          // A ceiling's height above its level is its offset, whatever it is called; one left on the floor is never meant.
          if (kind === 'ceiling') {
            const up = [raw.offset, raw.elevation, raw.height].map(Number).find((v) => v > 0);
            delete el.elevation;
            delete el.height;
            el.offset = up || 2700;
          }
          if (kind === 'floor' || kind === 'ceiling') Object.assign(el, { holes: [], offset: 0, ...el });
          if (kind === 'roof') Object.assign(el, { baseOffset: 0, ...el });
          if (kind === 'room') Object.assign(el, { number: el.number ?? String(doc.all('room').length + 1), name: el.name ?? 'Room', upperOffset: el.upperOffset ?? 2700 });
          if (kind === 'column' || kind === 'component') Object.assign(el, { rotation: 0, ...el });
          try {
            made.push({ id: doc.add(el).id, kind });
          } catch (err) {
            failed.push({ kind, error: String(err.message || err) });
          }
        }
      });
      return { made, failed, ...(ignored.length ? { ignored: [...new Set(ignored)] } : {}) };
    },
  },
  {
    name: 'set_finish',
    description: 'Give existing elements a finish: their look in 3D, without changing their type. ids, or kind (wall, floor, ceiling...) for every element of that kind. color: #rrggbb read from what you see, or a name. pattern: planks draws wooden boards in that colour (plank width in mm, direction x or y: the way the boards run). from_image { image_id, region, width, height } uses that part of a placed image as a repeating surface, width and height in mm being the real size of the part. clear: true takes the finish off.',
    parameters: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' } }, kind: { type: 'string' }, color: { type: 'string' }, pattern: { type: 'string', enum: ['planks'] }, plank: { type: 'number' }, direction: { type: 'string', enum: ['x', 'y'] }, from_image: { type: 'object' }, clear: { type: 'boolean' } } },
    async run(app, { ids, kind, color, pattern, plank, direction, from_image, clear }) {
      const doc = app.doc;
      const els = (Array.isArray(ids) && ids.length ? ids.map((id) => doc.get(id)).filter(Boolean) : kind ? doc.all(kind) : []).filter((e) => !e.kind?.endsWith('Type'));
      if (!els.length) return { error: 'Give ids of elements, or a kind of element the project has' };
      if (clear) {
        app.commit('Assistant: clear finish', () => els.forEach((e) => doc.update(e.id, { paintId: null })));
        return { cleared: els.length };
      }
      const hex = color != null ? hexOf(color) : '#8a8580';
      if (!hex) return { error: `${color} is not a colour; give #rrggbb` };
      let surface = null;
      if (from_image) {
        const cut = await cutPicture(app, from_image);
        if (cut.error) return cut;
        surface = { image: cut.url, w: +from_image.width || 1000, h: +from_image.height || 1000 };
      } else if (pattern === 'planks') {
        if (typeof document === 'undefined') return { error: 'Patterns are drawn in the browser' };
        surface = { ...planksPicture(hex, { plank: +plank || 180 }), angle: direction === 'y' ? 90 : 0 };
      }
      let mat;
      app.commit('Assistant: finish', () => {
        mat = surface ? pictureMaterial(doc, pattern === 'planks' ? `Boards ${hex}` : 'Surface from image', hex, surface) : paintOf(doc, hex);
        for (const e of els) doc.update(e.id, { paintId: mat.id });
      });
      return { painted: els.length, material: mat.name };
    },
  },
  {
    name: 'set_camera',
    description: 'Stand a camera at a point, looking at another, in a named 3D view that stays in the project and opens: eye and target are [x, y, z] in mm, z above project zero. fov: the vertical field of view in degrees (a phone or an interior photo is usually 45 to 60). aspect: width over height of the picture returned. style: realistic by default. lamps: true lights the lamps. Returns the picture, to compare with the photo you are rebuilding.',
    parameters: { type: 'object', properties: { eye: { type: 'array', items: { type: 'number' } }, target: { type: 'array', items: { type: 'number' } }, fov: { type: 'number' }, aspect: { type: 'number' }, name: { type: 'string' }, style: { type: 'string', enum: ['realistic', 'shaded', 'hidden'] }, lamps: { type: 'boolean' } }, required: ['eye', 'target'] },
    async run(app, { eye, target, fov = 55, aspect = 1.4, name = 'Camera view', style = 'realistic', lamps = true }) {
      const doc = app.doc;
      if (![eye, target].every((p) => Array.isArray(p) && p.length === 3 && p.every(Number.isFinite))) return { error: 'eye and target are [x, y, z] in mm' };
      const camera = { ...cameraLooking(eye, target, { fov: Math.max(15, Math.min(110, +fov || 55)) }), fitted: true };
      // Indoors the light has bounced round the room: without it a wall in shadow is far darker than in a photo.
      const patch = { camera, style, shadows: true, lampLight: !!lamps, lampDimmer: 0.55, interiorFill: 0.4 };
      let v = doc.all('view3d').find((x) => x.name === name);
      app.commit('Assistant: camera view', () => {
        if (v) doc.update(v.id, patch);
        else v = doc.add({ ...default3DView(name), ...patch });
      });
      app.viewStates?.delete(v.id);
      app.openView(v.id);
      // The view may be open already, with the camera it had.
      if (app.vc) {
        app.vc.cam = structuredClone(camera);
        app.vc.userMoved = true;
        app.requestRender?.();
      }
      app.cameraViewId = v.id;
      const { renderViewImage } = await import('../views/snapshot.js');
      const W = 1200;
      const H = Math.round(W / Math.max(0.5, Math.min(3, +aspect || 1.4)));
      const { canvas } = renderViewImage(app, doc.get(v.id), W, H, { fit: false, camera });
      const url = canvas.toDataURL('image/jpeg', 0.85);
      return { view: name, opened: true, _image: { media_type: 'image/jpeg', data: url.slice(url.indexOf(',') + 1) } };
    },
  },
  {
    name: 'remove_elements',
    description: 'Delete elements by id (what they host goes with them), one undo step. Only what you made yourself or the user asked to remove; a photo you were given as a reference, when you have finished with it.',
    parameters: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' } } }, required: ['ids'] },
    run(app, { ids }) {
      const known = (ids || []).filter((id) => app.doc.has(id));
      if (!known.length) return { error: 'No such elements' };
      app.commit('Assistant: remove elements', () => deleteElements(app.doc, known));
      return { removed: known.length };
    },
  },
];
