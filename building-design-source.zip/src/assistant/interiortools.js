/**
 * Assistant functions for interiors: search the object libraries in Italian or English, load the Archicad
 * libraries from this computer, make parametric furniture, place objects against a wall of a room, and add
 * any model element from a plain description.
 */
import { runGdlType } from '../core/gdlobject.js';
import { furnitureObject, FURNITURE_KINDS, matchesQuery, searchWords } from '../core/furniture.js';
import { ArchicadLibrary, partType } from '../core/aclib.js';
import { hexOf, paintOf, pictureMaterial, planksPicture } from '../core/finish.js';
import { deleteElements } from '../core/ops.js';
import { cameraLooking } from '../core/flythrough.js';
import { default3DView } from '../core/template.js';
import { imageForClaude } from './images.js';
import { UserLibrary, entryFromType, typeFromEntry, thumbnail } from '../core/userlib.js';
import { measurePhoto, measureObliquePhoto } from '../core/photometry.js';
import { isLamp } from '../core/lamps.js';
import { applyGdlChange } from '../core/paramscript.js';
import { levelElevation } from '../core/model.js';

const INTERIOR_PACKS = ['Electric Symbols', 'Beds', 'Cabinets and Shelves', 'Chairs', 'Couches and Sofas', 'Tables', 'Kitchen', 'Appliances', 'Decoration', 'Light Sources', 'Plumbing Fixtures and Bathroom', 'Office and School Equipment', 'Furniture Macros', 'Object Macros', 'Essential Library'];
const ADDABLE = new Set(['floor', 'ceiling', 'column', 'beam', 'roof', 'stair', 'railing', 'ramp', 'door', 'window', 'opening', 'room', 'morph', 'shell', 'topo', 'duct', 'pipe', 'component', 'wall']);
const TYPE_KIND = { floor: 'floorType', ceiling: 'ceilingType', column: 'columnType', beam: 'beamType', roof: 'roofType', stair: 'stairType', railing: 'railingType', ramp: 'rampType', door: 'doorType', window: 'windowType', duct: 'ductType', pipe: 'pipeType', component: 'componentType', wall: 'wallType' };

/** What an element has from its type, and so cannot take as its own field. */
const IGNORED_FIELDS = { wall: ['thickness', 'width'], floor: ['thickness', 'elevation', 'z'], ceiling: ['thickness', 'z'], roof: ['thickness'] };

const levelOf = (doc, name) => {
  const all = doc.levels();
  if (name == null || name === '') return all[0];
  const n = String(name).toLowerCase();
  return all.find((l) => l.id === name || l.name.toLowerCase() === n) || all.find((l) => l.name.toLowerCase().includes(n)) || null;
};

/** The extent of a room: { x0, y0, x1, y1 } of its floor, or null. */
function roomBox(app, room) {
  const outer = app.scene.rooms.room(room)?.outer || room.boundary;
  if (!outer?.length) return null;
  return { x0: Math.min(...outer.map((p) => p[0])), y0: Math.min(...outer.map((p) => p[1])), x1: Math.max(...outer.map((p) => p[0])), y1: Math.max(...outer.map((p) => p[1])) };
}

const roomNamed = (doc, name) => {
  const n = String(name ?? '').toLowerCase();
  const all = doc.all('room');
  return all.find((r) => r.id === name || r.name?.toLowerCase() === n || String(r.number).toLowerCase() === n) || all.find((r) => r.name?.toLowerCase().includes(n)) || null;
};

/** The plan extent of a placed object from its mesh. */
const extent = (app, el) => {
  const b = app.scene.mesh(el)?.bounds;
  return b ? { x0: b.min[0], y0: b.min[1], x1: b.max[0], y1: b.max[1], z0: b.min[2], z1: b.max[2] } : null;
};

/** Whether two pieces are in each other's way. A lamp on a table is not, nor a picture above a bed, nor a rug under anything. */
const FLAT = 60;
const overlaps = (a, b) => a.x0 < b.x1 - 1 && b.x0 < a.x1 - 1 && a.y0 < b.y1 - 1 && b.y0 < a.y1 - 1 && a.z0 < b.z1 - 1 && b.z0 < a.z1 - 1 && a.z1 - a.z0 > FLAT && b.z1 - b.z0 > FLAT;

const SIDE_TURN = { north: 0, west: 90, south: 180, east: -90 };
const sideOf = (v) => (SIDE_TURN[String(v).toLowerCase()] != null ? String(v).toLowerCase() : null);

/** How far to move a piece, from where it really is, so that its outline touches a wall of a room. */
function towardWall(mine, box, side, along, gap) {
  const a = Math.max(0, Math.min(1, along ?? 0.5));
  const w = mine.x1 - mine.x0;
  const d = mine.y1 - mine.y0;
  const dx = box.x0 + (box.x1 - box.x0 - w) * a - mine.x0;
  const dy = box.y0 + (box.y1 - box.y0 - d) * a - mine.y0;
  if (side === 'north') return [dx, box.y1 - gap - mine.y1];
  if (side === 'south') return [dx, box.y0 + gap - mine.y0];
  if (side === 'east') return [box.x1 - gap - mine.x1, dy];
  return [box.x0 + gap - mine.x0, dy];
}

/** How far to move a piece so that it stands on one side of another, centred on it (slide moves it along that side). */
function besidePiece(mine, ref, side, gap, slide = 0) {
  const dx = (ref.x0 + ref.x1) / 2 - (mine.x0 + mine.x1) / 2 + slide;
  const dy = (ref.y0 + ref.y1) / 2 - (mine.y0 + mine.y1) / 2 + slide;
  if (side === 'north') return [dx, ref.y1 + gap - mine.y0];
  if (side === 'south') return [dx, ref.y0 - gap - mine.y1];
  if (side === 'east') return [ref.x1 + gap - mine.x0, dy];
  return [ref.x0 - gap - mine.x1, dy];
}

/**
 * Adds a component where it is asked for, and reports where it ended up and what it runs into. Library objects have
 * their origin anywhere (Archicad's usually at a corner), so the piece goes by its real outline, not by its origin.
 */
function putComponent(app, type0, { at, rotation, room, wall, along, level, offset, next_to, side, gap, slide, faces, ignore, width, depth, height, color, values, on, shift }, placed) {
  const doc = app.doc;
  const r = room != null ? roomNamed(doc, room) : null;
  if (room != null && !r) return { error: `No room called ${room}; rooms: ${doc.all('room').map((x) => x.name).join(', ') || 'none'}` };
  const other = next_to != null ? placed?.get(next_to) || doc.get(next_to) : null;
  if (next_to != null && !other) return { error: `next_to: no element ${next_to}` };
  const under = on != null ? placed?.get(on) || doc.get(on) : null;
  if (on != null && !under) return { error: `on: no element ${on}` };
  const lv = r ? doc.get(r.levelId) : other || under ? doc.get((other || under).levelId) : levelOf(doc, level);
  if (!lv) return { error: `No level ${level}` };
  const onWall = sideOf(wall);
  const onSide = other ? sideOf(side) || 'south' : null;
  if (!at && !onWall && !other && !r && !under) return { error: 'Give at: [x, y] in mm, or room and wall (north, south, east, west), or next_to and side, or on' };
  const box = r ? roomBox(app, r) : null;
  if (r && !box) return { error: `Room ${r.name} has no floor outline yet: it needs walls round it` };
  const turn = rotation != null ? +rotation : onWall ? SIDE_TURN[onWall] : other && faces !== false ? SIDE_TURN[onSide] : 0;
  const start = at || (under ? under.at : other ? other.at : r.at);
  const { type, own } = sizedType(doc, type0, { width, depth, height });
  const paint = color != null ? hexOf(color) : null;
  const set = ownValues(doc, type, values);
  // As in Archicad, each value given runs the parameter script (a cabinet's carcass follows A, B and ZZYZX).
  const given = { ...own, ...set.values };
  const gdlValues = type.family === 'gdl' && Object.keys(given).length ? applyGdlChange(type, {}, given) : given;
  const el = doc.add({ kind: 'component', typeId: type.id, levelId: lv.id, at: [+start[0], +start[1]], rotation: turn, offset: +offset || 0, ...(Object.keys(gdlValues).length ? { gdlValues } : {}), ...(paint ? { paintId: paintOf(doc, paint).id } : {}) });
  let mine = extent(app, el);
  // A piece that hangs from its insertion point (a pendant lamp: Archicad's have their origin at the ceiling rose and
  // the cable and shade below it) hangs from the ceiling over it, whatever offset was given: its drop is its own size.
  let hangs = null;
  // A piece drawn well above its insertion point (Archicad's kitchen wall units carry their own 1.5 m placement
  // height): with an offset given, the offset is where its bottom goes, so that placement height comes off.
  let lifted = null;
  if (mine && !under && offset != null && type.family === 'gdl') {
    const base0 = levelElevation(doc, lv.id) + (+el.offset || 0);
    const lift = mine.z0 - base0;
    if (lift > 200) {
      const cur = doc.get(el.id);
      // The parameter that holds it: one that stays at nought once the parameter script has run (a derived one, such
      // as ac_bottomlevel, is worked out again from the one that sets it).
      let p = null;
      for (const q of (type.gdl?.params || []).filter((x) => x.kind === 'length' && !['A', 'B', 'ZZYZX'].includes(x.name) && Math.abs(+(cur.gdlValues?.[x.name] ?? x.value) - lift) < 5)) {
        const vals = applyGdlChange(type, cur.gdlValues || {}, { [q.name]: 0 });
        if (Math.abs(+vals[q.name] || 0) < 1) {
          p = q;
          doc.update(el.id, { gdlValues: vals });
          break;
        }
      }
      const again = extent(app, doc.get(el.id));
      const left = again ? again.z0 - base0 : 0;
      if (left > 5) doc.update(el.id, { offset: Math.round((+cur.offset || 0) - left) });
      mine = extent(app, doc.get(el.id)) || mine;
      lifted = { own_placement_height_mm: Math.round(lift), ...(p ? { set_to_zero: p.name } : {}) };
    }
  }
  if (mine && !under) {
    const base = levelElevation(doc, lv.id) + (+el.offset || 0);
    if (Math.abs(mine.z1 - base) < 30 && base - mine.z0 > 150) {
      const c = [(mine.x0 + mine.x1) / 2, (mine.y0 + mine.y1) / 2];
      const ceil = ceilingAbove(app, lv, c);
      const move = ceil - base;
      doc.update(el.id, { offset: Math.round((+el.offset || 0) + move) });
      mine = { ...mine, z0: mine.z0 + move, z1: mine.z1 + move };
      const elev = levelElevation(doc, lv.id);
      hangs = { from_mm: Math.round(ceil - elev), lowest_mm: Math.round(mine.z0 - elev), note: 'It hangs from the ceiling: to lower or raise it, change its height (ZZYZX, the drop), not offset.' };
    }
  }
  if (mine && under) {
    // Set on top of another piece, centred on it unless shift [dx, dy] says otherwise.
    const top = extent(app, under);
    // A bed frame carries what is laid on it lower than its headboard.
    const carries = doc.get(under.typeId)?.supportHeight;
    if (carries) top.z1 = doc.get(under.levelId).elevation + (+under.offset || 0) + +carries;
    const [dx, dy] = Array.isArray(shift) ? shift.map(Number) : [0, 0];
    const move = [(top.x0 + top.x1 - mine.x0 - mine.x1) / 2 + dx, (top.y0 + top.y1 - mine.y0 - mine.y1) / 2 + dy, top.z1 - mine.z0];
    doc.update(el.id, { at: [Math.round(el.at[0] + move[0]), Math.round(el.at[1] + move[1])], offset: Math.round(el.offset + move[2]) });
    mine = { x0: mine.x0 + move[0], y0: mine.y0 + move[1], x1: mine.x1 + move[0], y1: mine.y1 + move[1], z0: mine.z0 + move[2], z1: mine.z1 + move[2] };
  }
  if (mine && !at && (onWall || other || r)) {
    const pad = gap != null ? +gap : other ? 150 : 10;
    const refBox = other ? extent(app, other) : null;
    const move = refBox ? besidePiece(mine, refBox, onSide, pad, +slide || 0) : onWall ? towardWall(mine, box, onWall, along, pad) : [(box.x0 + box.x1 - mine.x0 - mine.x1) / 2, (box.y0 + box.y1 - mine.y0 - mine.y1) / 2];
    doc.update(el.id, { at: [Math.round(el.at[0] + move[0]), Math.round(el.at[1] + move[1])] });
    mine = { ...mine, x0: mine.x0 + move[0], y0: mine.y0 + move[1], x1: mine.x1 + move[0], y1: mine.y1 + move[1] };
  }
  const skip = new Set([el.id, other?.id, under?.id, ...(ignore || [])]);
  // What is laid on something is meant to touch what carries it.
  const hits = mine && !under ? doc.all('component').filter((o) => !skip.has(o.id) && o.levelId === lv.id && (() => { const x = extent(app, o); return x && overlaps(mine, x); })()).map((o) => doc.get(o.typeId)?.name) : [];
  const out = box && mine && (mine.x0 < box.x0 - 1 || mine.y0 < box.y0 - 1 || mine.x1 > box.x1 + 1 || mine.y1 > box.y1 + 1);
  const quarter = Math.abs(Math.round(turn)) % 180 === 90;
  const real = mine ? [mine.x1 - mine.x0, mine.y1 - mine.y0].map(Math.round) : null;
  const [realW, realD] = real && quarter ? [real[1], real[0]] : real || [];
  const missed = real && ((+width && Math.abs(realW - +width) > +width * 0.05) || (+depth && Math.abs(realD - +depth) > +depth * 0.05));
  const warnings = [missed ? `Asked for ${+width || realW} x ${+depth || realD} mm, it came out ${realW} x ${realD} mm: this object takes its size from its own options, see object_parameters` : '', hits.length ? `It overlaps: ${hits.join(', ')}` : '', out ? `It sticks out of ${r.name}` : '', set.unknown.length ? `No such parameters: ${set.unknown.join(', ')}` : ''].filter(Boolean);
  const elev0 = levelElevation(doc, lv.id);
  return { id: el.id, at: doc.get(el.id).at, rotation: turn, plan_extent: mine, ...(mine ? { bottom_mm: Math.round(mine.z0 - elev0), top_mm: Math.round(mine.z1 - elev0) } : {}), ...(lifted ? { lifted } : {}), ...(hangs ? { hangs } : {}), ...(warnings.length ? { warning: warnings.join('. ') } : {}) };
}

/** The height (absolute, mm) of the ceiling over a point of a level: a ceiling element there, else the level above, else 2.7 m up. */
function ceilingAbove(app, lv, p) {
  const doc = app.doc;
  const elev = levelElevation(doc, lv.id);
  const inside = (poly) => {
    let k = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[i];
      const b = poly[j];
      if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < ((b[0] - a[0]) * (p[1] - a[1])) / (b[1] - a[1]) + a[0]) k = !k;
    }
    return k;
  };
  const ceils = doc.all('ceiling').filter((c) => c.levelId === lv.id && Array.isArray(c.boundary) && inside(c.boundary));
  if (ceils.length) return elev + Math.min(...ceils.map((c) => +c.offset || 0));
  const above = doc.levelAbove?.(lv.id);
  return above ? levelElevation(doc, above.id) : elev + 2700;
}

/**
 * The parameters given for a placed object, by name whatever their case. A colour for a material parameter becomes a
 * project material, so that it can be picked and changed like any other.
 */
function ownValues(doc, type, values) {
  const out = { values: {}, unknown: [] };
  if (!values || typeof values !== 'object') return out;
  const params = type.gdl?.params || [];
  for (const [name, v] of Object.entries(values)) {
    // The object's own sizes, which every library part has whether it lists them or not.
    if (['A', 'B', 'ZZYZX'].includes(name.toUpperCase()) && Number.isFinite(+v)) {
      out.values[name.toUpperCase()] = +v;
      continue;
    }
    const p = params.find((x) => x.name.toLowerCase() === name.toLowerCase());
    if (!p) {
      out.unknown.push(name);
      continue;
    }
    const hex = p.kind === 'material' && typeof v === 'string' && !doc.get(v) ? hexOf(v) : null;
    out.values[p.name] = hex ? paintOf(doc, hex).id : v;
  }
  return out;
}

/**
 * A placed object of the size asked for: a GDL object keeps its type and has its own size; a catalogue
 * object has its size in its type, so it gets a type of that size.
 */
function sizedType(doc, type, { width, depth, height }) {
  const want = { width: +width || 0, depth: +depth || 0, height: +height || 0 };
  const same = (k) => !want[k] || Math.abs(want[k] - +type[k]) < 1;
  if (same('width') && same('depth') && same('height')) return { type, own: null };
  if (type.family === 'gdl') {
    const own = {};
    if (want.width) own.A = want.width;
    if (want.depth) own.B = want.depth;
    if (want.height) own.ZZYZX = want.height;
    // Some objects are sized by what they hold (a bed by its mattress); the frame round it stays as it is.
    const nominal = (name, asked, whole) => {
      const p = asked ? type.gdl?.params?.find((x) => x.name.toLowerCase() === name) : null;
      if (p && +p.value > 0 && +whole > +p.value) own[p.name] = asked - (+whole - +p.value);
    };
    nominal('nominalwidth', want.width, type.width);
    nominal('nominallength', want.depth, type.depth);
    return { type, own };
  }
  const size = { width: want.width || type.width, depth: want.depth || type.depth, height: want.height || type.height };
  const twin = doc.all('componentType').find((t) => t.family === type.family && t.category === type.category && t.width === size.width && t.depth === size.depth && t.height === size.height);
  if (twin) return { type: twin, own: null };
  const { id, ...rest } = type;
  return { type: doc.add({ ...rest, ...size, name: `${Math.round(size.width)} x ${Math.round(size.depth)} x ${Math.round(size.height)} mm` }), own: null };
}

/** The picture a piece shows, cut from a placed image: read before the change, because reading it takes time. */
async function cutPicture(app, from) {
  const img = from.image_id ? app.doc.get(from.image_id) : app.doc.all('image').at(-1);
  if (img?.kind !== 'image') return { error: 'from_image: no such image; use list_images' };
  const src = img.src;
  if (!src) return { error: 'from_image: the picture could not be read' };
  const pic = await imageForClaude(src, from.region || null, 1024);
  return { url: `data:${pic.media_type};base64,${pic.data}` };
}

function placeComponent(app, type, spec) {
  let out;
  app.commit('Assistant: place object', () => {
    out = putComponent(app, type, spec);
  });
  return out;
}

/** The project type a library reference names, bringing the part into the project the first time. */
function typeOfRef(app, ref) {
  const doc = app.doc;
  const key = String(ref);
  if (key.startsWith('type:')) {
    const t = doc.get(key.slice(5));
    return t?.kind === 'componentType' ? { type: t } : { error: `${ref} is not a placeable object; find one with library_search` };
  }
  if (key.startsWith('my:')) {
    const mine = app.userLibrary?.get(key.slice(3));
    if (!mine) return { error: `${ref} is not in your library` };
    return { type: doc.all('componentType').find((t) => t.name === mine.name && t.familyName === 'My Library') || doc.add(typeFromEntry(mine)) };
  }
  if (!key.startsWith('lib:')) return { error: `${ref} is not a placeable object; find one with library_search` };
  const e = app.acLibrary?.get(key.slice(4));
  if (!e) return { error: `${ref} is not in the loaded libraries` };
  return { type: doc.all('componentType').find((t) => t.name === e.name && t.family === 'gdl') || doc.add(partType(app.acLibrary, e)) };
}

/** Where n chairs go round a table: along its long sides first, then at its ends. */
export function seatsAround(w, d, n) {
  const long = w >= d ? ['north', 'south'] : ['east', 'west'];
  const short = w >= d ? ['east', 'west'] : ['north', 'south'];
  const L = Math.max(w, d);
  const fit = Math.max(1, Math.floor(L / 600));
  const onLong = Math.min(n, fit * 2);
  const seats = [];
  for (let s = 0; s < 2; s++) {
    const here = Math.ceil((onLong - s) / 2);
    for (let i = 0; i < here; i++) seats.push({ side: long[s], slide: (i - (here - 1) / 2) * (L / Math.max(here, 1)) });
  }
  for (let i = 0; i < Math.min(n - onLong, 2); i++) seats.push({ side: short[i], slide: 0 });
  return seats;
}

/** The user's library, read when first wanted. */
async function myLibrary(app) {
  app.userLibrary ||= new UserLibrary();
  await app.userLibrary.ready();
  return app.userLibrary;
}

/** Keeps a GDL object type in the user's library, so it is found like the others from now on. */
export async function keepInLibrary(app, type, { name, words } = {}) {
  const lib = await myLibrary(app);
  return lib.add(entryFromType(type, { name, words, thumb: typeof document === 'undefined' ? null : thumbnail(type) }));
}

/** One search of every library, noted so that make_furniture knows it was done. */
async function searchLibraries(app, query, limit) {
  const out = [];
  for (const e of (await myLibrary(app)).search(query)) out.push({ ref: `my:${e.name}`, name: e.name, category: e.category, width: e.width, depth: e.depth, height: e.height, source: 'My library' });
  for (const t of app.doc.all('componentType')) if (matchesQuery(`${t.name} ${t.familyName || ''} ${t.category || ''}`, query)) out.push({ ref: `type:${t.id}`, name: t.name, family: t.familyName, category: t.category, width: t.width, depth: t.depth, height: t.height, source: 'project' });
  const lib = app.acLibrary;
  if (lib) for (const e of lib.objects()) if (matchesQuery(`${e.name} ${e.path}`, query)) out.push({ ref: `lib:${e.name}`, name: e.name, folder: e.path.split('/').slice(0, -1).join('/'), source: 'Archicad library' });
  app.libSearches ||= new Map();
  for (const alts of searchWords(query)) for (const w of alts) app.libSearches.set(w, Math.max(app.libSearches.get(w) || 0, out.length));
  return { count: out.length, results: out.slice(0, limit), archicad_library_loaded: !!lib?.parts?.size };
}

/** What each kind of piece is called in the libraries: it must have been searched for before one is made. */
const LIBRARY_WORD = { wardrobe: 'wardrobe', closet: 'wardrobe', cabinet: 'cabinet', nightstand: 'nightstand', bookcase: 'bookshelf', kitchen_base: 'kitchen', kitchen_wall: 'kitchen', desk: 'desk', table: 'table', round_table: 'table', bed: 'bed', rug: 'carpet', curtain: 'curtain', table_lamp: 'lamp', shoes: 'shoe', hat: 'hat', folded_clothes: 'clothes' };

/**
 * The libraries come first, and this is where that is enforced: a piece can be made only after its library has been
 * searched, and if the search found something, only with the reason none of it will do. Returns an error, or null.
 */
function libraryFirst(app, spec) {
  const word = LIBRARY_WORD[spec.kind];
  // What no library has (a painting from a photo, a strip of light, a socket in 3D), and where there are no libraries to look in.
  if (!word || app.librariesUnreachable) return null;
  const found = app.libSearches?.get(word);
  if (found === undefined) return `First search the libraries: library_search with "${word}". A piece is made only if nothing there will do.`;
  if (found > 0 && !String(spec.reason || '').trim()) return `The libraries have ${found} results for "${word}": place one of them, or give in reason what makes every one of them wrong for this piece.`;
  // A bed comes from the libraries, unless the user asked for one made to measure.
  if (spec.kind === 'bed' && app.acLibrary?.parts?.size && !spec.user_asked) return 'Beds come from the libraries: take the closest with library_preview (Bed Double 01 to 05), set its size, its materials and bPillow in values, and add Pillow objects with on. Make one only if the user asked for it to measure (user_asked: true).';
  return null;
}

/** A new furniture type from a description; a picture shows what was cut from an image. Inside a transaction. */
function makePiece(app, spec, cut) {
  const doc = app.doc;
  const refused = libraryFirst(app, spec);
  if (refused) return { error: refused };
  const fields = furnitureObject(cut ? { ...spec, image: cut.url } : spec);
  const check = runGdlType(fields);
  if (check.error) return { error: check.error };
  return { type: doc.add({ kind: 'componentType', family: 'gdl', familyName: 'GDL Object', ...fields }), triangles: check.tris.length };
}

export const INTERIOR_TOOLS = [
  {
    name: 'library_search',
    description: 'Find furniture and objects to place, in Italian or English (armadio, divano, wardrobe...): the user\'s own library, every Archicad library loaded, and the project\'s catalogue. Returns a ref for place_object, with the size in mm. Empty? library_load brings in the interior libraries; what no library has can be made with make_furniture and kept with add_to_library.',
    parameters: { type: 'object', properties: { query: { type: 'string' }, queries: { type: 'array', items: { type: 'string' }, description: 'Several searches in one call: much quicker than one call each' }, limit: { type: 'number' } } },
    async run(app, { query, queries, limit = 25 }) {
      const list = Array.isArray(queries) && queries.length ? queries : query != null ? [query] : [];
      if (!list.length) return { error: 'Give query, or queries' };
      const answers = {};
      for (const q of list) answers[q] = await searchLibraries(app, q, list.length > 1 ? Math.min(+limit || 12, 12) : +limit || 25);
      if (list.length === 1) return answers[list[0]];
      return { results_by_query: answers, archicad_library_loaded: !!app.acLibrary?.parts?.size };
    },
  },
  {
    name: 'add_to_library',
    description: 'Keep an object in the user\'s own library, between projects, so that it is found like the others from now on and can be exported to Archicad. type is the type id make_furniture answered, or element the id of a placed object. name: a clear name; words: what to find it by, in Italian and English. Add every piece you make that a library did not have.',
    parameters: { type: 'object', properties: { type: { type: 'string' }, element: { type: 'string' }, name: { type: 'string' }, words: { type: 'string' } } },
    async run(app, { type, element, name, words }) {
      const doc = app.doc;
      const t = type ? doc.get(type) : doc.get(doc.get(element)?.typeId);
      if (t?.kind !== 'componentType' || !t.gdl) return { error: 'Give the type id of a GDL object, or the id of a placed one' };
      if (t.gdl.lenient) return { error: 'That object already comes from a library' };
      const e = await keepInLibrary(app, t, { name: name || t.name, words: words || '' });
      return { added: e.name, ref: `my:${e.name}` };
    },
  },
  {
    name: 'measure_photo',
    description: 'Measure a room from a photo, instead of guessing: more accurate, and the same each time. A photo taken at an angle, with two walls running away (most are): give lines_x and lines_y, two or more picture segments [[x, y], [x, y]] along each of the two wall directions (floor edges, ceiling edges, a rug or bed edge parallel to them), origin the floor corner to measure from, ref { a, b, mm } a known length on the floor (the long side of a double bed is 2000), points { name: [x, y] } the floor pixels under each piece, and image; it answers the camera (eye, target, fov for set_camera) and every point in mm from that corner: build at those places. A photo square to its far wall: in full-image pixels: wall { top_left, top_right, bottom_right, bottom_left } the corners of the far wall (extended past whatever hides them); width_ref { a, b, mm } two points on the far wall of a known distance (a double bed\'s width at the headboard, 1600; a door 800); depth_ref { near, far, mm } the near and far ends on the floor of something of known length running towards the camera (the bed\'s side, 2000); vanishing_point [x, y] where the lines running away from the camera meet, if you can tell; image [w, h]. Answers the room\'s width and height, the camera\'s distance from that wall, its height, its x from the left corner and the vertical field of view, to give to set_camera.',
    parameters: { type: 'object', properties: { lines_x: { type: 'array' }, lines_y: { type: 'array' }, origin: { type: 'array', items: { type: 'number' } }, ref: { type: 'object' }, points: { type: 'object' }, wall: { type: 'object' }, width_ref: { type: 'object' }, depth_ref: { type: 'object' }, vanishing_point: { type: 'array', items: { type: 'number' } }, image: { type: 'array', items: { type: 'number' } } }, required: ['image'] },
    run(app, input) {
      return input.lines_x ? measureObliquePhoto(input) : measurePhoto(input);
    },
  },
  {
    name: 'library_preview',
    description: 'See what objects of the loaded Archicad libraries look like, side by side, to choose the one closest to what you want: names is a list of names from library_search (up to 16). Returns a picture of their catalogue previews, in that order.',
    parameters: { type: 'object', properties: { names: { type: 'array', items: { type: 'string' } } }, required: ['names'] },
    async run(app, { names }) {
      const lib = app.acLibrary;
      const mine = await myLibrary(app);
      const list = (names || []).slice(0, 16).map((n) => String(n).replace(/^(lib|my):/, '')).map((name) => ({ name, pic: lib?.get(name)?.lp?.preview, thumb: mine.get(name)?.thumb }));
      const shown = [];
      for (const it of list) {
        if (!it.pic && !it.thumb) continue;
        try {
          const blob = it.pic ? new Blob([it.pic.bytes], { type: it.pic.mime }) : await (await fetch(it.thumb)).blob();
          shown.push({ name: it.name, bmp: await createImageBitmap(blob) });
        } catch {
          // A preview that cannot be read is left out, and listed below.
        }
      }
      if (!shown.length) return { error: 'None of these has a preview', names };
      const cell = 240;
      const label = 26;
      const cols = Math.min(4, shown.length);
      const rows = Math.ceil(shown.length / cols);
      const cv = document.createElement('canvas');
      cv.width = cols * cell;
      cv.height = rows * (cell + label);
      const g = cv.getContext('2d');
      g.fillStyle = '#fff';
      g.fillRect(0, 0, cv.width, cv.height);
      g.font = '15px sans-serif';
      g.textAlign = 'center';
      shown.forEach(({ name, bmp }, i) => {
        const x = (i % cols) * cell;
        const y = Math.floor(i / cols) * (cell + label);
        const k = Math.min((cell - 12) / bmp.width, (cell - 12) / bmp.height);
        g.drawImage(bmp, x + (cell - bmp.width * k) / 2, y + (cell - bmp.height * k) / 2, bmp.width * k, bmp.height * k);
        g.fillStyle = '#000';
        g.fillText(name, x + cell / 2, y + cell + 18, cell - 8);
      });
      const url = cv.toDataURL('image/jpeg', 0.85);
      return { shown: shown.map((s) => s.name), without_preview: list.filter((it) => !shown.some((s) => s.name === it.name)).map((it) => it.name), _image: { media_type: 'image/jpeg', data: url.slice(url.indexOf(',') + 1) } };
    },
  },
  {
    name: 'object_parameters',
    description: 'What can be set on an object before placing it: its size in mm, its material parameters (give a #rrggbb or a material id in values) and its other options, by name. Objects come plain: switch on in values what you want to see (bPillow: 1 for a bed\'s pillows, 0 or 1 for parts and picture options: a Carpet with bPict 1 shows a stock rug picture, with bPict 0 its carpet_mat). ref is what library_search gave.',
    parameters: { type: 'object', properties: { ref: { type: 'string' }, refs: { type: 'array', items: { type: 'string' }, description: 'Several objects at once: quicker' } } },
    run(app, { ref, refs }) {
      if (Array.isArray(refs) && refs.length) return { objects: Object.fromEntries(refs.map((r) => [r, INTERIOR_TOOLS.find((t) => t.name === 'object_parameters').run(app, { ref: r })])) };
      const key = String(ref);
      const e = key.startsWith('lib:') ? app.acLibrary?.get(key.slice(4)) : null;
      const mine = key.startsWith('my:') ? app.userLibrary?.get(key.slice(3)) : null;
      const type = e ? partType(app.acLibrary, e) : mine ? typeFromEntry(mine) : key.startsWith('type:') ? app.doc.get(key.slice(5)) : null;
      if (!type) return { error: `${ref} is not a placeable object; find one with library_search` };
      const row = (p) => ({ name: p.name, ...(p.label && p.label !== p.name ? { label: p.label } : {}), value: p.value });
      const params = (type.gdl?.params || []).filter((p) => !/^(ac_|gs_ui|gs_list|FM_|ifc_)/i.test(p.name) && !['title', 'separator'].includes(p.kind));
      const other = params.filter((p) => ['boolean', 'integer', 'string', 'length', 'number', 'angle'].includes(p.kind) && !Array.isArray(p.value) && !/^(iDetLev|gs_shadow|gs_detlevel|gs_cont_|gs_fill_|gs_back_|fill|pen|back|MS[A-Z]|iSymbol|iFMType|bUniformFill|gs_resol)/.test(p.name));
      return { name: type.name, width: type.width, depth: type.depth, height: type.height, materials: params.filter((p) => p.kind === 'material').map(row), options: other.slice(0, 50).map(row), more: Math.max(0, other.length - 50) };
    },
  },
  {
    name: 'library_load',
    description: 'Load the interior object libraries of the Archicad installed on this computer (furniture, kitchens, bathrooms, lighting, decoration), when the app runs on it. On the website, or without Archicad, the user loads them with File > Libraries; make_furniture needs no library.',
    parameters: { type: 'object', properties: { packs: { type: 'array', items: { type: 'string' }, description: 'Names of library packs; by default the interior ones' } } },
    async run(app, { packs }) {
      let list;
      try {
        const res = await fetch('./api/archicad-libraries');
        if (!res.ok || !/json/.test(res.headers.get('content-type') || '')) throw new Error('none');
        list = (await res.json()).files;
      } catch {
        app.librariesUnreachable = !app.acLibrary?.parts?.size;
        return { error: 'The Archicad libraries are not reachable from here. Use make_furniture and the project catalogue, or ask the user to load them with the Archicad Library command.' };
      }
      const want = (Array.isArray(packs) && packs.length ? packs : INTERIOR_PACKS).map((p) => String(p).toLowerCase());
      const chosen = list.filter((f) => want.includes(f.replace(/\.libpack$/i, '').toLowerCase()));
      app.acLibrary ||= new ArchicadLibrary();
      let added = 0;
      for (const f of chosen) {
        if (app.acLibrary.files.some((x) => x.name === f)) continue;
        const res = await fetch(`./api/archicad-libraries?file=${encodeURIComponent(f)}`);
        if (res.ok) added += app.acLibrary.add(f, new Uint8Array(await res.arrayBuffer()));
      }
      return { packs: chosen.length, parts_added: added, objects: app.acLibrary.objects().length, available: list.map((f) => f.replace(/\.libpack$/i, '')) };
    },
  },
  {
    name: 'make_furniture',
    description: `Make a piece of furniture to measure, when the libraries have nothing like it or are not available, as a parametric object (its doors, drawers, shelves and size stay editable), and place it if asked. kind: ${FURNITURE_KINDS.join(', ')}. Sizes in mm; colours by name (white, oak, walnut, grey, black, blue, green, or Italian) or #rrggbb, and #rrggbb read from a photo is better than a name. Place with room and wall (north, south, east, west; along 0..1 from one end), its back to that wall, or with at: [x, y]. bed: on tapered legs with a thin rail unless legs is false; bedding false makes only the frame and headboard, to lay a library Mattress and Pillows on it with on; color is the wood, front_color the bedding, accent_color a throw at the foot, top_color the big pillows, pillow_color the small ones. closet: glass doors over glass_share of its width (0..1), hanging space on the left, shelves on the right. table_lamp: color the base, front_color the shade, shade globe for a ball on a stem. shoes, hat, folded_clothes, wall_plate (a real socket or switch of the project, with function socket or switch: it counts in the electrical loads and shows as a symbol in plan; doors is its outlets; on a wall at offset height) and cove_light (a strip of light along the top of a wall, which lights it: width its length) are small pieces. closet: filled false for an empty one, lit true for light inside. nightstand: drawers with a shadow gap, no handles, on a plinth. round_table: base drum for a solid cylinder under a thin wider top.  picture: hung with offset = height of its bottom edge above the floor, depth 30; from_image { image_id, region: [x0, y0, x1, y1] in full-image pixels } makes it show that part of a placed image, so a painting in a photo is the painting. curtain: sheer unless opaque is true; depth is how deep its folds are.`,
    parameters: {
      type: 'object',
      properties: {
        kind: { type: 'string', enum: FURNITURE_KINDS },
        name: { type: 'string' },
        width: { type: 'number' },
        depth: { type: 'number' },
        height: { type: 'number' },
        doors: { type: 'number' },
        drawers: { type: 'number' },
        shelves: { type: 'number' },
        color: { type: 'string' },
        front_color: { type: 'string' },
        top_color: { type: 'string' },
        accent_color: { type: 'string' },
        pillow_color: { type: 'string' },
        glass_share: { type: 'number' },
        frame: { type: 'number' },
        filled: { type: 'boolean' },
        lit: { type: 'boolean' },
        legs: { type: 'boolean' },
        shade: { type: 'string', enum: ['dome', 'globe'] },
        user_asked: { type: 'boolean', description: 'The user asked in so many words for this piece to be made to measure' },
        bedding: { type: 'boolean' },
        function: { type: 'string', enum: ['socket', 'switch'] },
        base: { type: 'string', enum: ['stem', 'drum'] },
        opaque: { type: 'boolean' },
        reason: { type: 'string', description: 'What makes every piece the library search found wrong for this one. Required when the search found something.' },
        from_image: { type: 'object', properties: { image_id: { type: 'string' }, region: { type: 'array', items: { type: 'number' } } } },
        room: { type: 'string' },
        wall: { type: 'string', enum: ['north', 'south', 'east', 'west'] },
        along: { type: 'number' },
        at: { type: 'array', items: { type: 'number' } },
        rotation: { type: 'number' },
        level: { type: 'string' },
        offset: { type: 'number', description: 'Height above the level, mm; a kitchen wall unit is usually 1400. A piece that hangs (a pendant lamp) hangs from the ceiling whatever this says: its drop is its height (ZZYZX in values), and the answer gives its lowest point' },
      },
      required: ['kind'],
    },
    async run(app, input) {
      const cut = input.from_image ? await cutPicture(app, input.from_image) : null;
      if (cut?.error) return cut;
      const out = {};
      const { width: _w, depth: _d, height: _h, color: _c, ...where } = input;
      app.commit('Assistant: furniture', () => {
        const made = makePiece(app, input, cut);
        if (made.error) return Object.assign(out, made);
        const { type, triangles } = made;
        if (input.reason) out.made_because = input.reason;
        Object.assign(out, { type: type.id, name: type.name, width: type.width, depth: type.depth, height: type.height, triangles });
        if (input.room != null || input.at || input.next_to != null) {
          const r = putComponent(app, type, { ...where, offset: input.offset ?? (input.kind === 'kitchen_wall' ? 1400 : 0) });
          Object.assign(out, r);
        }
      });
      return out;
    },
  },
  {
    name: 'place_object',
    description: 'Place an object found with library_search, by its ref, optionally at a size (width, depth, height in mm), with its own parameters (values: { name: value } from object_parameters; a material parameter takes #rrggbb) and in one colour over the whole object (color, for a rug or a curtain). Against a wall of a room (room and wall: north, south, east, west; along 0..1), its back to it; beside another piece (next_to: its id, side: north, south, east or west of it, gap in mm, slide along that side), facing it unless faces is false; in the middle of a room (room alone); or at [x, y] in mm with a rotation in degrees. It goes by the object\'s real outline. Answers where it went and what it overlaps. For several pieces use place_objects.',
    parameters: { type: 'object', properties: { ref: { type: 'string' }, room: { type: 'string' }, wall: { type: 'string', enum: ['north', 'south', 'east', 'west'] }, along: { type: 'number' }, next_to: { type: 'string' }, side: { type: 'string', enum: ['north', 'south', 'east', 'west'] }, gap: { type: 'number' }, slide: { type: 'number' }, faces: { type: 'boolean' }, at: { type: 'array', items: { type: 'number' } }, rotation: { type: 'number' }, level: { type: 'string' }, offset: { type: 'number' }, on: { type: 'string', description: 'The id of a piece to set this on top of' }, shift: { type: 'array', items: { type: 'number' } }, width: { type: 'number' }, depth: { type: 'number' }, height: { type: 'number' }, color: { type: 'string' }, values: { type: 'object' } }, required: ['ref'] },
    run(app, input) {
      let out;
      app.commit('Assistant: place object', () => {
        const { type, error } = typeOfRef(app, input.ref);
        out = error ? { error } : putComponent(app, type, input);
      });
      return out;
    },
  },
  {
    name: 'place_objects',
    description: 'Furnish in one go, one undo step: much quicker than one call per piece. items: each is what place_object takes (ref) or what make_furniture takes (kind, and reason when a library search found something for it), with these additions: key, a name for the piece that later items use in next_to; around: the key or id of a table, with count, to set that many of this chair round it, tucked in. on: the key or id of a piece to set this on top of, with shift [dx, dy] from its centre (a lamp on a bedside table, shoes on a shelf). A sofa, then a coffee table next_to it on the side it faces, then chairs around a table, in one list. keep: true on a made piece also adds it to the user library, with words to find it by. Answers per item, with warnings.',
    parameters: { type: 'object', properties: { items: { type: 'array', items: { type: 'object' } } }, required: ['items'] },
    async run(app, { items }) {
      if (!Array.isArray(items) || !items.length) return { error: 'Give items' };
      const doc = app.doc;
      const placed = new Map();
      const results = [];
      const cuts = new Map();
      const toKeep = [];
      for (const item of items) if (item.from_image) cuts.set(item, await cutPicture(app, item.from_image));
      app.commit('Assistant: furnish', () => {
        for (const item of items) {
          let type;
          const cut = cuts.get(item);
          if (cut?.error) {
            results.push({ key: item.key, error: cut.error });
            continue;
          }
          if (item.kind) {
            const made = makePiece(app, item, cut);
            if (made.error) {
              results.push({ key: item.key, error: made.error });
              continue;
            }
            type = made.type;
            if (item.keep) toKeep.push({ type, name: item.name, words: item.words });
          } else {
            const found = typeOfRef(app, item.ref);
            if (found.error) {
              results.push({ key: item.key, error: found.error });
              continue;
            }
            type = found.type;
          }
          if (item.around != null) {
            const table = placed.get(item.around) || doc.get(item.around);
            const box = table && extent(app, table);
            if (!box) {
              results.push({ key: item.key, error: `around: no element ${item.around}` });
              continue;
            }
            const ids = [];
            for (const seat of seatsAround(box.x1 - box.x0, box.y1 - box.y0, Math.max(1, +item.count || 4))) {
              const r = putComponent(app, type, { next_to: table.id, gap: item.gap ?? -120, ...seat, ignore: ids }, placed);
              if (r.id) ids.push(r.id);
              results.push({ key: item.key, name: type.name, ...r });
            }
            continue;
          }
          const offset = item.offset ?? (item.kind === 'kitchen_wall' ? 1400 : 0);
          // A made piece has its size and colours already; a library piece takes them here.
          const r = putComponent(app, type, item.kind ? { ...item, width: undefined, depth: undefined, height: undefined, color: undefined, offset } : { ...item, offset }, placed);
          if (r.id && item.key != null) placed.set(item.key, doc.get(r.id));
          results.push({ key: item.key, name: type.name, ...r });
        }
      });
      for (const k of toKeep) await keepInLibrary(app, k.type, { name: k.name || k.type.name, words: k.words || '' });
      return { placed: results.filter((r) => r.id).length, results, ...(toKeep.length ? { added_to_library: toKeep.map((k) => k.name || k.type.name) } : {}) };
    },
  },
  {
    name: 'add_elements',
    description: `Add model elements from a description, several at once (one undo step). Each item: { kind: ${[...ADDABLE].join('|')}, level (name), type (name of its type, optional), color (optional, a paint), and the element's own fields in mm }. A wall's or a slab's thickness comes from its type. The answer lists under ignored what had no effect. floor/ceiling/roof: boundary [[x,y]...] (roof also slopes [degrees per edge]; ceiling: offset, its height above the level in mm); column/component: at [x,y]; beam/stair/ramp/wall/duct/pipe: a [x,y], b [x,y]; railing: path; door/window/opening: host (wall id) and t (mm along it), window sill; room: at, name. Use trace_floor_plan for whole plans.`,
    parameters: { type: 'object', properties: { items: { type: 'array', items: { type: 'object' } } }, required: ['items'] },
    run(app, { items }) {
      const doc = app.doc;
      if (!Array.isArray(items) || !items.length) return { error: 'Give items' };
      const made = [];
      const failed = [];
      const ignored = [];
      app.commit('Assistant: add elements', () => {
        for (const raw of items) {
          const { kind, level, top_level, type, host, color, ...fields } = raw || {};
          for (const key of Object.keys(fields)) {
            if (IGNORED_FIELDS[kind]?.includes(key)) {
              ignored.push(`${kind}.${key}`);
              delete fields[key];
            }
          }
          if (!ADDABLE.has(kind)) {
            failed.push({ kind, error: 'This kind cannot be added here' });
            continue;
          }
          const lv = levelOf(doc, level);
          const el = { kind, ...fields };
          if (lv && !['door', 'window', 'opening'].includes(kind)) el.levelId = lv.id;
          const top = top_level ? levelOf(doc, top_level) : kind === 'wall' || kind === 'column' || kind === 'stair' ? doc.levelAbove(lv?.id) : null;
          if (top) el.topLevelId = top.id;
          const tk = TYPE_KIND[kind];
          if (tk) {
            const list = doc.all(tk);
            const t = (type != null && (list.find((x) => x.id === type || x.name.toLowerCase() === String(type).toLowerCase()) || list.find((x) => x.name.toLowerCase().includes(String(type).toLowerCase())))) || list[0];
            if (!t) {
              failed.push({ kind, error: `No ${tk} in the project` });
              continue;
            }
            el.typeId = t.id;
          }
          if (host) el.hostId = host;
          if (color != null) {
            const hex = hexOf(color);
            if (hex) el.paintId = paintOf(doc, hex).id;
            else ignored.push(`${kind}.color (${color} is not a colour)`);
          }
          if (kind === 'wall') Object.assign(el, { baseOffset: 0, topOffset: 0, height: 3000, locationLine: 'center', joinA: true, joinB: true, roomBounding: true, ...el });
          // A ceiling's height above its level is its offset, whatever it is called; one left on the floor is never meant.
          if (kind === 'ceiling') {
            const up = [raw.offset, raw.elevation, raw.height].map(Number).find((v) => v > 0);
            delete el.elevation;
            delete el.height;
            el.offset = up || 2700;
          }
          if (kind === 'floor' || kind === 'ceiling') Object.assign(el, { holes: [], offset: 0, ...el });
          if (kind === 'roof') Object.assign(el, { baseOffset: 0, ...el });
          if (kind === 'room') Object.assign(el, { number: el.number ?? String(doc.all('room').length + 1), name: el.name ?? 'Room', upperOffset: el.upperOffset ?? 2700 });
          if (kind === 'column' || kind === 'component') Object.assign(el, { rotation: 0, ...el });
          try {
            made.push({ id: doc.add(el).id, kind });
          } catch (err) {
            failed.push({ kind, error: String(err.message || err) });
          }
        }
      });
      return { made, failed, ...(ignored.length ? { ignored: [...new Set(ignored)] } : {}) };
    },
  },
  {
    name: 'build_room',
    description: 'Build a whole room in one call, one undo step: much quicker than one call each. width and depth (inside, mm; x from the west wall, y from the south wall), height, thickness, level. openings: [{ kind: window or door, wall: north, south, east or west, at: mm along that wall from its west or south end to the middle of the opening, width, height, sill }]. finishes: { walls, north, south, east, west (one wall differently), ceiling, floor, plank (mm, for boards), plank_direction: x or y }: colours as #rrggbb. name: the zone. items: what place_objects takes, referring to the room by its name. camera: what set_camera takes. Answers what was made, the warnings per item and the picture from the camera.',
    parameters: { type: 'object', properties: { width: { type: 'number' }, depth: { type: 'number' }, height: { type: 'number' }, thickness: { type: 'number' }, level: { type: 'string' }, name: { type: 'string' }, openings: { type: 'array', items: { type: 'object' } }, finishes: { type: 'object' }, items: { type: 'array', items: { type: 'object' } }, camera: { type: 'object' } }, required: ['width', 'depth', 'height'] },
    async run(app, { width, depth, height, thickness = 200, level, name = 'Room', openings = [], finishes = {}, items = [], camera }) {
      const doc = app.doc;
      const lv = levelOf(doc, level);
      const T = (n) => INTERIOR_TOOLS.find((t) => t.name === n);
      const h = +thickness / 2;
      const [W, D, H] = [+width, +depth, +height];
      const corner = [[-h, -h], [W + h, -h], [W + h, D + h], [-h, D + h]];
      const SIDE = { south: 0, east: 1, north: 2, west: 3 };
      const walls = {};
      const wt = doc.all('wallType').find((t) => Math.abs((t.layers || []).reduce((s, l) => s + (+l.thickness || 0), 0) - thickness) < 1) || doc.get('wt-generic');
      const skipped = [];
      app.commit('Assistant: build room', () => {
        for (const [side, i] of Object.entries(SIDE)) walls[side] = doc.add({ kind: 'wall', typeId: wt.id, levelId: lv.id, a: corner[i], b: corner[(i + 1) % 4], baseOffset: 0, topLevelId: null, topOffset: 0, height: H, locationLine: 'center', joinA: true, joinB: true, roomBounding: true });
        const box = [[-h, -h], [W + h, -h], [W + h, D + h], [-h, D + h]];
        doc.add({ kind: 'floor', typeId: doc.all('floorType')[0].id, levelId: lv.id, boundary: box, holes: [], offset: 0 });
        doc.add({ kind: 'ceiling', typeId: doc.all('ceilingType')[0].id, levelId: lv.id, boundary: box, holes: [], offset: H });
        doc.add({ kind: 'room', levelId: lv.id, at: [W / 2, D / 2], name, number: String(doc.all('room').length + 1), upperOffset: H });
        for (const o of openings) {
          const wall = walls[o.wall];
          const list = doc.all(o.kind === 'door' ? 'doorType' : 'windowType');
          if (!wall || !list.length) {
            skipped.push(o);
            continue;
          }
          // Along the wall from its west or south end: the north and west walls run the other way.
          const along = h + +o.at;
          const t = o.wall === 'north' ? W + 2 * h - along : o.wall === 'west' ? D + 2 * h - along : along;
          doc.add({ kind: o.kind === 'door' ? 'door' : 'window', typeId: list[0].id, hostId: wall.id, t, width: +o.width, height: +o.height, ...(o.kind === 'door' ? {} : { sill: +o.sill || 0 }) });
        }
      });
      const paint = [];
      const each = (ids, color, extra = {}) => color && paint.push({ ids, color, ...extra });
      const sides = Object.keys(SIDE).filter((k) => finishes[k]);
      each(Object.keys(SIDE).filter((k) => !finishes[k]).map((k) => walls[k].id), finishes.walls);
      for (const k of sides) each([walls[k].id], finishes[k]);
      each(doc.all('ceiling').slice(-1).map((e) => e.id), finishes.ceiling);
      each(doc.all('floor').slice(-1).map((e) => e.id), finishes.floor, finishes.plank ? { pattern: 'planks', plank: finishes.plank, direction: finishes.plank_direction || 'y' } : {});
      if (paint.length) await T('set_finish').run(app, { items: paint });
      const furnished = items.length ? await T('place_objects').run(app, { items: items.map((it) => (it.room === undefined && (it.wall || (!it.at && !it.next_to && !it.on && !it.around)) ? { ...it, room: name } : it)) }) : null;
      const pic = camera ? await T('set_camera').run(app, camera) : null;
      // The room as built, measured on the model: what the camera picture is to be checked against.
      const zone = doc.all('room').filter((x) => x.levelId === lv.id).at(-1);
      const g = zone ? app.scene.rooms.room(zone) : null;
      const xs = g?.outer?.map((q) => q[0]) || [];
      const ys = g?.outer?.map((q) => q[1]) || [];
      const inside = xs.length ? { width_mm: Math.round(Math.max(...xs) - Math.min(...xs)), depth_mm: Math.round(Math.max(...ys) - Math.min(...ys)), height_mm: Math.round(+H), area_m2: Math.round(g.area / 1e4) / 100 } : null;
      return { walls: Object.fromEntries(Object.entries(walls).map(([k, w]) => [k, w.id])), ...(inside ? { inside } : {}), skipped_openings: skipped, placed: furnished?.placed, problems: furnished?.results?.filter((r) => r.error || r.warning).map((r) => ({ key: r.key, name: r.name, error: r.error, warning: r.warning })), ...(pic?._image ? { _image: pic._image, view: pic.view } : {}) };
    },
  },
  {
    name: 'set_finish',
    description: 'Give existing elements a finish: their look in 3D, without changing their type. ids, or kind (wall, floor, ceiling...) for every element of that kind. color: #rrggbb read from what you see, or a name. pattern: planks draws wooden boards in that colour (plank width in mm, direction x or y: the way the boards run). from_image { image_id, region, width, height } uses that part of a placed image as a repeating surface, width and height in mm being the real size of the part. clear: true takes the finish off.',
    parameters: { type: 'object', properties: { items: { type: 'array', items: { type: 'object' }, description: 'Several finishes at once, each with the fields below: quicker' }, ids: { type: 'array', items: { type: 'string' } }, kind: { type: 'string' }, color: { type: 'string' }, pattern: { type: 'string', enum: ['planks'] }, plank: { type: 'number' }, direction: { type: 'string', enum: ['x', 'y'] }, from_image: { type: 'object' }, clear: { type: 'boolean' } } },
    async run(app, { items, ids, kind, color, pattern, plank, direction, from_image, clear }) {
      const doc = app.doc;
      if (Array.isArray(items) && items.length) {
        const self = INTERIOR_TOOLS.find((t) => t.name === 'set_finish');
        const results = [];
        for (const it of items) results.push(await self.run(app, it));
        return { results };
      }
      const els = (Array.isArray(ids) && ids.length ? ids.map((id) => doc.get(id)).filter(Boolean) : kind ? doc.all(kind) : []).filter((e) => !e.kind?.endsWith('Type'));
      if (!els.length) return { error: 'Give ids of elements, or a kind of element the project has' };
      if (clear) {
        app.commit('Assistant: clear finish', () => els.forEach((e) => doc.update(e.id, { paintId: null })));
        return { cleared: els.length };
      }
      const hex = color != null ? hexOf(color) : '#8a8580';
      if (!hex) return { error: `${color} is not a colour; give #rrggbb` };
      let surface = null;
      if (from_image) {
        const cut = await cutPicture(app, from_image);
        if (cut.error) return cut;
        surface = { image: cut.url, w: +from_image.width || 1000, h: +from_image.height || 1000 };
      } else if (pattern === 'planks') {
        if (typeof document === 'undefined') return { error: 'Patterns are drawn in the browser' };
        surface = { ...planksPicture(hex, { plank: +plank || 180 }), angle: direction === 'y' ? 90 : 0 };
      }
      let mat;
      app.commit('Assistant: finish', () => {
        mat = surface ? pictureMaterial(doc, pattern === 'planks' ? `Boards ${hex}` : 'Surface from image', hex, surface) : paintOf(doc, hex);
        for (const e of els) doc.update(e.id, { paintId: mat.id });
      });
      return { painted: els.length, material: mat.name };
    },
  },
  {
    name: 'set_camera',
    description: 'Stand a camera at a point, looking at another, in a named 3D view that stays in the project and opens: eye and target are [x, y, z] in mm, z above project zero. fov: the vertical field of view in degrees (a phone or an interior photo is usually 45 to 60). aspect: width over height of the picture returned. style: realistic by default. lamps: true lights the lamps. Returns the picture, to compare with the photo you are rebuilding.',
    parameters: { type: 'object', properties: { eye: { type: 'array', items: { type: 'number' } }, target: { type: 'array', items: { type: 'number' } }, fov: { type: 'number' }, aspect: { type: 'number' }, name: { type: 'string' }, style: { type: 'string', enum: ['realistic', 'shaded', 'hidden'] }, lamps: { type: 'boolean' } }, required: ['eye', 'target'] },
    async run(app, { eye, target, fov = 55, aspect = 1.4, name = 'Camera view', style = 'realistic', lamps = true }) {
      const doc = app.doc;
      if (![eye, target].every((p) => Array.isArray(p) && p.length === 3 && p.every(Number.isFinite))) return { error: 'eye and target are [x, y, z] in mm' };
      const camera = { ...cameraLooking(eye, target, { fov: Math.max(15, Math.min(110, +fov || 55)) }), fitted: true };
      // Indoors the light has bounced round the room: without it a wall in shadow is far darker than in a photo.
      // However many lamps there are, together they should not wash the room out.
      const glow = doc.all('component').filter((el) => isLamp(doc, el) && el.lightOn !== false).reduce((s, el) => s + (+el.lightLumens || +doc.get(el.typeId)?.lightLumens || 800) / 800, 0);
      const patch = { camera, style, shadows: true, lampLight: !!lamps, lampDimmer: Math.max(0.1, Math.min(0.45, 1.3 / (glow || 1))), interiorFill: 0.4 };
      let v = doc.all('view3d').find((x) => x.name === name);
      app.commit('Assistant: camera view', () => {
        if (v) doc.update(v.id, patch);
        else v = doc.add({ ...default3DView(name), ...patch });
      });
      app.viewStates?.delete(v.id);
      app.openView(v.id);
      // The view may be open already, with the camera it had.
      if (app.vc) {
        app.vc.cam = structuredClone(camera);
        app.vc.userMoved = true;
        app.requestRender?.();
      }
      app.cameraViewId = v.id;
      const { renderViewImage } = await import('../views/snapshot.js');
      const W = 1200;
      const H = Math.round(W / Math.max(0.5, Math.min(3, +aspect || 1.4)));
      const { canvas } = renderViewImage(app, doc.get(v.id), W, H, { fit: false, camera });
      const url = canvas.toDataURL('image/jpeg', 0.85);
      return { view: name, opened: true, _image: { media_type: 'image/jpeg', data: url.slice(url.indexOf(',') + 1) } };
    },
  },
  {
    name: 'render_view',
    description: 'A finished picture of a 3D view by ray tracing (sun, lamps and the light they bounce round the room, pictures and boards on the surfaces): for the final image, not to check your work, since it takes up to a minute. view: its name, the open one by default. samples 40 to 200.',
    parameters: { type: 'object', properties: { view: { type: 'string' }, samples: { type: 'number' } } },
    async run(app, { view, samples = 60 }) {
      const doc = app.doc;
      const v = view ? doc.all('view3d').find((x) => x.name === view) : app.activeView;
      if (v?.kind !== 'view3d') return { error: 'Give a 3D view: the name set_camera answered, or open one' };
      app.openView(v.id);
      const { startRaytrace } = await import('../ui/raytrace.js');
      const W = 1200;
      const H = Math.round(W * (app.viewport.height / app.viewport.width) || 840);
      return new Promise((resolve) => {
        startRaytrace(app, doc.get(v.id), app.vc, W, H, {
          samples: Math.max(8, Math.min(400, +samples || 60)),
          sun: true,
          lamps: true,
          lampDimmer: v.lampDimmer ?? 0.4,
          daylight: v.daylight || 'day',
          depth: 7,
          onError: (error) => resolve({ error }),
          onDone: (canvas, n) => {
            const url = canvas.toDataURL('image/jpeg', 0.9);
            resolve({ view: v.name, samples: n, _image: { media_type: 'image/jpeg', data: url.slice(url.indexOf(',') + 1) } });
          },
        });
      });
    },
  },
  {
    name: 'remove_elements',
    description: 'Delete elements by id (what they host goes with them), one undo step. Only what you made yourself or the user asked to remove; a photo you were given as a reference, when you have finished with it.',
    parameters: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' } } }, required: ['ids'] },
    run(app, { ids }) {
      const known = (ids || []).filter((id) => app.doc.has(id));
      if (!known.length) return { error: 'No such elements' };
      app.commit('Assistant: remove elements', () => deleteElements(app.doc, known));
      return { removed: known.length };
    },
  },
];
