/**
 * Assistant functions for interiors: search the object libraries in Italian or English, load the Archicad
 * libraries from this computer, make parametric furniture, place objects against a wall of a room, and add
 * any model element from a plain description.
 */
import { runGdlType } from '../core/gdlobject.js';
import { furnitureObject, FURNITURE_KINDS, matchesQuery, placeAgainst } from '../core/furniture.js';
import { ArchicadLibrary, partType } from '../core/aclib.js';

const INTERIOR_PACKS = ['Beds', 'Cabinets and Shelves', 'Chairs', 'Couches and Sofas', 'Tables', 'Kitchen', 'Appliances', 'Decoration', 'Light Sources', 'Plumbing Fixtures and Bathroom', 'Office and School Equipment', 'Furniture Macros', 'Object Macros', 'Essential Library'];
const ADDABLE = new Set(['floor', 'ceiling', 'column', 'beam', 'roof', 'stair', 'railing', 'ramp', 'door', 'window', 'opening', 'room', 'morph', 'shell', 'topo', 'duct', 'pipe', 'component', 'wall']);
const TYPE_KIND = { floor: 'floorType', ceiling: 'ceilingType', column: 'columnType', beam: 'beamType', roof: 'roofType', stair: 'stairType', railing: 'railingType', ramp: 'rampType', door: 'doorType', window: 'windowType', duct: 'ductType', pipe: 'pipeType', component: 'componentType', wall: 'wallType' };

const levelOf = (doc, name) => {
  const all = doc.levels();
  if (name == null || name === '') return all[0];
  const n = String(name).toLowerCase();
  return all.find((l) => l.id === name || l.name.toLowerCase() === n) || all.find((l) => l.name.toLowerCase().includes(n)) || null;
};

/** The extent of a room: { x0, y0, x1, y1 } of its floor, or null. */
function roomBox(app, room) {
  const outer = app.scene.rooms.room(room)?.outer || room.boundary;
  if (!outer?.length) return null;
  return { x0: Math.min(...outer.map((p) => p[0])), y0: Math.min(...outer.map((p) => p[1])), x1: Math.max(...outer.map((p) => p[0])), y1: Math.max(...outer.map((p) => p[1])) };
}

const roomNamed = (doc, name) => {
  const n = String(name ?? '').toLowerCase();
  const all = doc.all('room');
  return all.find((r) => r.id === name || r.name?.toLowerCase() === n || String(r.number).toLowerCase() === n) || all.find((r) => r.name?.toLowerCase().includes(n)) || null;
};

/** The plan extent of a placed object from its mesh. */
const extent = (app, el) => {
  const b = app.scene.mesh(el)?.bounds;
  return b ? { x0: b.min[0], y0: b.min[1], x1: b.max[0], y1: b.max[1] } : null;
};

const overlaps = (a, b) => a.x0 < b.x1 - 1 && b.x0 < a.x1 - 1 && a.y0 < b.y1 - 1 && b.y0 < a.y1 - 1;

const SIDE_TURN = { north: 0, west: 90, south: 180, east: -90 };
const sideOf = (v) => (SIDE_TURN[String(v).toLowerCase()] != null ? String(v).toLowerCase() : null);

/** How far to move a piece, from where it really is, so that its outline touches a wall of a room. */
function towardWall(mine, box, side, along, gap) {
  const a = Math.max(0, Math.min(1, along ?? 0.5));
  const w = mine.x1 - mine.x0;
  const d = mine.y1 - mine.y0;
  const dx = box.x0 + (box.x1 - box.x0 - w) * a - mine.x0;
  const dy = box.y0 + (box.y1 - box.y0 - d) * a - mine.y0;
  if (side === 'north') return [dx, box.y1 - gap - mine.y1];
  if (side === 'south') return [dx, box.y0 + gap - mine.y0];
  if (side === 'east') return [box.x1 - gap - mine.x1, dy];
  return [box.x0 + gap - mine.x0, dy];
}

/** How far to move a piece so that it stands on one side of another, centred on it (slide moves it along that side). */
function besidePiece(mine, ref, side, gap, slide = 0) {
  const dx = (ref.x0 + ref.x1) / 2 - (mine.x0 + mine.x1) / 2 + slide;
  const dy = (ref.y0 + ref.y1) / 2 - (mine.y0 + mine.y1) / 2 + slide;
  if (side === 'north') return [dx, ref.y1 + gap - mine.y0];
  if (side === 'south') return [dx, ref.y0 - gap - mine.y1];
  if (side === 'east') return [ref.x1 + gap - mine.x0, dy];
  return [ref.x0 - gap - mine.x1, dy];
}

/**
 * Adds a component where it is asked for, and reports where it ended up and what it runs into. Library objects have
 * their origin anywhere (Archicad's usually at a corner), so the piece goes by its real outline, not by its origin.
 */
function putComponent(app, type, { at, rotation, room, wall, along, level, offset, next_to, side, gap, slide, faces, ignore }, placed) {
  const doc = app.doc;
  const r = room != null ? roomNamed(doc, room) : null;
  if (room != null && !r) return { error: `No room called ${room}; rooms: ${doc.all('room').map((x) => x.name).join(', ') || 'none'}` };
  const other = next_to != null ? placed?.get(next_to) || doc.get(next_to) : null;
  if (next_to != null && !other) return { error: `next_to: no element ${next_to}` };
  const lv = r ? doc.get(r.levelId) : other ? doc.get(other.levelId) : levelOf(doc, level);
  if (!lv) return { error: `No level ${level}` };
  const onWall = sideOf(wall);
  const onSide = other ? sideOf(side) || 'south' : null;
  if (!at && !onWall && !other && !r) return { error: 'Give at: [x, y] in mm, or room and wall (north, south, east, west), or next_to and side' };
  const box = r ? roomBox(app, r) : null;
  if (r && !box) return { error: `Room ${r.name} has no floor outline yet: it needs walls round it` };
  const turn = rotation != null ? +rotation : onWall ? SIDE_TURN[onWall] : other && faces !== false ? SIDE_TURN[onSide] : 0;
  const start = at || (other ? other.at : r.at);
  const el = doc.add({ kind: 'component', typeId: type.id, levelId: lv.id, at: [+start[0], +start[1]], rotation: turn, offset: +offset || 0 });
  let mine = extent(app, el);
  if (mine && !at && (onWall || other || r)) {
    const pad = gap != null ? +gap : other ? 150 : 10;
    const refBox = other ? extent(app, other) : null;
    const move = refBox ? besidePiece(mine, refBox, onSide, pad, +slide || 0) : onWall ? towardWall(mine, box, onWall, along, pad) : [(box.x0 + box.x1 - mine.x0 - mine.x1) / 2, (box.y0 + box.y1 - mine.y0 - mine.y1) / 2];
    doc.update(el.id, { at: [Math.round(el.at[0] + move[0]), Math.round(el.at[1] + move[1])] });
    mine = { x0: mine.x0 + move[0], y0: mine.y0 + move[1], x1: mine.x1 + move[0], y1: mine.y1 + move[1] };
  }
  const skip = new Set([el.id, other?.id, ...(ignore || [])]);
  const hits = mine ? doc.all('component').filter((o) => !skip.has(o.id) && o.levelId === lv.id && (() => { const x = extent(app, o); return x && overlaps(mine, x); })()).map((o) => doc.get(o.typeId)?.name) : [];
  const out = box && mine && (mine.x0 < box.x0 - 1 || mine.y0 < box.y0 - 1 || mine.x1 > box.x1 + 1 || mine.y1 > box.y1 + 1);
  const warnings = [hits.length ? `It overlaps: ${hits.join(', ')}` : '', out ? `It sticks out of ${r.name}` : ''].filter(Boolean);
  return { id: el.id, at: doc.get(el.id).at, rotation: turn, plan_extent: mine, ...(warnings.length ? { warning: warnings.join('. ') } : {}) };
}

function placeComponent(app, type, spec) {
  let out;
  app.commit('Assistant: place object', () => {
    out = putComponent(app, type, spec);
  });
  return out;
}

/** The project type a library reference names, bringing the part into the project the first time. */
function typeOfRef(app, ref) {
  const doc = app.doc;
  const key = String(ref);
  if (key.startsWith('type:')) {
    const t = doc.get(key.slice(5));
    return t?.kind === 'componentType' ? { type: t } : { error: `${ref} is not a placeable object; find one with library_search` };
  }
  if (!key.startsWith('lib:')) return { error: `${ref} is not a placeable object; find one with library_search` };
  const e = app.acLibrary?.get(key.slice(4));
  if (!e) return { error: `${ref} is not in the loaded libraries` };
  return { type: doc.all('componentType').find((t) => t.name === e.name && t.family === 'gdl') || doc.add(partType(app.acLibrary, e)) };
}

/** Where n chairs go round a table: along its long sides first, then at its ends. */
export function seatsAround(w, d, n) {
  const long = w >= d ? ['north', 'south'] : ['east', 'west'];
  const short = w >= d ? ['east', 'west'] : ['north', 'south'];
  const L = Math.max(w, d);
  const fit = Math.max(1, Math.floor(L / 600));
  const onLong = Math.min(n, fit * 2);
  const seats = [];
  for (let s = 0; s < 2; s++) {
    const here = Math.ceil((onLong - s) / 2);
    for (let i = 0; i < here; i++) seats.push({ side: long[s], slide: (i - (here - 1) / 2) * (L / Math.max(here, 1)) });
  }
  for (let i = 0; i < Math.min(n - onLong, 2); i++) seats.push({ side: short[i], slide: 0 });
  return seats;
}

export const INTERIOR_TOOLS = [
  {
    name: 'library_search',
    description: 'Find furniture and objects to place, in Italian or English (armadio, divano, wardrobe...): the project\'s catalogue and every Archicad library loaded. Returns a ref for place_object, with the size in mm. Empty? library_load brings in the interior libraries, or make_furniture makes the piece to measure.',
    parameters: { type: 'object', properties: { query: { type: 'string' }, limit: { type: 'number' } }, required: ['query'] },
    run(app, { query, limit = 25 }) {
      const out = [];
      for (const t of app.doc.all('componentType')) if (matchesQuery(`${t.name} ${t.familyName || ''} ${t.category || ''}`, query)) out.push({ ref: `type:${t.id}`, name: t.name, family: t.familyName, category: t.category, width: t.width, depth: t.depth, height: t.height, source: 'project' });
      const lib = app.acLibrary;
      if (lib) for (const e of lib.objects()) if (matchesQuery(`${e.name} ${e.path}`, query)) out.push({ ref: `lib:${e.name}`, name: e.name, folder: e.path.split('/').slice(0, -1).join('/'), source: 'Archicad library' });
      return { count: out.length, results: out.slice(0, +limit || 25), archicad_library_loaded: !!lib?.parts?.size };
    },
  },
  {
    name: 'library_load',
    description: 'Load the interior object libraries of the Archicad installed on this computer (furniture, kitchens, bathrooms, lighting, decoration), when the app runs on it. On the website, or without Archicad, the user loads them with File > Libraries; make_furniture needs no library.',
    parameters: { type: 'object', properties: { packs: { type: 'array', items: { type: 'string' }, description: 'Names of library packs; by default the interior ones' } } },
    async run(app, { packs }) {
      let list;
      try {
        const res = await fetch('./api/archicad-libraries');
        if (!res.ok || !/json/.test(res.headers.get('content-type') || '')) throw new Error('none');
        list = (await res.json()).files;
      } catch {
        return { error: 'The Archicad libraries are not reachable from here. Use make_furniture and the project catalogue, or ask the user to load them with the Archicad Library command.' };
      }
      const want = (Array.isArray(packs) && packs.length ? packs : INTERIOR_PACKS).map((p) => String(p).toLowerCase());
      const chosen = list.filter((f) => want.includes(f.replace(/\.libpack$/i, '').toLowerCase()));
      app.acLibrary ||= new ArchicadLibrary();
      let added = 0;
      for (const f of chosen) {
        if (app.acLibrary.files.some((x) => x.name === f)) continue;
        const res = await fetch(`./api/archicad-libraries?file=${encodeURIComponent(f)}`);
        if (res.ok) added += app.acLibrary.add(f, new Uint8Array(await res.arrayBuffer()));
      }
      return { packs: chosen.length, parts_added: added, objects: app.acLibrary.objects().length, available: list.map((f) => f.replace(/\.libpack$/i, '')) };
    },
  },
  {
    name: 'make_furniture',
    description: `Make a piece of furniture to measure, as a parametric object (its doors, drawers, shelves and size stay editable), and place it if asked. kind: ${FURNITURE_KINDS.join(', ')}. Sizes in mm; colours by name (white, oak, walnut, grey, black, blue, green, or Italian) or #rrggbb. Place with room and wall (north, south, east, west; along 0..1 from one end), its back to that wall, or with at: [x, y].`,
    parameters: {
      type: 'object',
      properties: {
        kind: { type: 'string', enum: FURNITURE_KINDS },
        name: { type: 'string' },
        width: { type: 'number' },
        depth: { type: 'number' },
        height: { type: 'number' },
        doors: { type: 'number' },
        drawers: { type: 'number' },
        shelves: { type: 'number' },
        color: { type: 'string' },
        front_color: { type: 'string' },
        top_color: { type: 'string' },
        room: { type: 'string' },
        wall: { type: 'string', enum: ['north', 'south', 'east', 'west'] },
        along: { type: 'number' },
        at: { type: 'array', items: { type: 'number' } },
        rotation: { type: 'number' },
        level: { type: 'string' },
        offset: { type: 'number', description: 'Height above the level, mm; a kitchen wall unit is usually 1400' },
      },
      required: ['kind'],
    },
    run(app, input) {
      const fields = furnitureObject(input);
      const check = runGdlType(fields);
      if (check.error) return { error: check.error };
      let type;
      app.commit('Assistant: furniture', () => {
        type = app.doc.add({ kind: 'componentType', family: 'gdl', familyName: 'GDL Object', ...fields });
      });
      const out = { type: type.id, name: type.name, width: type.width, depth: type.depth, height: type.height, triangles: check.tris.length };
      if (input.room != null || input.at) Object.assign(out, placeComponent(app, type, { ...input, offset: input.offset ?? (input.kind === 'kitchen_wall' ? 1400 : 0) }));
      return out;
    },
  },
  {
    name: 'place_object',
    description: 'Place an object found with library_search, by its ref. Against a wall of a room (room and wall: north, south, east, west; along 0..1), its back to it; beside another piece (next_to: its id, side: north, south, east or west of it, gap in mm, slide along that side), facing it unless faces is false; in the middle of a room (room alone); or at [x, y] in mm with a rotation in degrees. It goes by the object\'s real outline. Answers where it went and what it overlaps. For several pieces use place_objects.',
    parameters: { type: 'object', properties: { ref: { type: 'string' }, room: { type: 'string' }, wall: { type: 'string', enum: ['north', 'south', 'east', 'west'] }, along: { type: 'number' }, next_to: { type: 'string' }, side: { type: 'string', enum: ['north', 'south', 'east', 'west'] }, gap: { type: 'number' }, slide: { type: 'number' }, faces: { type: 'boolean' }, at: { type: 'array', items: { type: 'number' } }, rotation: { type: 'number' }, level: { type: 'string' }, offset: { type: 'number' } }, required: ['ref'] },
    run(app, input) {
      let out;
      app.commit('Assistant: place object', () => {
        const { type, error } = typeOfRef(app, input.ref);
        out = error ? { error } : putComponent(app, type, input);
      });
      return out;
    },
  },
  {
    name: 'place_objects',
    description: 'Furnish in one go, one undo step: much quicker than one call per piece. items: each is what place_object takes (ref) or what make_furniture takes (kind), with these additions: key, a name for the piece that later items use in next_to; around: the key or id of a table, with count, to set that many of this chair round it, tucked in. A sofa, then a coffee table next_to it on the side it faces, then chairs around a table, in one list. Answers per item, with warnings.',
    parameters: { type: 'object', properties: { items: { type: 'array', items: { type: 'object' } } }, required: ['items'] },
    run(app, { items }) {
      if (!Array.isArray(items) || !items.length) return { error: 'Give items' };
      const doc = app.doc;
      const placed = new Map();
      const results = [];
      app.commit('Assistant: furnish', () => {
        for (const item of items) {
          let type;
          if (item.kind) {
            const fields = furnitureObject(item);
            const check = runGdlType(fields);
            if (check.error) {
              results.push({ key: item.key, error: check.error });
              continue;
            }
            type = doc.add({ kind: 'componentType', family: 'gdl', familyName: 'GDL Object', ...fields });
          } else {
            const found = typeOfRef(app, item.ref);
            if (found.error) {
              results.push({ key: item.key, error: found.error });
              continue;
            }
            type = found.type;
          }
          if (item.around != null) {
            const table = placed.get(item.around) || doc.get(item.around);
            const box = table && extent(app, table);
            if (!box) {
              results.push({ key: item.key, error: `around: no element ${item.around}` });
              continue;
            }
            const ids = [];
            for (const seat of seatsAround(box.x1 - box.x0, box.y1 - box.y0, Math.max(1, +item.count || 4))) {
              const r = putComponent(app, type, { next_to: table.id, gap: item.gap ?? -120, ...seat, ignore: ids }, placed);
              if (r.id) ids.push(r.id);
              results.push({ key: item.key, name: type.name, ...r });
            }
            continue;
          }
          const offset = item.offset ?? (item.kind === 'kitchen_wall' ? 1400 : 0);
          const r = putComponent(app, type, { ...item, offset }, placed);
          if (r.id && item.key != null) placed.set(item.key, doc.get(r.id));
          results.push({ key: item.key, name: type.name, ...r });
        }
      });
      return { placed: results.filter((r) => r.id).length, results };
    },
  },
  {
    name: 'add_elements',
    description: `Add model elements from a description, several at once (one undo step). Each item: { kind: ${[...ADDABLE].join('|')}, level (name), type (name of its type, optional), and the element's own fields in mm }. floor/ceiling/roof: boundary [[x,y]...] (roof also slopes [degrees per edge]); column/component: at [x,y]; beam/stair/ramp/wall/duct/pipe: a [x,y], b [x,y]; railing: path; door/window/opening: host (wall id) and t (mm along it), window sill; room: at, name. Use trace_floor_plan for whole plans.`,
    parameters: { type: 'object', properties: { items: { type: 'array', items: { type: 'object' } } }, required: ['items'] },
    run(app, { items }) {
      const doc = app.doc;
      if (!Array.isArray(items) || !items.length) return { error: 'Give items' };
      const made = [];
      const failed = [];
      app.commit('Assistant: add elements', () => {
        for (const raw of items) {
          const { kind, level, top_level, type, host, ...fields } = raw || {};
          if (!ADDABLE.has(kind)) {
            failed.push({ kind, error: 'This kind cannot be added here' });
            continue;
          }
          const lv = levelOf(doc, level);
          const el = { kind, ...fields };
          if (lv && !['door', 'window', 'opening'].includes(kind)) el.levelId = lv.id;
          const top = top_level ? levelOf(doc, top_level) : kind === 'wall' || kind === 'column' || kind === 'stair' ? doc.levelAbove(lv?.id) : null;
          if (top) el.topLevelId = top.id;
          const tk = TYPE_KIND[kind];
          if (tk) {
            const list = doc.all(tk);
            const t = (type != null && (list.find((x) => x.id === type || x.name.toLowerCase() === String(type).toLowerCase()) || list.find((x) => x.name.toLowerCase().includes(String(type).toLowerCase())))) || list[0];
            if (!t) {
              failed.push({ kind, error: `No ${tk} in the project` });
              continue;
            }
            el.typeId = t.id;
          }
          if (host) el.hostId = host;
          if (kind === 'wall') Object.assign(el, { baseOffset: 0, topOffset: 0, height: 3000, locationLine: 'center', joinA: true, joinB: true, roomBounding: true, ...el });
          if (kind === 'floor' || kind === 'ceiling') Object.assign(el, { holes: [], offset: 0, ...el });
          if (kind === 'roof') Object.assign(el, { baseOffset: 0, ...el });
          if (kind === 'room') Object.assign(el, { number: el.number ?? String(doc.all('room').length + 1), name: el.name ?? 'Room', upperOffset: el.upperOffset ?? 2700 });
          if (kind === 'column' || kind === 'component') Object.assign(el, { rotation: 0, ...el });
          try {
            made.push({ id: doc.add(el).id, kind });
          } catch (err) {
            failed.push({ kind, error: String(err.message || err) });
          }
        }
      });
      return { made, failed };
    },
  },
];
