# Automating Building Design with Claude Code

Building Design is built so that Claude Code can do with a project everything a person does in the app, and
more: start projects from drawings, check existing ones, document, evaluate and export them — interactively,
or unattended in batches and on a schedule.

## How the pieces fit

```
Claude Code ──MCP (HTTP, token)──▶ dev server /mcp ──server-sent events──▶ app page (browser tab or headless)
     ▲                                  │  reads files for open_project / model_from_file           │
     │                                  │  writes files from save_project / export_file             │
     └──────────── results ◀────────────┴──────────────────────── tools (src/assistant/*.js) ◀──────┘
```

- **Tools.** Every assistant function (`src/assistant/tools.js`, `proptools.js`, `doctools.js`, `filetools.js`)
  is an MCP tool: about 60 of them, covering modelling (`create_walls`, `model_from_file`, `model_from_image`,
  `trace_floor_plan`, `gdl_object`…), information (properties, classifications, keynotes, IDs), checks
  (`model_warnings`, `physical_model_quality`, `check_requirements`, `mep_networks` quality), building physics
  (`energy_evaluation`, `thermal_bridge`), views and graphics, every app command (`search_commands`,
  `run_command`), and files (`new_project`, `open_project`, `save_project`, `export_file`).
- **Bridge** (`mcp-bridge.mjs`, a Vite plugin): `/mcp` speaks MCP over streamable HTTP and needs the token in
  `.env.local` (`npm run mcp:setup` creates it and registers the server with Claude Code). Calls run in the open
  page, each as one undo step. The newest page connected wins; an older one stops listening and says so.
- **Files.** The page never touches the disk. For `open_project` and `model_from_file` the dev server reads the
  file; for `save_project` and `export_file` the page returns the bytes (`download()` is captured while the tool
  runs) and the dev server writes them — only inside the user's home folder and only as file types the app makes
  (`.bdp .ifc .pdf .png .svg .dxf .xlsx .csv .obj .glb .json .txt .md`).
- **Headless.** `npm run headless` opens the app in a headless Chrome (software WebGL) so the bridge has a page
  without any window: for batch work, scheduled checks and CI.

## Setting up

```bash
npm install --ignore-scripts
npm run mcp:setup          # token in .env.local, server registered with Claude Code
npm run dev                # the app and the bridge, http://localhost:5173
npm run headless           # optional: no browser window needed
```

`claude mcp list` shows `building-design … Connected` when it works.

## Skills (`.claude/skills/`)

Claude Code started in this folder has three skills for the usual processes:

| Skill | For | What it does |
|---|---|---|
| `bd-new-project` | a new project from a DWG, DXF, PDF, picture, photo, IFC or a brief | models it, names and classifies zones, gives IDs, runs the checks, evaluates energy and junctions when asked, makes schedules and sheets, saves `.bdp` and exports IFC, PDF, XLSX, SAF |
| `bd-audit` | an existing project (`.bdp`, or IFC/DWG/PDF to bring in) | model quality, rules, missing information, energy and thermal bridges, structure and services; fixes what is unambiguous into a new file and writes a Markdown report |
| `bd-batch` | a folder of drawings or projects | the same steps for every file, without a window, with a summary table |

Ask for them in plain words ("use bd-audit on ~/Progetti/scuola.bdp") or by name.

## Unattended jobs

`scripts/bd-job.sh` runs one request with Claude Code in print mode, starting the headless app if needed and
allowing only the Building Design tools and file reading/writing:

```bash
scripts/bd-job.sh "Use the bd-batch skill on /Users/me/Drawings/incoming" ~/Drawings/incoming/job.log
```

From there it can run on a schedule (cron, launchd, a Claude Code scheduled task) — for example every night on a
folder where new survey drawings arrive, or every Monday as an audit of the projects in progress — or in CI after
each change to the app, as an end-to-end check that real projects still model, check and export.

## Typical processes

- **New project from the client's drawings.** Put the PDFs/DWGs in a folder, run `bd-batch` (or `bd-new-project`
  on one file). Each comes back as a `.bdp` with zones named and measured, IFC for the consultants, plan PDFs and
  schedules, plus a summary of what was uncertain.
- **Existing project brought up to date.** `bd-audit` on the `.bdp` (or on the IFC received): a report by severity
  with numbers (areas, U, ψ, fRsi, kWh/m²a) and a corrected copy.
- **Consultant round trip.** `export_file` IFC and SAF for structure and services; when their model comes back,
  `model_from_file` on the IFC; BCF issues through the Issue Manager.
- **Regression check of the app itself.** Run `bd-new-project` on a set of reference drawings and compare the
  numbers (walls, zones, areas) with the previous run.
