#!/bin/zsh
# Builds Building Design and makes "Building Design.app" in ~/Applications: double-click to open it in its own window.
set -e
HERE="$(cd "$(dirname "$0")/.." && pwd)"
APP="$HOME/Applications/Building Design.app"
cd "$HERE"
node_modules/.bin/vite build
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Building Design</string>
<key>CFBundleDisplayName</key><string>Building Design</string>
<key>CFBundleIdentifier</key><string>local.building-design.app</string>
<key>CFBundleVersion</key><string>1.0</string>
<key>CFBundleShortVersionString</key><string>1.0</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleExecutable</key><string>launch</string>
<key>CFBundleIconFile</key><string>icon</string>
<key>LSMinimumSystemVersion</key><string>12.0</string>
</dict></plist>
PLIST
cat > "$APP/Contents/MacOS/launch" <<LAUNCH
#!/bin/zsh
# Finds a Node runtime, then starts the app from its folder.
for n in "\$HOME/.local/node24/bin/node" /opt/homebrew/bin/node /usr/local/bin/node; do
  if [ -x "\$n" ]; then NODE="\$n"; break; fi
done
if [ -z "\$NODE" ]; then osascript -e 'display alert "Building Design needs Node.js 20 or later."'; exit 1; fi
mkdir -p "\$HOME/Library/Logs"
cd "$HERE"
exec "\$NODE" scripts/app.mjs >> "\$HOME/Library/Logs/BuildingDesign.log" 2>&1
LAUNCH
chmod +x "$APP/Contents/MacOS/launch"
# The icon, from the app's own picture.
SET="$(mktemp -d)/icon.iconset"
mkdir -p "$SET"
for s in 16 32 128 256 512; do
  sips -z $s $s icon.png --out "$SET/icon_${s}x${s}.png" >/dev/null
  sips -z $((s * 2)) $((s * 2)) icon.png --out "$SET/icon_${s}x${s}@2x.png" >/dev/null
done
iconutil -c icns "$SET" -o "$APP/Contents/Resources/icon.icns"
touch "$APP"
echo "Made $APP"
