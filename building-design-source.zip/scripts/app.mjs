/**
 * Building Design as an application: serves the built app (dist/) on this
 * machine with Claude and the MCP bridge, and opens it in a window of its
 * own. The window closes, the server stops. No dev server is needed.
 *
 *   npm run build && npm run app          (--no-window: only the server)
 *
 * Only 127.0.0.1 is served. The API key and the bridge token stay in
 * .env.local and in this process, as under the dev server.
 */
import http from 'node:http';
import { spawn } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { chmodSync, createReadStream, existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import claudeProxy from '../claude-proxy.mjs';
import mcpBridge from '../mcp-bridge.mjs';
import { startTeamServer } from './teamwork.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const DIST = join(ROOT, 'dist');
const PORT = +(process.env.BD_APP_PORT || 5180);
const URL_ = `http://localhost:${PORT}/`;
const NO_WINDOW = process.argv.includes('--no-window');
// Any of these gives the app a window of its own; otherwise the default browser opens it.
const BROWSERS = ['Google Chrome', 'Microsoft Edge', 'Brave Browser', 'Chromium'].map((n) => `/Applications/${n}.app/Contents/MacOS/${n}`);
const DATA = join(homedir(), 'Library', 'Application Support', 'BuildingDesign');
const CONFIG = join(DATA, 'config.env');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.wasm': 'application/wasm', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.map': 'application/json', '.webmanifest': 'application/manifest+json' };

/** Settings from .env.local (KEY=value lines), under what the environment already sets. */
export function readEnv(text) {
  const out = {};
  for (const line of String(text).split(/\r?\n/)) {
    const m = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && !line.trim().startsWith('#')) out[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
  return out;
}

/** The file under dist/ for a request path, or null (never outside dist/). */
export function staticPath(dist, url) {
  const path = decodeURIComponent(String(url).split('?')[0]);
  const file = normalize(join(dist, path === '/' ? 'index.html' : path));
  if (file !== dist && !file.startsWith(dist + sep)) return null;
  return existsSync(file) && statSync(file).isFile() ? file : null;
}

function isRunning() {
  return new Promise((done) => {
    const req = http.get(`${URL_}api/claude-backend`, { timeout: 800 }, (res) => {
      res.resume();
      done(res.statusCode < 500);
    });
    req.on('error', () => done(false));
    req.on('timeout', () => (req.destroy(), done(false)));
  });
}

function openWindow(onClose) {
  if (NO_WINDOW) return;
  const browser = BROWSERS.find((b) => existsSync(b));
  if (!browser) {
    console.log(`Open ${URL_} in a browser.`);
    if (process.platform === 'darwin') spawn('open', [URL_], { stdio: 'ignore' });
    return;
  }
  // A profile of its own: the app's windows, saved projects and recovery are not mixed with the browser's.
  const profile = join(DATA, 'window');
  mkdirSync(profile, { recursive: true });
  const win = spawn(browser, [`--app=${URL_}`, `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check', '--window-size=1600,1000'], { stdio: 'ignore' });
  win.on('exit', () => onClose?.());
}

async function main() {
  if (!existsSync(join(DIST, 'index.html'))) {
    console.error('dist/ is missing: run npm run build first.');
    process.exit(1);
  }
  if (await isRunning()) {
    console.log(`Already running at ${URL_}`);
    return openWindow();
  }
  // A developer's .env.local, else this user's own settings: a packaged copy carries no key of anyone's.
  const envFile = join(ROOT, '.env.local');
  mkdirSync(DATA, { recursive: true });
  const saved = existsSync(CONFIG) ? readEnv(readFileSync(CONFIG, 'utf8')) : {};
  const env = { ...saved, ...(existsSync(envFile) ? readEnv(readFileSync(envFile, 'utf8')) : {}), ...process.env };
  const remember = (patch) => {
    Object.assign(saved, patch);
    writeFileSync(CONFIG, `${Object.entries(saved).map(([k, v]) => `${k}=${v}`).join('\n')}\n`, { mode: 0o600 });
    chmodSync(CONFIG, 0o600);
  };
  if (!env.BD_MCP_TOKEN) {
    env.BD_MCP_TOKEN = randomBytes(24).toString('hex');
    remember({ BD_MCP_TOKEN: env.BD_MCP_TOKEN });
  }
  const routes = [];
  const httpServer = http.createServer((req, res) => {
    for (const [prefix, fn] of routes) {
      if (req.url === prefix || req.url.startsWith(`${prefix}/`) || req.url.startsWith(`${prefix}?`)) {
        req.originalUrl = req.url;
        req.url = req.url.slice(prefix.length) || '/';
        return fn(req, res, () => {
          res.statusCode = 404;
          res.end();
        });
      }
    }
    const file = req.method === 'GET' || req.method === 'HEAD' ? staticPath(DIST, req.url) : null;
    if (!file) {
      res.statusCode = 404;
      return res.end('Not found');
    }
    res.setHeader('Content-Type', MIME[extname(file).toLowerCase()] || 'application/octet-stream');
    res.setHeader('Cache-Control', 'no-cache');
    createReadStream(file).pipe(res);
  });
  // What the two plugins use of a Vite server.
  const server = {
    middlewares: { use: (prefix, fn) => routes.push([prefix, fn]) },
    config: { logger: { info: console.log, warn: console.warn, error: console.error } },
    httpServer,
    // A packaged copy has the tool list ready made, not the sources it comes from.
    ssrLoadModule: (p) => (existsSync(join(ROOT, 'tools.json')) ? Promise.resolve({ toolSchemas: () => JSON.parse(readFileSync(join(ROOT, 'tools.json'), 'utf8')) }) : import(pathToFileURL(join(ROOT, p)).href)),
  };
  // The user's own Claude API key, typed in the app: kept in this user's settings, readable by them alone.
  routes.push(['/api/app-key', (req, res) => {
    const host = req.headers.host || '';
    const site = req.headers['sec-fetch-site'];
    let sameOrigin = false;
    try {
      sameOrigin = new URL(req.headers.origin).host === host;
    } catch {
      sameOrigin = false;
    }
    if (req.method !== 'POST' || !/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host) || !sameOrigin || (site && site !== 'same-origin')) {
      res.statusCode = 403;
      return res.end('{}');
    }
    let body = '';
    req.on('data', (c) => (body = body.length < 4096 ? body + c : body));
    req.on('end', () => {
      let key = '';
      try {
        key = String(JSON.parse(body).key || '').trim();
      } catch {
        key = '';
      }
      res.setHeader('Content-Type', 'application/json');
      if (!/^sk-[a-z]+-[\w-]{8,}$/.test(key)) {
        res.statusCode = 400;
        return res.end(JSON.stringify({ error: 'That does not look like a Claude API key.' }));
      }
      env.ANTHROPIC_API_KEY = key;
      remember({ ANTHROPIC_API_KEY: key });
      res.end(JSON.stringify({ backend: 'api' }));
    });
  }]);
  // This computer as the team's server, on the local network, only when the person using it asks.
  let team = null;
  routes.push(['/api/team-host', (req, res) => {
    const host = req.headers.host || '';
    if (req.method !== 'POST' || !/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host)) {
      res.statusCode = 403;
      return res.end('{}');
    }
    team ||= startTeamServer({ dist: DIST, dir: join(DATA, 'team') });
    team.listening.then(() => {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ urls: team.urls(), code: team.code }));
    });
    return undefined;
  }]);
  claudeProxy(env).configureServer(server);
  mcpBridge(env).configureServer(server);
  httpServer.listen(PORT, '127.0.0.1', () => {
    console.log(`Building Design at ${URL_}`);
    openWindow(() => process.exit(0));
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();
