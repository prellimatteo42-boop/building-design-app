/**
 * Connect Claude Code to Building Design: makes sure .env.local has a
 * BD_MCP_TOKEN, then registers the dev server's /mcp endpoint (mcp-bridge.mjs)
 * with Claude Code for this user. Run again to replace an old registration.
 *
 *   npm run mcp:setup [-- port]     (default port 5173)
 */
import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { findClaudeCode } from '../claude-proxy.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const port = Number(process.argv[2]) || 5173;
const envFile = join(root, '.env.local');

let text = existsSync(envFile) ? readFileSync(envFile, 'utf8') : '';
let token = /^BD_MCP_TOKEN=(\S+)$/m.exec(text)?.[1];
if (!token) {
  token = randomBytes(24).toString('hex');
  text += `${text && !text.endsWith('\n') ? '\n' : ''}\n# Lets Claude Code reach the open project (npm run mcp:setup).\nBD_MCP_TOKEN=${token}\n`;
  writeFileSync(envFile, text, { mode: 0o600 });
  console.log('Added BD_MCP_TOKEN to .env.local');
}

const cli = process.env.CLAUDE_CODE_BIN || findClaudeCode();
if (!cli) {
  console.error('Claude Code was not found. Install it, or set CLAUDE_CODE_BIN, then run this again.');
  process.exit(1);
}
const url = `http://localhost:${port}/mcp`;
try {
  execFileSync(cli, ['mcp', 'remove', 'building-design', '--scope', 'user'], { stdio: 'ignore' });
} catch {
  // not registered yet
}
execFileSync(cli, ['mcp', 'add', '--transport', 'http', '--scope', 'user', 'building-design', url, '--header', `Authorization: Bearer ${token}`], { stdio: 'inherit' });
console.log(`Claude Code can now use Building Design at ${url} while npm run dev is running and the app is open.`);
console.log('Restart the dev server so it reads the token, and start a new Claude Code session to see the tools.');
