/**
 * Building Design without a window: opens the app in a headless Chrome so
 * Claude Code (through the MCP bridge, npm run mcp:setup) can work on
 * projects in the background — batch jobs, scheduled checks, CI — with no
 * browser tab open. The dev server must be running (npm run dev).
 *
 *   npm run headless [-- http://localhost:5173]
 *
 * Stops with Ctrl+C. While it runs it is the page the bridge talks to; a tab
 * opened later in a browser takes over.
 */
import { chromium } from '@playwright/test';

const url = process.argv[2] || process.env.BD_URL || 'http://localhost:5173/';
const browser = await chromium.launch({
  channel: process.env.BD_CHROME_CHANNEL || 'chrome',
  headless: true,
  // Software WebGL2, as the e2e suite uses: works on machines without a GPU.
  args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 1000 } });
page.on('pageerror', (e) => console.error(`page error: ${e.message}`));
page.on('dialog', (d) => d.accept());
await page.goto(url);
await page.waitForFunction(() => window.bd, null, { timeout: 60_000 });
console.log(`Building Design is running headless at ${url} — Claude Code can use it through MCP. Ctrl+C to stop.`);
const stop = async () => {
  await browser.close().catch(() => {});
  process.exit(0);
};
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
await new Promise(() => {});
