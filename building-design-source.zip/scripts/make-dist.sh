#!/bin/zsh
# Makes a copy of Building Design to give to others (macOS, Apple Silicon): release/Building-Design-macOS-arm64.zip.
# It holds the built app, its own Node, the licences and the source. No key, token or project of the person building it.
set -e
setopt extended_glob
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE"
NODE="${BD_NODE:-$HOME/.local/node24}"
[ -x "$NODE/bin/node" ] || { echo "Node not found at $NODE (set BD_NODE)"; exit 1; }
[ "$(file -b "$NODE/bin/node" | grep -c arm64)" = 1 ] || { echo "An arm64 Node is needed"; exit 1; }
node_modules/.bin/vite build
OUT="$HERE/release/Building Design"
APP="$OUT/Building Design.app"
rm -rf "$HERE/release"
RES="$APP/Contents/Resources"
mkdir -p "$APP/Contents/MacOS" "$RES/app/scripts" "$RES/app/node_modules/@anthropic-ai" "$RES/app/node_modules/@opentelemetry" "$RES/app/node_modules/@babel" "$RES/app/node_modules/@stablelib" "$RES/licenses"
cp -R dist "$RES/app/dist"
cp scripts/app.mjs scripts/teamwork.mjs scripts/teamstate.mjs "$RES/app/scripts/"
cp claude-proxy.mjs mcp-bridge.mjs package.json LICENSE "$RES/app/"
# The assistant's tool list, so the sources are not needed to run.
"$NODE/bin/node" --input-type=module -e "
import { writeFileSync } from 'node:fs';
const m = await import('$HERE/src/assistant/tools.js');
writeFileSync('$RES/app/tools.json', JSON.stringify(m.toolSchemas({ bridge: true })));
"
for d in @anthropic-ai/sdk @babel/runtime @opentelemetry/api @stablelib/base64 fast-sha256 json-schema-to-ts standardwebhooks ts-algebra; do
  mkdir -p "$RES/app/node_modules/$(dirname "$d")"
  cp -R "node_modules/$d" "$RES/app/node_modules/$d"
done
cp "$NODE/bin/node" "$RES/node"
# Licences of what ships, and the source the AGPL asks to go with the program.
cp "$NODE/LICENSE" "$RES/licenses/node.txt"
for d in @anthropic-ai/sdk @babel/runtime @opentelemetry/api @stablelib/base64 fast-sha256 json-schema-to-ts standardwebhooks ts-algebra @mlightcad/libredwg-web earcut lucide pdfjs-dist; do
  name="$RES/licenses/$(echo "$d" | tr '/@' '__').txt"
  f=( node_modules/$d/(LICEN[SC]E|LICEN[SC]E.*|COPYING)(N) )
  if [ -n "$f[1]" ]; then cp "$f[1]" "$name"; else "$NODE/bin/node" -e "const p=require('./node_modules/$d/package.json');console.log(p.name+' '+p.version+': licence '+p.license+' (declared in its package.json; see https://spdx.org/licenses/'+p.license+'.html)')" > "$name"; fi
done
cp LICENSE "$RES/licenses/building-design-AGPL-3.0.txt"
TOP="$(git rev-parse --show-toplevel)"
PREFIX="$(git rev-parse --show-prefix)"
git -C "$TOP" archive --format=zip -o "$OUT/building-design-source.zip" "HEAD:${PREFIX%/}"
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Building Design</string>
<key>CFBundleDisplayName</key><string>Building Design</string>
<key>CFBundleIdentifier</key><string>local.building-design.app</string>
<key>CFBundleVersion</key><string>0.1.0</string>
<key>CFBundleShortVersionString</key><string>0.1.0</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleExecutable</key><string>launch</string>
<key>CFBundleIconFile</key><string>icon</string>
<key>LSMinimumSystemVersion</key><string>12.0</string>
<key>LSArchitecturePriority</key><array><string>arm64</string></array>
</dict></plist>
PLIST
cat > "$APP/Contents/MacOS/launch" <<'LAUNCH'
#!/bin/zsh
# Starts the app with the Node inside it.
RES="$(cd "$(dirname "$0")/../Resources" && pwd)"
mkdir -p "$HOME/Library/Logs"
cd "$RES/app"
exec "$RES/node" scripts/app.mjs >> "$HOME/Library/Logs/BuildingDesign.log" 2>&1
LAUNCH
chmod +x "$APP/Contents/MacOS/launch"
SET="$(mktemp -d)/icon.iconset"
mkdir -p "$SET"
for s in 16 32 128 256 512; do
  sips -z $s $s icon.png --out "$SET/icon_${s}x${s}.png" >/dev/null
  sips -z $((s * 2)) $((s * 2)) icon.png --out "$SET/icon_${s}x${s}@2x.png" >/dev/null
done
iconutil -c icns "$SET" -o "$RES/icon.icns"
cat > "$OUT/LEGGIMI.txt" <<'TXT'
Building Design 0.1.0 (macOS, Apple Silicon)

1. Trascina "Building Design.app" nella cartella Applicazioni.
2. La prima volta: tasto destro sull'app, Apri, poi di nuovo Apri. L'app non e' firmata da uno sviluppatore Apple,
   quindi macOS chiede conferma. Se dice che e' danneggiata, in Terminale:
   xattr -dr com.apple.quarantine "/Applications/Building Design.app"
3. Serve Google Chrome (o Edge, Brave, Chromium) per avere la finestra dell'app; senza, si apre nel browser predefinito.

Assistente: alla prima domanda chiede una tua chiave API Claude (console.anthropic.com). Resta solo su questo computer.
Librerie Archicad: se hai Archicad installato puoi caricare le sue librerie dal tuo disco; non sono incluse.
Versione di prova: tieni copie dei progetti importanti.

Licenza: AGPL-3.0. Il codice sorgente e' in building-design-source.zip; le licenze dei componenti sono dentro l'app (Contents/Resources/licenses).
TXT
codesign --force --deep -s - "$APP" 2>&1 | tail -1
# Nothing private goes out: stop if any is found.
BAD=$(grep -rlE "/Users/$USER|sk-[a]nt-[A-Za-z0-9_-]{20}|decompiled/|BD_MCP_TOKEN[=][0-9a-f]{20}" "$RES/app" --exclude-dir=node_modules 2>/dev/null || true)
if [ -n "$BAD" ]; then echo "PRIVATE DATA FOUND:"; echo "$BAD"; exit 1; fi
unzip -l "$OUT/building-design-source.zip" | grep -E "\.env(\.local)?$|\.local-samples|\.bdp$|\.pdf$|\.dwg$" && { echo "PRIVATE FILES IN SOURCE"; exit 1; } || true
[ ! -e "$RES/app/.env.local" ] || { echo ".env.local in the package"; exit 1; }
cd "$HERE/release"
ditto -c -k --keepParent "Building Design" "Building-Design-macOS-arm64.zip"
echo "Made $HERE/release/Building-Design-macOS-arm64.zip"
ls -la "$HERE/release/Building-Design-macOS-arm64.zip"
