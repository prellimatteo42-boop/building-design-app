/**
 * The shared copy of a project on a team server, element by element: who changed what and when, and who has reserved what.
 * An element reserved by someone cannot be changed by anyone else. Two people changing the same free element: the first
 * to send it wins, and the other is told and gets that version.
 */
const same = (a, b) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null);

export class TeamProject {
  constructor({ id, name, format, version, items = [], rev = 1, revs = {}, log = [] }) {
    Object.assign(this, { id, name, format, version, rev, log });
    this.items = new Map(items.map((it) => [it.id, it]));
    this.revs = new Map(Object.entries(revs));
    for (const it of items) if (!this.revs.has(it.id)) this.revs.set(it.id, rev);
  }

  toJSON() {
    return { id: this.id, name: this.name, format: this.format, version: this.version, rev: this.rev, items: [...this.items.values()], revs: Object.fromEntries(this.revs), log: this.log.slice(-200) };
  }

  /** What a person opening the project needs. */
  snapshot() {
    return { id: this.id, name: this.name, rev: this.rev, document: { format: this.format, version: this.version, items: [...this.items.values()] } };
  }

  /** Everything changed after rev, as [[id, item | null]]. */
  since(rev, except = null) {
    const out = [];
    for (const [id, r] of this.revs) if (r > rev && !except?.has(id)) out.push([id, this.items.get(id) ?? null]);
    return out;
  }

  /**
   * Takes one person's changes, made on top of revision `base`. Returns { rev, incoming, rejected: [{ id, by }], conflicts: [id], applied }.
   * incoming is what that person must take: what others did, and the version kept for what could not go in.
   */
  sync({ base = 0, changes = [], user, comment = '' }) {
    const rejected = [];
    const conflicts = [];
    const refused = new Set();
    const applied = new Set();
    const next = this.rev + 1;
    for (const [id, item] of changes) {
      const cur = this.items.get(id) ?? null;
      if (same(cur, item)) continue;
      if (cur?.reservedBy && cur.reservedBy !== user) {
        rejected.push({ id, by: cur.reservedBy });
        refused.add(id);
        continue;
      }
      if ((this.revs.get(id) || 0) > base) {
        conflicts.push(id);
        refused.add(id);
        continue;
      }
      // What says who holds an element changes only through reserve().
      const kept = item ? { ...item } : null;
      if (kept) {
        if (cur?.reservedBy) kept.reservedBy = cur.reservedBy;
        else delete kept.reservedBy;
      }
      if (kept) this.items.set(id, kept);
      else this.items.delete(id);
      this.revs.set(id, next);
      applied.add(id);
    }
    if (applied.size) {
      this.rev = next;
      if (comment || applied.size) this.log.push({ rev: next, user, at: Date.now(), comment, count: applied.size });
    }
    const incoming = this.since(base, applied);
    for (const id of refused) if (!incoming.some(([k]) => k === id)) incoming.push([id, this.items.get(id) ?? null]);
    return { rev: this.rev, incoming, rejected, conflicts, applied: applied.size };
  }

  /** Reserve elements for a person, or release them. All or per element: those held by others are listed in denied. */
  reserve({ ids = [], user, release = false }) {
    const granted = [];
    const denied = [];
    const next = this.rev + 1;
    for (const id of ids) {
      const cur = this.items.get(id);
      if (!cur) continue;
      if (cur.reservedBy && cur.reservedBy !== user) {
        denied.push({ id, by: cur.reservedBy });
        continue;
      }
      if (release ? !cur.reservedBy : cur.reservedBy === user) continue;
      const item = { ...cur };
      if (release) delete item.reservedBy;
      else item.reservedBy = user;
      this.items.set(id, item);
      this.revs.set(id, next);
      granted.push(id);
    }
    if (granted.length) this.rev = next;
    return { rev: this.rev, granted, denied };
  }

  /** Someone left: what they held is free again. */
  releaseAll(user) {
    const ids = [...this.items.values()].filter((it) => it.reservedBy === user).map((it) => it.id);
    return ids.length ? this.reserve({ ids, user, release: true }) : null;
  }
}
