/**
 * Team server: several people work on the same projects, from their own browsers, over the local network.
 * It serves the built app and the shared copies. Anyone who reaches it needs the team code it prints.
 *
 *   npm run build && npm run teamwork        (--port 5190, --dir folder for the projects)
 */
import http from 'node:http';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { createReadStream, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, statSync, writeFileSync } from 'node:fs';
import { networkInterfaces, homedir } from 'node:os';
import { dirname, extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { TeamProject } from './teamstate.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.wasm': 'application/wasm', '.woff2': 'font/woff2' };
const MAX_BODY = 512 * 1024 * 1024;
const ID = /^[a-f0-9]{16}$/;

export function lanAddresses(port) {
  const out = [];
  for (const list of Object.values(networkInterfaces())) for (const a of list || []) if (a.family === 'IPv4' && !a.internal) out.push(`http://${a.address}:${port}/`);
  return out;
}

function sameCode(a, b) {
  const [x, y] = [Buffer.from(String(a)), Buffer.from(String(b))];
  return x.length === y.length && timingSafeEqual(x, y);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new Error('Too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      try {
        resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {});
      } catch {
        reject(new Error('Not JSON'));
      }
    });
    req.on('error', reject);
  });
}

/** Starts the server: { port, dir, dist, code, host }. Returns { server, code, urls, close() }. */
export function startTeamServer({ port = 5190, dir, dist = join(ROOT, 'dist'), code = null, host = '0.0.0.0' } = {}) {
  const DATA = dir || join(homedir(), 'BuildingDesign Team');
  mkdirSync(DATA, { recursive: true });
  const codeFile = join(DATA, 'team-code.txt');
  const teamCode = code || (existsSync(codeFile) ? readFileSync(codeFile, 'utf8').trim() : randomBytes(5).toString('hex'));
  writeFileSync(codeFile, teamCode, { mode: 0o600 });
  const projects = new Map();
  for (const f of readdirSync(DATA)) {
    if (!f.endsWith('.bdteam')) continue;
    try {
      const p = new TeamProject(JSON.parse(readFileSync(join(DATA, f), 'utf8')));
      projects.set(p.id, p);
    } catch (err) {
      console.warn(`Could not read ${f}: ${err.message}`);
    }
  }
  const timers = new Map();
  const persist = (p) => {
    clearTimeout(timers.get(p.id));
    timers.set(p.id, setTimeout(() => {
      const file = join(DATA, `${p.id}.bdteam`);
      writeFileSync(`${file}.tmp`, JSON.stringify(p));
      renameSync(`${file}.tmp`, file);
    }, 300));
  };
  /** project id -> Map of connection -> { user, res } */
  const rooms = new Map();
  const peopleOf = (id) => [...new Set([...(rooms.get(id)?.values() || [])].map((c) => c.user))];
  const tell = (id, event) => {
    const text = `data: ${JSON.stringify(event)}\n\n`;
    for (const c of rooms.get(id)?.values() || []) c.res.write(text);
  };
  const send = (res, status, body) => {
    res.statusCode = status;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(body));
  };
  const staticFile = (req, res) => {
    const path = normalize(decodeURIComponent(new URL(req.url, 'http://x').pathname));
    let file = resolve(dist, `.${path}`);
    if (file !== dist && !file.startsWith(dist + sep)) return send(res, 403, {});
    if (existsSync(file) && statSync(file).isDirectory()) file = join(file, 'index.html');
    if (!existsSync(file)) return send(res, 404, {});
    res.setHeader('Content-Type', MIME[extname(file).toLowerCase()] || 'application/octet-stream');
    res.setHeader('Cache-Control', 'no-cache');
    createReadStream(file).pipe(res);
  };
  const api = async (req, res, parts) => {
    if (!sameCode(req.headers['x-team-code'] || '', teamCode)) {
      await new Promise((r) => setTimeout(r, 400));
      return send(res, 401, { error: 'Wrong team code' });
    }
    if (parts[0] === 'ping') return send(res, 200, { ok: true });
    if (parts[0] === 'projects' && parts.length === 1) {
      if (req.method === 'GET') return send(res, 200, { projects: [...projects.values()].map((p) => ({ id: p.id, name: p.name, rev: p.rev, elements: p.items.size, people: peopleOf(p.id) })) });
      const { name, document } = await readBody(req);
      if (!document?.items) return send(res, 400, { error: 'Nothing to share' });
      const p = new TeamProject({ id: randomBytes(8).toString('hex'), name: String(name || 'Project').slice(0, 200), format: document.format, version: document.version, items: document.items });
      projects.set(p.id, p);
      persist(p);
      return send(res, 200, { id: p.id, rev: p.rev });
    }
    if (parts[0] !== 'p' || !ID.test(parts[1] || '')) return send(res, 404, {});
    const p = projects.get(parts[1]);
    if (!p) return send(res, 404, { error: 'No such project' });
    const action = parts[2];
    if (action === 'state') return send(res, 200, p.snapshot());
    if (action === 'events') {
      const user = String(new URL(req.url, 'http://x').searchParams.get('user') || 'Someone').slice(0, 80);
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
      if (!rooms.has(p.id)) rooms.set(p.id, new Map());
      const key = {};
      rooms.get(p.id).set(key, { user, res });
      res.write(`data: ${JSON.stringify({ rev: p.rev, people: peopleOf(p.id) })}\n\n`);
      tell(p.id, { people: peopleOf(p.id) });
      const beat = setInterval(() => res.write(': keep\n\n'), 20000);
      req.on('close', () => {
        clearInterval(beat);
        rooms.get(p.id)?.delete(key);
        // Whoever is gone for good frees what they held.
        if (!peopleOf(p.id).includes(user)) {
          const r = p.releaseAll(user);
          if (r) {
            persist(p);
            tell(p.id, { rev: p.rev });
          }
        }
        tell(p.id, { people: peopleOf(p.id) });
      });
      return undefined;
    }
    if (req.method !== 'POST') return send(res, 405, {});
    const body = await readBody(req);
    const user = String(body.user || 'Someone').slice(0, 80);
    if (action === 'sync') {
      const out = p.sync({ base: +body.base || 0, changes: Array.isArray(body.changes) ? body.changes : [], user, comment: String(body.comment || '').slice(0, 2000) });
      if (out.applied) {
        persist(p);
        tell(p.id, { rev: out.rev, by: user });
      }
      return send(res, 200, out);
    }
    if (action === 'reserve') {
      const out = p.reserve({ ids: Array.isArray(body.ids) ? body.ids : [], user, release: !!body.release });
      if (out.granted.length) {
        persist(p);
        tell(p.id, { rev: out.rev, by: user });
      }
      return send(res, 200, out);
    }
    if (action === 'history') return send(res, 200, { log: p.log.slice(-200) });
    return send(res, 404, {});
  };
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/team/')) {
      api(req, res, url.pathname.slice(6).split('/').filter(Boolean)).catch((err) => {
        if (!res.headersSent) send(res, 400, { error: err.message });
      });
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, {});
    staticFile(req, res);
    return undefined;
  });
  const listening = new Promise((r) => server.listen(port, host, r));
  return {
    server,
    code: teamCode,
    listening,
    urls: () => lanAddresses(server.address().port),
    close: () => {
      for (const room of rooms.values()) for (const c of room.values()) c.res.end();
      for (const t of timers.values()) clearTimeout(t);
      for (const p of projects.values()) writeFileSync(join(DATA, `${p.id}.bdteam`), JSON.stringify(p));
      return new Promise((r) => server.close(r));
    },
  };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const arg = (n) => {
    const i = process.argv.indexOf(`--${n}`);
    return i > 0 ? process.argv[i + 1] : undefined;
  };
  const t = startTeamServer({ port: +(arg('port') || 5190), dir: arg('dir') });
  await t.listening;
  console.log(`Building Design team server. Team code: ${t.code}`);
  for (const u of t.urls()) console.log(`  ${u}`);
  console.log(`  http://localhost:${t.server.address().port}/`);
}
