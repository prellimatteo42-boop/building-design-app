#!/bin/zsh
# Run a Building Design job with Claude Code, unattended (cron, CI, a scheduled task):
#
#   scripts/bd-job.sh "Use the bd-batch skill on /Users/me/Drawings/2026-11" [log file]
#
# Starts the app without a window if no page is connected, runs Claude Code in print mode with only the
# Building Design tools and file reading/writing allowed, and stops the headless app afterwards.
# Needs the dev server (npm run dev) and Claude Code registered with it (npm run mcp:setup).
set -euo pipefail
cd "$(dirname "$0")/.."
REQUEST="${1:?Say what to do, e.g. \"Use the bd-audit skill on /path/project.bdp\"}"
LOG="${2:-}"
URL="${BD_URL:-http://localhost:5173/}"
curl -sf -o /dev/null "$URL" || { echo "The dev server is not running at $URL: start it with npm run dev." >&2; exit 1; }
node scripts/headless.mjs "$URL" > /dev/null 2>&1 &
HEADLESS=$!
trap 'kill $HEADLESS 2>/dev/null || true' EXIT
sleep 6
CLAUDE="${CLAUDE_CODE_BIN:-claude}"
ARGS=(-p "$REQUEST" --allowedTools "mcp__building-design__*" "Read" "Write" "Glob" "Grep" "Bash(ls:*)" --output-format text)
if [[ -n "$LOG" ]]; then "$CLAUDE" "${ARGS[@]}" | tee "$LOG"; else "$CLAUDE" "${ARGS[@]}"; fi
