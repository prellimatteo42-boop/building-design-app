#!/bin/zsh
# Makes site/: Building Design as a plain website, with the source it was built from (AGPL), ready for any static host.
set -e
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE"
VITE_SOURCE_URL=./building-design-source.zip node_modules/.bin/vite build
rm -rf site
cp -R dist site
touch site/.nojekyll
cp LICENSE site/LICENSE.txt
TOP="$(git rev-parse --show-toplevel)"
PREFIX="$(git rev-parse --show-prefix)"
git -C "$TOP" archive --format=zip -o "$HERE/site/building-design-source.zip" "HEAD:${PREFIX%/}"
# Nothing private goes out: stop if any is found.
BAD=$(grep -rlE "/Users/$USER|sk-[a]nt-[A-Za-z0-9_-]{20}|decompiled/|BD_MCP_TOKEN[=][0-9a-f]{20}" site --exclude=building-design-source.zip 2>/dev/null || true)
if [ -n "$BAD" ]; then echo "PRIVATE DATA FOUND:"; echo "$BAD"; exit 1; fi
unzip -l site/building-design-source.zip | grep -E "\.env(\.local)?$|\.local-samples|\.bdp$|\.pdf$|\.dwg$" && { echo "PRIVATE FILES IN SOURCE"; exit 1; } || true
find site -type f -size +95M | grep . && { echo "A file is too big for GitHub"; exit 1; } || true
du -sh site
echo "Made $HERE/site"
