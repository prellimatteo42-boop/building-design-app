/**
 * Dev-server plugin: Building Design as an MCP server, so Claude Code (or any
 * MCP client) can work on the open project.
 *
 *   POST /mcp          MCP over streamable HTTP, answered with plain JSON.
 *                      Needs "Authorization: Bearer <BD_MCP_TOKEN>" (.env.local).
 *   GET  /api/bridge   The app page listens here (server-sent events) for
 *                      tool calls, runs them on its project with the
 *                      assistant's functions (src/assistant/tools.js), and
 *   POST /api/bridge   posts each result back.
 *
 * The tool list is read from tools.js on the server, so it is there even
 * before the page opens; calls need the page open. Page endpoints accept only
 * same-origin requests from a page this machine serves.
 */
import { timingSafeEqual } from 'node:crypto';
import { readFile, stat, writeFile, mkdir } from 'node:fs/promises';
import { extname, isAbsolute, resolve, dirname, basename, sep } from 'node:path';
import { homedir } from 'node:os';
import { existsSync, readdirSync } from 'node:fs';

const MAX_BODY = 16 * 1024 * 1024;
const MAX_FILE_RESULT = 400 * 1024 * 1024;
const MAX_IMAGE = 40 * 1024 * 1024;
const IMAGE_TYPES = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.pdf': 'application/pdf', '.dwg': 'application/acad', '.dxf': 'application/dxf', '.ifc': 'application/x-step' };
const CALL_TIMEOUT = 60_000;
// Tools that may read big drawings or write big files get longer.
const SLOW_TOOLS = new Set(['model_from_file', 'import_floor_plan_image', 'export_file', 'save_project', 'open_project', 'model_from_image', 'thermal_bridge']);
const LOCAL_HOST = /^(localhost|127\.0\.0\.1|\[::1\]|[a-z0-9.-]+\.localhost)(:\d+)?$/i;
const PROTOCOL = '2025-06-18';
const INSTRUCTIONS =
  'Building Design is a building information modeling app running in the browser. These tools act on the project open in it: look before you change, lengths are millimetres, and every change is one undo step the user can take back.';

// Where Archicad keeps its libraries, by language of the install.
const ARCHICAD_LIBRARIES = ['/Applications/Graphisoft/Archicad 30/Pacchetti Libreria Archicad', '/Applications/Graphisoft/Archicad 30/Archicad Library Packages', 'C:/Program Files/Graphisoft/Archicad 30/Pacchetti Libreria Archicad', 'C:/Program Files/Graphisoft/Archicad 30/Archicad Library Packages'];

export default function mcpBridge(env) {
  const token = env.BD_MCP_TOKEN || '';
  let page = null; // the listening page's event stream
  let nextId = 1;
  const pending = new Map();

  /** Run a tool in the open page; resolves to its result object. */
  function callPage(name, input) {
    if (!page) return Promise.resolve({ error: 'Building Design is not open. Open it in a browser (npm run dev, then the address it prints) and try again.' });
    const id = nextId++;
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        pending.delete(id);
        resolve({ error: 'The app did not answer in time.' });
      }, SLOW_TOOLS.has(name) ? CALL_TIMEOUT * 5 : CALL_TIMEOUT);
      pending.set(id, (result) => {
        clearTimeout(timer);
        resolve(result);
      });
      page.write(`event: call\ndata: ${JSON.stringify({ id, name, input: input || {} })}\n\n`);
    });
  }

  return {
    name: 'mcp-bridge',
    apply: 'serve',
    configureServer(server) {
      const tools = async () => (await server.ssrLoadModule('/src/assistant/tools.js')).toolSchemas({ bridge: true });

      // The Archicad libraries installed on this computer, for the page to load (only to pages this machine serves).
      server.middlewares.use('/api/archicad-libraries', async (req, res) => {
        const site = req.headers['sec-fetch-site'];
        if (req.method !== 'GET' || (site && site !== 'same-origin') || !/^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(req.headers.host || '')) return reply(res, 403, { error: 'Only this app' });
        const dir = ARCHICAD_LIBRARIES.find((d) => existsSync(d));
        if (!dir) return reply(res, 404, { error: 'Archicad is not installed here' });
        const names = readdirSync(dir).filter((f) => f.endsWith('.libpack'));
        const file = new URL(req.url, 'http://x').searchParams.get('file');
        if (!file) return reply(res, 200, { files: names });
        if (!names.includes(file)) return reply(res, 404, { error: 'No such library' });
        res.setHeader('Content-Type', 'application/octet-stream');
        res.end(await readFile(resolve(dir, file)));
      });
      server.middlewares.use('/mcp', async (req, res) => {
        if (req.method !== 'POST') {
          res.setHeader('Allow', 'POST');
          return reply(res, 405, { error: 'Use POST' });
        }
        if (!token) return reply(res, 503, { error: 'No BD_MCP_TOKEN in .env.local. Run npm run mcp:setup.' });
        if (!authorized(req.headers.authorization, token)) return reply(res, 401, { error: 'Unauthorized' });
        // Browsers send Origin; MCP clients do not. Only this app's own pages may.
        if (req.headers.origin && !fromThisPage(req)) return reply(res, 403, { error: 'Forbidden' });
        let msg;
        try {
          msg = JSON.parse(await readBody(req));
        } catch {
          return reply(res, 400, rpcError(null, -32700, 'Parse error'));
        }
        const batch = Array.isArray(msg) ? msg : [msg];
        const out = [];
        for (const m of batch) {
          if (m?.id === undefined || m.id === null) continue; // notifications need no answer
          out.push(await handle(m));
        }
        if (!out.length) {
          res.statusCode = 202;
          return res.end();
        }
        reply(res, 200, Array.isArray(msg) ? out : out[0]);
      });

      async function handle(m) {
        try {
          switch (m.method) {
            case 'initialize':
              return { jsonrpc: '2.0', id: m.id, result: { protocolVersion: m.params?.protocolVersion || PROTOCOL, capabilities: { tools: { listChanged: false } }, serverInfo: { name: 'building-design', version: '0.1.0' }, instructions: INSTRUCTIONS } };
            case 'ping':
              return { jsonrpc: '2.0', id: m.id, result: {} };
            case 'tools/list':
              return { jsonrpc: '2.0', id: m.id, result: { tools: (await tools()).map((t) => ({ name: t.name, description: t.description, inputSchema: t.input_schema })) } };
            case 'tools/call': {
              const { name, arguments: input } = m.params || {};
              if (!(await tools()).some((t) => t.name === name)) return rpcError(m.id, -32602, `Unknown tool ${name}`);
              const prepared = name === 'import_floor_plan_image' || name === 'model_from_file' ? await withImageFile(input) : name === 'open_project' ? await withProjectFile(input) : name === 'ids_check' && input?.path ? await withTextFile(input, 'ids_text') : input;
              let result = prepared?.error ? prepared : await callPage(name, prepared);
              // A file a tool made (save_project, export_file) is written where the client asked.
              if (result?._file) result = await writeToolFile(input?.path, result);
              // A picture in a result (view_image) goes to the client as image content.
              const { _image, ...rest } = result || {};
              const content = [{ type: 'text', text: JSON.stringify(rest) }];
              if (_image?.data) content.push({ type: 'image', data: _image.data, mimeType: _image.media_type });
              return { jsonrpc: '2.0', id: m.id, result: { content, isError: !!result?.error } };
            }
            default:
              return rpcError(m.id, -32601, `Method not found: ${m.method}`);
          }
        } catch (err) {
          server.config.logger.error(`mcp: ${err?.stack || err}`);
          return rpcError(m.id, -32603, 'Internal error');
        }
      }

      server.middlewares.use('/api/bridge', async (req, res) => {
        if (!fromThisPage(req)) return reply(res, 403, { error: 'Only this app may use the bridge' });
        if (req.method === 'GET') {
          res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
          res.write(': connected\n\n');
          // The newest page wins; the one it replaces is told to stop listening, or its EventSource would
          // reconnect at once and the two pages would take the bridge from each other in turn.
          if (page) {
            page.write('event: replaced\ndata: {}\n\n');
            page.end();
          }
          page = res;
          const ping = setInterval(() => res.write(': ping\n\n'), 15_000);
          req.on('close', () => {
            clearInterval(ping);
            if (page === res) page = null;
          });
          return;
        }
        if (req.method !== 'POST') return reply(res, 405, { error: 'Use GET or POST' });
        if (!/^application\/json\b/i.test(req.headers['content-type'] || '')) return reply(res, 415, { error: 'Send JSON' });
        try {
          // Results may carry an exported file (export_file, save_project).
          const { id, result } = JSON.parse(await readBody(req, MAX_FILE_RESULT));
          pending.get(id)?.(result ?? { ok: true });
          pending.delete(id);
          reply(res, 200, { ok: true });
        } catch (err) {
          reply(res, 400, { error: err.message });
        }
      });
    },
  };
}

/**
 * import_floor_plan_image from an MCP client: read the picture at `path`
 * (an image, PDF, DWG or DXF file on this machine, at most 40 MB) into a data URL for the page.
 */
async function withImageFile(input) {
  const path = input?.path;
  if (typeof path !== 'string' || !isAbsolute(path)) return { error: 'Pass path, the absolute path of a PNG, JPEG, PDF, DWG or DXF file on this computer' };
  const type = IMAGE_TYPES[extname(path).toLowerCase()];
  if (!type) return { error: 'Only PNG, JPEG, WebP, GIF images, PDF, DWG, DXF and IFC files can be placed' };
  try {
    const info = await stat(path);
    if (!info.isFile()) return { error: 'That path is not a file' };
    if (info.size > MAX_IMAGE) return { error: 'That file is larger than 40 MB' };
    const data = await readFile(path);
    const { path: _p, ...rest } = input;
    return { ...rest, name: rest.name || path.split('/').pop(), data_url: `data:${type};base64,${data.toString('base64')}` };
  } catch {
    return { error: 'That image could not be read' };
  }
}

function authorized(header, token) {
  const got = Buffer.from(String(header || ''));
  const want = Buffer.from(`Bearer ${token}`);
  return got.length === want.length && timingSafeEqual(got, want);
}

const WRITE_TYPES = new Set(['.bdp', '.ifc', '.pdf', '.png', '.svg', '.dxf', '.xlsx', '.csv', '.obj', '.glb', '.kmz', '.json', '.txt', '.md']);

/** A path the bridge may write: absolute, inside the home folder, of a file type the app makes. */
function writablePath(path) {
  if (typeof path !== 'string' || !isAbsolute(path)) return 'Pass path, an absolute path on this computer';
  const full = resolve(path);
  const home = homedir();
  if (!full.startsWith(home + sep)) return `Write inside your home folder (${home})`;
  if (!WRITE_TYPES.has(extname(full).toLowerCase())) return `Use one of these file types: ${[...WRITE_TYPES].join(' ')}`;
  return null;
}

/** open_project from an MCP client: read the project file at `path` for the page. */
async function withProjectFile(input) {
  const path = input?.path;
  if (typeof path !== 'string' || !isAbsolute(path)) return { error: 'Pass path, the absolute path of a .bdp project file' };
  if (extname(path).toLowerCase() !== '.bdp') return { error: 'open_project opens .bdp projects; use model_from_file for DWG, DXF, IFC, PDF and pictures' };
  try {
    const info = await stat(path);
    if (!info.isFile()) return { error: 'That path is not a file' };
    if (info.size > MAX_IMAGE * 4) return { error: 'The file is too large' };
    return { name: basename(path), data_base64: (await readFile(path)).toString('base64') };
  } catch {
    return { error: `Cannot read ${path}` };
  }
}

/** A tool that reads a text file (an IDS): the dev server reads `path` into input[field]. */
async function withTextFile(input, field) {
  const path = input?.path;
  if (typeof path !== 'string' || !isAbsolute(path)) return { error: 'Pass path, an absolute path on this computer' };
  try {
    const info = await stat(path);
    if (!info.isFile() || info.size > MAX_BODY) return { error: 'That path is not a readable file (or it is too large)' };
    const { path: _p, ...rest } = input;
    return { ...rest, [field]: await readFile(path, 'utf8') };
  } catch {
    return { error: `Cannot read ${path}` };
  }
}

/** Write the file a tool returned (`_file.base64`) to `path`; the result says where. */
async function writeToolFile(path, result) {
  const bad = writablePath(path);
  if (bad) return { error: bad };
  const { _file, ...rest } = result;
  const full = resolve(path);
  await mkdir(dirname(full), { recursive: true });
  await writeFile(full, Buffer.from(_file.base64, 'base64'));
  return { ...rest, written: full, bytes: _file.bytes };
}

/** A same-origin request from a page this machine serves (no other site, no rebinding). */
function fromThisPage(req) {
  const host = req.headers.host || '';
  if (!LOCAL_HOST.test(host)) return false;
  const site = req.headers['sec-fetch-site'];
  if (site && site !== 'same-origin') return false;
  // EventSource GETs may come without Origin; the fetch metadata above covers them.
  if (!req.headers.origin) return req.method === 'GET' && site === 'same-origin';
  try {
    return new URL(req.headers.origin).host === host;
  } catch {
    return false;
  }
}

function rpcError(id, code, message) {
  return { jsonrpc: '2.0', id, error: { code, message } };
}

function readBody(req, max = MAX_BODY) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > max) {
        reject(new Error('Request too large'));
        req.destroy();
      } else chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function reply(res, status, data) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(data));
}
