import { describe, it, expect } from 'vitest';
import { egressAnalysis, zoneOccupants, minDoorWidth, RVITA } from '../src/core/egress.js';

const rect = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
// A corridor 40 m long and 2 m wide (y 0..2000), walls 200 thick round it, a room 4 x 4 m on its north side at x 0..4000.
function building({ eastExit = true } = {}) {
  const barriers = [rect(-200, -200, 40200, 0), rect(-200, 2000, 40200, 2200), rect(-200, 0, 0, 2000), rect(40000, 0, 40200, 2000), rect(-200, 2200, 0, 6200), rect(4000, 2200, 4200, 6200), rect(-200, 6000, 4200, 6200)];
  const openings = [
    { id: 'west', poly: rect(-250, 500, 50, 1500), width: 1000 },
    { id: 'room', poly: rect(1000, 1950, 1900, 2250), width: 900 },
  ];
  if (eastExit) openings.push({ id: 'east', poly: rect(39950, 500, 40250, 1500), width: 1000 });
  const rooms = [
    { id: 'c', name: 'Corridoio', poly: rect(0, 0, 40000, 2000), occupants: 0 },
    { id: 'r', name: 'Camera', poly: rect(0, 2200, 4000, 6000), occupants: 2 },
  ];
  return { barriers, openings, rooms };
}

describe('escape check after the fire code', () => {
  it('measures the longest walk to an exit and the dead end, with exits at both ends', () => {
    const res = egressAnalysis({ ...building(), profile: 'Ciii2', cell: 100 });
    const corr = res.rooms.find((r) => r.id === 'c');
    // Halfway along the corridor is 20 m from either end.
    expect(corr.les).toBeGreaterThan(19.5);
    expect(corr.les).toBeLessThan(21);
    // Two exits: no dead end in the corridor.
    expect(corr.lcc).toBeLessThan(1);
    const room = res.rooms.find((r) => r.id === 'r');
    // The room's far corner to the west exit: about 5.5 m within it, then along to the door.
    expect(room.les).toBeGreaterThan(5);
    expect(room.les).toBeLessThan(9);
    // Its dead end is the way out of the room into the corridor.
    expect(room.lcc).toBeGreaterThan(3);
    expect(room.lcc).toBeLessThan(7);
    expect(room.exitId).toBe('west');
    expect(room.path.length).toBeGreaterThan(1);
    expect(res.exits.map((e) => e.id).sort()).toEqual(['east', 'west']);
  });

  it('fails a long corridor with one exit (a dead end longer than allowed)', () => {
    const res = egressAnalysis({ ...building({ eastExit: false }), profile: 'Ciii2', cell: 100 });
    const corr = res.rooms.find((r) => r.id === 'c');
    expect(corr.les).toBeGreaterThan(39);
    expect(corr.lcc).toBeGreaterThan(RVITA.Ciii2.lcc);
    expect(corr.ok).toBe(false);
    expect(res.ok).toBe(false);
  });

  it('counts occupants by use and sizes doorways', () => {
    expect(zoneOccupants('Sala da pranzo', 30e6)).toBe(21);
    expect(zoneOccupants('Camera 12', 15e6)).toBe(2);
    expect(zoneOccupants('Corridoio A', 60e6)).toBe(0);
    expect(zoneOccupants('Camera', 15e6, { beds: 3 })).toBe(3);
    expect(minDoorWidth(8)).toBe(700);
    expect(minDoorWidth(40)).toBe(800);
    expect(minDoorWidth(120)).toBe(900);
  });
});

describe('thin partitions', () => {
  it('does not let the walk pass through a wall thinner than a cell', () => {
    const rect = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
    // Two rooms side by side, a 60 mm partition between them, the exit in the west room only; the east room's door
    // opens to a closed lobby (no way out).
    const barriers = [rect(-200, -200, 8200, 0), rect(-200, 4000, 8200, 4200), rect(-200, 0, 0, 4000), rect(8000, 0, 8200, 4000), rect(3970, 0, 4030, 4000)];
    const openings = [{ id: 'exit', poly: rect(-250, 1500, 50, 2500), width: 1000 }];
    const rooms = [{ id: 'w', name: 'W', poly: rect(0, 0, 3970, 4000), occupants: 1 }, { id: 'e', name: 'E', poly: rect(4030, 0, 8000, 4000), occupants: 1 }];
    const res = egressAnalysis({ barriers, openings, rooms, profile: 'A2', cell: 150 });
    expect(res.rooms.find((r) => r.id === 'e').les).toBe(Infinity);
    expect(res.rooms.find((r) => r.id === 'w').les).toBeLessThan(6);
  });
});
