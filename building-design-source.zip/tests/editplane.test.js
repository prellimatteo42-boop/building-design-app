import { describe, it, expect } from 'vitest';
import { rayPlane, inputPoint, horizontalPlane, planeFromSurface, resultNormal, offsetPatch, isHorizontal } from '../src/core/editplane.js';

const close = (a, b) => a.forEach((v, i) => expect(v).toBeCloseTo(b[i], 6));

describe('editing plane and input projections', () => {
  const o = [0, -10000, 5000];
  const d = [0, 1, -0.5];
  it('meets a horizontal or a vertical plane', () => {
    close(rayPlane(o, d, horizontalPlane(0)), [0, 0, 0]);
    const wall = planeFromSurface({ p: [0, -2000, 0], n: [0, -1, 0] });
    expect(isHorizontal(wall)).toBe(false);
    close(rayPlane(o, d, wall), [0, -2000, 1000]);
  });
  it('constrains points after the first one', () => {
    const plane = horizontalPlane(0);
    const anchor = [0, -4000, 2000];
    close(inputPoint(o, d, plane, { mode: 'horizontal', anchor }), [0, -4000, 2000]);
    const v = inputPoint(o, [0.3, 1, -0.5], plane, { mode: 'vertical', anchor, view: d });
    expect(v[1]).toBeCloseTo(-4000);
    close(inputPoint(o, d, plane, { mode: 'perpEdit', anchor: [0, -2000, 0] }), [0, -2000, 1000]);
  });
  it('finds the plane of the points so far', () => {
    close(resultNormal([[0, 0, 0], [1000, 0, 0], [1000, 0, 1000]]), [0, -1, 0]);
    expect(resultNormal([[0, 0, 0], [1, 0, 0]])).toBeNull();
  });
  it('gives the placed element its height on the level', () => {
    expect(offsetPatch('component', 3500, 3000)).toEqual({ offset: 500 });
    expect(offsetPatch('column', 3000, 3000)).toEqual({ baseOffset: 0 });
    expect(offsetPatch('wall', 3500, 3000)).toBeNull();
  });
});

import { wrapText, textBox, boxWidthFor } from '../src/core/textbox.js';
describe('text boxes', () => {
  it('wrap words to the box width', () => {
    expect(wrapText('one two three four', 9)).toEqual(['one two', 'three', 'four']);
    expect(wrapText('a\nb c', 3)).toEqual(['a', 'b c']);
    const b = textBox({ text: 'one two three four', boxWidth: 15 }, 250, 'left', 100);
    expect(b.w).toBe(1500);
    expect(b.lines).toEqual(['one two', 'three four']);
    expect(textBox({ text: 'abc' }, 100).w).toBeCloseTo(180);
    expect(boxWidthFor(2000, 100)).toBe(20);
    expect(boxWidthFor(10, 100)).toBe(5);
  });
});
