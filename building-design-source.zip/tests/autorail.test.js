import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { railingsOnStair, railingsOnSlabEdges } from '../src/core/autorail.js';
import { stairLayout } from '../src/core/model.js';
import { build3D } from '../src/core/build3d.js';
import { WallSolver } from '../src/core/walls.js';

describe('railings on elements', () => {
  it('climb both sides of a straight stair', () => {
    const p = project();
    const stair = p.add({ kind: 'stair', typeId: p.doc.all('stairType')[0].id, levelId: p.L1.id, topLevelId: p.L2.id, a: [0, 0], b: [4000, 0], shape: 'straight' });
    const rails = railingsOnStair(p.doc, stair, p.doc.all('railingType')[0].id);
    expect(rails.length).toBe(2);
    const lay = stairLayout(p.doc, stair);
    expect(rails[0].pathZ[1] - rails[0].pathZ[0]).toBeCloseTo((lay.risers - 1) * lay.riserHeight, 6);
    const mesh = build3D({ doc: p.doc, walls: new WallSolver(p.doc), material: (id) => p.doc.get(id) }, rails[0]);
    expect(mesh.bounds.max[2]).toBeGreaterThan(lay.risers * lay.riserHeight);
  });

  it('run along the outer edges of a landing', () => {
    const p = project();
    const stair = p.add({ kind: 'stair', typeId: p.doc.all('stairType')[0].id, levelId: p.L1.id, topLevelId: p.L2.id, a: [0, 0], b: [4000, 0], shape: 'l' });
    const rails = railingsOnStair(p.doc, stair, p.doc.all('railingType')[0].id);
    // Two flights with two sides each, and the landing's two outer edges.
    expect(rails.length).toBe(6);
    expect(rails.filter((r) => !r.pathZ).length).toBe(2);
  });

  it('run along the free edges of a slab', () => {
    const p = project();
    const slab = p.add({ kind: 'floor', typeId: p.doc.all('floorType')[0].id, levelId: p.L2.id, boundary: [[0, 0], [4000, 0], [4000, 1500], [0, 1500]], offset: 0 });
    // A wall along the back edge.
    p.add({ kind: 'wall', typeId: 'wt-generic', levelId: p.L2.id, a: [0, 1600], b: [4000, 1600], height: 3000, locationLine: 'center' });
    const rails = railingsOnSlabEdges(p.doc, slab, p.doc.all('railingType')[0].id);
    expect(rails.length).toBe(3);
    // Inside the slab.
    expect(rails.every((r) => r.path.every((q) => q[0] >= 0 && q[0] <= 4000 && q[1] >= 0 && q[1] <= 1500))).toBe(true);
  });
});
