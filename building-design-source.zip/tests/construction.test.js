import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { simState, tasksByElement, scheduleSpan, frameDates, scheduleFile, readScheduleFile } from '../src/core/construction.js';

describe('construction simulation', () => {
  const pr = {
    construction: {
      name: 'Site',
      tasks: [
        { id: 't1', name: 'Walls', start: '2026-03-01', end: '2026-03-20', action: 'build', ids: ['w1'] },
        { id: 't2', name: 'Scaffold', start: '2026-03-05', end: '2026-04-10', action: 'temporary', ids: ['s1'] },
        { id: 't3', name: 'Old shed', start: '2026-04-01', end: '2026-04-05', action: 'demolish', ids: ['old'] },
      ],
    },
  };
  const by = tasksByElement(pr);
  it('hides, colours and removes elements by date', () => {
    expect(simState(by, 'w1', '2026-02-28')).toBe('hidden');
    expect(simState(by, 'w1', '2026-03-10')).toBe('building');
    expect(simState(by, 'w1', '2026-03-25')).toBe('built');
    expect(simState(by, 'door', '2026-02-28', 'w1')).toBe('hidden'); // hosted: follows its wall
    expect(simState(by, 's1', '2026-03-01')).toBe('hidden');
    expect(simState(by, 's1', '2026-03-06')).toBe('temporary');
    expect(simState(by, 'old', '2026-03-01')).toBe('built');
    expect(simState(by, 'old', '2026-04-02')).toBe('demolishing');
    expect(simState(by, 'old', '2026-04-06')).toBe('hidden');
    expect(simState(by, 'other', '2026-01-01')).toBe('none');
    expect(scheduleSpan(pr)).toEqual({ start: '2026-03-01', end: '2026-04-10' });
    const f = frameDates(pr, 3);
    expect(f).toEqual(['2026-03-01', '2026-03-21', '2026-04-10']);
  });

  it('saves the schedule and reopens it in a copy by IFC GlobalId', () => {
    const p = project();
    const w = p.wall([0, 0], [3000, 0], { ifcGuid: 'GUID-1' });
    p.doc.transact('s', () => p.doc.update('project', { construction: { name: 'S', tasks: [{ id: 't', name: 'W', start: '2026-01-01', end: '2026-01-02', action: 'build', ids: [w.id] }] } }));
    const file = scheduleFile(p.doc);
    const q = project();
    const w2 = q.wall([0, 0], [3000, 0], { ifcGuid: 'GUID-1' });
    const { schedule, missing } = readScheduleFile(q.doc, file);
    expect(schedule.tasks[0].ids).toEqual([w2.id]);
    expect(missing).toBe(0);
  });
});
