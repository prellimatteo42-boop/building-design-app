import { describe, it, expect } from 'vitest';
import { MeshBuilder } from '../src/core/mesh.js';
import { meshPolygons, subtract, union, intersect, polygonsMesh } from '../src/core/csg.js';

const box = (x0, y0, z0, x1, y1, z1) => {
  const b = new MeshBuilder();
  b.box(x0, y0, z0, x1, y1, z1, [200, 200, 200, 255]);
  return meshPolygons(b.build());
};

/** Volume of a closed polygon set (divergence theorem over fan triangles). */
function volume(polys) {
  let v = 0;
  for (const p of polys)
    for (let i = 1; i + 1 < p.vs.length; i++) {
      const [a, b, c] = [p.vs[0].p, p.vs[i].p, p.vs[i + 1].p];
      v += (a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0]) + a[2] * (b[0] * c[1] - b[1] * c[0])) / 6;
    }
  return v;
}

describe('csg', () => {
  const A = () => box(0, 0, 0, 1000, 1000, 1000);
  const B = () => box(500, 500, 500, 1500, 1500, 1500);

  it('subtracts, unites and intersects boxes', () => {
    expect(volume(A())).toBeCloseTo(1e9, -3);
    expect(volume(subtract(A(), B()))).toBeCloseTo(1e9 - 1.25e8, -3);
    expect(volume(union(A(), B()))).toBeCloseTo(2e9 - 1.25e8, -3);
    expect(volume(intersect(A(), B()))).toBeCloseTo(1.25e8, -3);
  });

  it('makes a mesh with edges of the result', () => {
    const m = polygonsMesh(subtract(A(), B()));
    expect(m.pos.length % 9).toBe(0);
    expect(m.edges.length).toBeGreaterThan(0);
    expect(m.bounds.max[0]).toBeCloseTo(1000, 3);
  });
});
