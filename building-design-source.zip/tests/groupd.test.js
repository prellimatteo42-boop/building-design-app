import { describe, it, expect } from 'vitest';
import { createSampleProject } from '../src/core/sample.js';
import { createProject } from '../src/core/template.js';
import { Scene } from '../src/core/scene.js';
import { writeIFC } from '../src/io/ifc.js';
import { ifcToModel } from '../src/io/ifcmodel.js';
import { collada, kml, kmz } from '../src/io/kmz.js';
import { readZip } from '../src/io/zip.js';

describe('IFC local preferences', () => {
  it('leave GlobalIds and property sets out when asked, and still put doors in their walls', () => {
    const src = createSampleProject();
    const text = writeIFC({ doc: src, scene: new Scene(src) });
    const ifc = typeof text === 'string' ? text : text.text;
    const doc = createProject({ system: 'metric' });
    let out;
    doc.transact('Open IFC', () => (out = ifcToModel(doc, ifc, { prefs: { keepGuids: false, keepProps: false } })));
    expect(doc.all('wall').some((w) => w.ifcGuid || w.ifcProps)).toBe(false);
    expect(out.doors).toBe(src.all('door').length);
  });
});

describe('Google Earth', () => {
  const mesh = { name: 'box', pos: new Float32Array([0, 0, 0, 1000, 0, 0, 0, 1000, 0, 0, 0, 0, 0, 1000, 0, 0, 0, 3000]), col: new Uint8Array([255, 0, 0, 255, 255, 0, 0, 255, 255, 0, 0, 255, 0, 0, 255, 255, 0, 0, 255, 255, 0, 0, 255, 255]) };
  it('writes COLLADA in metres with one material per colour', () => {
    const x = collada([mesh]);
    expect(x).toContain('<up_axis>Z_UP</up_axis>');
    expect(x).toContain('0 0 0 1 0 0 0 1 0 0 0 0 0 1 0 0 0 3');
    expect(x.match(/<material id=/g)).toHaveLength(2);
    expect(x).toContain('<color>1 0 0 1</color>');
  });
  it('places the model at the project location turned to true north', () => {
    const k = kml({ name: 'House', lat: 45.07, lon: 7.69, heading: 30 });
    expect(k).toContain('<latitude>45.07</latitude>');
    expect(k).toContain('<heading>30</heading>');
  });
  it('packs both in a KMZ', async () => {
    const files = await readZip(kmz([mesh], { name: 'House', location: { lat: 45, lon: 7 }, trueNorth: 10 }));
    const names = (Array.isArray(files) ? files.map((f) => f.name) : [...(files.keys?.() || Object.keys(files))]).sort();
    expect(names).toEqual(['doc.kml', 'models/model.dae']);
  });
});
