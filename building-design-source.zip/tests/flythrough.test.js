import { describe, it, expect } from 'vitest';
import { cameraEye, cameraLooking, cameraAt, pathCameras } from '../src/core/flythrough.js';

describe('fly-through', () => {
  it('turns eye and target into an orbit camera and back', () => {
    const c = cameraLooking([1000, 2000, 1600], [5000, 2000, 1600]);
    const e = cameraEye(c);
    expect(e[0]).toBeCloseTo(1000, 6);
    expect(e[1]).toBeCloseTo(2000, 6);
    expect(e[2]).toBeCloseTo(1600, 6);
  });

  it('passes through each recorded camera', () => {
    const cams = [cameraLooking([0, 0, 1600], [1000, 0, 1600]), cameraLooking([5000, 0, 1600], [6000, 0, 1600]), cameraLooking([5000, 5000, 1600], [5000, 6000, 1600])];
    const mid = cameraEye(cameraAt(cams, 0.5));
    expect(mid[0]).toBeCloseTo(5000, 6);
    expect(mid[1]).toBeCloseTo(0, 6);
    const q = cameraEye(cameraAt(cams, 0.25));
    expect(q[0]).toBeGreaterThan(0);
    expect(q[0]).toBeLessThan(5000);
  });

  it('walks a plan path at eye height, looking ahead', () => {
    const cams = pathCameras([[0, 0], [9000, 0]], 1600, { step: 1500, ahead: 2000 });
    expect(cams).toHaveLength(7);
    for (const c of cams) {
      expect(cameraEye(c)[2]).toBeCloseTo(1600, 6);
      expect(c.target[0]).toBeGreaterThan(cameraEye(c)[0]);
    }
  });
});
