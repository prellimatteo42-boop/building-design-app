import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { polylineSegments, polylinePoints, polylineLength, arcOfBulge, tangentBulge, endTangent, bulgeThrough, segmentMiddle, explodePolyline, chainToPolyline } from '../src/core/polyline.js';
import { decomposeArea, pieceFormula, areaListRows, layerComponents, listedComponents, listedQuantity, adjustPixels, toCSV } from '../src/core/doccmds.js';
import { orbitOfCamera, cameraFromOrbit, camerasInOrder, nextCamera } from '../src/core/cameras.js';
import { cameraEye } from '../src/core/flythrough.js';
import { sheetText } from '../src/core/masters.js';
import { tagText, layerLines } from '../src/core/plan.js';
import { spellableTexts } from '../src/ui/spelling.js';

const near = (a, b, e = 1e-6) => expect(Math.abs(a - b)).toBeLessThan(e);

describe('polyline', () => {
  it('a half circle by bulge 1 has the chord as diameter', () => {
    const arc = arcOfBulge([0, 0], [2000, 0], 1);
    near(arc.r, 1000);
    near(arc.c[0], 1000);
    near(arc.c[1], 0);
    near(Math.abs(arc.sweep), Math.PI);
  });
  it('a positive bulge sweeps counter-clockwise and passes on the right of the chord', () => {
    const m = segmentMiddle({ a: [0, 0], b: [2000, 0], bulge: 1 });
    near(m[0], 1000);
    near(m[1], -1000);
  });
  it('measures straight and arc segments', () => {
    const el = { path: [[0, 0], [1000, 0], [3000, 0]], bulges: [0, 1, 0] };
    near(polylineLength(el), 1000 + Math.PI * 1000);
    expect(polylinePoints(el).at(-1)).toEqual([3000, 0]);
  });
  it('closes back to the start', () => {
    const el = { path: [[0, 0], [1000, 0], [1000, 1000]], bulges: [], closed: true };
    expect(polylineSegments(el)).toHaveLength(3);
    expect(polylinePoints(el).at(-1)).toEqual([0, 0]);
    near(polylineLength(el), 2000 + Math.SQRT2 * 1000);
  });
  it('a tangent arc leaves along the direction given', () => {
    const b = tangentBulge([1000, 0], [1, 0], [2000, 1000]);
    // Heading east to a point up and to the right: a quarter circle turning left.
    near(b, Math.tan(Math.PI / 8));
    const t = endTangent([1000, 0], [2000, 1000], b);
    near(t[0], 0);
    near(t[1], 1);
  });
  it('a straight continuation has no bulge', () => near(tangentBulge([0, 0], [1, 0], [1000, 0]), 0));
  it('bends a segment through a dragged point and straightens near the chord', () => {
    const b = bulgeThrough([0, 0], [2000, 0], [1000, -500]);
    const m = segmentMiddle({ a: [0, 0], b: [2000, 0], bulge: b });
    near(m[1], -500, 1e-6);
    expect(bulgeThrough([0, 0], [2000, 0], [1000, 5])).toBe(0);
  });
  it('explodes into lines and arcs and joins back', () => {
    const el = { viewId: 'v', path: [[0, 0], [1000, 0], [3000, 0]], bulges: [0, -1, 0], style: 'thin' };
    const parts = explodePolyline(el);
    expect(parts.map((p) => p.kind)).toEqual(['detailLine', 'detailArc']);
    expect(parts[1].a1).toBeGreaterThan(parts[1].a0);
    const chain = chainToPolyline(parts);
    expect(chain.closed).toBe(false);
    expect(chain.path).toHaveLength(3);
    near(polylineLength(chain), polylineLength(el), 1e-6);
  });
  it('joins lines given out of order and backwards, and refuses a gap', () => {
    const L = (a, b) => ({ kind: 'detailLine', a, b });
    const c = chainToPolyline([L([1000, 0], [2000, 0]), L([1000, 0], [0, 0]), L([2000, 0], [2000, 900])]);
    expect(c.path).toHaveLength(4);
    near(polylineLength(c), 2900);
    expect(chainToPolyline([L([0, 0], [1, 0]), L([500, 500], [900, 500])])).toBe(null);
  });
  it('joins a closed square', () => {
    const L = (a, b) => ({ kind: 'detailLine', a, b });
    const c = chainToPolyline([L([0, 0], [10, 0]), L([10, 0], [10, 10]), L([10, 10], [0, 10]), L([0, 10], [0, 0])]);
    expect(c.closed).toBe(true);
    expect(c.path).toHaveLength(4);
  });
});

describe('area list', () => {
  it('a rectangle is one piece', () => {
    const p = decomposeArea([[0, 0], [4210, 0], [4210, 6100], [0, 6100]]);
    expect(p).toHaveLength(1);
    expect(pieceFormula(p[0])).toBe('4.21 x 6.10 = 25.68');
  });
  it('an L is cut into rectangles that add up', () => {
    const L = [[0, 0], [4000, 0], [4000, 2000], [2000, 2000], [2000, 4000], [0, 4000]];
    const p = decomposeArea(L);
    expect(p.every((x) => x.kind === 'rect')).toBe(true);
    expect(p).toHaveLength(2);
    near(p.reduce((t, x) => t + x.area, 0), 12e6);
  });
  it('a hole is left out', () => {
    const p = decomposeArea([[0, 0], [4000, 0], [4000, 4000], [0, 4000]], [[[1000, 1000], [1000, 2000], [2000, 2000], [2000, 1000]]]);
    near(p.reduce((t, x) => t + x.area, 0), 15e6);
  });
  it('a sloping side goes to triangles that add up', () => {
    const p = decomposeArea([[0, 0], [4000, 0], [3000, 3000], [0, 3000]]);
    expect(p.every((x) => x.kind === 'tri')).toBe(true);
    near(p.reduce((t, x) => t + x.area, 0), 10.5e6, 1);
    expect(pieceFormula({ kind: 'tri', w: 3000, h: 2000, area: 3e6 })).toBe('1/2 x 3.00 x 2.00 = 3.00');
  });
  it('lists the zones of a project', () => {
    const { doc, box, add, L1 } = project();
    box(0, 0, 5000, 4000);
    add({ kind: 'room', levelId: L1.id, at: [2500, 2000], name: 'Living', number: '1', upperOffset: 2700 });
    const rows = areaListRows(doc, new Scene(doc).rooms);
    expect(rows).toHaveLength(1);
    expect(rows[0].name).toBe('Living');
    near(rows[0].pieces.reduce((t, x) => t + x.area, 0), rows[0].area, 1);
  });
});

describe('component list', () => {
  it('adds up layers by material', () => {
    const { doc, wall } = project();
    wall([0, 0], [5000, 0], { height: 3000 });
    wall([0, 3000], [5000, 3000], { height: 3000 });
    const rows = layerComponents(doc);
    expect(rows.length).toBeGreaterThan(0);
    expect(rows[0].count).toBe(2);
    near(rows[0].volume, rows[0].area * rows[0].thickness, 1);
  });
  it('multiplies listed components by what they are per', () => {
    const m = { length: 2000, area: 3e6, volume: 6e8 };
    expect(listedQuantity({ qty: 2, per: 'piece' }, m)).toBe(2);
    expect(listedQuantity({ qty: 2, per: 'length' }, m)).toBe(4);
    expect(listedQuantity({ qty: 2, per: 'area' }, m)).toBe(6);
    near(listedQuantity({ qty: 2, per: 'volume' }, m), 1.2);
  });
  it('adds up listed components across elements', () => {
    const { doc, wall } = project();
    const w = wall([0, 0], [4000, 0]);
    doc.transact('t', () => doc.update(w.typeId, { listing: [{ code: 'A1', name: 'Plaster', qty: 2, unit: 'kg', per: 'length' }] }));
    wall([0, 3000], [4000, 3000]);
    const r = listedComponents(doc);
    expect(r).toHaveLength(1);
    expect(r[0].count).toBe(2);
    near(r[0].quantity, 16);
  });
  it('quotes CSV cells', () => expect(toCSV([['a,b', 'c"d'], [1, 2]])).toBe('"a,b","c""d"\n1,2'));
});

describe('cameras', () => {
  it('stands where the plan says, above its level', () => {
    const { doc, add, L2 } = project();
    const c = add({ kind: 'camera', levelId: L2.id, at: [1000, 2000], eyeHeight: 1600, target: [5000, 2000], targetHeight: 1000, fov: 50 });
    const o = orbitOfCamera(doc, c);
    const eye = cameraEye(o);
    near(eye[0], 1000, 1e-6);
    near(eye[1], 2000, 1e-6);
    near(eye[2], L2.elevation + 1600, 1e-6);
    near(o.target[2], L2.elevation + 1000, 1e-6);
    expect(o.fov).toBe(50);
  });
  it('comes back from the orbit camera', () => {
    const { doc, L1 } = project();
    const el = { levelId: L1.id, at: [100, 200], eyeHeight: 1500, target: [900, 700], targetHeight: 1200, fov: 70 };
    const back = cameraFromOrbit(doc, orbitOfCamera(doc, el), L1.id);
    near(back.at[0], 100, 1e-6);
    near(back.eyeHeight, 1500, 1e-6);
    near(back.target[1], 700, 1e-6);
    near(back.targetHeight, 1200, 1e-6);
  });
  it('are kept in order and named in turn', () => {
    const { doc, add, L1 } = project();
    expect(nextCamera(doc)).toEqual({ name: 'Camera 1', order: 1 });
    add({ kind: 'camera', levelId: L1.id, at: [0, 0], target: [1, 0], order: 5, name: 'B' });
    add({ kind: 'camera', levelId: L1.id, at: [0, 0], target: [1, 0], order: 2, name: 'A' });
    expect(camerasInOrder(doc).map((c) => c.name)).toEqual(['A', 'B']);
    expect(nextCamera(doc).order).toBe(6);
  });
});

describe('document commands', () => {
  it('leaves pinned elements out of the editable spelling check', () => {
    const { doc, add } = project();
    const v = doc.all('plan')[0];
    add({ kind: 'text', viewId: v.id, at: [0, 0], text: 'Kitchen note' });
    add({ kind: 'text', viewId: v.id, at: [0, 0], text: 'Pinned note', pinned: true });
    const texts = (o) => spellableTexts(doc, o).filter((t) => /note/.test(t.text)).map((t) => t.text);
    expect(texts({})).toHaveLength(2);
    expect(texts({ editable: true, view: v })).toEqual(['Kitchen note']);
  });
  it('labels every layer of a wall', () => {
    const { doc, wall } = project();
    const w = wall([0, 0], [4000, 0]);
    const layers = doc.get(w.typeId).layers;
    expect(layerLines(doc, w)).toHaveLength(layers.length);
    expect(tagText(doc, w, 'layers').split('\n')[0]).toContain(String(Math.round(layers[0].thickness)));
  });
  it('fills drawing autotext', () => {
    const { doc } = project();
    expect(sheetText(doc, { name: 'A' }, '{Drawing Name}/{Drawing Scale}', { 'drawing name': 'Plan', 'drawing scale': '1:50' })).toBe('Plan/1:50');
  });
  it('adjusts pixels', () => {
    const a = new Uint8ClampedArray([100, 100, 100, 255]);
    adjustPixels(a, { exposure: 1 });
    expect(a[0]).toBe(200);
    const g = new Uint8ClampedArray([200, 100, 0, 255]);
    adjustPixels(g, { saturation: -1 });
    expect(g[0]).toBe(g[1]);
    const n = new Uint8ClampedArray([1, 2, 3, 4]);
    adjustPixels(n, {});
    expect([...n]).toEqual([1, 2, 3, 4]);
  });
});
