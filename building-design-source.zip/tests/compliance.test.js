import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { roomUse, checkCompliance } from '../src/core/compliance.js';

describe('checking a dwelling against the Italian requirements', () => {
  it('reads room uses from names in several languages', () => {
    expect(roomUse('Camera matrimoniale')).toBe('bedroomDouble');
    expect(roomUse('Спальня 2')).toBe('bedroom');
    expect(roomUse('Soggiorno')).toBe('living');
    expect(roomUse('Кухня + вітальня')).toBe('living');
    expect(roomUse('Bagno')).toBe('bath');
    expect(roomUse('Гостевой С/У')).toBe('bath');
    expect(roomUse('Disimpegno')).toBe('service');
    expect(roomUse('Cucina')).toBe('kitchen');
  });

  it('finds a small bedroom, too little window, a bathroom without one and a narrow door', () => {
    const { doc, L1, box } = project();
    // A 2.8 x 3 m bedroom (8.4 m²) beside a 2 x 3 m bathroom.
    const w = box(0, 0, 3000, 3200);
    box(3000, 0, 5200, 3200);
    const wt = doc.all('windowType')[0];
    const dt = doc.all('doorType')[0];
    doc.transact('openings', () => {
      doc.add({ kind: 'window', typeId: wt.id, hostId: w[0].id, t: 1500, width: 600, height: 800, sill: 900 });
      doc.add({ kind: 'door', typeId: dt.id, hostId: w[1].id, t: 1600, width: 700, height: 2100 });
      doc.add({ kind: 'room', levelId: L1.id, at: [1500, 1600], name: 'Camera', number: '1', upperOffset: 2700 });
      doc.add({ kind: 'room', levelId: L1.id, at: [4100, 1600], name: 'Bagno', number: '2', upperOffset: 2700 });
    });
    const f = checkCompliance(doc, new Scene(doc));
    const rules = f.map((x) => `${x.rule}:${x.severity}`).sort();
    expect(rules).toContain('bedroom:error');
    expect(rules).toContain('daylight:error');
    expect(rules).toContain('ventilation:warning');
    expect(rules).toContain('door:warning');
    expect(f.find((x) => x.rule === 'bedroom').message).toMatch(/at least 9 m²/);
  });
});
