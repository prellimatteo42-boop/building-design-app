import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { resolveAutotext, autotextFields } from '../src/core/autotext.js';
import { Scene } from '../src/core/scene.js';
import { planGraphics, planContext } from '../src/core/plan.js';
import { instanceParams } from '../src/core/props.js';

describe('autotext labels', () => {
  it('fill a template with the values of the labelled element, in project units', () => {
    const { doc, add, box, L1 } = project();
    box(0, 0, 5000, 4000);
    const room = add({ kind: 'room', levelId: L1.id, at: [2500, 2000], name: 'Kitchen', number: '3' });
    const scene = new Scene(doc);
    const text = resolveAutotext({ doc, scene }, doc.get(room.id), '{Number} {Name}\n{Area}\n{level} / {Project Name} / {Nope}');
    const [first, area, last] = text.split('\n');
    expect(first).toBe('3 Kitchen');
    expect(area).toMatch(/m²/);
    expect(parseFloat(area)).toBeGreaterThan(15);
    expect(last).toBe(`${L1.name} / ${doc.project.name} / ?`);
  });

  it('offers the schedule fields of the element and the project fields', () => {
    const labels = autotextFields({ kind: 'door' }).map((f) => f.label);
    expect(labels).toEqual(expect.arrayContaining(['Mark', 'Width', 'Height', 'Level', 'Project Name']));
    expect(labels).not.toContain('Count');
  });

  it('draw as lines of text on a label set to Autotext', () => {
    const { doc, add, wall, L1 } = project();
    const w = wall([0, 0], [4000, 0]);
    const view = doc.all('plan').find((v) => v.levelId === L1.id);
    const tag = add({ kind: 'tag', viewId: view.id, targetId: w.id, at: [2000, 800], show: 'autotext', template: '{Type}\n{Length}', frame: true, leader: true });
    const scene = new Scene(doc);
    const g = planGraphics(planContext(doc, view, scene.walls, scene.rooms, scene.areas), doc.get(tag.id));
    expect(g.texts.map((t) => t.text)).toEqual([doc.get('wt-generic').name, '4000']);
    expect(g.texts[0].at[1]).toBeGreaterThan(g.texts[1].at[1]);
    expect(g.lines.length).toBeGreaterThan(4);
    expect(instanceParams(doc.get(tag.id)).map((p) => p.key)).toEqual(expect.arrayContaining(['template', 'frame']));
  });
});
