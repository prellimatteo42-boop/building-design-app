import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene, MODEL_KINDS } from '../src/core/scene.js';
import { cameraBasis, projectPoint, document3dLines, rebuildDocument3d, isDocument3d } from '../src/core/doc3d.js';

describe('3D documents', () => {
  it('projects along the camera: target at the origin, up stays up', () => {
    const cam = { target: [1000, 1000, 0], yaw: -Math.PI / 4, pitch: Math.PI / 6 };
    const { up, right } = cameraBasis(cam);
    expect(up[2]).toBeGreaterThan(0.8);
    expect(right[2]).toBe(0);
    expect(projectPoint(cam, [1000, 1000, 0])).toEqual([0, 0]);
    // Higher points sit higher in the drawing.
    expect(projectPoint(cam, [1000, 1000, 3000])[1]).toBeGreaterThan(2000);
  });

  it('draws a wall box in axonometry without the hidden edges, and rebuild keeps annotations', () => {
    const p = project();
    const { doc } = p;
    p.box(0, 0, 6000, 4000, { topLevelId: null, height: 3000 });
    const scene = new Scene(doc);
    const meshOf = (el) => scene.mesh(el);
    const cam = { target: [3000, 2000, 1500], yaw: -Math.PI / 4 - Math.PI / 2, pitch: Math.PI / 6 };
    const lines = document3dLines(doc, { camera: cam }, meshOf, MODEL_KINDS, { res: 20 });
    expect(lines.length).toBeGreaterThan(8);
    // The bottom corner farthest from the eye is hidden behind the walls: no line ends there.
    const { back } = cameraBasis(cam);
    const corners = [[0, 0], [6000, 0], [6000, 4000], [0, 4000]];
    const far = corners.reduce((best, c) => (c[0] * back[0] + c[1] * back[1] < best[0] * back[0] + best[1] * back[1] ? c : best));
    const q = projectPoint(cam, [far[0], far[1], 0]);
    const ends = lines.flatMap((l) => [l.a, l.b]);
    expect(ends.some((e) => Math.hypot(e[0] - q[0], e[1] - q[1]) < 60)).toBe(false);
    // The top corner nearest the eye shows.
    const nearC = corners.reduce((best, c) => (c[0] * back[0] + c[1] * back[1] > best[0] * back[0] + best[1] * back[1] ? c : best));
    const qn = projectPoint(cam, [nearC[0], nearC[1], 3000]);
    expect(ends.some((e) => Math.hypot(e[0] - qn[0], e[1] - qn[1]) < 80)).toBe(true);

    const view = doc.transact('v', () => doc.add({ kind: 'drafting', name: '3D Doc', scale: 100, doc3d: { camera: cam } }));
    expect(isDocument3d(view)).toBe(true);
    const n = doc.transact('r', () => rebuildDocument3d(doc, view, meshOf, MODEL_KINDS));
    const note = doc.transact('t', () => doc.add({ kind: 'text', viewId: view.id, at: [0, 0], text: 'Note' }));
    const n2 = doc.transact('r2', () => rebuildDocument3d(doc, view, meshOf, MODEL_KINDS));
    expect(n2).toBe(n);
    expect(doc.all('detailLine').filter((l) => l.viewId === view.id)).toHaveLength(n);
    expect(doc.has(note.id)).toBe(true);
  });
});
