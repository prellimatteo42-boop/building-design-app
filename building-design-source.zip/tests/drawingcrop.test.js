import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { planContext } from '../src/core/plan.js';
import { planViewportGraphics, clipSegment, clipToRect } from '../src/core/sheet.js';

describe('drawings cropped to their frame', () => {
  it('clips segments and polygons to a rectangle', () => {
    const r = { x0: 0, y0: 0, x1: 10, y1: 10 };
    expect(clipSegment([-5, 5], [15, 5], r)).toEqual([[0, 5], [10, 5]]);
    expect(clipSegment([-5, -5], [-1, -1], r)).toBeNull();
    const sq = clipToRect([[5, 5], [20, 5], [20, 20], [5, 20]], r);
    expect(sq.map((p) => p.join(',')).sort()).toEqual(['10,10', '10,5', '5,10', '5,5']);
  });

  it('a cropped plan drawing keeps only what is inside its frame', () => {
    const p = project();
    p.box(0, 0, 20000, 10000);
    const plan = p.doc.all('plan').find((v) => v.levelId === p.L1.id);
    const scene = new Scene(p.doc);
    const pc = planContext(p.doc, plan, scene.walls, scene.rooms);
    const vp = { id: 'vp1', viewId: 'sheet', placedId: plan.id, at: [200, 150] };
    const full = planViewportGraphics(scene, plan, vp, pc);
    // At 1:100 the box is 200 x 100 mm on paper; a 100 x 120 mm frame cuts the long walls.
    const cut = planViewportGraphics(scene, plan, { ...vp, cropped: true, frame: [100, 120] }, pc);
    expect(full.rect.x1 - full.rect.x0).toBeGreaterThan(190);
    expect(cut.rect.x1 - cut.rect.x0).toBeCloseTo(100, 6);
    const pts = cut.items.flatMap((it) => it.builder.lines.flatMap((l) => [l.a, l.b]));
    expect(pts.length).toBeGreaterThan(0);
    expect(pts.every((q) => q[0] >= 150 - 1e-6 && q[0] <= 250 + 1e-6 && q[1] >= 90 - 1e-6 && q[1] <= 210 + 1e-6)).toBe(true);
  });
});
