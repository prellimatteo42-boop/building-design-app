import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { makeZip, readZip } from '../src/io/zip.js';
import { writeBCF, readBCF } from '../src/io/bcf.js';
import { ifcGuidFor, cameraToBCF, cameraFromBCF } from '../src/core/issues.js';
import { writeIFC } from '../src/io/ifc.js';
import { Scene } from '../src/core/scene.js';

describe('zip', () => {
  it('writes files that read back, and reads deflated ones', async () => {
    const z = makeZip([{ name: 'a.txt', data: 'hello' }, { name: 'dir/b.bin', data: new Uint8Array([1, 2, 3]) }]);
    const files = await readZip(z);
    expect(new TextDecoder().decode(files.get('a.txt'))).toBe('hello');
    expect([...files.get('dir/b.bin')]).toEqual([1, 2, 3]);
    // A deflated entry, as other tools write them.
    const raw = new Uint8Array(await new Response(new Blob([new TextEncoder().encode('deflated text '.repeat(20))]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer());
    const z2 = makeZip([{ name: 'c.txt', data: raw }]);
    const dv = new DataView(z2.buffer);
    dv.setUint16(8, 8, true);
    const cd = z2.length - 22 - 46 - 5;
    dv.setUint16(cd + 10, 8, true);
    dv.setUint32(cd + 24, 'deflated text '.length * 20, true);
    expect(new TextDecoder().decode((await readZip(z2)).get('c.txt'))).toBe('deflated text '.repeat(20));
  });
});

describe('BCF', () => {
  it('turns cameras into BCF and back', () => {
    const cam = { target: [1000, 2000, 500], dist: 12000, yaw: 0.7, pitch: 0.4, persp: true, fov: 50 };
    const back = cameraFromBCF(cameraToBCF(cam), 12000);
    for (let i = 0; i < 3; i++) expect(back.target[i]).toBeCloseTo(cam.target[i], 6);
    expect(back.yaw).toBeCloseTo(0.7, 9);
    expect(back.pitch).toBeCloseTo(0.4, 9);
    const c = cameraToBCF(cam);
    expect(c.dir[0] * c.up[0] + c.dir[1] * c.up[1] + c.dir[2] * c.up[2]).toBeCloseTo(0, 9);
  });

  it('names elements by the same GlobalId as the IFC export', () => {
    const { doc, wall } = project();
    const w = wall([0, 0], [3000, 0]);
    expect(ifcGuidFor(w.id)).toMatch(/^[0-3][0-9A-Za-z_$]{21}$/);
    expect(ifcGuidFor(w.id)).toBe(ifcGuidFor(w.id));
    expect(ifcGuidFor(w.id)).not.toBe(ifcGuidFor(`${w.id}x`));
    expect(writeIFC({ doc, scene: new Scene(doc) })).toContain(`IFCWALL('${ifcGuidFor(w.id)}'`);
  });

  it('exports issues with comments, viewpoint and snapshot, and imports them back', async () => {
    const { doc, wall } = project();
    const w = wall([0, 0], [3000, 0]);
    const png = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
    const issue = {
      guid: '11111111-2222-4333-8444-555555555555',
      title: 'Wall too thin <check>',
      type: 'Clash',
      status: 'In Progress',
      priority: 'High',
      assignedTo: 'engineer@example.com',
      author: 'MP',
      created: '2026-11-04T10:00:00Z',
      description: 'Fire rating & acoustics',
      comments: [{ guid: 'c1', author: 'MP', date: '2026-11-04T10:05:00Z', text: 'Use 200 mm' }, { guid: 'c2', author: 'AB', date: '2026-11-04T11:00:00Z', text: 'Agreed' }],
      viewpoint: { viewId: null, camera: { target: [0, 0, 0], dist: 20000, yaw: -0.8, pitch: 0.5, persp: true, fov: 45 }, selection: [w.id] },
      snapshot: png,
    };
    const bytes = writeBCF(doc, [issue]);
    const files = await readZip(bytes);
    expect([...files.keys()]).toEqual(expect.arrayContaining(['bcf.version', `${issue.guid}/markup.bcf`, `${issue.guid}/viewpoint.bcfv`, `${issue.guid}/snapshot.png`]));
    const [back] = await readBCF(doc, bytes);
    expect(back).toMatchObject({ guid: issue.guid, title: issue.title, type: 'Clash', status: 'In Progress', priority: 'High', assignedTo: issue.assignedTo, description: issue.description, author: 'MP' });
    expect(back.comments.map((c) => c.text)).toEqual(['Use 200 mm', 'Agreed']);
    expect(back.viewpoint.selection).toEqual([w.id]);
    expect(back.viewpoint.camera.yaw).toBeCloseTo(-0.8, 6);
    expect(back.snapshot).toBe(png);
  });
});
