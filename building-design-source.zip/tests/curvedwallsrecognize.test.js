import { describe, it, expect } from 'vitest';
import { flattenCAD } from '../src/core/cadflatten.js';
import { recognizeCAD, buildRecognized, curvedWallsFromArcs, layerRole } from '../src/core/recognize.js';
import { project } from './helpers.js';

const A = (layer, c, r, a0, a1) => ({ type: 'ARC', layer, center: { x: c[0], y: c[1] }, radius: r, startAngle: a0, endAngle: a1 });
const L = (layer, a, b) => ({ type: 'LINE', layer, startPoint: { x: a[0], y: a[1] }, endPoint: { x: b[0], y: b[1] } });

describe('curved walls from drawn arcs', () => {
  it('pairs concentric face arcs into a wall on the arc between them', () => {
    const [w] = curvedWallsFromArcs([{ c: [0, 0], r: 5000, a0: 0, a1: Math.PI / 2 }, { c: [5, 0], r: 5300, a0: 0.1, a1: Math.PI / 2 }]);
    expect(w.thickness).toBeCloseTo(300, 0);
    expect(w.r).toBeCloseTo(5150, 0);
    expect(w.sweep).toBeCloseTo(Math.PI / 2 - 0.1, 3);
  });

  it('makes a curved wall in the model, joined to the straight ones', () => {
    // A quarter circle of radius 5000-5300 from (5000..5300, 0) to (0, 5000..5300), with straight walls running on.
    const flat = flattenCAD({
      entities: [
        A('Walls', [0, 0], 5000, 0, Math.PI / 2), A('Walls', [0, 0], 5300, 0, Math.PI / 2),
        L('Walls', [5000, 0], [5000, -4000]), L('Walls', [5300, 0], [5300, -4000]),
        L('Walls', [0, 5000], [-4000, 5000]), L('Walls', [0, 5300], [-4000, 5300]),
      ],
    });
    const roles = new Map([['Walls', layerRole('Walls')]]);
    const rec = recognizeCAD(flat, roles);
    expect(rec.counts.curvedWalls).toBe(1);
    const p = project();
    let out;
    p.doc.transact('import', () => (out = buildRecognized(p.doc, rec, { levelId: p.L1.id })));
    const curved = out.walls.map((id) => p.doc.get(id)).filter((w) => w.arc);
    expect(curved.length).toBe(1);
    expect(curved[0].arc).toBeCloseTo(Math.PI / 2, 2);
    expect(Math.hypot(...curved[0].a)).toBeCloseTo(5150, -1);
    expect(out.walls.length).toBe(3);
  });
});
