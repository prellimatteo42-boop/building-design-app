import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { explodeGraphics, addExploded, styleOfLine } from '../src/core/explode.js';
import { PlanBuilder, planGraphics, planContext, W, INK, BG, PATTERN } from '../src/core/plan.js';
import { Scene } from '../src/core/scene.js';

describe('explode', () => {
  it('turns plan graphics into lines, fills and text, skipping masks and repeats', () => {
    const b = new PlanBuilder();
    b.line([0, 0], [1000, 0], W.cut);
    b.line([1000, 0], [0, 0], W.thin);
    b.line([0, 0], [0, 1000], W.thin, 1);
    b.fill([[0, 0], [100, 0], [100, 100]], [], INK(14), PATTERN.brick);
    b.fill([[0, 0], [100, 0], [100, 100]], [], BG, 0);
    b.fill([[0, 0], [100, 0], [100, 100]], [], INK(115), 0);
    b.fill([[0, 0], [100, 0], [100, 100]], [], [110, 160, 90, 60], 0);
    b.text([500, 500], 'Living', { size: 250, rot: Math.PI / 2 });
    const out = explodeGraphics([b], 100);
    expect(out.lines.map((l) => l.style)).toEqual(['wide', 'dashed']);
    expect(out.fills.map((f) => f.pattern)).toEqual(['brick', 'none']);
    expect(out.texts[0]).toMatchObject({ text: 'Living', size: 2.5, rotation: 90 });
    expect(styleOfLine({ w: W.medium, d: 0 })).toBe('medium');
  });

  it('draws a wall as editable drafting in a view', () => {
    const { doc, wall } = project();
    const w = wall([0, 0], [4000, 0]);
    const view = doc.all('plan')[0];
    const scene = new Scene(doc);
    const g = planGraphics(planContext(doc, view, scene.walls, scene.rooms), doc.get(w.id));
    const parts = explodeGraphics([g], 100);
    let ids;
    doc.transact('x', () => (ids = addExploded(doc, view.id, parts)));
    const lines = ids.map((id) => doc.get(id)).filter((e) => e.kind === 'detailLine');
    expect(lines.length).toBeGreaterThanOrEqual(4);
    const xs = lines.flatMap((l) => [l.a[0], l.b[0]]);
    expect(Math.max(...xs) - Math.min(...xs)).toBeGreaterThanOrEqual(4000);
    expect(lines.every((l) => l.viewId === view.id)).toBe(true);
  });
});
