import { describe, it, expect } from 'vitest';
import { guessUnitMm } from '../src/core/cadflatten.js';

const arc = (x, r) => ({ type: 'ARC', layer: '0', center: { x, y: 0, z: 0 }, radius: r, startAngle: 0, endAngle: Math.PI / 2 });
const line = (x0, y0, x1, y1) => ({ type: 'LINE', layer: '0', startPoint: { x: x0, y: y0, z: 0 }, endPoint: { x: x1, y: y1, z: 0 } });

describe('the unit a drawing is really in', () => {
  it('keeps millimetres when the door swings measure as doors', () => {
    expect(guessUnitMm({ units: 4, entities: [arc(0, 800), arc(2000, 900), arc(4000, 800), arc(6000, 700)] })).toBe(1);
  });
  it('reads metres when the doors only make sense in metres', () => {
    expect(guessUnitMm({ units: 4, entities: [arc(0, 0.8), arc(2, 0.9), arc(4, 0.8), arc(6, 0.7)] })).toBe(1000);
  });
  it('reads a drawing a few tens of units across, saved as millimetres, in metres', () => {
    const lines = [];
    for (let i = 0; i < 30; i++) lines.push(line(i, 0, i, 25));
    expect(guessUnitMm({ units: 4, entities: lines })).toBe(1000);
  });
  it('keeps a real millimetre plan as it is', () => {
    const lines = [];
    for (let i = 0; i < 30; i++) lines.push(line(i * 500, 0, i * 500, 12000));
    expect(guessUnitMm({ units: 4, entities: lines })).toBe(1);
  });
});

import { flattenCAD } from '../src/core/cadflatten.js';

describe('multiline texts', () => {
  it('keep the middle of the text as it reads, whatever corner it is anchored at', () => {
    const f = flattenCAD({ entities: [{ type: 'MTEXT', layer: '0', insertionPoint: { x: 10, y: 20 }, text: 'dis.\\P2.80 mq', textHeight: 0.2, attachmentPoint: 1 }] });
    const t = f.texts[0];
    expect(t.text).toBe('dis.\n2.80 mq');
    // Top left anchor: the middle lies right of and below it.
    expect(t.mid[0]).toBeGreaterThan(10);
    expect(t.mid[1]).toBeLessThan(20);
  });
});

import { formatDimension, formatLength } from '../src/core/units.js';

describe('drawings written the Italian way', () => {
  it('use a decimal comma when the project asks for it', () => {
    const units = { system: 'metric', metric: 'm', decimals: 2, decimalComma: true, dim: { linear: { unit: 'm', decimals: 2 } } };
    expect(formatDimension(4794, units)).toBe('4,79');
    expect(formatDimension(4794, { ...units, decimalComma: false })).toBe('4.79');
    expect(formatLength(300, { system: 'metric', metric: 'mm', decimals: 0, decimalComma: true })).toBe('300');
  });
});
