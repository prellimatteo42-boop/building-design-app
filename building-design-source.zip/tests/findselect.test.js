import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { findElements, elementMaterials, CRITERIA } from '../src/core/findselect.js';

describe('find & select', () => {
  it('matches every criterion', () => {
    const p = project();
    const a = p.wall([0, 0], [4000, 0], { typeId: 'wt-ext-concrete' });
    p.wall([0, 3000], [4000, 3000], { typeId: 'wt-int-partition' });
    p.add({ kind: 'room', levelId: p.L1.id, at: [1000, 1000], name: 'Kitchen' });
    expect(findElements(p.doc, [{ id: 'kind', value: 'wall' }]).length).toBe(2);
    expect(findElements(p.doc, [{ id: 'material', value: 'mat-concrete' }]).map((e) => e.id)).toEqual([a.id]);
    expect(findElements(p.doc, [{ id: 'kind', value: 'wall' }, { id: 'layer', value: 'ly-walls' }, { id: 'story', value: p.L1.id }]).length).toBe(2);
    expect(findElements(p.doc, [{ id: 'zoneCategory', value: 'zc-kitchen' }]).length).toBe(1);
    // No criteria: everything searchable, but no views, types or settings.
    expect(findElements(p.doc, []).some((e) => e.kind === 'plan' || e.kind === 'wallType' || e.kind === 'layer')).toBe(false);
    expect(elementMaterials(p.doc, p.doc.get(a.id)).has('mat-gypsum')).toBe(true);
    expect(CRITERIA.map((c) => c.label)).toContain('Building Material');
  });
});
