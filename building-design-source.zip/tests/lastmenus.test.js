import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { writeLibraryPart, readLibraryPart, ancestryOf, writeContainer, writeLibraryPackage, readContainer, libraryParts, packageInfo } from '../src/io/gsm.js';
import { stretchPatches, findHatches, convexHull } from '../src/core/editmore.js';
import { bookSettings, layoutId, nextLayoutId, renumberPatches } from '../src/core/bookset.js';
import { ChangeLog } from '../src/core/changelog.js';
import { compareDocs, changeDetails } from '../src/core/compare.js';
import { Doc } from '../src/core/doc.js';
import { resolveConnections } from '../src/core/mepnet.js';
import { phaseFilters, phaseLook, resetPhasePatch } from '../src/core/phases.js';
import { attributeRows, attributeUses, exportAttributes, importAttributes, defaultPens, penTable, classWeights, classColors, applyMepSystems, applyOperationProfiles } from '../src/core/attrs.js';
import { SYSTEMS } from '../src/core/mep.js';
import { PROFILES } from '../src/core/energyhourly.js';

describe('writing library files', () => {
  it('writes a part that reads back', () => {
    const b = writeLibraryPart({ name: 'Test', master: 'A = 1\nEND\n' });
    const lp = readLibraryPart(b);
    expect(lp.scripts.master).toContain('A = 1');
    expect(Object.keys(lp.sections).sort()).toEqual(['1DSC', 'ANCS', 'MCRS', 'PARD']);
    expect(lp.params).toEqual([]);
  });
  it('keeps its identity when saved again', () => {
    const a = writeLibraryPart({ name: 'Test', master: 'x' });
    const b = writeLibraryPart({ name: 'Test', master: 'y' });
    const c = writeLibraryPart({ name: 'Other', master: 'x' });
    expect([...a.subarray(0x48, 0x58)]).toEqual([...b.subarray(0x48, 0x58)]);
    expect([...a.subarray(0x48, 0x58)]).not.toEqual([...c.subarray(0x48, 0x58)]);
  });
  it('carries the ancestry it is given', () => {
    const src = writeLibraryPart({ name: 'S', master: 'x' });
    const anc = ancestryOf(src);
    expect(String.fromCharCode(...anc.subarray(0, 4))).toBe('SCNA');
    expect([...ancestryOf(writeLibraryPart({ name: 'T', master: 'y', ancestry: anc }))]).toEqual([...anc]);
  });
  it('writes a container that reads back, with folders', () => {
    const data = new Uint8Array([1, 2, 3, 4, 5]);
    const b = writeContainer([{ path: 'Sub/a.gsm', data }, { path: 'b.txt', data: new Uint8Array([9]) }], 'Lib');
    expect(String.fromCharCode(...b.subarray(0, 4))).toBe('GLCF');
    const r = Object.fromEntries(readContainer(b).map((f) => [f.path, [...f.bytes]]));
    expect(r['Lib/Sub/a.gsm']).toEqual([1, 2, 3, 4, 5]);
    expect(r['Lib/b.txt']).toEqual([9]);
  });
  it('writes a package with its inner container and info', () => {
    const part = writeLibraryPart({ name: 'P', master: 'x' });
    const b = writeLibraryPackage([{ path: 'P.gsm', data: part }], { name: 'Pack', id: 'ID-1' });
    expect(libraryParts(b).map((f) => f.path)).toEqual(['Pack/P.gsm']);
    expect(readContainer(b).map((f) => f.path).sort()).toEqual(['Pack/Pack.lcf', 'Pack/package.info']);
    expect(packageInfo({ name: 'a&b', id: 'X', lcf: 'a.lcf' })).toContain('displayName="a&amp;b"');
  });
});

describe('stretch and hatches', () => {
  const box = { x0: -10, y0: -10, x1: 10, y1: 10 };
  it('moves only the points in the box', () => {
    const { doc, add, wall } = project();
    const w = wall([0, 0], [4000, 0]);
    const r = add({ kind: 'region', viewId: 'v', boundary: [[0, 0], [100, 0], [100, 100]], holes: [] });
    const out = Object.fromEntries(stretchPatches(doc, [w.id, r.id], box, [0, 500]).map((p) => [p.id, p.patch]));
    expect(out[w.id]).toEqual({ a: [0, 500] });
    expect(out[r.id].boundary).toEqual([[0, 500], [100, 0], [100, 100]]);
  });
  it('leaves elements with nothing in the box', () => {
    const { doc, wall } = project();
    expect(stretchPatches(doc, [wall([1000, 0], [4000, 0]).id], box, [1, 1])).toEqual([]);
  });
  const hatch = (n, gap, y0 = 0) => Array.from({ length: n }, (_, i) => ({ id: `l${y0}-${i}`, a: [0, y0 + i * gap], b: [500, y0 + i * gap], style: 'thin' }));
  it('finds parallel evenly spaced lines', () => {
    const r = findHatches(hatch(8, 50));
    expect(r).toHaveLength(1);
    expect(r[0].ids).toHaveLength(8);
    expect(r[0].spacing).toBeCloseTo(50);
    expect(r[0].outline).toHaveLength(4);
  });
  it('ignores too few lines and uneven spacing', () => {
    expect(findHatches(hatch(3, 50))).toEqual([]);
    expect(findHatches([0, 40, 300, 310, 900, 1500, 3000].map((y, i) => ({ id: `${i}`, a: [0, y], b: [500, y] })))).toEqual([]);
  });
  it('takes the whole hatch when another line stands near it', () => {
    const lines = [{ id: 'near', a: [0, -50], b: [500, -50] }, ...hatch(8, 100)];
    expect(findHatches(lines)[0].ids).toHaveLength(8);
  });
  it('makes a hull', () => expect(convexHull([[0, 0], [2, 0], [1, 1], [2, 2], [0, 2]])).toHaveLength(4));
});

describe('layout book', () => {
  it('builds IDs', () => {
    expect(layoutId({ prefix: 'B', start: 7, digits: 3 }, 2)).toBe('B009');
    expect(bookSettings({}).prefix).toBe('A');
  });
  it('finds the next free ID', () => {
    const { doc, add } = project();
    add({ kind: 'sheet', number: 'A101', name: 'x', size: 'A1' });
    expect(nextLayoutId(doc)).toBe('A102');
  });
  it('numbers subsets with their own prefix on their own run', () => {
    const s = { prefix: 'A', start: 1, digits: 2, subsets: [{ name: 'S', prefix: 'S' }] };
    expect(renumberPatches([{ id: 1 }, { id: 2, subset: 'S' }, { id: 3 }], s).map((p) => p.number)).toEqual(['A01', 'S01', 'A02']);
  });
});

describe('changes', () => {
  it('tracks what is added, changed and deleted', () => {
    const { doc, wall } = project();
    const log = new ChangeLog(doc);
    doc.on((ev) => log.record(doc, ev));
    const w = wall([0, 0], [1000, 0]);
    doc.transact('m', () => doc.update(w.id, { a: [1, 1] }));
    doc.transact('d', () => doc.remove(w.id));
    const mine = log.list([w.id]).map((e) => e.action);
    expect(mine).toEqual(['deleted', 'modified', 'added']);
    expect(log.list(['nope'])).toEqual([]);
  });
  it('lists changed parameters', () => {
    const { doc, wall } = project();
    const w = wall([0, 0], [1000, 0]);
    const base = Doc.fromJSON(JSON.parse(JSON.stringify(doc.toJSON())));
    doc.transact('m', () => doc.update(w.id, { height: 2222 }));
    const r = changeDetails(compareDocs(base, doc), base, doc);
    expect(r.find((x) => x.field === 'height')).toMatchObject({ id: w.id, to: '2222' });
  });
});

describe('MEP connections', () => {
  it('brings near ends together, and leaves far ones', () => {
    const { doc, add, L1 } = project();
    const type = doc.all('ductType')[0].id;
    const a = add({ kind: 'duct', typeId: type, levelId: L1.id, a: [0, 0], b: [1000, 0], offset: 2500, width: 300, height: 200 });
    const b = add({ kind: 'duct', typeId: type, levelId: L1.id, a: [1100, 0], b: [2000, 0], offset: 2500, width: 300, height: 200 });
    add({ kind: 'duct', typeId: type, levelId: L1.id, a: [9000, 0], b: [9500, 0], offset: 2500, width: 300, height: 200 });
    const fix = Object.fromEntries(resolveConnections(doc).map((x) => [x.id, x.patch]));
    expect(fix[a.id].b).toEqual([1050, 0]);
    expect(fix[b.id].a).toEqual([1050, 0]);
    expect(Object.keys(fix)).toHaveLength(2);
  });
});

describe('renovation', () => {
  it('lists own filters and uses them', () => {
    const { doc } = project();
    doc.transact('p', () => doc.update('project', { phaseFiltersCustom: [{ value: 'x', label: 'Mine', existing: 'hidden', demolished: 'hidden', new: 'dashed' }] }));
    expect(phaseFilters(doc).at(-1).label).toBe('Mine');
    expect(resetPhasePatch('p1')).toEqual({ phaseId: 'p1', demolishedId: null });
    expect(typeof phaseLook).toBe('function');
  });
});

describe('attributes', () => {
  it('counts uses and lists them', () => {
    const { doc, wall } = project();
    wall([0, 0], [1000, 0]);
    expect(attributeUses(doc).get('mat-default')).toBeGreaterThan(0);
    expect(attributeRows(doc).some((r) => r.id === 'mat-concrete')).toBe(true);
  });
  it('carries attributes over and skips those already there', () => {
    const a = project().doc;
    const file = exportAttributes(a, ['mat-concrete']);
    expect(file.items).toHaveLength(1);
    const b = project().doc;
    b.transact('r', () => b.remove('mat-concrete'));
    let r;
    b.transact('i', () => (r = importAttributes(b, file)));
    expect(r).toEqual({ added: 1, replaced: 0 });
    b.transact('i', () => (r = importAttributes(b, file)));
    expect(r.added).toBe(0);
  });
  it('has 255 pens and assigns them to classes', () => {
    expect(defaultPens()).toHaveLength(255);
    const pens = defaultPens();
    pens[4] = { color: '#ff0000', mm: 0.77 };
    const project2 = { penTable: pens, penClasses: { 4: 5 }, penColors: true };
    expect(penTable(project2)[4].mm).toBe(0.77);
    expect(classWeights(project2)[4]).toBe(0.77);
    expect(classWeights({})).toBe(null);
    const col = classColors(project2);
    expect(col[16]).toBeCloseTo(1);
    expect(col[19]).toBe(1);
    expect(classColors({ penClasses: { 4: 5 } })).toBe(null);
  });
  it('project MEP systems take effect and go back', () => {
    const before = SYSTEMS.duct.length;
    applyMepSystems({ mepSystems: { duct: [{ value: 'x', label: 'X', color: '#000000' }] } });
    expect(SYSTEMS.duct).toHaveLength(1);
    applyMepSystems({});
    expect(SYSTEMS.duct).toHaveLength(before);
  });
  it('project operation profiles appear and go', () => {
    applyOperationProfiles({ operationProfiles: { mine: { label: 'M', weekday: Array(24).fill(1), weekend: Array(24).fill(1) } } });
    expect(PROFILES.mine.label).toBe('M');
    applyOperationProfiles({});
    expect(PROFILES.mine).toBeUndefined();
    expect(PROFILES.office).toBeDefined();
  });
});
