import { describe, it, expect } from 'vitest';
import { createProject } from '../src/core/template.js';
import { landingGuides, pointAlong } from '../src/core/landingguides.js';

describe('stair landing calculation guidelines', () => {
  it('measures the walking line over an L landing and the rule lengths', () => {
    const doc = createProject({ system: 'metric' });
    const lv = doc.levels();
    let st;
    doc.transact('s', () => (st = doc.add({ kind: 'stair', levelId: lv[0].id, topLevelId: lv[1]?.id ?? null, a: [0, 0], b: [3000, 0], shape: 'l', width: 1000, typeId: doc.all('stairType')[0]?.id })));
    const g = landingGuides(doc, doc.get(st.id));
    expect(g).toHaveLength(1);
    expect(g[0].path).toHaveLength(3);
    expect(g[0].length).toBeGreaterThan(900);
    expect(g[0].ideal[0].n).toBe(0);
    expect(g[0].ideal.every((x, i) => i === 0 || x.length - g[0].ideal[i - 1].length === g[0].step)).toBe(true);
  });
  it('finds points along a polyline', () => {
    expect(pointAlong([[0, 0], [100, 0], [100, 100]], 150)).toEqual([100, 50]);
  });
});
