/** Synthetic Archicad library files for tests, laid out as Archicad's (see src/io/gsm.js). */
const be32 = (v) => [(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255];
const le32 = (v) => [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255];
export const ascii = (s) => Array.from(s, (c) => c.charCodeAt(0));
const utf16be = (s) => Array.from(s).flatMap((c) => [0, c.charCodeAt(0)]);
const utf16le = (s) => Array.from(s).flatMap((c) => [c.charCodeAt(0), 0]);
const nameBlock = (s) => [2, 1, 0, 0, 0, 0x24, 1, 0, ...be32(s.length), ...utf16be(s)];

export function fileEntry(name, data) {
  const nb = nameBlock(name);
  // Prefix: tag, 0, 0, 1, size; record: version 2, header 0x38, name size; dates; data size, 0, data offset (from the record).
  const rec = [...be32(2), ...be32(0x38), ...be32(nb.length), ...new Array(16).fill(0), ...new Array(16).fill(0), ...be32(data.length), ...be32(0), ...be32(0x38 + nb.length)];
  const body = [...rec, ...nb, ...data];
  return [...ascii('FILE'), ...be32(0), ...be32(0), ...be32(1), ...be32(20 + body.length), ...body];
}
export function folderEntry(name, children) {
  const nb = nameBlock(name);
  const kids = children.flat();
  const rec = [...be32(2), ...be32(0x1c), ...be32(nb.length), ...be32(1), ...be32(4), ...be32(0), ...be32(0x1c + nb.length)];
  const body = [...rec, ...nb, ...kids];
  return [...ascii('FLDR'), ...be32(0), ...be32(0), ...be32(children.length), ...be32(20 + body.length), ...body];
}
export function container(entries) {
  const kids = entries.flat();
  return new Uint8Array([...ascii('GLCF'), 0x65, 0xc0, 0x7a, 0x1e, 0, 1, 0, 0, 0, 0, 0, 0, ...be32(0x18), 0, 0, 0, 0, ...ascii('MAIN'), ...be32(0), ...be32(0), ...be32(1), ...be32(20 + kids.length), ...kids]);
}
/**
 * A binary 3D section's content after its 16-byte header (see src/io/binary3d.js): one body of the
 * triangles given (each three [x, y, z]).
 */
export function binary3d(tris) {
  const n = tris.length;
  const size = 0x54 + 124 + 32 * n + 4 * 3 * n + 24 * 3 * n + 24 * 3 * n + 24 * n;
  const dv = new DataView(new ArrayBuffer(size));
  const u = (o, v) => dv.setUint32(o, v, true);
  u(0x10, 0xfb1);
  [1, n, 3 * n, 3 * n, 3 * n, n].forEach((v, k) => u(0x18 + 4 * k, v));
  const ranges = [n, 3 * n, 3 * n, 3 * n, n];
  ranges.forEach((v, k) => (u(0x54 + 0x30 + 8 * k, 1), u(0x54 + 0x34 + 8 * k, v)));
  const pgons = 0x54 + 124;
  const list = pgons + 32 * n;
  const edges = list + 12 * n;
  const verts = edges + 72 * n;
  tris.forEach((t, i) => {
    u(pgons + 32 * i + 16, 3 * i);
    u(pgons + 32 * i + 20, 3 * i + 2);
    for (let k = 0; k < 3; k++) {
      dv.setInt32(list + 4 * (3 * i + k), 3 * i + k + 1, true);
      u(edges + 24 * (3 * i + k) + 8, 3 * i + k);
      u(edges + 24 * (3 * i + k) + 12, 3 * i + ((k + 1) % 3));
      t[k].forEach((c, j) => dv.setFloat64(verts + 24 * (3 * i + k) + 8 * j, c, true));
    }
  });
  return Array.from(new Uint8Array(dv.buffer, 16));
}

/**
 * The same as binary3d in the oldest layout Archicad 30's libraries hold (version 4001): a header of 0x30
 * after the version, 76-byte bodies (ranges at +0x24), 24-byte polygons (edge list at +12, +16), 20-byte
 * edges (vertices at +4, +8), vertices as floats.
 */
export function binary3d4001(tris) {
  const n = tris.length;
  const at = 0x44;
  const size = at + 76 + 24 * n + 4 * 3 * n + 20 * 3 * n + 12 * 3 * n + 12 * n;
  const dv = new DataView(new ArrayBuffer(size));
  const u = (o, v) => dv.setUint32(o, v, true);
  u(0x10, 4001);
  [1, n, 3 * n, 3 * n, 3 * n, n].forEach((v, k) => u(0x18 + 4 * k, v));
  [n, 3 * n, 3 * n, 3 * n, n].forEach((v, k) => (u(at + 0x24 + 8 * k, 1), u(at + 0x28 + 8 * k, v)));
  const pgons = at + 76;
  const list = pgons + 24 * n;
  const edges = list + 12 * n;
  const verts = edges + 60 * n;
  tris.forEach((t, i) => {
    u(pgons + 24 * i + 12, 3 * i);
    u(pgons + 24 * i + 16, 3 * i + 2);
    for (let k = 0; k < 3; k++) {
      dv.setInt32(list + 4 * (3 * i + k), 3 * i + k + 1, true);
      u(edges + 20 * (3 * i + k) + 4, 3 * i + k);
      u(edges + 20 * (3 * i + k) + 8, 3 * i + ((k + 1) % 3));
      t[k].forEach((c, j) => dv.setFloat32(verts + 12 * (3 * i + k) + 4 * j, c, true));
    }
  });
  return Array.from(new Uint8Array(dv.buffer, 16));
}

export function libraryPart({ script3d = '', script2d = '', master = '', params, pictures = [], binaries = [], preview = null }) {
  const sec = (tag, body) => [...ascii(tag.split('').reverse().join('')), 0x57, 0x57, 0x14, 0, ...le32(16 + body.length), 0, 0, 0, 0, ...body];
  // Parameters: a header with the count at 0x2F and the pool at 0x3D, 72-byte records from 0x41. An array
  // (p.array: values, or rows of values) has its flag at 18, its dimensions at 20 and 24, and the offset of its
  // values (from 0x41) in the 4 bytes after its record; the values follow the pool.
  const recs = [];
  const data = [];
  const arrays = [];
  for (const p of params) {
    const r = new Array(72).fill(0);
    r[16] = p.code;
    const v = new DataView(new ArrayBuffer(8));
    if (p.int) v.setInt32(0, p.value || 0, true);
    else v.setFloat64(0, p.value || 0, true);
    for (let i = 0; i < 8; i++) r[32 + i] = v.getUint8(i);
    ascii(p.name).forEach((c, i) => (r[40 + i] = c));
    if (p.array) {
      const rows = Array.isArray(p.array[0]) ? p.array : null;
      const flat = rows ? rows.flat() : p.array;
      r[18] = 1;
      le32(rows ? rows.length : flat.length).forEach((b, i) => (r[20 + i] = b));
      le32(rows ? rows[0].length : 0).forEach((b, i) => (r[24 + i] = b));
      arrays.push({ at: recs.length + 72, from: data.length });
      for (const x of flat) {
        const w = new DataView(new ArrayBuffer(p.int ? 4 : 8));
        if (p.int) w.setInt32(0, x, true);
        else w.setFloat64(0, x, true);
        for (let i = 0; i < w.byteLength; i++) data.push(w.getUint8(i));
      }
    }
    // A string (p.string): UTF-16 ending with a zero, its offset (from 0x41) after its record, as an array's.
    if (typeof p.string === 'string') {
      arrays.push({ at: recs.length + 72, from: data.length });
      data.push(...utf16le(p.string), 0, 0);
    }
    recs.push(...r);
  }
  recs.push(...new Array(12).fill(0));
  const pool = params.flatMap((p) => [...utf16le(p.label), 0, 0]);
  for (const a of arrays) le32(recs.length + pool.length + a.from).forEach((b, i) => (recs[a.at + i] = b));
  const head = new Array(0x41 - 16).fill(0);
  const pardBody = [...head, ...recs, ...pool, ...data];
  pardBody[0x2f - 16] = params.length & 255;
  const poolAt = 0x41 + recs.length;
  le32(poolAt).forEach((b, i) => (pardBody[0x3d - 16 + i] = b));
  const sections = [['3DSC', ascii(script3d)], ['2DSC', ascii(script2d)], ['1DSC', ascii(master)], ['PARD', pardBody]];
  // Pictures: the index in the section's header (at +12), then a MIME type and a zero byte before the image.
  const picSec = (tag, id, data) => {
    const body = tag === '3DBN' ? data : [...ascii('image/png'), 0, ...data];
    return [...ascii(tag.split('').reverse().join('')), 0x57, 0x57, 0x13, 0, ...le32(16 + body.length), ...le32(id), ...body];
  };
  for (const [id, data] of pictures) sections.push(['GDLP', { id, data }]);
  for (const [id, data] of binaries) sections.push(['3DBN', { id, data }]);
  if (preview) sections.push(['GIFF', { id: 0, data: preview }]);
  const dirAt = 0x80;
  let at = dirAt + 16 * sections.length;
  const dir = [];
  const bodies = [];
  for (const [tag, body] of sections) {
    const s = body.data ? picSec(tag, body.id, body.data) : sec(tag, body);
    dir.push(...ascii(tag.split('').reverse().join('')), ...le32(at), ...le32(s.length), 0, 0, 0, 0);
    bodies.push(...s);
    at += s.length;
  }
  const headBytes = new Array(dirAt).fill(0);
  headBytes[0] = 0x57;
  headBytes[1] = 0x57;
  le32(sections.length).forEach((b, i) => (headBytes[0x24 + i] = b));
  le32(dirAt).forEach((b, i) => (headBytes[0x34 + i] = b));
  return [...headBytes, ...dir, ...bodies];
}

