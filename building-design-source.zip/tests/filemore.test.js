import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { scheduleTable } from '../src/core/schedule.js';
import { applyPropertyTable } from '../src/core/propimport.js';
import { analyticalModel, safSheets } from '../src/core/analytical.js';
import { safToModel, filterSAFModel } from '../src/core/safimport.js';
import { Settings } from '../src/settings.js';

describe('Export Property Values from Schedule', () => {
  it('writes element ids and brings edited values back, units and groups included', () => {
    const { doc, wall, add } = project();
    const fire = add({ kind: 'projectParam', name: 'Fire Rating', type: 'text', categories: ['walls'], group: 'Identity Data' });
    const cover = add({ kind: 'projectParam', name: 'Cover', type: 'length', categories: ['walls'], group: 'Identity Data' });
    const a = wall([0, 0], [4000, 0]);
    const b = wall([0, 3000], [4000, 3000]);
    const view = { kind: 'schedule', category: 'wall', fields: ['type', `param:${fire.id}`, `param:${cover.id}`], itemize: true };
    const t = scheduleTable({ doc, scene: new Scene(doc) }, view, { ids: true });
    const head = t.rows[0].cells;
    expect(head[0]).toBe('Element ID');
    expect(head.some((h) => /^Cover \((m|ft)\)$/.test(h))).toBe(true);
    // Edit: one row's ids may hold both walls (a grouped row).
    const rows = t.rows.map((r) => [...r.cells]);
    const iFire = head.indexOf('Fire Rating');
    const iCover = head.findIndex((h) => h.startsWith('Cover'));
    rows[1][iFire] = 'REI 60';
    rows[1][iCover] = 0.05;
    if (!String(rows[1][0]).includes(';')) rows[1][0] = `${a.id}; ${b.id}`;
    let out;
    doc.transact('i', () => (out = applyPropertyTable(doc, rows)));
    expect(out.updated).toBeGreaterThanOrEqual(2);
    expect(doc.get(a.id).params[fire.id]).toBe('REI 60');
    expect(doc.get(b.id).params[cover.id]).toBeCloseTo(50, 6);
  });
});

describe('SAF translators and import', () => {
  function frame() {
    const p = project();
    const { doc } = p;
    const ct = doc.all('columnType')[0];
    const bt = doc.all('beamType')[0];
    for (const at of [[0, 0], [6000, 0], [6000, 5000], [0, 5000]]) p.add({ kind: 'column', typeId: ct.id, levelId: p.L1.id, at, topLevelId: p.L2.id });
    p.add({ kind: 'beam', typeId: bt.id, levelId: p.L2.id, a: [0, 0], b: [6000, 0], offset: 0, structural: true });
    p.add({ kind: 'floor', typeId: doc.all('floorType')[0].id, levelId: p.L2.id, offset: 0, boundary: [[0, 0], [6000, 0], [6000, 5000], [0, 5000]], structural: true });
    return p;
  }
  const asMap = (sheets) => new Map(sheets.map((s) => [s.name, s.rows.map((r) => r.cells)]));

  it('leaves out what the translator turns off', () => {
    const p = frame();
    const m = analyticalModel(p.doc);
    const f = filterSAFModel(m, { members: true, surfaces: false, supports: true, loads: true, combinations: true });
    expect(f.surfaces).toHaveLength(0);
    expect(f.members.length).toBe(m.members.length);
  });

  it('brings a SAF workbook back as columns, beams and slabs', () => {
    const src = frame();
    const m = analyticalModel(src.doc);
    expect(m.members.length).toBeGreaterThanOrEqual(5);
    const sheets = asMap(safSheets(m));
    const dst = project();
    let n;
    dst.doc.transact('saf', () => (n = safToModel(dst.doc, sheets)));
    expect(n.columns).toBe(m.members.filter((x) => x.type === 'Column').length);
    expect(n.beams).toBeGreaterThanOrEqual(1);
    expect(n.slabs).toBe(m.surfaces.length);
    const col = dst.doc.all('column')[0];
    expect(col.height).toBeGreaterThan(2000);
    const fl = dst.doc.all('floor')[0];
    expect(Math.max(...fl.boundary.map((q) => q[0]))).toBeCloseTo(6000, -2);
  });
});

describe('New & Reset All', () => {
  it('sets preferences back to their defaults, keeping the theme', () => {
    const s = new Settings();
    s.saved = { theme: 'dark', snaps: { enabled: false }, workspaceAc: true };
    s.reset(['theme']);
    expect(s.saved).toEqual({ theme: 'dark' });
    expect(s.values.snaps?.enabled).not.toBe(false);
  });
});
