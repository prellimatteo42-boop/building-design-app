import { describe, it, expect } from 'vitest';
import { gridSystem, parseSpacings, letterName } from '../src/core/gridsystem.js';

describe('grid system', () => {
  it('reads spacings with repeats', () => {
    expect(parseSpacings('5000, 2x4000; 3500')).toEqual([5000, 4000, 4000, 3500]);
    expect(parseSpacings('5000, -1')).toBe(null);
    expect(parseSpacings('')).toEqual([]);
  });

  it('names lines with numbers and letters', () => {
    expect([0, 1, 25, 26, 27].map(letterName)).toEqual(['A', 'B', 'Z', 'AA', 'AB']);
  });

  it('lays out the grid with dimension chains', () => {
    const { grids, dims } = gridSystem({ origin: [1000, 0], xs: [5000, 4000], ys: [6000], overhang: 2000, viewId: 'v1' });
    expect(grids.map((g) => g.name)).toEqual(['1', '2', '3', 'A', 'B']);
    const g3 = grids.find((g) => g.name === '3');
    expect(g3.a).toEqual([10000, -2000]);
    expect(g3.b).toEqual([10000, 8000]);
    // Spacings and overall along x; one spacing along y.
    expect(dims.length).toBe(3);
    expect(dims[0].refs.map((r) => r.at[0])).toEqual([1000, 6000, 10000]);
  });
});
