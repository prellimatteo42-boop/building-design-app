import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { placeParapetDims, removeParapetDims, sillHeight, convertDimensions, refreshConverted, removeConverted, formatInUnit, heightToReference } from '../src/core/dimextras.js';
import { elevationFrom } from '../src/core/coords.js';
import { instanceParams, paramValue } from '../src/core/props.js';
import { snapFeatures } from '../src/editor/snap.js';
import { KIND_LABEL } from '../src/core/catalog.js';

const planOf = (doc, L) => doc.all('plan').find((v) => v.levelId === L.id);

describe('parapet dimensions', () => {
  it('writes the sill height by each window on the room side, refreshes and removes them', () => {
    const p = project();
    const { doc, L1 } = p;
    const w = p.wall([0, 0], [6000, 0], { baseOffset: 150 });
    const wt = doc.all('windowType')[0];
    const win = p.add({ kind: 'window', typeId: wt.id, hostId: w.id, levelId: L1.id, t: 2000, width: 1200, sill: 900 });
    expect(sillHeight(doc, win)).toBe(1050);
    expect(sillHeight(doc, win, 'wall')).toBe(900);
    const v = planOf(doc, L1);
    const units = { system: 'metric', metric: 'cm', decimals: 0 };
    const r = doc.transact('pd', () => placeParapetDims(doc, v, units, { opts: { prefix: 'H', from: 'story', side: 'interior' } }));
    expect(r.added).toBe(1);
    const t = doc.all('text').find((x) => x.auto?.kind === 'parapet');
    expect(t.text).toBe('H 105');
    expect(t.at[0]).toBeCloseTo(2000);
    // Exterior is the left of a->b (+y): the text sits on the -y side, off the face.
    expect(t.at[1]).toBeLessThan(-100);
    // Move the window and raise it: refresh follows.
    doc.transact('m', () => doc.update(win.id, { t: 3000, sill: 1000 }));
    const r2 = doc.transact('rf', () => placeParapetDims(doc, v, units, { opts: { prefix: 'H', from: 'story', side: 'interior' }, refresh: true }));
    expect(r2.updated).toBe(1);
    const t2 = doc.get(t.id);
    expect(t2.text).toBe('H 115');
    expect(t2.at[0]).toBeCloseTo(3000);
    expect(doc.transact('rm', () => removeParapetDims(doc, v))).toBe(1);
    expect(doc.all('text')).toHaveLength(0);
  });
});

describe('secondary dimensions', () => {
  it('formats in a second unit', () => {
    expect(formatInUnit(3048, 'ftin', 8)).toBe(`10' - 0"`);
    expect(formatInUnit(1234, 'm', 2)).toBe('1.23');
    expect(formatInUnit(304.8, 'ft', 1)).toBe(`1.0'`);
  });

  it('converts each segment, refreshes after a change and removes', () => {
    const p = project();
    const { doc, L1 } = p;
    const v = planOf(doc, L1);
    const w1 = p.wall([0, 0], [0, 3000]);
    const w2 = p.wall([4000, 0], [4000, 3000]);
    const w3 = p.wall([6000, 0], [6000, 3000]);
    const dim = p.add({ kind: 'dimension', viewId: v.id, dir: [1, 0], line: [0, -1000], refs: [w1, w2, w3].map((w) => ({ id: w.id, ref: 'center', at: [w.a[0], -1000] })) });
    const n = doc.transact('c', () => convertDimensions(doc, v, { unit: 'ftin', decimals: 2 }));
    expect(n).toBe(2);
    const texts = doc.all('text').sort((a, b) => a.auto.seg - b.auto.seg);
    expect(texts[0].text).toBe(formatInUnit(4000, 'ftin', 2));
    expect(texts[0].at[1]).toBeLessThan(-1000); // under the line
    doc.transact('mv', () => doc.update(w2.id, { a: [3000, 0], b: [3000, 3000] }));
    expect(doc.transact('r', () => refreshConverted(doc, v))).toBe(2);
    const after = doc.all('text').sort((a, b) => a.auto.seg - b.auto.seg);
    expect(after[0].text).toBe(formatInUnit(3000, 'ftin', 2));
    expect(after[1].text).toBe(formatInUnit(3000, 'ftin', 2));
    expect(doc.transact('x', () => removeConverted(doc, v, [dim.id]))).toBe(2);
  });
});

describe('hotspots and reference levels', () => {
  it('a hotspot is a snap point', () => {
    const p = project();
    const h = p.add({ kind: 'hotspot', viewId: planOf(p.doc, p.L1).id, at: [100, 200] });
    expect(snapFeatures({ doc: p.doc }, h).points[0].p).toEqual([100, 200]);
    expect(KIND_LABEL.hotspot).toBe('Hotspot');
  });

  it('reads elevations from the reference levels', () => {
    const p = project();
    const { doc } = p;
    doc.transact('r', () => doc.update('project', { referenceLevels: [{ name: 'Sea Level', elevation: -42000 }, { name: 'Ground', elevation: -300 }] }));
    expect(elevationFrom(doc, 0, 'ref1')).toBe(42000);
    expect(elevationFrom(doc, 1000, 'ref2')).toBe(1300);
    expect(heightToReference(doc.get('project'), 0)).toBe(42000);
    const w = p.wall([0, 0], [3000, 0], { topLevelId: null, height: 2700 });
    const ctx = { doc };
    const defs = instanceParams(w);
    const get = (k) => paramValue(defs.find((d) => d.key === k), w, ctx);
    expect(get('refBottom')).toBe(42000);
    doc.transact('s', () => doc.update('project', { shownReference: 2 }));
    expect(get('refTop')).toBe(3000);
    expect(get('refName')).toBe('Ground');
  });
});
