import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { writeIFC } from '../src/io/ifc.js';
import { ifcProducts } from '../src/io/ifcread.js';
import { translatorFor, productLine, TRANSLATOR_PRESETS } from '../src/core/ifctranslators.js';
import { compareIFC, ifcElements } from '../src/core/ifccompare.js';
import { parseBIMContent, applyBIMContent, writeBIMContent, parseXML } from '../src/core/bimcontent.js';
import { paramsForElement } from '../src/core/params.js';

function house() {
  const p = project();
  for (const [a, b] of [[[0, 0], [6000, 0]], [[6000, 0], [6000, 4000]], [[6000, 4000], [0, 4000]], [[0, 4000], [0, 0]]]) p.wall(a, b, { typeId: 'wt-ext-concrete' });
  p.add({ kind: 'column', typeId: p.doc.all('columnType')[0].id, levelId: p.L1.id, at: [3000, 2000] });
  p.add({ kind: 'duct', typeId: p.doc.all('ductType')[0].id, levelId: p.L1.id, a: [500, 500], b: [5000, 500], offset: 2600 });
  p.add({ kind: 'room', levelId: p.L1.id, at: [3000, 2000], name: 'Room', upperOffset: 2700 });
  return p;
}
const app = (p) => ({ doc: p.doc, scene: new Scene(p.doc) });

describe('IFC translators', () => {
  it('writes IFC2x3 with faceted B-rep that the reader takes back', () => {
    const p = house();
    const txt = writeIFC(app(p), 'tr-coordination');
    expect(txt).toContain("FILE_SCHEMA(('IFC2X3'))");
    expect(txt).toContain('IFCFACETEDBREP');
    expect(txt).not.toContain('IFCTRIANGULATEDFACESET');
    expect(txt).toMatch(/IFCWALL\('[^']+',\$,[^)]*,'[^']*'\)/);
    expect(txt).toContain('IFCPRESENTATIONSTYLEASSIGNMENT');
    const back = ifcProducts(txt);
    expect(back.products.filter((x) => x.type === 'IFCWALL')).toHaveLength(4);
  });

  it('writes in metres and filters to the load-bearing structure', () => {
    const p = house();
    const txt = writeIFC(app(p), 'tr-structural');
    expect(txt).toContain('IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.)');
    expect(txt).not.toContain('IFCSPACE(');
    expect(txt).not.toMatch(/IFCDUCTSEGMENT|IFCBUILDINGELEMENTPROXY\(/);
    expect(txt).toContain('IFCCOLUMN(');
    const back = ifcProducts(txt);
    expect(back.scale).toBe(1000);
    // Read back in millimetres, the 6 m wall is 6 m long.
    const xs = back.products.filter((x) => x.type === 'IFCWALL').flatMap((w) => w.tris.filter((_, i) => i % 3 === 0));
    expect(Math.max(...xs)).toBeGreaterThan(5900);
  });

  it('only the building services', () => {
    const p = house();
    const txt = writeIFC(app(p), { ...TRANSLATOR_PRESETS[0], filter: 'mep' });
    expect(txt).not.toContain('IFCWALL(');
    expect(txt).toMatch(/IFC(DUCTSEGMENT|BUILDINGELEMENTPROXY)\(/);
  });

  it('maps entities by kind and writes the project tree names', () => {
    const p = house();
    p.doc.transact('t', () => p.doc.update('project', { ifcProject: { projectName: 'Casa Rossi', siteName: 'Lotto 7', buildingName: 'Edificio A' } }));
    const w = p.doc.all('wall')[0];
    p.doc.transact('a', () => p.doc.update(w.id, { ifcAttrs: { Name: 'Muro sud', Description: 'Facciata', ObjectType: 'Muro portante' } }));
    const txt = writeIFC(app(p), { ...translatorFor(p.doc), entityMap: { column: 'IfcMember' } });
    expect(txt).toContain("IFCPROJECT('");
    expect(txt).toContain("'Casa Rossi'");
    expect(txt).toContain("'Lotto 7'");
    expect(txt).toContain("'Edificio A'");
    expect(txt).toContain("'Muro sud','Facciata','Muro portante'");
    expect(txt).toContain('IFCMEMBER(');
  });

  it('writes IFC2x3 lines with the right attribute counts', () => {
    const a = { g: 'G', n: "'n'", p: '#1', r: '#2', tag: "'t'", height: '2100.', width: '900.' };
    expect(productLine('IFC2X3', 'IFCDOOR', 'DOOR', a)).toBe("IFCDOOR('G',$,'n',$,$,#1,#2,'t',2100.,900.)");
    expect(productLine('IFC2X3', 'IFCFURNITURE', 'NOTDEFINED', a)).toBe("IFCFURNISHINGELEMENT('G',$,'n',$,$,#1,#2,'t')");
    expect(productLine('IFC2X3', 'IFCSLAB', 'FLOOR', a)).toBe("IFCSLAB('G',$,'n',$,$,#1,#2,'t',.FLOOR.)");
    expect(productLine('IFC4', 'IFCWALL', 'NOTDEFINED', a)).toBe("IFCWALL('G',$,'n',$,$,#1,#2,'t',.NOTDEFINED.)");
  });
});

describe('Detect IFC Model Changes', () => {
  it('finds new, deleted and changed elements by GlobalId', () => {
    const p = house();
    const before = writeIFC(app(p));
    const walls = p.doc.all('wall');
    p.doc.transact('c', () => {
      p.doc.update(walls[0].id, { b: [7000, 0] });
      p.doc.update(walls[1].id, { ifcAttrs: { Name: 'Renamed' } });
      p.doc.remove(p.doc.all('column')[0].id);
      p.add({ kind: 'column', typeId: p.doc.all('columnType')[0].id, levelId: p.L1.id, at: [1000, 1000] });
    });
    const after = writeIFC(app(p));
    const r = compareIFC(before, after);
    expect(r.added).toHaveLength(1);
    expect(r.deleted).toHaveLength(1);
    expect(r.modified.some((m) => m.changes.includes('geometry'))).toBe(true);
    expect(r.modified.some((m) => m.changes.some((c) => c.startsWith('name')))).toBe(true);
    expect(r.unchanged).toBeGreaterThan(0);
    expect(ifcElements(before).size).toBeGreaterThan(4);
  });
});

describe('Import BIM Content', () => {
  const XML = `<?xml version="1.0" encoding="UTF-8"?>
<BuildingInformation>
  <Classification><System><Name>Uniclass Lite</Name><EditionVersion>2024</EditionVersion><Items>
    <Item><ID>Ss</ID><Name>Systems</Name><Children>
      <Item><ID>Ss_25</ID><Name>Wall &amp; barrier systems</Name></Item>
    </Children></Item>
  </Items></System></Classification>
  <PropertyDefinitionGroups><PropertyDefinitionGroup><Name>Fire</Name><PropertyDefinitions>
    <PropertyDefinition><Name>Fire Rating</Name><Description>REI minutes</Description>
      <ValueDescriptor type="EnumerationValueDescriptor"><ValueType>String</ValueType><Values>
        <EnumerationValue><Value>REI 60</Value></EnumerationValue><EnumerationValue><Value>REI 120</Value></EnumerationValue>
      </Values></ValueDescriptor>
      <Classifications><ClassificationID><ItemID>Ss_25</ItemID><SystemName>Uniclass Lite</SystemName></ClassificationID></Classifications>
    </PropertyDefinition>
    <PropertyDefinition><Name>Thickness Check</Name><ValueDescriptor type="SingleValueDescriptor"><ValueType>Length</ValueType></ValueDescriptor></PropertyDefinition>
  </PropertyDefinitions></PropertyDefinitionGroup></PropertyDefinitionGroups>
</BuildingInformation>`;

  it('reads XML', () => {
    const root = parseXML('<a x="1"><b>t &lt; u</b><c/></a>');
    expect(root.children[0].attrs.x).toBe('1');
    expect(root.children[0].children[0].text).toBe('t < u');
  });

  it('brings in systems and properties, available by classification, and writes them back', () => {
    const p = house();
    const c = parseBIMContent(XML);
    expect(c.systems[0].items.map((i) => [i.code, i.parent])).toEqual([['Ss', null], ['Ss_25', 'Ss']]);
    expect(c.systems[0].items[1].name).toBe('Wall & barrier systems');
    expect(c.groups[0].props[0]).toMatchObject({ name: 'Fire Rating', type: 'choice', options: ['REI 60', 'REI 120'] });
    expect(c.groups[0].props[1].type).toBe('length');
    let n;
    p.doc.transact('i', () => (n = applyBIMContent(p.doc, c)));
    expect(n).toEqual({ systems: 1, items: 2, groups: 1, properties: 2 });
    const sys = p.doc.all('classSystem').find((s) => s.name === 'Uniclass Lite');
    const w = p.doc.all('wall')[0];
    p.doc.transact('c', () => p.doc.update(w.id, { classes: { [sys.id]: 'Ss_25' } }));
    expect(paramsForElement(p.doc, p.doc.get(w.id)).map((x) => x.name)).toContain('Fire Rating');
    // Again: updated, not doubled.
    p.doc.transact('i', () => applyBIMContent(p.doc, c));
    expect(p.doc.all('projectParam').filter((x) => x.name === 'Fire Rating')).toHaveLength(1);
    const back = parseBIMContent(writeBIMContent(p.doc));
    expect(back.systems.find((s) => s.name === 'Uniclass Lite').items).toHaveLength(2);
    expect(back.groups.find((g) => g.name === 'Fire').props.find((x) => x.name === 'Fire Rating').classes[0]).toEqual({ system: 'Uniclass Lite', code: 'Ss_25' });
  });
});
