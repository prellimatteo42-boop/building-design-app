import { describe, it, expect } from 'vitest';
import { elementKind, exportedZoneNames, exportedOpenings, isElementExport, exportedColumns, exportedRailings, exportedLifts } from '../src/core/acdwg.js';
import { flattenCAD } from '../src/core/cadflatten.js';
import { recognizeCAD } from '../src/core/recognize.js';

const L = (layer, a, b) => ({ type: 'LINE', layer, startPoint: { x: a[0], y: a[1] }, endPoint: { x: b[0], y: b[1] } });
const rect = (layer, x0, y0, x1, y1) => [L(layer, [x0, y0], [x1, y0]), L(layer, [x1, y0], [x1, y1]), L(layer, [x1, y1], [x0, y1]), L(layer, [x0, y1], [x0, y0])];
const ins = (name, layer = 'Walls') => ({ type: 'INSERT', layer, name, insertionPoint: { x: 0, y: 0 }, xScale: 1, yScale: 1, rotation: 0 });

// A plan Archicad wrote element by element: three wall blocks, a door and a window nested in two of them, a zone block.
function exported() {
  return {
    entities: [ins('Wall_1'), ins('Wall_2'), ins('Wall_3'), ins('Kitchen_7_9', 'Zone'), ...rect('Zone', 300, 300, 5800, 2800).map((l) => ({ ...l })), { type: 'TEXT', layer: 'Zone', startPoint: { x: 2000, y: 1500 }, text: '7', textHeight: 200 }],
    blocks: {
      // 6 m wall 200 thick with a 900 mm doorway at 2000..2900; the door's casings run 40 past the hole.
      Wall_1: { basePoint: { x: 0, y: 0 }, entities: [...rect('Walls', 0, 0, 2000, 200), ...rect('Walls', 2900, 0, 6000, 200), ins('Single Door 27', 'Doors')] },
      'Single Door 27': {
        basePoint: { x: 0, y: 0 },
        entities: [L('Doors', [1960, 0], [2940, 0]), L('Doors', [1960, 200], [2940, 200]), L('Doors', [2020, 200], [2020, 1060]), { type: 'ARC', layer: 'Doors', center: { x: 2020, y: 200 }, radius: 860, startAngle: 0, endAngle: Math.PI / 2 }],
      },
      // A wall across, with a window as long as its own block.
      Wall_2: { basePoint: { x: 0, y: 0 }, entities: [...rect('Walls', 6000, 0, 6200, 1000), ...rect('Walls', 6000, 2200, 6200, 3000), ins('Window 27', 'Windows')] },
      'Window 27': { basePoint: { x: 0, y: 0 }, entities: [L('Windows', [6000, 1000], [6000, 2200]), L('Windows', [6100, 1000], [6100, 2200]), L('Windows', [6200, 1000], [6200, 2200])] },
      Wall_3: { basePoint: { x: 0, y: 0 }, entities: [...rect('Walls', 0, 2800, 6000, 3000)] },
      Kitchen_7_9: { basePoint: { x: 0, y: 0 }, entities: [] },
    },
  };
}

describe('drawings Archicad exported element by element', () => {
  it('knows its element blocks in the languages it runs in', () => {
    expect(elementKind('Стена_12')).toBe('wall');
    expect(elementKind('Muro_3')).toBe('wall');
    expect(elementKind('Однопольная Дверь 27')).toBe('door');
    expect(elementKind('Прямоугольный Дверной Проем 27')).toBe('doorway');
    expect(elementKind('Двустворчатое Окно 27_4')).toBe('window');
    expect(elementKind('Portafinestra 2 ante')).toBe('window');
    expect(elementKind('Отверстие_1')).toBe('opening');
    expect(elementKind('Лестница_1')).toBe('stair');
    expect(elementKind('Leaf', 'Двери Archicad')).toBe('door');
  });

  it('reads zone names from zone blocks', () => {
    const flat = { inserts: [{ name: 'Camera 13_H.13 _33', parent: -1 }, { name: 'Corridoio A_2A_2', parent: -1 }, { name: 'Стена_1', parent: -1 }] };
    const names = exportedZoneNames(flat);
    expect(names.get('H.13')).toBe('Camera 13');
    expect(names.get('2A')).toBe('Corridoio A');
    expect(names.size).toBe(2);
  });

  it('finds each opening block with the wall it sits in', () => {
    const flat = flattenCAD(exported());
    expect(isElementExport(flat)).toBe(true);
    const ops = exportedOpenings(flat);
    const door = ops.find((o) => o.kind === 'door');
    const win = ops.find((o) => o.kind === 'window');
    // The door's leaf runs across the wall: the wall runs along x.
    expect(Math.abs(door.d[0])).toBeCloseTo(1, 5);
    expect(door.swing[0].r).toBe(860);
    // The window's glass runs along its wall (y), though its block's reveals are as long as its faces are.
    expect(Math.abs(win.d[1])).toBeCloseTo(1, 5);
    expect(win.hostWall.thickness).toBeCloseTo(200, 0);
  });

  it('makes doors and windows of the blocks, at the hole the gap leaves, and names the zone', () => {
    const flat = flattenCAD(exported());
    const roles = new Map([['Walls', 'wall'], ['Doors', 'door'], ['Windows', 'window'], ['Zone', 'zone']]);
    const rec = recognizeCAD(flat, roles);
    expect(rec.plan.doors).toHaveLength(1);
    expect(Math.round(rec.plan.doors[0].width)).toBe(900);
    expect(rec.plan.doors[0].swing[0].hinge).toEqual([2020, 200]);
    expect(rec.plan.windows).toHaveLength(1);
    expect(Math.round(rec.plan.windows[0].width)).toBe(1200);
    expect(rec.plan.rooms[0]).toEqual(expect.objectContaining({ name: 'Kitchen', number: '7' }));
  });
});

describe('columns, railings and lifts of an element-by-element export', () => {
  const circle = (layer, c, r, n = 36) => Array.from({ length: n }, (_, k) => L(layer, [c[0] + r * Math.cos((2 * Math.PI * k) / n), c[1] + r * Math.sin((2 * Math.PI * k) / n)], [c[0] + r * Math.cos((2 * Math.PI * (k + 1)) / n), c[1] + r * Math.sin((2 * Math.PI * (k + 1)) / n)]));
  const flat = () => flattenCAD({
    entities: [ins('Колонна_1', 'Columns'), ins('Column_2', 'Columns'), ins('Ограждение_1', '0'), ins('Лифт 27', '0')],
    blocks: {
      // A round column 360 across, with a coarse diamond hatch; a square one turned 30 degrees.
      'Колонна_1': { basePoint: { x: 0, y: 0 }, entities: [...circle('Columns', [1000, 1000], 180), { type: 'HATCH', layer: 'Columns', boundaryPaths: [{ polyline: [[1180, 1000], [1000, 1180], [820, 1000], [1000, 820]] }] }] },
      Column_2: { basePoint: { x: 0, y: 0 }, entities: [[0, 0], [400, 0], [400, 300], [0, 300]].map((p, i, a) => { const r = (q) => [5000 + q[0] * Math.cos(Math.PI / 6) - q[1] * Math.sin(Math.PI / 6), 5000 + q[0] * Math.sin(Math.PI / 6) + q[1] * Math.cos(Math.PI / 6)]; return L('Columns', r(p), r(a[(i + 1) % 4])); }) },
      // A railing in an L: the two faces of its rail, 45 apart, with short posts across.
      'Ограждение_1': { basePoint: { x: 0, y: 0 }, entities: [L('0', [0, 0], [3000, 0]), L('0', [0, 45], [2955, 45]), L('0', [3000, 0], [3000, 2000]), L('0', [2955, 45], [2955, 2000]), L('0', [1000, 0], [1000, 45]), L('0', [2000, 0], [2000, 45])] },
      // A lift car 1600 x 1200 with a door line.
      'Лифт 27': { basePoint: { x: 0, y: 0 }, entities: [...rect('0', 10000, 0, 11600, 1200), L('0', [10500, 0], [11100, 0])] },
    },
  });

  it('knows the block names', () => {
    expect(elementKind('Колонна_3')).toBe('column');
    expect(elementKind('Ограждение_1')).toBe('railing');
    expect(elementKind('Лифт 27')).toBe('lift');
    expect(elementKind('Stair Railing_2')).toBe('railing');
  });

  it('reads round and turned columns', () => {
    const cols = exportedColumns(flat());
    const round = cols.find((c) => c.round);
    expect(round.w).toBeGreaterThan(355);
    expect(round.w).toBeLessThan(365);
    expect(round.at[0]).toBeCloseTo(1000, -1);
    const sq = cols.find((c) => !c.round);
    expect([Math.round(sq.w), Math.round(sq.d)].sort()).toEqual([300, 400]);
    expect(((sq.rotation % 90) + 90) % 90).toBeCloseTo(30, 0);
  });

  it('reads a railing as the centre line of its rail, round its corner', () => {
    const [r] = exportedRailings(flat());
    expect(r.paths.length).toBe(1);
    const path = r.paths[0];
    expect(path.length).toBe(3);
    const corner = path.find((p) => Math.abs(p[0] - 2977.5) < 5 && Math.abs(p[1] - 22.5) < 5);
    expect(corner).toBeTruthy();
  });

  it('reads a lift car', () => {
    const [l] = exportedLifts(flat());
    expect([Math.round(l.w), Math.round(l.d)].sort((a, b) => a - b)).toEqual([1200, 1600]);
    expect(l.at[0]).toBeCloseTo(10800, -1);
  });
});
