import { describe, it, expect } from 'vitest';
import { hiddenLineEdges, independentDrawing } from '../src/core/hiddenline.js';
import { project } from './helpers.js';
import { Scene, MODEL_KINDS } from '../src/core/scene.js';

/** An axis-aligned box as a mesh: 12 triangles and its 12 edges. */
function box([x0, y0, z0], [x1, y1, z1]) {
  const v = (i) => [i & 1 ? x1 : x0, i & 2 ? y1 : y0, i & 4 ? z1 : z0];
  const quads = [[0, 1, 3, 2], [4, 5, 7, 6], [0, 1, 5, 4], [2, 3, 7, 6], [0, 2, 6, 4], [1, 3, 7, 5]];
  const pos = [];
  for (const [a, b, c, d] of quads) pos.push(...v(a), ...v(b), ...v(c), ...v(a), ...v(c), ...v(d));
  const edges = [];
  for (let i = 0; i < 8; i++) for (const bit of [1, 2, 4]) if (!(i & bit)) edges.push(...v(i), ...v(i | bit));
  return { pos: new Float32Array(pos), edges: new Float32Array(edges) };
}

describe('hidden-line projection', () => {
  // Looking north (+y) from y = 0: u along +x, depth along +y.
  const frame = { origin: [0, 0], right: [1, 0], look: [0, 1], near: 0, far: 100000 };

  it('hides the edges of a box behind a wider one', () => {
    const front = box([0, 1000, 0], [4000, 2000, 3000]);
    const back = box([1000, 5000, 500], [3000, 6000, 2000]);
    const lines = hiddenLineEdges([front, back], frame, { res: 10 });
    // Only the front box's outline shows: 4 sides of its front face (edges along the view direction project to points).
    const inside = lines.filter((l) => [l.a, l.b].every((p) => p[0] > 900 && p[0] < 3100 && p[1] > 400 && p[1] < 2100));
    expect(inside).toHaveLength(0);
    const horizontal = lines.filter((l) => Math.abs(l.a[1] - l.b[1]) < 1 && Math.abs(Math.abs(l.a[0] - l.b[0]) - 4000) < 30);
    expect(horizontal.length).toBe(2);
  });

  it('shows the part of a box that sticks out and cuts at the near plane', () => {
    const front = box([0, 1000, 0], [2000, 2000, 3000]);
    const back = box([1000, 5000, 0], [4000, 6000, 1000]);
    const lines = hiddenLineEdges([front, back], frame, { res: 10 });
    // The back box's top edge shows from x = 2000 to 4000 only.
    const top = lines.find((l) => Math.abs(l.a[1] - 1000) < 1 && Math.abs(l.b[1] - 1000) < 1 && Math.max(l.a[0], l.b[0]) > 3900);
    expect(Math.min(top.a[0], top.b[0])).toBeGreaterThan(1950);
    expect(Math.min(top.a[0], top.b[0])).toBeLessThan(2100);
    // With the near plane past the front box it no longer hides anything.
    const behind = hiddenLineEdges([front, back], { ...frame, near: 3000 }, { res: 10 });
    expect(behind.some((l) => Math.abs(l.a[1] - 1000) < 1 && Math.min(l.a[0], l.b[0]) < 1100)).toBe(true);
  });

  it('draws a section of real walls as cut fills and projected lines', () => {
    const p = project();
    p.box(0, 0, 6000, 4000);
    const scene = new Scene(p.doc);
    const section = p.add({ kind: 'section', a: [-1000, 2000], b: [7000, 2000], depth: 8000, scale: 50, name: 'S1' });
    const parts = independentDrawing(p.doc, p.doc.get(section.id), (el) => scene.mesh(el), MODEL_KINDS);
    // Two walls cut, filled; the wall beyond is drawn in projection.
    expect(parts.fills.length).toBeGreaterThanOrEqual(2);
    expect(parts.lines.length).toBeGreaterThan(8);
  });
});
