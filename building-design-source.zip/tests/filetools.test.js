import { describe, it, expect } from 'vitest';
import { toolSchemas, runTool } from '../src/assistant/tools.js';
import { download } from '../src/io/storage.js';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';

describe('file tools for automation', () => {
  it('appear only through the MCP bridge, not in the in-app assistant', () => {
    const inApp = toolSchemas().map((t) => t.name);
    const bridge = toolSchemas({ bridge: true }).map((t) => t.name);
    for (const n of ['new_project', 'open_project', 'save_project', 'export_file']) {
      expect(inApp).not.toContain(n);
      expect(bridge).toContain(n);
    }
  });

  it('downloads are captured while a tool runs', () => {
    globalThis.__bdCapture = [];
    download(new Blob(['x']), 'a.txt');
    expect(globalThis.__bdCapture.map((f) => f.name)).toEqual(['a.txt']);
    globalThis.__bdCapture = undefined;
  });

  it('save_project returns the project bytes for the bridge to write', async () => {
    const p = project();
    p.box(0, 0, 4000, 3000);
    const app = { doc: p.doc, scene: new Scene(p.doc), selection: new Set(), commit: (l, fn) => p.doc.transact(l, fn) };
    const r = await runTool(app, 'save_project', { path: '/tmp/x.bdp' });
    expect(r.error).toBeUndefined();
    expect(r._file.bytes).toBeGreaterThan(100);
    expect(atob(r._file.base64).length).toBe(r._file.bytes);
  });
});
