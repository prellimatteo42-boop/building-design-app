import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { hatchSegments, defaultFillTypes, parseDashes } from '../src/core/filltypes.js';
import { PlanBuilder, materialPattern, regionPattern, planGraphics, planContext } from '../src/core/plan.js';
import { Scene } from '../src/core/scene.js';

const total = (segs) => segs.reduce((s, [a, b]) => s + Math.hypot(b[0] - a[0], b[1] - a[1]), 0);

describe('fill types', () => {
  const sq = [[0, 0], [1000, 0], [1000, 1000], [0, 1000]];
  it('hatch inside the outline and around holes', () => {
    const tile = defaultFillTypes().find((f) => f.id === 'ft-tile');
    const segs = hatchSegments(sq, [], tile);
    // Lines at 0, 300, 600, 900 both ways: 4 + 4 full lines.
    expect(segs).toHaveLength(8);
    expect(total(segs)).toBeCloseTo(8000, 6);
    const holed = hatchSegments(sq, [[[250, 250], [750, 250], [750, 750], [250, 750]]], tile);
    expect(total(holed)).toBeCloseTo(8000 - 2 * 2 * 500, 6);
  });

  it('dash and shift lines like CAD patterns, and scale paper fills', () => {
    const brick = defaultFillTypes().find((f) => f.id === 'ft-brick');
    const v = hatchSegments([[0, 0], [900, 0], [900, 150], [0, 150]], [], { families: [brick.families[1]] });
    // Vertical joints: 75 mm long, alternating between courses.
    expect(v.every(([a, b]) => Math.abs(Math.hypot(b[0] - a[0], b[1] - a[1]) - 75) < 1e-6)).toBe(true);
    // Each course has a joint every 225 mm, half a brick from the next course's.
    const course = (lo) => v.filter(([a, b]) => Math.min(a[1], b[1]) >= lo - 1e-6 && Math.max(a[1], b[1]) <= lo + 75 + 1e-6).map(([a]) => Math.round(a[0] * 10) / 10).sort((x, y) => x - y);
    const c1 = course(0);
    const c2 = course(75);
    expect(c1[1] - c1[0]).toBeCloseTo(225, 6);
    expect(c2[1] - c2[0]).toBeCloseTo(225, 6);
    expect(c1.some((x) => c2.includes(x))).toBe(false);
    const paper = defaultFillTypes().find((f) => f.id === 'ft-fine-diag');
    expect(hatchSegments(sq, [], paper, 100).length).toBeLessThan(hatchSegments(sq, [], paper, 50).length);
    expect(parseDashes('75, -25 x 0')).toEqual([75, -25]);
  });

  it('draw as lines in fills and in material cuts', () => {
    const { doc, wall } = project();
    const view = doc.all('plan')[0];
    const b = new PlanBuilder();
    b.fill(sq, [], [0, 0, 0, 20], regionPattern(doc, 'ft-tile', 100));
    expect(b.lines).toHaveLength(8);
    expect(b.fills[0].pattern).toBe(0);
    expect(regionPattern(doc, 'brick')).toBe(5);
    doc.transact('m', () => doc.update('mat-masonry-brick', { fillTypeId: 'ft-brick' }));
    expect(materialPattern(doc.get('mat-masonry-brick'), { doc, scale: 50 }).type.id).toBe('ft-brick');
    const w = wall([0, 0], [4000, 0], { typeId: 'wt-ext-brick-stud' });
    const scene = new Scene(doc);
    const before = planGraphics(planContext(doc, { ...view, detail: 'fine' }, scene.walls, scene.rooms), doc.get(w.id)).lines.length;
    doc.transact('m2', () => doc.update('mat-masonry-brick', { fillTypeId: null }));
    const after = planGraphics(planContext(doc, { ...view, detail: 'fine' }, scene.walls, scene.rooms), doc.get(w.id)).lines.length;
    expect(before).toBeGreaterThan(after);
  });
});

describe('fill orientation', () => {
  it('turns and places the pattern with a frame', () => {
    const tile = { families: [{ angle: 0, spacing: 100 }] };
    const poly = [[0, 0], [1000, 0], [1000, 1000], [0, 1000]];
    const plain = hatchSegments(poly, [], tile);
    expect(plain.every(([a, b]) => Math.abs(a[1] - b[1]) < 1e-6)).toBe(true);
    const turned = hatchSegments(poly, [], tile, 1, { angle: 90, origin: [50, 0] });
    expect(turned.every(([a, b]) => Math.abs(a[0] - b[0]) < 1e-6)).toBe(true);
    expect(turned.map(([a]) => Math.round(a[0])).sort((x, y) => x - y)[0]).toBe(50);
  });
});
