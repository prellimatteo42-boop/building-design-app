import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { surfaceZ, gravityPatch } from '../src/core/gravity.js';

describe('gravity', () => {
  it('puts objects and columns on the slab, roof or mesh under them', () => {
    const p = project();
    const l1 = p.L1;
    p.add({ kind: 'floor', typeId: p.doc.all('floorType')[0].id, levelId: l1.id, boundary: [[0, 0], [4000, 0], [4000, 4000], [0, 4000]], offset: 450 });
    p.add({ kind: 'topo', points: [[-10000, -10000, 100], [10000, -10000, 100], [10000, 10000, 700], [-10000, 10000, 700]] });
    expect(surfaceZ(p.doc, 'slab', [1000, 1000], l1.id)).toBe((l1.elevation || 0) + 450);
    expect(surfaceZ(p.doc, 'slab', [9000, 1000], l1.id)).toBe(null);
    expect(surfaceZ(p.doc, 'mesh', [0, 0], l1.id)).toBeCloseTo(400, 6);
    const comp = { kind: 'component', at: [1000, 1000], levelId: l1.id };
    expect(gravityPatch(p.doc, 'slab', comp)).toEqual({ offset: 450 });
    expect(gravityPatch(p.doc, 'slab', { kind: 'column', at: [1000, 1000], levelId: l1.id })).toEqual({ baseOffset: 450 });
    expect(gravityPatch(p.doc, 'off', comp)).toBe(null);
  });
});
