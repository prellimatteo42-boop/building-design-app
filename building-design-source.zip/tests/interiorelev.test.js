import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { interiorElevations } from '../src/core/interiorelev.js';
import { viewFrame, viewClip } from '../src/core/elevation.js';

describe('interior elevations', () => {
  it('look at each wall of a room from inside, cropped to the room', () => {
    const p = project();
    const room = p.add({ kind: 'room', levelId: p.L1.id, at: [2000, 1500], name: 'Kitchen', number: '3' });
    // A 4 x 3 m room (clockwise outline on purpose).
    const region = { outer: [[0, 0], [0, 3000], [4000, 3000], [4000, 0]] };
    const views = interiorElevations(p.doc, room, region, 50);
    expect(views.map((v) => v.name).sort()).toEqual(['Kitchen 3 - East', 'Kitchen 3 - North', 'Kitchen 3 - South', 'Kitchen 3 - West']);
    const north = views.find((v) => v.name.endsWith('North'));
    const f = viewFrame(north);
    // Looking north at the wall at y = 3000 from 1000 inside, across the 4 m width.
    expect(f.look[1]).toBeCloseTo(1, 9);
    expect(north.origin[1]).toBeCloseTo(2000, 6);
    expect(f.u1 - f.u0).toBeCloseTo(4040, 6);
    expect(north.depth).toBeCloseTo(1250, 6);
    // Clipped to the level's height.
    expect(viewClip(f).length).toBe(6);
    expect(f.z0).toBeCloseTo(p.L1.elevation - 10, 6);
  });
});
