import { describe, it, expect } from 'vitest';
import { createProject } from '../src/core/template.js';
import { Scene } from '../src/core/scene.js';
import { wallAxis } from '../src/core/model.js';
import { project } from './helpers.js';
import { invertWallDirection, modifyReferenceLine, relinkHomeStory, unlockAll } from '../src/core/editextras.js';

function setup() {
  const doc = createProject({ system: 'metric' });
  const lv = doc.levels();
  let w;
  let d;
  doc.transact('t', () => {
    w = doc.add({ kind: 'wall', typeId: doc.all('wallType')[0].id, levelId: lv[0].id, a: [0, 0], b: [4000, 0], height: 3000, locationLine: 'exterior', pinned: true });
    d = doc.add({ kind: 'door', hostId: w.id, typeId: doc.all('doorType')[0].id, t: 1000, flipFacing: false, flipHand: false });
  });
  return { doc, lv, w, d };
}

describe('edit menu extras', () => {
  it('inverts a wall keeping the reference line and the door in place', () => {
    const { doc, w, d } = setup();
    doc.transact('i', () => invertWallDirection(doc, w.id));
    const x = doc.get(w.id);
    expect(x.a).toEqual([4000, 0]);
    expect(x.b).toEqual([0, 0]);
    expect(doc.get(d.id)).toMatchObject({ t: 3000, flipFacing: true, flipHand: true });
  });
  it('moves the reference line and keeps the wall body', () => {
    const { doc, w } = setup();
    const before = wallAxis(doc, doc.get(w.id));
    doc.transact('m', () => modifyReferenceLine(doc, w.id, 'interior'));
    const after = wallAxis(doc, doc.get(w.id));
    expect(doc.get(w.id).locationLine).toBe('interior');
    after.a.forEach((v, i) => expect(v).toBeCloseTo(before.a[i], 6));
    after.b.forEach((v, i) => expect(v).toBeCloseTo(before.b[i], 6));
    void Scene;
  });
  it('relinks to another story at the same height, and unlocks all', () => {
    const { doc, lv, w } = setup();
    if (lv.length < 2) return;
    doc.transact('r', () => relinkHomeStory(doc, w.id, lv[1].id));
    expect(doc.get(w.id).levelId).toBe(lv[1].id);
    expect(doc.get(w.id).baseOffset).toBe(lv[0].elevation - lv[1].elevation);
    let n;
    doc.transact('u', () => (n = unlockAll(doc)));
    expect(n).toBe(1);
    expect(doc.get(w.id).pinned).toBe(false);
  });
});

describe('reference line of a curved wall', () => {
  it('keeps the curved wall where it is', () => {
    const { doc } = setup();
    let w;
    doc.transact('a', () => (w = doc.add({ kind: 'wall', typeId: doc.all('wallType')[0].id, levelId: doc.levels()[0].id, a: [0, 0], b: [4000, 0], arc: Math.PI / 3, height: 3000, locationLine: 'exterior' })));
    const before = wallAxis(doc, doc.get(w.id));
    doc.transact('m', () => modifyReferenceLine(doc, w.id, 'center'));
    const after = wallAxis(doc, doc.get(w.id));
    after.a.forEach((v, i) => expect(v).toBeCloseTo(before.a[i], 0));
    after.b.forEach((v, i) => expect(v).toBeCloseTo(before.b[i], 0));
  });
});

import { adjustToSlabs, deleteOnStories, duplicateIds } from '../src/core/editextras2.js';
describe('adjust to slabs, stories and duplicates', () => {
  it('brings a wall top to the underside of the slab above and its bottom to the slab below', () => {
    const doc = createProject({ system: 'metric' });
    const lv = doc.levels()[0];
    const ft = doc.all('floorType')[0];
    let w;
    let slab;
    doc.transact('t', () => {
      w = doc.add({ kind: 'wall', typeId: doc.all('wallType')[0].id, levelId: lv.id, a: [0, 0], b: [4000, 0], height: 2000, baseOffset: 0 });
      slab = doc.add({ kind: 'floor', typeId: ft.id, levelId: lv.id, offset: 2800, boundary: [[-1000, -1000], [5000, -1000], [5000, 1000], [-1000, 1000]] });
      doc.add({ kind: 'floor', typeId: ft.id, levelId: lv.id, offset: 150, boundary: [[-1000, -1000], [5000, -1000], [5000, 1000], [-1000, 1000]] });
    });
    const th = typeThicknessOf(doc, ft);
    doc.transact('a', () => adjustToSlabs(doc, [w.id], 'topToBottom'));
    expect(doc.get(w.id).height).toBe(Math.round(lv.elevation + 2800 - th - lv.elevation));
    doc.transact('b', () => adjustToSlabs(doc, [w.id], 'bottomToTop'));
    const x = doc.get(w.id);
    expect(x.baseOffset).toBe(150);
    expect(x.baseOffset + x.height).toBe(2800 - th);
    void slab;
  });
  it('deletes kinds on stories and finds duplicates', () => {
    const doc = createProject({ system: 'metric' });
    const lv = doc.levels()[0];
    doc.transact('t', () => {
      for (let i = 0; i < 2; i++) doc.add({ kind: 'wall', typeId: doc.all('wallType')[0].id, levelId: lv.id, a: [0, 0], b: [4000, 0], height: 3000 });
    });
    const scene = new Scene(doc);
    expect(duplicateIds(doc, scene)).toHaveLength(1);
    let n;
    doc.transact('d', () => (n = deleteOnStories(doc, [lv.id], ['wall'])));
    expect(n).toBe(2);
    expect(doc.all('wall')).toHaveLength(0);
  });
});
import { typeThickness } from '../src/core/catalog.js';
const typeThicknessOf = (doc, t) => typeThickness(t) || 200;

import { multiply } from '../src/core/multiply.js';
import { distributeXYMoves, alongLineMoves, alignToLineMoves } from '../src/core/distribute.js';
describe('multiply, special align and distribute', () => {
  it('copies in a matrix with an elevation step, by increment or distribute', () => {
    const doc = createProject({ system: 'metric' });
    let c;
    doc.transact('t', () => (c = doc.add({ kind: 'column', typeId: doc.all('columnType')[0]?.id, levelId: doc.levels()[0].id, at: [0, 0], baseOffset: 0 })));
    let ids;
    doc.transact('m', () => (ids = multiply(doc, [c.id], { d1: [1000, 0], n1: 3, d2: [0, 2000], n2: 2, dz: 100 })));
    expect(ids).toHaveLength(5);
    const at = ids.map((id) => doc.get(id).at.join(',')).sort();
    expect(at).toEqual(['0,2000', '1000,0', '1000,2000', '2000,0', '2000,2000'].sort());
    expect(Math.max(...ids.map((id) => doc.get(id).baseOffset))).toBe(500);
    doc.transact('d', () => (ids = multiply(doc, [c.id], { d1: [3000, 0], n1: 4, method: 'distribute' })));
    expect(ids.map((id) => doc.get(id).at[0]).sort((a, b) => a - b)).toEqual([1000, 2000, 3000]);
  });
  const box = (id, x, y) => ({ id, x0: x - 50, y0: y - 50, x1: x + 50, y1: y + 50 });
  it('distributes along XY and along a line, and aligns to a line', () => {
    const m = distributeXYMoves([box('a', 0, 0), box('b', 900, 100), box('c', 3000, 3000)]);
    expect(m.find((x) => x.id === 'b').d.map(Math.round)).toEqual([600, 1400]);
    const l = alongLineMoves([box('a', 0, 0), box('b', 500, 0)], [0, 1000], [0, 3000], { by: 'spacing', spacing: 500 });
    expect(l.map((x) => x.d)).toEqual([[0, 1000], [-500, 1500]]);
    const al = alignToLineMoves([box('a', 300, 700)], [0, 0], [1000, 0]);
    expect(al[0].d.map((v) => Math.round(v) + 0)).toEqual([0, -700]);
  });
});

import { modelCheckReport, reportCSV, reportMarkdown } from '../src/core/modelcheck.js';
describe('model check report', () => {
  it('gathers every check and exports it', () => {
    const doc = createProject({ system: 'metric' });
    const lv = doc.levels()[0];
    doc.transact('t', () => {
      for (let i = 0; i < 2; i++) doc.add({ kind: 'wall', typeId: doc.all('wallType')[0].id, levelId: lv.id, a: [0, 0], b: [4000, 0], height: 3000 });
      doc.add({ kind: 'pipe', levelId: lv.id, a: [0, 0], b: [3000, 0], offset: 500, system: 'sanitary', typeId: doc.all('pipeType')[0]?.id });
    });
    const r = modelCheckReport(doc, new Scene(doc), { date: new Date('2026-11-07') });
    expect(r.sections.map((s) => s.id)).toEqual(['physical', 'mep', 'analytical']);
    expect(r.sections[0].items.some((x) => x.check === 'duplicate')).toBe(true);
    expect(r.sections[1].items.some((x) => x.check === 'fall')).toBe(true);
    expect(reportCSV(r).split('\n')[0]).toBe('Section,Check,Message,Elements');
    expect(reportMarkdown(r, 'Test')).toContain('## MEP Model Quality');
  });
});

describe('multiply mirror and spread', () => {
  it('spreads copies at a spacing along a path', async () => {
    const { multiply, spreadStep } = await import('../src/core/multiply.js');
    expect(spreadStep([5000, 0], 1200).n).toBe(5);
    const p = project();
    const w = p.wall([0, 0], [0, 1000]);
    let ids;
    p.doc.transact('Spread', () => (ids = multiply(p.doc, [w.id], { d1: [5000, 0], method: 'spread', spacing: 1200 })));
    expect(ids).toHaveLength(4);
    expect(p.doc.get(ids[3]).a[0]).toBeCloseTo(4800);
  });
  it('mirrors copies across an axis and on', async () => {
    const { multiplyMirror } = await import('../src/core/multiply.js');
    const p = project();
    // A wall from x 0 to 1000; axis at x = 1500: the selection's centre is 1000 from it.
    const w = p.wall([0, 0], [1000, 0]);
    let ids;
    p.doc.transact('Mirror', () => (ids = multiplyMirror(p.doc, [w.id], [1500, -1000], [1500, 1000], { n: 3 })));
    expect(ids).toHaveLength(2);
    const [m1, m2] = ids.map((id) => p.doc.get(id));
    // First: mirrored (2000..3000, reversed); second: moved on by twice the distance twice (4000..5000).
    expect([m1.a[0], m1.b[0]].sort((x, y) => x - y)).toEqual([2000, 3000]);
    expect(m1.a[0]).toBeCloseTo(3000);
    expect(m2.a[0]).toBeCloseTo(4000);
    expect(m2.b[0]).toBeCloseTo(5000);
  });
});
