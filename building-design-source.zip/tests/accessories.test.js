import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { WallSolver } from '../src/core/walls.js';
import { RoomSolver } from '../src/core/rooms.js';
import { build3D } from '../src/core/build3d.js';
import { outerSide, moldingsGeometry, batteredGeometry, framingGeometry, framingList } from '../src/core/cladding.js';
import { floorGeometry, footingGeometry, roofAccessoryGeometry, roomAccessoryGeometry } from '../src/core/accessories.js';
import { curveMorphEdges } from '../src/core/morphops.js';
import { deleteElements } from '../src/core/ops.js';

const ctxOf = (doc) => {
  const walls = new WallSolver(doc);
  return { doc, walls, rooms: new RoomSolver(doc, walls), material: (id) => doc.get(id) };
};
const zSpan = (m) => {
  let lo = Infinity;
  let hi = -Infinity;
  for (let i = 2; i < m.pos.length; i += 3) (lo = Math.min(lo, m.pos[i])), (hi = Math.max(hi, m.pos[i]));
  return [lo, hi];
};

describe('Wall accessories: moldings, battered wall, framing', () => {
  const room = () => {
    const p = project();
    const ws = p.box(0, 0, 5000, 4000);
    const type = p.doc.all('windowType')[0];
    const dt = p.doc.all('doorType')[0];
    p.add({ kind: 'window', typeId: type.id, hostId: ws[0].id, t: 1500, width: 1200, sill: 900 });
    p.add({ kind: 'door', typeId: dt.id, hostId: ws[0].id, t: 3800, width: 900 });
    return { p, ws };
  };

  it('runs moldings round the inside, stopping at the door and window, with panels between', () => {
    const { p, ws } = room();
    const w = p.doc.get(ws[0].id);
    const inside = outerSide(p.doc, w) === 'exterior' ? 'interior' : 'exterior';
    const m = p.add({ kind: 'wallCladding', wallId: w.id, side: inside, accessory: 'moldings' });
    const g = moldingsGeometry(p.doc, p.doc.get(m.id));
    const base = g.runs.filter((r) => r.role === 'base');
    const chair = g.runs.filter((r) => r.role === 'chair');
    const crown = g.runs.filter((r) => r.role === 'crown');
    // The base molding breaks at the door only, the chair rail at the window (and door), the crown runs on.
    expect(base.length).toBe(2);
    expect(chair.length).toBe(3);
    expect(crown.length).toBe(1);
    // Inside corners: the face is shorter than the wall's axis (the side walls' faces stop it).
    const half = 100;
    expect(crown[0].t0).toBeCloseTo(half, 0);
    expect(crown[0].t1).toBeCloseTo(5000 - half, 0);
    expect(g.panels.length).toBeGreaterThan(3);
    // Under the window there is wainscot, at the door none.
    expect(g.panels.some(([t0, t1]) => t0 < 1500 && t1 > 1500)).toBe(true);
    for (const [t0, t1] of g.panels) expect(t1 <= 3800 - 450 || t0 >= 3800 + 450).toBe(true);
    expect(build3D(ctxOf(p.doc), p.doc.get(m.id)).pos.length).toBeGreaterThan(0);
  });

  it('builds a battered veneer thicker at the bottom', () => {
    const { p, ws } = room();
    const w = p.doc.get(ws[1].id);
    const v = p.add({ kind: 'wallCladding', wallId: w.id, side: outerSide(p.doc, w), accessory: 'battered', thickBottom: 200, thickTop: 50, extendBelow: 300 });
    const g = batteredGeometry(p.doc, p.doc.get(v.id));
    expect(g.z0).toBe(-300);
    expect(g.depth(g.z0)).toBe(200);
    expect(g.depth(g.z1)).toBe(50);
  });

  it('frames the wall: studs at the spacing, kings, jacks, header, sill and cripples at the window', () => {
    const { p, ws } = room();
    const w = p.doc.get(ws[0].id);
    const f = p.add({ kind: 'wallCladding', wallId: w.id, side: 'exterior', accessory: 'framing', spacing: 400 });
    const g = framingGeometry(p.doc, p.doc.get(f.id));
    const roles = (r) => g.members.filter((m) => m.role === r);
    expect(roles('header').length).toBe(2);
    expect(roles('sill').length).toBe(1);
    expect(roles('king stud').length).toBe(4);
    expect(roles('jack stud').length).toBe(4);
    expect(roles('cripple').length).toBeGreaterThan(2);
    expect(roles('top plate').length).toBe(2);
    expect(roles('corner stud').length).toBe(2);
    // No common stud stands in an opening.
    for (const s of roles('stud')) expect(s.t1 <= 900 - 45 || (s.t0 >= 2100 + 45 && s.t1 <= 3350 - 45) || s.t0 >= 4250 + 45).toBe(true);
    // Inside the wall.
    expect(g.o0).toBeCloseTo(-170, 3);
    expect(g.o1).toBeCloseTo(-30, 3);
    const list = framingList(g);
    expect(list.find((r) => r.role === 'bottom plate').length).toBe(5000);
  });
});

describe('Slab accessories', () => {
  const slab = () => {
    const p = project();
    const s = p.add({ kind: 'floor', typeId: p.doc.all('floorType')[0].id, levelId: p.L1.id, boundary: [[0, 0], [6000, 0], [6000, 4000], [0, 4000]], offset: 0 });
    return { p, s };
  };

  it('puts joists across the shorter span, under the slab', () => {
    const { p, s } = slab();
    const a = p.add({ kind: 'slabAccessory', slabId: s.id, accessory: 'floor', joistSpacing: 400 });
    const g = floorGeometry(p.doc, p.doc.get(a.id));
    expect(g.joists.length).toBeGreaterThan(12);
    for (const j of g.joists) {
      // Running in y (the 4000 side), inside the rim joist.
      expect(Math.abs(j.a[0] - j.b[0])).toBeLessThan(1e-6);
      expect(Math.abs(j.b[1] - j.a[1])).toBeCloseTo(4000 - 100, 3);
    }
    const m = build3D(ctxOf(p.doc), p.doc.get(a.id));
    const [lo, hi] = zSpan(m);
    expect(hi).toBeCloseTo(g.z1, 3);
    expect(hi - lo).toBeCloseTo(220, 3);
  });

  it('puts a stem wall and footing under the edge, with a sill plate', () => {
    const { p, s } = slab();
    const a = p.add({ kind: 'slabAccessory', slabId: s.id, accessory: 'footing' });
    const g = footingGeometry(p.doc, p.doc.get(a.id));
    expect(g.stem.z1 - g.stem.z0).toBe(600);
    expect(g.sill.z1 - g.sill.z0).toBe(45);
    expect(g.footing.z1).toBe(g.stem.z0);
    // The footing spreads 200 either side of the stem wall.
    const xs = g.footing.outer.map((q) => q[0]);
    expect(Math.min(...xs)).toBeCloseTo(-200, 3);
    expect(build3D(ctxOf(p.doc), p.doc.get(a.id)).pos.length).toBeGreaterThan(0);
  });
});

describe('Roof accessories', () => {
  const roof = () => {
    const p = project();
    const r = p.add({ kind: 'roof', typeId: p.doc.all('roofType')[0].id, levelId: p.L2.id, boundary: [[0, 0], [8000, 0], [8000, 6000], [0, 6000]], slopes: [30, 30, 30, 30], baseOffset: 0 });
    return { p, r };
  };

  it('sheathes a hipped roof tile by tile, with caps on the ridge and hips', () => {
    const { p, r } = roof();
    const a = p.add({ kind: 'roofAccessory', roofId: r.id, accessory: 'surfacer', sheathing: 'tiles' });
    const g = roofAccessoryGeometry(p.doc, p.doc.get(a.id));
    expect(g.pieces.length).toBeGreaterThan(300);
    expect(g.caps.length).toBe(5);
    const m = build3D(ctxOf(p.doc), p.doc.get(a.id));
    const roofMesh = build3D(ctxOf(p.doc), p.doc.get(r.id));
    // The tiles sit on the roof, the caps over its ridge.
    expect(zSpan(m)[1]).toBeGreaterThan(zSpan(roofMesh)[1]);
  });

  it('runs standing-seam sheets and a wood ceiling under it', () => {
    const { p, r } = roof();
    const metal = roofAccessoryGeometry(p.doc, p.add({ kind: 'roofAccessory', roofId: r.id, accessory: 'surfacer', sheathing: 'metal' }));
    expect(metal.pieces.length).toBeGreaterThan(10);
    expect(metal.caps.length).toBe(5);
    const ceiling = p.add({ kind: 'roofAccessory', roofId: r.id, accessory: 'woodCeiling' });
    const gc = roofAccessoryGeometry(p.doc, p.doc.get(ceiling.id));
    expect(gc.caps.length).toBe(0);
    const m = build3D(ctxOf(p.doc), p.doc.get(ceiling.id));
    const roofMesh = build3D(ctxOf(p.doc), p.doc.get(r.id));
    expect(zSpan(m)[0]).toBeLessThan(zSpan(roofMesh)[0]);
  });

  it('goes with its roof when the roof is deleted', () => {
    const { p, r } = roof();
    const a = p.add({ kind: 'roofAccessory', roofId: r.id });
    p.doc.transact('del', () => deleteElements(p.doc, [r.id]));
    expect(p.doc.get(a.id)).toBeFalsy();
  });
});

describe('Room accessories', () => {
  it('runs a skirting round the room, broken at its door', () => {
    const p = project();
    const ws = p.box(0, 0, 5000, 4000);
    p.add({ kind: 'door', typeId: p.doc.all('doorType')[0].id, hostId: ws[0].id, t: 2500, width: 900 });
    const room = p.add({ kind: 'room', levelId: p.L1.id, at: [2500, 2000], name: 'Living' });
    const a = p.add({ kind: 'roomAccessory', roomId: room.id, skirtingHeight: 100, skirtingDepth: 15 });
    const ctx = ctxOf(p.doc);
    const g = roomAccessoryGeometry(ctx, p.doc.get(a.id));
    expect(g.runs.length).toBe(5);
    const len = g.runs.reduce((s, r) => s + Math.hypot(r.b[0] - r.a[0], r.b[1] - r.a[1]), 0);
    expect(len).toBeCloseTo(2 * (4800 + 3800) - 900, 0);
    const m = build3D(ctx, p.doc.get(a.id));
    expect(zSpan(m)).toEqual([0, 100]);
  });
});

describe('Curve & Merge Edges', () => {
  it('turns a prism morph\'s straight edges into one smooth curve through its corners', () => {
    const el = { boundary: [[0, 0], [2000, 0], [2000, 2000], [0, 2000]], heights: [1000, 1000, 2000, 2000] };
    const patch = curveMorphEdges(el, 8);
    expect(patch.boundary.length).toBe(32);
    expect(patch.curved).toBe(true);
    // It passes through the corners, with their heights.
    expect(patch.boundary[8]).toEqual([2000, 0]);
    expect(patch.heights[16]).toBeCloseTo(2000, 6);
    // Between corners it bulges out of the square.
    const mid = patch.boundary[4];
    expect(mid[1]).toBeLessThan(0);
  });
});
