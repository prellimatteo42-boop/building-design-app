import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { imagePointToModel, modelPointToImage, calibrateImagePatch, tidyWalls, buildFloorPlan, wallTypeFor } from '../src/core/floorplan.js';
import { Scene } from '../src/core/scene.js';
import { typeThickness } from '../src/core/catalog.js';

describe('image underlays', () => {
  const img = { kind: 'image', at: [1000, 2000], w: 10000, h: 5000, rotation: 0, px: [1000, 500] };
  it('map pixels from the top left to model millimetres and back', () => {
    expect(imagePointToModel(img, [0, 0])).toEqual([1000, 7000]);
    expect(imagePointToModel(img, [1000, 500])).toEqual([11000, 2000]);
    expect(imagePointToModel(img, [250, 250])).toEqual([3500, 4500]);
    const q = modelPointToImage({ ...img, rotation: 30 }, imagePointToModel({ ...img, rotation: 30 }, [123, 456]));
    expect(q[0]).toBeCloseTo(123, 6);
    expect(q[1]).toBeCloseTo(456, 6);
  });

  it('calibrate from two points and their true distance, keeping the first in place', () => {
    const patch = calibrateImagePatch(img, [100, 100], [300, 100], 4000);
    const next = { ...img, ...patch };
    expect(imagePointToModel(next, [100, 100])).toEqual(imagePointToModel(img, [100, 100]));
    const a = imagePointToModel(next, [100, 100]);
    const b = imagePointToModel(next, [300, 100]);
    expect(Math.hypot(b[0] - a[0], b[1] - a[1])).toBeCloseTo(4000, 6);
    expect(calibrateImagePatch(img, [1, 1], [1, 1], 1000)).toBeNull();
  });
});

describe('tidying traced walls', () => {
  it('squares near-orthogonal walls and makes ends that nearly meet meet', () => {
    const ws = tidyWalls(
      [
        { a: [0, 0], b: [6000, 40] },
        { a: [6080, -60], b: [6000, 4000] },
        { a: [6050, 4050], b: [0, 4000] },
        { a: [30, 4000], b: [0, 50] },
      ],
      { tol: 150 },
    );
    expect(ws).toHaveLength(4);
    for (let i = 0; i < 4; i++) expect(ws[i].b).toEqual(ws[(i + 1) % 4].a);
    expect(ws[0].a[1]).toBe(ws[0].b[1]);
    expect(ws[1].a[0]).toBe(ws[1].b[0]);
  });

  it('puts an end that stops short of a wall onto it, and drops scraps', () => {
    const ws = tidyWalls(
      [
        { a: [0, 0], b: [8000, 0] },
        { a: [3000, 90], b: [3000, 3000] },
        { a: [5000, 5000], b: [5050, 5000] },
      ],
      { tol: 150 },
    );
    expect(ws).toHaveLength(2);
    expect(ws[1].a).toEqual([3000, 0]);
  });
});

describe('building a traced plan', () => {
  it('makes joined walls of the nearest types, hosted openings and enclosed rooms', () => {
    const { doc, L1 } = project();
    let out;
    doc.transact('trace', () => {
      out = buildFloorPlan(
        doc,
        {
          walls: [
            { a: [0, 0], b: [8000, 0], thickness: 300, exterior: true },
            { a: [8000, 0], b: [8000, 6000], thickness: 300, exterior: true },
            { a: [8000, 6000], b: [0, 6000], thickness: 300, exterior: true },
            { a: [0, 6000], b: [0, 0], thickness: 300, exterior: true },
            { a: [4000, 60], b: [4000, 6000], thickness: 120, exterior: false },
          ],
          doors: [{ at: [2000, 20], width: 900 }, { at: [4010, 3000], width: 800 }],
          windows: [{ at: [6000, 6000], width: 1500, sill: 900 }, { at: [20000, 0], width: 900 }],
          rooms: [{ at: [2000, 3000], name: 'Living' }, { at: [6000, 3000], name: 'Bedroom' }],
        },
        { levelId: L1.id },
      );
    });
    expect(out.walls).toHaveLength(5);
    expect(out.doors).toHaveLength(2);
    expect(out.windows).toHaveLength(1);
    expect(out.skipped.some((s) => /no wall near/.test(s))).toBe(true);
    const inner = doc.get(out.walls[4]);
    expect(inner.a).toEqual([4000, 0]);
    expect(doc.get(inner.typeId).function).toBe('interior');
    const door2 = doc.get(out.doors[1]);
    expect(door2.hostId).toBe(inner.id);
    expect(door2.t).toBeCloseTo(3000, 0);
    const win = doc.get(out.windows[0]);
    expect(win.sill).toBe(900);
    expect(win.mark).toBe('W1');
    const scene = new Scene(doc);
    const areas = out.rooms.map((id) => scene.rooms.room(doc.get(id))?.area / 1e6);
    expect(areas[0]).toBeGreaterThan(10);
    expect(areas[1]).toBeGreaterThan(10);
    expect(doc.get(out.rooms[1]).number).toBe(String(+doc.get(out.rooms[0]).number + 1));
  });

  it('picks the wall type nearest a thickness', () => {
    const { doc } = project();
    const t = wallTypeFor(doc, 100, false);
    for (const o of doc.all('wallType').filter((x) => x.function === 'interior' && x.layers?.length)) expect(Math.abs(typeThickness(t) - 100)).toBeLessThanOrEqual(Math.abs(typeThickness(o) - 100));
  });
});
