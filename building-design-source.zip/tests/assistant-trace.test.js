import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { runTool, resultContent, placeUnderlay, toolSchemas } from '../src/assistant/tools.js';
import { Scene } from '../src/core/scene.js';
import { typeThickness } from '../src/core/catalog.js';

function fakeApp() {
  const p = project();
  const plan = p.doc.all('plan').find((v) => v.levelId === p.L1.id);
  const app = { doc: p.doc, activeView: plan, scene: new Scene(p.doc), commit: (label, fn) => p.doc.transact(label, fn), showElements() {}, openView() {} };
  return { ...p, app, plan };
}

describe('assistant floor plan tools', () => {
  it('place a picture, calibrate it and trace a plan in its pixels', async () => {
    const { app, doc, plan } = fakeApp();
    const img = placeUnderlay(app, { src: 'data:image/png;base64,AAAA', name: 'scan.png', px: [1000, 800] });
    expect(img.viewId).toBe(plan.id);
    // 100 px on the drawing are 1 m.
    const cal = await runTool(app, 'calibrate_image', { image_id: img.id, from: [100, 700], to: [600, 700], distance: 5000 });
    expect(cal.mmPerPixel).toBeCloseTo(10, 6);
    const out = await runTool(app, 'trace_floor_plan', {
      image_id: img.id,
      walls: [
        { from: [100, 700], to: [700, 700], thickness: 300, exterior: true },
        { from: [700, 700], to: [700, 200], thickness: 300, exterior: true },
        { from: [700, 200], to: [100, 200], thickness: 300, exterior: true },
        { from: [100, 200], to: [100, 700], thickness: 300, exterior: true },
      ],
      doors: [{ at: [400, 700], width: 900 }],
      windows: [{ at: [700, 450], width: 1200 }],
      rooms: [{ at: [400, 450], name: 'Studio' }],
    });
    expect(out).toMatchObject({ walls: 4, doors: 1, windows: 1, skipped: [] });
    expect(out.rooms[0].name).toBe('Studio');
    const w = doc.all('wall');
    const t = typeThickness(doc.get(w[0].typeId));
    expect(parseFloat(out.rooms[0].area)).toBeCloseTo(((6000 - t) * (5000 - t)) / 1e6, 1);
    const xs = w.flatMap((x) => [x.a[0], x.b[0]]);
    expect(Math.max(...xs) - Math.min(...xs)).toBeCloseTo(6000, 3);
  });

  it('trace in millimetres without an image, and say what was left out', async () => {
    const { app } = fakeApp();
    const out = await runTool(app, 'trace_floor_plan', { walls: [{ from: [0, 0], to: [4000, 0] }], doors: [{ at: [9000, 9000], width: 800 }] });
    expect(out.walls).toBe(1);
    expect(out.skipped[0]).toMatch(/no wall near/);
    expect((await runTool(app, 'calibrate_image', { image_id: 'nope', from: [0, 0], to: [1, 1], distance: 1 })).error).toBeTruthy();
  });

  it('send pictures back as image content and keep schemas valid', () => {
    const content = resultContent({ ok: 1, _image: { media_type: 'image/jpeg', data: 'QUJD' } });
    expect(content[1]).toEqual({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: 'QUJD' } });
    expect(resultContent({ ok: 1 })).toBe('{"ok":1}');
    for (const t of toolSchemas()) expect(t.input_schema.type).toBe('object');
  });
});

describe('PDF pages for the assistant', () => {
  it('take their scale from the paper size and a 1:N drawing scale', async () => {
    const { app } = fakeApp();
    const img = placeUnderlay(app, { src: 'data:image/png;base64,AAAA', name: 'plan.pdf - page 1', px: [2480, 1754], pageMm: [420, 297] });
    const r = await runTool(app, 'calibrate_image', { image_id: img.id, scale: 100 });
    expect(r).toMatchObject({ calibrated: true, scale: '1:100' });
    expect(app.doc.get(img.id).w).toBeCloseTo(42000, 6);
    const photo = placeUnderlay(app, { src: 'data:image/png;base64,AAAA', name: 'photo', px: [100, 100] });
    expect((await runTool(app, 'calibrate_image', { image_id: photo.id, scale: 100 })).error).toMatch(/PDF/);
    expect((await runTool(app, 'list_images', {}))[0].pdfPageMm).toEqual([420, 297]);
  });
});

describe('converting lines with the assistant', () => {
  it('makes walls from face lines in the plan, only inside the box', async () => {
    const { app, doc, plan } = fakeApp();
    const add = (a, b) => doc.transact('l', () => doc.add({ kind: 'detailLine', viewId: plan.id, a, b, style: 'thin' }));
    add([0, 0], [6000, 0]);
    add([0, 300], [6000, 300]);
    add([20000, 0], [26000, 0]);
    const r = await runTool(app, 'convert_lines', { to: 'wallPairs', within: [-100, -100, 7000, 1000] });
    expect(r.made).toBe(1);
    expect(doc.all('detailLine')).toHaveLength(1);
    expect(doc.all('wall')[0].a[1]).toBeCloseTo(150, 6);
  });
});

describe('assistant tools like Archicad\'s MCP server', () => {
  const withCommands = (app) => {
    const defs = { roofFraming: { label: 'Roof Framing (RoofMaker)', desc: 'Timber rafters under the selected roof', search: 'roofmaker rafter', enabled: () => true }, save: { label: 'Save' } };
    const ran = [];
    return Object.assign(app, { selection: new Set(), commandNames: () => Object.keys(defs), commandDef: (n) => defs[n], run: (n) => ran.push(n), ran });
  };

  it('find and run commands, but not those that send out or replace the project', async () => {
    const { app } = fakeApp();
    withCommands(app);
    const found = await runTool(app, 'search_commands', { query: 'rafter' });
    expect(found.commands.map((c) => c.command)).toEqual(['roofFraming']);
    expect(await runTool(app, 'run_command', { command: 'roofFraming' })).toEqual({ ran: 'Roof Framing (RoofMaker)' });
    expect((await runTool(app, 'run_command', { command: 'save' })).error).toBeTruthy();
    expect(app.ran).toEqual(['roofFraming']);
  });

  it('classify, keep favorites, switch layers and set a plan view range and phase', async () => {
    const { app, doc, plan } = fakeApp();
    withCommands(app);
    const w = doc.all('wall')[0] || app.commit('w', () => doc.add({ kind: 'wall', typeId: 'wt-generic', levelId: plan.levelId, a: [0, 0], b: [4000, 0], height: 3000 }));
    const wall = doc.all('wall')[0];
    app.selection = new Set([wall.id]);
    const items = await runTool(app, 'classify_elements', { query: 'wall' });
    expect(items.items.length).toBeGreaterThan(0);
    const code = items.items[0].code;
    expect((await runTool(app, 'classify_elements', { code })).classified).toBe(1);
    expect(Object.values(doc.get(wall.id).classes)).toEqual([code]);
    expect((await runTool(app, 'favorites', { action: 'save', name: 'Thick wall' })).saved).toBe('Thick wall');
    expect((await runTool(app, 'favorites', { action: 'list', kind: 'wall' })).favorites[0].name).toBe('Thick wall');
    expect((await runTool(app, 'favorites', { action: 'apply', name: 'thick wall' })).elements).toBe(1);
    const lay = await runTool(app, 'layers', { action: 'set', layer: 'walls', hidden: true });
    expect(lay.hidden).toBe(true);
    expect((await runTool(app, 'layers', { action: 'store_combination', combination: 'No walls' })).stored).toBe('No walls');
    expect((await runTool(app, 'layers', { action: 'apply_combination', combination: 'no walls' })).combination).toBe('No walls');
    const range = await runTool(app, 'set_view_range', { cut_height: 1500, view_depth: -300 });
    expect(range).toMatchObject({ cut_height: 1500, view_depth: -300 });
    const ph = await runTool(app, 'set_view_phase', { filter: 'new' });
    expect(ph.filter).toBe('new');
    expect(w || true).toBeTruthy();
  });
});
