import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { isLamp, kelvinColor, lampRange, lampEmitter, lampSources, lampLightAt, MAX_LAMPS } from '../src/core/lamps.js';
import { worksetParams } from '../src/core/props.js';

const lamp = (p, typeId, at, extra = {}) => p.add({ kind: 'component', typeId, levelId: p.L1.id, at, rotation: 0, ...extra });

describe('lamps', () => {
  it('knows lighting fixtures', () => {
    const p = project();
    const d = lamp(p, 'cpt-downlight', [0, 0]);
    expect(isLamp(p.doc, d)).toBe(true);
    const chair = p.doc.all('componentType').find((t) => t.category !== 'lighting');
    expect(isLamp(p.doc, p.add({ kind: 'component', typeId: chair.id, levelId: p.L1.id, at: [0, 0] }))).toBe(false);
  });

  it('turns colour temperature into colour', () => {
    const warm = kelvinColor(2700);
    expect(warm[0]).toBe(1);
    expect(warm[2]).toBeLessThan(warm[1]);
    const cool = kelvinColor(6500);
    expect(cool[2]).toBeGreaterThan(0.95);
    expect(kelvinColor(10000)[2]).toBe(1);
  });

  it('reaches farther with more flux', () => {
    expect(lampRange({})).toBe(4000);
    expect(lampRange({ lightLumens: 3200 })).toBe(8000);
    expect(lampRange({ lightRange: 2500 })).toBe(2500);
  });

  it('emits under a hung fixture and near the top of a standing one', () => {
    const b = { min: [0, 0, 2600], max: [100, 100, 2700] };
    expect(lampEmitter({ offset: 2600 }, b)).toEqual([50, 50, 2570]);
    const f = { min: [0, 0, 0], max: [400, 400, 1600] };
    expect(lampEmitter({ offset: 0 }, f)[2]).toBe(1450);
    expect(lampEmitter({ offset: 0, lightZ: 900 }, f)[2]).toBe(900);
  });

  it('lists the lit lamps nearest the camera first, at most sixteen', () => {
    const p = project();
    const scene = new Scene(p.doc);
    for (let i = 0; i < 20; i++) lamp(p, 'cpt-downlight', [i * 1000, 0]);
    const off = lamp(p, 'cpt-downlight', [-1000, 0], { lightOn: false });
    const ls = lampSources(p.doc, (el) => scene.mesh(el)?.bounds, { eye: [0, 0, 1500] });
    expect(ls).toHaveLength(MAX_LAMPS);
    expect(ls.some((l) => l.id === off.id)).toBe(false);
    expect(ls[0].pos[0]).toBeLessThan(ls.at(-1).pos[0]);
    expect(ls[0].pos[2]).toBeLessThan(2700);
    expect(ls[0].color[0]).toBe(1);
  });

  it('lights a floor under the lamp and nothing past its reach', () => {
    const l = [{ pos: [0, 0, 2500], color: [1, 1, 1], range: 4000 }];
    const under = lampLightAt(l, [0, 0, 0], [0, 0, 1]);
    const aside = lampLightAt(l, [2000, 0, 0], [0, 0, 1]);
    expect(under[0]).toBeGreaterThan(aside[0]);
    expect(aside[0]).toBeGreaterThan(0);
    expect(lampLightAt(l, [5000, 0, 0], [0, 0, 1])[0]).toBe(0);
    // Facing away: no light.
    expect(lampLightAt(l, [0, 0, 0], [0, 0, -1])[0]).toBe(0);
  });

  it('shines a downlight down more than sideways', () => {
    const l = { pos: [0, 0, 2500], color: [1, 1, 1], range: 6000 };
    const floor = lampLightAt([{ ...l, down: 1 }], [0, 0, 0], [0, 0, 1])[0];
    const wall = lampLightAt([{ ...l, down: 1 }], [2500, 0, 2500], [-1, 0, 0])[0];
    const wallRound = lampLightAt([l], [2500, 0, 2500], [-1, 0, 0])[0];
    expect(floor).toBeGreaterThan(lampLightAt([l], [0, 0, 0], [0, 0, 1])[0]);
    expect(wall).toBeLessThan(wallRound);
  });

  it('shows light settings on lamps only', () => {
    const p = project();
    const d = lamp(p, 'cpt-downlight', [0, 0]);
    const keys = worksetParams(p.doc, p.doc.get(d.id)).map((x) => x.key);
    expect(keys).toContain('lightLumens');
    expect(keys).toContain('lightKelvin');
    const chair = p.doc.all('componentType').find((t) => t.category !== 'lighting');
    const c = p.add({ kind: 'component', typeId: chair.id, levelId: p.L1.id, at: [0, 0] });
    expect(worksetParams(p.doc, p.doc.get(c.id)).map((x) => x.key)).not.toContain('lightLumens');
  });
});
