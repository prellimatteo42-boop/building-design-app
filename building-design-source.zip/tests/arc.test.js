import { describe, it, expect } from 'vitest';
import { arcOf, arcPoint, arcParam, arcTangent, sweepThrough, offsetArc } from '../src/core/arc.js';

describe('arcs', () => {
  it('a half circle from (0,0) to (2000,0) turning right goes over the top', () => {
    const arc = arcOf([0, 0], [2000, 0], -Math.PI);
    expect(arc.c[0]).toBeCloseTo(1000, 6);
    expect(arc.c[1]).toBeCloseTo(0, 6);
    expect(arc.r).toBeCloseTo(1000, 6);
    expect(arc.length).toBeCloseTo(1000 * Math.PI, 6);
    const top = arcPoint(arc, arc.length / 2);
    expect(top[0]).toBeCloseTo(1000, 6);
    expect(top[1]).toBeCloseTo(1000, 6);
    expect(arcTangent(arc, 0)[1]).toBeCloseTo(1, 6);
    expect(arcParam(arc, [1000, 5000])).toBeCloseTo(arc.length / 2, 6);
    // Left of travel over the top (clockwise) is outward: a larger radius.
    expect(arcPoint(arc, arc.length / 2, 100)[1]).toBeCloseTo(1100, 6);
    expect(offsetArc(arc, 100).r).toBeCloseTo(1100, 6);
  });

  it('finds the sweep through three points', () => {
    expect(sweepThrough([0, 0], [1000, 1000], [2000, 0])).toBeCloseTo(-Math.PI, 6);
    expect(sweepThrough([0, 0], [1000, -1000], [2000, 0])).toBeCloseTo(Math.PI, 6);
    expect(sweepThrough([0, 0], [1000, 0], [2000, 0])).toBe(0);
    expect(arcOf([0, 0], [2000, 0], 0)).toBe(null);
  });
});
