import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { classOf, autoClass, classTree, parseClassCSV, classLabel } from '../src/core/classify.js';
import { worksetParams, paramPatch } from '../src/core/props.js';
import { findElements } from '../src/core/findselect.js';
import { resolveAutotext } from '../src/core/autotext.js';
import { writeIFC } from '../src/io/ifc.js';
import { Scene } from '../src/core/scene.js';

describe('classification', () => {
  it('gives elements the item of their kind or category, or the one chosen', () => {
    const { doc, wall, add, L1 } = project();
    const sys = doc.all('classSystem')[0];
    const w = wall([0, 0], [4000, 0]);
    expect(classLabel(classOf(doc, w, sys))).toBe('10.10 Wall');
    const c = add({ kind: 'component', typeId: 'cpt-toilet', levelId: L1.id, at: [1000, 1000], rotation: 0 });
    expect(classOf(doc, c, sys).name).toBe('Sanitary Terminal');
    const p = worksetParams(doc, w).find((x) => x.key === `class:${sys.id}`);
    expect(p.options({ doc, items: [w] })[0].label).toBe('Automatic: 10.10 Wall');
    doc.transact('set', () => doc.update(w.id, paramPatch(p, w, '10.11', { doc })));
    expect(classOf(doc, doc.get(w.id), sys).name).toBe('Curtain Wall');
    doc.transact('none', () => doc.update(w.id, paramPatch(p, doc.get(w.id), '-', { doc })));
    expect(classOf(doc, doc.get(w.id), sys)).toBeNull();
    doc.transact('auto', () => doc.update(w.id, paramPatch(p, doc.get(w.id), '', { doc })));
    expect(classOf(doc, doc.get(w.id), sys).code).toBe('10.10');
    expect(autoClass(doc, { kind: 'stair' }, sys).name).toBe('Stair');
  });

  it('list items as a tree and read systems from CSV', () => {
    const items = parseClassCSV('Code,Name\nEF,Elements/functions\nEF_25,Walls\nEF_25_10,Walls,,IfcWall\n"EF_30";"Roofs"');
    expect(items.map((i) => [i.code, i.parent])).toEqual([['EF', null], ['EF_25', 'EF'], ['EF_25_10', 'EF_25'], ['EF_30', 'EF']]);
    expect(items[2].ifc).toBe('IfcWall');
    const tree = classTree({ items });
    expect(tree.map((t) => t.depth)).toEqual([0, 1, 2, 1]);
  });

  it('find, label and export to IFC by classification', () => {
    const { doc, wall, add, L1 } = project();
    const sys = doc.all('classSystem')[0];
    const w1 = wall([0, 0], [4000, 0]);
    const w2 = wall([0, 3000], [4000, 3000]);
    doc.transact('cw', () => doc.update(w2.id, { classes: { [sys.id]: '10.11' } }));
    add({ kind: 'component', typeId: 'cpt-pendant', levelId: L1.id, at: [1000, 1000], rotation: 0 });
    expect(findElements(doc, [{ id: 'classification', value: `${sys.id}|10` }]).map((e) => e.id).sort()).toEqual([w1.id, w2.id].sort());
    expect(findElements(doc, [{ id: 'classification', value: `${sys.id}|10.11` }]).map((e) => e.id)).toEqual([w2.id]);
    const scene = new Scene(doc);
    expect(resolveAutotext({ doc, scene }, doc.get(w2.id), '{Classification}')).toBe('10.11 Curtain Wall');
    const ifc = writeIFC({ doc, scene });
    expect(ifc).toMatch(/IFCWALL\('/);
    expect(ifc).toMatch(/IFCCURTAINWALL\('/);
    expect(ifc).toMatch(/IFCLIGHTFIXTURE\('/);
    expect(ifc).toMatch(/IFCCLASSIFICATION\('Building Design'/);
    expect(ifc).toMatch(/IFCCLASSIFICATIONREFERENCE\(\$,'10.11','Curtain Wall'/);
    expect((ifc.match(/IFCRELASSOCIATESCLASSIFICATION/g) || []).length).toBe(3);
  });
});
