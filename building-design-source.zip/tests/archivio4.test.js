import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { Doc } from '../src/core/doc.js';
import { mergeOptions, mergeFromProject } from '../src/core/mergefile.js';
import { libraryReport, libraryOf } from '../src/core/libmanager.js';
import { connectorsFromSelection, connectorPoints, mepNetworks } from '../src/core/mepnet.js';
import { linkData } from '../src/core/links.js';
import { embedLink } from '../src/core/modules.js';

function source() {
  const p = project();
  p.wall([0, 0], [5000, 0]);
  p.wall([0, 0], [0, 4000], { levelId: p.L2.id });
  const plan = p.doc.all('plan').find((v) => v.levelId === p.L1.id);
  p.add({ kind: 'detailLine', viewId: plan.id, levelId: p.L1.id, a: [0, -500], b: [5000, -500] });
  p.add({ kind: 'drafting', name: 'Particolare 1', scale: 10 });
  p.add({ kind: 'material', name: 'Cotto antico', color: '#aa6644' });
  return p;
}

describe('Merge from File', () => {
  it('offers the stories with their elements', () => {
    const o = mergeOptions(source().doc);
    expect(o.levels.map((l) => l.count)).toEqual([1, 1]);
    expect(o.views.some((v) => v.name === 'Particolare 1')).toBe(true);
  });

  it('brings only the chosen story, its plan drawings, views and missing attributes', () => {
    const src = source().doc;
    const dst = project();
    const before = dst.doc.all('wall').length;
    let r;
    dst.doc.transact('m', () => (r = mergeFromProject(dst.doc, src, { levels: [src.levels()[0].id], views: true, attributes: true, offset: [10000, 0, 0] })));
    expect(r.elements).toBe(1);
    expect(dst.doc.all('wall').length).toBe(before + 1);
    expect(dst.doc.all('wall').at(-1).a[0]).toBe(10000);
    expect(r.annotations).toBe(1);
    expect(dst.doc.all('drafting').some((v) => v.name === 'Particolare 1')).toBe(true);
    expect(dst.doc.all('material').some((m) => m.name === 'Cotto antico')).toBe(true);
    // A level at a new height is made.
    const src2 = source().doc;
    src2.transact('l', () => src2.update(src2.levels()[1].id, { elevation: 7777 }));
    let r2;
    dst.doc.transact('m', () => (r2 = mergeFromProject(dst.doc, src2, { levels: [src2.levels()[1].id], attributes: false })));
    expect(r2.levels).toBe(1);
    expect(dst.doc.levels().some((l) => l.elevation === 7777)).toBe(true);
  });
});

describe('Library Manager', () => {
  it('reports libraries, duplicates, missing parts and macros, unused parts', () => {
    const { doc, add, L1 } = project();
    const a = add({ kind: 'componentType', family: 'gdl', name: 'Chair 01', gdl: { source: 'Furniture/Chairs/Chair 01.gsm', script3d: 'CALL "chair_macro"', macros: {} }, width: 500, depth: 500, height: 900 });
    add({ kind: 'componentType', family: 'gdl', name: 'Chair 01', gdl: { source: 'Old Library/Chair 01.gsm', script3d: 'BLOCK 1,1,1', macros: {} }, width: 500, depth: 500, height: 900 });
    add({ kind: 'component', typeId: a.id, levelId: L1.id, at: [0, 0] });
    add({ kind: 'component', typeId: 'gone-type', levelId: L1.id, at: [0, 0] });
    expect(libraryOf(a)).toBe('Furniture');
    const r = libraryReport(doc);
    expect(r.libraries.find((l) => l.name === 'Furniture')).toMatchObject({ parts: 1, placed: 1 });
    expect(r.duplicates).toHaveLength(1);
    expect(r.missing).toHaveLength(1);
    expect(r.macros[0].missing).toEqual(['chair_macro']);
    expect(r.unused.some((u) => u.library === 'Old Library')).toBe(true);
  });
});

describe('MEP part connectors', () => {
  it('come from the open ends of the saved runs and join runs to the placed part', () => {
    const p = project();
    const { doc } = p;
    const dt = doc.all('ductType')[0];
    const r1 = p.add({ kind: 'duct', typeId: dt.id, levelId: p.L1.id, a: [0, 0], b: [1000, 0], offset: 2500 });
    const r2 = p.add({ kind: 'duct', typeId: dt.id, levelId: p.L1.id, a: [1000, 0], b: [1000, 800], offset: 2500 });
    const conns = connectorsFromSelection(doc, [r1.id, r2.id], [0, -200, 2300]);
    expect(conns).toHaveLength(2);
    expect(conns[0]).toMatchObject({ at: [0, 200, 200], family: 'duct' });
    expect(conns[0].dir[0]).toBeCloseTo(-1, 6);
    // A part with those connectors placed at (5000, 0): a run ending at a connector joins it.
    const t = p.add({ kind: 'componentType', family: 'gdl', name: 'Box', category: 'mechanical', width: 1000, depth: 1000, height: 400, mepConnectors: conns, gdl: { script3d: '' } });
    const c = p.add({ kind: 'component', typeId: t.id, levelId: p.L1.id, at: [5000, -200], rotation: 0, offset: 2300 });
    const pts = connectorPoints(doc, doc.get(c.id));
    expect(pts[0].p).toEqual([5000, 0, 2500]);
    const r3 = p.add({ kind: 'duct', typeId: dt.id, levelId: p.L1.id, a: [3000, 0], b: [5000, 0], offset: 2500 });
    const net = mepNetworks(doc).find((n) => n.runs.includes(r3.id));
    expect(net.terminals).toContain(c.id);
    expect(net.openEnds.some((e) => e.id === r3.id && e.p[0] === 5000)).toBe(false);
  });
});

describe('Nested hotlinks', () => {
  it('show a module inside a module and keep it when embedding', () => {
    const inner = project();
    inner.wall([0, 0], [3000, 0]);
    const middle = project();
    middle.wall([0, 1000], [3000, 1000]);
    middle.add({ kind: 'link', name: 'Inner', data: linkData(inner.doc), at: [0, 5000], rotation: 0, z: 0 });
    const host = project();
    const link = host.add({ kind: 'link', name: 'Middle', data: linkData(middle.doc), at: [10000, 0], rotation: 0, z: 0 });
    const scene = new Scene(host.doc);
    const m = scene.mesh(host.doc.get(link.id));
    // The inner wall (y = 5000 in the middle module) shows too.
    expect(m.bounds.max[1]).toBeGreaterThan(5000);
    const mid = Doc.fromJSON(JSON.parse(linkData(middle.doc)));
    let out;
    host.doc.transact('e', () => (out = embedLink(host.doc, host.doc.get(link.id), mid)));
    const kept = host.doc.all('link');
    expect(kept).toHaveLength(1);
    expect(kept[0].at).toEqual([10000, 5000]);
    expect(out.added.length).toBeGreaterThan(1);
  });
});
