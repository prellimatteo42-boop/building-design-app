import { describe, it, expect } from 'vitest';
import { createSampleProject } from '../src/core/sample.js';
import { createProject } from '../src/core/template.js';
import { Scene } from '../src/core/scene.js';
import { writeIFC } from '../src/io/ifc.js';
import { ifcToModel } from '../src/io/ifcmodel.js';
import { typeThickness } from '../src/core/catalog.js';

describe('opening an IFC file as a model', () => {
  it('turns a model this app exported back into walls, slabs, openings and zones', () => {
    const src = createSampleProject();
    const w0 = src.all('wall')[0];
    src.transact('props', () => src.update(w0.id, { ifcGuid: '0123456789abcdefABCDEF', ifcProps: { 'Pset_WallCommon.IsExternal': true, 'Pset_WallCommon.FireRating': 'REI 60', 'Pset_WallCommon.ThermalTransmittance': 0.28 } }));
    const text = writeIFC({ doc: src, scene: new Scene(src) });
    const ifc = typeof text === 'string' ? text : text.text;
    const doc = createProject({ system: 'metric' });
    let out;
    doc.transact('Open IFC', () => (out = ifcToModel(doc, ifc, { name: 'house.ifc' })));
    const count = (k) => src.all(k).length;
    expect(out.walls + out.curtainWalls).toBe(count('wall'));
    expect(out.doors).toBe(count('door'));
    expect(out.windows).toBe(count('window'));
    expect(out.spaces).toBe(count('room'));
    // Walls keep their thickness and length.
    const scene = new Scene(doc);
    const len = (w) => Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]);
    const total = (d) => d.all('wall').reduce((s, w) => s + len(w), 0);
    expect(Math.abs(total(doc) - total(src)) / total(src)).toBeLessThan(0.08);
    const th = (d) => d.all('wall').map((w) => Math.round(typeThickness(d.get(w.typeId)))).sort((a, b) => a - b);
    expect(th(doc)).toEqual(th(src));
    // Zones keep their areas.
    const srcScene = new Scene(src);
    const areas = (d, s) => d.all('room').map((r) => Math.round(s.rooms.room(r).area / 1e4) / 100).sort((a, b) => a - b);
    expect(areas(doc, scene)).toEqual(areas(src, srcScene));
    // And the IFC identity of each element.
    expect(doc.all('wall').every((w) => typeof w.ifcGuid === 'string' && w.ifcGuid.length === 22)).toBe(true);
    // An element's GlobalId and property sets go out and come back.
    const back = doc.all('wall').find((w) => w.ifcGuid === '0123456789abcdefABCDEF');
    expect(back.ifcProps).toEqual({ 'Pset_WallCommon.IsExternal': true, 'Pset_WallCommon.FireRating': 'REI 60', 'Pset_WallCommon.ThermalTransmittance': 0.28 });
  });
});

describe('opening an IFC file written by other software', () => {
  it('reads extruded walls in rotated placements, a door filling an opening, a space and a storey', () => {
    // Millimetres. Storey 1 at 3000; a wall 4 m long, 200 thick, 2800 high, placed at (1000, 2000) and turned 90 degrees.
    const ifc = `ISO-10303-21;
DATA;
#1=IFCSIUNIT(*,.LENGTHUNIT.,.MILLI.,.METRE.);
#2=IFCCARTESIANPOINT((0.,0.,0.));
#3=IFCDIRECTION((0.,0.,1.));
#4=IFCDIRECTION((1.,0.,0.));
#5=IFCAXIS2PLACEMENT3D(#2,#3,#4);
#6=IFCLOCALPLACEMENT($,#5);
#7=IFCPROJECT('3d$ZRWqUL9z9u1M7Yd0Ad7',$,'Tower',$,$,$,$,$,$);
#10=IFCCARTESIANPOINT((0.,0.,3000.));
#11=IFCAXIS2PLACEMENT3D(#10,#3,#4);
#12=IFCLOCALPLACEMENT(#6,#11);
#13=IFCBUILDINGSTOREY('1hWqdQ8Q50XxLGEBJ2Pyhz',$,'Primo piano',$,$,#12,$,$,.ELEMENT.,3000.);
#20=IFCCARTESIANPOINT((1000.,2000.,0.));
#21=IFCDIRECTION((0.,1.,0.));
#22=IFCAXIS2PLACEMENT3D(#20,#3,#21);
#23=IFCLOCALPLACEMENT(#12,#22);
#24=IFCCARTESIANPOINT((2000.,0.));
#25=IFCAXIS2PLACEMENT2D(#24,$);
#26=IFCRECTANGLEPROFILEDEF(.AREA.,$,#25,4000.,200.);
#27=IFCEXTRUDEDAREASOLID(#26,#5,#3,2800.);
#28=IFCSHAPEREPRESENTATION($,'Body','SweptSolid',(#27));
#29=IFCPRODUCTDEFINITIONSHAPE($,$,(#28));
#30=IFCWALLSTANDARDCASE('2O2Fr$t4X7Zf8NOew3FLOH',$,'Muro 200',$,$,#23,#29,$,.STANDARD.);
#40=IFCCARTESIANPOINT((1500.,0.,0.));
#41=IFCAXIS2PLACEMENT3D(#40,#3,#4);
#42=IFCLOCALPLACEMENT(#23,#41);
#43=IFCCARTESIANPOINT((450.,0.));
#44=IFCAXIS2PLACEMENT2D(#43,$);
#45=IFCRECTANGLEPROFILEDEF(.AREA.,$,#44,900.,200.);
#46=IFCEXTRUDEDAREASOLID(#45,#5,#3,2100.);
#47=IFCSHAPEREPRESENTATION($,'Body','SweptSolid',(#46));
#48=IFCPRODUCTDEFINITIONSHAPE($,$,(#47));
#49=IFCOPENINGELEMENT('0nLEHKzAP4NeeWzScnS9pT',$,$,$,$,#42,#48,$,.OPENING.);
#50=IFCRELVOIDSELEMENT('1nLEHKzAP4NeeWzScnS9pT',$,$,$,#30,#49);
#51=IFCDOOR('2nLEHKzAP4NeeWzScnS9pT',$,'Porta 90',$,$,#42,#48,$,2100.,900.,.DOOR.,.SINGLE_SWING_LEFT.,$);
#52=IFCRELFILLSELEMENT('3nLEHKzAP4NeeWzScnS9pT',$,$,$,#49,#51);
#60=IFCCARTESIANPOINT((0.,0.));
#61=IFCCARTESIANPOINT((3000.,0.));
#62=IFCCARTESIANPOINT((3000.,2500.));
#63=IFCCARTESIANPOINT((0.,2500.));
#64=IFCPOLYLINE((#60,#61,#62,#63,#60));
#65=IFCARBITRARYCLOSEDPROFILEDEF(.AREA.,$,#64);
#66=IFCEXTRUDEDAREASOLID(#65,#5,#3,2700.);
#67=IFCSHAPEREPRESENTATION($,'Body','SweptSolid',(#66));
#68=IFCPRODUCTDEFINITIONSHAPE($,$,(#67));
#69=IFCSPACE('4nLEHKzAP4NeeWzScnS9pT',$,'1.01',$,$,#12,#68,'Ufficio',.ELEMENT.,.INTERNAL.,$);
#70=IFCRELCONTAINEDINSPATIALSTRUCTURE('5nLEHKzAP4NeeWzScnS9pT',$,$,$,(#30,#51),#13);
#71=IFCRELAGGREGATES('6nLEHKzAP4NeeWzScnS9pT',$,$,$,#13,(#69));
#80=IFCPROPERTYSINGLEVALUE('IsExternal',$,IFCBOOLEAN(.T.),$);
#81=IFCPROPERTYSET('7nLEHKzAP4NeeWzScnS9pT',$,'Pset_WallCommon',$,(#80));
#82=IFCRELDEFINESBYPROPERTIES('8nLEHKzAP4NeeWzScnS9pT',$,$,$,(#30),#81);
ENDSEC;
END-ISO-10303-21;`;
    const doc = createProject({ system: 'metric' });
    let out;
    doc.transact('Open IFC', () => (out = ifcToModel(doc, ifc)));
    expect(out).toMatchObject({ walls: 1, doors: 1, spaces: 1 });
    const lv = doc.levels().find((l) => l.elevation === 3000);
    expect(lv).toBeTruthy();
    const w = doc.all('wall')[0];
    expect(w.levelId).toBe(lv.id);
    // The wall runs along y from (1000, 2000) to (1000, 6000).
    const ends = [w.a, w.b].map((p) => p.map(Math.round)).sort((p, q) => p[1] - q[1]);
    expect(ends).toEqual([[1000, 2000], [1000, 6000]]);
    expect(Math.round(typeThickness(doc.get(w.typeId)))).toBe(200);
    expect(w.height).toBe(2800);
    expect(w.ifcProps).toEqual({ 'Pset_WallCommon.IsExternal': true });
    const d = doc.all('door')[0];
    expect(d.hostId).toBe(w.id);
    expect(Math.abs(d.t - (Math.abs(ends[0][1] - w.a[1]) < 1 ? 1950 : 2050))).toBeLessThan(2);
    const room = doc.all('room')[0];
    expect(room).toMatchObject({ name: 'Ufficio', number: '1.01', levelId: lv.id });
    expect(new Scene(doc).rooms.room(room).area).toBeCloseTo(7.5e6, -3);
  });
});

describe('IFC files as buildingSMART samples write them', () => {
  // Millimetres assigned to the project, metres declared too (for a map conversion): the project's unit counts.
  // A footing slab 6 x 4 m, 300 thick, and a level duct 5 m long, 400 x 250, its centre at 2600.
  const ifc = `ISO-10303-21;
DATA;
#1=IFCSIUNIT(*,.LENGTHUNIT.,.MILLI.,.METRE.);
#2=IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.);
#3=IFCUNITASSIGNMENT((#1));
#4=IFCPROJECT('0YvctVUKr0kugbFTf53O9L',$,'Samples',$,$,$,$,$,#3);
#10=IFCCARTESIANPOINT((0.,0.,0.));
#11=IFCDIRECTION((0.,0.,1.));
#12=IFCDIRECTION((1.,0.,0.));
#13=IFCAXIS2PLACEMENT3D(#10,#11,#12);
#14=IFCLOCALPLACEMENT($,#13);
#20=IFCCARTESIANPOINT((3000.,2000.));
#21=IFCAXIS2PLACEMENT2D(#20,$);
#22=IFCRECTANGLEPROFILEDEF(.AREA.,$,#21,6000.,4000.);
#23=IFCCARTESIANPOINT((0.,0.,-300.));
#24=IFCAXIS2PLACEMENT3D(#23,#11,#12);
#25=IFCEXTRUDEDAREASOLID(#22,#24,#11,300.);
#26=IFCSHAPEREPRESENTATION($,'Body','SweptSolid',(#25));
#27=IFCPRODUCTDEFINITIONSHAPE($,$,(#26));
#28=IFCFOOTING('1YvctVUKr0kugbFTf53O9L',$,'Foundation',$,$,#14,#27,$,.PAD_FOOTING.);
#30=IFCCARTESIANPOINT((2500.,0.));
#31=IFCAXIS2PLACEMENT2D(#30,$);
#32=IFCRECTANGLEPROFILEDEF(.AREA.,$,#31,5000.,400.);
#33=IFCCARTESIANPOINT((0.,1000.,2475.));
#34=IFCAXIS2PLACEMENT3D(#33,#11,#12);
#35=IFCEXTRUDEDAREASOLID(#32,#34,#11,250.);
#36=IFCSHAPEREPRESENTATION($,'Body','SweptSolid',(#35));
#37=IFCPRODUCTDEFINITIONSHAPE($,$,(#36));
#38=IFCDUCTSEGMENT('2YvctVUKr0kugbFTf53O9L',$,'Duct',$,$,#14,#37,$,.RIGIDSEGMENT.);
ENDSEC;
END-ISO-10303-21;`;

  it('read lengths in the project unit, footings as foundation slabs and level ducts as ducts', () => {
    const doc = createProject({ system: 'metric' });
    let out;
    doc.transact('Open IFC', () => (out = ifcToModel(doc, ifc)));
    expect(out).toMatchObject({ foundations: 1, runs: 1 });
    const f = doc.all('floor').find((x) => doc.get(x.typeId)?.foundation);
    const xs = f.boundary.map((p) => p[0]);
    expect(Math.max(...xs) - Math.min(...xs)).toBeCloseTo(6000, 0);
    expect(Math.round(typeThickness(doc.get(f.typeId)))).toBe(300);
    const d = doc.all('duct')[0];
    expect(Math.round(Math.hypot(d.b[0] - d.a[0], d.b[1] - d.a[1]))).toBe(5000);
    expect([d.width, d.height]).toEqual([400, 250]);
    const lv = doc.get(d.levelId).elevation;
    expect(lv + d.offset).toBeCloseTo(2600, 0);
  });
});

describe('IFC roofs made of sloping slabs', () => {
  // A sloping slab over a plan rectangle: its underside z = z0 + k * (distance uphill from x = xe), 200 thick.
  const slab = (x0, x1, xe, dirUp, z0, k) => {
    const zu = (x) => z0 + k * (x - xe) * dirUp;
    const P = (x, y, top) => [x, y, zu(x) + (top ? 200 : 0)];
    const q = (a, b, c, d) => [...a, ...b, ...c, ...a, ...c, ...d];
    const [y0, y1] = [0, 6000];
    return {
      tris: [
        ...q(P(x0, y0, 0), P(x0, y1, 0), P(x1, y1, 0), P(x1, y0, 0)),
        ...q(P(x0, y0, 1), P(x1, y0, 1), P(x1, y1, 1), P(x0, y1, 1)),
        ...q(P(x0, y0, 0), P(x1, y0, 0), P(x1, y0, 1), P(x0, y0, 1)),
        ...q(P(x1, y1, 0), P(x0, y1, 0), P(x0, y1, 1), P(x1, y1, 1)),
      ],
    };
  };

  it('become one native roof: eaves sloping, gables upright, a higher eave by its pivot moved out', async () => {
    const { roofFromSlabs } = await import('../src/io/ifcmodel.js');
    const { roofFaces } = await import('../src/core/roof.js');
    // Left plane rises from x = 0 (eave at 3000) to the ridge at x = 4000; right plane from x = 10000 (eave at 2000).
    const left = slab(0, 4000, 0, 1, 3000, 1);
    const right = slab(4000, 10000, 10000, -1, 1000, 1);
    const r = roofFromSlabs([left, right]);
    expect(r.base).toBe(1000);
    expect(r.thickness).toBe(141);
    expect(r.slopes.filter((x) => x === 45)).toHaveLength(2);
    // Outline and ridge as in the file.
    const f = roofFaces(r.boundary, r.slopes, { overhangs: r.overhangs });
    const xs = f.poly.map((p) => Math.round(p[0]));
    expect([Math.min(...xs), Math.max(...xs)]).toEqual([0, 10000]);
    expect(f.ridges.map((e) => e.map((p) => Math.round(p[0])))).toEqual([[4000, 4000]]);
  });
});
