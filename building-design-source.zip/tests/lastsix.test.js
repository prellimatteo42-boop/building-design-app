import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { traceReferences, traceReference } from '../src/core/trace.js';
import { varyingSection, ANALYTICAL_RULES, analyticalModel } from '../src/core/analytical.js';
import { boxUV, applySurfaceTextures, texturedMaterials } from '../src/core/surfaces2.js';
import { surfaceScript } from '../src/core/surfaces.js';
import { Scene } from '../src/core/scene.js';

describe('entire model trace', () => {
  it('shows every other story', () => {
    const { doc } = project();
    const plans = doc.all('plan');
    const refs = traceReferences(doc, plans[0], { on: true, refId: 'entire' });
    expect(refs.map((r) => r.id)).toEqual(plans.slice(1).map((p) => p.id));
    expect(traceReferences(doc, plans[0], { on: false, refId: 'entire' })).toEqual([]);
  });
  it('keeps a single reference as before', () => {
    const { doc } = project();
    const plans = doc.all('plan');
    expect(traceReferences(doc, plans[0], { on: true, refId: 'above' })).toEqual([traceReference(doc, plans[0], { on: true, refId: 'above' })]);
  });
});

describe('varying members', () => {
  it('stands for a tapered member', () => {
    expect(varyingSection('average', 400, 200, 600, 300)).toEqual([500, 250]);
    expect(varyingSection('start', 400, 200, 600, 300)).toEqual([400, 200]);
    expect(varyingSection('end', 400, 200, 600, 300)).toEqual([600, 300]);
    expect(varyingSection('max', 700, 200, 600, 300)).toEqual([700, 300]);
    expect(ANALYTICAL_RULES.varyingProfile).toBe('average');
  });
  it('builds a tapered beam', () => {
    const { doc, add, L1 } = project();
    const type = doc.all('beamType')[0];
    const plain = add({ kind: 'beam', typeId: type.id, levelId: L1.id, a: [0, 0], b: [4000, 0], offset: 3000 });
    const tap = add({ kind: 'beam', typeId: type.id, levelId: L1.id, a: [0, 2000], b: [4000, 2000], offset: 3000, endDepth: +type.depth * 2 });
    const s = new Scene(doc);
    const low = (m) => { let z = Infinity; for (let i = 2; i < m.pos.length; i += 3) z = Math.min(z, m.pos[i]); return z; };
    expect(low(s.mesh(tap))).toBeLessThan(low(s.mesh(plain)) - 1);
  });
});

describe('surfaces', () => {
  it('maps a texture by the axis a face looks along', () => {
    const sf = { w: 500, h: 250 };
    expect(boxUV([1000, 500, 0], [0, 0, 1], sf)).toEqual([2, 2]);
    expect(boxUV([9, 1000, 500], [127, 0, 0], sf)).toEqual([2, 2]);
    expect(boxUV([1000, 9, 500], [0, -127, 0], sf)).toEqual([2, 2]);
  });
  it('moves only the faces of that colour', () => {
    const tri = (z, c) => ({ p: [0, 0, z, 1000, 0, z, 0, 1000, z], c: [...c, 255, ...c, 255, ...c, 255] });
    const a = tri(0, [200, 10, 10]);
    const b = tri(5, [10, 200, 10]);
    const mesh = { pos: new Float32Array([...a.p, ...b.p]), nrm: new Int8Array(18).map((_, i) => (i % 3 === 2 ? 127 : 0)), col: new Uint8Array([...a.c, ...b.c]) };
    const out = applySurfaceTextures(mesh, [{ rgb: [200, 10, 10], surface: { image: 'data:x', w: 1000, h: 1000 } }]);
    expect(out.pos.length).toBe(9);
    expect(out.pos[2]).toBe(5);
    expect(out.tex).toHaveLength(1);
    expect(out.tex[0].uv.length).toBe(6);
    expect(out.tex[0].src).toBe('data:x');
    expect(out.tex[0].col.length).toBe(12);
  });
  it('leaves a mesh with no such colour', () => {
    const mesh = { pos: new Float32Array(9), nrm: new Int8Array(9), col: new Uint8Array(12) };
    expect(applySurfaceTextures(mesh, [{ rgb: [200, 0, 0], surface: { image: 'x' } }])).toBe(mesh);
    expect(applySurfaceTextures(mesh, [])).toBe(mesh);
  });
  it('finds textured materials and carries reflection into the script', () => {
    const { doc } = project();
    doc.transact('s', () => doc.update('mat-concrete', { surface: { image: 'data:x', w: 1, h: 1 } }));
    expect(texturedMaterials(doc)).toHaveLength(1);
    expect(surfaceScript({ name: 'M', color: '#808080', opacity: 1, surface: { reflection: 0.6, shininess: 0.5 } })).toContain('0.7, 0.8, 0.6000, 0.0000, 50, 1,');
  });
});
