import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { schemeLines, frameFor, frameRoles, panelFor, frameSection, parsePattern } from '../src/core/cwscheme.js';
import { curtainGrid } from '../src/core/build3d.js';
import { copyCellPattern } from '../src/core/curtainmore.js';

const cw = (p, a, b) => p.wall(a, b, { typeId: 'wt-curtain', topLevelId: null, height: 3600 });
const setCurtain = (doc, patch) => doc.transact('t', () => doc.update('wt-curtain', { curtain: { ...doc.get('wt-curtain').curtain, ...patch } }));

describe('curtain wall schemes', () => {
  it('parses patterns from text', () => {
    expect(parsePattern('900, 1500 600;x')).toEqual([900, 1500, 600]);
  });

  it('repeats a module pattern with the remainder at the end', () => {
    expect(schemeLines(5000, { pattern: [900, 1500], fit: 'repeat' })).toEqual([0, 900, 2400, 3300, 4800, 5000]);
  });

  it('centres the remainder', () => {
    expect(schemeLines(5000, { pattern: [900, 1500], fit: 'center' })).toEqual([0, 100, 1000, 2500, 3400, 4900, 5000]);
  });

  it('stretches the pattern to fit', () => {
    const u = schemeLines(5000, { pattern: [1000, 1500], fit: 'stretch' });
    // Two repetitions of 2500 fit exactly.
    expect(u).toEqual([0, 1000, 2500, 3500, 5000]);
    const v = schemeLines(5200, { pattern: [1000, 1500], fit: 'stretch' });
    expect(v.at(-1)).toBe(5200);
    expect(v[1]).toBeCloseTo(1040, 6);
  });

  it('places the pattern once with fixed fit', () => {
    expect(schemeLines(6000, { pattern: [600, 1200], fit: 'fixed' })).toEqual([0, 600, 1800, 6000]);
  });

  it('drives the curtain grid of the type unless the wall has its own lines', () => {
    const p = project();
    setCurtain(p.doc, { uScheme: { pattern: [900, 1500], fit: 'repeat' }, vScheme: { pattern: [800, 2000], fit: 'repeat' } });
    const t = p.doc.get('wt-curtain');
    expect(curtainGrid(5000, 3600, t).us).toEqual([0, 900, 2400, 3300, 4800, 5000]);
    expect(curtainGrid(5000, 3600, t).vs).toEqual([0, 800, 2800, 3600]);
    expect(curtainGrid(5000, 3600, t, { curtainU: [2500] }).us).toEqual([0, 2500, 5000]);
  });
});

describe('frame and panel classes', () => {
  it('uses boundary frames on the outline and mullions/transoms inside', () => {
    const c = { mullionWidth: 50, mullionDepth: 150, frames: { boundary: { width: 80 }, transom: { kind: 'capped' } } };
    expect(frameRoles(c).mullion).toMatchObject({ width: 50, depth: 150, kind: 'rect' });
    expect(frameFor(c, {}, 'v:0:1', 4, 3).id).toBe('boundary');
    expect(frameFor(c, {}, 'v:4:1', 4, 3).width).toBe(80);
    expect(frameFor(c, {}, 'v:2:1', 4, 3).id).toBe('mullion');
    expect(frameFor(c, {}, 'h:1:0', 4, 3).kind).toBe('capped');
    expect(frameFor(c, {}, 'h:3:0', 4, 3).id).toBe('boundary');
  });

  it('assigns a frame class to one segment', () => {
    const c = { frameClasses: [{ id: 'fin', name: 'Fin', kind: 'tee', width: 60, depth: 400 }] };
    const w = { frameClass: { 'v:2:0': 'fin' } };
    expect(frameFor(c, w, 'v:2:0', 4, 3).depth).toBe(400);
    expect(frameFor(c, w, 'v:2:1', 4, 3).id).toBe('mullion');
  });

  it('resolves panel classes, built-in kinds and the main panel', () => {
    const c = { panelClasses: [{ id: 'p-spandrel', name: 'Spandrel', kind: 'spandrel', thickness: 30 }], mainPanel: 'p-spandrel' };
    expect(panelFor(c, {}, 0, 0).kind).toBe('spandrel');
    expect(panelFor(c, { panels: { '0:0': 'door' } }, 0, 0).kind).toBe('door');
    expect(panelFor({}, {}, 0, 0).kind).toBe('glass');
  });

  it('gives each profile kind its own section', () => {
    expect(frameSection({ kind: 'rect', width: 50, depth: 150 })).toEqual([[-25, -75, 25, 75]]);
    const capped = frameSection({ kind: 'capped', width: 50, depth: 150 });
    expect(capped).toHaveLength(2);
    expect(capped[1][2] - capped[1][0]).toBeGreaterThan(50);
    expect(frameSection({ kind: 'tee', width: 60, depth: 200 })).toHaveLength(2);
  });

  it('builds frames by class in 3D and in plan', () => {
    const p = project();
    const { doc } = p;
    const w = cw(p, [0, 0], [6000, 0]);
    const scene = new Scene(doc);
    const plain = scene.mesh(doc.get(w.id)).bounds;
    expect(plain.max[1] - plain.min[1]).toBeCloseTo(150, 0);
    setCurtain(doc, { frameClasses: [{ id: 'fin', name: 'Fin', kind: 'rect', width: 60, depth: 500 }] });
    doc.transact('f', () => doc.update(w.id, { frameClass: { 'v:2:0': 'fin', 'v:2:1': 'fin', 'v:2:2': 'fin' } }));
    const m = scene.mesh(doc.get(w.id)).bounds;
    expect(m.max[1] - m.min[1]).toBeCloseTo(500, 0);
    const view = doc.all('plan').find((v) => v.levelId === p.L1.id);
    const g = scene.planOf(view, doc.get(w.id));
    const ys = [];
    for (const l of g.lines || []) for (const q of [l.a, l.b]) if (q) ys.push(q[1]);
    // The fin's section shows in plan at its own depth.
    expect(Math.max(...ys) - Math.min(...ys)).toBeCloseTo(500, -1);
  });

  it('builds spandrel, louvre and custom solid panels', () => {
    const p = project();
    const { doc } = p;
    const w = cw(p, [0, 0], [6000, 0]);
    const scene = new Scene(doc);
    const n0 = scene.mesh(doc.get(w.id)).pos.length;
    setCurtain(doc, { panelClasses: [{ id: 'stone', name: 'Stone', kind: 'solid', thickness: 40, materialId: 'mat-stone' }] });
    doc.transact('p', () => doc.update(w.id, { panels: { '0:0': 'louvre', '1:0': 'spandrel', '2:0': 'stone' } }));
    const m = scene.mesh(doc.get(w.id));
    expect(m.pos.length).toBeGreaterThan(n0);
  });

  it('copies frame classes with the cell pattern', () => {
    const r = copyCellPattern({ frameClass: { 'v:1:0': 'fin' } }, 6, 2, { i0: 0, i1: 1, j0: 0, j1: 0 });
    expect(r.frameClass['v:3:0']).toBe('fin');
    expect(r.frameClass['v:5:0']).toBe('fin');
    expect(r.frameClass['v:2:0']).toBeUndefined();
  });
});
