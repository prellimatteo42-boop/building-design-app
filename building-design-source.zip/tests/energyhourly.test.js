import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { energyReport } from '../src/core/energy.js';
import { annualEnergy, CLIMATES } from '../src/core/energysim.js';
import { parseEPW, climateFromEPW, sunAt, hourlyClimate, irradiationOn, simulateBlock, HOURS, monthOfHour } from '../src/core/energyhourly.js';

function house(rooms = 1) {
  const p = project();
  for (const [a, b] of [[[0, 0], [8000, 0]], [[8000, 0], [8000, 4000]], [[8000, 4000], [0, 4000]], [[0, 4000], [0, 0]]]) p.wall(a, b, { typeId: 'wt-ext-concrete' });
  const host = p.doc.all('wall')[0];
  p.add({ kind: 'window', typeId: p.doc.all('windowType')[0].id, hostId: host.id, levelId: p.L1.id, t: 2000, width: 2400, height: 1800 });
  if (rooms === 2) {
    p.wall([4000, 0], [4000, 4000]);
    p.add({ kind: 'room', levelId: p.L1.id, at: [2000, 2000], name: 'Living', upperOffset: 2700 });
    p.add({ kind: 'room', levelId: p.L1.id, at: [6000, 2000], name: 'Store', upperOffset: 2700 });
  } else p.add({ kind: 'room', levelId: p.L1.id, at: [4000, 2000], name: 'Room', upperOffset: 2700 });
  p.doc.transact('c', () => p.doc.update('project', { energy: { ...(p.doc.get('project').energy || {}), climate: CLIMATES.find((c) => c.name === 'Milano') } }));
  return p;
}
const setEnergy = (p, patch) => p.doc.transact('e', () => p.doc.update('project', { energy: { ...p.doc.get('project').energy, ...patch } }));

function epwText() {
  const head = ['LOCATION,Testville,-,ITA,TMY,000000,45.0,9.0,1.0,120', 'DESIGN CONDITIONS,0', 'TYPICAL/EXTREME PERIODS,0', 'GROUND TEMPERATURES,0', 'HOLIDAYS/DAYLIGHT SAVINGS,No,0,0,0', 'COMMENTS 1,test', 'COMMENTS 2,test', 'DATA PERIODS,1,1,Data,Sunday, 1/ 1,12/31'];
  const rows = [];
  const days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  days.forEach((d, m) => {
    for (let day = 1; day <= d; day++)
      for (let hr = 1; hr <= 24; hr++) {
        const f = Array(35).fill(0);
        f[0] = 2001;
        f[1] = m + 1;
        f[2] = day;
        f[3] = hr;
        f[6] = m * 2; // °C: 0 in January … 22 in December
        f[13] = hr >= 8 && hr <= 16 ? 300 : 0;
        f[14] = hr >= 8 && hr <= 16 ? 400 : 0;
        f[15] = hr >= 8 && hr <= 16 ? 100 : 0;
        rows.push(f.join(','));
      }
  });
  return [...head, ...rows].join('\n');
}

describe('hourly climate', () => {
  it('reads an EPW file', () => {
    const e = parseEPW(epwText());
    expect(e.name).toBe('Testville, ITA');
    expect(e.lat).toBe(45);
    expect(e.t).toHaveLength(HOURS);
    const c = climateFromEPW(e);
    expect(c.temps[0]).toBe(0);
    expect(c.temps[11]).toBe(22);
    expect(c.hourly.ghi[12]).toBe(300);
    expect(() => parseEPW('nothing')).toThrow();
  });

  it('puts the sun south at solar noon, higher in June', () => {
    const march = sunAt(45, (79 * 24) + 11);
    expect(march.az).toBeGreaterThan(165); // the middle of the hour before noon
    expect(march.az).toBeLessThan(180);
    expect(Math.abs(Math.acos(march.cosZ) * (180 / Math.PI) - 45)).toBeLessThan(1.5);
    expect(sunAt(45, 171 * 24 + 11).cosZ).toBeGreaterThan(march.cosZ);
    expect(sunAt(45, 171 * 24 + 7).az).toBeLessThan(120);
  });

  it('makes up hours that keep the monthly means and a plausible sun', () => {
    const milan = CLIMATES.find((c) => c.name === 'Milano');
    const hc = hourlyClimate(milan);
    const sum = Array(12).fill(0);
    const n = Array(12).fill(0);
    for (let h = 0; h < HOURS; h++) {
      sum[monthOfHour(h)] += hc.t[h];
      n[monthOfHour(h)]++;
    }
    sum.forEach((s, m) => expect(Math.abs(s / n[m] - milan.temps[m])).toBeLessThan(1.2));
    const hor = irradiationOn(hc, 0, null).year;
    expect(hor).toBeGreaterThan(1000);
    expect(hor).toBeLessThan(1700);
    // A 30° south plane gets more than the horizontal, a north wall far less.
    expect(irradiationOn(hc, 30, 180).year).toBeGreaterThan(hor);
    expect(irradiationOn(hc, 90, 0).year).toBeLessThan(hor / 2);
  });
});

describe('hourly simulation', () => {
  it('matches the steady state with no gains', () => {
    const hc = { t: Array(HOURS).fill(0), ghi: Array(HOURS).fill(0), dni: Array(HOURS).fill(0), dhi: Array(HOURS).fill(0), lat: 45 };
    const r = simulateBlock(hc, { H: 100, Cm: 1e7, area: 50, windows: [], inside: 20, cooling: 26, internalGains: 0 });
    const heating = r.months.reduce((t, m) => t + m.heating, 0);
    expect(heating).toBeCloseTo((100 * 20 * HOURS) / 1000, 0);
    expect(r.peakHeating).toBeCloseTo(2000, 3);
    expect(r.months[0].cooling).toBe(0);
  });

  it('sets back at night only below the set point and limits the morning recovery', () => {
    const hc = { t: Array(HOURS).fill(0), ghi: Array(HOURS).fill(0), dni: Array(HOURS).fill(0), dhi: Array(HOURS).fill(0), lat: 45 };
    const base = { H: 100, Cm: 1e7, area: 50, windows: [], internalGains: 0, cooling: null };
    const cold = simulateBlock(hc, { ...base, inside: 8, setback: 17 });
    expect(cold.months.reduce((t, m) => t + m.heating, 0)).toBeCloseTo((100 * 8 * HOURS) / 1000, 0);
    const warm = simulateBlock(hc, { ...base, inside: 20, setback: 16 });
    expect(warm.months.reduce((t, m) => t + m.heating, 0)).toBeLessThan((100 * 20 * HOURS) / 1000);
    expect(warm.peakHeating).toBeLessThanOrEqual(1.5 * 100 * 20 + 1e-6);
    expect(warm.tmin).toBeLessThan(17);
  });

  it('floats between the set points and counts overheating without cooling', () => {
    const hc = { t: Array(HOURS).fill(30), ghi: Array(HOURS).fill(0), dni: Array(HOURS).fill(0), dhi: Array(HOURS).fill(0), lat: 45 };
    const r = simulateBlock(hc, { H: 100, Cm: 1e7, area: 50, windows: [], inside: 20, cooling: null, internalGains: 0 });
    expect(r.tmax).toBeGreaterThan(29);
    expect(r.overheatingHours).toBeGreaterThan(8000);
    expect(r.months.reduce((t, m) => t + m.heating + m.cooling, 0)).toBe(0);
  });

  it('gives a yearly balance close to the monthly method', () => {
    const p = house();
    const monthly = annualEnergy(p.doc, new Scene(p.doc));
    setEnergy(p, { method: 'hourly' });
    const hourly = annualEnergy(p.doc, new Scene(p.doc));
    expect(hourly.method).toBe('hourly');
    expect(hourly.annual.heating).toBeGreaterThan(monthly.annual.heating * 0.6);
    expect(hourly.annual.heating).toBeLessThan(monthly.annual.heating * 1.5);
    expect(hourly.annual.peakHeating).toBeGreaterThan(0);
    expect(hourly.months[0].heating).toBeGreaterThan(hourly.months[6].heating);
  });
});

describe('building systems and thermal blocks', () => {
  it('heat recovery cuts the heating need and adds fan electricity', () => {
    const p = house();
    const nat = annualEnergy(p.doc, new Scene(p.doc));
    setEnergy(p, { ventilation: { type: 'mvhr', ach: 0.5, recovery: 0.85, sfp: 0.35 } });
    const mv = annualEnergy(p.doc, new Scene(p.doc));
    expect(mv.annual.heating).toBeLessThan(nat.annual.heating);
    expect(mv.annual.fans).toBeGreaterThan(0);
    expect(mv.annual.delivered.electricity).toBeGreaterThan(nat.annual.delivered.electricity || 0);
  });

  it('counts hot water, solar collectors and photovoltaics', () => {
    const p = house();
    setEnergy(p, { dhw: { demand: 15, system: 'heatpump' } });
    const a = annualEnergy(p.doc, new Scene(p.doc));
    expect(a.annual.dhw).toBeCloseTo(15 * a.area, 3);
    const elec = a.annual.delivered.electricity;
    setEnergy(p, { solarThermal: 4, pv: { kwp: 3, tilt: 30, azimuth: 180 } });
    const b = annualEnergy(p.doc, new Scene(p.doc));
    expect(b.annual.solarThermal).toBeGreaterThan(0);
    expect(b.annual.solarThermal).toBeLessThanOrEqual(b.annual.dhw + 1e-6);
    // 3 kWp in northern Italy: some 3000–4500 kWh a year.
    expect(b.annual.pv).toBeGreaterThan(2500);
    expect(b.annual.pv).toBeLessThan(5000);
    expect(b.annual.delivered.electricity || 0).toBeLessThan(elec);
    expect(b.annual.renewableShare).toBeGreaterThan(0);
  });

  it('balances thermal blocks with their own set points', () => {
    const p = house(2);
    const one = annualEnergy(p.doc, new Scene(p.doc));
    expect(one.blocks).toHaveLength(1);
    const store = p.doc.all('room').find((r) => r.name === 'Store');
    setEnergy(p, { blocks: [{ id: 'b1', name: 'Unheated store', roomIds: [store.id], inside: 10, internalGains: 0 }] });
    const two = annualEnergy(p.doc, new Scene(p.doc));
    expect(two.blocks.map((b) => b.name).sort()).toEqual(['Other zones', 'Unheated store']);
    expect(two.annual.heating).toBeLessThan(one.annual.heating);
    const b1 = two.blocks.find((b) => b.id === 'b1');
    expect(b1.result.heating).toBeLessThan(two.blocks.find((b) => b.id === 'default').result.heating);
  });

  it('takes U-values set by hand in the model review', () => {
    const p = house();
    const before = energyReport(p.doc, new Scene(p.doc)).totals.HT;
    const wall = p.doc.all('wall')[1];
    setEnergy(p, { uOverrides: { [wall.id]: 0.15 } });
    const r = energyReport(p.doc, new Scene(p.doc));
    expect(r.totals.HT).toBeLessThan(before);
    expect(r.rows[0].faces.find((f) => f.id === wall.id).u).toBe(0.15);
  });
});
