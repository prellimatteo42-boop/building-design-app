import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { captureProfile, stretchedShapes } from '../src/core/profiles.js';
import { refPlaneDepth, refOffset, offsetForRef } from '../src/core/slabref.js';
import { roofsFromMesh, planarGroups } from '../src/core/roofsfrommesh.js';
import { roofFaces, planeHeight } from '../src/core/roof.js';
import { delaunay } from '../src/core/topo.js';

describe('capture profile', () => {
  it('fills become a wall profile from the middle and bottom', () => {
    const pr = captureProfile([{ kind: 'region', boundary: [[1000, 500], [1300, 500], [1300, 3500], [1000, 3500]], pattern: 'concrete' }, { kind: 'region', boundary: [[1300, 500], [1400, 500], [1400, 3500], [1300, 3500]], pattern: 'insulation' }], { use: 'wall' });
    expect(pr.shapes).toHaveLength(2);
    expect(pr.shapes[0].poly[0]).toEqual([-200, 0]);
    expect(pr.shapes[1].materialId).toBe('mat-insulation');
    expect(pr.stretch).toBe(1500);
    expect(Math.max(...stretchedShapes(pr, 4000)[0].poly.map((p) => p[1]))).toBe(4000);
  });
});

describe('slab reference plane', () => {
  it('reads the elevation at another plane without moving the slab', () => {
    const type = { layers: [{ thickness: 50, function: 'finish' }, { thickness: 200, function: 'structure' }, { thickness: 30, function: 'finish' }] };
    expect(refPlaneDepth(type, 'top')).toBe(0);
    expect(refPlaneDepth(type, 'coreTop')).toBe(50);
    expect(refPlaneDepth(type, 'coreBottom')).toBe(250);
    expect(refPlaneDepth(type, 'bottom')).toBe(280);
    const slab = { offset: 0, refPlane: 'coreTop' };
    expect(refOffset(slab, type)).toBe(-50);
    expect(offsetForRef(slab, type, 0)).toBe(50);
  });
});

describe('roofs from mesh', () => {
  it('a hipped mesh gives four roofs on its faces', () => {
    const p = project();
    // A hip: rectangle eaves at z = 3000, ridge 2000 mm long at z = 4500.
    const mesh = p.add({ kind: 'topo', levelId: p.L1.id, points: [[0, 0, 3000], [6000, 0, 3000], [6000, 4000, 3000], [0, 4000, 3000], [2000, 2000, 4000], [4000, 2000, 4000]] });
    const g = planarGroups(mesh.points, delaunay(mesh.points));
    expect(g.length).toBe(4);
    const roofs = roofsFromMesh(p.doc, mesh, p.doc.all('roofType')[0].id);
    expect(roofs).toHaveLength(4);
    for (const r of roofs) {
      const f = roofFaces(r.boundary, r.slopes, {}).faces.find((x) => x.plane);
      const c = [r.boundary.reduce((s, q) => s + q[0], 0) / r.boundary.length, r.boundary.reduce((s, q) => s + q[1], 0) / r.boundary.length];
      // The roof's plane passes through the mesh: at the face's centroid the height matches the hip.
      const want = 3000 + Math.min(c[0], 6000 - c[0], c[1] * 1, 4000 - c[1]) * 0.5;
      expect(r.baseOffset + planeHeight(f.plane, c)).toBeCloseTo(want, -1);
    }
  });
});

import { blockSymbol, blockInserts, blocksAsObjects } from '../src/core/cadblocks.js';
import { runGdlType } from '../src/core/gdlobject.js';
describe('DWG blocks as objects', () => {
  const cad = {
    blocks: { CHAIR: { basePoint: { x: 10, y: 10 }, entities: [{ type: 'LINE', layer: '0', startPoint: { x: 10, y: 10 }, endPoint: { x: 510, y: 10 } }, { type: 'CIRCLE', layer: '0', center: { x: 260, y: 260 }, radius: 100 }] } },
    entities: [
      { type: 'INSERT', name: 'CHAIR', layer: 'FURN', insertionPoint: { x: 1000, y: 2000 }, rotation: Math.PI / 2 },
      { type: 'INSERT', name: 'CHAIR', layer: 'FURN', insertionPoint: { x: 3000, y: 2000 }, rotation: 0 },
      { type: 'INSERT', name: '*D1', insertionPoint: { x: 0, y: 0 } },
    ],
  };
  it('makes one part per block and one object per insertion', () => {
    expect(blockInserts(cad)).toHaveLength(2);
    const sym = blockSymbol(cad, 'CHAIR', 1);
    expect(sym.script2d).toContain('LINE2 0, 0, 0.5, 0');
    const { types, placed } = blocksAsObjects(cad, { unitMm: 1 });
    expect(types).toHaveLength(1);
    expect(placed.map((p) => [p.at, p.rotation])).toEqual([[[1000, 2000], 90], [[3000, 2000], 0]]);
    const r = runGdlType(types[0]);
    expect(r.error).toBe(null);
    expect(r.lines.length).toBeGreaterThan(0);
    expect(Math.max(...r.lines.map(([a, b]) => Math.max(a[0], b[0])))).toBeCloseTo(500, 0);
  });
});
