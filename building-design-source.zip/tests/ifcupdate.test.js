import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { writeIFC } from '../src/io/ifc.js';
import { ifcToModel } from '../src/io/ifcmodel.js';
import { createProject } from '../src/core/template.js';
import { updateFromIFC } from '../src/core/ifcupdate.js';

const ifcOf = (doc) => writeIFC({ doc, scene: new Scene(doc) });

describe('Update with IFC Model', () => {
  it('matches by GlobalId: moved walls update, new ones come in, missing ones are listed', () => {
    // The consultant's model, version 1 and version 2.
    const src = project();
    src.wall([0, 0], [6000, 0]);
    const w2 = src.wall([6000, 0], [6000, 4000]);
    const w3 = src.wall([0, 4000], [6000, 4000]);
    const v1 = ifcOf(src.doc);
    src.doc.transact('v2', () => {
      src.doc.update(w2.id, { a: [6500, 0], b: [6500, 4000] });
      src.doc.remove(w3.id);
    });
    src.wall([0, 0], [0, 4000]);
    const v2 = ifcOf(src.doc);
    // Our project made from version 1, with our own data on a wall.
    const doc = createProject({ system: 'metric' });
    doc.transact('open', () => ifcToModel(doc, v1));
    const mine = doc.all('wall');
    expect(mine).toHaveLength(3);
    const keep = mine.find((w) => Math.abs(w.a[0] - 6000) < 300 && Math.abs(w.b[0] - 6000) < 300);
    doc.transact('mine', () => doc.update(keep.id, { comments: 'checked by us' }));
    const preview = updateFromIFC(doc, v2);
    expect(preview.updated).toHaveLength(1);
    expect(preview.added).toHaveLength(1);
    expect(preview.gone).toHaveLength(1);
    expect(doc.all('wall')).toHaveLength(3);
    doc.transact('update', () => updateFromIFC(doc, v2, { apply: true, removeGone: true }));
    const after = doc.all('wall');
    expect(after).toHaveLength(3);
    const moved = doc.get(preview.updated[0]);
    expect(Math.max(moved.a[0], moved.b[0])).toBeGreaterThan(6300);
    // The moved wall is the one we annotated, and our note stays.
    expect(moved.id).toBe(keep.id);
    expect(moved.comments).toBe('checked by us');
  });
});
