import { describe, it, expect } from 'vitest';
import { readContainer, libraryParts, readLibraryPart } from '../src/io/gsm.js';

import { fileEntry, folderEntry, container, libraryPart, ascii, binary3d, binary3d4001 } from './fixtures/aclib.js';

describe('Archicad libraries', () => {
  it('reads a container tree and the library parts in it', () => {
    const part = libraryPart({
      script3d: 'BLOCK A, B, ZZYZX',
      params: [
        { name: 'A', code: 2, value: 1.2, label: 'Width' },
        { name: 'B', code: 2, value: 0.8, label: 'Depth' },
        { name: 'iRes', code: 0, value: 16, int: true, label: 'Resolution' },
        { name: 'bLegs', code: 13, value: 1, int: true, label: 'Legs' },
      ],
    });
    const bytes = container([folderEntry('Tables', [fileEntry('Table.gsm', part), fileEntry('notes.txt', ascii('hi'))])]);
    const files = readContainer(bytes);
    expect(files.map((f) => f.path)).toEqual(['Tables/Table.gsm', 'Tables/notes.txt']);
    const parts = libraryParts(bytes);
    expect(parts).toHaveLength(1);
    const lp = readLibraryPart(parts[0].bytes);
    expect(lp.scripts.script3d).toBe('BLOCK A, B, ZZYZX');
    expect(lp.params.map((p) => [p.name, p.kind, p.value, p.label])).toEqual([
      ['A', 'length', 1.2, 'Width'],
      ['B', 'length', 0.8, 'Depth'],
      ['iRes', 'integer', 16, 'Resolution'],
      ['bLegs', 'boolean', 1, 'Legs'],
    ]);
  });

  it('reads array parameters, counted from 1 as in GDL', () => {
    const part = libraryPart({
      params: [
        { name: 'heights', code: 2, array: [0.4, 0.2, 0.2], label: 'Segment heights' },
        { name: 'types', code: 0, int: true, array: [[1, 2], [3, 4]], label: 'Segment types' },
        { name: 'n', code: 0, int: true, value: 3, label: 'Segments' },
      ],
    });
    const lp = readLibraryPart(libraryParts(container([fileEntry('Cabinet.gsm', part)]))[0].bytes);
    expect(lp.params.map((p) => [p.name, p.value])).toEqual([
      ['heights', [0, 0.4, 0.2, 0.2]],
      ['types', [[], [0, 1, 2], [0, 3, 4]]],
      ['n', 3],
    ]);
  });

  it('reads string parameters\' values', () => {
    const part = libraryPart({
      params: [
        { name: 'gs_detlevel_3D', code: 12, string: 'Detailed', label: '3D Detail Level' },
        { name: 'n', code: 0, int: true, value: 3, label: 'Count' },
        { name: 'unit', code: 12, string: 'kg', label: 'Unit' },
      ],
    });
    const lp = readLibraryPart(libraryParts(container([fileEntry('Chair.gsm', part)]))[0].bytes);
    expect(lp.params.map((p) => [p.name, p.kind, p.value])).toEqual([
      ['gs_detlevel_3D', 'string', 'Detailed'],
      ['n', 'integer', 3],
      ['unit', 'string', 'kg'],
    ]);
  });

  it('reads the pictures a part carries, by their index', () => {
    const png = [0x89, 0x50, 0x4e, 0x47, 1, 2, 3];
    const part = libraryPart({ params: [], pictures: [[9, png], [21, [0x89, 0x50, 0x4e, 0x47, 7]]] });
    const lp = readLibraryPart(libraryParts(container([fileEntry('Tree.gsm', part)]))[0].bytes);
    expect([...lp.pictures.keys()]).toEqual([9, 21]);
    expect(lp.pictures.get(9).mime).toBe('image/png');
    expect([...lp.pictures.get(9).bytes]).toEqual(png);
  });

  it('says plainly what is not a library', () => {
    expect(() => readContainer(new Uint8Array(32))).toThrow(/not an Archicad library container/);
    expect(() => readLibraryPart(new Uint8Array(64))).toThrow(/not an Archicad library part/);
  });
});

describe('Archicad objects in this app', () => {
  it('imports a part with the macro it calls, and runs it on its own', async () => {
    const { ArchicadLibrary, partType } = await import('../src/core/aclib.js');
    const { runGdlType } = await import('../src/core/gdlobject.js');
    const table = libraryPart({
      master: 'top = ZZYZX * 0.05',
      script3d: 'ADDZ ZZYZX - top\nBLOCK A, B, top\nDEL 1\nCALL "Leg_m" PARAMETERS h = ZZYZX - top RETURNED_PARAMETERS made',
      params: [
        { name: 'A', code: 2, value: 1.2, label: 'Width' },
        { name: 'B', code: 2, value: 0.8, label: 'Depth' },
        { name: 'ZZYZX', code: 2, value: 0.75, label: 'Height' },
        { name: 'gs_leg', code: 2, value: 0.05, label: 'Leg' },
      ],
    });
    const leg = libraryPart({ script3d: 'BLOCK 0.05, 0.05, h\nEND 1', params: [{ name: 'h', code: 2, value: 0.7, label: 'Height' }] });
    const lib = new ArchicadLibrary();
    lib.add('Tables.lcf', container([folderEntry('Tables', [fileEntry('Table.gsm', table)]), folderEntry('Macros', [fileEntry('Leg_m.gsm', leg)])]));
    expect(lib.objects().map((e) => e.name)).toEqual(['Table']);
    const type = partType(lib, lib.get('Table'));
    expect(type).toMatchObject({ width: 1200, depth: 800, height: 750, family: 'gdl' });
    expect(Object.keys(type.gdl.macros)).toEqual(['leg_m']);
    expect(type.gdl.params).toEqual([{ name: 'gs_leg', label: 'Leg', kind: 'length', value: 50 }]);
    // The type alone (no library) draws the top and the leg, centred, in millimetres.
    const r = runGdlType(type);
    expect(r.error).toBeNull();
    expect(r.tris.length).toBe(24);
    const zs = r.tris.flatMap((t) => [t.a[2], t.b[2], t.c[2]]);
    expect(Math.max(...zs)).toBeCloseTo(750, 6);
    expect(r.lines.length + r.polys.length).toBeGreaterThan(0);
  });
});

describe('Archicad pictures and binary 3D data', () => {
  const PNG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];

  it('finds the catalogue preview from the section directory alone', async () => {
    const { partPreview } = await import('../src/io/gsm.js');
    const bytes = new Uint8Array(libraryPart({ params: [], preview: PNG, pictures: [[1, [1, 2]]] }));
    expect(partPreview(bytes)).toEqual({ mime: 'image/png', bytes: new Uint8Array(PNG) });
    expect(readLibraryPart(bytes).preview.mime).toBe('image/png');
    expect(partPreview(new Uint8Array(libraryPart({ params: [] })))).toBeNull();
  });

  it('reads binary 3D bodies, their polygons chained from the edges', async () => {
    const { read3DBinary } = await import('../src/io/binary3d.js');
    const tri = [[0, 0, 0], [1, 0, 0], [0, 2, 0]];
    const part = libraryPart({ params: [], binaries: [[1, binary3d([tri, [[0, 0, 1], [1, 0, 1], [1, 1, 1]]])]] });
    const lp = readLibraryPart(libraryParts(container([fileEntry('Man.gsm', part)]))[0].bytes);
    const bodies = read3DBinary(lp.binaries.get(1));
    expect(bodies).toHaveLength(1);
    expect(bodies[0].polys).toHaveLength(2);
    expect(bodies[0].polys[0]).toEqual(tri);
    expect(bodies[0].max).toEqual([1, 2, 1]);
    expect(read3DBinary(new Uint8Array(200))).toBeNull();
  });

  it('reads the oldest binary 3D layout (version 4001: smaller records, vertices as floats)', async () => {
    const { read3DBinary } = await import('../src/io/binary3d.js');
    const tri = [[0, 0, 0], [1, 0, 0], [0, 2, 0.5]];
    const part = libraryPart({ params: [], binaries: [[1, binary3d4001([tri, [[0, 0, 1], [1, 0, 1], [1, 1, 1]]])]] });
    const bodies = read3DBinary(readLibraryPart(libraryParts(container([fileEntry('Plant.gsm', part)]))[0].bytes).binaries.get(1));
    expect(bodies).toHaveLength(1);
    expect(bodies[0].polys).toHaveLength(2);
    expect(bodies[0].polys[0]).toEqual(tri);
    expect(bodies[0].max).toEqual([1, 2, 1]);
  });

  it('carries the pictures and binary data a part draws into its type, and draws them from the type alone', async () => {
    const { ArchicadLibrary, partType } = await import('../src/core/aclib.js');
    const { runGdlType } = await import('../src/core/gdlobject.js');
    const part = libraryPart({
      script3d: 'PICTURE 2, A, B, 0\nMATERIAL 3\nBINARY 0, 1, 1',
      params: [
        { name: 'A', code: 2, value: 1, label: 'Width' },
        { name: 'B', code: 2, value: 2, label: 'Depth' },
      ],
      pictures: [[1, PNG], [2, PNG]],
      binaries: [[1, binary3d([[[0, 0, 0], [1, 0, 0], [0, 1, 1]]])]],
    });
    const lib = new ArchicadLibrary();
    lib.add('People.lcf', container([fileEntry('Figure.gsm', part)]));
    const type = partType(lib, lib.get('Figure'));
    // Only the picture it shows.
    expect(Object.keys(type.gdl.pictures)).toEqual(['2']);
    expect(type.gdl.pictures[2]).toMatch(/^data:image\/png;base64,/);
    expect(Object.keys(type.gdl.binaries)).toEqual(['1']);
    const r = runGdlType(JSON.parse(JSON.stringify(type)));
    expect(r.error).toBeNull();
    const shown = r.tris.filter((t) => t.src);
    expect(shown).toHaveLength(2);
    expect(shown[0].uv).toEqual([[0, 0], [1, 0], [1, 1]]);
    expect(r.tris.filter((t) => !t.src)).toHaveLength(1);
  });

  it('draws the picture a 2D script shows in the plan symbol, with no blank fill under it', async () => {
    const { ArchicadLibrary, partType } = await import('../src/core/aclib.js');
    const { buildFamily } = await import('../src/core/families.js');
    const { Frame } = await import('../src/core/mesh.js');
    const part = libraryPart({ script2d: 'PICTURE2{2} 1, A, B, 1', params: [{ name: 'A', code: 2, value: 3, label: 'Width' }, { name: 'B', code: 2, value: 3, label: 'Depth' }], pictures: [[1, PNG]] });
    const lib = new ArchicadLibrary();
    lib.add('Plants.lcf', container([fileEntry('Tree Top.gsm', part)]));
    const type = partType(lib, lib.get('Tree Top'));
    const plan = buildFamily(type, new Frame([0, 0], 0, 0), null, () => null);
    expect(plan.noFill).toBe(true);
    expect(plan.pictures).toHaveLength(1);
    expect(plan.pictures[0].pts[2]).toEqual([3000, 3000]);
  });
});

describe('Archicad doors and windows', () => {
  it('come in as door and window types and draw in the opening, from the reveal face', async () => {
    const { ArchicadLibrary, partType } = await import('../src/core/aclib.js');
    const { runGdlOpening } = await import('../src/core/gdlobject.js');
    // A frame 50 mm deep at the reveal face (z from -0.05 to 0), 60 mm wide jambs; its plan: the frame from the face in.
    const win = libraryPart({
      script3d: 'ADD -A/2, 0, -0.05\nBLOCK 0.06, B, 0.05\nDEL 1',
      script2d: 'RECT2 -A/2, 0, A/2, 0.05',
      params: [{ name: 'A', code: 2, value: 1.2, label: 'Width' }, { name: 'B', code: 2, value: 1.5, label: 'Height' }],
    });
    const lib = new ArchicadLibrary();
    lib.add('W.lcf', container([folderEntry('Doors and Windows', [folderEntry('Windows', [fileEntry('Plain Window.gsm', win)])])]));
    const type = partType(lib, lib.get('Plain Window'));
    expect(type).toMatchObject({ kind: 'windowType', width: 1200, height: 1500, family: 'gdl' });
    const r = runGdlOpening(type, { width: 1000, height: 1400, thickness: 300 });
    expect(r.error).toBeNull();
    const pts = r.tris.flatMap((t) => [t.a, t.b, t.c]);
    // Sized to the opening: from -500 along the wall, up to 1400, 50 deep at the face.
    expect(Math.min(...pts.map((p) => p[0]))).toBeCloseTo(-500, 6);
    expect(Math.max(...pts.map((p) => p[1]))).toBeCloseTo(1400, 6);
    expect(Math.min(...pts.map((p) => p[2]))).toBeCloseTo(-50, 6);
    expect(r.polys[0].pts[2]).toEqual([500, 50]);
  });
});
