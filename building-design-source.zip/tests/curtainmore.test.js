import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { copyCellPattern, joinCurtainEnds, wallsToCurtain, accessoryBoxes, glazedRoofFrom, glazingGeometry, junctionPost, endFrameKeys } from '../src/core/curtainmore.js';
import { curtainGrid } from '../src/core/build3d.js';
import { wallAxis, verticalExtent } from '../src/core/model.js';
import { deleteElements } from '../src/core/ops.js';

const cw = (p, a, b) => p.wall(a, b, { typeId: 'wt-curtain', topLevelId: null, height: 3600 });
const gridOf = (doc, w) => {
  const ax = wallAxis(doc, w);
  const { base, top } = verticalExtent(doc, w);
  return curtainGrid(ax.length, top - base, doc.get(w.typeId), w);
};

describe('curtain wall extras', () => {
  it('copies a cell pattern along the wall', () => {
    const w = { panels: { '0:0': 'solid', '1:2': 'door' }, mullionsOff: ['v:1:2'] };
    const r = copyCellPattern(w, 6, 3, { i0: 0, i1: 1, j0: 0, j1: 2 }, { alongU: true });
    expect(r.panels['2:0']).toBe('solid');
    expect(r.panels['4:0']).toBe('solid');
    expect(r.panels['3:2']).toBe('door');
    expect(r.panels['5:2']).toBe('door');
    expect(r.mullionsOff).toContain('v:3:2');
    expect(r.mullionsOff).toContain('v:5:2');
  });

  it('shares frames in line and makes a corner post at an angle', () => {
    const p = project();
    const { doc } = p;
    const a = cw(p, [0, 0], [6000, 0]);
    const b = cw(p, [6000, 0], [12000, 0]);
    const c = cw(p, [12000, 0], [12000, 4500]);
    const n = doc.transact('j', () => joinCurtainEnds(doc, [a.id, b.id, c.id], (w) => gridOf(doc, w), { junction: true }));
    expect(n).toBe(2);
    const gb = gridOf(doc, doc.get(b.id));
    for (const k of endFrameKeys(gb.nu, gb.nv, 0)) expect(doc.get(b.id).mullionsOff).toContain(k);
    const j = doc.all('cwJunction');
    expect(j).toHaveLength(1);
    expect(j[0].at).toEqual([12000, 0]);
    const post = junctionPost(doc, j[0]);
    expect(post.outline).toHaveLength(4);
    expect(new Scene(doc).mesh(j[0]).pos.length).toBeGreaterThan(0);
    doc.transact('d', () => deleteElements(doc, [c.id]));
    expect(doc.all('cwJunction')).toHaveLength(0);
  });

  it('stops walls at the curtain wall face and adds accessories outside', () => {
    const p = project();
    const { doc } = p;
    const c = cw(p, [0, 0], [8000, 0]);
    const w = p.wall([3000, -4000], [3000, 300]); // runs through the curtain wall
    const patches = wallsToCurtain(doc, [w.id], [c.id]);
    expect(patches).toHaveLength(1);
    const md = doc.get('wt-curtain').curtain.mullionDepth;
    expect(patches[0].patch.b).toEqual([3000, -md / 2]);
    const boxes = accessoryBoxes({ kind: 'fins', depth: 300, width: 40 }, [0, 1500, 3000], [0, 1200, 2400], 50, 150);
    expect(boxes).toHaveLength(6);
    expect(boxes[0][1]).toBe(75);
    expect(boxes[0][4]).toBe(375);
  });

  it('turns a roof into a glazed roof with rafters up the slope', () => {
    const p = project();
    const { doc } = p;
    const roof = p.add({ kind: 'roof', typeId: doc.all('roofType')[0].id, levelId: p.L1.id, boundary: [[0, 0], [4000, 0], [4000, 3000], [0, 3000]], slopes: [null, null, 20, null], baseOffset: 2700 });
    const g = doc.transact('g', () => doc.add(glazedRoofFrom(doc.get(roof.id), { spacing: 1000, transoms: 0 })));
    const geo = glazingGeometry(doc, g);
    const rafters = geo.bars.filter((b) => b.kind === 'rafter');
    expect(rafters.length).toBe(3);
    // Rafters run up the slope: their ends are at different heights.
    expect(Math.abs(rafters[0].a[2] - rafters[0].b[2])).toBeGreaterThan(500);
    expect(new Scene(doc).mesh(g).pos.length).toBeGreaterThan(0);
  });
});
