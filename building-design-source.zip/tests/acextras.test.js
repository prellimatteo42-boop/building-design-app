import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { segmentsOf, WAND } from '../src/core/convert.js';
import { arrayLinear } from '../src/core/ops.js';
import { createGroup, groupable } from '../src/core/groups.js';
import { AC_MENUBAR, AC_TOOLBOX, AC_KEYMAP, AC_INFOBOX } from '../src/ui/acmenus.js';
import { COMMANDS } from '../src/commands.js';

describe('Archicad menus and extras', () => {
  it('every menu, toolbox and shortcut command exists in the app', () => {
    const cmds = [];
    const walk = (nodes) => nodes.forEach((n) => n && (n.items ? walk(n.items) : n.cmd && cmds.push(n.cmd)));
    AC_MENUBAR.forEach((m) => walk(m.items));
    AC_TOOLBOX.forEach((g) => g.tools.forEach((t) => t.cmd && cmds.push(t.cmd)));
    cmds.push(...Object.values(AC_KEYMAP));
    const missing = [...new Set(cmds)].filter((c) => !COMMANDS[c]);
    expect(missing).toEqual([]);
    expect(AC_MENUBAR.map((m) => m.label)).toEqual(['File', 'Edit', 'View', 'Design', 'Document', 'Options', 'Teamwork', 'Window', 'Help']);
    expect(AC_INFOBOX.wall.slice(0, 4)).toEqual(['Main', 'Layer', 'Reference Line Location', 'Geometry Method']);
  });

  it('Magic Wand Settings change how finely arcs are followed', () => {
    const arc = { kind: 'detailArc', c: [0, 0], r: 1000, a0: 0, a1: Math.PI };
    const saved = WAND.arcStep;
    WAND.arcStep = 10;
    expect(segmentsOf([arc])).toHaveLength(18);
    WAND.arcStep = 45;
    expect(segmentsOf([arc])).toHaveLength(4);
    WAND.arcStep = saved;
  });

  it('Autogroup groups what Multiply made', () => {
    const p = project();
    const w = p.wall([0, 0], [3000, 0]);
    const copies = p.doc.transact('a', () => {
      const out = arrayLinear(p.doc, [w.id], [0, 1000], 3);
      createGroup(p.doc, [w.id, ...out].filter((id) => groupable(p.doc.get(id))), { name: 'Multiply', levelId: p.L1.id });
      return out;
    });
    expect(copies).toHaveLength(2);
    expect(new Set(p.doc.all('wall').map((x) => x.groupId)).size).toBe(1);
    expect(p.doc.get(w.id).groupId).toBeTruthy();
  });
});

import { traceReference } from '../src/core/trace.js';
describe('trace source view', () => {
  it('a detail traces the view it comes from', () => {
    const p = project();
    const plan = p.doc.all('plan')[0];
    const detail = p.add({ kind: 'plan', name: 'Detail 1', levelId: plan.levelId, calloutOf: plan.id, crop: { x0: 0, y0: 0, x1: 1000, y1: 1000 } });
    expect(traceReference(p.doc, detail, { refId: 'source', on: true })?.id).toBe(plan.id);
  });
});
