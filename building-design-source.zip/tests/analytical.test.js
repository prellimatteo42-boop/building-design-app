import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { analyticalModel, safSheets, safMaterial } from '../src/core/analytical.js';
import { writeXLSX } from '../src/io/xlsx.js';

describe('structural analytical model', () => {
  it('walls meet the slab mid-plane, beams land on column axes, nodes are shared', () => {
    const p = project();
    const { doc, L1, L2 } = p;
    p.box(0, 0, 6000, 4000, { structural: true });
    const ft = doc.all('floorType')[0];
    const t = ft.layers?.reduce((s, l) => s + (+l.thickness || 0), 0) || 200;
    p.add({ kind: 'floor', typeId: ft.id, levelId: L2.id, offset: 0, boundary: [[0, 0], [6000, 0], [6000, 4000], [0, 4000]], structural: true });
    const ct = doc.all('columnType')[0];
    p.add({ kind: 'column', typeId: ct.id, levelId: L1.id, at: [3000, 2000], baseOffset: 0, topLevelId: L2.id, topOffset: 0 });
    const bt = doc.all('beamType')[0];
    p.add({ kind: 'beam', typeId: bt.id, levelId: L2.id, offset: -300, a: [3000 + 100, 2000], b: [6000, 2000] });
    p.add({ kind: 'structuralSupport', levelId: L1.id, offset: 0, at: [3000, 2000], fixity: 'fixed' });
    const am = analyticalModel(doc);
    expect(am.surfaces.filter((s) => s.type === 'Wall')).toHaveLength(4);
    const slab = am.surfaces.find((s) => s.type === 'Plate');
    const zMid = 3000 - t / 2;
    expect(slab.corners[0][2]).toBeCloseTo(zMid, 3);
    // Wall tops are on the slab's mid-plane, so wall and slab corners share nodes.
    const wall = am.surfaces.find((s) => s.type === 'Wall');
    expect(wall.corners[2][2]).toBeCloseTo(zMid, 3);
    expect(slab.nodes.every((n) => am.surfaces.filter((s) => s.type === 'Wall').some((w) => w.nodes.includes(n)))).toBe(true);
    // The column reaches the slab; the beam starts on the column axis, as an internal node of it.
    const col = am.members.find((m) => m.type === 'Column');
    expect(col.b[2]).toBeCloseTo(zMid, 3);
    const beam = am.members.find((m) => m.type === 'Beam');
    expect(beam.a.slice(0, 2)).toEqual([3000, 2000]);
    expect(col.internalNodes).toContain(beam.nodes[0]);
    expect(am.supports).toEqual([{ name: 'PS1', node: col.nodes[0], fixity: 'fixed' }]);
    // The workbook has the SAF sheets.
    const sheets = safSheets(am, { projectName: 'Test' });
    const names = sheets.map((s) => s.name);
    for (const n of ['Model', 'StructuralMaterial', 'StructuralCrossSection', 'StructuralPointConnection', 'StructuralCurveMember', 'StructuralSurfaceMember', 'StructuralPointSupport', 'StructuralLoadCase']) expect(names).toContain(n);
    const nodesSheet = sheets.find((s) => s.name === 'StructuralPointConnection');
    expect(nodesSheet.rows[0].cells).toEqual(['Name', 'Coordinate X [m]', 'Coordinate Y [m]', 'Coordinate Z [m]']);
    expect(nodesSheet.rows.length - 1).toBe(am.nodes.length);
    expect(writeXLSX(sheets).length).toBeGreaterThan(1000);
  });

  it('takes every wall when none is marked, and maps materials', () => {
    const p = project();
    p.box(0, 0, 4000, 4000);
    const am = analyticalModel(p.doc);
    expect(am.surfaces).toHaveLength(4);
    expect(am.notes[0]).toMatch(/No wall or slab is marked/);
    expect(safMaterial({ name: 'Structural Steel' }).type).toBe('Steel');
    expect(safMaterial({ name: 'Glulam' })).toMatchObject({ type: 'Timber', quality: 'C24' });
  });
});

describe('member end releases', () => {
  it('a hinged beam is written to RelConnectsStructuralMember', () => {
    const p = project();
    const bt = p.doc.all('beamType')[0];
    p.add({ kind: 'beam', typeId: bt.id, levelId: p.L2.id, offset: 0, a: [0, 0], b: [5000, 0], endRelease: 'both' });
    const am = analyticalModel(p.doc);
    const rel = safSheets(am).find((s) => s.name === 'RelConnectsStructuralMember');
    expect(rel.rows[1].cells).toEqual(['H1', 'B1', 'Both', 'Rigid', 'Rigid', 'Rigid', 'Rigid', 'Free', 'Free']);
  });
});

describe('line loads in SAF', () => {
  it('a line load on a beam and on a wall becomes a StructuralCurveAction', () => {
    const p = project();
    const bt = p.doc.all('beamType')[0];
    const beam = p.add({ kind: 'beam', typeId: bt.id, levelId: p.L2.id, offset: 0, a: [0, 0], b: [5000, 0] });
    const w = p.wall([0, 3000], [5000, 3000]);
    p.add({ kind: 'structuralLoad', type: 'line', levelId: p.L2.id, offset: 0, a: [0, 0], b: [5000, 0], value: 5, loadCase: 'live', hostId: beam.id });
    p.add({ kind: 'structuralLoad', type: 'line', levelId: p.L2.id, offset: 0, a: [0, 3000], b: [5000, 3000], value: 3, loadCase: 'dead', hostId: w.id });
    const am = analyticalModel(p.doc);
    const sheet = safSheets(am).find((s) => s.name === 'StructuralCurveAction');
    const rows = sheet.rows.slice(1).map((r) => r.cells);
    expect(rows).toHaveLength(2);
    expect(rows.find((r) => r[2] === 'On beam')).toMatchObject({ 5: -5, 6: 'B1', 9: 'Q' });
    expect(rows.find((r) => r[2] === 'On edge')).toMatchObject({ 5: -3, 7: 'W1', 8: 3, 9: 'G2' });
    expect(am.notes.join(' ')).not.toMatch(/line load/i);
  });
});

describe('generation rules', () => {
  it('only marked walls, and no meeting with slabs', () => {
    const p = project();
    p.box(0, 0, 4000, 4000);
    const ft = p.doc.all('floorType')[0];
    p.add({ kind: 'floor', typeId: ft.id, levelId: p.L2.id, offset: 0, boundary: [[0, 0], [4000, 0], [4000, 4000], [0, 4000]] });
    expect(analyticalModel(p.doc, { bearing: 'marked' }).surfaces).toHaveLength(0);
    const free = analyticalModel(p.doc, { meetSlabs: false });
    expect(free.surfaces.find((s) => s.type === 'Wall').corners[2][2]).toBeCloseTo(3000, 6);
    p.doc.transact('rules', () => p.doc.update('project', { analyticalRules: { bearing: 'marked' } }));
    expect(analyticalModel(p.doc).surfaces).toHaveLength(0);
  });
});
