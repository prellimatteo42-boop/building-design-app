import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { expressionValue, expressionText, paramDescriptors, paramFields } from '../src/core/params.js';
import { resolveAutotext } from '../src/core/autotext.js';
import { scheduleRows } from '../src/core/schedule.js';

describe('expression parameters', () => {
  const setup = () => {
    const p = project();
    const { doc, add, box, L1, wall } = p;
    box(0, 0, 5000, 4000);
    const room = add({ kind: 'room', levelId: L1.id, at: [2500, 2000], name: 'Kitchen', number: '3', upperOffset: 2700 });
    const w = wall([10000, 0], [14000, 0]);
    let fin, size, tag, self;
    doc.transact('params', () => {
      fin = doc.add({ kind: 'projectParam', name: 'Finish Factor', type: 'number', categories: ['rooms'] });
      size = doc.add({ kind: 'projectParam', name: 'Finish Area', type: 'expression', expression: '{Area} * {Finish Factor}', result: 'area', categories: ['rooms'] });
      tag = doc.add({ kind: 'projectParam', name: 'Size Class', type: 'expression', expression: 'IF({Finish Area} > 20, "Large", "Small") & " " & UPPER({Name})', result: 'text', categories: ['rooms'] });
      self = doc.add({ kind: 'projectParam', name: 'Loop', type: 'expression', expression: '{Loop} + 1', result: 'number', categories: ['walls'] });
      doc.update(room.id, { params: { [fin.id]: 1.5 } });
    });
    const scene = new Scene(doc);
    return { ...p, scene, room: doc.get(room.id), w: doc.get(w.id), fin, size, tag, self };
  };

  it('compute from fields and other parameters, in SI units', () => {
    const { doc, scene, room, size, tag } = setup();
    const area = scene.rooms.room(room).area;
    const v = expressionValue({ doc, scene }, room, size);
    expect(v.value).toBeCloseTo(area * 1.5, 0);
    expect(expressionValue({ doc, scene }, room, tag).value).toBe(`${area * 1.5 > 20e6 ? 'Large' : 'Small'} KITCHEN`);
    expect(expressionText({ doc, scene }, room, size)).toMatch(/m²/);
  });

  it('report errors and loops instead of failing', () => {
    const { doc, scene, w, self } = setup();
    expect(expressionValue({ doc, scene }, w, self).error).toMatch(/refers to itself/);
    doc.transact('bad', () => doc.update(self.id, { expression: '{Length} +' }));
    expect(expressionText({ doc, scene }, w, doc.get(self.id))).toMatch(/^Error:/);
    doc.transact('ok', () => doc.update(self.id, { expression: 'ROUND({Length} * 2, 1)' }));
    expect(expressionValue({ doc, scene }, w, doc.get(self.id)).value).toBe(8);
  });

  it('show read-only in properties and computed in schedules and autotext', () => {
    const { doc, scene, room, size, tag } = setup();
    const d = paramDescriptors(doc, room).find((x) => x.key === `param:${size.id}`);
    expect(d.type).toBe('readonly');
    expect(d.get(room, { doc, scene })).toMatch(/m²/);
    const f = paramFields(doc, ['room'], () => 'rooms').find((x) => x.id === `param:${size.id}`);
    expect(f.type).toBe('area');
    expect(f.get(room, { doc, scene })).toBeGreaterThan(1e6);
    expect(resolveAutotext({ doc, scene }, room, '{Size Class}')).toMatch(/KITCHEN$/);
    const view = { kind: 'schedule', category: 'room', fields: ['name', `param:${size.id}`, `param:${tag.id}`] };
    const rows = scheduleRows({ doc, scene }, view);
    expect(rows[0].values[`param:${tag.id}`]).toMatch(/KITCHEN/);
  });
});
