import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { transferPatch } from '../src/editor/modify.js';
import { temporaryDimensions, GUIDES } from '../src/editor/tempdims.js';
import { readColorTable } from '../src/ui/groupa.js';
import { regionPattern, FILL_LOOK } from '../src/core/plan.js';

describe('group A', () => {
  it('Element Transfer Settings choose what Inject carries', () => {
    const src = { kind: 'wall', typeId: 't2', layerId: 'L2', height: 2800, baseOffset: 100, paintId: 'p1', a: [0, 0], b: [1, 0] };
    expect(transferPatch(src, {}, {})).toEqual({ typeId: 't2', layerId: 'L2', height: 2800, baseOffset: 100, paintId: 'p1' });
    expect(transferPatch(src, {}, { heights: false, surfaces: false, layer: false })).toEqual({ typeId: 't2' });
  });

  it('distance guides to the opening centre and to reference lines', () => {
    const p = project();
    const w = p.wall([0, 0], [5000, 0]);
    const win = p.add({ kind: 'window', typeId: p.doc.all('windowType')[0].id, hostId: w.id, levelId: p.L1.id, t: 2000, width: 1000 });
    expect(temporaryDimensions(p.doc, p.doc.get(win.id)).map((d) => Math.round(d.value))).toEqual([1500, 2500]);
    GUIDES.center = true;
    expect(temporaryDimensions(p.doc, p.doc.get(win.id)).map((d) => Math.round(d.value))).toEqual([2000, 3000]);
    GUIDES.center = false;
    GUIDES.refLines = true;
    expect(temporaryDimensions(p.doc, p.doc.get(w.id))[0].a).toEqual([0, 0]);
    GUIDES.refLines = false;
  });

  it('reads colour tables and simplifies fills', () => {
    const c = readColorTable('RAL 3020 Traffic red #CC0605\nRAL 9010;Pure white;241;236;225\n\nrubbish');
    expect(c).toEqual([{ name: 'RAL 3020 Traffic red', color: '#cc0605' }, { name: 'RAL 9010 Pure white', color: '#f1ece1' }]);
    const p = project();
    expect(regionPattern(p.doc, 'concrete')).toBeGreaterThan(0);
    FILL_LOOK.simplified = true;
    expect(regionPattern(p.doc, 'concrete')).toBe(0);
    FILL_LOOK.simplified = false;
  });
});

import { patchPieces } from '../src/ui/patch.js';
describe('create patch', () => {
  it('clips the drawing to the rectangle on a cover fill', () => {
    const parts = { lines: [{ a: [0, 0], b: [2000, 0], style: 'thin' }, { a: [5000, 5000], b: [6000, 5000] }], fills: [{ boundary: [[-100, -100], [500, -100], [500, 500], [-100, 500]], pattern: 'concrete' }] };
    const p = patchPieces(parts, { x0: 0, y0: -50, x1: 1000, y1: 1000 }, 'v1');
    expect(p[0]).toMatchObject({ kind: 'region', cover: true });
    expect(p.filter((x) => x.kind === 'detailLine')).toHaveLength(1);
    expect(p.find((x) => x.kind === 'detailLine').b).toEqual([1000, 0]);
    expect(new Set(p.map((x) => x.patchId)).size).toBe(1);
  });
});
