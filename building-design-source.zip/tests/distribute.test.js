import { describe, it, expect } from 'vitest';
import { alignMoves, distributeMoves } from '../src/core/distribute.js';

const box = (id, x0, y0, w, h) => ({ id, x0, y0, x1: x0 + w, y1: y0 + h });

describe('align and distribute', () => {
  it('align sides and centres', () => {
    const bs = [box('a', 0, 0, 100, 100), box('b', 500, 300, 200, 100)];
    expect(alignMoves(bs, 'left').map((m) => m.d)).toEqual([[0, 0], [-500, 0]]);
    expect(alignMoves(bs, 'top').map((m) => m.d)).toEqual([[0, 300], [0, 0]]);
    expect(alignMoves(bs, 'centerX')[1].d[0]).toBe(350 - 600);
  });

  it('space gaps or centres evenly between the outermost', () => {
    const bs = [box('a', 0, 0, 100, 10), box('c', 1000, 0, 100, 10), box('b', 150, 0, 300, 10)];
    const m = Object.fromEntries(distributeMoves(bs, 'x').map((x) => [x.id, x.d]));
    // Gaps: (1100 - 500) / 2 = 300, so b starts at 400.
    expect(m.a).toEqual([0, 0]);
    expect(m.c).toEqual([0, 0]);
    expect(m.b).toEqual([250, 0]);
    const c = Object.fromEntries(distributeMoves(bs, 'x', 'centers').map((x) => [x.id, x.d]));
    expect(c.b[0]).toBe(550 - 300);
    expect(distributeMoves(bs.slice(0, 2), 'x')).toEqual([]);
  });
});
