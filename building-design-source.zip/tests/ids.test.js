import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { parseIDS, checkIDS, valueMatches, parseXML } from '../src/core/ids.js';

const IDS = `<?xml version="1.0" encoding="UTF-8"?>
<ids:ids xmlns:ids="http://standards.buildingsmart.org/IDS" xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <ids:info><ids:title>Test &amp; check</ids:title></ids:info>
  <ids:specifications>
    <ids:specification name="Walls have a fire rating" ifcVersion="IFC4">
      <ids:applicability minOccurs="1" maxOccurs="unbounded">
        <ids:entity><ids:name><ids:simpleValue>IFCWALL</ids:simpleValue></ids:name></ids:entity>
      </ids:applicability>
      <ids:requirements>
        <ids:property dataType="IFCLABEL" cardinality="required">
          <ids:propertySet><ids:simpleValue>Fire Safety</ids:simpleValue></ids:propertySet>
          <ids:baseName><ids:simpleValue>Fire Rating</ids:simpleValue></ids:baseName>
          <ids:value><xs:restriction base="xs:string"><xs:enumeration value="EI 60"/><xs:enumeration value="EI 120"/></xs:restriction></ids:value>
        </ids:property>
        <ids:attribute cardinality="required"><ids:name><ids:simpleValue>Tag</ids:simpleValue></ids:name>
          <ids:value><xs:restriction base="xs:string"><xs:pattern value="W[0-9]{2}"/></xs:restriction></ids:value></ids:attribute>
        <ids:partOf relation="IFCRELCONTAINEDINSPATIALSTRUCTURE"><ids:entity><ids:name><ids:simpleValue>IFCBUILDINGSTOREY</ids:simpleValue></ids:name></ids:entity></ids:partOf>
      </ids:requirements>
    </ids:specification>
    <ids:specification name="No proxies" ifcVersion="IFC4">
      <ids:applicability minOccurs="0" maxOccurs="0">
        <ids:entity><ids:name><ids:simpleValue>IFCBUILDINGELEMENTPROXY</ids:simpleValue></ids:name></ids:entity>
      </ids:applicability>
      <ids:requirements/>
    </ids:specification>
    <ids:specification name="Doors classified" ifcVersion="IFC4">
      <ids:applicability minOccurs="0" maxOccurs="unbounded">
        <ids:entity><ids:name><ids:simpleValue>IFCDOOR</ids:simpleValue></ids:name></ids:entity>
      </ids:applicability>
      <ids:requirements>
        <ids:classification><ids:value><xs:restriction base="xs:string"><xs:pattern value="20\\..*"/></xs:restriction></ids:value></ids:classification>
        <ids:property cardinality="prohibited"><ids:propertySet><ids:simpleValue>Fire Safety</ids:simpleValue></ids:propertySet><ids:baseName><ids:simpleValue>Fire Rating</ids:simpleValue></ids:baseName></ids:property>
      </ids:requirements>
    </ids:specification>
  </ids:specifications>
</ids:ids>`;

describe('IDS', () => {
  it('reads the file: specifications, uses, facets and restrictions', () => {
    const ids = parseIDS(IDS);
    expect(ids.title).toBe('Test & check');
    expect(ids.specifications.map((s) => s.use)).toEqual(['required', 'prohibited', 'optional']);
    const prop = ids.specifications[0].requirements[0];
    expect(prop).toMatchObject({ facet: 'property', propertySet: { simple: 'Fire Safety' }, value: { enumeration: ['EI 60', 'EI 120'] } });
    expect(parseXML('<a x="1"><b/>t</a>').children[0]).toMatchObject({ name: 'a', attrs: { x: '1' }, text: 't' });
  });

  it('values: numbers with tolerance, patterns, bounds, booleans', () => {
    expect(valueMatches({ simple: '30' }, 30.0000001)).toBe(true);
    expect(valueMatches({ pattern: ['DT[0-9]{2}'] }, 'DT05')).toBe(true);
    expect(valueMatches({ pattern: ['DT[0-9]{2}'] }, 'DT5')).toBe(false);
    expect(valueMatches({ minExclusive: 0.5, maxExclusive: 2.1 }, 1.4)).toBe(true);
    expect(valueMatches({ minExclusive: 0.5, maxExclusive: 2.1 }, 2.1)).toBe(false);
    expect(valueMatches({ simple: 'TRUE' }, true)).toBe(true);
  });

  it('checks the model as it exports to IFC', () => {
    const p = project();
    const { doc } = p;
    const a = p.wall([0, 0], [5000, 0], { mark: 'W01' });
    const b = p.wall([5000, 0], [5000, 4000], { mark: 'wall-b' });
    p.add({ kind: 'door', typeId: 'dt-single-36', hostId: a.id, t: 2000, levelId: p.L1.id });
    doc.transact('props', () => {
      doc.add({ kind: 'propertyGroup', name: 'Fire Safety' });
      const fr = doc.add({ kind: 'projectParam', name: 'Fire Rating', type: 'text', categories: ['walls'], group: 'Fire Safety' });
      doc.update(a.id, { params: { [fr.id]: 'EI 60' } });
      doc.update(b.id, { params: { [fr.id]: 'EI 30' } });
    });
    const r = checkIDS(doc, parseIDS(IDS));
    const [walls, proxies, doors] = r.specifications;
    expect(walls.applicable).toBe(2);
    expect(walls.passed).toBe(1);
    expect(walls.failed).toHaveLength(1);
    expect(walls.failed[0].id).toBe(b.id);
    expect(walls.failed[0].reasons.join(' ')).toMatch(/EI 30/);
    expect(walls.failed[0].reasons.join(' ')).toMatch(/wall-b/);
    expect(proxies.ok).toBe(true);
    expect(doors).toMatchObject({ applicable: 1, passed: 1, ok: true });
    expect(r.ok).toBe(false);
  });
});
