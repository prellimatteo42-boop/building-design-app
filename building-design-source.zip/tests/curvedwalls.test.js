import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { wallAxis } from '../src/core/model.js';
import { WallSolver } from '../src/core/walls.js';
import { RoomSolver } from '../src/core/rooms.js';
import { planGraphics, planContext } from '../src/core/plan.js';
import { build3D } from '../src/core/build3d.js';

/** A 6 x 4 m room closed on the north by a half circle bulging outward. */
function apse() {
  const p = project();
  const s = p.wall([0, 0], [6000, 0]);
  const e = p.wall([6000, 0], [6000, 4000]);
  // From (6000,4000) to (0,4000) turning left (counterclockwise) bulges north.
  const n = p.wall([6000, 4000], [0, 4000], { arc: Math.PI });
  const w = p.wall([0, 4000], [0, 0]);
  return { p, s, e, n, w };
}

describe('curved walls', () => {
  it('have an arc axis as long as the arc', () => {
    const { p, n } = apse();
    const ax = wallAxis(p.doc, p.doc.get(n.id));
    expect(ax.curve.r).toBeCloseTo(3000, 6);
    expect(ax.length).toBeCloseTo(3000 * Math.PI, 3);
  });

  it('join the straight walls at their ends', () => {
    const { p, n } = apse();
    const g = new WallSolver(p.doc).level(p.L1.id).walls.get(n.id);
    expect(g.ends.map((e) => e.kind)).toEqual(['corner', 'corner']);
    expect(g.poly.length).toBeGreaterThan(20);
  });

  it('bound rooms along the curve', () => {
    const { p } = apse();
    const room = p.add({ kind: 'room', levelId: p.L1.id, at: [3000, 2000], name: 'Apse' });
    const r = new RoomSolver(p.doc, new WallSolver(p.doc)).room(room);
    // Inside faces (200 thick walls, centred): 5.8 x 3.9 m plus a half disc of radius 2.9 m, about.
    const expected = 5800 * 3900 + (Math.PI * 2900 * 2900) / 2;
    expect(r.area).toBeGreaterThan(expected * 0.97);
    expect(r.area).toBeLessThan(expected * 1.03);
  });

  it('draw in plan and build in 3D with a window', () => {
    const { p, n } = apse();
    const win = p.add({ kind: 'window', typeId: p.doc.all('windowType')[0].id, hostId: n.id, levelId: p.L1.id, t: 3000 * Math.PI / 2 });
    const walls = new WallSolver(p.doc);
    const plan = p.doc.all('plan').find((v) => v.levelId === p.L1.id);
    const pc = planContext(p.doc, plan, walls, new RoomSolver(p.doc, walls));
    const g = planGraphics(pc, p.doc.get(n.id));
    expect(g.fills.length).toBe(2);
    expect(g.lines.length).toBeGreaterThan(40);
    const ctx = { doc: p.doc, walls, material: (id) => p.doc.get(id) };
    const mesh = build3D(ctx, p.doc.get(n.id));
    expect(mesh.pos.length).toBeGreaterThan(1000);
    // The window sits on the top of the arc, along its tangent (east-west).
    const wm = build3D(ctx, p.doc.get(win.id));
    let ymin = Infinity;
    let ymax = -Infinity;
    for (let i = 1; i < wm.pos.length; i += 3) {
      ymin = Math.min(ymin, wm.pos[i]);
      ymax = Math.max(ymax, wm.pos[i]);
    }
    expect((ymin + ymax) / 2).toBeGreaterThan(6800);
    expect(ymax - ymin).toBeLessThan(400);
  });
});

describe('curved wall editing', () => {
  it('split into two arcs that keep the bend', async () => {
    const { splitWall } = await import('../src/core/ops.js');
    const { p, n } = apse();
    let second;
    p.doc.transact('split', () => (second = splitWall(p.doc, p.doc.get(n.id), [3000, 7000])));
    const first = p.doc.get(n.id);
    expect(first.arc + second.arc).toBeCloseTo(Math.PI, 9);
    expect(first.b[0]).toBeCloseTo(3000, 3);
    expect(first.b[1]).toBeCloseTo(7000, 3);
  });

  it('turn the other way when mirrored, and measure their arc', async () => {
    const { transformPatch } = await import('../src/core/ops.js');
    const { wallLength } = await import('../src/core/model.js');
    const { p, n } = apse();
    const xf = { point: (q) => [q[0], -q[1]], mirror: true, mirrorAngle: (d) => -d, angle: 0 };
    expect(transformPatch(p.doc.get(n.id), xf).arc).toBeCloseTo(-Math.PI, 9);
    expect(wallLength(p.doc.get(n.id))).toBeCloseTo(3000 * Math.PI, 3);
  });
});
