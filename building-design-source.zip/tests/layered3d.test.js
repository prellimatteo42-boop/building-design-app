import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { WallSolver } from '../src/core/walls.js';
import { build3D } from '../src/core/build3d.js';
import { sectionCuts, viewFrame } from '../src/core/elevation.js';
import { W } from '../src/core/plan.js';

function setup(typeId) {
  const p = project();
  const w = p.wall([0, 0], [6000, 0], { typeId });
  const ctx = { doc: p.doc, walls: new WallSolver(p.doc), material: (id) => p.doc.get(id) };
  const mesh = build3D(ctx, p.doc.get(w.id));
  // A section across the wall at x = 3000, looking along +x.
  const frame = viewFrame({ kind: 'section', a: [3000, -2000], b: [3000, 2000], depth: 5000 });
  const cut = (detail) => sectionCuts(p.doc, frame, (el) => (el.id === w.id ? mesh : null), detail).find((c) => c.id === w.id);
  return { p, w, mesh, cut };
}

describe('layered walls in 3D', () => {
  it('build one solid per layer, each triangle tagged with its layer', () => {
    const { mesh } = setup('wt-ext-concrete');
    expect(mesh.partMaterials).toEqual(['mat-plaster', 'mat-concrete', 'mat-gypsum']);
    expect(mesh.parts.length * 9).toBe(mesh.pos.length);
    expect(new Set(mesh.parts)).toEqual(new Set([0, 1, 2]));
  });

  it('cut in sections layer by layer: material fills, thin lines between layers', () => {
    const { cut } = setup('wt-ext-concrete');
    const g = cut('fine').g;
    expect(g.fills.length).toBe(3);
    const thin = g.lines.filter((l) => l.w === W.thin);
    const heavy = g.lines.filter((l) => l.w === W.cut);
    expect(thin.length).toBe(2);
    // Outline: two sides and the top and bottom of each layer.
    expect(heavy.length).toBe(8);
    // At medium detail one poche without lines between layers.
    expect(cut('medium').g.lines.filter((l) => l.w === W.thin).length).toBe(0);
  });

  it('keep single-layer walls as before', () => {
    const { mesh, cut } = setup('wt-generic');
    expect(mesh.parts).toBeUndefined();
    expect(cut('fine').g.fills.length).toBe(1);
  });

  it('follow the partial structure display in section cuts', () => {
    const { p, w, mesh } = setup('wt-ext-concrete');
    const frame = viewFrame({ kind: 'section', a: [3000, -2000], b: [3000, 2000], depth: 5000 });
    const cut = (show) => sectionCuts(p.doc, frame, (el) => (el.id === w.id ? mesh : null), 'fine', show).find((c) => c.id === w.id);
    expect(cut('core').g.fills.length).toBe(1);
    // The core alone: its whole outline is cut lines.
    expect(cut('core').g.lines.every((l) => l.w === W.cut)).toBe(true);
    expect(cut('coreLoadBearing')).toBeUndefined();
  });
});

describe('partial structure display in 3D', () => {
  const build = (p, w, show) => build3D({ doc: p.doc, walls: new WallSolver(p.doc), material: (id) => p.doc.get(id), show }, p.doc.get(w.id));

  it('builds only the shown layers, each with its own edges', () => {
    const p = project();
    const w = p.wall([0, 0], [6000, 0], { typeId: 'wt-ext-concrete' });
    const full = build(p, w, 'entire');
    const core = build(p, w, 'core');
    expect(new Set(core.parts)).toEqual(new Set([1]));
    expect(core.pos.length).toBeLessThan(full.pos.length);
    // Edges at the concrete faces (y = 121.5 and -128.5), none at the plaster face.
    const ys = new Set();
    for (let i = 1; i < core.edges.length; i += 3) ys.add(Math.round(core.edges[i] * 10) / 10);
    expect(ys).toEqual(new Set([121.5, -128.5]));
  });

  it('leaves out walls with nothing to show', () => {
    const p = project();
    const w = p.wall([0, 0], [6000, 0], { typeId: 'wt-ext-concrete' });
    expect(build(p, w, 'coreLoadBearing')).toBe(null);
    const part = p.wall([0, 3000], [6000, 3000], { typeId: 'wt-generic' });
    // A single-layer wall is all core.
    expect(build(p, part, 'core')).not.toBe(null);
  });
});

describe('openings under partial structure display', () => {
  it('span only the shown layers in plan and 3D', async () => {
    const { shownSpan } = await import('../src/core/layerjoins.js');
    const p = project();
    const w = p.wall([0, 0], [6000, 0], { typeId: 'wt-ext-concrete' });
    // 20 plaster + 250 concrete + 13 plasterboard = 283, half 141.5: the concrete spans 121.5 to -128.5.
    expect(shownSpan(p.doc, p.doc.get(w.id), 'core', 141.5)).toEqual({ lo: -128.5, hi: 121.5 });
    expect(shownSpan(p.doc, p.doc.get(w.id), 'entire', 141.5)).toEqual({ lo: -141.5, hi: 141.5 });
    expect(shownSpan(p.doc, p.doc.get(w.id), 'coreLoadBearing', 141.5)).toBe(null);
    const win = p.add({ kind: 'window', typeId: p.doc.all('windowType')[0].id, hostId: w.id, levelId: p.L1.id, t: 3000, sillBoard: false });
    const ctx = (show) => ({ doc: p.doc, walls: new WallSolver(p.doc), material: (id) => p.doc.get(id), show });
    const depth = (m) => {
      let lo = Infinity;
      let hi = -Infinity;
      for (let i = 1; i < m.pos.length; i += 3) {
        lo = Math.min(lo, m.pos[i]);
        hi = Math.max(hi, m.pos[i]);
      }
      return [lo, hi];
    };
    const full = depth(build3D(ctx('entire'), p.doc.get(win.id)));
    const core = depth(build3D(ctx('core'), p.doc.get(win.id)));
    // A window keeps its frame depth and its place at the outer face of what is shown: 20 of plaster in.
    expect(Math.abs((core[0] + core[1]) / 2 - (full[0] + full[1]) / 2)).toBeCloseTo(20, 3);
    expect(build3D(ctx('coreLoadBearing'), p.doc.get(win.id))).toBe(null);
  });
});
