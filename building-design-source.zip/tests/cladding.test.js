import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { WallSolver } from '../src/core/walls.js';
import { build3D } from '../src/core/build3d.js';
import { claddingGeometry, outerSide as outerSideFn } from '../src/core/cladding.js';

const setup = (extra = {}) => {
  const p = project();
  const w = p.wall([0, 0], [4000, 0]);
  const type = p.doc.all('windowType')[0];
  p.add({ kind: 'window', typeId: type.id, hostId: w.id, t: 2000, width: 1200, sill: 900 });
  const c = p.add({ kind: 'wallCladding', wallId: w.id, side: 'exterior', pattern: 'horizontal', board: 150, gap: 10, thickness: 20, cavity: 30, materialId: 'mat-wood', ...extra });
  const ctx = { doc: p.doc, walls: new WallSolver(p.doc), material: (id) => p.doc.get(id) };
  return { p, w, c, ctx };
};

describe('Wall accessories (cladding)', () => {
  it('runs boards along the face and leaves the window open', () => {
    const { p, c } = setup();
    const g = claddingGeometry(p.doc, p.doc.get(c.id));
    expect(g.pieces.length).toBeGreaterThan(10);
    // Nothing covers the window (centre at 2000, 900..2100 up), with the gap round it.
    for (const [t0, t1, z0, z1] of g.pieces) expect(t1 <= 1390 || t0 >= 2610 || z1 <= 890 || z0 >= 2110).toBe(true);
    // Boards above and beside it are still there.
    expect(g.pieces.some(([t0, t1, z0]) => t0 < 1000 && t1 > 1300 && z0 > 1000 && z0 < 2000)).toBe(true);
    expect(g.pieces.some(([t0, t1, z0]) => t0 <= 1500 && t1 >= 2500 && z0 > 2100)).toBe(true);
    // Each board is 140 high (150 less the gap).
    const full = g.pieces.find(([t0, t1]) => t0 === 0 && t1 === 4000);
    expect(full[3] - full[2]).toBe(140);
  });

  it('builds boards off the face on battens', () => {
    const { p, w, c, ctx } = setup();
    const mesh = build3D(ctx, p.doc.get(c.id));
    expect(mesh.pos.length).toBeGreaterThan(0);
    // The wall's face plane is at |y| = half its thickness; boards reach cavity + thickness beyond it.
    const half = (p.doc.get(w.id).thickness ?? p.doc.get(p.doc.get(w.id).typeId)?.thickness ?? 200) / 2;
    let far = 0;
    for (let i = 1; i < mesh.pos.length; i += 3) far = Math.max(far, Math.abs(mesh.pos[i]));
    expect(far).toBeGreaterThan(half + 40);
    expect(far).toBeLessThan(half + 60);
  });

  it('cuts vertical boards and panels round the window too', () => {
    for (const pattern of ['vertical', 'panels']) {
      const { p, c } = setup({ pattern, board: pattern === 'panels' ? 1000 : 120 });
      const g = claddingGeometry(p.doc, p.doc.get(c.id));
      expect(g.pieces.length).toBeGreaterThan(4);
      for (const [t0, t1, z0, z1] of g.pieces) expect(t1 <= 1390 || t0 >= 2610 || z1 <= 890 || z0 >= 2110).toBe(true);
    }
  });

  it('follows the wall when it moves', () => {
    const { p, w, c } = setup();
    p.doc.transact('move', () => p.doc.update(w.id, { b: [6000, 0] }));
    const g = claddingGeometry(p.doc, p.doc.get(c.id));
    expect(Math.max(...g.pieces.map((r) => r[1]))).toBe(6000);
  });
});

describe('Wall accessories side', () => {
  it('goes on the face out of the building whichever way the walls were drawn', async () => {
    const { outerSide } = await import('../src/core/cladding.js');
    for (const ccw of [true, false]) {
      const p = project();
      const pts = ccw ? [[0, 0], [6000, 0], [6000, 4000], [0, 4000]] : [[0, 0], [0, 4000], [6000, 4000], [6000, 0]];
      const ws = pts.map((a, i) => p.wall(a, pts[(i + 1) % 4]));
      const w = ws.find((x) => x.a[1] === 0 && x.b[1] === 0);
      const c = p.add({ kind: 'wallCladding', wallId: w.id, side: outerSide(p.doc, p.doc.get(w.id)) });
      const g = claddingGeometry(p.doc, p.doc.get(c.id));
      // Outside the box is y < 0.
      expect(g.face(1000, 0)[1]).toBeLessThan(0);
    }
  });
});

describe('Wall accessories at corners', () => {
  it('runs round the outside corner: one laps the other, which butts against its back', async () => {
    const { outerSide } = await import('../src/core/cladding.js');
    const p = project();
    const pts = [[0, 0], [6000, 0], [6000, 4000], [0, 4000]];
    const ws = pts.map((a, i) => p.wall(a, pts[(i + 1) % 4]));
    const [s, e] = ws.map((w) => p.doc.get(w.id));
    const half = (s.thickness ?? p.doc.get(s.typeId)?.thickness ?? 200) / 2;
    const cs = p.add({ kind: 'wallCladding', wallId: s.id, side: outerSide(p.doc, s), cavity: 30, thickness: 20 });
    const ce = p.add({ kind: 'wallCladding', wallId: e.id, side: outerSide(p.doc, e), cavity: 30, thickness: 20 });
    const gs = claddingGeometry(p.doc, p.doc.get(cs.id));
    const ge = claddingGeometry(p.doc, p.doc.get(ce.id));
    // South wall's boards run past x = 6000 over the east wall and its cladding; at x = 0 they meet the west face.
    expect(gs.hi).toBeCloseTo(4000 + 2000 + half + 50, 3);
    expect(gs.lo).toBeCloseTo(-half, 3);
    // East wall's start butts against the back of the south boards (its face plus the cavity).
    expect(ge.lo).toBeCloseTo(-(half + 30), 3);
  });
});

describe('Wall accessories on curved walls', () => {
  it('follow the arc of the face, in short steps, cut round a window', async () => {
    const { arcOf } = await import('../src/core/arc.js');
    const p = project();
    const w = p.wall([0, 0], [6000, 0], { arc: Math.PI / 2 });
    p.add({ kind: 'window', typeId: p.doc.all('windowType')[0].id, hostId: w.id, t: 3000, width: 1200, sill: 900 });
    const c = p.add({ kind: 'wallCladding', wallId: w.id, side: 'exterior', cavity: 30, thickness: 20 });
    const g = claddingGeometry(p.doc, p.doc.get(c.id));
    expect(g.pieces.length).toBeGreaterThan(10);
    expect(g.steps(0, 3000).length).toBeGreaterThan(10);
    // Every point of the boards' back is at one distance from the arc's centre.
    const arc = arcOf([0, 0], [6000, 0], Math.PI / 2);
    const rs = g.steps(0, g.length).map((t) => Math.hypot(...[0, 1].map((k) => g.face(t, 30)[k] - arc.c[k])));
    expect(Math.max(...rs) - Math.min(...rs)).toBeLessThan(1e-6);
    expect(Math.abs(rs[0] - arc.r)).toBeCloseTo(130, 3);
    const ctx = { doc: p.doc, walls: new WallSolver(p.doc), material: (id) => p.doc.get(id) };
    expect(build3D(ctx, p.doc.get(c.id)).pos.length).toBeGreaterThan(1000);
  });
});

describe('Wall accessories on curved walls at corners', () => {
  it('run on to the face of a straight wall joined at the arc\'s end', () => {
    const p = project();
    // A quarter arc from (0, 0) to (4000, 4000) bulging out, then a straight wall on from its end.
    const w = p.wall([0, 0], [4000, 4000], { arc: -Math.PI / 2 });
    const s = p.wall([4000, 4000], [8000, 4000]);
    const side = (id) => outerSideOf(p, id);
    const c = p.add({ kind: 'wallCladding', wallId: w.id, side: side(w.id), cavity: 30, thickness: 20 });
    p.add({ kind: 'wallCladding', wallId: s.id, side: side(s.id), cavity: 30, thickness: 20 });
    const g = claddingGeometry(p.doc, p.doc.get(c.id));
    // The arc ends tangent to the straight wall (collinear there): no corner, it stops at its end.
    expect(g.hi).toBeCloseTo(g.length, 3);
  });

  it('reach past the end where a wall meets the arc at an angle', () => {
    const p = project();
    const w = p.wall([0, 0], [4000, 0], { arc: Math.PI / 3 });
    const s = p.wall([4000, 0], [4000, -3000]);
    const c = p.add({ kind: 'wallCladding', wallId: w.id, side: outerSideOf(p, w.id), cavity: 30, thickness: 20 });
    const g = claddingGeometry(p.doc, p.doc.get(c.id));
    expect(Math.abs(g.hi - g.length)).toBeGreaterThan(50);
    expect(Math.abs(g.hi - g.length)).toBeLessThan(400);
  });
});

function outerSideOf(p, id) {
  return outerSideFn(p.doc, p.doc.get(id));
}
