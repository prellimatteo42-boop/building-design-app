import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { winsJunction, segmentOutside, KIND_RANK } from '../src/core/junctions.js';

describe('junctions between kinds', () => {
  it('lets the higher material priority win, and on a tie the stronger kind', () => {
    const { doc, L1, wall } = project();
    const w = wall([0, 0], [6000, 0]);
    const ct = doc.all('columnType')[0];
    let c;
    doc.transact('c', () => (c = doc.add({ kind: 'column', typeId: ct.id, levelId: L1.id, at: [3000, 0], rotation: 0, height: 3000 })));
    expect(KIND_RANK.column).toBeGreaterThan(KIND_RANK.wall);
    // A stronger material wins; with equal ones the column does.
    doc.transact('weak', () => doc.update(ct.id, { materialId: null }));
    doc.transact('wall core', () => {
      const wt = doc.get(w.typeId);
      doc.update(wt.id, { layers: wt.layers.map((l) => ({ ...l, priority: 100 })) });
    });
    expect(winsJunction(doc, doc.get(c.id), doc.get(w.id))).toBe(true);
    doc.transact('wall strong', () => {
      const wt = doc.get(w.typeId);
      doc.update(wt.id, { layers: wt.layers.map((l) => ({ ...l, priority: 999 })) });
    });
    expect(winsJunction(doc, doc.get(c.id), doc.get(w.id))).toBe(false);
  });

  it('cuts a segment where it crosses a convex shape', () => {
    const sq = [[1, -1], [2, -1], [2, 1], [1, 1]];
    expect(segmentOutside([0, 0], [3, 0], [sq])).toEqual([[[0, 0], [1, 0]], [[2, 0], [3, 0]]]);
    expect(segmentOutside([0, 5], [3, 5], [sq])).toEqual([[[0, 5], [3, 5]]]);
  });

  it('takes a winning column out of the wall it stands in, in plan', () => {
    const { doc, L1, wall } = project();
    const w = wall([0, 0], [6000, 0]);
    const ct = doc.all('columnType')[0];
    const plan = doc.all('plan').find((v) => v.levelId === L1.id);
    const scene = new Scene(doc);
    const lines = () => scene.planOf(plan, doc.get(w.id)).lines.length;
    const before = lines();
    doc.transact('c', () => doc.add({ kind: 'column', typeId: ct.id, levelId: L1.id, at: [3000, 0], rotation: 0, height: 3000 }));
    // The wall's face lines now stop at the column's edges: each face in two.
    expect(lines()).toBe(before + 2);
  });
});

describe('a branch nearly in line with walls running through a node', () => {
  it('keeps its own end instead of reaching for their face far away', () => {
    const { doc, wall } = project();
    wall([0, 0], [3000, 0]);
    wall([3000, 0], [6000, 0]);
    const b = wall([3000, 0], [3450, 5]);
    const g = new Scene(doc).walls.wall(b.id);
    for (const p of [g.L0, g.R0, g.L1, g.R1]) expect(Math.hypot(p[0] - 3200, p[1])).toBeLessThan(2000);
  });
});
