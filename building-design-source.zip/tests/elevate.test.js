import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { elevatePatch } from '../src/core/elevate.js';

describe('elevate', () => {
  it('moves elements through their own vertical offsets', () => {
    const p = project();
    const w = p.wall([0, 0], [4000, 0], { baseOffset: 100, topOffset: 0 });
    expect(elevatePatch(p.doc, p.doc.get(w.id), 300)).toEqual({ baseOffset: 400, topOffset: 300 });
    const free = p.wall([0, 2000], [4000, 2000], { topLevelId: null, baseOffset: 0 });
    expect(elevatePatch(p.doc, p.doc.get(free.id), -50)).toEqual({ baseOffset: -50 });
    const f = p.add({ kind: 'floor', typeId: p.doc.all('floorType')[0].id, levelId: p.L1.id, boundary: [[0, 0], [1, 0], [1, 1]], offset: 0 });
    expect(elevatePatch(p.doc, f, 200)).toEqual({ offset: 200 });
    const win = p.add({ kind: 'window', typeId: p.doc.all('windowType')[0].id, hostId: w.id, levelId: p.L1.id, t: 2000 });
    const sill = p.doc.get(win.typeId).sill ?? 900;
    expect(elevatePatch(p.doc, win, 100)).toEqual({ sill: sill + 100 });
    expect(elevatePatch(p.doc, p.doc.all('grid')[0] ?? { kind: 'grid', a: [0, 0], b: [1, 0] }, 100)).toBe(null);
  });
});
