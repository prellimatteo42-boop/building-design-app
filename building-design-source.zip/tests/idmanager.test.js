import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { assignIds, elementPoint } from '../src/core/idmanager.js';
import { runTool } from '../src/assistant/tools.js';
import { Scene } from '../src/core/scene.js';

describe('Element ID Manager', () => {
  it('numbers doors in rows per level with a level code and leading zeros', () => {
    const { doc, wall, add, L1, L2 } = project();
    const w1 = wall([0, 0], [10000, 0]);
    const w2 = wall([0, 5000], [10000, 5000]);
    const w3 = wall([0, 0], [10000, 0], { levelId: L2.id });
    const d = (w, t) => add({ kind: 'door', typeId: 'dt-single-36', hostId: w.id, t, levelId: w.levelId });
    const low = [d(w1, 8000), d(w1, 2000)];
    const top = [d(w2, 5000)];
    const up = [d(w3, 1000)];
    expect(elementPoint(doc, low[0])[0]).toBeCloseTo(8000, 6);
    const ids = assignIds(doc, [...low, ...top, ...up], { prefix: 'D', levelCode: 'index', separator: '.', digits: 2 });
    // Top row first (y grows upwards), then left to right; the upper level starts again.
    expect(ids.get(top[0].id)).toBe('D0.01');
    expect(ids.get(low[1].id)).toBe('D0.02');
    expect(ids.get(low[0].id)).toBe('D0.03');
    expect(ids.get(up[0].id)).toBe('D1.01');
    const cols = assignIds(doc, [...low, ...top], { order: 'columns', start: 10, step: 10 });
    expect([cols.get(low[1].id), cols.get(top[0].id), cols.get(low[0].id)]).toEqual(['10', '20', '30']);
  });

  it('the assistant previews then assigns room numbers', async () => {
    const p = project();
    const { doc, L1 } = p;
    const r1 = p.add({ kind: 'room', levelId: L1.id, at: [1000, 1000], name: 'A' });
    const r2 = p.add({ kind: 'room', levelId: L1.id, at: [6000, 1000], name: 'B' });
    const app = { doc, scene: new Scene(doc), selection: new Set(), commit: (l, fn) => doc.transact(l, fn) };
    const pre = await runTool(app, 'assign_ids', { kind: 'room', prefix: 'R', digits: 3, preview: true });
    expect(pre.would_assign.map((x) => x.id_value)).toEqual(['R001', 'R002']);
    expect(doc.get(r1.id).number).not.toBe('R001');
    await runTool(app, 'assign_ids', { ids: [r2.id, r1.id], prefix: 'R', digits: 3, order: 'given' });
    expect([doc.get(r2.id).number, doc.get(r1.id).number]).toEqual(['R001', 'R002']);
  });
});

import { changesInOrder, nextChangeId } from '../src/core/revisions.js';

describe('Change Manager', () => {
  it('lists change markers with IDs, revisions, views and sheets', () => {
    const { doc, add } = project();
    const plan = doc.all('plan')[0];
    const r1 = add({ kind: 'revision', seq: 1, number: '1', description: 'Tender' });
    const r2 = add({ kind: 'revision', seq: 2, number: '2', description: 'Planning' });
    const sheet = add({ kind: 'sheet', name: 'Plans', number: 'A101' });
    add({ kind: 'viewport', viewId: sheet.id, placedId: plan.id, at: [0, 0] });
    const sq = [[0, 0], [1000, 0], [1000, 1000]];
    add({ kind: 'revisionCloud', viewId: plan.id, boundary: sq, revisionId: r2.id, changeId: nextChangeId(doc), changeDescription: 'Door moved' });
    add({ kind: 'revisionCloud', viewId: plan.id, boundary: sq, revisionId: r1.id, changeId: nextChangeId(doc) });
    const list = changesInOrder(doc);
    expect(list.map((c) => c.id)).toEqual(['C-02', 'C-01']);
    expect(list[1]).toMatchObject({ description: 'Door moved', view: { id: plan.id } });
    expect(list[0].sheets.map((s) => s.number)).toEqual(['A101']);
  });
});

import { tagSelected, revertDimensionTexts } from '../src/editor/draw.js';

describe('document commands', () => {
  it('tag the selected elements once and revert custom dimension texts', () => {
    const p = project();
    const { doc } = p;
    const plan = doc.all('plan').find((v) => v.levelId === p.L1.id);
    const w = p.wall([0, 0], [5000, 0]);
    const d = p.add({ kind: 'door', typeId: 'dt-single-36', hostId: w.id, t: 2000, levelId: p.L1.id });
    const dim = p.add({ kind: 'dimension', viewId: plan.id, a: [0, -1000], b: [5000, -1000], override: '5 m (approx)' });
    const msgs = [];
    const app = { doc, vc: { view: plan }, selection: new Set([d.id, w.id]), scene: new Scene(doc), commit: (l, fn) => doc.transact(l, fn), toast: (m) => msgs.push(m) };
    tagSelected(app);
    tagSelected(app);
    expect(doc.all('tag').filter((t) => t.viewId === plan.id).map((t) => t.targetId).sort()).toEqual([d.id, w.id].sort());
    expect(msgs[1]).toMatch(/already tagged/);
    app.selection = new Set();
    revertDimensionTexts(app);
    expect(doc.get(dim.id).override).toBe('');
  });
});
