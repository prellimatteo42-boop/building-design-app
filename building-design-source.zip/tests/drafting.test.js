import { describe, it, expect } from 'vitest';
import { snapToGrid, gridLines, trackerValues, trackerPoint, constrainToDirection, bisectorDirection, ZoomHistory, actualSizeZoom, draftingOf } from '../src/core/drafting.js';

describe('precise drafting', () => {
  it('snaps to the nodes of a rotated grid with its own origin', () => {
    const g = { spacing: [500, 500], angle: 30, origin: [100, 200] };
    const node = snapToGrid(g, [100 + 1000 * Math.cos(Math.PI / 6) + 20, 200 + 1000 * Math.sin(Math.PI / 6) - 30]);
    expect(node[0]).toBeCloseTo(100 + 1000 * Math.cos(Math.PI / 6), 6);
    expect(node[1]).toBeCloseTo(200 + 1000 * Math.sin(Math.PI / 6), 6);
    const plain = snapToGrid({ spacing: [1000, 250], angle: 0, origin: [0, 0] }, [1420, 380]);
    expect(plain).toEqual([1000, 500]);
  });

  it('thins grid lines when zoomed out and marks every fifth major', () => {
    const g = draftingOf({ drafting: { grid: { spacing: [1000, 1000] } } }).grid;
    const box = { x0: 0, y0: 0, x1: 10000, y1: 10000 };
    const all = gridLines(g, box);
    expect(all.major.length + all.minor.length).toBe(22);
    expect(all.major.length).toBe(6);
    const thin = gridLines(g, box, 3000);
    expect(thin.minor.length + thin.major.length).toBe(6);
  });

  it('tracker values and points are inverse of each other', () => {
    const origin = [1000, 1000];
    expect(trackerValues([3000, 4000], { origin })).toEqual({ kind: 'absolute', x: 2000, y: 3000 });
    const from = [0, 0];
    const polar = trackerValues([3000, 3000], { from });
    expect(polar.r).toBeCloseTo(Math.hypot(3000, 3000), 6);
    expect(polar.angle).toBeCloseTo(45, 6);
    const back = trackerPoint({ kind: 'polar', r: 5000, angle: 90 }, { from: [100, 0] });
    expect(back[0]).toBeCloseTo(100, 6);
    expect(back[1]).toBeCloseTo(5000, 6);
    expect(trackerPoint({ kind: 'xy', dx: -200, dy: 50 }, { from: [10, 10] })).toEqual([-190, 60]);
    expect(trackerPoint({ kind: 'absolute', x: 1, y: 2 }, { origin })).toEqual([1001, 1002]);
  });

  it('parallel and bisector constraints', () => {
    const p = constrainToDirection([1000, 700], [0, 0], [1, 1]);
    expect(p[0]).toBeCloseTo(850, 6);
    expect(p[1]).toBeCloseTo(850, 6);
    const d = bisectorDirection({ a: [0, 0], b: [1000, 0] }, { a: [0, 0], b: [0, 1000] });
    expect(d[0]).toBeCloseTo(Math.SQRT1_2, 6);
    expect(d[1]).toBeCloseTo(Math.SQRT1_2, 6);
  });

  it('zoom history goes back and forward and drops the future on a new zoom', () => {
    const z = new ZoomHistory();
    z.push({ cx: 0, cy: 0, zoom: 1 });
    z.push({ cx: 10, cy: 0, zoom: 2 });
    z.push({ cx: 10, cy: 0, zoom: 2 });
    z.push({ cx: 20, cy: 5, zoom: 4 });
    expect(z.back()).toEqual({ cx: 10, cy: 0, zoom: 2 });
    expect(z.back()).toEqual({ cx: 0, cy: 0, zoom: 1 });
    expect(z.back()).toBeNull();
    expect(z.forward()).toEqual({ cx: 10, cy: 0, zoom: 2 });
    z.push({ cx: 99, cy: 0, zoom: 1 });
    expect(z.canForward).toBe(false);
    expect(actualSizeZoom(100)).toBeCloseTo(96 / 25.4 / 100, 12);
  });
});

import { specialPoints, stretchBetweenIntersections } from '../src/editor/snap.js';

describe('special snap points', () => {
  it('distance from the middle, and the stretch between intersections', () => {
    const l = { a: [0, 0], b: [10000, 0], id: 'l' };
    expect(specialPoints(l, { distance: 1000, fromMiddle: true }).map((x) => x.p[0])).toEqual([4000, 6000]);
    expect(specialPoints(l, { distance: 1000 }).map((x) => x.p[0])).toEqual([1000, 9000]);
    const cross = [l, { a: [3000, -1000], b: [3000, 1000], id: 'c1' }, { a: [7000, -1000], b: [7000, 1000], id: 'c2' }];
    const s = stretchBetweenIntersections(l, cross, [5000, 50]);
    expect([s.a[0], s.b[0]]).toEqual([3000, 7000]);
    expect(specialPoints(s, { divisions: 2 }).map((x) => x.p[0])).toEqual([5000]);
  });
});

import { PlanController } from '../src/views/plan.js';

describe('turned plan view', () => {
  it('model and screen coordinates stay inverse when the view is turned', () => {
    const fake = Object.create(PlanController.prototype);
    fake.vp = { width: 800, height: 600, requestRender() {} };
    fake.cam = { cx: 1000, cy: 500, zoom: 0.05, rot: 0.7 };
    const s = fake.modelToScreen([3000, -2000]);
    const back = fake.screenToModel(s.x, s.y);
    expect(back[0]).toBeCloseTo(3000, 6);
    expect(back[1]).toBeCloseTo(-2000, 6);
    // Turned by -angle of a direction, that direction runs along the screen's x.
    fake.cam.rot = -Math.atan2(1, 1);
    const a = fake.modelToScreen([0, 0]);
    const b = fake.modelToScreen([1000, 1000]);
    expect(a.y).toBeCloseTo(b.y, 6);
  });
});

import { hasIcon } from '../src/ui/icons.js';
import fs from 'node:fs';

describe('commands', () => {
  it('every command has an icon that exists', () => {
    const src = fs.readFileSync(new URL('../src/commands.js', import.meta.url), 'utf8');
    const missing = [...new Set([...src.matchAll(/icon: '([^']+)'/g)].map((m) => m[1]))].filter((n) => !hasIcon(n));
    expect(missing).toEqual([]);
  });
});

import { referenceLines } from '../src/core/drafting.js';
import { project } from './helpers.js';

describe('reference lines', () => {
  it('lists the reference lines of the kinds switched on, on the view level', () => {
    const p = project();
    p.wall([0, 0], [4000, 0]);
    p.add({ kind: 'roof', typeId: p.doc.all('roofType')[0].id, levelId: p.L1.id, boundary: [[0, 0], [4000, 0], [4000, 3000], [0, 3000]], slopes: [30, 30, 30, 30] });
    p.wall([0, 0], [4000, 0], { levelId: p.L2.id });
    const plan = p.doc.all('plan').find((v) => v.levelId === p.L1.id);
    expect(referenceLines(p.doc, plan, { wall: true })).toEqual([{ pts: [[0, 0], [4000, 0]], arrow: true }]);
    expect(referenceLines(p.doc, plan, { roof: true })[0]).toMatchObject({ closed: true, pivot: true });
    expect(referenceLines(p.doc, plan, {})).toEqual([]);
  });
});
