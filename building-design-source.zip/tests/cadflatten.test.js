import { describe, it, expect } from 'vitest';
import { flattenCAD, mtextPlain, layerCounts } from '../src/core/cadflatten.js';

const near = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]) < 1e-6;

describe('flattening CAD drawings', () => {
  it('expands nested blocks with their placement, scale and rotation', () => {
    const cad = {
      entities: [
        { type: 'INSERT', layer: 'Doors', name: 'D', insertionPoint: { x: 100, y: 0 }, xScale: 2, yScale: 2, rotation: Math.PI / 2 },
        { type: 'LINE', layer: 'Walls', startPoint: { x: 0, y: 0 }, endPoint: { x: 10, y: 0 } },
      ],
      blocks: {
        D: { basePoint: { x: 1, y: 0 }, entities: [{ type: 'LINE', layer: '0', startPoint: { x: 1, y: 0 }, endPoint: { x: 2, y: 0 } }, { type: 'INSERT', layer: 'Inner', name: 'E', insertionPoint: { x: 1, y: 0 }, xScale: 1, yScale: 1, rotation: 0 }] },
        E: { basePoint: { x: 0, y: 0 }, entities: [{ type: 'LINE', layer: 'Inner', startPoint: { x: 0, y: 0 }, endPoint: { x: 0, y: 1 } }] },
      },
    };
    const f = flattenCAD(cad);
    const door = f.lines.find((l) => l.layer === 'Doors');
    // (1,0)-(2,0) less the base point, doubled, turned 90 degrees, moved to (100, 0).
    expect(near(door.a, [100, 0])).toBe(true);
    expect(near(door.b, [100, 2])).toBe(true);
    const inner = f.lines.find((l) => l.layer === 'Inner');
    expect(near(inner.a, [100, 0])).toBe(true);
    expect(near(inner.b, [98, 0])).toBe(true);
    expect(layerCounts(f).get('Walls')).toBe(1);
    expect(flattenCAD(cad, { layers: new Set(['Walls']) }).lines).toHaveLength(1);
  });

  it('draws polylines with arcs, closed polylines, circles and mirrored arcs', () => {
    const cad = {
      entities: [
        { type: 'LWPOLYLINE', layer: 'L', flag: 1, vertices: [{ x: 0, y: 0, bulge: 1 }, { x: 2, y: 0, bulge: 0 }, { x: 2, y: 2, bulge: 0 }] },
        { type: 'INSERT', layer: 'M', name: 'A', insertionPoint: { x: 0, y: 0 }, xScale: -1, yScale: 1, rotation: 0 },
      ],
      blocks: { A: { basePoint: { x: 0, y: 0 }, entities: [{ type: 'ARC', layer: '0', center: { x: 0, y: 0 }, radius: 1, startAngle: 0, endAngle: Math.PI / 2 }] } },
    };
    const f = flattenCAD(cad);
    const pl = f.lines.filter((l) => l.layer === 'L');
    // The bulge makes a half circle below the first edge (several pieces), then two straight edges and the closing one.
    expect(pl.length).toBeGreaterThan(5);
    expect(Math.min(...pl.flatMap((l) => [l.a[1], l.b[1]]))).toBeCloseTo(-1, 6);
    const arc = f.arcs[0];
    // Mirrored in x: the quarter from 90 to 180 degrees.
    expect(arc.layer).toBe('M');
    expect(Math.cos(arc.a0)).toBeCloseTo(0, 6);
    expect(Math.sin(arc.a0)).toBeCloseTo(1, 6);
    expect(Math.cos(arc.a1)).toBeCloseTo(-1, 6);
  });

  it('reads texts, MTEXT formatting and solid hatches', () => {
    expect(mtextPlain('{\\fArial|b1;Living}\\PRoom %%c 12')).toBe('Living\nRoom Ø 12');
    expect(mtextPlain('\\pql;Hall')).toBe('Hall');
    const f = flattenCAD({
      entities: [
        { type: 'MTEXT', layer: 'T', insertionPoint: { x: 5, y: 5 }, textHeight: 250, text: '\\A1;Kitchen', rotation: 0 },
        { type: 'HATCH', layer: 'H', solidFill: 1, boundaryPaths: [{ vertices: [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }] }] },
      ],
      blocks: {},
    });
    expect(f.texts[0]).toMatchObject({ text: 'Kitchen', height: 250, layer: 'T' });
    expect(f.fills[0].poly).toHaveLength(3);
  });
});
