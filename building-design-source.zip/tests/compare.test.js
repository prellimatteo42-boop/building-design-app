import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Doc } from '../src/core/doc.js';
import { compareDocs, compareSummary, fieldClass } from '../src/core/compare.js';

describe('model compare', () => {
  it('finds new, deleted and modified elements and what changed', () => {
    const { doc, wall, add, L1 } = project();
    const w1 = wall([0, 0], [4000, 0]);
    const w2 = wall([0, 3000], [4000, 3000]);
    const c = add({ kind: 'component', typeId: 'cpt-sofa', levelId: L1.id, at: [1000, 1000], rotation: 0 });
    const base = Doc.fromJSON(JSON.parse(JSON.stringify(doc.toJSON())));
    doc.transact('edit', () => {
      doc.update(w1.id, { b: [5000, 0] });
      doc.update(c.id, { typeId: 'cpt-armchair', comments: 'moved' });
      doc.remove(w2.id);
      doc.add({ kind: 'room', levelId: L1.id, at: [2000, 1500], name: 'Living', number: '1' });
      doc.update('mat-concrete', { color: '#999999' });
    });
    const d = compareDocs(base, doc);
    expect(d.added.map((x) => x.label)).toEqual(['Room: Living']);
    expect(d.removed.map((x) => x.id)).toEqual([w2.id]);
    const mw = d.modified.find((x) => x.id === w1.id);
    expect(mw.fields).toEqual(['b']);
    expect([...mw.classes]).toEqual(['geometry']);
    const mc = d.modified.find((x) => x.id === c.id);
    expect([...mc.classes].sort()).toEqual(['properties', 'type']);
    expect(d.modified.find((x) => x.id === 'mat-concrete').group).toBe('Types and Settings');
    const s = compareSummary(d);
    expect(s.find((x) => x.group === 'Walls')).toMatchObject({ added: 0, removed: 1, modified: 1 });
    expect(fieldClass('typeId')).toBe('type');
  });

  it('finds nothing between identical versions', () => {
    const { doc, wall } = project();
    wall([0, 0], [4000, 0]);
    const base = Doc.fromJSON(JSON.parse(JSON.stringify(doc.toJSON())));
    expect(compareDocs(base, doc)).toEqual({ added: [], removed: [], modified: [] });
  });
});
