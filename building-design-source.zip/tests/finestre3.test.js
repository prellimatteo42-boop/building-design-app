import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { snapTo, vertexAt, edgeAt, moveVertex, insertVertex, removeVertex } from '../src/core/profileedit.js';
import { titleBlock } from '../src/core/sheet.js';

const sq = () => [{ poly: [[0, 0], [100, 0], [100, 100], [0, 100]], holes: [[[30, 30], [30, 70], [70, 70], [70, 30]]], materialId: 'm' }];

describe('Profile Editor', () => {
  it('snaps to the grid', () => {
    expect(snapTo([14, 26], 10)).toEqual([10, 30]);
    expect(snapTo([14, 26], 0)).toEqual([14, 26]);
  });

  it('finds corners and edges, in outlines and holes', () => {
    expect(vertexAt(sq(), [99, 2], 5)).toMatchObject({ shape: 0, loop: 0, index: 1 });
    expect(vertexAt(sq(), [31, 69], 5)).toMatchObject({ loop: 1, index: 1 });
    const e = edgeAt(sq(), [50, 1], 5);
    expect(e).toMatchObject({ loop: 0, index: 0 });
    expect(e.at).toEqual([50, 0]);
  });

  it('moves, adds and removes corners; a hole left with two corners goes', () => {
    let s = moveVertex(sq(), { shape: 0, loop: 0, index: 2 }, [120, 120]);
    expect(s[0].poly[2]).toEqual([120, 120]);
    s = insertVertex(s, { shape: 0, loop: 0, index: 0 }, [50, -20]);
    expect(s[0].poly).toHaveLength(5);
    expect(s[0].poly[1]).toEqual([50, -20]);
    s = removeVertex(s, { shape: 0, loop: 0, index: 1 });
    expect(s[0].poly).toHaveLength(4);
    let t = removeVertex(sq(), { shape: 0, loop: 1, index: 0 });
    expect(t[0].holes[0]).toHaveLength(3);
    t = removeVertex(t, { shape: 0, loop: 1, index: 0 });
    expect(t[0].holes).toHaveLength(0);
    // An outline keeps at least three corners.
    const tri = [{ poly: [[0, 0], [1, 0], [0, 1]], holes: [] }];
    expect(removeVertex(tri, { shape: 0, loop: 0, index: 0 })[0].poly).toHaveLength(3);
  });
});

describe('Master layout window', () => {
  it('draws a master on its own with a sample layout title', () => {
    const { doc, add } = project();
    const m = add({ kind: 'masterLayout', name: 'Studio A1', size: 'A1', strip: 'right', margin: 10, rows: [{ text: '{SheetName}', size: 4 }] });
    const tb = titleBlock(doc, doc.get(m.id));
    expect(tb.builder.lines.length).toBeGreaterThan(3);
    expect(tb.area.x1).toBeGreaterThan(tb.area.x0);
  });
});
