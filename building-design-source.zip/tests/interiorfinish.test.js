import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { FURNITURE_KINDS, furnitureObject } from '../src/core/furniture.js';
import { runGdlType, gdlVars } from '../src/core/gdlobject.js';
import { boardLayout, freeColor, hexOf, paintOf } from '../src/core/finish.js';
import { INTERIOR_TOOLS } from '../src/assistant/interiortools.js';

const tool = (n) => INTERIOR_TOOLS.find((t) => t.name === n);

function room() {
  const p = project();
  p.wall([0, 4000], [5000, 4000]);
  p.wall([5000, 4000], [5000, 0]);
  p.wall([5000, 0], [0, 0]);
  p.wall([0, 0], [0, 4000]);
  p.doc.transact('room', () => p.doc.add({ kind: 'room', levelId: p.L1.id, at: [2500, 2000], name: 'Camera', number: '1', upperOffset: 2700 }));
  const scene = new Scene(p.doc);
  return { p, app: { doc: p.doc, scene, commit: (name, fn) => p.doc.transact(name, fn) } };
}

describe('rebuilding a room from a photo', () => {
  it.each(FURNITURE_KINDS)('draws a %s', (kind) => {
    const r = runGdlType(furnitureObject({ kind }));
    expect(r.error).toBeNull();
    expect(r.unknown).toBeNull();
    expect(r.tris.length).toBeGreaterThan(5);
  });

  it('lets a curtain be seen through and a closet have glass', () => {
    expect(runGdlType(furnitureObject({ kind: 'curtain' })).tris.some((t) => t.alpha < 1)).toBe(true);
    expect(runGdlType(furnitureObject({ kind: 'closet' })).tris.some((t) => t.alpha < 0.5)).toBe(true);
    expect(runGdlType(furnitureObject({ kind: 'curtain', opaque: true })).tris.every((t) => (t.alpha ?? 1) === 1)).toBe(true);
  });

  it('gives a placed GDL object its own size', () => {
    const type = furnitureObject({ kind: 'rug', width: 2000, depth: 1000 });
    expect(gdlVars(type, { A: 3000 }).A).toBe(3);
    expect(gdlVars(type, {}).A).toBe(2);
  });

  it('reads colours and keeps textured ones apart from the rest', () => {
    expect(hexOf('#BDB2A7')).toBe('#bdb2a7');
    expect(hexOf('not a colour')).toBeNull();
    const { p } = room();
    p.doc.transact('paint', () => {
      const a = paintOf(p.doc, '#808080');
      expect(paintOf(p.doc, '#808080').id).toBe(a.id);
      expect(freeColor(p.doc, '#808080')).not.toBe('#808080');
    });
  });

  it('lays boards that cover every row of the tile exactly once', () => {
    const boards = boardLayout(2400, 10);
    for (let row = 0; row < 10; row++) {
      const here = boards.filter((b) => b.row === row);
      expect(here.reduce((s, b) => s + b.x1 - b.x0, 0)).toBeCloseTo(2400, 3);
    }
  });

  it('shows the image a picture holds, wherever the object goes', () => {
    const r = runGdlType(furnitureObject({ kind: 'picture', image: 'data:image/png;base64,AAAA' }));
    expect(r.error).toBeNull();
    const shown = r.tris.filter((t) => t.src);
    expect(shown.length).toBe(2);
    expect(Math.min(...shown.flatMap((t) => [t.a[1], t.b[1], t.c[1]]))).toBeLessThan(Math.min(...r.tris.filter((t) => !t.src).flatMap((t) => [t.a[1], t.b[1], t.c[1]])) + 1e-6);
    expect(runGdlType(furnitureObject({ kind: 'picture' })).tris.every((t) => !t.src)).toBe(true);
  });

  it('paints elements for real and says what it could not take', () => {
    const { p, app } = room();
    const out = tool('add_elements').run(app, { items: [{ kind: 'floor', boundary: [[0, 0], [5000, 0], [5000, 4000], [0, 4000]], thickness: 250, color: '#c89a62' }] });
    expect(out.failed).toEqual([]);
    expect(out.ignored).toEqual(['floor.thickness']);
    const floor = p.doc.get(out.made[0].id);
    expect(p.doc.get(floor.paintId).color).toBe('#c89a62');
    const m = app.scene.mesh(floor);
    expect([m.col[0], m.col[1], m.col[2]]).toEqual([0xc8, 0x9a, 0x62]);
  });

  it('paints every wall with set_finish, and takes the paint off', async () => {
    const { p, app } = room();
    expect((await tool('set_finish').run(app, { kind: 'wall', color: '#bdb2a7' })).painted).toBe(4);
    expect(p.doc.all('wall').every((w) => p.doc.get(w.paintId).color === '#bdb2a7')).toBe(true);
    expect(p.doc.all('material').filter((m) => m.color === '#bdb2a7').length).toBe(1);
    await tool('set_finish').run(app, { kind: 'wall', clear: true });
    expect(p.doc.all('wall').every((w) => !w.paintId)).toBe(true);
    expect((await tool('set_finish').run(app, { kind: 'wall', color: 'nope' })).error).toMatch(/not a colour/);
  });

  it('does not call a lamp on a table, a picture over a bed or a rug under it overlaps', async () => {
    const { app } = room();
    const out = await tool('place_objects').run(app, { items: [
      { key: 'bed', kind: 'bed', room: 'Camera', wall: 'north' },
      { key: 'table', kind: 'nightstand', next_to: 'bed', side: 'east', gap: 50, height: 420 },
      { kind: 'rug', at: [2500, 3000], width: 2400, depth: 1700 },
      { kind: 'picture', at: [2500, 3900], offset: 1200 },
      { kind: 'cabinet', at: [2500, 3000] },
    ] });
    expect(out.placed).toBe(5);
    expect(out.results.slice(0, 4).every((r) => !r.warning)).toBe(true);
    expect(out.results[4].warning).toMatch(/Bed/);
  });

  it('resizes and paints a catalogue object', async () => {
    const { p, app } = room();
    const rug = p.doc.all('componentType').find((t) => t.category !== undefined && t.family !== 'gdl');
    const r = tool('place_object').run(app, { ref: `type:${rug.id}`, at: [1000, 1000], width: +rug.width + 300, color: '#112233' });
    const el = p.doc.get(r.id);
    expect(p.doc.get(el.typeId).width).toBe(+rug.width + 300);
    expect(p.doc.get(el.paintId).color).toBe('#112233');
    expect(rug.width).not.toBe(p.doc.get(el.typeId).width);
  });

  it('removes only what exists', () => {
    const { p, app } = room();
    const id = p.doc.all('wall')[0].id;
    expect(tool('remove_elements').run(app, { ids: [id, 'nothing'] }).removed).toBe(1);
    expect(p.doc.has(id)).toBe(false);
    expect(tool('remove_elements').run(app, { ids: ['nothing'] }).error).toBeTruthy();
  });
});

describe('a ceiling described in other words', () => {
  it('goes at the height asked for, and never stays on the floor', () => {
    const { p, app } = room();
    const boundary = [[0, 0], [5000, 0], [5000, 4000], [0, 4000]];
    const at = (fields) => p.doc.get(tool('add_elements').run(app, { items: [{ kind: 'ceiling', boundary, ...fields }] }).made[0].id).offset;
    expect(at({ offset: 2900 })).toBe(2900);
    expect(at({ elevation: 2700 })).toBe(2700);
    expect(at({ height: 2600 })).toBe(2600);
    expect(at({})).toBe(2700);
  });
});

describe('objects from a library, as they are placed', () => {
  const part = (p, params, size = { width: 1880, depth: 2230, height: 900 }) => {
    let t;
    p.doc.transact('type', () => {
      t = p.doc.add({ kind: 'componentType', family: 'gdl', familyName: 'GDL Object', name: 'Bed', category: 'furniture', ...size, gdl: { params, script3d: 'BLOCK A, B, ZZYZX', script2d: 'RECT2 0, 0, A, B' } });
    });
    return t;
  };

  it('takes a colour for a material parameter as a project material', () => {
    const { p, app } = room();
    const t = part(p, [{ name: 'matPillow', kind: 'material', value: 'mat-wood' }, { name: 'bPillow', kind: 'boolean', value: 0 }]);
    const r = tool('place_object').run(app, { ref: `type:${t.id}`, at: [1000, 1000], values: { MATPILLOW: '#223344', bPillow: 1, nothing: 3 } });
    const el = p.doc.get(r.id);
    expect(p.doc.get(el.gdlValues.matPillow).color).toBe('#223344');
    expect(el.gdlValues.bPillow).toBe(1);
    expect(r.warning).toMatch(/No such parameters: nothing/);
  });

  it('sizes a bed by its mattress, keeping the frame round it', () => {
    const { p, app } = room();
    const t = part(p, [{ name: 'nominalWidth', kind: 'length', value: 1800 }, { name: 'nominalLength', kind: 'length', value: 2000 }]);
    const r = tool('place_object').run(app, { ref: `type:${t.id}`, at: [1000, 1000], width: 1700, depth: 2130 });
    expect(p.doc.get(r.id).gdlValues).toMatchObject({ A: 1700, B: 2130, nominalWidth: 1620, nominalLength: 1900 });
  });

  it('says so when an object does not come out at the size asked for', () => {
    const { p, app } = room();
    const t = part(p, []);
    p.doc.transact('fixed', () => p.doc.update(t.id, { gdl: { ...t.gdl, script3d: 'BLOCK 3, 0.6, 2' } }));
    const r = tool('place_object').run(app, { ref: `type:${t.id}`, at: [1000, 1000], width: 2200 });
    expect(r.warning).toMatch(/it came out 3000/);
  });

  it('lists what can be set on an object, without the drawing options', () => {
    const { p, app } = room();
    const t = part(p, [{ name: 'matFrame', kind: 'material', value: 'mat-wood' }, { name: 'bPillow', kind: 'boolean', value: 0 }, { name: 'fillPenBlanket', kind: 'integer', value: 19 }]);
    const r = tool('object_parameters').run(app, { ref: `type:${t.id}` });
    expect(r.materials.map((m) => m.name)).toEqual(['matFrame']);
    expect(r.options.map((m) => m.name)).toEqual(['bPillow']);
    expect(tool('object_parameters').run(app, { ref: 'nope' }).error).toBeTruthy();
  });
});
