import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { exteriorDimensions } from '../src/core/autodim.js';
import { dimensionGeometry } from '../src/core/plan.js';
import { WallSolver } from '../src/core/walls.js';

describe('automatic exterior dimensions', () => {
  it('measure the openings, the walls and the overall length on each side', () => {
    const p = project();
    // A 10 x 6 m box of 200 walls (centerline) with a 4 m partition and a window in the south wall.
    const [s, e, n, w] = p.box(0, 0, 10000, 6000);
    p.wall([4000, 0], [4000, 6000]);
    p.add({ kind: 'window', typeId: p.doc.all('windowType')[0].id, hostId: s.id, levelId: p.L1.id, t: 2000, width: 1200 });
    const plan = p.doc.all('plan')[0];
    const dims = exteriorDimensions(p.doc, p.doc.all('wall'), plan.id, 100);
    const walls = new WallSolver(p.doc);
    const values = (dim) => {
      const g = dimensionGeometry(p.doc, walls, dim);
      const sorted = g.order.map((i) => g.pos[i]);
      return sorted.slice(1).map((v, i) => Math.round(v - sorted[i]));
    };
    // South: openings, walls, overall; north, east and west: walls and overall.
    const south = dims.filter((d) => d.dir[0] === 1 && d.line[1] < 0);
    expect(south.length).toBe(3);
    const [opens, wallsChain, overall] = south.sort((a, b) => b.line[1] - a.line[1]);
    expect(values(overall)).toEqual([10200]);
    // Faces of the west wall, the partition and the east wall.
    expect(values(wallsChain)).toEqual([200, 3800, 200, 5800, 200]);
    // Corner, window jambs at 1400 and 2600 from the axis start, corner.
    expect(values(opens)).toEqual([1500, 1200, 7500]);
    expect(dims.filter((d) => d.dir[1] === 1).length).toBe(4);
    expect(dims.length).toBe(9);
    expect(dims.every((d) => d.viewId === plan.id && d.auto)).toBe(true);
    void [e, n, w];
  });
});

describe('interior dimensioning', () => {
  it('measures every wall face the line crosses', async () => {
    const { interiorDimension } = await import('../src/core/autodim.js');
    const p = project();
    p.box(0, 0, 10000, 6000);
    p.wall([4000, 0], [4000, 6000]);
    const plan = p.doc.all('plan')[0];
    const dim = interiorDimension(p.doc, p.doc.all('wall'), [-500, 3000], [10500, 3000], plan.id);
    const walls = new WallSolver(p.doc);
    const g = dimensionGeometry(p.doc, walls, dim);
    const sorted = g.order.map((i) => g.pos[i]);
    // West wall, partition, east wall: both faces of each (200 thick, centred).
    expect(sorted.slice(1).map((v, i) => Math.round(v - sorted[i]))).toEqual([200, 3800, 200, 5800, 200]);
    // A line along a wall crosses no faces.
    expect(interiorDimension(p.doc, p.doc.all('wall'), [1000, 0], [3000, 0], plan.id)).toBe(null);
  });
});
