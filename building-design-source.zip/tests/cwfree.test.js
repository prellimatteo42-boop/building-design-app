import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';

describe('curtain walls on curved and slanted lines', () => {
  it('follows an arc: mullions on the circle, panels as chords', () => {
    const p = project();
    // A half circle of radius 5 m round (5000, 0).
    const w = p.wall([0, 0], [10000, 0], { typeId: 'wt-curtain', topLevelId: null, height: 3000, arc: Math.PI });
    const m = new Scene(p.doc).mesh(p.doc.get(w.id));
    expect(m.pos.length).toBeGreaterThan(0);
    // Every point lies near the circle (within the frame depth), none along the straight chord.
    let far = 0;
    for (let i = 0; i < m.pos.length; i += 3) {
      const r = Math.hypot(m.pos[i] - 5000, m.pos[i + 1]);
      if (Math.abs(r - 5000) > 400) far++;
    }
    expect(far).toBe(0);
    expect(m.bounds.max[1] - m.bounds.min[1]).toBeGreaterThan(4500);
  });

  it('draws the curved one in plan', () => {
    const p = project();
    const w = p.wall([0, 0], [10000, 0], { typeId: 'wt-curtain', topLevelId: null, height: 3000, arc: Math.PI });
    const view = p.doc.all('plan').find((v) => v.levelId === p.L1.id);
    const g = new Scene(p.doc).planOf(view, p.doc.get(w.id));
    const ys = (g.lines || []).flatMap((l) => [l.a?.[1], l.b?.[1]]).filter(Number.isFinite);
    expect(Math.max(...ys.map(Math.abs))).toBeGreaterThan(4500);
  });

  it('leans when slanted', () => {
    const p = project();
    const w = p.wall([0, 0], [6000, 0], { typeId: 'wt-curtain', topLevelId: null, height: 3000, slant: 'slanted', slantOuter: 10 });
    const b = new Scene(p.doc).mesh(p.doc.get(w.id)).bounds;
    // 3 m up at 10°: about 530 mm across.
    expect(b.max[1] - b.min[1]).toBeGreaterThan(500);
  });
});
