import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { favoriteFrom, favoritePatch, favoritesFor } from '../src/core/favorites.js';

describe('favorites', () => {
  it('keep the settings of an element, not where it is', () => {
    const p = project();
    const w = p.wall([0, 0], [4000, 0], { typeId: 'wt-ext-concrete', locationLine: 'exterior', baseOffset: 150, structural: true, layerId: 'ly-structure', mark: 'W1' });
    const f = favoriteFrom(p.doc, p.doc.get(w.id), 'Concrete, exterior line');
    expect(f.typeId).toBe('wt-ext-concrete');
    expect(f.params).toMatchObject({ locationLine: 'exterior', baseOffset: 150, structural: true, layerId: 'ly-structure' });
    for (const k of ['a', 'b', 'levelId', 'mark', 'id', 'topLevelId']) expect(f.params).not.toHaveProperty(k);
    // The top was the level above: it stays relative.
    expect(f.topAbove).toBe(true);
  });

  it('apply to elements of their kind, on any level', () => {
    const p = project();
    const src = p.wall([0, 0], [4000, 0], { typeId: 'wt-ext-concrete', locationLine: 'exterior', structural: true });
    const fav = p.add(favoriteFrom(p.doc, p.doc.get(src.id), 'Concrete'));
    const other = p.wall([0, 3000], [4000, 3000], { topLevelId: null, height: 2500 });
    p.doc.transact('fav', () => p.doc.update(other.id, favoritePatch(p.doc, fav, p.doc.get(other.id))));
    const w = p.doc.get(other.id);
    expect(w.typeId).toBe('wt-ext-concrete');
    expect(w.locationLine).toBe('exterior');
    expect(w.topLevelId).toBe(p.L2.id);
    expect(w.a).toEqual([0, 3000]);
    expect(favoritesFor(p.doc, 'wall').map((f) => f.name)).toEqual(['Concrete']);
    expect(favoritesFor(p.doc, 'floor')).toEqual([]);
  });

  it('set a roof slope on every edge', () => {
    const p = project();
    const fav = { kind: 'favorite', elementKind: 'roof', typeId: null, params: {}, slope: 35 };
    const patch = favoritePatch(p.doc, fav, { boundary: [[0, 0], [1, 0], [1, 1]], levelId: p.L1.id });
    expect(patch.slopes).toEqual([35, 35, 35]);
  });

  it('override what a tool sets while armed', () => {
    const p = project();
    p.doc.addOverrides = [(item) => (item.kind === 'wall' ? { locationLine: 'interior' } : null)];
    const w = p.wall([0, 0], [1000, 0], { locationLine: 'center' });
    expect(p.doc.get(w.id).locationLine).toBe('interior');
  });
});
