import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { detectCollisions } from '../src/core/collision.js';

describe('collision detection', () => {
  it('finds a beam running through a wall, by the volume they share', () => {
    const p = project();
    const wall = p.wall([2000, -2000], [2000, 2000]);
    const beam = p.add({ kind: 'beam', typeId: p.doc.all('beamType')[0].id, levelId: p.L1.id, a: [0, 0], b: [4000, 0], offset: 2000 });
    const far = p.add({ kind: 'beam', typeId: p.doc.all('beamType')[0].id, levelId: p.L1.id, a: [0, 5000], b: [4000, 5000], offset: 2000 });
    const scene = new Scene(p.doc);
    const hits = detectCollisions([p.doc.get(beam.id), p.doc.get(far.id)], [p.doc.get(wall.id)], (el) => scene.mesh(el));
    expect(hits.length).toBe(1);
    expect(hits[0].a.id).toBe(beam.id);
    expect(hits[0].volume).toBeGreaterThan(1e6);
    expect(hits[0].center[0]).toBeCloseTo(2000, -1);
    // A large tolerance lets it pass.
    expect(detectCollisions([p.doc.get(beam.id)], [p.doc.get(wall.id)], (el) => scene.mesh(el), { tolerance: 1e12 }).length).toBe(0);
  });
});
