import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { levelDimensions } from '../src/core/autolevels.js';

describe('automatic level dimensions', () => {
  it('measure slab tops, wall tops and the roof in a section', () => {
    const p = project();
    p.box(0, 0, 6000, 4000);
    p.add({ kind: 'floor', typeId: p.doc.all('floorType')[0].id, levelId: p.L1.id, boundary: [[0, 0], [6000, 0], [6000, 4000], [0, 4000]], offset: 0 });
    p.add({ kind: 'roof', typeId: p.doc.all('roofType')[0].id, levelId: p.L2.id, boundary: [[-500, -500], [6500, -500], [6500, 4500], [-500, 4500]], slopes: [30, 30, 30, 30], baseOffset: 0 });
    const sec = p.add({ kind: 'section', name: 'S', a: [3000, 6000], b: [3000, -2000], flip: false, depth: 10000, scale: 100 });
    const scene = new Scene(p.doc);
    const spots = levelDimensions(p.doc, sec, (el) => scene.mesh(el));
    const zs = spots.map((s) => s.at[1]);
    // Slab top at the level, wall tops at Level 2, the roof's eaves and ridge above.
    expect(zs).toContain(p.L1.elevation || 0);
    expect(Math.max(...zs)).toBeGreaterThan(p.L2.elevation + 1000);
    expect(new Set(zs).size).toBe(zs.length);
    // One chain: every leader at the same u, beside the building.
    expect(new Set(spots.map((s) => s.leader[0])).size).toBe(1);
  });
});
