import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { runTool, toolSchemas } from '../src/assistant/tools.js';
import { Scene } from '../src/core/scene.js';
import { viewGraphics } from '../src/core/graphics.js';
import { editKeynotes, parseKeynoteFile, keynoteFileText, keynoteTree } from '../src/core/keynotes.js';

function fakeApp() {
  const p = project();
  const plan = p.doc.all('plan').find((v) => v.levelId === p.L1.id);
  const app = { doc: p.doc, get activeView() { return p.doc.get(plan.id); }, scene: new Scene(p.doc), selection: new Set(), commit: (label, fn) => p.doc.transact(label, fn), showElements(ids) { app.selection = new Set(ids); }, openView() {} };
  return { ...p, app, plan };
}

describe('assistant settings tools', () => {
  it('schemas are valid for the Claude API (unique names, object inputs)', () => {
    const s = toolSchemas();
    expect(new Set(s.map((t) => t.name)).size).toBe(s.length);
    for (const t of s) expect(t.input_schema.type).toBe('object');
  });

  it('graphic override rules on a custom property, view entries and combinations', async () => {
    const { app, doc, wall, plan } = fakeApp();
    const a = wall([0, 0], [4000, 0]);
    const b = wall([4000, 0], [4000, 3000]);
    await runTool(app, 'property_definitions', { action: 'create', properties: [{ name: 'Fire Rating', type: 'choice', options: ['EI 30', 'EI 60'], categories: ['walls'], default: 'EI 30' }] });
    await runTool(app, 'set_property_values', { ids: [a.id], values: [{ name: 'Fire Rating', value: 'EI 60' }] });
    const made = await runTool(app, 'graphic_overrides', { action: 'create_rules', rules: [{ name: 'Fire walls', categories: ['walls'], criteria: [{ param: 'Fire Rating', op: 'equals', value: 'EI 60' }] }] });
    expect(made.success).toBe(true);
    await runTool(app, 'graphic_overrides', { action: 'set_view', entries: [{ rule: 'Fire walls', color: '#ff0000', weight: 5 }] });
    const v = doc.get(plan.id);
    expect(viewGraphics(doc, v, doc.get(a.id)).color).toBe('#ff0000');
    expect(viewGraphics(doc, v, doc.get(b.id)).color).toBeNull();
    expect((await runTool(app, 'graphic_overrides', { action: 'get_view' })).entries).toEqual([{ rule: 'Fire walls', visible: true, color: '#ff0000', weight: 5 }]);
    await runTool(app, 'graphic_overrides', { action: 'save_combination', combination: 'Fire Plan' });
    const other = doc.all('plan').find((x) => x.id !== plan.id);
    const ap = await runTool(app, 'graphic_overrides', { action: 'apply_combination', combination: 'fire plan', views: [other.name] });
    expect(ap.success).toBe(true);
    expect(doc.get(other.id).filters).toHaveLength(1);
    expect(doc.get(other.id).overrideCombo).toBe('Fire Plan');
    const rules = await runTool(app, 'graphic_overrides', { action: 'search_rules', query: 'fire' });
    expect(rules.rules[0].criteria[0].param).toBe('Fire Rating');
    await runTool(app, 'graphic_overrides', { action: 'delete_rules', rules: [{ name: 'Fire walls' }] });
    expect(doc.get(other.id).filters).toHaveLength(0);
  });

  it('classification systems and items: create, rename a code with its elements, delete', async () => {
    const { app, doc, wall } = fakeApp();
    const w = wall([0, 0], [4000, 0]);
    expect((await runTool(app, 'classifications', { action: 'create_system', system: 'Uniclass', edition: '2015' })).success).toBe(true);
    const items = await runTool(app, 'classifications', { action: 'create_items', system: 'Uniclass', items: [{ code: 'EF', name: 'Elements' }, { code: 'EF_25', name: 'Walls', parent: 'EF', ifc: 'IfcWall' }, { code: 'X', parent: 'nope' }] });
    expect(items.done).toEqual(['EF', 'EF_25']);
    expect(items.errors[0].error).toMatch(/No parent/);
    const sys = doc.all('classSystem').find((s) => s.name === 'Uniclass');
    await runTool(app, 'classify_elements', { ids: [w.id], code: 'EF_25', system: 'Uniclass' });
    await runTool(app, 'classifications', { action: 'modify_item', system: 'Uniclass', items: [{ code: 'EF_25', new_code: 'EF_25_10', name: 'Walls (external)' }] });
    expect(doc.get(w.id).classes[sys.id]).toBe('EF_25_10');
    expect((await runTool(app, 'classifications', { action: 'delete_items', system: 'Uniclass', items: [{ code: 'EF' }] })).errors[0].error).toMatch(/under it/);
    await runTool(app, 'classifications', { action: 'delete_items', system: 'Uniclass', items: [{ code: 'EF_25_10' }] });
    expect(doc.get(w.id).classes[sys.id]).toBeUndefined();
    const found = await runTool(app, 'classifications', { action: 'search_systems', query: 'uni' });
    expect(found.systems).toEqual([{ name: 'Uniclass', edition: '2015', items: 1, top: ['EF Elements'] }]);
  });

  it('keynotes: tree edits, file round trip and assigning a key to a type', async () => {
    const list = editKeynotes([], [
      { op: 'add', key: '04', title: 'Masonry', folder: true },
      { op: 'add', key: '04.20', title: 'Brick wall', parent: '04' },
      { op: 'add', key: '04.10', title: 'Block wall', parent: '04' },
    ]);
    expect(keynoteTree(list).map((t) => `${t.depth}:${t.item.key}`)).toEqual(['0:04', '1:04.10', '1:04.20']);
    expect(() => editKeynotes(list, [{ op: 'delete', key: '04', folder: true }])).toThrow(/not empty/);
    const renamed = editKeynotes(list, [{ op: 'modify', key: '04', folder: true, new_key: '4' }]);
    expect(renamed.filter((k) => k.parent === '4')).toHaveLength(2);
    const back = parseKeynoteFile(keynoteFileText(list));
    expect(back.find((k) => k.key === '04').folder).toBe(true);
    expect(back.find((k) => k.key === '04.20')).toMatchObject({ title: 'Brick wall', parent: '04', folder: false });

    const { app, doc, wall } = fakeApp();
    const w = wall([0, 0], [4000, 0]);
    await runTool(app, 'keynotes', { action: 'create', entries: [{ key: '04', title: 'Masonry', folder: true }, { key: '04.20', title: 'Brick wall', parent: '04' }] });
    expect((await runTool(app, 'keynotes', { action: 'assign', key: '09.99', ids: [w.id] })).error).toMatch(/No keynote/);
    await runTool(app, 'keynotes', { action: 'assign', key: '04.20', ids: [w.id], to_type: true });
    expect(doc.get(w.typeId).keynote).toBe('04.20');
    expect((await runTool(app, 'keynotes', { action: 'search', query: 'brick' })).entries).toHaveLength(1);
  });

  it('views, view templates and attributes', async () => {
    const { app, doc, plan } = fakeApp();
    const found = await runTool(app, 'views', { action: 'search', kind: 'plan' });
    expect(found.views.some((v) => v.name === plan.name && v.active)).toBe(true);
    doc.transact('t', () => doc.add({ kind: 'viewTemplate', name: 'Coarse Plan', viewKind: 'plan', settings: { detail: 'coarse', scale: 200 } }));
    const ap = await runTool(app, 'views', { action: 'apply_template', template: 'coarse' });
    expect(ap.success).toBe(true);
    const st = await runTool(app, 'views', { action: 'settings' });
    expect(st.views[0]).toMatchObject({ scale: '1:200', detail: 'coarse', template: 'Coarse Plan' });
    const attrs = await runTool(app, 'attribute_search', { type: 'composite' });
    expect(attrs.total_count).toBeGreaterThan(0);
    expect(attrs.attributes[0].layers.length).toBeGreaterThan(0);
  });
});

describe('assistant selection and favorites', () => {
  it('add to and remove from the selection, and make a favorite the tool default', async () => {
    const { app, doc, wall } = fakeApp();
    const a = wall([0, 0], [4000, 0]);
    const b = wall([4000, 0], [4000, 3000]);
    app.select = (ids, mode) => (mode === 'add' ? ids.forEach((id) => app.selection.add(id)) : ids.forEach((id) => app.selection.delete(id)));
    const armed = new Map();
    app.armFavorite = (kind, id) => armed.set(kind, id);
    app.setCurrentType = () => {};
    await runTool(app, 'select_elements', { ids: [a.id] });
    await runTool(app, 'select_elements', { ids: [b.id], mode: 'add' });
    expect(app.selection.size).toBe(2);
    expect((await runTool(app, 'select_elements', { ids: [a.id], mode: 'remove' })).selected).toBe(1);
    await runTool(app, 'favorites', { action: 'save', name: 'Party wall', ids: [b.id] });
    const r = await runTool(app, 'favorites', { action: 'set_defaults', name: 'party wall' });
    expect(r).toEqual({ defaults: 'wall', favorite: 'Party wall' });
    expect(doc.get(armed.get('wall')).name).toBe('Party wall');
  });
});
