import { describe, it, expect } from 'vitest';
import { bridgeOpenings } from '../src/core/recognize.js';

// Two piers 800 deep in front of a thin wall, 2.6 m apart (a niche for the fridges): the glass-like lines of the counter
// in front of the niche must not make the piers one thick wall with a window.
describe('a recess between piers in front of a wall', () => {
  const thin = { a: [500, 0], b: [500, 8000], thickness: 150 };
  const pierA = { a: [0, 1000], b: [0, 2000], thickness: 850 };
  const pierB = { a: [0, 4600], b: [0, 5000], thickness: 850 };
  it('is not bridged when a wall runs along it', () => {
    const out = bridgeOpenings([thin, pierA, pierB], {}, { classify: () => 'window', maxGap: 6000 });
    expect(out.openings.length).toBe(0);
    expect(out.walls.filter((w) => w.thickness === 850).length).toBe(2);
  });
  it('is bridged when nothing runs along it', () => {
    const out = bridgeOpenings([pierA, pierB], {}, { classify: () => 'window', maxGap: 6000 });
    expect(out.openings.length).toBe(1);
  });
  it('is bridged when the wall alongside has a gap of its own there (a door through both)', () => {
    const a = { a: [500, 0], b: [500, 2000], thickness: 150 };
    const b = { a: [500, 4600], b: [500, 8000], thickness: 150 };
    const out = bridgeOpenings([a, b, pierA, pierB], {}, { classify: () => 'door', maxGap: 6000 });
    expect(out.openings.length).toBe(2);
  });
  it('joins a gap a classifier calls solid (the back of a niche) without an opening', () => {
    const out = bridgeOpenings([pierA, pierB], {}, { classify: () => 'solid', maxGap: 6000 });
    expect(out.openings.length).toBe(0);
    expect(out.walls.length).toBe(1);
  });
});
