import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { energyReport } from '../src/core/energy.js';
import { thermalProperties } from '../src/core/materials.js';

describe('energy evaluation', () => {
  it('adds up walls, windows and ventilation for a room', () => {
    const p = project();
    // A 6 x 4 m single-story room of concrete exterior walls (centred, 283 thick).
    for (const [a, b] of [[[0, 0], [6000, 0]], [[6000, 0], [6000, 4000]], [[6000, 4000], [0, 4000]], [[0, 4000], [0, 0]]]) p.wall(a, b, { typeId: 'wt-ext-concrete' });
    const south = p.doc.all('wall')[0];
    p.add({ kind: 'window', typeId: p.doc.all('windowType')[0].id, hostId: south.id, levelId: p.L1.id, t: 3000, width: 1500, height: 1200 });
    const room = p.add({ kind: 'room', levelId: p.L1.id, at: [3000, 2000], name: 'Room', upperOffset: 2700 });
    const scene = new Scene(p.doc);
    const { rows, totals } = energyReport(p.doc, scene, { inside: 20, outside: -5, ach: 0.5 });
    expect(rows.length).toBe(1);
    const r = rows[0];
    const inner = [6000 - 283, 4000 - 283];
    expect(r.area).toBeCloseTo((inner[0] * inner[1]) / 1e6, 2);
    expect(r.windows).toBeCloseTo(1.8, 6);
    const perimeter = 2 * (inner[0] + inner[1]);
    expect(r.walls).toBeCloseTo((perimeter * 2700) / 1e6 - 1.8, 2);
    const U = thermalProperties(p.doc, p.doc.get('wt-ext-concrete')).u;
    // No roof or slab here: walls and the window only.
    expect(r.roof + r.floor).toBe(0);
    expect(r.HT).toBeCloseTo(U * r.walls + 1.4 * 1.8, 6);
    expect(r.HV).toBeCloseTo(0.34 * 0.5 * r.volume, 6);
    expect(r.load).toBeCloseTo((r.HT + r.HV) * 25, 6);
    expect(totals.load).toBeCloseTo(r.load, 6);
    expect(room.id).toBe(r.room.id);
  });
});

describe('energy evaluation, roof', () => {
  it('counts the roof over a single-story room', () => {
    const p = project();
    for (const [a, b] of [[[0, 0], [6000, 0]], [[6000, 0], [6000, 4000]], [[6000, 4000], [0, 4000]], [[0, 4000], [0, 0]]]) p.wall(a, b, { typeId: 'wt-ext-concrete' });
    p.add({ kind: 'room', levelId: p.L1.id, at: [3000, 2000], name: 'Room' });
    p.add({ kind: 'roof', typeId: p.doc.all('roofType')[0].id, levelId: p.L2.id, boundary: [[-500, -500], [6500, -500], [6500, 4500], [-500, 4500]], slopes: [30, 30, 30, 30], baseOffset: 0 });
    const r = energyReport(p.doc, new Scene(p.doc)).rows[0];
    expect(r.roof).toBeCloseTo(r.area, 6);
  });
});
