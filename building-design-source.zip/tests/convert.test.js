import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { segmentsOf, chainLoops, wallPairs, convertLines } from '../src/core/convert.js';
import { Scene } from '../src/core/scene.js';
import { typeThickness } from '../src/core/catalog.js';

const rect = (x0, y0, x1, y1) => [
  { a: [x0, y0], b: [x1, y0] },
  { a: [x1, y1], b: [x1, y0] },
  { a: [x1, y1], b: [x0, y1] },
  { a: [x0, y0], b: [x0, y1] },
];

describe('converting lines', () => {
  it('chains lines into closed loops, whatever their direction', () => {
    const { loops, open } = chainLoops([...rect(0, 0, 4000, 3000), { a: [9000, 0], b: [9500, 0] }]);
    expect(loops).toHaveLength(1);
    expect(loops[0]).toHaveLength(4);
    expect(open).toHaveLength(1);
  });

  it('pairs parallel face lines into walls of their thickness', () => {
    const { walls, rest } = wallPairs([{ a: [0, 0], b: [5000, 0] }, { a: [5000, 300], b: [0, 300] }, { a: [0, 2000], b: [5000, 2000] }]);
    expect(walls).toEqual([{ a: [0, 150], b: [5000, 150], thickness: 300 }]);
    expect(rest).toHaveLength(1);
  });

  it('reads arcs and splines as short pieces', () => {
    const s = segmentsOf([{ kind: 'detailArc', c: [0, 0], r: 1000, a0: 0, a1: Math.PI }, { kind: 'spline', path: [[0, 0], [100, 100], [200, 0]] }, { kind: 'text' }]);
    expect(s.length).toBeGreaterThan(18);
  });

  it('makes walls, slabs and zones on a level', () => {
    const { doc, L1 } = project();
    let r;
    // A room drawn as double face lines, 250 mm apart.
    const faces = [...rect(0, 0, 6000, 4000), ...rect(250, 250, 5750, 3750)];
    doc.transact('w', () => (r = convertLines(doc, faces, 'wallPairs', { levelId: L1.id })));
    expect(r.ids).toHaveLength(4);
    const w = doc.get(r.ids[0]);
    expect(Math.abs(typeThickness(doc.get(w.typeId)) - 250)).toBeLessThan(100);
    doc.transact('s', () => (r = convertLines(doc, rect(0, 0, 6000, 4000), 'slabs', { levelId: L1.id })));
    expect(doc.get(r.ids[0]).boundary).toHaveLength(4);
    const { doc: d2, L1: l2 } = project();
    d2.transact('z', () => (r = convertLines(d2, rect(0, 0, 5000, 4000), 'zones', { levelId: l2.id })));
    const room = r.ids.map((id) => d2.get(id)).find((e) => e.kind === 'room');
    expect(new Scene(d2).rooms.room(room).area).toBeCloseTo(20e6, -3);
  });
});

describe('walls from cut fills', () => {
  it('pair the opposite edges of filled wall shapes', async () => {
    const { wallsFromPolygons, fillColors } = await import('../src/core/convert.js');
    const L = [[0, 0], [5000, 0], [5000, 3000], [4750, 3000], [4750, 250], [0, 250]];
    const w = wallsFromPolygons([L]);
    expect(w.map((x) => x.thickness).sort()).toEqual([250, 250]);
    expect(fillColors([{ fill: true, closed: true, pts: L, fillColor: '#4a4a4a' }, { fill: true, closed: true, pts: L, fillColor: '#ffffff' }, { fill: false, closed: true, pts: L, fillColor: '#4a4a4a' }])).toEqual([{ color: '#4a4a4a', count: 1 }]);
  });

  it('make a generic type when no wall type is near the thickness', async () => {
    const { wallTypeMaking } = await import('../src/core/floorplan.js');
    const { project } = await import('./helpers.js');
    const { typeThickness } = await import('../src/core/catalog.js');
    const { doc } = project();
    let t;
    doc.transact('t', () => (t = wallTypeMaking(doc, 347, false)));
    expect(t.name).toBe('Generic - 347 mm');
    expect(typeThickness(t)).toBe(347);
    let again;
    doc.transact('t2', () => (again = wallTypeMaking(doc, 347, false)));
    expect(again.id).toBe(t.id);
    expect(doc.get(wallTypeMaking(doc, 200, true)?.id)?.curtain).toBeFalsy();
  });
});
