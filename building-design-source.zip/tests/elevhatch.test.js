import { describe, it, expect } from 'vitest';
import { hatchSegments } from '../src/core/elevhatch.js';

describe('surface hatches in elevations', () => {
  // A face 2 m wide and 1 m high in the plane y = 0, turned to +y; the viewer stands at +y looking along -y.
  const mesh = { pos: new Float32Array([0, 0, 0, 2000, 0, 1000, 2000, 0, 0, 0, 0, 0, 0, 0, 1000, 2000, 0, 1000]) };
  const frame = { origin: [0, 5000], look: [0, -1], right: [-1, 0] };
  it('lays tile courses on the faces seen, on the face itself', () => {
    const segs = hatchSegments(frame, [{ mesh, hatch: 'tiles' }]);
    expect(segs.length).toBeGreaterThan(0);
    // Every point on the face (y = 0), courses horizontal at multiples of 250 mm.
    for (let i = 0; i < segs.length; i += 3) expect(Math.abs(segs[i + 1])).toBeLessThan(1e-6);
    const zs = new Set();
    for (let i = 2; i < segs.length; i += 3) zs.add(Math.round(segs[i]));
    for (const z of zs) expect(z % 250).toBe(0);
  });
  it('leaves faces turned away alone', () => {
    expect(hatchSegments({ ...frame, origin: [0, -5000], look: [0, 1], right: [1, 0] }, [{ mesh, hatch: 'tiles' }]).length).toBe(0);
  });
  it('hatches only the upward faces of a roof', () => {
  // A slope rising away from a viewer at -y (normal up and towards -y) and a vertical end face towards -y.
  const slope = { pos: new Float32Array([0, 0, 0, 2000, 0, 0, 2000, 2000, 600, 0, 0, 0, 2000, 2000, 600, 0, 2000, 600]) };
  const end = { pos: new Float32Array([0, 0, 0, 2000, 0, 0, 2000, 0, 300, 0, 0, 0, 2000, 0, 300, 0, 0, 300]) };
  const frame = { origin: [0, -5000], look: [0, 1], right: [1, 0] };
  expect(hatchSegments(frame, [{ mesh: slope, hatch: 'tiles', up: true }]).length).toBeGreaterThan(0);
  expect(hatchSegments(frame, [{ mesh: end, hatch: 'tiles', up: true }]).length).toBe(0);
  expect(hatchSegments(frame, [{ mesh: end, hatch: 'tiles' }]).length).toBeGreaterThan(0);
  });
});
