import { describe, it, expect } from 'vitest';
import { runGDL, parse, gdlPolygon } from '../src/core/gdl.js';
import { runGdlType } from '../src/core/gdlobject.js';

describe('GDL', () => {
  it('evaluates expressions with degrees, strings and arrays', () => {
    const r = runGDL(`x = 2 + 3 * 4 ^ 2 / 8
s = "a" + "b"
y = SIN(90) + COS(0) + ATN(1)
DIM v[3]
FOR i = 1 TO 3
  v[i] = i * i
NEXT i
z = v[3] + (5 MOD 3) + NOT(0) + (1 AND 0) + (1 OR 0)`);
    expect(r.vars.X).toBe(8);
    expect(r.vars.S).toBe('ab');
    expect(r.vars.Y).toBeCloseTo(47, 9);
    expect(r.vars.Z).toBe(9 + 2 + 1 + 0 + 1);
  });

  it('runs IF blocks, one-line IF, WHILE, REPEAT, GOSUB and labels', () => {
    const r = runGDL(`n = 0
IF n = 0 THEN
  a = 1
ELSE
  a = 2
ENDIF
IF a = 1 THEN b = 10 ELSE b = 20
WHILE n < 5 DO
  n = n + 1
ENDWHILE
REPEAT
  n = n - 2
UNTIL n < 0
GOSUB 100
END
100:
  c = 7
RETURN`);
    expect(r.vars).toMatchObject({ A: 1, B: 10, N: -1, C: 7 });
  });

  it('stops a script that never ends, and says where an error is', () => {
    expect(() => runGDL('1:\nGOTO 1', { maxSteps: 1000 })).toThrow(/too long/);
    expect(() => runGDL('x = 1\nFOO 1, 2')).toThrow(/Line 2: Unknown command FOO/);
    expect(() => parse('IF 1 THEN\nx = 1')).toThrow(/not closed/);
  });

  it('makes bodies through the transformation stack', () => {
    const r = runGDL(`MATERIAL "mat-wood"
BLOCK 1, 0.5, 0.2
ADDZ 0.2
ROTZ 90
BLOCK 1, 0.5, 0.1
DEL 2
ADD 2, 0, 0
CYLIND 1, 0.1
DEL TOP
SPHERE 0.3`);
    expect(r.tris.length).toBeGreaterThan(24 + 24);
    // The turned block lies along y, from z 0.2 to 0.3.
    const zs = r.tris.flatMap((t) => [t.a[2], t.b[2], t.c[2]]);
    expect(Math.max(...zs)).toBeCloseTo(1, 6);
    expect(r.tris.every((t) => t.mat === 'mat-wood')).toBe(true);
  });

  it('reads polygon status codes for arcs', () => {
    const p = gdlPolygon([[1, 0, 1], [0, 0, 900], [0, 180, 4001]], 4);
    expect(p[0]).toEqual([1, 0]);
    expect(p.at(-1)[0]).toBeCloseTo(-1, 9);
    expect(p.length).toBeGreaterThan(5);
  });

  it('makes a parametric object from a type, in millimetres, centred', () => {
    const type = {
      width: 1200,
      depth: 600,
      height: 750,
      gdl: {
        params: [{ name: 'top', kind: 'length', value: 40 }, { name: 'legs', kind: 'boolean', value: true }],
        script3d: `ADDZ ZZYZX - top
BLOCK A, B, top
DEL 1
IF legs THEN
  FOR i = 0 TO 1
    FOR j = 0 TO 1
      ADD 0.05 + i * (A - 0.1), 0.05 + j * (B - 0.1), 0
      CYLIND ZZYZX - top, 0.025
      DEL 1
    NEXT j
  NEXT i
ENDIF`,
        script2d: 'RECT2 0, 0, A, B\nLINE2 0, 0, A, B',
      },
    };
    const r = runGdlType(type);
    expect(r.error).toBeNull();
    const xs = r.tris.flatMap((t) => [t.a[0], t.b[0], t.c[0]]);
    expect(Math.min(...xs)).toBeCloseTo(-600, 6);
    expect(Math.max(...xs)).toBeCloseTo(600, 6);
    expect(r.polys[0].pts[2]).toEqual([600, 300, 0]);
    expect(r.lines).toHaveLength(1);
    const noLegs = runGdlType(type, { legs: false });
    expect(noLegs.tris.length).toBeLessThan(r.tris.length);
  });
});

describe('GDL bodies by their conventions', () => {
  it('revolves a profile about the x axis from the x-y plane towards +z', () => {
    const r = runGDL('REVOLVE 2, 90, 0, 0, 1, 0, 2, 1, 0');
    const pts = r.tris.flatMap((t) => [t.a, t.b, t.c]);
    const xs = pts.map((p) => p[0]);
    expect(Math.min(...xs)).toBeCloseTo(0, 6);
    expect(Math.max(...xs)).toBeCloseTo(2, 6);
    // A quarter turn: y and z both from 0 to the radius, never below.
    expect(Math.min(...pts.map((p) => p[1]))).toBeGreaterThan(-1e-9);
    expect(Math.min(...pts.map((p) => p[2]))).toBeGreaterThan(-1e-9);
    expect(Math.max(...pts.map((p) => p[2]))).toBeCloseTo(1, 6);
  });

  it('draws an arc to a point the shorter way round its centre', async () => {
    const { gdlPolygon } = await import('../src/core/gdl.js');
    const p = gdlPolygon([[0.22, 0.02, 1], [0, 1, 900], [-0.22, 0.02, 3001]], 8);
    expect(Math.min(...p.map((q) => q[1]))).toBeGreaterThan(-0.01);
  });

  it('reads prisms with materials per point, two cutting planes and a profile tube', () => {
    const box = (r) => {
      const pts = r.tris.flatMap((t) => [t.a, t.b, t.c]);
      return [0, 1, 2].map((k) => [Math.min(...pts.map((p) => p[k])), Math.max(...pts.map((p) => p[k]))]);
    };
    // CPRISM_{3}: three materials, a mask, n, h; each point x, y, angle, status, material.
    expect(box(runGDL('CPRISM_{3} 1, 1, 1, 0, 4, 0.5, 0, 0, 0, 15, 1, 2, 0, 0, 15, 1, 2, 1, 0, 15, 1, 0, 1, 0, 15, 1'))).toEqual([[0, 2], [0, 1], [0, 0.5]]);
    // SPRISM_{2}: n, then a top and a bottom plane (line, height, angle), then points x, y, status, material.
    expect(box(runGDL('SPRISM_{2} 1, 1, 1, 4, 0, 0, 1, 0, 2, 0, 0, 0, 1, 0, 0.5, 0, 0, 0, 15, 1, 1, 0, 15, 1, 1, 1, 15, 1, 0, 1, 15, 1'))[2]).toEqual([0.5, 2]);
    // BPRISM_: the bending radius comes before the points.
    expect(box(runGDL('BPRISM_ 1, 1, 1, 4, 0.1, 3, 0, 0, 15, 1, 0, 15, 1, 1, 15, 0, 1, 15'))[0]).toEqual([0, 1]);
    // TUBE{2}: three materials, then a TUBE whose profile points carry a material.
    const tube = runGDL('TUBE{2} 1, 1, 1, 4, 4, 0, 0, 0, 2, 1, 0.1, 0, 2, 1, 0.1, 0.1, 2, 1, 0, 0.1, 2, 1, -1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0');
    expect(tube.tris.length).toBeGreaterThan(0);
    expect(tube.unknown.size).toBe(0);
  });
});

describe('GDL bodies from the element commands', () => {
  const box = (r) => {
    const pts = r.tris.flatMap((t) => [t.a, t.b, t.c]);
    return [0, 1, 2].map((k) => [Math.min(...pts.map((p) => p[k])), Math.max(...pts.map((p) => p[k]))].map((v) => +v.toFixed(3)));
  };

  it('lays slabs and masses through their points heights', () => {
    expect(box(runGDL('CSLAB_ 1,1,1, 4, 0.1, 0,0,1,15, 2,0,1,15, 2,3,2,15, 0,3,2,15'))).toEqual([[0, 2], [0, 3], [1, 2.1]]);
    expect(box(runGDL('MASS 1,1,1, 4, 0, 21, 0, 0,0,1,15, 2,0,1,15, 2,3,2,15, 0,3,2,15'))).toEqual([[0, 2], [0, 3], [0, 2]]);
  });

  it('lifts a roof to the plane rising left of its reference line', () => {
    const r = box(runGDL('CROOF_ 1,1,1, 4, 0,0, 1,0, 0, 45, 0.1, 0,0,0,15, 1,0,0,15, 1,1,0,15, 0,1,0,15'));
    expect(r[2][1]).toBeCloseTo(1, 6);
    expect(r[2][0]).toBeCloseTo(-0.141, 3);
  });

  it('builds a wall around its openings', () => {
    const solid = runGDL('CWALL_ 1,1,1, 2, 0, 3, 3, 0, 0.3, 15,15,15,15, 0, 0');
    const open = runGDL('CWALL_ 1,1,1, 2, 0, 3, 3, 0, 0.3, 15,15,15,15, 1, 1, 0.5, 2, 1.5, -255, 0');
    expect(box(open)).toEqual(box(solid));
    // Nothing inside the opening.
    const inside = open.tris.filter((t) => [t.a, t.b, t.c].every((p) => p[0] > 1.01 && p[0] < 1.99 && p[2] > 0.51 && p[2] < 1.49));
    expect(inside).toHaveLength(0);
  });

  it('turns about any axis with ROT', () => {
    expect(box(runGDL('ROT 0, 0, 1, 90\nBLOCK 2, 1, 1'))).toEqual([[-1, 0], [0, 2], [0, 1]]);
  });
});

describe('GDL primitive bodies', () => {
  const tri = (k) => `VERT 0, 0, ${k}\nVERT 1, 0, ${k}\nVERT 0, 1, ${k}\nEDGE 1, 2, 1, -1, ${k ? 3 : 0}\nEDGE 2, 3, 1, -1, 0\nEDGE 3, 1, 1, -1, 0\nPGON 3, 0, 0, 1, 2, 3`;

  it('keeps what BASE leaves for BODY, numbering vertices afresh', () => {
    const r = runGDL(`${tri(0)}\nBASE\n${tri(1)}\nBASE\nBODY -1`);
    expect(r.tris).toHaveLength(2);
    expect(r.tris.map((t) => t.a[2])).toEqual([0, 1]);
  });

  it('makes a body of primitives a script leaves open, without the edges it hides', () => {
    const r = runGDL(tri(1));
    expect(r.tris).toHaveLength(1);
    // The first edge (status 3: invisible, smooth) is not drawn.
    expect(r.edges).toHaveLength(2);
  });
});

describe('GDL textures', () => {
  it('maps a defined texture onto a polygon by its texture coordinate system', () => {
    const r = runGDL(`
DEFINE TEXTURE "Tree" 9, 4, 8, 1, 0
DEFINE MATERIAL "TreeMat" 20, 0, 0, 0, 0.5, 0.8, 0, 0.25, 20, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, IND(TEXTURE, "Tree")
MATERIAL "TreeMat"
VERT 0, 0, 0
VERT 4, 0, 0
VERT 4, 0, 8
VERT 0, 0, 8
EDGE 1, 2, 0, 0, 0
EDGE 2, 3, 0, 0, 0
EDGE 3, 4, 0, 0, 0
EDGE 4, 1, 0, 0, 0
PGON{2} 4, 0, 0, 6, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 2, 3, 4
BODY 1`);
    expect(r.tris).toHaveLength(2);
    expect(r.tris[0].tex).toEqual({ pic: 9, w: 4, h: 8 });
    expect(r.tris[0].alpha).toBeCloseTo(0.75, 9);
    expect(r.tris[0].uv.map((p) => p.map((v) => +v.toFixed(6)))).toEqual([[0, 0], [1, 0], [1, 1]]);
    // A cut-out picture draws no outline.
    expect(r.edges).toHaveLength(0);
  });

  it('draws splines through their points, along their tangents', () => {
    const r = runGDL('SPLINE2A 2, 0, 0, 0, 90, 0, 1, 1, 0, 270, 1, 0', { mode: '2d' });
    expect(r.lines2).toHaveLength(8);
    expect(r.lines2[3][1].map((v) => +v.toFixed(3))).toEqual([0.5, 0.75]);
    expect(r.lines2[7][1].map((v) => +v.toFixed(9))).toEqual([1, 0]);
    expect(runGDL('SPLINE2 3, 1, 0, 0, 0, 1, 0, 90, 0, 1, 180', { mode: '2d' }).lines2).toHaveLength(24);
  });

  it('places a plan picture with the 2D transformation', () => {
    const r = runGDL('ADD2 1, 2\nROT2 90\nPICTURE2{2} 7, 2, 1, 1', { mode: '2d' });
    expect(r.pictures2).toHaveLength(1);
    expect(r.pictures2[0].pic).toBe(7);
    expect(r.pictures2[0].pts.map((p) => p.map((v) => +v.toFixed(9)))).toEqual([[1, 2], [1, 4], [0, 4], [0, 2]]);
  });

  it('shows a picture on a rectangle', () => {
    const r = runGDL('PICTURE 1, 2, 3, 0');
    expect(r.tris.map((t) => t.tex)).toEqual([{ pic: 1, w: 2, h: 3 }, { pic: 1, w: 2, h: 3 }]);
    expect(r.tris[1].c).toEqual([0, 3, 0]);
  });
});

describe('GDL macros as Archicad runs them', () => {
  it('reads library globals from a settings object, and runs a macro master and script as one', () => {
    const macros = {
      DW_MVOSETTINGS: { params: [{ name: 'iDoor2DDetlevel', value: 16 }, { name: 'iDoor3DDetlevel', value: 1 }], scripts: {} },
      GETGLOBALS: {
        params: [],
        scripts: {
          master: 'goto "masterEnd"\n"readLevel":\n  ok = LIBRARYGLOBAL("DW_MVOSettings", "iDoor2DDetlevel", level)\nreturn\n"masterEnd":',
          script3d: 'gosub "readLevel"\nend level, ok',
        },
      },
    };
    const r = runGDL('CALL "GetGlobals" PARAMETERS RETURNED_PARAMETERS lv, found\nmissing = LIBRARYGLOBAL("Nowhere", "x", y)', { lenient: true, macros: (n) => macros[String(n).toUpperCase()] || null });
    expect([r.vars.LV, r.vars.FOUND, r.vars.MISSING]).toEqual([16, 1, 0]);
    // The app's model view options ask for full 3D detail over the stored schematic default.
    const full = runGDL('ok = LIBRARYGLOBAL("DW_MVOSettings", "iDoor3DDetlevel", d)', { lenient: true, macros: (n) => macros[String(n).toUpperCase()] || null });
    expect([full.vars.OK, full.vars.D]).toEqual([1, 3]);
  });

  it('shares the parameter buffer with a macro, and draws a macro called inside a group into it', () => {
    const macros = {
      PROFILE: { params: [], scripts: { master: '', script3d: 'put 0, 0, 1, 0, 1, 1, 0, 1' } },
      BOX: { params: [], scripts: { master: '', script3d: 'block 1, 1, 1' } },
    };
    const r = runGDL('call "profile"\nn = nsp / 2\ngroup "g"\ncall "box"\nendgroup\nk = 0', { lenient: true, macros: (n) => macros[String(n).toUpperCase()] || null });
    expect(r.vars.N).toBe(4);
    expect(r.tris.length).toBe(0);
    expect(r.groups.get('g').filter((t) => !t.edge).length).toBe(12);
  });

  it('works out a FOR loop\'s end once, as it starts', () => {
    // A loop to NSP / 4 that GETs four values a turn reads them all.
    const r = runGDL('put 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12\nn = 0\nfor i = 1 to nsp / 4\n  a = get(4)\n  n = n + 1\nnext i\nk = 0\nfor j = 1 to 10 step k + 2\n  k = k + 5\nnext j', { lenient: true });
    expect(r.vars.N).toBe(3);
    // The step too: 1, 3, 5, 7, 9.
    expect(r.vars.K).toBe(25);
  });

  it('places a group where the transformations at PLACEGROUP put it, and counts them with NTR', () => {
    // A fixing defined once under a rotation and placed at two points along an edge.
    const r = runGDL('rotz 90\ngroup "fix"\nblock 0.1, 0.1, 0.1\nendgroup\nn0 = ntr()\nadd 1, 0, 0\nplacegroup "fix"\ndel 1\nadd 3, 0, 0\nplacegroup "fix"\ndel ntr() - n0', { lenient: true });
    const xs = r.tris.flatMap((t) => [t.a[0], t.b[0], t.c[0]]);
    const ys = r.tris.flatMap((t) => [t.a[1], t.b[1], t.c[1]]);
    expect(r.vars.N0).toBe(1);
    // Placed under the quarter turn still in force: its moves run along y, each block 0.1 across x.
    expect([Math.min(...xs), Math.max(...xs)].map((v) => +v.toFixed(6))).toEqual([-0.1, 0]);
    expect([Math.min(...ys), Math.max(...ys)].map((v) => +v.toFixed(6))).toEqual([1, 3.1]);
    expect(r.tris.length).toBe(24);
  });

  it('gives a C-prism its holes and its top, bottom and side materials', () => {
    // A square frame: the outline, then a hole after the status -1 point that closes it.
    const r = runGDL('cprism_{2} "mat-glass", "mat-glass", "mat-steel", 10, 0.1, 0, 0, 0, 15, "mat-steel", 1, 0, 0, 15, "mat-steel", 1, 1, 0, 15, "mat-steel", 0, 1, 0, 15, "mat-steel", 0, 0, 0, -1, "mat-steel", 0.2, 0.2, 0, 15, "mat-steel", 0.8, 0.2, 0, 15, "mat-steel", 0.8, 0.8, 0, 15, "mat-steel", 0.2, 0.8, 0, 15, "mat-steel", 0.2, 0.2, 0, -1, "mat-steel"', { lenient: true });
    const top = r.tris.filter((t) => [t.a, t.b, t.c].every((p) => Math.abs(p[2] - 0.1) < 1e-9));
    const area = top.reduce((a, t) => a + Math.abs((t.b[0] - t.a[0]) * (t.c[1] - t.a[1]) - (t.c[0] - t.a[0]) * (t.b[1] - t.a[1])) / 2, 0);
    expect(area).toBeCloseTo(1 - 0.36, 6);
    expect(top.every((t) => t.mat === 'mat-glass')).toBe(true);
    // The inner sides are there too: 8 quads of sides.
    expect(r.tris.filter((t) => t.mat === 'mat-steel').length).toBe(16);
    // A building material's surface is the material itself.
    const b = runGDL('ok = request{2} ("Building_Material_info", "mat-glass", "gs_bmat_surface", surf)', { lenient: true });
    expect([b.vars.OK, b.vars.SURF]).toEqual([1, 'mat-glass']);
  });

  it('carries a continued line over blank and comment lines', () => {
    const r = runGDL('t = 79\nif t = 73 | \\\n\n\tt = 80 | \\\n  ! note\n\tt = 81 then\nx = 1\nendif\ny = 2', { lenient: true });
    expect([r.vars.T, r.vars.X, r.vars.Y]).toEqual([79, undefined, 2]);
  });

  it('lets the macros a part calls see the global variables its host sets', () => {
    // A window's wall thickness and a stair tread's polygon are globals: a macro reads them as the part does.
    const macros = { DEPTH: { params: [], scripts: { master: '', script3d: 'n = vardim1(STAIR_TREAD_GEOMETRY)\nend WALL_THICKNESS, n' } } };
    const r = runGDL('CALL "depth" PARAMETERS RETURNED_PARAMETERS t, n', { lenient: true, vars: { WALL_THICKNESS: 0.3, STAIR_TREAD_GEOMETRY: [[], [0, 0, 0, 0], [0, 1, 0, 0]], OWN: 1 }, macros: (n) => macros[String(n).toUpperCase()] || null });
    expect([r.vars.T, r.vars.N]).toEqual([0.3, 2]);
  });
});

describe('GDL values', () => {
  it('copies dictionaries on assignment, finds keys with HASKEY and reads keywords as fields', () => {
    const r = runGDL(`
dict d
d.offset[3].front = 2
dict e
e = d
e.offset[3].front = 5
n = vardim1(d.offset)
h1 = HASKEY(d.offset[3].front)
h2 = HASKEY(d.offset[2].front)
dict p
p.start = 1
p.end = 4
len = p.end - p.start`);
    expect(r.vars.D.OFFSET[3].FRONT).toBe(2);
    expect(r.vars.E.OFFSET[3].FRONT).toBe(5);
    expect([r.vars.N, r.vars.H1, r.vars.H2, r.vars.LEN]).toEqual([3, 1, 0, 3]);
  });

  it('skips what a condition on a missing key guards, as Archicad stops it with an error', () => {
    const r = runGDL(`
dict g
if g.numValidEdges < 3 then end
x = 1
repeat
  k = k + 1
until g.missing = 1`);
    expect(r.vars.X).toBe(1);
    expect(r.vars.K).toBe(1);
  });

  it('gives one value for GET in an expression, all of them in a list, and reads inches and feet', () => {
    const r = runGDL(`
put 1, 2, 3, 4
a = get(1)
dim b[]
b[1] = 5
put get(3)
c = get(1) + get(1)
w = 29" + 7/8"
f = 2'`);
    expect([r.vars.A, r.vars.C]).toEqual([1, 5]);
    expect(r.vars.W).toBeCloseTo(29.875 * 0.0254, 9);
    expect(r.vars.F).toBeCloseTo(0.6096, 9);
  });

  it('jumps to a label a variable names', () => {
    const r = runGDL(`
style = 2
gosub style
end
1:
  x = 1
return
2:
  x = 2
return`);
    expect(r.vars.X).toBe(2);
  });
});

describe('door and window commands on the wall in plan', () => {
  it('records WALLHOLE2, WALLBLOCK2, WALLLINE2 and WALLARC2 with the 2D transformations', () => {
    const r = runGDL(
      `ADD2 1, 0
WALLHOLE2 4, 1, 1, 0, 0, 0, 0, -0.5, 0, 1, -0.5, -0.3, 1, 0.5, -0.3, 1, 0.5, 0, 1
WALLHOLE2{2} 4, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0.5, -0.1, 1, 1, -0.1, 1, 1, -0.2, 1, 0.5, -0.2, 1
WALLBLOCK2 3, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1
WALLLINE2 0, 0, 1, 0
WALLARC2 0, 0, 1, 0, 90`,
      { mode: '2d' },
    );
    expect(r.wallHoles2).toHaveLength(2);
    expect(r.wallHoles2[0][0]).toEqual([0.5, 0]);
    expect(r.wallHoles2[1][1]).toEqual([2, -0.1]);
    expect(r.wallBlocks2).toHaveLength(1);
    expect(r.wallLines2[0]).toEqual([[1, 0], [2, 0]]);
    // The arc as short lines from (2, 0) round to (1, 1).
    expect(r.wallLines2.length).toBeGreaterThan(3);
    const last = r.wallLines2.at(-1)[1];
    expect(last[0]).toBeCloseTo(1);
    expect(last[1]).toBeCloseTo(1);
  });
});

describe('script forms the libraries use', () => {
  it('jumps to an expression, runs IF ... GOSUB and THEN:, and skips an unreadable line whole', () => {
    const r = runGDL(
      `k = 2
GOSUB 100 + k
IF k = 2 GOSUB 200
IF k = 2 THEN: m = 5: ENDIF
BLOCK 1, 1, 1
END
102: x = 7 : RETURN
200: y = 9 : RETURN`,
      { lenient: true },
    );
    expect(r.vars.X).toBe(7);
    expect(r.vars.Y).toBe(9);
    expect(r.vars.M).toBe(5);
    expect(r.tris.length).toBeGreaterThan(0);
  });

  it('reads mixed inches, typographic quotes and wide spaces', () => {
    const r = runGDL('a = 1 1/4"　\nb = ´x´', { lenient: true });
    expect(r.vars.A).toBeCloseTo(1.25 * 0.0254);
    expect(r.vars.B).toBe('x');
  });

  it("places a text block's paragraphs with RICHTEXT2", () => {
    const r = runGDL(
      `PARAGRAPH "p1" 1, 0, 0, 0, 1
PEN 1
"Room " + "12"
ENDPARAGRAPH
PARAGRAPH "p2" 1, 0, 0, 0, 1
"15.2 m2"
ENDPARAGRAPH
TEXTBLOCK "tb" 0, 5, 0, 1, 1, 1, "p1", "p2"
RICHTEXT2 1, 2, "tb"`,
      { mode: '2d' },
    );
    expect(r.texts2.map((t) => t.text)).toEqual(['Room 12', '15.2 m2']);
    expect(r.texts2[0].at).toEqual([1, 2]);
    expect(r.texts2[1].at[1]).toBeLessThan(2);
  });
});
