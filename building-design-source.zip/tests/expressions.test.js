import { describe, it, expect } from 'vitest';
import { parseExpression, evaluate, expressionFields, ExpressionError } from '../src/core/expressions.js';

const run = (src, fields = {}) => evaluate(parseExpression(src), (n) => fields[n.toLowerCase()]);

describe('expressions', () => {
  it('do arithmetic with the usual precedence', () => {
    expect(run('1 + 2 * 3')).toBe(7);
    expect(run('(1 + 2) * 3')).toBe(9);
    expect(run('2 ^ 3 ^ 2')).toBe(512);
    expect(run('-2 ^ 2')).toBe(-4);
    expect(run('10 / 4 - 1')).toBe(1.5);
    expect(run('7 % 3')).toBe(1);
  });

  it('compare, combine logic and choose with IF', () => {
    expect(run('IF({height} > 2.7, "High", "Standard")', { height: 3 })).toBe('High');
    expect(run('IF({height} > 2.7 AND {area} >= 20, 1, 0)', { height: 3, area: 12 })).toBe(0);
    expect(run('NOT({x} = 1) OR {y} <> "a"', { x: 1, y: 'A' })).toBe(false);
    expect(run('IF(1, 2, {missing})')).toBe(2);
  });

  it('work with text and functions', () => {
    expect(run('CONCAT({number}, " - ", UPPER({name}))', { number: '3', name: 'Kitchen' })).toBe('3 - KITCHEN');
    expect(run('{name} & " " & ROUND({area}, 1)', { name: 'Bath', area: 5.678 })).toBe('Bath 5.7');
    expect(run('MAX(1, {a}, 3) + MIN(4, 2) + ROUNDUP(1.21, 1)', { a: 5 })).toBeCloseTo(8.3, 9);
    expect(run('LEFT("Living", 3) & LEN("abc")')).toBe('Liv3');
  });

  it('list the fields they read, and explain mistakes', () => {
    expect([...expressionFields(parseExpression('{Area} * {Height} + {Area}'))]).toEqual(['Area', 'Height']);
    expect(() => parseExpression('1 +')).toThrow(ExpressionError);
    expect(() => parseExpression('FOO(1)')).toThrow(/Unknown function FOO/);
    expect(() => parseExpression('{Area')).toThrow(/closing/);
    expect(() => run('{Nope} + 1')).toThrow(/No field \{Nope\}/);
    expect(() => run('1 / 0')).toThrow(/zero/);
  });
});
