import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { WallSolver } from '../src/core/walls.js';
import { build3D, wallOpenings } from '../src/core/build3d.js';

describe('Corner windows', () => {
  it('open both walls right through the corner, without a jamb there', () => {
    const p = project();
    const w1 = p.wall([0, 0], [4000, 0]);
    const w2 = p.wall([4000, 0], [4000, 3000]);
    const type = p.doc.all('windowType')[0];
    const a = p.add({ kind: 'window', typeId: type.id, hostId: w1.id, t: 3400, width: 1200, sill: 900, corner: 'b' });
    const b = p.add({ kind: 'window', typeId: type.id, hostId: w2.id, t: 600, width: 1200, sill: 900, corner: 'a', cornerWith: a.id });
    p.doc.transact('pair', () => p.doc.update(a.id, { cornerWith: b.id }));
    const [o] = wallOpenings(p.doc, p.doc.get(w1.id), 0, 3000);
    expect(o.corner).toBe('b');
    const ctx = { doc: p.doc, walls: new WallSolver(p.doc), material: (id) => p.doc.get(id) };
    // The wall has nothing left at its corner end between the sill and the head.
    const wall = build3D(ctx, p.doc.get(w1.id));
    let solid = false;
    for (let i = 0; i < wall.pos.length; i += 3) if (wall.pos[i] > 3990 && wall.pos[i + 2] > 950 && wall.pos[i + 2] < 2050) solid = true;
    expect(solid).toBe(false);
    // The two windows' glass meets where their planes cross: the first window's glass ends at the second's plane.
    const span = (m, k) => {
      const v = [];
      for (let i = k; i < m.pos.length; i += 3) v.push(m.pos[i]);
      return [Math.min(...v), Math.max(...v)];
    };
    const wa = build3D(ctx, p.doc.get(a.id));
    const wb = build3D(ctx, p.doc.get(b.id));
    const ya = span(wa, 1);
    const xb = span(wb, 0);
    // Each frame is 100 deep at its wall's exterior face (the sill beyond it): window a reaches the middle of
    // window b's frame, not the wall's end at 4000, and b starts at the middle of a's.
    expect(span(wa, 0)[1]).toBeCloseTo(xb[1] - 50, 3);
    expect(span(wb, 1)[0]).toBeCloseTo(ya[0] + 50, 3);
  });
});
