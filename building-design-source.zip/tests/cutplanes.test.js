import { describe, it, expect } from 'vitest';
import { cutPlaneOf, viewCutPlanes, keptByCuts } from '../src/core/cutplanes.js';

describe('3D cutting planes', () => {
  it('cut above a height, or keep the other side when flipped', () => {
    expect(cutPlaneOf({ type: 'horizontal', z: 1200 })).toEqual([0, 0, 1, 1200]);
    expect(cutPlaneOf({ type: 'horizontal', z: 1200, flip: true })).toEqual([-0, -0, -1, -1200]);
    const view = { cutPlanes: [{ type: 'horizontal', z: 1200, on: true }] };
    expect(keptByCuts(view, [0, 0, 1000])).toBe(true);
    expect(keptByCuts(view, [0, 0, 1500])).toBe(false);
  });

  it('cut vertically through a point, and ignore planes that are off', () => {
    const v = cutPlaneOf({ type: 'vertical', at: [1000, 0], angle: 0 });
    expect(v[0]).toBeCloseTo(1, 9);
    expect(v[3]).toBeCloseTo(1000, 9);
    const view = { cutPlanes: [{ type: 'vertical', at: [1000, 0], angle: 90 }, { type: 'horizontal', z: 0, on: false }, { type: 'horizontal', z: 0 }] };
    expect(viewCutPlanes(view)).toHaveLength(2);
    expect(keptByCuts({ cutPlanes: [view.cutPlanes[0]] }, [5000, -10, 0])).toBe(true);
    expect(keptByCuts({ cutPlanes: [view.cutPlanes[0]] }, [5000, 10, 0])).toBe(false);
  });
});
