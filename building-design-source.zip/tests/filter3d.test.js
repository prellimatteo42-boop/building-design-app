import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { hiddenByStoryFilter } from '../src/core/filter3d.js';

describe('filter elements in 3D', () => {
  it('shows only the stories chosen, doors by their wall', () => {
    const { doc, wall, add, L1, L2 } = project();
    const w1 = wall([0, 0], [4000, 0]);
    const w2 = wall([0, 0], [4000, 0], { levelId: L2.id, topLevelId: null });
    const d = add({ kind: 'door', typeId: doc.all('doorType')[0].id, hostId: w2.id, t: 2000 });
    const view = { kind: 'view3d', storyFilter: { from: L2.id, to: L2.id } };
    expect(hiddenByStoryFilter(doc, view, doc.get(w1.id))).toBe(true);
    expect(hiddenByStoryFilter(doc, view, doc.get(w2.id))).toBe(false);
    expect(hiddenByStoryFilter(doc, view, doc.get(d.id))).toBe(false);
    expect(hiddenByStoryFilter(doc, { kind: 'view3d', storyFilter: { from: null, to: L1.id } }, doc.get(w2.id))).toBe(true);
    expect(hiddenByStoryFilter(doc, { kind: 'plan', storyFilter: { from: L2.id, to: L2.id } }, doc.get(w1.id))).toBe(false);
  });
});
