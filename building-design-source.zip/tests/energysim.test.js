import { describe, it, expect } from 'vitest';
import { project } from './helpers.js';
import { Scene } from '../src/core/scene.js';
import { energyReport } from '../src/core/energy.js';
import { annualEnergy, monthlyIrradiation, climateFor } from '../src/core/energysim.js';

function house(windowWall = 0) {
  const p = project();
  for (const [a, b] of [[[0, 0], [6000, 0]], [[6000, 0], [6000, 4000]], [[6000, 4000], [0, 4000]], [[0, 4000], [0, 0]]]) p.wall(a, b, { typeId: 'wt-ext-concrete' });
  const host = p.doc.all('wall')[windowWall];
  p.add({ kind: 'window', typeId: p.doc.all('windowType')[0].id, hostId: host.id, levelId: p.L1.id, t: 3000, width: 3000, height: 1800 });
  p.add({ kind: 'room', levelId: p.L1.id, at: [3000, 2000], name: 'Room', upperOffset: 2700 });
  return p;
}

describe('annual energy', () => {
  it('irradiation: plausible yearly totals and orientations', () => {
    const year = (az) => Array.from({ length: 12 }, (_, m) => monthlyIrradiation(45.5, m, az, 0.47) * [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m]).reduce((a, b) => a + b, 0);
    const hor = year(null);
    expect(hor).toBeGreaterThan(1100);
    expect(hor).toBeLessThan(1600);
    // In winter a south window gets far more than a north one; in summer the roof more than the south wall.
    expect(monthlyIrradiation(45.5, 0, 180, 0.47)).toBeGreaterThan(3 * monthlyIrradiation(45.5, 0, 0, 0.47));
    expect(monthlyIrradiation(45.5, 6, null, 0.47)).toBeGreaterThan(monthlyIrradiation(45.5, 6, 180, 0.47));
  });

  it('windows face where their wall faces', () => {
    const p = house(0); // the wall along y = 0: the room is north of it, so it faces south
    const r = energyReport(p.doc, new Scene(p.doc)).rows[0];
    const w = r.faces.find((f) => f.kind === 'window');
    expect(w.azimuth).toBeCloseTo(180, 6);
    expect(r.faces.filter((f) => f.kind === 'wall').map((f) => Math.round(f.azimuth)).sort((a, b) => a - b)).toEqual([0, 90, 180, 270]);
  });

  it('heats in winter, not in July; a south window needs less heating than a north one', () => {
    const doc = (w) => {
      const p = house(w);
      p.doc.transact('loc', () => p.doc.update('project', { location: { name: 'Milano', lat: 45.46, lon: 9.19, utcOffset: 1 } }));
      return p;
    };
    const south = doc(0);
    const north = doc(2);
    expect(climateFor(south.doc.get('project')).name).toBe('Milano');
    const s = annualEnergy(south.doc, new Scene(south.doc));
    const n = annualEnergy(north.doc, new Scene(north.doc));
    expect(s.months[0].heating).toBeGreaterThan(0);
    expect(s.months[6].heating).toBe(0);
    expect(s.annual.heating).toBeLessThan(n.annual.heating);
    expect(s.months[0].solar).toBeGreaterThan(n.months[0].solar * 2);
    // Delivered energy by the default condensing boiler, primary energy and cost follow.
    expect(s.annual.delivered.gas).toBeCloseTo(s.annual.heating / 0.95, 6);
    expect(s.annual.primary).toBeGreaterThan(0);
    expect(s.annual.cost).toBeGreaterThan(0);
  });
});

import { runTool } from '../src/assistant/tools.js';

describe('assistant energy tool', () => {
  it('changes the heating system and reports the annual balance', async () => {
    const p = house(0);
    const app = { doc: p.doc, scene: new Scene(p.doc), selection: new Set(), commit: (l, fn) => p.doc.transact(l, fn) };
    const gas = await runTool(app, 'energy_evaluation', { report: 'annual', settings: { climate: 'Roma' } });
    const hp = await runTool(app, 'energy_evaluation', { report: 'annual', settings: { heating_system: 'heatpump' } });
    expect(gas.climate).toBe('Roma');
    expect(hp.heating_kWh).toBe(gas.heating_kWh);
    expect(hp.delivered_kWh.electricity).toBeLessThan(gas.delivered_kWh.gas);
    expect((await runTool(app, 'energy_evaluation', { report: 'review' })).parts.some((x) => x.part === 'window' && x.facing_deg === 180)).toBe(true);
  });
});
