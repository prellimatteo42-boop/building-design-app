import { test, expect } from '@playwright/test';
import { openApp } from './helpers.js';

/** A Claude reply as the dev server's /api/claude returns it. */
const claudeReply = (content, stop_reason = 'end_turn') => ({ json: { role: 'assistant', content, stop_reason } });

test('check spelling suggests corrections and applies the accepted ones', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  // A stand-in for Claude behind the dev server.
  await page.route('**/api/claude', async (route) => {
    const list = JSON.parse(route.request().postDataJSON().messages[0].content);
    const bad = list.find((x) => x.text === 'Livng');
    await route.fulfill(claudeReply([{ type: 'text', text: JSON.stringify(bad ? [{ i: bad.i, corrected: 'Living' }] : []) }]));
  });
  await page.evaluate(() => {
    const app = window.bd;
    const room = app.doc.all('room')[0];
    app.commit('typo', () => app.doc.update(room.id, { name: 'Livng' }));
    window.__room = room.id;
    app.run('checkSpelling');
  });
  const dialog = page.getByRole('dialog', { name: 'Check Spelling' });
  await expect(dialog).toContainText('Livng');
  await dialog.getByRole('button', { name: 'Apply' }).click();
  expect(await page.evaluate(() => window.bd.doc.get(window.__room).name)).toBe('Living');
  expect(errors).toEqual([]);
});

test('the assistant runs the functions the AI asks for and shows the answer', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  // A stand-in for Claude behind the dev server: first it asks for a door schedule, then it answers.
  await page.route('**/api/claude-backend', (route) => route.fulfill({ json: { backend: 'api' } }));
  const calls = [];
  await page.route('**/api/claude', async (route) => {
    calls.push(route.request().postDataJSON());
    if (calls.length === 1) return route.fulfill(claudeReply([{ type: 'tool_use', id: 'c1', name: 'create_schedule', input: { category: 'door', sortBy: 'level' } }], 'tool_use'));
    return route.fulfill(claudeReply([{ type: 'text', text: 'I made a door schedule:\n- sorted by level' }]));
  });
  await page.getByRole('button', { name: 'Assistant' }).click();
  const input = page.getByRole('textbox', { name: 'Message to the assistant' });
  await input.fill('Make a door schedule sorted by level');
  await input.press('Enter');
  await expect(page.locator('.as-step')).toContainText('Created Door');
  await expect(page.locator('.as-bot').last()).toContainText('sorted by level');
  const result = await page.evaluate(() => ({ view: window.bd.activeView?.kind, sortBy: window.bd.activeView?.sortBy }));
  expect(result.view).toBe('schedule');
  expect(result.sortBy).toBe('level');
  expect(calls[0].tools.map((t) => t.name)).toContain('find_elements');
  // The second round carries Claude's call and its result, answered by id.
  const toolReply = calls[1].messages.at(-1);
  expect(toolReply.role).toBe('user');
  expect(toolReply.content[0]).toMatchObject({ type: 'tool_result', tool_use_id: 'c1' });
  expect(toolReply.content[0].content).toContain('created');
  // The change is one undo step.
  await page.evaluate(() => window.bd.undo());
  expect(await page.evaluate(() => window.bd.doc.all('schedule').some((s) => s.sortBy === 'level' && s.category === 'door'))).toBe(false);
  expect(errors).toEqual([]);
});

test('a floor plan picture attached to the assistant is placed, seen, calibrated and traced', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  await page.route('**/api/claude-backend', (route) => route.fulfill({ json: { backend: 'api' } }));
  const calls = [];
  let imageId = null;
  await page.route('**/api/claude', async (route) => {
    const body = route.request().postDataJSON();
    calls.push(body);
    const n = calls.length;
    if (n === 1) {
      imageId = /placed as image (\S+) in/.exec(body.messages[0].content.at(-1).text)?.[1];
      return route.fulfill(claudeReply([{ type: 'tool_use', id: 'v1', name: 'view_image', input: { image_id: imageId, region: [0, 0, 500, 200] } }], 'tool_use'));
    }
    if (n === 2) return route.fulfill(claudeReply([{ type: 'tool_use', id: 'k1', name: 'calibrate_image', input: { image_id: imageId, from: [100, 900], to: [1100, 900], distance: 10000 } }], 'tool_use'));
    if (n === 3)
      return route.fulfill(
        claudeReply(
          [
            {
              type: 'tool_use',
              id: 't1',
              name: 'trace_floor_plan',
              input: {
                image_id: imageId,
                walls: [
                  { from: [100, 900], to: [1100, 900], thickness: 300, exterior: true },
                  { from: [1100, 900], to: [1100, 300], thickness: 300, exterior: true },
                  { from: [1100, 300], to: [100, 300], thickness: 300, exterior: true },
                  { from: [100, 300], to: [100, 900], thickness: 300, exterior: true },
                ],
                doors: [{ at: [400, 900], width: 900 }],
                rooms: [{ at: [600, 600], name: 'Studio' }],
              },
            },
          ],
          'tool_use',
        ),
      );
    return route.fulfill(claudeReply([{ type: 'text', text: 'Traced.\n| Room | Area |\n|---|---|\n| Studio | 54 m² |' }]));
  });
  // A new, empty project, so the traced walls meet nothing else.
  await page.evaluate(() => window.bd.newProject('metric'));
  await page.getByRole('button', { name: 'Assistant' }).click();
  await page.evaluate(async () => {
    const c = document.createElement('canvas');
    c.width = 1200;
    c.height = 1000;
    const x = c.getContext('2d');
    x.fillStyle = '#fff';
    x.fillRect(0, 0, 1200, 1000);
    x.strokeRect(100, 300, 1000, 600);
    const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
    const input = document.querySelector('.as-compose input[type=file]');
    const dt = new DataTransfer();
    dt.items.add(new File([blob], 'plan.png', { type: 'image/png' }));
    input.files = dt.files;
    input.dispatchEvent(new Event('change'));
  });
  await expect(page.locator('.as-chip-file')).toContainText('plan.png');
  await page.getByRole('textbox', { name: 'Message to the assistant' }).press('Enter');
  await expect(page.locator('.as-table')).toContainText('Studio');
  // The picture went with the message, and view_image sent a picture back.
  expect(calls[0].messages[0].content[0]).toMatchObject({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg' } });
  expect(calls[1].messages.at(-1).content[0].content[1]).toMatchObject({ type: 'image' });
  const out = await page.evaluate((id) => {
    const doc = window.bd.doc;
    const img = doc.get(id);
    const room = doc.all('room').find((r) => r.name === 'Studio');
    return { px: img.px, calibrated: img.calibrated, w: img.w, rooms: !!room, area: window.bd.scene.rooms.room(room)?.area, doors: doc.all('door').filter((d) => doc.get(d.hostId)?.levelId === room.levelId).length };
  }, imageId);
  expect(out.px).toEqual([1200, 1000]);
  expect(out.calibrated).toBe(true);
  expect(out.w).toBeCloseTo(12000, 3);
  expect(out.area / 1e6).toBeGreaterThan(50);
  expect(errors).toEqual([]);
});
