import { test, expect } from '@playwright/test';
import { openApp, clickModel, screenOf } from './helpers.js';

/** The sample house in the Archicad workspace. */
async function openArchicad(page) {
  await page.addInitScript(() => localStorage.setItem('bd.settings', JSON.stringify({ workspaceAc: true })));
  const errors = await openApp(page, '?sample');
  await expect(page.locator('.ws-ac')).toBeVisible();
  return errors;
}

test('the Magic Wand: Space + click with the Slab tool makes a slab of the room', async ({ page }) => {
  const errors = await openArchicad(page);
  await page.evaluate(() => window.bd.run('floor'));
  await expect.poll(() => page.evaluate(() => window.bd.tool?.constructor.name)).toBe('SketchTool');
  const bath = await page.evaluate(() => window.bd.doc.all('room').find((r) => r.name === 'Bath').at);
  const before = await page.evaluate(() => window.bd.doc.count('floor'));
  await page.keyboard.down('Space');
  await clickModel(page, bath[0] + 300, bath[1] - 600);
  await page.keyboard.up('Space');
  expect(await page.evaluate(() => window.bd.doc.count('floor'))).toBe(before + 1);
  const area = await page.evaluate(() => {
    const b = window.bd.doc.all('floor').at(-1).boundary;
    let s = 0;
    for (let i = 0; i < b.length; i++) s += b[i][0] * b[(i + 1) % b.length][1] - b[(i + 1) % b.length][0] * b[i][1];
    return Math.abs(s) / 2e6;
  });
  expect(area).toBeCloseTo(11.16, 1);
  expect(errors).toEqual([]);
});

test('eyedropper (Alt + click) and syringe (Cmd + Alt + click)', async ({ page }) => {
  const errors = await openArchicad(page);
  const { part, ext } = await page.evaluate(() => {
    const doc = window.bd.doc;
    const walls = doc.all('wall');
    const mid = (w, f) => [w.a[0] + (w.b[0] - w.a[0]) * f, w.a[1] + (w.b[1] - w.a[1]) * f];
    const p = walls.find((w) => doc.get(w.typeId).name.includes('Partition') && !doc.all('door', 'window').some((o) => o.hostId === w.id));
    const e = walls.find((w) => doc.get(w.typeId).name.includes('Brick'));
    const len = Math.hypot(e.b[0] - e.a[0], e.b[1] - e.a[1]);
    return { part: { id: p.id, at: mid(p, 0.3) }, ext: { id: e.id, at: mid(e, 400 / len), type: e.typeId } };
  });
  const [px, py] = await screenOf(page, ...part.at);
  await page.mouse.move(px, py);
  await page.keyboard.down('Alt');
  await page.mouse.click(px, py);
  await page.keyboard.up('Alt');
  await expect.poll(() => page.evaluate(() => window.bd.tool?.constructor.name)).toBe('WallTool');
  expect(await page.evaluate(() => window.bd.pickedSettings.get('wall')?.typeId)).toBe('wt-int-partition');
  const [ex, ey] = await screenOf(page, ...ext.at);
  await page.mouse.move(ex, ey);
  await page.keyboard.down('Meta');
  await page.keyboard.down('Alt');
  await page.mouse.click(ex, ey);
  await page.keyboard.up('Alt');
  await page.keyboard.up('Meta');
  expect(await page.evaluate((id) => window.bd.doc.get(id).typeId, ext.id)).toBe('wt-int-partition');
  // No wall was drawn by those clicks.
  expect(await page.evaluate(() => window.bd.doc.count('wall'))).toBe(7);
  expect(errors).toEqual([]);
});

test('F5 shows the selection in 3D, and a click on it opens the Pet palette', async ({ page }) => {
  const errors = await openArchicad(page);
  const wall = await page.evaluate(() => {
    const app = window.bd;
    const w = app.doc.all('wall').find((x) => app.doc.get(x.typeId).name.includes('Partition'));
    const at = [w.a[0] + (w.b[0] - w.a[0]) * 0.3, w.a[1] + (w.b[1] - w.a[1]) * 0.3];
    // Select what a click there picks.
    const s = app.vc.modelToScreen(at);
    const id = app.pickTargets(app.vc.hitTest(s.x, s.y))[0];
    app.select([id]);
    return { id, at };
  });
  // A click on the selected wall: the Pet palette.
  await clickModel(page, ...wall.at);
  await expect(page.locator('.pet-palette')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.locator('.pet-palette')).toHaveCount(0);
  await page.evaluate((id) => window.bd.select([id]), wall.id);
  await page.locator('.canvas-wrap canvas').last().focus();
  await page.keyboard.press('F5');
  await expect.poll(() => page.evaluate(() => window.bd.activeView.kind)).toBe('view3d');
  expect(await page.evaluate(() => [...(window.bd.temp.get(window.bd.activeViewId)?.ids || [])].length)).toBeGreaterThan(0);
  expect(errors).toEqual([]);
});

test('Archicad shortcuts: Drag, Rotate and the story above', async ({ page }) => {
  const errors = await openArchicad(page);
  await page.evaluate(() => window.bd.select([window.bd.doc.all('wall')[0].id]));
  await page.locator('.canvas-wrap canvas').last().focus();
  await page.keyboard.press('ControlOrMeta+d');
  await expect.poll(() => page.evaluate(() => window.bd.tool?.constructor.name)).toBe('MoveTool');
  await page.keyboard.press('Escape');
  await page.evaluate(() => window.bd.select([window.bd.doc.all('wall')[0].id]));
  await page.keyboard.press('ControlOrMeta+e');
  await expect.poll(() => page.evaluate(() => window.bd.tool?.constructor.name)).toBe('RotateTool');
  await page.keyboard.press('Escape');
  await page.keyboard.press('ControlOrMeta+ArrowUp');
  await expect.poll(() => page.evaluate(() => window.bd.activeView.name)).toBe('Level 2');
  expect(errors).toEqual([]);
});
