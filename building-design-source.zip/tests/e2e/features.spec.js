import { test, expect } from '@playwright/test';
import { openApp, inkCoverage } from './helpers.js';
import { container, folderEntry, fileEntry, libraryPart } from '../fixtures/aclib.js';

test('every ribbon tab shows its tools without errors', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const tabs = page.locator('.ribbon [role="tab"]');
  const n = await tabs.count();
  expect(n).toBeGreaterThan(8);
  for (let i = 0; i < n; i++) {
    const tab = tabs.nth(i);
    if (!(await tab.isVisible())) continue;
    await tab.click();
    await expect(tab).toHaveAttribute('aria-selected', 'true');
  }
  expect(errors).toEqual([]);
});

test('dialogs for settings, collaboration and analysis open and close', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const commands = ['options', 'shortcuts', 'worksets', 'designOptions', 'globalParams', 'lineStyles', 'sunSettings', 'zones', 'syncHistory', 'manageLinks', 'phases', 'objectStyles', 'objectLibrary', 'masterLayouts', 'classifications', 'issues', 'projectParams'];
  for (const cmd of commands) {
    await page.evaluate((c) => window.bd.run(c), cmd);
    const dialog = page.locator('dialog[open]');
    await expect(dialog, cmd).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(dialog, cmd).toBeHidden();
  }
  expect(errors).toEqual([]);
});

test('views can be tiled side by side and drawn', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  await page.evaluate(() => {
    const app = window.bd;
    app.open3D();
    app.openView(app.doc.all('elevation')[0].id);
    app.run('tileViews');
  });
  // Tiles are laid out on the next frame.
  await expect.poll(() => page.evaluate(() => window.bd.viewport.tiles.length)).toBe(3);
  expect(await inkCoverage(page)).toBeGreaterThan(0.01);
  // Clicking a tile makes its view active.
  const target = await page.evaluate(() => {
    const t = window.bd.viewport.tiles.find((x) => x.viewId !== window.bd.activeViewId);
    const r = window.bd.shell.overlay.getBoundingClientRect();
    return { id: t.viewId, x: r.left + t.x + t.w / 2, y: r.top + t.y + t.h / 2 };
  });
  await page.mouse.click(target.x, target.y);
  expect(await page.evaluate(() => window.bd.activeViewId)).toBe(target.id);
  await page.evaluate(() => window.bd.run('tabViews'));
  expect(await page.evaluate(() => window.bd.viewport.tiled)).toBe(false);
  expect(errors).toEqual([]);
});

test('3D shadows, render and model elements from the newer tabs draw without errors', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  await page.evaluate(() => {
    const app = window.bd;
    const doc = app.doc;
    const L = doc.levels()[0].id;
    app.commit('things', () => {
      doc.add({ kind: 'truss', typeId: 'tt-pratt', levelId: L, a: [15000, 0], b: [24000, 0], offset: 2800 });
      doc.add({ kind: 'modelText', levelId: L, at: [15000, -3000], rotation: 0, text: 'TEST', size: 400, depth: 40, plane: 'vertical', offset: 0 });
      doc.add({ kind: 'wallSweep', wallId: doc.all('wall')[0].id, typeId: 'swt-band', side: 'exterior', z: 600 });
      doc.add({ kind: 'duct', typeId: 'dct-rect', levelId: L, a: [15000, 4000], b: [20000, 4000], offset: 2700 });
    });
    app.open3D();
    app.run('shadows');
  });
  expect(await inkCoverage(page)).toBeGreaterThan(0.01);
  await page.evaluate(() => window.bd.run('render'));
  await page.getByRole('button', { name: 'Render', exact: true }).click();
  await expect(page.locator('.render-preview img')).toBeVisible();
  expect(errors).toEqual([]);
});

test('a spline is drawn by clicks, a guide line snaps, and an issue keeps its viewpoint', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const canvas = page.locator('.canvas-wrap canvas').last();
  const box = await canvas.boundingBox();
  const at = (fx, fy) => [box.x + box.width * fx, box.y + box.height * fy];
  await page.evaluate(() => window.bd.run('spline'));
  for (const [fx, fy] of [[0.2, 0.85], [0.35, 0.75], [0.5, 0.85], [0.65, 0.75]]) await page.mouse.click(...at(fx, fy));
  await page.keyboard.press('Enter');
  const spline = await page.evaluate(() => window.bd.doc.all('spline')[0]);
  expect(spline.path).toHaveLength(4);
  await page.keyboard.press('Escape');
  // A horizontal guide line, then a line drawn from it snaps onto it.
  await page.evaluate(() => {
    window.bd.toolOptions('guideLine', { mode: 'two' }).mode = 'h';
    window.bd.run('guideLine');
  });
  await page.mouse.click(...at(0.5, 0.1));
  const guide = await page.evaluate(() => window.bd.guides.get(window.bd.activeViewId)?.[0]);
  expect(guide.d).toEqual([1, 0]);
  await page.keyboard.press('Escape');
  // An issue from the 3D view comes back with its camera.
  const cam = await page.evaluate(async () => {
    const bd = window.bd;
    bd.open3D();
    await new Promise((r) => setTimeout(r, 300));
    bd.vc.cam.yaw = 1.1;
    bd.run('issues');
    await new Promise((r) => setTimeout(r, 200));
    [...document.querySelectorAll('dialog[open] button')].find((b) => b.textContent.includes('New Issue')).click();
    const is = bd.doc.all('issue')[0];
    return { yaw: is.viewpoint.camera.yaw, snap: !!is.snapshot };
  });
  expect(cam).toEqual({ yaw: 1.1, snap: true });
  expect(errors).toEqual([]);
});

test('a PDF imports page by page at the drawing scale, from the app itself', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const external = [];
  page.on('request', (r) => {
    const u = new URL(r.url());
    if (!['localhost', '127.0.0.1'].includes(u.hostname) && !u.protocol.startsWith('data') && !u.protocol.startsWith('blob')) external.push(r.url());
  });
  const out = await page.evaluate(async () => {
    const bd = window.bd;
    bd.newProject('metric');
    const { PdfPage, buildPdf } = await import('/src/io/pdf.js');
    const pg = new PdfPage(420, 297);
    pg.color([0, 0, 0]);
    pg.lineWidth(0.5);
    pg.line([50, 50], [150, 50]);
    pg.text([60, 80], 'LIVING', 4);
    const bytes = buildPdf([pg, pg, pg]);
    const file = new File([bytes instanceof Blob ? bytes : new Blob([bytes])], 'plan.pdf', { type: 'application/pdf' });
    const done = bd.importPDF(file);
    for (let i = 0; i < 50 && !document.querySelector('dialog[open]'); i++) await new Promise((r) => setTimeout(r, 100));
    const dlg = document.querySelector('dialog[open]');
    dlg.querySelector('input[aria-label="Pages"]').value = '1, 3';
    dlg.querySelector('select[aria-label="Drawing scale"]').value = '50';
    [...dlg.querySelectorAll('button')].find((b) => b.textContent === 'Import').click();
    await done;
    return bd.doc.all('image').map((i) => ({ w: Math.round(i.w), name: i.name, calibrated: i.calibrated, page: i.pageMm.map(Math.round) }));
  });
  expect(out).toEqual([
    { w: 21000, name: 'plan - page 1', calibrated: true, page: [420, 297] },
    { w: 21000, name: 'plan - page 3', calibrated: true, page: [420, 297] },
  ]);
  expect(external).toEqual([]);
  expect(errors).toEqual([]);
});

test('a CAD drawing becomes walls, a window, a zone and drafting from its layers', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const out = await page.evaluate(async () => {
    const bd = window.bd;
    bd.newProject('metric');
    const { placeCAD } = await import('/src/io/cadplace.js');
    const { Scene } = await import('/src/core/scene.js');
    const rect = (x0, y0, x1, y1, layer) => ({ type: 'LWPOLYLINE', layer, flag: 1, vertices: [{ x: x0, y: y0 }, { x: x1, y: y0 }, { x: x1, y: y1 }, { x: x0, y: y1 }] });
    const line = (a, b, layer) => ({ type: 'LINE', layer, startPoint: { x: a[0], y: a[1] }, endPoint: { x: b[0], y: b[1] } });
    const entities = [
      rect(0, 0, 2000, 250, 'A-MURI'), rect(3200, 0, 6000, 250, 'A-MURI'), rect(5750, 250, 6000, 4000, 'A-MURI'), rect(0, 3750, 5750, 4000, 'A-MURI'), rect(0, 250, 250, 3750, 'A-MURI'),
      line([2000, 0], [3200, 0], 'A-FINESTRE'), line([2000, 125], [3200, 125], 'A-FINESTRE'), line([2000, 250], [3200, 250], 'A-FINESTRE'),
      rect(250, 250, 5750, 3750, 'A-ZONE'),
      { type: 'TEXT', layer: 'A-ZONE', startPoint: { x: 3000, y: 2000 }, text: 'Soggiorno', textHeight: 200, rotation: 0 },
      line([1000, 1000], [2000, 1500], 'A-ARREDI'),
    ];
    const cad = { units: 4, entities, blocks: {}, layers: ['A-MURI', 'A-FINESTRE', 'A-ZONE', 'A-ARREDI'].map((name) => ({ name })) };
    const view = bd.activeView;
    let res;
    bd.commit('Import DWG', () => (res = placeCAD(bd.doc, cad, { view, mode: 'smart' })));
    const room = bd.doc.all('room')[0];
    return { walls: res.model.walls.length, windows: res.model.windows.length, drafting: res.drafting, name: room.name, area: Math.round(new Scene(bd.doc).rooms.room(room).area / 1e4) / 100 };
  });
  expect(out).toEqual({ walls: 4, windows: 1, drafting: 1, name: 'Soggiorno', area: 19.25 });
  await page.evaluate(() => window.bd.run('view3d'));
  await page.waitForTimeout(500);
  expect(errors).toEqual([]);
});

test('a PDF from a CAD program becomes a model at the scale its title block states', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const out = await page.evaluate(async () => {
    const bd = window.bd;
    bd.newProject('metric');
    const { PdfPage, buildPdf } = await import('/src/io/pdf.js');
    // A 6 x 4 m room at 1:50 (millimetres on paper): 250 mm walls, a 1.2 m window in the bottom wall.
    const pg = new PdfPage(297, 210);
    const R = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
    const o = [40, 40];
    const p = (x, y) => [o[0] + x / 50, o[1] + y / 50];
    pg.color([0.29, 0.29, 0.29], false);
    for (const [x0, y0, x1, y1] of [[0, 0, 2000, 250], [3200, 0, 6000, 250], [5750, 250, 6000, 4000], [0, 3750, 5750, 4000], [0, 250, 250, 3750]]) pg.polygon(R(...p(x0, y0), ...p(x1, y1)));
    pg.color([0, 0, 0]);
    pg.lineWidth(0.18);
    for (const y of [60, 125, 190]) pg.line(p(2000, y), p(3200, y));
    pg.text(p(2700, 2000), '19,25 m²', 2.5);
    pg.text(p(2700, 2300), 'Soggiorno', 2.5);
    pg.text([250, 20], '1:50', 3);
    const bytes = buildPdf([pg]);
    const { openPDF } = await import('/src/io/pdfread.js');
    const pdf = await openPDF(bytes instanceof Uint8Array ? bytes : new Uint8Array(await new Blob([bytes]).arrayBuffer()));
    await bd.modelFromPdf(pdf, 1, 0, 'room.pdf', 72);
    const room = bd.doc.all('room')[0];
    return { walls: bd.doc.all('wall').length, windows: bd.doc.all('window').length, name: room?.name, prompt: document.querySelector('.statusbar, footer')?.textContent };
  });
  expect(out.walls).toBe(4);
  expect(out.windows).toBe(1);
  expect(out.name).toBe('Soggiorno');
  expect(out.prompt).toContain('1 of 1 zones measure as their stamps say');
  expect(errors).toEqual([]);
});

test('a calibrated picture of a plan becomes walls, a window, a door and a zone', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const out = await page.evaluate(async () => {
    const bd = window.bd;
    bd.newProject('metric');
    // A 6 x 4 m room at 20 mm a pixel: 200 mm walls, a window in the top wall, a door in the left one.
    const c = document.createElement('canvas');
    c.width = 340;
    c.height = 230;
    const g = c.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, 340, 230);
    g.fillStyle = '#000';
    for (const [x, y, w, h] of [[10, 10, 100, 10], [170, 10, 140, 10], [10, 200, 300, 10], [300, 10, 10, 200], [10, 10, 10, 50], [10, 105, 10, 105]]) g.fillRect(x, y, w, h);
    g.strokeStyle = '#000';
    g.lineWidth = 1;
    for (const y of [13.5, 15.5, 17.5]) (g.beginPath(), g.moveTo(110, y), g.lineTo(170, y), g.stroke());
    g.beginPath();
    g.arc(20, 105, 45, -Math.PI / 2, 0);
    g.stroke();
    const { placeUnderlay } = await import('/src/assistant/tools.js');
    const img = placeUnderlay(bd, { src: c.toDataURL('image/png'), name: 'plan', px: [340, 230], width: 340 * 20, calibrated: true });
    const res = await bd.modelFromImage(img.id);
    return { walls: bd.doc.all('wall').length, windows: res.windows, doors: res.doors, zones: res.zones.map((z) => Math.round(z.area)) };
  });
  expect(out.walls).toBeGreaterThanOrEqual(4);
  expect(out.windows).toBe(1);
  expect(out.doors).toBe(1);
  expect(out.zones).toEqual([20]);
  expect(errors).toEqual([]);
});

test('an IFC file opens as walls, openings and zones of the project', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const out = await page.evaluate(async () => {
    const bd = window.bd;
    const { writeIFC } = await import('/src/io/ifc.js');
    const text = writeIFC(bd);
    const ifc = typeof text === 'string' ? text : text.text;
    const want = { walls: bd.doc.all('wall').length, doors: bd.doc.all('door').length, windows: bd.doc.all('window').length, rooms: bd.doc.all('room').length };
    bd.newProject('metric');
    await bd.openIFC(new File([ifc], 'house.ifc'));
    const got = { walls: bd.doc.all('wall').length, doors: bd.doc.all('door').length, windows: bd.doc.all('window').length, rooms: bd.doc.all('room').length };
    bd.run('view3d');
    return { want, got };
  });
  expect(out.got).toEqual(out.want);
  await page.waitForTimeout(400);
  expect(errors).toEqual([]);
});

test('a photo of a plan taken at an angle is straightened and modelled', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const out = await page.evaluate(async () => {
    const bd = window.bd;
    bd.newProject('metric');
    // The sheet: a 6 x 4 m room at 20 mm a pixel, as in the picture test.
    const sheet = document.createElement('canvas');
    sheet.width = 340;
    sheet.height = 230;
    const g = sheet.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, 340, 230);
    g.fillStyle = '#000';
    for (const [x, y, w, h] of [[10, 10, 100, 10], [170, 10, 140, 10], [10, 200, 300, 10], [300, 10, 10, 200], [10, 10, 10, 50], [10, 105, 10, 105]]) g.fillRect(x, y, w, h);
    for (const y of [13.5, 15.5, 17.5]) (g.beginPath(), g.moveTo(110, y), g.lineTo(170, y), g.stroke());
    g.beginPath();
    g.arc(20, 105, 45, -Math.PI / 2, 0);
    g.stroke();
    // The photo: the sheet on a dark table, seen at an angle, twice as large.
    const { homography, applyH } = await import('/src/core/rectify.js');
    const W = 900;
    const H = 700;
    const corners = [[120, 90], [800, 140], [760, 620], [70, 560]];
    const toSheet = homography(corners, [[0, 0], [340, 0], [340, 230], [0, 230]]);
    const sd = g.getImageData(0, 0, 340, 230).data;
    const photo = document.createElement('canvas');
    photo.width = W;
    photo.height = H;
    const pctx = photo.getContext('2d');
    const im = pctx.createImageData(W, H);
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        const [u, v] = applyH(toSheet, [x + 0.5, y + 0.5]);
        const o = (y * W + x) * 4;
        if (u >= 0 && u < 340 && v >= 0 && v < 230) {
          const s = (Math.floor(v) * 340 + Math.floor(u)) * 4;
          im.data.set([sd[s], sd[s + 1], sd[s + 2], 255], o);
        } else im.data.set([60, 50, 45, 255], o);
      }
    pctx.putImageData(im, 0, 0);
    const { placeUnderlay } = await import('/src/assistant/tools.js');
    const img = placeUnderlay(bd, { src: photo.toDataURL('image/png'), name: 'photo', px: [W, H], width: 9000 });
    const st = await bd.straightenImage(img.id);
    // Calibrate: the sheet is 340 x 20 = 6800 mm wide.
    bd.commit('cal', () => bd.doc.update(img.id, { w: 6800, h: (6800 * st.pixels[1]) / st.pixels[0], calibrated: true }));
    const res = await bd.modelFromImage(img.id);
    return { corners: st.corners, walls: res.walls, zones: res.zones.map((z) => z.area) };
  });
  // The corners are found where the sheet lies in the photo.
  expect(out.corners).toEqual([[120, 90], [800, 140], [760, 620], [70, 560]]);
  expect(out.walls).toBeGreaterThanOrEqual(4);
  // One room of 5.6 x 3.6 m, within what resampling the photo twice blurs.
  expect(out.zones).toHaveLength(1);
  expect(Math.abs(out.zones[0] - 20.16)).toBeLessThan(1);
  expect(errors).toEqual([]);
});

test('a picture of a plan dropped on the app is modelled at an estimated scale', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const out = await page.evaluate(async () => {
    const bd = window.bd;
    bd.newProject('metric');
    // Two 3 x 4 m rooms at 20 mm a pixel, 200 mm walls, a door between them.
    const c = document.createElement('canvas');
    c.width = 340;
    c.height = 240;
    const g = c.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, 340, 240);
    g.fillStyle = '#000';
    for (const [x, y, w, h] of [[10, 10, 310, 10], [10, 210, 310, 10], [10, 10, 10, 210], [310, 10, 10, 210], [160, 10, 10, 70], [160, 125, 10, 95]]) g.fillRect(x, y, w, h);
    g.beginPath();
    g.arc(170, 125, 45, -Math.PI / 2, 0);
    g.stroke();
    const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
    const dt = new DataTransfer();
    dt.items.add(new File([blob], 'plan.png', { type: 'image/png' }));
    window.dispatchEvent(new DragEvent('drop', { dataTransfer: dt, bubbles: true, cancelable: true }));
    for (let i = 0; i < 100 && !bd.doc.all('room').length; i++) await new Promise((r) => setTimeout(r, 100));
    const { Scene } = await import('/src/core/scene.js');
    const s = new Scene(bd.doc);
    return { walls: bd.doc.all('wall').length, areas: bd.doc.all('room').map((r) => s.rooms.room(r).area / 1e6) };
  });
  expect(out.walls).toBeGreaterThanOrEqual(4);
  expect(out.areas).toHaveLength(2);
  // Each room is 2.8 x 4 m; an estimated scale lands within 20 % of the area.
  for (const a of out.areas) expect(Math.abs(a - 11.2) / 11.2).toBeLessThan(0.2);
  expect(errors).toEqual([]);
});

test('GDL objects: written in the editor or by the assistant, placed and drawn', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  await page.evaluate(() => window.bd.run('gdlObjects'));
  const dialog = page.locator('dialog[open]');
  await expect(dialog).toBeVisible();
  await dialog.locator('select[aria-label="New GDL object from"]').selectOption({ label: 'Table' });
  await expect(dialog.locator('.gdl-status')).toContainText('triangles');
  // A script error is shown with its line.
  const s3 = dialog.locator('textarea[aria-label="3D Script"]');
  await s3.fill('BLOCK A, B\nFOO');
  await expect(dialog.locator('.gdl-status')).toContainText('Line 1');
  await page.keyboard.press('Escape');
  const out = await page.evaluate(async () => {
    const bd = window.bd;
    const { runTool } = await import('/src/assistant/tools.js');
    const bad = await runTool(bd, 'gdl_object', { name: 'Stool', width: 400, depth: 400, height: 450, script3d: 'CYLIND ZZYZX, A/2\nWOBBLE' });
    const good = await runTool(bd, 'gdl_object', {
      name: 'Stool',
      params: [{ name: 'seat', kind: 'length', value: 40 }],
      script3d: 'ADD A/2, B/2, 0\nCYLIND ZZYZX - seat, 0.02\nADDZ ZZYZX - seat\nCYLIND seat, A/2\nDEL 2',
      place_at: [2000, 2000],
    });
    const el = bd.doc.get(good.placed);
    const plan = bd.doc.all('plan').find((v) => v.levelId === el.levelId);
    const sym = bd.scene.planOf(plan, el);
    const mesh = bd.scene.mesh(el);
    return { bad: bad.error, good, lines: sym.lines.length, tris: mesh.pos.length / 9 };
  });
  expect(out.bad).toMatch(/Line 2: Unknown command WOBBLE/);
  expect(out.good.triangles).toBeGreaterThan(40);
  expect(out.lines).toBeGreaterThan(10);
  expect(out.tris).toBe(out.good.triangles);
  await page.evaluate(() => window.bd.run('view3d'));
  await page.waitForTimeout(400);
  expect(errors).toEqual([]);
});

test('the assistant sees the plan, a part of it, and the 3D view', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  const out = await page.evaluate(async () => {
    const bd = window.bd;
    const { runTool } = await import('/src/assistant/tools.js');
    const plan = await runTool(bd, 'look_at_view', { view: 'Level 1' });
    const part = await runTool(bd, 'look_at_view', { view: 'Level 1', region: [0, 0, 4000, 3000], size: 600 });
    const d3 = await runTool(bd, 'look_at_view', { view: '3d' });
    // A picture of mostly the same colour is a blank render.
    const varied = async (r) => {
      const img = new Image();
      img.src = `data:${r._image.media_type};base64,${r._image.data}`;
      await img.decode();
      const c = document.createElement('canvas');
      c.width = 64;
      c.height = 48;
      const g = c.getContext('2d');
      g.drawImage(img, 0, 0, 64, 48);
      const d = g.getImageData(0, 0, 64, 48).data;
      const set = new Set();
      for (let i = 0; i < d.length; i += 4) set.add(`${d[i] >> 4},${d[i + 1] >> 4},${d[i + 2] >> 4}`);
      return set.size;
    };
    return { kinds: [plan.kind, part.kind, d3.kind], sizes: [plan.pixels, part.pixels], colours: [await varied(plan), await varied(part), await varied(d3)] };
  });
  expect(out.kinds).toEqual(['plan', 'plan', 'view3d']);
  expect(Math.max(...out.sizes[1])).toBe(600);
  for (const n of out.colours) expect(n).toBeGreaterThan(3);
  expect(errors).toEqual([]);
});

test('objects from an Archicad library file come in with their macros and are placed', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  await page.evaluate(() => window.bd.newProject('metric'));
  const table = libraryPart({
    script3d: 'ADDZ ZZYZX - 0.04\nBLOCK A, B, 0.04\nDEL 1\nFOR i = 0 TO 1\nFOR j = 0 TO 1\nADD i * (A - 0.05), j * (B - 0.05), 0\nCALL "Leg_m" PARAMETERS h = ZZYZX - 0.04\nDEL 1\nNEXT j\nNEXT i',
    params: [{ name: 'A', code: 2, value: 1.4, label: 'Width' }, { name: 'B', code: 2, value: 0.8, label: 'Depth' }, { name: 'ZZYZX', code: 2, value: 0.75, label: 'Height' }],
  });
  const leg = libraryPart({ script3d: 'BLOCK 0.05, 0.05, h', params: [{ name: 'h', code: 2, value: 0.7, label: 'Height' }] });
  const bytes = container([folderEntry('Furniture', [fileEntry('Plain Table.gsm', table)]), folderEntry('Macros', [fileEntry('Leg_m.gsm', leg)])]);
  await page.evaluate(() => window.bd.run('archicadLibrary'));
  const dlg = page.locator('dialog[open]');
  const chooser = page.waitForEvent('filechooser');
  await dlg.getByText('Add Library Files...').click();
  await (await chooser).setFiles({ name: 'Furniture.lcf', mimeType: 'application/octet-stream', buffer: Buffer.from(bytes) });
  await dlg.locator('.ac-item', { hasText: 'Plain Table' }).click();
  await expect(dlg.locator('.ac-detail')).toContainText('1400 x 800 x 750 mm');
  // The top and four legs: five blocks of twelve triangles.
  await expect(dlg.locator('.ac-detail')).toContainText('60 triangles');
  await dlg.getByRole('button', { name: 'Place' }).click();
  const out = await page.evaluate(() => {
    const bd = window.bd;
    const t = bd.doc.all('componentType').find((x) => x.name === 'Plain Table');
    let id;
    bd.commit('place', () => (id = bd.doc.add({ kind: 'component', typeId: t.id, levelId: bd.activeView.levelId, at: [0, 0], rotation: 0, offset: 0 }).id));
    return { macros: Object.keys(t.gdl.macros), tris: bd.scene.mesh(bd.doc.get(id)).pos.length / 9 };
  });
  expect(out.macros).toEqual(['leg_m']);
  expect(out.tris).toBe(60);
  expect(errors).toEqual([]);
});

test('the requirements check lists what a room lacks and keeps it as issues', async ({ page }) => {
  const errors = await openApp(page, '?sample');
  await page.evaluate(() => window.bd.run('checkRequirements'));
  const dlg = page.locator('dialog[open]');
  await expect(dlg).toBeVisible();
  await expect(dlg.locator('.dialog-text').first()).toContainText(/not met|meets/);
  const before = await page.evaluate(() => window.bd.doc.all('issue').length);
  const n = await dlg.locator('.cc-item').count();
  if (n) {
    await dlg.getByRole('button', { name: 'Make Issues' }).click();
    await expect.poll(() => page.evaluate(() => window.bd.doc.all('issue').length)).toBe(before + n);
  }
  await page.keyboard.press('Escape');
  expect(errors).toEqual([]);
});
